package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * HUD Editor v4 (v0.16.12 feedback round):
 * <ul>
 *   <li><b>Enabled-only</b>: the editor now shows ONLY enabled HUD modules -
 *       disabled ones are hidden entirely, so the screen is no longer crowded
 *       with ghost boxes for things you turned off. Enable a HUD in the
 *       modules menu and it appears in the editor.</li>
 *   <li><b>Gear icon</b>: every HUD in the editor has a small settings gear
 *       floating at its top-right corner. Click it to jump straight into that
 *       module's settings page; the back arrow returns to the editor.</li>
 *   <li>Left-click drag = move, right-click = reset, ESC = save.</li>
 * </ul>
 */
public class HudEditScreen extends Screen {
   private static final int HANDLE = 4;
   private static final int GEAR = 12;
   private final Screen parent;
   private HudModule dragging;
   private int grabDx;
   private int grabDy;

   public HudEditScreen(BlueClient blue, Screen parent) {
      super(Text.literal("HUD Editor"));
      this.parent = parent;
   }

   public HudEditScreen(Screen parent) {
      super(Text.literal("HUD Editor"));
      this.parent = parent;
   }

   /** v0.16.12: enabled HUDs only - disabled modules are hidden in the editor. */
   private List<HudModule> huds() {
      List<HudModule> out = new ArrayList<>();
      for (Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof HudModule hud && hud.isEnabled()) {
            out.add(hud);
         }
      }
      return out;
   }

   @Override
   public void close() {
      this.saveAndExit();
   }

   private void saveAndExit() {
      BlueClient.getInstance().configManager().save();
      MinecraftClient.getInstance().setScreen(this.parent);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
         this.saveAndExit();
         return true;
      }
      return super.keyPressed(input);
   }

   /** Null-safe size probe: HUDs that need a live player/world can throw when
    * the editor is opened from the main menu - that used to crash the game. */
   private int safeWidth(HudModule hud) {
      try {
         return Math.max(6, hud.getWidth());
      } catch (Throwable t) {
         return 40;
      }
   }

   private int safeHeight(HudModule hud) {
      try {
         return Math.max(6, hud.getHeight());
      } catch (Throwable t) {
         return 12;
      }
   }

   /** Gear position for a HUD. Sits just outside the top-right corner, but
    * flips INSIDE the box near the right screen edge so it never leaves the
    * screen. Same computation in render + click handling = always aligned. */
   private int gearX(HudModule hud) {
      int x = hud.getX() + this.safeWidth(hud);
      if (x + GEAR + 3 > this.width) {
         x = hud.getX() + this.safeWidth(hud) - GEAR - 2;
      } else {
         x += 3;
      }
      return x;
   }

   private int gearY(HudModule hud) {
      int y = hud.getY() - GEAR + 2;
      if (y < 2) {
         y = hud.getY() + 2;
      }
      return y;
   }

   private boolean gearHit(HudModule hud, int mx, int my) {
      int gx = this.gearX(hud);
      int gy = this.gearY(hud);
      return mx >= gx && mx <= gx + GEAR && my >= gy && my <= gy + GEAR;
   }

   private HudModule pick(int mx, int my) {
      // topmost first: reverse registration order
      List<HudModule> list = this.huds();
      for (int i = list.size() - 1; i >= 0; i--) {
         HudModule hud = list.get(i);
         int x = hud.getX();
         int y = hud.getY();
         if (mx >= x - HANDLE && mx <= x + this.safeWidth(hud) + HANDLE
             && my >= y - HANDLE && my <= y + this.safeHeight(hud) + HANDLE) {
            return hud;
         }
      }
      return null;
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      if (click.button() == 0) {
         List<HudModule> list = this.huds();
         for (int i = list.size() - 1; i >= 0; i--) {
            HudModule hud = list.get(i);
            if (this.gearHit(hud, (int) click.x(), (int) click.y())) {
               RenderUtil.clickSound();
               MinecraftClient.getInstance().setScreen(new ModuleSettingsScreen(
                  BlueClient.getInstance(), this, hud));
               return true;
            }
         }
         HudModule hud = this.pick((int) click.x(), (int) click.y());
         if (hud != null) {
            this.dragging = hud;
            this.grabDx = (int) click.x() - hud.getX();
            this.grabDy = (int) click.y() - hud.getY();
            RenderUtil.clickSound();
            return true;
         }
      } else if (click.button() == 1) {
         HudModule hud = this.pick((int) click.x(), (int) click.y());
         if (hud != null) {
            hud.resetPosition();
            RenderUtil.clickSound();
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseDragged(Click click, double dx, double dy) {
      if (this.dragging != null) {
         int nx = (int) click.x() - this.grabDx;
         int ny = (int) click.y() - this.grabDy;
         int maxX = this.width - this.safeWidth(this.dragging) - 2;
         int maxY = this.height - this.safeHeight(this.dragging) - 2;
         this.dragging.setPosition(Math.max(2, Math.min(maxX, nx)), Math.max(2, Math.min(maxY, ny)), this.width, this.height);
         return true;
      }
      return super.mouseDragged(click, dx, dy);
   }

   @Override
   public boolean mouseReleased(Click click) {
      if (this.dragging != null) {
         this.dragging = null;
         BlueClient.getInstance().configManager().save();
         RenderUtil.clickSound();
         return true;
      }
      return super.mouseReleased(click);
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      List<HudModule> list = this.huds();
      for (HudModule hud : list) {
         int x = hud.getX();
         int y = hud.getY();
         int w = this.safeWidth(hud);
         int h = this.safeHeight(hud);
         // corner brackets on every shown HUD (all are enabled now)
         int c = 0xFF3D6BFF;
         int len = 7;
         context.fill(x - 1, y - 1, x + len, y, c);
         context.fill(x - 1, y - 1, x, y + len, c);
         context.fill(x + w - len, y - 1, x + w, y, c);
         context.fill(x + w, y - 1, x + w + 1, y + len, c);
         context.fill(x - 1, y + h, x + len, y + h + 1, c);
         context.fill(x - 1, y + h - len, x, y + h + 1, c);
         context.fill(x + w - len, y + h, x + w, y + h + 1, c);
         context.fill(x + w, y + h - len, x + w + 1, y + h + 1, c);
         // settings gear - click opens this module's settings page
         int gx = this.gearX(hud);
         int gy = this.gearY(hud);
         boolean gearHover = this.gearHit(hud, mouseX, mouseY);
         net.bluenetwork.client.render.SmoothRect.fill(context, gx - 2, gy - 2, GEAR + 4, GEAR + 4, 4.0F,
            gearHover ? 0x33FFFFFF : 0x14FFFFFF);
         RenderUtil.drawIcon(context, "settings", gx, gy, GEAR,
            gearHover ? 0xFFFFFFFF : 0xFF9DB2FF);
      }
      RenderUtil.drawText(context, "HUD EDITOR - drag to move, right-click to reset, gear = settings, ESC to save",
         6, this.height - 12, 0xFF9DB2FF);
   }
}
