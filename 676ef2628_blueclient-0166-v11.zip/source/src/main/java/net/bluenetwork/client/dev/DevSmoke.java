package net.bluenetwork.client.dev;

import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Module;

/**
 * Dev-only self check, wired into {@link BlueClient#onInitializeClient()} when
 * dev mode is on. Verifies the module registry matches the expected catalogue
 * for v2 and logs a clear PASS/FAIL. Kept out of normal startup so feature
 * regressions surface early during Phase N development.
 */
public final class DevSmoke {
   /**
    * Baseline modules that must always be registered (original 29 + modules
    * added since). New modules are appended here as they land, so a missing
    * registration is caught while the total count may still grow.
    */
   private static final List<String> EXPECTED = List.of(
      "Client Logo", "FPS Display", "Coordinates", "Keystrokes", "Ping", "ArmorHUD",
      "Direction", "Speedometer", "Clock", "Server", "Biome", "Attack Indicator",
      "Playtime", "Frame Times", "Sun Position", "Item Countdown",
      "ToggleSprint", "Toggle Sneak", "Zoom", "Fullbright", "CPS", "Combo", "Reach",
      "Chat Height", "Chat Timestamps", "Mention Highlight", "Music Player",
      "Crosshair", "No Hurt Cam",
      "Day Counter", "Armor Durability", "Low Health Alert", "Memory Watchdog",
      "Alarm Timer", "Totem Counter", "Hunger Numbers", "Durability Warning",
      "Health Numbers", "FPS Graph", "Server Ticks", "Potion Timers",
      "Elytra HUD Assist", "Session Stats", "Nether Coords", "Dimension Display",
      "Safe Walk", "Anti AFK", "Auto Walk", "Sprint Modes",
      "Auto Respawn", "Adaptive Render Distance", "Chunk Load Indicator",
      "Frame Smooth", "UI Sound Pack", "Attack Chime", "Keybind Viewer",
      "Session Notes", "Target Info", "Waypoint Arrow", "Chat Cleaner",
      "Chat Logger", "Friend Presence", "Volume Mixer", "Pickup Tracker",
      "Auto Quality", "Performance Monitor",
      "Hotbar Info", "Light Level", "Server IP", "Player Count", "Air Meter",
      "Highlight Manager", "Name Formatter", "Auto Tool", "Drop Warning",
      "Low Food Alert", "Custom FOV", "Coords Converter", "Module Search",
      "XP Progress", "Mount Health", "Moon Phase", "Chunk Position",
      "Looked Block", "Spawn Distance", "Death Coords", "Sleep Reminder"
   );

   private DevSmoke() {
   }

   public static void selfCheck() {
      BlueClient blue = BlueClient.getInstance();
      if (blue == null) {
         BlueClient.LOGGER.error("[DevSmoke] FAIL - BlueClient instance is null");
         return;
      }

      int expected = EXPECTED.size();
      int actual = blue.moduleManager().getModules().size();
      int missing = 0;
      for (String name : EXPECTED) {
         Module module = blue.moduleManager().byName(name);
         if (module == null) {
            BlueClient.LOGGER.error("[DevSmoke] FAIL - expected module '{}' is not registered", name);
            missing++;
         }
      }
      int hudCount = blue.moduleManager().getHudModules().size();
      if (missing > 0 || actual < expected) {
         BlueClient.LOGGER.error(
            "[DevSmoke] FAIL - expected {} core modules, found {} ({} missing, {} HUD)",
            expected, actual, missing, hudCount);
      } else {
         BlueClient.LOGGER.info(
            "[DevSmoke] PASS - {} modules registered ({} core, {} HUD), version {}",
            actual, expected, hudCount, BlueClient.MOD_VERSION);
      }

      catalogueSummary();
   }

   /** Prints the v3 catalogue breakdown (dev only). */
   private static void catalogueSummary() {
      try {
         net.bluenetwork.client.module.ModuleCatalogue catalogue =
            new net.bluenetwork.client.module.ModuleCatalogue();
         StringBuilder sb = new StringBuilder("[DevSmoke] catalogue: ");
         boolean first = true;
         for (net.bluenetwork.client.module.Family family : net.bluenetwork.client.module.Family.values()) {
            if (!first) {
               sb.append(", ");
            }
            first = false;
            sb.append(family.displayName()).append('=')
              .append(catalogue.byFamily(family).size());
         }
         sb.append(" (total ").append(catalogue.size()).append(')');
         BlueClient.LOGGER.info(sb.toString());
      } catch (Throwable t) {
         BlueClient.LOGGER.error("[DevSmoke] catalogue summary failed", t);
      }
   }
}
