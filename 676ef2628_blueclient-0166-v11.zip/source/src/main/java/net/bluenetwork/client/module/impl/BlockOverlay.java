package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Block Overlay - customises the outline of the block under your crosshair:
 * pick the colour and opacity, and keep the box visible even when you are not
 * holding an item that interacts with the block.
 */
public class BlockOverlay extends Module {
   private final ColorSetting color = new ColorSetting("Color", "Outline colour of the target block", 0xFF3D6BFF);
   private final NumberSetting alpha = new NumberSetting("Opacity", "Outline opacity %", 100.0, 20.0, 100.0, 5.0);
   private final BooleanSetting alwaysShow = new BooleanSetting("Always show", "Draw the outline even without an interactable item", true);

   public BlockOverlay() {
      super("Block Overlay", "Customise the outline of the block you look at", Category.RENDER);
      this.addSettings(new Setting[]{this.color, this.alpha, this.alwaysShow});
   }

   public static boolean active() {
      BlockOverlay self = Module.find(BlockOverlay.class);
      return self != null && self.isEnabled();
   }

   public static int outlineArgb() {
      BlockOverlay self = Module.find(BlockOverlay.class);
      if (self == null) {
         return 0xFF3D6BFF;
      }
      int a = (int) Math.round(self.alpha.get() * 2.55D);
      return (Math.max(20, Math.min(255, a)) << 24) | (self.color.rgb() & 0xFFFFFF);
   }

   public static boolean always() {
      BlockOverlay self = Module.find(BlockOverlay.class);
      return self == null || self.alwaysShow.get();
   }
}
