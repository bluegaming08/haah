package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.brand.BlueBrand;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.CookieStorage;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ConnectScreen.class})
public abstract class ConnectScreenMixin {
   private static boolean blueclient$nextConnectBranded = false;
   private boolean blueclient$branded = false;
   @Shadow
   private Text status;

   @Inject(
      method = {"connect"},
      at = {@At("HEAD")}
   )
   private static void blueclient$captureTarget(
      Screen parent, MinecraftClient client, ServerAddress address, ServerInfo info, boolean quickPlay, CookieStorage cookies, CallbackInfo ci
   ) {
      blueclient$nextConnectBranded = info != null && BlueBrand.isBlueNetwork(info.address);
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void blueclient$markBranded(CallbackInfo ci) {
      this.blueclient$branded = blueclient$nextConnectBranded;
      blueclient$nextConnectBranded = false;
      // v0.16.12: the vanilla cancel button can sit anywhere - pin it
      // horizontally centred under the join stack so nothing looks off-centre.
      if (this.blueclient$branded) {
         ButtonWidget cancel = this.findCancelButton();
         if (cancel != null) {
            Screen self = (Screen)(Object)this;
            cancel.setPosition(self.width / 2 - cancel.getWidth() / 2, self.height / 2 + 56);
         }
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$renderBranded(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (this.blueclient$branded) {
         ci.cancel();
         int width = context.getScaledWindowWidth();
         int height = context.getScaledWindowHeight();

         // v0.16.11 revamp: deep-blue gradient + drifting brand-blue dots,
         // centred logo, big Poppins join title, live status line, animated
         // progress shimmer and a glass CANCEL - all pure functions of time
         // so the mixin keeps no extra state.
         int top = -16382193;
         int bottom = -16051661;
         int strips = 24;

         for (int i = 0; i < strips; i++) {
            double t = (double) i / (strips - 1);
            int c = stripColor(top, bottom, t);
            int y0 = (int) ((double) (height * i) / strips);
            int y1 = (int) ((double) (height * (i + 1)) / strips);
            context.fill(0, y0, width, y1, c);
         }

         long now = System.currentTimeMillis();
         java.util.Random dotSeed = new java.util.Random(0xC0FFEEL);
         for (int i = 0; i < 26; i++) {
            double baseX = dotSeed.nextDouble();
            double baseY = dotSeed.nextDouble();
            double speed = 0.008D + dotSeed.nextDouble() * 0.020D;
            double phase = (now / 1000.0D * speed + baseY) % 1.0D;
            int dy = (int) (phase * height);
            int dx = (int) (baseX * width + Math.sin((now / 900.0D) + i) * 14.0D);
            int alpha = 0x33 + (int) (0x22 * Math.sin((now / 600.0D) + i * 1.7D));
            int size = 2 + (i % 3);
            context.fill(dx, dy, dx + size, dy + size, (Math.max(0x14, alpha)) << 24 | 0x3D6BFF);
         }

         // logo: draw via RenderUtil so the 345-wide art in its 512 box is
         // centred on its VISIBLE width (the raw quad call was drawing an
         // invisible/degenerate quad - the logo never showed before).
         int logoH = Math.min(72, height / 6);
         int logoVisW = RenderUtil.logoWidth(logoH);
         int cy = height / 2;
         RenderUtil.drawLogoTinted(context, width / 2 - logoVisW / 2, cy - 92, logoH, -1);

         int dots = (int) (now / 400L % 4L);
         String title = "JOINING BLUE NETWORK" + ".".repeat(dots);
         RenderUtil.drawPoppinsCentered(context, title, width / 2.0F, cy - 8, 0xFFFFFFFF, 13.0F);

         if (this.status != null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            RenderUtil.drawText(context, this.status.getString(),
               (width - RenderUtil.textWidth(this.status.getString())) / 2, cy + 12, BlueColors.TEXT_MUTED);
         }

         // animated progress shimmer
         float barW = Math.min(220, width - 60);
         float barX = (width - barW) / 2.0F;
         float barY = cy + 30;
         net.bluenetwork.client.render.SmoothRect.fill(context, barX, barY, barW, 4, 2.0F, 0x2EFFFFFF);
         float sweep = (now % 1600L) / 1600.0F;
         float segW = barW * 0.3F;
         float sx = barX + (barW - segW) * (sweep < 0.5F ? sweep * 2.0F : (1.0F - sweep) * 2.0F);
         net.bluenetwork.client.render.SmoothRect.fill(context, sx, barY, segW, 4, 2.0F, 0xFF3D6BFF);

         ButtonWidget cancel = this.findCancelButton();
         if (cancel != null) {
            int x = cancel.getX();
            int y = cancel.getY();
            int w = cancel.getWidth();
            int h = cancel.getHeight();
            boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
            net.bluenetwork.client.render.SmoothRect.fill(context, x, y, w, h, 6.0F,
               hovered ? 0x4D141A26 : 0x33141A26);
            net.bluenetwork.client.render.SmoothRect.outline(context, x, y, w, h, 6.0F, 1.0F,
               hovered ? 0xFF3D6BFF : 0x55FFFFFF);
            String label = "CANCEL";
            RenderUtil.drawPoppinsCentered(context, label, x + w / 2.0F, y + (h - 8) / 2.0F,
               hovered ? 0xFFFFFFFF : BlueColors.TEXT_MUTED, 9.0F);
         }
      }
   }

   private ButtonWidget findCancelButton() {
      Screen self = (Screen)(Object)this;

      for (Element child : self.children()) {
         if (child instanceof ButtonWidget button) {
            return button;
         }
      }

      return null;
   }

   private static int stripColor(int a, int b, double t) {
      int aR = a >> 16 & 0xFF;
      int aG = a >> 8 & 0xFF;
      int aB = a & 0xFF;
      int bR = b >> 16 & 0xFF;
      int bG = b >> 8 & 0xFF;
      int bB = b & 0xFF;
      return 0xFF000000 | (int)(aR + (bR - aR) * t) << 16 | (int)(aG + (bG - aG) * t) << 8 | (int)(aB + (bB - aB) * t);
   }
}
