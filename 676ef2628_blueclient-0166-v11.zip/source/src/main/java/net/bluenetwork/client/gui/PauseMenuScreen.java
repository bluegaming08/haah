package net.bluenetwork.client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;

public class PauseMenuScreen extends Screen {
   private final List<PauseMenuScreen.Hit> hits = new ArrayList<>();

   public PauseMenuScreen() {
      super(Text.literal("Blue Client"));
   }

   public boolean shouldPause() {
      return true;
   }

   public boolean shouldCloseOnEsc() {
      return true;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      this.hits.clear();
      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();
      context.fill(0, 0, width, height, -2012146654);
      int left = 18;
      int logoH = 56;
      int logoW = RenderUtil.logoWidth(logoH);
      RenderUtil.drawLogo(context, left, 12, logoH);
      int textLeft = left + logoW + 8;
      RenderUtil.drawInterText(context, "BLUE CLIENT", textLeft, 20, BlueColors.TEXT_PRIMARY);
      context.fill(textLeft, 32, textLeft + RenderUtil.interTextWidth("BLUE CLIENT") / 2 + 4, 33, -13673473);
      String subtitle = this.client.isInSingleplayer() ? "singleplayer" : "multiplayer";
      RenderUtil.drawInterText(context, subtitle, textLeft, 38, BlueColors.TEXT_MUTED);
      int buttonW = 148;
      int buttonH = 20;
      int gap = 6;
      int startY = 88;
      int i = 0;
      this.button(
         context, this.hits, "pause:back", mouseX, mouseY, left, startY + (buttonH + gap) * i++, buttonW, buttonH, "play", "BACK TO GAME", false, this::close
      );
      this.button(
         context,
         this.hits,
         "pause:settings",
         mouseX,
         mouseY,
         left,
         startY + (buttonH + gap) * i++,
         buttonW,
         buttonH,
         "settings",
         "CLIENT SETTINGS",
         false,
         () -> this.client.setScreen(new ClientSettingsScreen(this))
      );
      this.button(
         context,
         this.hits,
         "pause:options",
         mouseX,
         mouseY,
         left,
         startY + (buttonH + gap) * i++,
         buttonW,
         buttonH,
         "sliders-horizontal",
         "OPTIONS",
         false,
         () -> this.client.setScreen(new OptionsScreen(this, this.client.options))
      );
      this.button(
         context,
         this.hits,
         "pause:accounts",
         mouseX,
         mouseY,
         left,
         startY + (buttonH + gap) * i++,
         buttonW,
         buttonH,
         "user-round",
         "ACCOUNTS",
         false,
         () -> this.client.setScreen(new AccountsScreen(this))
      );
      int quitY = startY + (buttonH + gap) * i + 6;
      String quitLabel = this.client.isInSingleplayer() ? "SAVE & QUIT TO TITLE" : "DISCONNECT";
      this.button(
         context,
         this.hits,
         "pause:quit",
         mouseX,
         mouseY,
         left,
         quitY,
         buttonW,
         buttonH,
         "log-out",
         quitLabel,
         true,
         () -> this.client.disconnect(ClientWorld.QUITTING_MULTIPLAYER_TEXT)
      );
      /* vanilla-mode switch: square glass button with a pickaxe icon */
      int vbW = 20;
      int vbX = width - vbW - 8;
      int vbY = 8;
      RenderUtil.drawRoundedRect(context, vbX, vbY, vbW, vbW, BlueColors.PANEL_BG, 4);
      RenderUtil.drawRoundedOutline(context, vbX, vbY, vbW, vbW, BlueColors.PANEL_BORDER, 4);
      RenderUtil.drawIcon(context, "pickaxe", vbX + 4, vbY + 4, vbW - 8, BlueColors.TEXT_MUTED);
      this.hits.add(new PauseMenuScreen.Hit(vbX, vbY, vbW, vbW, () -> {
         BlueClient.getInstance().settings().customPauseMenu(false);
         this.client.setScreen(new GameMenuScreen(true));
      }));
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int)click.x();
      int my = (int)click.y();

      for (PauseMenuScreen.Hit hit : this.hits) {
         if (hit.contains(mx, my)) {
            RenderUtil.clickSound();
            hit.action().run();
            return true;
         }
      }

      return super.mouseClicked(click, doubled);
   }

   private void button(
      DrawContext context,
      List<PauseMenuScreen.Hit> hits,
      String id,
      int mx,
      int my,
      int x,
      int y,
      int w,
      int h,
      String icon,
      String label,
      boolean accent,
      Runnable action
   ) {
      boolean hovered = mx >= x && mx < x + w && my >= y && my < y + h;
      float progress = net.bluenetwork.client.util.HoverAnim.progress(id, hovered,
         net.bluenetwork.client.util.HoverAnim.rate(BlueClient.getInstance().settings().animations()));
      int body = accent ? -2144379905 : lerpColor(BlueColors.PANEL_BG, BlueColors.PANEL_BG_HOVER, progress);
      RenderUtil.drawRoundedRect(context, x, y, w, h, body, 6);
      int borderRest = accent ? -2130706433 : BlueColors.PANEL_BORDER;
      int border = accent ? borderRest : lerpColor(borderRest, -14531329, progress);
      RenderUtil.drawRoundedOutline(context, x, y, w, h, border, 6);
      if (progress > 0.05F) {
         int glow = (int)(96.0F * progress);
         context.fill(x + 4, y, x + w - 4, y + 1, glow << 24 | 16777215);
      }

      int iconColor = accent ? -1 : lerpColor(BlueColors.TEXT_MUTED, -11699713, progress);
      int unitW = 16 + RenderUtil.interTextWidth(label);
      int unitX = x + (w - unitW) / 2;
      int labelColor = accent ? BlueColors.TEXT_PRIMARY : lerpColor(BlueColors.TEXT_MUTED, BlueColors.TEXT_PRIMARY, progress);
      RenderUtil.drawIcon(context, icon, unitX, y + (h - 10) / 2 + 1, 10, iconColor);
      RenderUtil.drawInterText(context, label, unitX + 16, y + (h - 10) / 2 + 1, labelColor);
      hits.add(new PauseMenuScreen.Hit(x, y, w, h, action));
   }

   private static int lerpColor(int a, int b, double t) {
      int aR = a >> 16 & 0xFF;
      int aG = a >> 8 & 0xFF;
      int aB = a & 0xFF;
      int bR = b >> 16 & 0xFF;
      int bG = b >> 8 & 0xFF;
      int bB = b & 0xFF;
      return 0xFF000000 | (int)(aR + (bR - aR) * t) << 16 | (int)(aG + (bG - aG) * t) << 8 | (int)(aB + (bB - aB) * t);
   }

   private record Hit(int x, int y, int w, int h, Runnable action) {
      boolean contains(int mx, int my) {
         return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
      }
   }
}
