package net.bluenetwork.client.ui.theme;

import net.bluenetwork.client.config.ThemeManager;

/**
 * v2 theme catalogue. Mirrors the themes already supported by
 * {@link net.bluenetwork.client.config.ThemeManager} (DARK / LIGHT / COSMIC /
 * EMBER / MIDNIGHT / NEON / EMERALD) as a typed enum so new UI code can switch
 * cleanly instead of comparing raw strings.
 *
 * <p>Phase 1: the enum exists as the typed view over the current theme system.
 * It is deliberately NOT a second source of truth — {@link #current()} always
 * reads {@link ThemeManager#currentTheme()}, so the whole client (legacy +
 * v2) stays on one palette at all times. Phase 1b replaces the raw palette
 * ints with semantic tokens that derive from this enum.</p>
 */
public enum UiTheme {
   DARK("DARK"),
   LIGHT("LIGHT"),
   COSMIC("COSMIC"),
   EMBER("EMBER"),
   MIDNIGHT("MIDNIGHT"),
   NEON("NEON"),
   EMERALD("EMERALD");

   private final String id;

   UiTheme(String id) {
      this.id = id;
   }

   public String id() {
      return id;
   }

   /** True for themes designed on a light background (only LIGHT today). */
   public boolean isLight() {
      return this == LIGHT;
   }

   public static UiTheme current() {
      return fromId(ThemeManager.currentTheme());
   }

   public static UiTheme fromId(String id) {
      if (id != null) {
         for (UiTheme t : values()) {
            if (t.id.equalsIgnoreCase(id.trim())) {
               return t;
            }
         }
      }
      return DARK;
   }
}
