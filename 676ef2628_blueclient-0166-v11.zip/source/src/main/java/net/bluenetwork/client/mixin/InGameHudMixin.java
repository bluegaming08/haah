package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.ScreenOverlay;
import net.bluenetwork.client.module.impl.CustomCrosshair;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public abstract class InGameHudMixin {
   @Inject(
      method = {"renderCrosshair"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$customCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      CustomCrosshair crosshair = find();
      if (crosshair != null && crosshair.isEnabled()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player != null && mc.options.getPerspective().isFirstPerson()) {
            ci.cancel();
            int cx = mc.getWindow().getScaledWidth() / 2;
            int cy = mc.getWindow().getScaledHeight() / 2;
            int color = crosshair.color();
            int size = crosshair.size();
            boolean outline = crosshair.outline();
            int black = -16119286;
            String var12 = crosshair.style();
            switch (var12) {
               case "Dot":
                  if (outline) {
                     context.fill(cx - size / 2 - 1, cy - size / 2 - 1, cx + size / 2 + 2, cy + size / 2 + 2, black);
                  }

                  context.fill(cx - size / 2, cy - size / 2, cx + size / 2 + 1, cy + size / 2 + 1, color);
                  break;
               case "Circle":
                  int r = size + 2;

                  for (int a = 0; a < 16; a++) {
                     double angle = a * Math.PI / 8.0;
                     int px = (int)Math.round(Math.cos(angle) * r);
                     int py = (int)Math.round(Math.sin(angle) * r);
                     if (outline) {
                        context.fill(cx + px - 1, cy + py - 1, cx + px + 2, cy + py + 2, black);
                     }

                     context.fill(cx + px, cy + py, cx + px + 1, cy + py + 1, color);
                  }
                  break;
               default:
                  int gap = size / 2 + 1;
                  int half = 1;
                  context.fill(cx - half, cy - size - 1, cx + half + 1, cy - gap, color);
                  context.fill(cx - half, cy + gap, cx + half + 1, cy + size + 1, color);
                  context.fill(cx - size - 1, cy - half, cx - gap, cy + half + 1, color);
                  context.fill(cx + gap, cy - half, cx + size + 1, cy + half + 1, color);
                  if (outline) {
                     context.fill(cx - 1, cy - 1, cx + 2, cy + 2, black);
                     context.fill(cx, cy, cx + 1, cy + 1, color);
                  }
            }
         }
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("TAIL")},
      require = 0
   )
   private void blueclient$screenOverlays(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         if (module instanceof ScreenOverlay overlay && module.isEnabled()) {
            try {
               overlay.renderOverlay(context);
            } catch (Throwable ignored) {
            }
         }
      }
   }

   private static CustomCrosshair find() {
      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         if (module instanceof CustomCrosshair crosshair) {
            return crosshair;
         }
      }

      return null;
   }
}
