package net.bluenetwork.client.ui.screen;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.music.MusicEngine;
import net.bluenetwork.client.module.impl.MusicPlayer;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.ui.material.GlassPanel;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * MusicScreen (v0.16.9) - replaces the old SongsScreen. Lists every song in
 * the .minecraft/songs folder as a scrollable list: click a row to play it,
 * click the now-playing bar to stop. Lazy-loading on purpose: this class only
 * touches MusicPlayer.listSongs()/playSongFile(), never any decoder classes
 * directly, so merely opening it can never pull a decoder onto the classpath.
 */
public class MusicScreen extends Screen {
   private static final int ROW_H = 20;
   private static final int VISIBLE_ROWS = 9;
   private final Screen parent;
   private int scroll;
   private final List<Rect> rowRects = new ArrayList<>();
   private Rect stopRect;

   public MusicScreen(Screen parent) {
      super(Text.literal("Music"));
      this.parent = parent;
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   private void back() {
      MinecraftClient mc = MinecraftClient.getInstance();
      mc.setScreen(this.parent != null ? this.parent : null);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      if (input.key() == 256) {
         this.back();
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
      List<Path> songs = MusicPlayer.listSongs();
      int maxScroll = Math.max(0, songs.size() - VISIBLE_ROWS);
      this.scroll = Math.max(0, Math.min(maxScroll, this.scroll - (int) Math.signum(vAmount)));
      return true;
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) click.x();
      int my = (int) click.y();
      List<Path> songs = MusicPlayer.listSongs();
      for (int i = 0; i < this.rowRects.size(); i++) {
         Rect r = this.rowRects.get(i);
         if (r.contains(mx, my)) {
            int idx = this.scroll + i;
            if (idx < songs.size()) {
               RenderUtil.clickSound();
               MusicPlayer.playSongFile(songs.get(idx));
            }
            return true;
         }
      }
      if (this.stopRect != null && this.stopRect.contains(mx, my) && MusicEngine.INSTANCE.isPlaying()) {
         RenderUtil.clickSound();
         MusicEngine.INSTANCE.stop();
         return true;
      }
      return super.mouseClicked(click, doubled);
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0x990B0E14);

      List<Path> songs = MusicPlayer.listSongs();
      int cw = Math.max(240, Math.min(320, w - 40));
      int listH = ROW_H * Math.min(VISIBLE_ROWS, Math.max(1, songs.size()));
      int ch = 40 + listH + 26;
      int cx = (w - cw) / 2;
      int cy = (h - ch) / 2;

      GlassPanel.panel(context, cx, cy, cw, ch, 14.0F, GlassSurface.defaultSurface(), true, DesignTokens.accent());
      TextPainter.drawPoppins(context, "MUSIC", cx + 16, cy + 12, DesignTokens.textHi(), 13.0F);
      TextPainter.drawPoppins(context, songs.size() + " SONGS", cx + cw - 16 - TextPainter.poppinsWidth(songs.size() + " SONGS", 8.0F),
         cy + 15, DesignTokens.textMid(), 8.0F);

      this.rowRects.clear();
      int ly = cy + 34;
      String nowPlaying = MusicEngine.INSTANCE.isPlaying() ? MusicEngine.INSTANCE.nowPlaying() : "";
      for (int i = 0; i < VISIBLE_ROWS; i++) {
         int idx = this.scroll + i;
         if (idx >= songs.size()) {
            break;
         }
         Path song = songs.get(idx);
         String name = song.getFileName().toString();
         int dot = name.lastIndexOf('.');
         if (dot > 0) {
            name = name.substring(0, dot);
         }
         Rect r = new Rect(cx + 10, ly + i * ROW_H, cw - 20, ROW_H - 2);
         this.rowRects.add(r);
         boolean hover = r.contains(mouseX, mouseY);
         boolean current = !nowPlaying.isEmpty() && name.equals(stripExt(nowPlaying));
         if (current) {
            net.bluenetwork.client.render.SmoothRect.fill(context, r.x, r.y, r.w, r.h, 6.0F, 0x333D6BFF);
         } else if (hover) {
            net.bluenetwork.client.render.SmoothRect.fill(context, r.x, r.y, r.w, r.h, 6.0F, 0x14FFFFFF);
         }
         int tx = r.x + (current ? 17 : 6);
         RenderUtil.drawText(context, fit(name, r.w - 12), tx, r.y + 6,
            current ? 0xFFFFFFFF : (hover ? DesignTokens.textHi() : DesignTokens.textMid()));
      }

      // now-playing / hint bar
      int by = cy + 40 + listH + 4;
      this.stopRect = null;
      if (!nowPlaying.isEmpty()) {
         this.stopRect = new Rect(cx + 10, by, cw - 20, 18);
         boolean hover = this.stopRect.contains(mouseX, mouseY);
         net.bluenetwork.client.render.SmoothRect.fill(context, this.stopRect.x, this.stopRect.y, this.stopRect.w, this.stopRect.h, 6.0F, hover ? 0x26FFFFFF : 0x14FFFFFF);
         RenderUtil.drawText(context, "STOP", this.stopRect.x + 5, this.stopRect.y + 5, DesignTokens.textHi());
         RenderUtil.drawText(context, fit(nowPlaying, this.stopRect.w - 40),
            this.stopRect.x + 34, this.stopRect.y + 5, DesignTokens.textHi());
      } else if (songs.isEmpty()) {
         RenderUtil.drawText(context, "No songs yet - drop mp3/wav/m4a into .minecraft/songs",
            cx + 12, by + 5, DesignTokens.textMid());
      } else {
         RenderUtil.drawText(context, "Click a song to play it", cx + 12, by + 5, DesignTokens.textMid());
      }

      // scroll hint
      if (songs.size() > VISIBLE_ROWS) {
         String hint = (this.scroll + 1) + "-" + Math.min(songs.size(), this.scroll + VISIBLE_ROWS) + " / " + songs.size();
         RenderUtil.drawText(context, hint, cx + cw - 12 - RenderUtil.textWidth(hint), cy + ch - 10, DesignTokens.textMid());
      }
      RenderUtil.drawText(context, "ESC to go back", cx + 12, cy + ch - 10, DesignTokens.textMid());
   }

   private static String stripExt(String name) {
      int dot = name.lastIndexOf('.');
      return dot > 0 ? name.substring(0, dot) : name;
   }

   private static String fit(String text, int maxWidth) {
      if (RenderUtil.textWidth(text) <= maxWidth) {
         return text;
      }
      String t = text;
      while (t.length() > 3 && RenderUtil.textWidth(t + "...") > maxWidth) {
         t = t.substring(0, t.length() - 1);
      }
      return t + "...";
   }

   private static final class Rect {
      final int x;
      final int y;
      final int w;
      final int h;

      Rect(int x, int y, int w, int h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
