package net.bluenetwork.client.module.impl;

import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.text.Text;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Fullbright — real lightmap boost. The gamma option in 1.21.11 is validated to
 * 0.0–1.0, so the module can no longer write 16.0 into the option; instead the
 * LightmapTextureManager mixin swaps the gamma read for our unbounded option
 * while the module is on (see LightmapTextureManagerMixin). Brightness is
 * adjustable and restored by simply turning the module off.
 */
public class Fullbright extends Module {
   private static volatile boolean on = false;
   private static SimpleOption<Double> bright;

   private final NumberSetting brightness = new NumberSetting("Brightness", "Boost level (16 = fullbright)", 16.0, 1.0, 16.0, 1.0);

   public Fullbright() {
      super("Fullbright", "Maximum brightness - see in the dark.", Category.RENDER);
      this.addSettings(new Setting[]{this.brightness});
   }

   @Override
   protected void onEnable() {
      on = true;
   }

   @Override
   protected void onDisable() {
      on = false;
   }

   /** True while the module is enabled — read by the lightmap mixin every frame. */
   public static boolean isBright() {
      return on;
   }

   /** The boosted gamma option handed to the lightmap while on (lazily built, cached). */
   public static SimpleOption<Double> brightGamma() {
      if (!on) {
         return null;
      }
      Fullbright module = current();
      double value = module != null ? module.brightness.get() : 16.0;
      SimpleOption<Double> option = ensure();
      if (Math.abs(option.getValue() - value) > 0.001) {
         option.setValue(value);
      }
      return option;
   }

   private static Fullbright current() {
      try {
        Module module = net.bluenetwork.client.BlueClient.getInstance().moduleManager().byName("Fullbright");
        if (module instanceof Fullbright fullbright) {
           return fullbright;
        }
      } catch (Throwable ignored) {
      }
      return null;
   }

   private static synchronized SimpleOption<Double> ensure() {
      if (bright == null) {
         // BlueBrightCallbacks lives inside net.minecraft.client.option so it
         // can implement the package-private Callbacks interface (unbounded gamma).
         bright = new SimpleOption<>(
            "blueclient.fullbright",
            SimpleOption.emptyTooltip(),
            (option, value) -> Text.literal(""),
            new net.minecraft.client.option.BlueBrightCallbacks(),
            16.0,
            value -> {
            });
      }
      return bright;
   }
}
