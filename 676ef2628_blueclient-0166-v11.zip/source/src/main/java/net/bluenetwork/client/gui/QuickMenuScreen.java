package net.bluenetwork.client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public class QuickMenuScreen extends Screen {
   private final List<QuickMenuScreen.Hit> hits = new ArrayList<>();
   private final long openedAt = System.currentTimeMillis();

   public QuickMenuScreen() {
      super(Text.literal("Blue Client"));
   }

   public boolean shouldPause() {
      return false;
   }

   public boolean shouldCloseOnEsc() {
      return true;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      this.hits.clear();
      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();
      int logoH = 72;
      int logoW = RenderUtil.logoWidth(logoH);
      int centerX = width / 2;
      int logoY = height / 2 - 96;
      RenderUtil.drawRoundedRect(context, centerX - 74, logoY - 8, 148, logoH + 62, 1713779268, 14);
      RenderUtil.drawLogo(context, centerX - logoW / 2, logoY, logoH);
      String wordmark = "BLUE CLIENT";
      RenderUtil.drawInterText(context, wordmark, centerX - RenderUtil.interTextWidth(wordmark) / 2, logoY + logoH + 4, BlueColors.TEXT_PRIMARY);
      String version = BlueClient.MOD_VERSION + " · 1.21.11";
      RenderUtil.drawInterText(context, version, centerX - RenderUtil.interTextWidth(version) / 2, logoY + logoH + 16, -13673473);
      int bw = 96;
      int bh = 24;
      int gap = 8;
      int totalW = bw * 3 + gap * 2;
      int bx = centerX - totalW / 2;
      int by = logoY + logoH + 34;
      float intro = 1.0F;
      if (BlueClient.getInstance().settings().menuIntroAnim()) {
         long el = System.currentTimeMillis() - this.openedAt;
         intro = Math.max(0.0F, Math.min(1.0F, el / 220.0F));
      }
      float eased = 1.0F - (1.0F - intro) * (1.0F - intro);
      int dy = Math.round((1.0F - eased) * 12.0F);
      int alpha = (int) (255.0F * eased);
      // the logo card + texts fade in slightly ahead of the buttons
      this.quickButton(context, mouseX, mouseY, bx, by + dy, bw, bh, "layout-dashboard", "Modules", () -> {
         BlueClient blue = BlueClient.getInstance();
         MinecraftClient mc = MinecraftClient.getInstance();
         mc.setScreen(new net.bluenetwork.client.ui.screen.ModuleMenuScreen(blue, QuickMenuScreen.this));
      }, alpha);
      this.quickButton(context, mouseX, mouseY, bx + bw + gap, by + dy, bw, bh, "move", "HUD Editor", () -> {
         BlueClient blue = BlueClient.getInstance();
         MinecraftClient mc = MinecraftClient.getInstance();
         mc.setScreen(new net.bluenetwork.client.ui.screen.HudEditScreen(blue, QuickMenuScreen.this));
      }, alpha);
      this.quickButton(
         context,
         mouseX,
         mouseY,
         bx + (bw + gap) * 2,
         by + dy,
         bw,
         bh,
         "settings",
         "Settings",
         () -> MinecraftClient.getInstance().setScreen(new ClientSettingsScreen(this)),
         alpha
      );
      String hint = "ESC to close";
      RenderUtil.drawText(context, hint, centerX - RenderUtil.textWidth(hint) / 2, by + bh + 8, BlueColors.TEXT_MUTED);
   }

   private void quickButton(DrawContext context, int mouseX, int mouseY, int x, int y, int w, int h, String icon, String label, Runnable action) {
      this.quickButton(context, mouseX, mouseY, x, y, w, h, icon, label, action, 255);
   }

   private void quickButton(DrawContext context, int mouseX, int mouseY, int x, int y, int w, int h, String icon, String label, Runnable action, int alpha) {
      boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
      String id = "quick:" + label;
      float progress = net.bluenetwork.client.util.HoverAnim.progress(id, hovered,
         net.bluenetwork.client.util.HoverAnim.rate(BlueClient.getInstance().settings().animations()));
      int body = lerpColor(-1441720801, -300211404, progress);
      RenderUtil.drawRoundedRect(context, x, y, w, h, body, 7);
      int borderColor = lerpColor(1728053247, -299744001, progress);
      RenderUtil.drawRoundedOutline(context, x, y, w, h, borderColor, 7);
      if (progress > 0.05F) {
         int glow = (int)(96.0F * progress);
         context.fill(x + 5, y, x + w - 5, y + 1, glow << 24 | 16777215);
      }

      int iconColor = lerpColor(BlueColors.TEXT_MUTED, -11699713, progress);
      int labelW = RenderUtil.interTextWidth(label);
      int groupW = 15 + labelW;
      int startX = x + (w - groupW) / 2;
      RenderUtil.drawIcon(context, icon, startX, y + (h - 11) / 2 + 1, 11, iconColor);
      RenderUtil.drawInterText(context, label, startX + 15, y + (h - 10) / 2 + 1, BlueColors.TEXT_PRIMARY);
      this.hits.add(new QuickMenuScreen.Hit(x, y, w, h, action));
   }

   private static int lerpColor(int a, int b, double t) {
      int aR = a >> 16 & 0xFF;
      int aG = a >> 8 & 0xFF;
      int aB = a & 0xFF;
      int bR = b >> 16 & 0xFF;
      int bG = b >> 8 & 0xFF;
      int bB = b & 0xFF;
      return 0xFF000000 | (int)(aR + (bR - aR) * t) << 16 | (int)(aG + (bG - aG) * t) << 8 | (int)(aB + (bB - aB) * t);
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int)click.x();
      int my = (int)click.y();
      if (click.button() == 0) {
         for (QuickMenuScreen.Hit hit : this.hits) {
            if (mx >= hit.x && mx < hit.x + hit.w && my >= hit.y && my < hit.y + hit.h) {
               RenderUtil.clickSound();
               hit.action.run();
               return true;
            }
         }
      }

      return super.mouseClicked(click, doubled);
   }

   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      int guiKey = BlueClient.getInstance().settings().guiKeybind();
      if (key == guiKey && System.currentTimeMillis() - this.openedAt < 250L) {
         return true;
      } else if (key != 256 && (guiKey <= 0 || key != guiKey)) {
         return super.keyPressed(input);
      } else {
         this.close();
         return true;
      }
   }

   private record Hit(int x, int y, int w, int h, Runnable action) {
   }
}
