package net.bluenetwork.client.mixin;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.thread.NameableExecutor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Chunk-build worker thread boost (Settings &gt; Performance &gt; Chunk Builder
 * Threads). Vanilla mesh-builds chunk sections on the shared main worker pool;
 * giving the ChunkBuilder a larger dedicated pool keeps chunk generation and
 * rebuilds from starving the render thread, so flying / fast turning stays
 * smooth. Skipped entirely when Sodium is installed - Sodium replaces the
 * chunk builder with its own, and we must not fight it over threads.
 */
@Mixin({WorldRenderer.class})
public abstract class WorldRendererMixin {
   private static ExecutorService previousPool;

   /**
    * Block Overlay module: replaces the vanilla crosshair-block outline with a
    * configurable colour/opacity box, and can keep it visible even when the
    * held item cannot interact with the block.
    */
   @Inject(
      method = {"renderTargetBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void blueclient$customBlockOutline(net.minecraft.client.render.VertexConsumerProvider.Immediate immediate,
                                              net.minecraft.client.util.math.MatrixStack matrices,
                                              boolean hasBlock, net.minecraft.client.render.state.WorldRenderState state,
                                              CallbackInfo ci) {
      if (!net.bluenetwork.client.module.impl.BlockOverlay.active()) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (!net.bluenetwork.client.module.impl.BlockOverlay.always() && !hasBlock) {
         return;
      }
      if (mc.player == null || mc.world == null || mc.crosshairTarget == null
            || mc.crosshairTarget.getType() != net.minecraft.util.hit.HitResult.Type.BLOCK
            || !(mc.crosshairTarget instanceof net.minecraft.util.hit.BlockHitResult hit)) {
         ci.cancel();
         return;
      }
      try {
         var cam = mc.gameRenderer.getCamera().getCameraPos();
         var pos = hit.getBlockPos();
         var shape = mc.world.getBlockState(pos).getOutlineShape(mc.world, pos);
         int argb = net.bluenetwork.client.module.impl.BlockOverlay.outlineArgb();
         net.minecraft.client.render.VertexRendering.drawOutline(
            matrices, immediate.getBuffer(net.minecraft.client.render.RenderLayers.linesTranslucent()),
            shape, pos.getX() - cam.x, pos.getY() - cam.y, pos.getZ() - cam.z, argb & 0xFFFFFF, (argb >>> 24) / 255.0F);
      } catch (Throwable t) {
         // never break world rendering over a cosmetic outline
      }
      ci.cancel();
   }

   @ModifyExpressionValue(
      method = {"reload()V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/thread/Util;getMainWorkerExecutor()Lnet/minecraft/util/thread/NameableExecutor;"
      ),
      require = 0
   )
   private NameableExecutor blueclient$chunkThreadBoost(NameableExecutor original) {
      try {
         if (FabricLoader.getInstance().isModLoaded("sodium")) {
            return original;
         }
         int boost = BlueClient.getInstance().settings().chunkThreads();
         boolean preloadBoost = net.bluenetwork.client.module.impl.ChunkPreload.boostThreads();
         if (boost <= 0 && !preloadBoost) {
            return original;
         }
         int extra = boost <= 1 ? 2 : (boost == 2 ? 4 : 8);
         if (preloadBoost) {
            extra += 4;
         }
         int threads = Math.max(2, Runtime.getRuntime().availableProcessors() + extra);
         ExecutorService pool = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "Blue Client Chunk Builder");
            t.setPriority(Thread.NORM_PRIORITY - 1);
            t.setDaemon(true);
            return t;
         });
         ExecutorService old = previousPool;
         previousPool = pool;
         if (old != null) {
            old.shutdown();
         }
         return new NameableExecutor(pool);
      } catch (Throwable t) {
         return original;
      }
   }
}
