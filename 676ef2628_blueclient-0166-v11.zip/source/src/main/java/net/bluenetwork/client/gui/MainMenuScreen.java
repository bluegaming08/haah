package net.bluenetwork.client.gui;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.brand.BlueBrand;
import net.bluenetwork.client.presence.NetworkStats;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.material.GlassPanel;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.bluenetwork.client.settings.ClientSettings;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class MainMenuScreen extends Screen {
   private static final int PARTICLE_COUNT = 90;
   private float uiScale = 1.0F;
   private int btnLeft;
   private int btnTop;
   private int btnRight;
   private int btnBottom;
   private static final String NEWS_TITLE = "Blue Client x Blue Network";
   private static final String NEWS_DESCRIPTION = "The Best Minecraft Server\nFeatures: Tier Testing, Blue SMP, Battle Royale and much more!";
   private static final String NEWS_IMAGE_URL = "https://cdn.discordapp.com/banners/1428698374336413829/f0aba37c5ddcdd268bf390e5f2e6af87.png?size=2048";
   private static final String NEWS_BUTTON_URL = "play.sennahosting.com";
   private final List<MainMenuScreen.Button> buttons = new ArrayList<>();
   private MainMenuScreen.Particle[] particles;
   private CompletableFuture<Optional<NativeImageBackedTexture>> newsImageFuture;
   private static Identifier customBgTexture;
   private static boolean customBgTried = false;
   private CompletableFuture<Optional<SkinTextures>> skinFuture;
   private SkinTextures skin;

   public MainMenuScreen() {
      super(Text.literal("Blue Client"));
      BlueClient.getInstance().newsManager().refreshIfStaleAsync();
      this.loadNewsImage();
   }

   private void loadNewsImage() {
      this.newsImageFuture = CompletableFuture.supplyAsync(() -> {
         try {
            // Load image from Discord CDN
            java.net.URL url = new java.net.URL(NEWS_IMAGE_URL);
            java.io.InputStream is = url.openStream();
            NativeImage img = NativeImage.read(is);
            NativeImageBackedTexture tex = new NativeImageBackedTexture(() -> "blueclient:news_image", img);
            MinecraftClient.getInstance().getTextureManager().registerTexture(Identifier.of("blueclient", "news_image"), tex);
            is.close();
            return Optional.of(tex);
         } catch (Exception e) {
            return Optional.empty();
         }
      });
   }

   protected void init() {
      super.init();
      this.skin = null;

      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         // v0.16.12: getGameProfile() is the profile Minecraft cached at
         // startup, so after an account switch the menu kept drawing the OLD
         // skin. Build a fresh profile from the live session instead.
         net.minecraft.client.session.Session session = mc.getSession();
         java.util.UUID id = session.getUuidOrNull();
         if (id == null) {
            id = java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:" + session.getUsername()).getBytes(java.nio.charset.StandardCharsets.UTF_8));
         }
         this.skinFuture = mc.getSkinProvider().fetchSkinTextures(new com.mojang.authlib.GameProfile(id, session.getUsername()));
         this.skinFuture.thenAccept(result -> result.ifPresent(textures -> this.skin = textures));
      } catch (Throwable var2) {
         this.skinFuture = null;
      }
   }

   public boolean shouldPause() {
      return false;
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   private void initParticles(int width, int height) {
      Random random = new Random();
      this.particles = new MainMenuScreen.Particle[90];

      for (int i = 0; i < 90; i++) {
         MainMenuScreen.Particle p = new MainMenuScreen.Particle();
         p.x = random.nextDouble() * width;
         p.y = random.nextDouble() * height;
         p.vx = (random.nextDouble() - 0.5) * 0.15;
         p.vy = -0.05 - random.nextDouble() * 0.2;
         p.size = 1.0F + random.nextFloat() * 2.5F;
         p.alpha = 40 + random.nextInt(80);
         p.swayPhase = random.nextDouble() * Math.PI * 2.0;
         p.swaySpeed = 0.3 + random.nextDouble() * 0.8;
         this.particles[i] = p;
      }
   }

   private static int lerpColor(int a, int b, double t) {
      int aR = a >> 16 & 0xFF;
      int aG = a >> 8 & 0xFF;
      int aB = a & 0xFF;
      int bR = b >> 16 & 0xFF;
      int bG = b >> 8 & 0xFF;
      int bB = b & 0xFF;
      int r = (int)(aR + (bR - aR) * t);
      int g = (int)(aG + (bG - aG) * t);
      int bl = (int)(aB + (bB - aB) * t);
      return 0xFF000000 | r << 16 | g << 8 | bl;
   }

   private static int parseHex(String hex, int fallback) {
      try {
         return 0xFF000000 | Integer.parseInt(hex.replace("#", "").trim(), 16) & 16777215;
      } catch (Throwable var3) {
         return fallback;
      }
   }

   private int s(int v) {
      return Math.round((float)v * this.uiScale);
   }

   private void gradient(DrawContext context, int width, int height, int top, int bottom) {
      int strips = 24;

      for (int i = 0; i < strips; i++) {
         double t = (double)i / (strips - 1);
         int color = lerpColor(top, bottom, t);
         int y0 = (int)((double)(height * i) / strips);
         int y1 = (int)((double)(height * (i + 1)) / strips);
         context.fill(0, y0, width, y1, color);
      }
   }

   private void renderParticles(DrawContext context, int width, int height, boolean fall, int baseColor) {
      if (this.particles == null) {
         this.initParticles(width, height);
      }

      long now = System.currentTimeMillis();

      for (MainMenuScreen.Particle p : this.particles) {
         double sway = Math.sin(now / 1000.0 * p.swaySpeed + p.swayPhase) * 0.2;
         p.x = p.x + (p.vx + sway * 0.1);
         p.y = p.y + (fall ? -p.vy : p.vy);
         if (fall) {
            if (p.y > height + 4) {
               p.y = -4.0;
               p.x = Math.random() * width;
            }
         } else if (p.y < -4.0) {
            p.y = height + 4;
            p.x = Math.random() * width;
         }

         if (p.x < -4.0) {
            p.x = width + 4;
         } else if (p.x > width + 4) {
            p.x = -4.0;
         }

         int color = p.alpha << 24 | baseColor & 16777215;
         int ix = (int)p.x;
         int iy = (int)p.y;
         int s = (int)p.size;
         context.fill(ix, iy, ix + s, iy + s, color);
      }
   }

   private static int[] sunsetPalette(double time) {
      int[][] palettes = new int[][]{{-15462874, -12969138}, {-15069394, -8769707}, {-15853010, -13739126}};
      double cycle = time / 24.0 % palettes.length;
      int i = (int)cycle;
      double t = cycle - i;
      int[] a = palettes[i];
      int[] b = palettes[(i + 1) % palettes.length];
      return new int[]{lerpColor(a[0], b[0], t), lerpColor(a[1], b[1], t)};
   }

   private void renderBackground(DrawContext context, int width, int height) {
      boolean animations = BlueClient.getInstance().settings().animations();
      int background = BlueClient.getInstance().settings().menuBackground();
      switch (background) {
         case 1:
            this.gradient(context, width, height, -16118246, -15392714);
            if (animations) {
               this.renderParticles(context, width, height, true, -1379585);
            }
            break;
         case 2:
            int[] palette = sunsetPalette(System.currentTimeMillis() / 1000.0);
            this.gradient(context, width, height, palette[0], palette[1]);
            long now = System.currentTimeMillis();

            for (int i = 0; i < 4; i++) {
               int bandY = 20 + i * 26;
               int bandH = 6 + i * 2;
               double phase = (now / 30000.0 + i * 0.27) % 1.0;
               int bandX = (int)(-80.0 + phase * (width + 160));
               context.fill(bandX, bandY, bandX + 90, bandY + bandH, 352321535);
            }
            break;
         case 3:
            ClientSettings settings = BlueClient.getInstance().settings();
            this.gradient(context, width, height, parseHex(settings.gradientTop(), -16117200), parseHex(settings.gradientBottom(), -16767264));
            break;
         case 4:
            if (this.loadCustomBackground()) {
               context.drawTexturedQuad(customBgTexture, 0, 0, width, height, 0.0F, 1.0F, 0.0F, 1.0F);
               context.fill(0, 0, width, height, 1073741824);
            } else {
               this.gradient(context, width, height, -16382193, -16051661);
            }
            break;
         default:
            this.gradient(context, width, height, -15922680, -13426673);
            if (animations) {
               this.renderParticles(context, width, height, false, -4950486);

               for (int i = 0; i < 26; i++) {
                  double phase = System.currentTimeMillis() / 14.0 + i * 137.0;
                  int sx = (int)(phase * 0.6 % width);
                  int sy = (int)(phase * 1.3 % height);
                  context.fill(sx, sy, sx + 1, sy + 2, 1627389951);
               }
            }
      }
   }

   private boolean loadCustomBackground() {
      if (customBgTried) {
         return customBgTexture != null;
      } else {
         customBgTried = true;

         try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("background.png");
            if (!Files.exists(file)) {
               return false;
            } else {
               NativeImage image = NativeImage.read(Files.newInputStream(file));
               NativeImageBackedTexture texture = new NativeImageBackedTexture(() -> "blueclient/menu_background", image);
               customBgTexture = Identifier.of("blueclient", "dynamic/menu_background");
               this.client.getTextureManager().registerTexture(customBgTexture, texture);
               return true;
            }
         } catch (Throwable var4) {
            BlueClient.LOGGER.debug("Custom background failed", var4);
            customBgTexture = null;
            return false;
         }
      }
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      this.buttons.clear();
      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();
      this.renderBackground(context, width, height);

      /* v0.16.7 responsive layout: the whole flagship menu (Lunar-inspired
         centred badge + wordmark, primary button stack, bottom icon dock)
         now scales with the window. On small windows / high GUI scale every
         element shrinks, the news dock tucks beside (or hides behind) the
         button column instead of overflowing, and nothing overlaps. */
      /* v0.16.8: the whole composition is 15% smaller by default at full
         screen (uiScale capped at 0.85), every text is centred + auto-scaled
         to fit its panel instead of being trimmed with "...", and the news
         dock is a smaller wide rectangle (2:1). */
      this.uiScale = Math.max(0.55F, Math.min(0.85F, Math.min(width / 400.0F, height / 280.0F)));
      int cx = width / 2;
      int logoH = s(74);
      int logoY = Math.max(s(8), height / 2 - s(150));
      // v0.16.11: center on the logo's VISIBLE width (the texture rides a
      // square 512 box with the 345-wide art centred in it), not on the box.
      int logoVisW = RenderUtil.logoWidth(logoH);
      RenderUtil.drawLogoTinted(context, cx - logoVisW / 2, logoY, logoH, -1);

      /* v0.16.9 wordmark: bold Poppins, two-tone - "BLUE" in brand blue,
         "CLIENT" in white, no underline. */
      int wordY = logoY + logoH + s(4);
      // v0.16.11 wordmark: "BLUE" in bold SemiBold + brand blue, "CLIENT" in
      // the lighter Medium weight + white, with an explicit gap between them.
      float wordSize = 13.0F * this.uiScale;
      String left = "BLUE";
      String rightWord = "CLIENT";
      int wordGap = s(5);
      int leftW = RenderUtil.interTextWidth(left, wordSize);
      int rightW = RenderUtil.poppinsMediumWidth(rightWord, wordSize);
      float fit = Math.min(1.0F, (float)(width - s(16)) / (float) Math.max(1, leftW + wordGap + rightW));
      wordSize *= fit;
      leftW = Math.round(leftW * fit);
      rightW = Math.round(rightW * fit);
      wordGap = Math.round(wordGap * fit);
      int wordX = cx - (leftW + wordGap + rightW) / 2;
      RenderUtil.drawPoppinsShadow(context, left, wordX, wordY, 0xFF3D6BFF, wordSize);
      RenderUtil.drawPoppinsMediumShadow(context, rightWord, wordX + leftW + wordGap, wordY, BlueColors.TEXT_PRIMARY, wordSize);

      int buttonW = Math.min(s(184), width - s(24));
      int buttonH = s(20);
      int gap = s(6);
      int startY = wordY + s(26);
      this.btnLeft = cx - buttonW / 2;
      this.btnRight = cx + buttonW / 2;
      this.btnTop = startY;
      this.btnBottom = startY + buttonH * 3 + gap * 2;
      this.menuButton(context, mouseX, mouseY, cx - buttonW / 2, startY, buttonW, buttonH, "play", "SINGLEPLAYER",
         () -> this.client.setScreen(new SelectWorldScreen(this)));
      this.menuButton(context, mouseX, mouseY, cx - buttonW / 2, startY + buttonH + gap, buttonW, buttonH, "globe", "MULTIPLAYER",
         () -> this.client.setScreen(new MultiplayerScreen(this)));
      this.menuButton(context, mouseX, mouseY, cx - buttonW / 2, startY + (buttonH + gap) * 2, buttonW, buttonH, "settings", "OPTIONS",
         () -> this.client.setScreen(new net.minecraft.client.gui.screen.option.OptionsScreen(this, this.client.options)));

      /* bottom icon dock */
      record Dock(String icon, String label, Runnable action) {
      }
      java.util.List<Dock> dock = new java.util.ArrayList<>();
      dock.add(new Dock("settings", "CLIENT SETTINGS", () -> this.client.setScreen(new ClientSettingsScreen(this))));
      if (BlueBrand.modMenuInstalled()) {
         dock.add(new Dock("layout-grid", "MODS", () -> {
            Screen mods = BlueBrand.openModMenu(this);
            if (mods != null) {
               this.client.setScreen(mods);
            }
         }));
      }
      if (BlueBrand.flashbackInstalled()) {
         dock.add(new Dock("disc-3", "FLASHBACK", () -> {
            Screen fb = BlueBrand.openFlashback(this);
            if (fb != null) {
               this.client.setScreen(fb);
            }
         }));
      }
      dock.add(new Dock("log-out", "QUIT GAME", () -> this.client.scheduleStop()));
      int iconSize = s(24);
      int igap = s(6);
      int dockW = dock.size() * iconSize + (dock.size() - 1) * igap;
      int dx = cx - dockW / 2;
      int dy = height - iconSize - s(12);
      for (Dock entry : dock) {
         this.iconButton(context, mouseX, mouseY, dx, dy, iconSize, entry.icon(), entry.label(), entry.action());
         dx += iconSize + igap;
      }

      this.drawNetworkPanel(context, s(14), 0, mouseX, mouseY);
      this.drawPlayerCard(context, width, mouseX, mouseY);
      String footer = "\u00a9 Blue Client - not affiliated with Mojang";
      drawFitText(context, footer, cx, height - s(10), BlueColors.TEXT_MUTED, width - s(12));
   }

   private void iconButton(DrawContext context, int mouseX, int mouseY, int x, int y, int size, String icon, String label, Runnable action) {
      boolean hovered = mouseX >= x && mouseX < x + size && mouseY >= y && mouseY < y + size;
      float progress = hoverProgress("dock:" + label, hovered);
      float glass = Math.max(0.0F, Math.min(1.0F, BlueClient.getInstance().settings().menuButtonOpacity() / 100.0F));
      SmoothRect.fill(context, x, y, size, size, 7.0F,
         withAlpha(DesignTokens.panelBg() & 0xFFFFFF, glass + 0.10F * progress));
      SmoothRect.outline(context, x, y, size, size, 7.0F, 1.2F,
         withAlpha(lerpColor(DesignTokens.panelBorder(), DesignTokens.accent(), progress) & 0xFFFFFF,
            Math.max(0.30F, glass * 0.8F) + 0.20F * progress));
      RenderUtil.drawIcon(context, icon, x + (size - 12) / 2, y + (size - 12) / 2, 12,
         lerpColor(BlueColors.TEXT_MUTED, -11699713, progress));
      if (hovered) {
         int lw = RenderUtil.textWidth(label) + 10;
         int lx = Math.max(2, Math.min(x + size / 2 - lw / 2, context.getScaledWindowWidth() - lw - 2));
         int ly = y - 16;
         GlassPanel.panelNoShadow(context, lx, ly, lw, 13, 4.0F, true, BlueColors.PANEL_BORDER);
         RenderUtil.drawText(context, label, lx + 5, ly + 2, BlueColors.TEXT_PRIMARY);
      }
      this.buttons.add(new MainMenuScreen.Button(x, y, size, size, action));
   }

   /** Main-menu glass button - same material as the modules menu panels:
    * soft drop shadow, translucent body tint, hairline border that fades to
    * the theme accent on hover. Label never trims: it scales down to fit. */
   private void menuButton(DrawContext context, int mouseX, int mouseY, int x, int y, int w, int h, String icon, String label, Runnable action) {
      boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
      float progress = hoverProgress("menu:" + label, hovered);
      float radius = 7.0F;
      float glass = Math.max(0.0F, Math.min(1.0F, BlueClient.getInstance().settings().menuButtonOpacity() / 100.0F));
      SmoothRect.fill(context, x, y, w, h, radius,
         withAlpha(DesignTokens.panelBg() & 0xFFFFFF, glass + 0.10F * progress));
      SmoothRect.outline(context, x, y, w, h, radius, 1.5F,
         withAlpha(lerpColor(DesignTokens.panelBorder(), DesignTokens.accent(), progress) & 0xFFFFFF,
            Math.max(0.30F, glass * 0.8F) + 0.25F * progress));

      float labelSize = 9.0F * this.uiScale;
      int iconSize = (int) Math.round(10.0F * this.uiScale);
      int labelW = RenderUtil.interTextWidth(label, labelSize);
      int unitW = iconSize + 5 + labelW;
      float unitScale = Math.min(1.0F, (float)(w - 12) / unitW);
      int unitW2 = Math.max(1, Math.round(unitW * unitScale));
      int unitX = x + (w - unitW2) / 2;
      int iconColor = lerpColor(BlueColors.TEXT_MUTED, -11699713, progress);
      RenderUtil.drawIcon(context, icon, unitX, y + (h - iconSize) / 2, iconSize, iconColor);
      int labelColor = lerpColor(BlueColors.TEXT_PRIMARY, -11699713, progress);
      RenderUtil.drawPoppinsShadow(context, label, unitX + iconSize + 5, y + (h - labelSize) / 2.0F, labelColor, labelSize * unitScale);
      this.buttons.add(new MainMenuScreen.Button(x, y, w, h, action));
   }

   private static float hoverProgress(String id, boolean hovered) {
      return net.bluenetwork.client.util.HoverAnim.progress(id, hovered,
         net.bluenetwork.client.util.HoverAnim.rate(BlueClient.getInstance().settings().animations()));
   }

   private void drawNetworkPanel(DrawContext context, int unused, int unusedY, int mouseX, int mouseY) {
      int w = s(196);
      int h = s(92);
      int width = context.getScaledWindowWidth();
      int panelY = context.getScaledWindowHeight() - s(14) - h;
      if (panelY < s(10)) {
         return;
      }
      int x = width - w - s(14);
      int y = panelY;
      // if the centred button column overlaps the banner, shrink from the left
      if (x < this.btnRight + s(6) && y < this.btnBottom && y + h > this.btnTop) {
         int maxW = x + w - this.btnRight - s(8) + w; // never used wider than original
         w = Math.min(w, (x + w) - (this.btnRight + s(8)));
         if (w < s(124)) {
            return;
         }
         h = Math.min(h, w / 2);
         x = width - w - s(14);
      }

      boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
      float progress = hoverProgress("menu:news", hovered);
      GlassPanel.panelNoShadow(context, x, y, w, h, 12.0F, true,
         lerpColor(BlueColors.PANEL_BORDER, -14531329, progress));

      if (this.newsImageFuture != null && this.newsImageFuture.isDone()) {
         try {
            Optional<NativeImageBackedTexture> imgOpt = this.newsImageFuture.join();
            boolean drew = false;
            if (imgOpt.isPresent()) {
               NativeImage img = imgOpt.get().getImage();
               if (img != null && img.getWidth() > 0 && img.getHeight() > 0) {
                  // 1.21.11 drawTexturedQuad(id, x1,y1,x2,y2, u1,u2,v1,v2).
                  // Centre-crop the banner to the panel's aspect so it never squashes.
                  float iw = img.getWidth();
                  float ih = img.getHeight();
                  float targetAspect = (float) (w - 6) / (float) Math.max(1, h - 6);
                  float imgAspect = iw / ih;
                  float u0 = 0.0F, u1 = 1.0F, v0 = 0.0F, v1 = 1.0F;
                  if (imgAspect > targetAspect) { // image wider -> crop sides
                     float keep = targetAspect / imgAspect;
                     u0 = (1.0F - keep) / 2.0F;
                     u1 = 1.0F - u0;
                  } else {                        // image taller -> crop top/bottom
                     float keep = imgAspect / targetAspect;
                     v0 = (1.0F - keep) / 2.0F;
                     v1 = 1.0F - v0;
                  }
                  context.drawTexturedQuad(Identifier.of("blueclient", "news_image"),
                     x + 3, y + 3, x + w - 3, y + h - 3, u0, u1, v0, v1);
                  drew = true;
               }
            }
            if (!drew) {
               drawNewsPlaceholder(context, x, y, w, h);
            }
         } catch (Throwable e) {
            drawNewsPlaceholder(context, x, y, w, h);
         }
      } else {
         drawNewsPlaceholder(context, x, y, w, h);
      }

      // click the banner -> join Blue Network directly
      this.buttons.add(new MainMenuScreen.Button(x, y, w, h, () -> {
         RenderUtil.clickSound();
         joinBlueNetwork();
      }));
   }

   private void drawNewsPlaceholder(DrawContext context, int x, int y, int w, int h) {
      context.fill(x + 4, y + 4, x + w - 4, y + h - 4, 0xFF1a1e2e);
      drawFitInter(context, "BLUE NETWORK", x + w / 2, y + h / 2 - s(14), BlueColors.TEXT_PRIMARY, 9.0F, w - 16);
      drawFitText(context, "Click to join " + NEWS_BUTTON_URL, x + w / 2, y + h / 2 + s(2), BlueColors.TEXT_MUTED, w - 16);
   }

   /** Joins play.sennahosting.com straight from the news banner click. */
   private void joinBlueNetwork() {
      try {
         net.minecraft.client.network.ServerAddress address = net.minecraft.client.network.ServerAddress.parse(NEWS_BUTTON_URL);
         net.minecraft.client.network.ServerInfo info = new net.minecraft.client.network.ServerInfo(
            "Blue Network", NEWS_BUTTON_URL, net.minecraft.client.network.ServerInfo.ServerType.OTHER);
         net.minecraft.client.network.CookieStorage cookies = new net.minecraft.client.network.CookieStorage(
            new java.util.HashMap<>(), new java.util.HashMap<>(), false);
         MinecraftClient client = MinecraftClient.getInstance();
         net.minecraft.client.gui.screen.multiplayer.ConnectScreen.connect(this, client, address, info, false, cookies);
      } catch (Throwable t) {
         BlueClient.LOGGER.error("Failed to join Blue Network from the news banner", t);
      }
   }

   private static int withAlpha(int rgb, float alpha) {
      int a = Math.max(0, Math.min(255, (int)(alpha * 255.0F)));
      return a << 24 | rgb & 0xFFFFFF;
   }

   /** Poppins text centred on cx, scaled down (never "...") to fit maxWidth,
    * and scaled with the menu's uiScale so text shrinks with the layout.
    * Renders the pure-black MiniMessage-style shadow. Returns drawn width. */
   private int drawFitInter(DrawContext context, String text, int cx, int y, int color, float baseSize, int maxWidth) {
      if (text == null || text.isEmpty() || maxWidth <= 1) {
         return 0;
      }
      baseSize *= this.uiScale;
      float scale = Math.min(1.0F, maxWidth / Math.max(1.0F, RenderUtil.interTextWidth(text, baseSize)));
      float size = baseSize * scale;
      int w = (int)Math.ceil(RenderUtil.interTextWidth(text, size));
      RenderUtil.drawPoppinsShadow(context, text, cx - w / 2.0F, y, color, size);
      return w;
   }

   /** Vanilla-font text centred on cx, scaled down to fit maxWidth, with the
    * same pure-black shadow; also scales with the menu's uiScale. */
   private void drawFitText(DrawContext context, String text, int cx, int y, int color, int maxWidth) {
      if (text == null || text.isEmpty() || maxWidth <= 1) {
         return;
      }
      int w = RenderUtil.textWidth(text);
      if (w <= 0) {
         return;
      }
      float f = Math.min(1.0F, (float)maxWidth / w) * this.uiScale;
      context.getMatrices().pushMatrix();
      context.getMatrices().translate(cx - w * f / 2.0F, y);
      context.getMatrices().scale(f, f);
      RenderUtil.drawText(context, text, 0, 0, color);
      context.getMatrices().popMatrix();
   }

   private void drawPlayerCard(DrawContext context, int width, int mouseX, int mouseY) {
      int cardW = s(150);
      int cardH = s(30);
      int x = width - cardW - s(10);
      int y = s(8);
      boolean hovered = mouseX >= x && mouseX < x + cardW && mouseY >= y && mouseY < y + cardH;
      float progress = hoverProgress("menu:player", hovered);
      GlassPanel.panelNoShadow(context, x, y, cardW, cardH, 7.0F, true, lerpColor(BlueColors.PANEL_BORDER, -14531329, progress));
      int headX = x + s(6);
      int headY = y + s(4);
      int headSize = cardH - s(8);
      boolean drewHead = false;
      if (this.skin != null) {
         try {
            Identifier skinTexture = this.skin.body().texturePath();
            // 1.21.11 quads take (x1,y1,x2,y2, u1,u2,v1,v2); the 8x8 face sits
            // at u 8/64..16/64, the hat overlay at u 40/64..48/64.
            context.drawTexturedQuad(skinTexture, headX, headY, headX + headSize, headY + headSize,
               0.125F, 0.25F, 0.125F, 0.25F);
            context.drawTexturedQuad(skinTexture, headX, headY, headX + headSize, headY + headSize,
               0.625F, 0.75F, 0.125F, 0.25F);
            drewHead = true;
         } catch (Throwable var19) {
         }
      }

      if (!drewHead) {
         Identifier apiHead = net.bluenetwork.client.util.HeadFetch.head(name());
         if (apiHead != null) {
            context.drawTexturedQuad(apiHead, headX, headY, headX + headSize, headY + headSize,
               0.125F, 0.25F, 0.125F, 0.25F);
            drewHead = true;
         } else {
            RenderUtil.drawRoundedRect(context, headX, headY, headSize, headSize, -2144379905, 3);
            RenderUtil.drawIcon(context, "user-round", headX + 3, headY + 3, headSize - 6, BlueColors.TEXT_PRIMARY);
         }
      }

      String name = MinecraftClient.getInstance().getGameProfile().name();
      String type = BlueClient.getInstance().accountManager().getAccounts().isEmpty() ? "add an account" : "click to switch";
      int textX = headX + headSize + s(6);
      int textW = x + cardW - s(6) - textX;
      drawFitInter(context, name, textX + textW / 2, y + s(6), BlueColors.TEXT_PRIMARY, 9.0F, textW);
      drawFitText(context, type, textX + textW / 2, y + s(19), BlueColors.TEXT_MUTED, textW);
      this.buttons.add(new MainMenuScreen.Button(x, y, cardW, cardH, () -> {
         RenderUtil.clickSound();
         this.client.setScreen(new AccountsScreen(this));
      }));
      int chipW = s(56);
      int chipH = s(13);
      int vy = y + cardH + s(6);
      GlassPanel.panelNoShadow(context, x, vy, chipW, chipH, 5.0F, true, BlueColors.PANEL_BORDER);
      drawFitInter(context, "VANILLA", x + chipW / 2, vy + s(2), BlueColors.TEXT_MUTED, 8.0F, chipW - s(8));
      this.buttons.add(new MainMenuScreen.Button(x, vy, chipW, chipH, () -> {
         RenderUtil.clickSound();
         BlueClient.getInstance().settings().customMainMenu(false);
         this.client.setScreen(new TitleScreen());
      }));
   }

   private static String name() {
      try {
         return MinecraftClient.getInstance().getGameProfile().name();
      } catch (Throwable t) {
         return "Player";
      }
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int)click.x();
      int my = (int)click.y();
      if (click.button() == 0) {
         for (MainMenuScreen.Button button : this.buttons) {
            if (mx >= button.x && mx < button.x + button.w && my >= button.y && my < button.y + button.h) {
               RenderUtil.clickSound();
               button.action.run();
               return true;
            }
         }
      }

      return super.mouseClicked(click, doubled);
   }

   public boolean keyPressed(KeyInput input) {
      return input.key() == 256 ? true : super.keyPressed(input);
   }

   private record Button(int x, int y, int w, int h, Runnable action) {
   }

   private static final class Particle {
      double x;
      double y;
      double vx;
      double vy;
      float size;
      int alpha;
      double swayPhase;
      double swaySpeed;
   }
}
