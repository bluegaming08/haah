package net.bluenetwork.client.account;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import net.bluenetwork.client.BlueClient;

public class MsAuth {
   private static final String CLIENT_ID = "c36a9fb6-4f15-4b4f-8817-4a4f7f0a4f8c";
   private static final String DEVICE_CODE_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
   private static final String TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
   private static final String XBL_URL = "https://user.auth.xboxlive.com/user/authenticate";
   private static final String XSTS_URL = "https://xsts.auth.xboxlive.com/xsts/authorize";
   private static final String MC_LOGIN_URL = "https://api.minecraftservices.com/authentication/login_with_xbox";
   private static final String MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile";

   public static MsAuth.State start() {
      String clientId = BlueClient.getInstance().settings().msClientId();
      if (clientId == null || clientId.isBlank() || clientId.equals("00000000-0000-0000-0000-000000000000")) {
         clientId = "c36a9fb6-4f15-4b4f-8817-4a4f7f0a4f8c";
      }

      MsAuth.State state = new MsAuth.State();
      String id = clientId;
      Thread thread = new Thread(() -> {
         try {
            run(state, id);
         } catch (Throwable var3x) {
            state.error = var3x.getMessage() == null ? var3x.toString() : var3x.getMessage();
            state.done = true;
         }
      }, "Blue Client MS Login");
      thread.setDaemon(true);
      thread.start();
      return state;
   }

   private static void run(MsAuth.State state, String clientId) throws Exception {
      HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).followRedirects(Redirect.NORMAL).build();
      JsonObject code = JsonParser.parseString(
            postForm(
               http,
               "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode",
               "client_id=" + clientId + "&scope=" + enc("XboxLive.signin offline_access")
            )
         )
         .getAsJsonObject();
      state.userCode = code.get("user_code").getAsString();
      state.verificationUri = code.has("verification_uri") ? code.get("verification_uri").getAsString() : "https://www.microsoft.com/link";
      long interval = code.has("interval") ? code.get("interval").getAsLong() : 5L;
      long deadline = System.currentTimeMillis() + 900000L;
      String msAccess = null;
      String msRefresh = null;

      while (System.currentTimeMillis() < deadline) {
         Thread.sleep(interval * 1000L);
         String response = postForm(
            http,
            "https://login.microsoftonline.com/consumers/oauth2/v2.0/token",
            "client_id="
               + clientId
               + "&grant_type="
               + enc("urn:ietf:params:oauth:grant-type:device_code")
               + "&device_code="
               + enc(code.get("device_code").getAsString())
         );
         JsonObject token = JsonParser.parseString(response).getAsJsonObject();
         if (token.has("access_token")) {
            msAccess = token.get("access_token").getAsString();
            msRefresh = token.has("refresh_token") ? token.get("refresh_token").getAsString() : "";
            break;
         }

         String error = token.has("error") ? token.get("error").getAsString() : "";
         if (!"authorization_pending".equals(error) && !"slow_down".equals(error)) {
            if ("authorization_declined".equals(error)) {
               throw new IllegalStateException("Login was cancelled");
            }

            if ("expired_token".equals(error)) {
               throw new IllegalStateException("The code expired - try again");
            }

            throw new IllegalStateException("Microsoft login failed: " + error);
         }
      }

      if (msAccess == null) {
         throw new IllegalStateException("The code expired - try again");
      } else {
         JsonObject xblBody = new JsonObject();
         JsonObject props = new JsonObject();
         props.addProperty("AuthMethod", "RPS");
         props.addProperty("SiteName", "user.auth.xboxlive.com");
         props.addProperty("RpsTicket", "d=" + msAccess);
         xblBody.add("Properties", props);
         JsonObject xbl = JsonParser.parseString(postJson(http, "https://user.auth.xboxlive.com/user/authenticate", xblBody.toString())).getAsJsonObject();
         String xblToken = xbl.get("Token").getAsString();
         JsonObject xstsBody = new JsonObject();
         JsonObject xstsProps = new JsonObject();
         xstsProps.addProperty("SandboxId", "RETAIL");
         JsonArray tokens = new JsonArray();
         tokens.add(xblToken);
         xstsProps.add("UserTokens", tokens);
         xstsBody.add("Properties", xstsProps);
         String xstsResponse = postJson(http, "https://xsts.auth.xboxlive.com/xsts/authorize", xstsBody.toString());
         JsonObject xsts = JsonParser.parseString(xstsResponse).getAsJsonObject();
         if (!xsts.has("Token")) {
            long xerr = xsts.has("XErr") ? xsts.get("XErr").getAsLong() : 0L;
            if (xerr == 2148916233L) {
               throw new IllegalStateException("This Microsoft account has no Xbox profile");
            } else if (xerr == 2148916238L) {
               throw new IllegalStateException("Child accounts need adult sign-in");
            } else {
               throw new IllegalStateException("Xbox authorization failed (XErr " + xerr + ")");
            }
         } else {
            String xstsToken = xsts.get("Token").getAsString();
            String uhs = xsts.getAsJsonArray("DisplayClaims").get(0).getAsJsonObject().get("uhs").getAsString();
            JsonObject mcBody = new JsonObject();
            mcBody.addProperty("identityToken", "XBL3.0 x=" + uhs + ";" + xstsToken);
            JsonObject mc = JsonParser.parseString(postJson(http, "https://api.minecraftservices.com/authentication/login_with_xbox", mcBody.toString()))
               .getAsJsonObject();
            String mcAccess = mc.get("access_token").getAsString();
            HttpRequest profileRequest = HttpRequest.newBuilder(URI.create("https://api.minecraftservices.com/minecraft/profile"))
               .header("Authorization", "Bearer " + mcAccess)
               .timeout(Duration.ofSeconds(10L))
               .GET()
               .build();
            HttpResponse<String> profileResponse = http.send(profileRequest, BodyHandlers.ofString());
            if (profileResponse.statusCode() == 404) {
               throw new IllegalStateException("This account does not own Minecraft");
            } else {
               JsonObject profile = JsonParser.parseString(profileResponse.body()).getAsJsonObject();
               String compactUuid = profile.get("id").getAsString();
               String name = profile.get("name").getAsString();
               String dashed = compactUuid.length() == 32
                  ? compactUuid.substring(0, 8)
                     + "-"
                     + compactUuid.substring(8, 12)
                     + "-"
                     + compactUuid.substring(12, 16)
                     + "-"
                     + compactUuid.substring(16, 20)
                     + "-"
                     + compactUuid.substring(20, 32)
                  : compactUuid;
               state.account = new Account("msa", name, dashed, mcAccess, msRefresh, uhs);
               state.success = true;
               state.done = true;
               BlueClient.LOGGER.info("Microsoft account '{}' logged in", name);
            }
         }
      }
   }

   private static String postForm(HttpClient http, String url, String body) throws Exception {
      HttpRequest request = HttpRequest.newBuilder(URI.create(url))
         .header("Content-Type", "application/x-www-form-urlencoded")
         .timeout(Duration.ofSeconds(15L))
         .POST(BodyPublishers.ofString(body, StandardCharsets.UTF_8))
         .build();
      return http.send(request, BodyHandlers.ofString()).body();
   }

   private static String postJson(HttpClient http, String url, String body) throws Exception {
      HttpRequest request = HttpRequest.newBuilder(URI.create(url))
         .header("Content-Type", "application/json")
         .header("Accept", "application/json")
         .timeout(Duration.ofSeconds(15L))
         .POST(BodyPublishers.ofString(body, StandardCharsets.UTF_8))
         .build();
      return http.send(request, BodyHandlers.ofString()).body();
   }

   private static String enc(String value) {
      return URLEncoder.encode(value, StandardCharsets.UTF_8);
   }

   public static class State {
      public volatile String userCode = "";
      public volatile String verificationUri = "";
      public volatile boolean done = false;
      public volatile boolean success = false;
      public volatile String error = "";
      public volatile Account account = null;
   }
}
