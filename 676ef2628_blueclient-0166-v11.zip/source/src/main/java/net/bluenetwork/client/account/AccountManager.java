package net.bluenetwork.client.account;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.mixin.MinecraftClientSessionAccessor;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import net.minecraft.text.Text;

public class AccountManager {
   private final List<Account> accounts = new ArrayList<>();
   private String activeUsername = "";
   private String activeUuid = "";

   public void load() {
      try {
         Path file = path();
         this.accounts.clear();
         if (!Files.exists(file)) {
            this.captureCurrentSession();
            return;
         }

         for (JsonElement element : JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonArray()) {
            JsonObject obj = element.getAsJsonObject();
            this.accounts
               .add(
                  new Account(
                     obj.get("type").getAsString(),
                     obj.get("username").getAsString(),
                     obj.get("uuid").getAsString(),
                     obj.has("accessToken") ? obj.get("accessToken").getAsString() : "0",
                     obj.has("refreshToken") ? obj.get("refreshToken").getAsString() : "",
                     obj.has("xuid") ? obj.get("xuid").getAsString() : ""
                  )
               );
         }
      } catch (Throwable var6) {
         BlueClient.LOGGER.debug("Could not load accounts", var6);
      }

      this.captureCurrentSession();
   }

   private void captureCurrentSession() {
      try {
         Session session = MinecraftClient.getInstance().getSession();
         this.activeUsername = session.getUsername();
         this.activeUuid = String.valueOf(session.getUuidOrNull());
      } catch (Throwable var2) {
      }
   }

   public void save() {
      try {
         JsonArray array = new JsonArray();

         for (Account account : this.accounts) {
            JsonObject obj = new JsonObject();
            obj.addProperty("type", account.type());
            obj.addProperty("username", account.username());
            obj.addProperty("uuid", account.uuid());
            obj.addProperty("accessToken", account.accessToken());
            obj.addProperty("refreshToken", account.refreshToken());
            obj.addProperty("xuid", account.xuid());
            array.add(obj);
         }

         Files.createDirectories(path().getParent());
         Files.writeString(path(), array.toString(), StandardCharsets.UTF_8);
      } catch (Throwable var5) {
         BlueClient.LOGGER.debug("Could not save accounts", var5);
      }
   }

   public List<Account> getAccounts() {
      return this.accounts;
   }

   public static String offlineUuid(String name) {
      return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8)).toString();
   }

   public String addCracked(String name) {
      String trimmed = name.trim();
      if (trimmed.length() >= 3 && trimmed.length() <= 16 && trimmed.chars().allMatch(c -> Character.isLetterOrDigit(c) || c == 95)) {
         Account account = new Account("cracked", trimmed, offlineUuid(trimmed), "0", "", "");
         this.accounts.removeIf(a -> a.uuid().equals(account.uuid()));
         this.accounts.add(account);
         this.save();
         return null;
      } else {
         return "Name must be 3-16 letters, numbers or _";
      }
   }

   public void addMicrosoft(Account account) {
      this.accounts.removeIf(a -> a.uuid().equals(account.uuid()));
      this.accounts.add(account);
      this.save();
   }

   public void remove(Account account) {
      this.accounts.remove(account);
      this.save();
   }

   public boolean isActive(Account account) {
      return account.uuid().equals(this.activeUuid) || account.username().equalsIgnoreCase(this.activeUsername);
   }

   public void use(Account account) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null || mc.player != null) {
         mc.disconnect(Text.literal("Switching accounts..."));
      }

      UUID uuid;
      try {
         uuid = UUID.fromString(account.uuid());
      } catch (IllegalArgumentException var5) {
         uuid = UUID.fromString(offlineUuid(account.username()));
      }

      Session session = new Session(
         account.username(), uuid, account.accessToken(), account.isMicrosoft() ? Optional.of(account.xuid()) : Optional.empty(), Optional.empty()
      );
      ((MinecraftClientSessionAccessor)mc).blueclient$setSession(session);
      this.activeUsername = account.username();
      this.activeUuid = account.uuid();
      this.save();
      BlueClient.LOGGER.info("Switched to account '{}' ({})", account.username(), account.type());
   }

   public String currentUsername() {
      try {
         return MinecraftClient.getInstance().getSession().getUsername();
      } catch (Throwable var2) {
         return this.activeUsername;
      }
   }

   private static Path path() {
      return FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("accounts.json");
   }
}
