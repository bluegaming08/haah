package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;

/**
 * Auto Respawn (v3 catalogue F5) — automatically clicks respawn after a short
 * delay on the death screen. Ships disabled by default. Fully client-side; only
 * triggers vanilla respawn logic, nothing else.
 */
public class AutoRespawn extends Module {
   private final NumberSetting delay = new NumberSetting("Delay", "Seconds to wait on the death screen", 3.0, 0.5, 15.0, 0.5);
   private final BooleanSetting sound = new BooleanSetting("Sound", "Play a pickup chime when you respawn", true);

   private int deathTicks = 0;
   private boolean sent = false;

   public AutoRespawn() {
      super("Auto Respawn", "Respawn automatically (default-off)", Category.MISC);
      this.addSettings(new Setting[]{this.delay, this.sound});
   }

   @Override
   protected void onDisable() {
      this.deathTicks = 0;
      this.sent = false;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.currentScreen instanceof DeathScreen) {
         if (!this.sent) {
            this.deathTicks++;
            int ticks = Math.max(1, (int) Math.round(this.delay.get() * 20.0));
            if (this.deathTicks >= ticks && mc.player != null) {
               this.sent = true;
               if (this.sound.get()) {
                  Sounds.pickup();
               }
               mc.player.requestRespawn();
            }
         }
      } else {
         this.deathTicks = 0;
         this.sent = false;
      }
   }
}
