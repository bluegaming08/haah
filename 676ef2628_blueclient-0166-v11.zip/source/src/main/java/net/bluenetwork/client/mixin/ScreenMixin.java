package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.gui.ClientSettingsScreen;
import net.bluenetwork.client.gui.MainMenuScreen;
import net.bluenetwork.client.gui.PauseMenuScreen;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Screen.class})
public abstract class ScreenMixin {
   @Shadow
   public TextRenderer textRenderer;

   /**
    * Vanilla pause menu: skin the two Blue squares (opaque dark glass with a
    * logo / gear) on top of the vanilla background.
    */
   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void blueclient$pauseSquares(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (net.bluenetwork.client.gui.PauseSquares.squaresVisible()) {
         int size = net.bluenetwork.client.gui.PauseSquares.squareSize();
         int[] b = net.bluenetwork.client.gui.PauseSquares.squareBounds();
         int sx = b[0];
         int sy = b[1];
         int gx = b[2];
         int gy = b[3];
         drawSquare(context, sx, sy, size);
         RenderUtil.drawLogoTinted(context, sx + size / 2 - 5, sy + 5, 10, -1);
         drawSquare(context, gx, gy, size);
         RenderUtil.drawIcon(context, "settings", gx + 4, gy + 4, size - 8, 0xFFFFFFFF);
      }
   }

   private static net.minecraft.client.MinecraftClient blueclient$client() {
      return net.minecraft.client.MinecraftClient.getInstance();
   }

   private void drawSquare(DrawContext context, int x, int y, int size) {
      // opaque dark glass + subtle border so the square reads on any pause bg
      context.fill(x, y, x + size, y + size, 0xE80B0E14);
      net.bluenetwork.client.render.SmoothRect.outline(context, x, y, size, size, 0.0F, 1.0F, 0x663D6BFF);
   }

   /** Vanilla pause menu: clicks on the two squares. */
   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$pauseSquareClick(net.minecraft.client.gui.Click click, boolean doubled, CallbackInfo ci) {
      Screen self = (Screen)(Object)this;
      if (!net.bluenetwork.client.gui.PauseSquares.squaresVisible()) {
         return;
      }
      int mx = (int) click.x();
      int my = (int) click.y();
      int size = net.bluenetwork.client.gui.PauseSquares.squareSize();
      int[] b = net.bluenetwork.client.gui.PauseSquares.squareBounds();
      int sx = b[0];
      int sy = b[1];
      int gx = b[2];
      int gy = b[3];
      if (mx >= sx && mx < sx + size && my >= sy && my < sy + size) {
         net.bluenetwork.client.BlueClient.getInstance().settings().customPauseMenu(true);
         RenderUtil.clickSound();
         this.blueclient$client().setScreen(new net.bluenetwork.client.gui.PauseMenuScreen());
         ci.cancel();
      } else if (mx >= gx && mx < gx + size && my >= gy && my < gy + size) {
         RenderUtil.clickSound();
         this.blueclient$client().setScreen(new net.bluenetwork.client.gui.ClientSettingsScreen(self));
         ci.cancel();
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void blueclient$screenWatermark(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      Screen self = (Screen)(Object)this;
      // toasts (music feedback, config saves...) also show on menu screens;
      // in-game the HudManager draws them instead.
      if (blueclient$client().player == null) {
         BlueClient.getInstance().notificationManager().render(context);
      }
      // v0.16.4: the watermark is mandatory - there is intentionally no setting,
      // module or config key that can switch it off.
      if (!(self instanceof MainMenuScreen)
         && !(self instanceof PauseMenuScreen)
         && !(self instanceof ClientSettingsScreen)) {
         int height = context.getScaledWindowHeight();
         RenderUtil.drawLogoTinted(context, 6, height - 28, 22, 0x4DFFFFFF);
      }
   }
}
