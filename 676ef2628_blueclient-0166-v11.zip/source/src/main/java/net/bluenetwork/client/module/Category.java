package net.bluenetwork.client.module;

public enum Category {
   HUD("HUD"),
   COMBAT("Combat"),
   MOVEMENT("Movement"),
   RENDER("Render"),
   MISC("Misc");

   private final String displayName;

   private Category(String displayName) {
      this.displayName = displayName;
   }

   public String displayName() {
      return this.displayName;
   }
}
