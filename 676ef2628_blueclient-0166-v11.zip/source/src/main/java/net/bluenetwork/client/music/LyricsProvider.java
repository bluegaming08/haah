package net.bluenetwork.client.music;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Timed lyrics for the Music Player HUD, fetched from the public LRCLIB
 * API (no key required). Synced lyrics are preferred; when a track only has
 * plain lyrics they are shown as evenly spaced blocks so the lyric effects
 * still animate.
 */
public final class LyricsProvider {
   /** One lyric line and the playback position (ms) it belongs to. */
   public record Line(long ms, String text) {
   }

   public record Lyrics(List<Line> lines, boolean synced) {
      public Line at(long positionMs) {
         Line current = null;
         for (Line line : this.lines) {
            if (line.ms() <= positionMs) {
               current = line;
            } else {
               break;
            }
         }
         return current;
      }

      public Line after(Line line) {
         for (int i = 0; i < this.lines.size(); i++) {
            if (this.lines.get(i) == line && i + 1 < this.lines.size()) {
               return this.lines.get(i + 1);
            }
         }
         return null;
      }
   }

   private static final long PLAIN_LINE_MS = 6000L;

   private LyricsProvider() {
   }

   /** Returns lyrics for the track, or null when none exist. */
   public static Lyrics fetch(String title, String artist, int durationSec) {
      String query = (title + " " + (artist == null ? "" : artist)).trim();
      if (query.isEmpty()) {
         return null;
      }
      try {
         String body = TrackResolver.httpGetWithAgent("https://lrclib.net/api/search?q="
            + java.net.URLEncoder.encode(query, java.nio.charset.StandardCharsets.UTF_8),
               TrackResolver.LYRICS_USER_AGENT);
         JsonArray results = JsonParser.parseString(body).getAsJsonArray();
         JsonObject best = null;
         int bestDiff = Integer.MAX_VALUE;
         for (JsonElement element : results) {
            if (!element.isJsonObject()) {
               continue;
            }
            JsonObject candidate = element.getAsJsonObject();
            int candidateDuration = candidate.has("duration") && candidate.get("duration").isJsonPrimitive()
               && candidate.getAsJsonPrimitive("duration").isNumber() ? candidate.getAsJsonPrimitive("duration").getAsInt() : -1;
            int diff = durationSec > 0 && candidateDuration >= 0 ? Math.abs(candidateDuration - durationSec) : 999;
            boolean hasSynced = candidate.has("syncedLyrics") && !candidate.get("syncedLyrics").isJsonNull()
               && !candidate.get("syncedLyrics").getAsString().isBlank();
            if (hasSynced) {
               diff -= 1000; // strongly prefer synced entries
            }
            if (diff < bestDiff) {
               bestDiff = diff;
               best = candidate;
            }
         }
         if (best == null) {
            return null;
         }
         String synced = best.has("syncedLyrics") && !best.get("syncedLyrics").isJsonNull()
            ? best.get("syncedLyrics").getAsString() : "";
         if (!synced.isBlank()) {
            Lyrics parsed = parseSynced(synced);
            if (parsed != null && !parsed.lines().isEmpty()) {
               return parsed;
            }
         }
         String plain = best.has("plainLyrics") && !best.get("plainLyrics").isJsonNull()
            ? best.get("plainLyrics").getAsString() : "";
         if (!plain.isBlank()) {
            return parsePlain(plain);
         }
         return null;
      } catch (Throwable t) {
         if (Boolean.getBoolean("blueclient.lyricsDebug")) {
            t.printStackTrace();
         }
         return null;
      }
   }

   private static Lyrics parseSynced(String raw) {
      List<Line> lines = new ArrayList<>();
      for (String row : raw.split("\n")) {
         String line = row.trim();
         if (line.isEmpty() || !line.startsWith("[")) {
            continue;
         }
         int close = line.indexOf(']');
         if (close < 0) {
            continue;
         }
         long ms = parseTimestamp(line.substring(1, close));
         String text = line.substring(close + 1).trim();
         // Skip metadata tags like [ar: ...] / [ti: ...]
         if (text.isEmpty() || text.startsWith("[")) {
            if (text.isEmpty()) {
               continue;
            }
         }
         if (ms >= 0) {
            lines.add(new Line(ms, text.isEmpty() ? "…" : text));
         }
      }
      lines.sort((a, b) -> Long.compare(a.ms(), b.ms()));
      return lines.isEmpty() ? null : new Lyrics(lines, true);
   }

   private static Lyrics parsePlain(String raw) {
      List<Line> lines = new ArrayList<>();
      long ms = 0;
      for (String row : raw.split("\n")) {
         String text = row.trim();
         if (text.isEmpty()) {
            continue;
         }
         lines.add(new Line(ms, text));
         ms += PLAIN_LINE_MS;
      }
      return lines.isEmpty() ? null : new Lyrics(lines, false);
   }

   /** Parses mm:ss.xx (or hh:mm:ss.xx) into milliseconds; -1 when invalid. */
   private static long parseTimestamp(String stamp) {
      try {
         String[] parts = stamp.split(":");
         double seconds;
         long total = 0;
         if (parts.length == 2) {
            total = Long.parseLong(parts[0].trim()) * 60_000L;
            seconds = Double.parseDouble(parts[1].trim());
         } else if (parts.length == 3) {
            total = Long.parseLong(parts[0].trim()) * 3_600_000L + Long.parseLong(parts[1].trim()) * 60_000L;
            seconds = Double.parseDouble(parts[2].trim());
         } else {
            return -1;
         }
         return total + (long) (seconds * 1000.0D);
      } catch (Throwable t) {
         return -1;
      }
   }

   /** m:ss formatter shared by the HUD. */
   public static String clock(long ms) {
      long totalSeconds = Math.max(0, ms / 1000);
      long minutes = totalSeconds / 60;
      long seconds = totalSeconds % 60;
      return String.format(Locale.ROOT, "%d:%02d", minutes, seconds);
   }
}
