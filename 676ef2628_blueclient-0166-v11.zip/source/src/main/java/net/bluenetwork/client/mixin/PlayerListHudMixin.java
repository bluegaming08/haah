package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.brand.BlueBrand;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListHud.class})
public abstract class PlayerListHudMixin {
   @Inject(
      method = {"getPlayerName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void blueclient$tabIcon(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
      Text name = (Text)cir.getReturnValue();
      if (name != null && entry != null) {
         if (net.bluenetwork.client.module.impl.BlueLogo.showIcons()
            && BlueClient.getInstance().presence().isBlueClientUser(entry.getProfile().id())) {
            cir.setReturnValue(BlueBrand.withIcon(name));
         }
      }
   }
}
