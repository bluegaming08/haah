package net.bluenetwork.client.keybind;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.event.KeyEvent;
import net.bluenetwork.client.gui.QuickMenuScreen;
import net.bluenetwork.client.module.HoldModule;
import net.bluenetwork.client.module.SelfKeyedModule;
import net.bluenetwork.client.module.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Event-driven keybind handling. Key events arrive directly from the
 * GLFW callback (via KeyboardMixin), so even the fastest tap is caught -
 * no 20Hz polling that can miss short presses.
 */
public class KeybindManager {
   private final BlueClient client;

   public KeybindManager(BlueClient client) {
      this.client = client;
   }

   public void init() {
      this.client.eventBus().subscribe(KeyEvent.class, this::onKey);
   }

   private void onKey(KeyEvent event) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null || mc.currentScreen != null) {
         return;
      }

      if (event.action() == 1) {
         int guiKey = this.client.settings().guiKeybind();
         if (guiKey > 0 && event.key() == guiKey) {
            mc.setScreen(new QuickMenuScreen());
            return;
         }

         for (Module module : this.client.moduleManager().getModules()) {
            if (module.getKeybind() == event.key() && !(module instanceof SelfKeyedModule)) {
               if (module instanceof HoldModule) {
                  module.setEnabled(true);
               } else {
                  module.toggle();
                  BlueClient.LOGGER.info("Module '{}' toggled via hotkey -> {}", module.getName(), module.isEnabled());
               }
            }
         }
      } else if (event.action() == 0) {
         for (Module module : this.client.moduleManager().getModules()) {
            if (module instanceof HoldModule && !(module instanceof SelfKeyedModule)
               && module.getKeybind() == event.key()) {
               module.setEnabled(false);
            }
         }
      }
   }
}
