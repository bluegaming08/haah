package net.bluenetwork.client.music;

import it.unimi.dsi.fastutil.floats.FloatArrayList;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.function.Consumer;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import net.minecraft.client.sound.OggAudioStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Music Engine v2 (see BLUE_CLIENT_V3_MASTER_PLAN.md §8).
 *
 * <p>Fixes over v0.15:
 * <ul>
 *   <li><b>Ownership.</b> {@code play(...)} owns the passed stream entirely — callers must
 *       NOT close it (v0.15 closed it right after {@code play} returned, killing the decode
 *       thread). The engine closes the stream in its own finally.</li>
 *   <li><b>Windowed OGG drain.</b> Samples arriving from
 *       {@link OggAudioStream#read(FloatConsumer)} are drained in fixed windows into the PCM
 *       buffer, so playback is correct whether a read returns one chunk or a whole stream, and
 *       the blocking {@link SourceDataLine#write} paces playback in real time.</li>
 *   <li><b>Error sink.</b> Callers can pass a {@code Consumer<String>} to surface the real
 *       failure reason (decode / device / format) instead of silence.</li>
 * </ul>
 *
 * <p>All decoding runs on a daemon thread; the render thread never touches audio. The only
 * mutable field the render thread reads is {@link #nowPlaying()} / {@link #isPlaying()}, both
 * volatile.
 */
public class MusicEngine {
   public static final MusicEngine INSTANCE = new MusicEngine();
   private static final Logger LOGGER = LoggerFactory.getLogger("Blue Client Music");
   private static final int LINE_BUFFER = 131072;
   /** Floats drained per write window — ~0.05 s of audio, comfortably under the line buffer. */
   private static final int SAMPLE_WINDOW = 4096;

   private volatile Thread thread;
   private volatile boolean stopped = true;
   private volatile SourceDataLine line;
   private volatile String nowPlaying = "";
   private volatile float volume = 1.0F;
   private volatile long positionMs = 0L;
   private volatile long durationMs = 0L;

   private MusicEngine() {
   }

   public String nowPlaying() {
      return this.nowPlaying;
   }

   public boolean isPlaying() {
      return this.thread != null && this.thread.isAlive() && !this.stopped;
   }

   public void setVolume(float volume) {
      float clamped = Math.max(0.0F, Math.min(1.0F, volume));
      this.volume = clamped;
      SourceDataLine current = this.line;
      if (current != null) {
         try {
            FloatControl control = (FloatControl) current.getControl(FloatControl.Type.MASTER_GAIN);
            float gain = (float) (Math.log(Math.max(1.0E-4, clamped)) / Math.log(10.0) * 20.0);
            control.setValue(Math.max(control.getMinimum(), Math.min(control.getMaximum(), gain)));
         } catch (IllegalArgumentException ignored) {
            // MASTER_GAIN not supported on this line — acceptable, play at device volume.
         } catch (Throwable t) {
            LOGGER.debug("Could not set volume", t);
         }
      }
   }

   public float volume() {
      return this.volume;
   }

   /** Playback position of the current track in milliseconds. */
   public long positionMs() {
      SourceDataLine current = this.line;
      if (current != null) {
         try {
            return Math.max(0L, current.getMicrosecondPosition() / 1000L);
         } catch (Throwable ignored) {
         }
      }
      return this.positionMs;
   }

   /** Track length in milliseconds (0 when unknown, e.g. live streams). */
   public long durationMs() {
      return this.durationMs;
   }

   /** Hint from the resolver / metadata so the HUD can show total time. */
   public void setDurationMs(long ms) {
      this.durationMs = Math.max(0L, ms);
   }

   /** Legacy signature (silent errors). See {@link #play(InputStream, String, float, String, Consumer)}. */
   public synchronized void play(InputStream input, String format, float volume, String name) {
      play(input, format, volume, name, null);
   }

   /**
    * Plays a stream the caller no longer touches. {@code onError} (nullable) receives a
    * human-readable reason if the stream can't be played.
    */
   public synchronized void play(InputStream input, String format, float volume, String name, Consumer<String> onError) {
      this.stop();
      this.stopped = false;
      this.positionMs = 0L;
      this.nowPlaying = name == null ? "" : name;
      this.volume = Math.max(0.0F, Math.min(1.0F, volume));
      Consumer<String> sink = onError;

      Thread worker = new Thread(() -> {
         try {
            BufferedInputStream buffered = new BufferedInputStream(input, 8192);
            if ("ogg".equalsIgnoreCase(format)) {
               this.playOgg(buffered, sink);
            } else if ("mp3".equalsIgnoreCase(format)) {
               this.playMp3(buffered, sink);
            } else if ("m4a".equalsIgnoreCase(format) || "aac".equalsIgnoreCase(format)) {
               this.playM4a(buffered, sink);
            } else if ("wav".equalsIgnoreCase(format)) {
               this.playWav(buffered, sink);
            } else {
               report(sink, "Unknown format '" + format + "' - expected mp3 or ogg.");
            }
         } catch (Throwable t) {
            report(sink, t.getMessage() == null ? t.toString() : t.getMessage());
         } finally {
            try {
               input.close();
            } catch (Throwable ignored) {
            }
            this.closeLine();
            this.stopped = true;
            this.nowPlaying = "";
         }
      }, "Blue Client Music");
      this.thread = worker;
      worker.setDaemon(true);
      worker.start();
   }

   public synchronized void stop() {
      this.stopped = true;
      Thread old = this.thread;
      this.thread = null;
      this.nowPlaying = "";
      this.positionMs = 0L;
      if (old != null) {
         old.interrupt();
      }
      this.closeLine();
   }

   /* ---------------- OGG ---------------- */

   private void playOgg(BufferedInputStream input, Consumer<String> sink) throws Exception {
      OggAudioStream ogg = new OggAudioStream(input);
      try {
         AudioFormat format = ogg.getFormat();
         boolean bigEndian = format.isBigEndian();
         SourceDataLine out = null;
         FloatArrayList floats = new FloatArrayList();
         byte[] window = new byte[SAMPLE_WINDOW * 4]; // roomiest case: 4096 floats interleaved → 8192 bytes

         while (!this.stopped) {
            boolean more;
            try {
               more = ogg.read(floats::add);
            } catch (Throwable t) {
               // A closed/interrupted stream surfaces here when stopping; that's expected.
               if (this.stopped) {
                  break;
               }
               throw t;
            }
            // NOTE: drain() clears the sample list, so "is the list empty" can
            // never be used as an end-of-stream signal here. Only the boolean
            // return of read() says whether more PCM follows.
            out = this.drain(floats, window, format, out, bigEndian, sink);
            if (!more) {
               break;
            }
         }
         // Tail samples (only reachable when the read loop ended on !more with leftover data)
         out = this.drain(floats, window, format, out, bigEndian, sink);
         if (out != null && !this.stopped) {
            out.drain();
         }
      } finally {
         try {
            ogg.close();
         } catch (Throwable ignored) {
         }
      }
   }

   /** Drains the whole sample list in fixed windows through the line. */
   private SourceDataLine drain(FloatArrayList floats, byte[] window, AudioFormat format,
                                SourceDataLine current, boolean bigEndian, Consumer<String> sink) throws Exception {
      int n = floats.size();
      int idx = 0;
      SourceDataLine out = current;
      while (idx < n && !this.stopped) {
         int take = Math.min(SAMPLE_WINDOW, n - idx);
         int pcmLen = floatsToPcm(floats, idx, take, window, bigEndian);
         if (out == null) {
            out = this.openLine(format, sink);
            if (out == null) {
               return null; // error already reported
            }
         }
         out.write(window, 0, pcmLen);
         this.positionMs = out.getMicrosecondPosition() / 1000L;
         idx += take;
      }
      floats.clear();
      return out;
   }

   private int floatsToPcm(FloatArrayList floats, int offset, int count, byte[] buffer, boolean bigEndian) {
      int pos = 0;
      for (int i = 0; i < count && pos + 1 < buffer.length; i++) {
         float value = floats.getFloat(offset + i);
         value = Math.max(-1.0F, Math.min(1.0F, value));
         short sample = (short) (value * 32767.0F);
         if (bigEndian) {
            buffer[pos++] = (byte) (sample >> 8 & 0xFF);
            buffer[pos++] = (byte) (sample & 0xFF);
         } else {
            buffer[pos++] = (byte) (sample & 0xFF);
            buffer[pos++] = (byte) (sample >> 8 & 0xFF);
         }
      }
      return pos;
   }

   /* ---------------- MP3 ---------------- */

   private void playMp3(BufferedInputStream input, Consumer<String> sink) throws Exception {
      Bitstream bitstream = new Bitstream(input);
      Decoder decoder = new Decoder();
      SourceDataLine out = null;
      byte[] transfer = new byte[8192];

      try {
         while (!this.stopped) {
            Header header = bitstream.readFrame();
            if (header == null) {
               break;
            }
            SampleBuffer samples = (SampleBuffer) decoder.decodeFrame(header, bitstream);
            if (out == null) {
               AudioFormat format = new AudioFormat(decoder.getOutputFrequency(), 16,
                  decoder.getOutputChannels(), true, false);
               out = this.openLine(format, sink);
               if (out == null) {
                  return;
               }
            }
            short[] pcm = samples.getBuffer();
            int count = samples.getBufferLength();
            int pos = 0;
            for (int i = 0; i < count && pos + 1 < transfer.length; i++) {
               short sample = pcm[i];
               transfer[pos++] = (byte) (sample & 0xFF);
               transfer[pos++] = (byte) (sample >> 8 & 0xFF);
            }
            out.write(transfer, 0, pos);
            this.positionMs = out.getMicrosecondPosition() / 1000L;
            bitstream.closeFrame();
         }
         if (out != null && !this.stopped) {
            out.drain();
         }
      } finally {
         try {
            bitstream.close();
         } catch (Throwable ignored) {
         }
      }
   }

   /* ---------------- M4A / AAC (JAAD, pure java) ---------------- */

   private void playM4a(BufferedInputStream input, Consumer<String> sink) throws Exception {
      this.playM4a(net.sourceforge.jaad.mp4.MP4InputStream.open(input), sink);
   }

   /**
    * Plays a local file (seekable) - used for downloaded YouTube streams so
    * the MP4 box reader can jump straight to the moov atom.
    */
   public synchronized void playFile(java.nio.file.Path file, String format, float volume, String name, Consumer<String> onError) {
      if ("m4a".equalsIgnoreCase(format) || "aac".equalsIgnoreCase(format)) {
         this.stop();
         this.stopped = false;
         this.positionMs = 0L;
         this.nowPlaying = name == null ? "" : name;
         this.volume = Math.max(0.0F, Math.min(1.0F, volume));
         Consumer<String> sink = onError;
         Thread worker = new Thread(() -> {
            try {
               this.playM4a(net.sourceforge.jaad.mp4.MP4InputStream.open(new java.io.RandomAccessFile(file.toFile(), "r")), sink);
            } catch (Throwable t) {
               report(sink, t.getMessage() == null ? t.toString() : t.getMessage());
            } finally {
               this.closeLine();
               this.stopped = true;
               this.nowPlaying = "";
            }
         }, "Blue Client Music");
         this.thread = worker;
         worker.setDaemon(true);
         worker.start();
         return;
      }
      try {
         this.play(java.nio.file.Files.newInputStream(file), format, volume, name, onError);
      } catch (Throwable t) {
         if (onError != null) {
            onError.accept(t.getMessage() == null ? t.toString() : t.getMessage());
         }
      }
   }

   private void playM4a(net.sourceforge.jaad.mp4.MP4InputStream stream, Consumer<String> sink) throws Exception {
      try {
         net.sourceforge.jaad.mp4.MP4Container container = new net.sourceforge.jaad.mp4.MP4Container(stream);
         java.util.List<net.sourceforge.jaad.mp4.api.Track> tracks =
            container.getMovie().getTracks(net.sourceforge.jaad.mp4.api.Type.AUDIO);
         if (tracks.isEmpty()) {
            report(sink, "That MP4/M4A file has no audio track.");
            return;
         }
         net.sourceforge.jaad.mp4.api.AudioTrack track = (net.sourceforge.jaad.mp4.api.AudioTrack) tracks.get(0);
         net.sourceforge.jaad.aac.Decoder decoder =
            net.sourceforge.jaad.aac.Decoder.create(track.getDecoderSpecificInfo().getData());
         net.sourceforge.jaad.SampleBuffer buffer = new net.sourceforge.jaad.SampleBuffer();
         AudioFormat format = decoder.getAudioFormat();
         SourceDataLine out = null;
         while (!this.stopped && track.hasMoreFrames()) {
            net.sourceforge.jaad.mp4.api.Frame frame = track.readNextFrame();
            decoder.decodeFrame(frame.getData(), buffer);
            byte[] pcm = buffer.getData();
            if (pcm == null || pcm.length == 0) {
               continue;
            }
            if (out == null) {
               out = this.openLine(format, sink);
               if (out == null) {
                  return;
               }
            }
            out.write(pcm, 0, pcm.length);
            this.positionMs = out.getMicrosecondPosition() / 1000L;
         }
         if (out != null && !this.stopped) {
            out.drain();
         }
      } catch (Throwable t) {
         if (!this.stopped) {
            report(sink, "AAC decode failed: " + brief(t));
         }
      } finally {
         try {
            stream.close();
         } catch (Throwable ignored) {
         }
      }
   }

   /* ---------------- WAV (javax.sound) ---------------- */

   private void playWav(BufferedInputStream input, Consumer<String> sink) throws Exception {
      javax.sound.sampled.AudioInputStream decoded;
      try {
         javax.sound.sampled.AudioInputStream raw = AudioSystem.getAudioInputStream(input);
         AudioFormat base = raw.getFormat();
         AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, base.getSampleRate(), 16,
            base.getChannels(), base.getChannels() * 2, base.getSampleRate(), false);
         decoded = AudioSystem.getAudioInputStream(target, raw);
      } catch (Throwable t) {
         report(sink, "Couldn't read that WAV file: " + brief(t));
         return;
      }
      SourceDataLine out = null;
      byte[] chunk = new byte[8192];
      try {
         while (!this.stopped) {
            int read = decoded.read(chunk, 0, chunk.length);
            if (read < 0) {
               break;
            }
            if (out == null) {
               out = this.openLine(decoded.getFormat(), sink);
               if (out == null) {
                  return;
               }
            }
            out.write(chunk, 0, read);
            this.positionMs = out.getMicrosecondPosition() / 1000L;
         }
         if (out != null && !this.stopped) {
            out.drain();
         }
      } finally {
         try {
            decoded.close();
         } catch (Throwable ignored) {
         }
      }
   }

   /* ---------------- shared ---------------- */

   private SourceDataLine openLine(AudioFormat format, Consumer<String> sink) {
      try {
         SourceDataLine newLine = AudioSystem.getSourceDataLine(format);
         newLine.open(format, LINE_BUFFER);
         newLine.start();
         this.line = newLine;
         this.setVolume(this.volume);
         return newLine;
      } catch (IllegalArgumentException e) {
         report(sink, "Your audio device doesn't support this format (" + format + ").");
         return null;
      } catch (Throwable t) {
         report(sink, "Couldn't open the audio device: " + brief(t));
         return null;
      }
   }

   private void closeLine() {
      SourceDataLine current = this.line;
      this.line = null;
      if (current != null) {
         try {
            current.stop();
         } catch (Throwable ignored) {
         }
         try {
            current.flush();
         } catch (Throwable ignored) {
         }
         try {
            current.close();
         } catch (Throwable ignored) {
         }
      }
   }

   private static void report(Consumer<String> sink, String message) {
      LOGGER.warn("Music error: {}", message);
      if (sink != null) {
         try {
            sink.accept(message);
         } catch (Throwable ignored) {
         }
      }
   }

   private static String brief(Throwable t) {
      String msg = t.getMessage();
      if (msg != null && !msg.isBlank()) {
         return msg;
      }
      return t.getClass().getSimpleName();
   }
}
