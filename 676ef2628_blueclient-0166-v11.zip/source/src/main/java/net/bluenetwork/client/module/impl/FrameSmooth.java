package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;

/**
 * Frame Smooth (v3 catalogue G5) — frame-pacing helpers: optionally disables
 * vsync while on (reduces input lag when you're already above your refresh
 * rate) and keeps the FPS cap at a chosen value. Options are held through
 * {@link OptionGuard}, so stacking it with Adaptive Render Distance or the
 * built-in optimizer no longer corrupts anyone's saved value.
 */
public class FrameSmooth extends Module {
   private static final String[] CAP_STYLES = {"Hard cap", "No cap", "Unchanged"};

   private final ModeSetting capStyle = new ModeSetting("Cap style", "How the FPS cap is handled", java.util.List.of(CAP_STYLES), "Hard cap");
   private final NumberSetting cap = new NumberSetting("Cap FPS", "Target when cap style is Hard cap", 144.0, 30.0, 480.0, 1.0);
   private final BooleanSetting vsyncOff = new BooleanSetting("Disable vsync", "Turn vsync off while enabled", true);

   public FrameSmooth() {
      super("Frame Smooth", "FPS cap + vsync handling", Category.MISC);
      this.addSettings(new Setting[]{this.capStyle, this.cap, this.vsyncOff});
   }

   @Override
   protected void onEnable() {
      this.apply();
   }

   @Override
   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null) {
         return;
      }
      OptionGuard.release(mc.options.getMaxFps(), this);
      OptionGuard.release(mc.options.getEnableVsync(), this);
   }

   @Override
   public void onTick() {
      this.apply();
   }

   private void apply() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }
      switch (this.capStyle.get()) {
         case "Hard cap" -> OptionGuard.hold(mc.options.getMaxFps(), Math.max(30, (int) Math.round(this.cap.get())), this);
         case "No cap" -> OptionGuard.hold(mc.options.getMaxFps(), 480, this);
         default -> OptionGuard.release(mc.options.getMaxFps(), this); // Unchanged
      }
      if (this.vsyncOff.get()) {
         if (mc.options.getEnableVsync().getValue()) {
            OptionGuard.hold(mc.options.getEnableVsync(), false, this);
         }
      } else {
         OptionGuard.release(mc.options.getEnableVsync(), this);
      }
   }
}
