package net.bluenetwork.client.ui.theme;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.config.ThemeManager;

/**
 * v2 semantic colour tokens.
 *
 * <p>Phase 1 provides a read-through adapter over the client's live palette
 * ({@link BlueColors}, which {@link ThemeManager} keeps up to date). New UI
 * code should read tokens through this class instead of touching
 * {@code BlueColors} fields directly, so the eventual replacement of the raw
 * palette with a token table happens in one place with no call-site churn.</p>
 *
 * <p>The long-term token table (dark/light-accent pairs, see the redesign
 * plan §3.2a) arrives in Phase 1b together with the cross-fade between themes;
 * the names below already match that table so nothing downstream changes.</p>
 */
public final class DesignTokens {
   private DesignTokens() {
   }

   /* --- semantic reads over the live palette --- */

   /** Primary interactive / active / focus colour. */
   public static int accent() {
      return BlueColors.ACCENT;
   }

   /** Accent at ~50 % alpha (soft fills, pressed states). */
   public static int accentSoft() {
      return BlueColors.ACCENT_SOFT;
   }

   /** Near-white primary text. */
   public static int textHi() {
      return BlueColors.TEXT_PRIMARY;
   }

   /** Muted secondary text. */
   public static int textMid() {
      return BlueColors.TEXT_MUTED;
   }

   /** Translucent dark panel fill. */
   public static int panelBg() {
      return BlueColors.PANEL_BG;
   }

   /** Hovered panel fill. */
   public static int panelBgHover() {
      return BlueColors.PANEL_BG_HOVER;
   }

   /** 1 px structural border. */
   public static int panelBorder() {
      return BlueColors.PANEL_BORDER;
   }

   /** Accent-tinted translucent glass tint. */
   public static int glassTint() {
      return BlueColors.GLASS_TINT;
   }

   /** Toggle "off" track colour (red = tap to turn on). */
   public static int toggleOff() {
      return BlueColors.TOGGLE_OFF;
   }

   /** Toggle "on" track colour (green = tap to turn off). */
   public static int toggleOn() {
      return 0xFF34C759;
   }

   public static String themeName() {
      return ThemeManager.currentTheme();
   }

   public static UiTheme theme() {
      return UiTheme.current();
   }
}
