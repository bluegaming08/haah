package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class Speedometer extends HudModule {
   public Speedometer() {
      super("Speedometer", "Shows your speed in blocks per second.", Category.HUD, 4, 262);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         double blocksPerSecond = mc.player.getVelocity().length() * 20.0;
         String text = String.format("Speed: %.1f b/s", blocksPerSecond);
         this.drawTextPanel(context, text);
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Speed: 99.9 b/s") + 12 + 2;
   }
}
