package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.optimization.PerformanceOptimizer;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;

/**
 * Custom FOV (bonus comfort module) — pin the FOV option to your chosen value
 * while enabled and restore whatever you had before on disable. A pure option
 * override; nothing about the world/render is modified.
 *
 * <p>v0.16.1: held through {@link OptionGuard}, so Zoom (which rides the same
 * option) stacks correctly instead of clobbering this module's value.
 */
public class CustomFov extends Module {
   private final NumberSetting fov = new NumberSetting("FOV", "Field of view in degrees", 90.0, 30.0, 120.0, 1.0);

   private double lastApplied = -1.0;

   public CustomFov() {
      super("Custom FOV", "Pin your FOV while enabled", Category.MISC);
      this.addSettings(new Setting[]{this.fov});
   }

   @Override
   protected void onEnable() {
      this.lastApplied = -1.0;
   }

   @Override
   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         OptionGuard.release(mc.options.getFov(), this);
      }
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }
      int target = (int) Math.round(this.fov.get());
      if (target != (int) Math.round(this.lastApplied)) {
         this.lastApplied = target;
         OptionGuard.hold(mc.options.getFov(), target, this);
      }
   }
}
