package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;

/**
 * Blue Logo - controls the Blue Client logo badge next to your name on
 * nametags and in the tab list (only shown for Blue Client users).
 */
public class BlueLogo extends Module {
   public BlueLogo() {
      super("Blue Logo", "Shows the Blue Client logo on nametags and the tab list", Category.MISC);
      this.setEnabled(true);
   }

   /** True when the logo badges should be drawn. */
   public static boolean showIcons() {
      try {
         for (Module m : BlueClient.getInstance().moduleManager().getModules()) {
            if (m instanceof BlueLogo logo) {
               return logo.isEnabled();
            }
         }
      } catch (Throwable ignored) {
      }
      return false;
   }
}
