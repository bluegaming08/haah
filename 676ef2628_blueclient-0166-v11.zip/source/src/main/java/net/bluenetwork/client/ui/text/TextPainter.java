package net.bluenetwork.client.ui.text;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.render.BlueFont;
import net.bluenetwork.client.ui.color.RainbowColor;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.DrawContext;

/**
 * Central text painter for v2 UI (plan §4.2). Draws the Poppins brand font with
 * the global {@link TextEffect} applied — this is how the single 3-way setting
 * reaches every new screen and (later) HUD element.
 *
 * <p>Effect rendering is built purely from offset passes through
 * {@link BlueFont#draw}, so it reuses the existing SDF pipeline and gracefully
 * falls back to the vanilla renderer if the custom font ever fails.</p>
 *
 * <p>Cost note: a glow pass redraws the glyphs a handful of times. That is fine
 * for short labels (menus, buttons, HUD panels); very long paragraphs should be
 * drawn with {@link TextEffect#SHADOW} or {@link TextEffect#NONE} — Phase 3
 * enforces a width cap so huge titles never take the glow path.</p>
 */
public final class TextPainter {
   private TextPainter() {
   }

   /**
    * The global text effect from client settings (defaults to Shadow & Glow).
    * When the UI surface is at FLAT quality (LoadGovernor stepped down, or the
    * user picked Flat glass), glow is skipped entirely and shadow is used —
    * glow is the single most expensive part of the text path.
    */
   public static TextEffect globalEffect() {
      try {
         BlueClient blue = BlueClient.getInstance();
         if (blue != null) {
            TextEffect chosen = blue.settings().textEffect();
            if (chosen == TextEffect.GLOW_SHADOW
               && blue.settings().glassLevel() == net.bluenetwork.client.ui.material.GlassSurface.FLAT) {
               return TextEffect.SHADOW;
            }
            return chosen;
         }
      } catch (Throwable ignored) {
      }
      return TextEffect.defaultEffect();
   }

   /** Draws Poppins text at logical size with the global text effect. */
   public static float drawPoppins(DrawContext context, String text, float x, float y, int color, float size) {
      return drawPoppins(context, text, x, y, color, size, globalEffect(), 1.0F);
   }

   /** Draws Poppins text at logical size with the global text effect and an explicit glow strength. */
   public static float drawPoppins(DrawContext context, String text, float x, float y, int color, float size, float strength) {
      return drawPoppins(context, text, x, y, color, size, globalEffect(), strength);
   }

   /** Draws Poppins text with an explicit effect (per-module override support). */
   public static float drawPoppins(DrawContext context, String text, float x, float y, int color, float size, TextEffect effect) {
      return drawPoppins(context, text, x, y, color, size, effect, 1.0F);
   }

   /**
    * Full draw. Returns the pen position after the text so callers can chain.
    *
    * @param strength 0..1 glow intensity (default 1)
    */
   public static float drawPoppins(DrawContext context, String text, float x, float y, int color, float size, TextEffect effect, float strength) {
      // v0.16.2: glow removed by design decision — every effect mode other than
      // NONE now renders the flat black drop shadow only (the classic
      // MiniMessage / vanilla look). GLOW_SHADOW is kept as a recognised enum
      // value (old configs, LoadGovernor tiers) but no longer draws a halo.
      switch (effect == null ? TextEffect.defaultEffect() : effect) {
         case NONE:
            return BlueFont.get("poppins").draw(context, text, x, y, color, false, size);
         case GLOW_SHADOW:
         case SHADOW:
         default:
            return BlueFont.get("poppins").draw(context, text, x, y, color, true, size);
      }
   }

   /**
    * v0.16.1: the glow is always the glyph's own (stroke) colour — text now
    * self-tints instead of glowing accent-blue.
    */
   public static int glowTintFor(int glyphColor) {
      return glyphColor & 0xFFFFFF;
   }

   public static float poppinsWidth(String text, float size) {
      return BlueFont.get("poppins").width(text, size);
   }

   public static float poppinsWidth(String text) {
      return poppinsWidth(text, 9.0F);
   }

   /** Rainbow convenience — packs a rainbow rgb for callers that want hue-driven draws. */
   public static int rainbowRgb(long timeMs, float cyclesPerSecond, float offset) {
      return RainbowColor.rgb(timeMs, cyclesPerSecond, offset);
   }
}
