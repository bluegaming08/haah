package net.bluenetwork.client.config;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.JsonUtil;
import net.fabricmc.loader.api.FabricLoader;

public class ConfigManager {
   private final BlueClient client;
   private final Path configDir;
   private final Path configFile;

   public ConfigManager(BlueClient client) {
      this.client = client;
      this.configDir = FabricLoader.getInstance().getConfigDir().resolve("blueclient");
      this.configFile = this.configDir.resolve("config.json");
   }

   public void load() {
      if (Files.exists(this.configFile)) {
         try {
            JsonObject root = JsonParser.parseString(Files.readString(this.configFile)).getAsJsonObject();
            if (!root.has("modules")) {
               return;
            }

            for (JsonElement element : root.getAsJsonArray("modules")) {
               JsonObject moduleJson = element.getAsJsonObject();
               Module module = this.client.moduleManager().byName(moduleJson.get("name").getAsString());
               if (module != null) {
                  if (moduleJson.has("enabled")) {
                     module.setEnabled(moduleJson.get("enabled").getAsBoolean());
                  }

                  if (moduleJson.has("keybind")) {
                     module.setKeybind(moduleJson.get("keybind").getAsInt());
                  }

                  if (moduleJson.has("settings")) {
                     for (Setting<?> setting : module.getSettings()) {
                        if (moduleJson.getAsJsonObject("settings").has(setting.getName())) {
                           setting.fromJson(moduleJson.getAsJsonObject("settings").get(setting.getName()));
                        }
                     }
                  }

                  if (module instanceof HudModule hud && moduleJson.has("hud")) {
                     JsonObject hudJson = moduleJson.getAsJsonObject("hud");
                     if (hudJson.has("anchor")) {
                        hud.setAnchorAndOffsets(
                           HudModule.Anchor.valueOf(hudJson.get("anchor").getAsString()),
                           hudJson.get("ox").getAsInt(),
                           hudJson.get("oy").getAsInt()
                        );
                     } else {
                        // Legacy config: absolute coords, converted at the first resolve
                        hud.setRawPosition(hudJson.get("x").getAsInt(), hudJson.get("y").getAsInt());
                     }
                  }
               }
            }

            BlueClient.LOGGER.info("Loaded Blue Client config from {}", this.configFile);
         } catch (Exception var8) {
            BlueClient.LOGGER.error("Failed to load config - starting with defaults", var8);
         }
      }
   }

   public void save() {
      try {
         Files.createDirectories(this.configDir);
         JsonObject root = new JsonObject();
         JsonArray modulesArray = new JsonArray();

         for (Module module : this.client.moduleManager().getModules()) {
            JsonObject moduleJson = new JsonObject();
            moduleJson.addProperty("name", module.getName());
            moduleJson.addProperty("enabled", module.isEnabled());
            moduleJson.addProperty("keybind", module.getKeybind());
            if (!module.getSettings().isEmpty()) {
               JsonObject settingsJson = new JsonObject();

               for (Setting<?> setting : module.getSettings()) {
                  settingsJson.add(setting.getName(), setting.toJson());
               }

               moduleJson.add("settings", settingsJson);
            }

            if (module instanceof HudModule hud) {
               JsonObject hudJson = new JsonObject();
               hudJson.addProperty("x", hud.getX());
               hudJson.addProperty("y", hud.getY());
               hudJson.addProperty("anchor", hud.getAnchor().name());
               hudJson.addProperty("ox", hud.getOffsetX());
               hudJson.addProperty("oy", hud.getOffsetY());
               hudJson.addProperty("scale", hud.getScale());
               moduleJson.add("hud", hudJson);
            }

            modulesArray.add(moduleJson);
         }

         root.add("modules", modulesArray);
         Files.writeString(this.configFile, JsonUtil.pretty(root));
      } catch (IOException var9) {
         BlueClient.LOGGER.error("Failed to save config", var9);
      }
   }
}
