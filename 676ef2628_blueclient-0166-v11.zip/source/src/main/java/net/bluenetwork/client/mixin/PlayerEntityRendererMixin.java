package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.brand.BlueBrand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerEntityRenderer.class})
public abstract class PlayerEntityRendererMixin {
   @Inject(
      method = {"updateRenderState"},
      at = {@At("TAIL")}
   )
   private void blueclient$nametagIcon(PlayerLikeEntity entity, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
      if (entity == null || state == null || state.displayName == null) {
         return;
      }
      // 1) Blue Client logo badge after the name for Blue Client users
      if (net.bluenetwork.client.module.impl.BlueLogo.showIcons()
         && BlueClient.getInstance().presence().isBlueClientUser(entity.getUuid())) {
         state.displayName = BlueBrand.withIcon(state.displayName);
      }
      // 2) v0.16.13: Third Person Nametag - restyle YOUR OWN nametag
      //    (color / bold / shadow), visible in F5 third person.
      try {
         MinecraftClient client = MinecraftClient.getInstance();
         if (net.bluenetwork.client.module.impl.ThirdPersonNametag.active()
            && client != null && client.player != null
            && client.player.getUuid().equals(entity.getUuid())
            && !client.player.isInvisible()) {
            Text base = state.displayName;
            state.displayName = base.copy().styled(style -> {
               style = style.withColor(net.bluenetwork.client.module.impl.ThirdPersonNametag.colorRgb());
               if (net.bluenetwork.client.module.impl.ThirdPersonNametag.boldOn()) {
                  style = style.withBold(true);
               }
               if (net.bluenetwork.client.module.impl.ThirdPersonNametag.shadowOn()) {
                  style = style.withShadowColor(0xFF000000);
               }
               return style;
            });
         }
      } catch (Throwable ignored) {
         // styling is cosmetic - never let it break entity rendering
      }
   }
}
