package net.bluenetwork.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting<Double> {
   private final double min;
   private final double max;
   private final double step;

   public NumberSetting(String name, String description, double defaultValue, double min, double max, double step) {
      super(name, description, defaultValue);
      this.min = min;
      this.max = max;
      this.step = step;
      this.set(defaultValue);
   }

   public void set(Double value) {
      double snapped = Math.round(value / this.step) * this.step;
      super.set(Math.max(this.min, Math.min(this.max, snapped)));
   }

   public double getMin() {
      return this.min;
   }

   public double getMax() {
      return this.max;
   }

   public double getStep() {
      return this.step;
   }

   public int getInt() {
      return (int)Math.round(this.get());
   }

   public float getFloat() {
      return this.get().floatValue();
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.get());
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
         this.set(element.getAsDouble());
      }
   }
}
