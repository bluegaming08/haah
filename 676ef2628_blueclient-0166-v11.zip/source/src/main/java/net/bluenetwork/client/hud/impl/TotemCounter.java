package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * Totem Counter (v3 catalogue A2) — live count of totems of undying in your
 * inventory (incl. offhand). Optional warn colour when the count drops to a
 * threshold; hides entirely at zero by default. Pure inventory read, safe.
 */
public class TotemCounter extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Normal count colour", 0xFFFFFFFF);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Colour when at/below the warn threshold", 0xFFFF5C5C);
   private final NumberSetting warnAt = new NumberSetting("Warn at", "Count at or below which the warning colour is used", 1.0, 0.0, 8.0, 1.0);
   private final BooleanSetting hideAtZero = new BooleanSetting("Hide at zero", "Show nothing when you have no totems", true);

   public TotemCounter() {
      super("Totem Counter", "Totems of undying in your inventory + offhand", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.warnColor, this.warnAt, this.hideAtZero});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 54);
   }

   public int count() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return 0;
      }
      int total = 0;
      for (ItemStack stack : mc.player.getInventory().getMainStacks()) {
         if (!stack.isEmpty() && stack.isOf(Items.TOTEM_OF_UNDYING)) {
            total += stack.getCount();
         }
      }
      ItemStack offhand = mc.player.getOffHandStack();
      if (!offhand.isEmpty() && offhand.isOf(Items.TOTEM_OF_UNDYING)) {
         total += offhand.getCount();
      }
      return total;
   }

   private int displayColor() {
      return this.count() <= this.warnAt.getInt()
         ? this.warnColor.currentRgb(System.currentTimeMillis())
         : this.textColor.currentRgb(System.currentTimeMillis());
   }

   @Override
   public void render(DrawContext context) {
      int total = this.count();
      if (total <= 0 && this.hideAtZero.get()) {
         return;
      }
      if (MinecraftClient.getInstance().player == null) {
         return;
      }
      String text = "Totems \u00d7" + total;
      this.drawPanel(context);
      RenderUtil.drawText(context, text, this.x + 6 + 2, this.y + 6, this.displayColor());
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Totems \u00d7" + this.count()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
