package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

public class CustomCrosshair extends Module {
   private final ModeSetting style = new ModeSetting("Style", "Crosshair shape", List.of("Cross", "Dot", "Circle"), "Cross");
   private final ColorSetting color = new ColorSetting("Color", "Crosshair color (RGB / hex)", -13673473);
   private final NumberSetting size = new NumberSetting("Size", "Crosshair arm length / radius", 5.0, 2.0, 14.0, 1.0);
   private final BooleanSetting outline = new BooleanSetting("Outline", "Black outline around the crosshair", true);

   public CustomCrosshair() {
      super("Crosshair", "Custom crosshair with RGB/hex colors", Category.RENDER);
      this.addSettings(new Setting[]{this.style, this.color, this.size, this.outline});
   }

   public String style() {
      return this.style.get();
   }

   public int color() {
      return this.color.get();
   }

   public int size() {
      return this.size.getInt();
   }

   public boolean outline() {
      return this.outline.get();
   }
}
