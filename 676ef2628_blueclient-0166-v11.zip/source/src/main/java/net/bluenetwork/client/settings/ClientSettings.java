package net.bluenetwork.client.settings;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextEffect;
import net.fabricmc.loader.api.FabricLoader;

public class ClientSettings {
   private boolean customMainMenu = true;
   private boolean customPauseMenu = true;
   private boolean animations = true;
   private int renderScale = 3; // v0.16.5: ship high-res by default
   private int chunkThreads = 0;
   private int menuButtonOpacity = 10;
   private boolean menuIntroAnim = true;
   private int chunkPreload = 300;

   /** GUI render-scale presets: 0 = vanilla auto. */
   public static final String[] RESOLUTION_NAMES = {"POTATO (1x)", "PERFORMANCE (2x)", "NATIVE (AUTO)", "HIGH (3x)", "4K CLASS (4x)"};
   public static final int[] RESOLUTION_SCALE = {1, 2, 0, 3, 4};
   /** Chunk builder worker-thread presets (index 0 = vanilla auto). */
   public static final String[] CHUNK_THREAD_NAMES = {"AUTO", "BOOST +2", "BOOST +4", "BOOST +8"};
   private boolean lightTheme = false;
   private int menuBackground = 0;
   private String gradientTop = "#0A1230";
   private String gradientBottom = "#0026E0";
   private boolean guiCards = true;
   private boolean presence = true;
   private int guiKeybind = 344;
   private String msClientId = "c36a9fb6-4f15-4b4f-8817-4a4f7f0a4f8c";
   private int configVersion = 2;
   private String theme = "DARK";
   private boolean perfOptimizer = false;
   private boolean perfParticles = true;
   private boolean perfCulling = true;
   private boolean perfAdaptive = true;
   private boolean hudGridSnap = true;
   private boolean modulesEnabledFirst = true;
   private String textEffect = TextEffect.SHADOW.name();
   private String glassLevel = GlassSurface.GLASS.name();

   public void load() {
      try {
         Path file = path();
         if (!Files.exists(file)) {
            return;
         }

         JsonObject json = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
         if (json.has("customMainMenu")) {
            this.customMainMenu = json.get("customMainMenu").getAsBoolean();
         }

         if (json.has("customPauseMenu")) {
            this.customPauseMenu = json.get("customPauseMenu").getAsBoolean();
         }

         if (json.has("renderScale")) {
            this.renderScale = Math.max(0, Math.min(4, json.get("renderScale").getAsInt()));
         }
         if (json.has("chunkThreads")) {
            this.chunkThreads = Math.max(0, Math.min(3, json.get("chunkThreads").getAsInt()));
         }
         if (json.has("menuButtonOpacity")) {
            this.menuButtonOpacity = Math.max(0, Math.min(100, json.get("menuButtonOpacity").getAsInt()));
         }
         if (json.has("menuIntroAnim")) {
            this.menuIntroAnim = json.get("menuIntroAnim").getAsBoolean();
         }
         if (json.has("chunkPreload")) {
            this.chunkPreload = Math.max(100, Math.min(5000, json.get("chunkPreload").getAsInt()));
         }
         if (json.has("animations")) {
            this.animations = json.get("animations").getAsBoolean();
         }


         if (json.has("lightTheme")) {
            this.lightTheme = json.get("lightTheme").getAsBoolean();
         }

         if (json.has("theme")) {
            this.theme = json.get("theme").getAsString();
         } else if (this.lightTheme) {
            this.theme = "LIGHT";
         }

         ThemeManager.applyByName(this.theme);
         if (json.has("perfOptimizer")) {
            this.perfOptimizer = json.get("perfOptimizer").getAsBoolean();
         }

         if (json.has("perfParticles")) {
            this.perfParticles = json.get("perfParticles").getAsBoolean();
         }

         if (json.has("perfCulling")) {
            this.perfCulling = json.get("perfCulling").getAsBoolean();
         }

         if (json.has("perfAdaptive")) {
            this.perfAdaptive = json.get("perfAdaptive").getAsBoolean();
         }

         if (json.has("hudGridSnap")) {
            this.hudGridSnap = json.get("hudGridSnap").getAsBoolean();
         }

         if (json.has("modulesEnabledFirst")) {
            this.modulesEnabledFirst = json.get("modulesEnabledFirst").getAsBoolean();
         }

         if (json.has("menuBackground")) {
            this.menuBackground = json.get("menuBackground").getAsInt();
         }

         if (json.has("gradientTop") && json.get("gradientTop").isJsonPrimitive()) {
            this.gradientTop = json.get("gradientTop").getAsString();
         }

         if (json.has("gradientBottom") && json.get("gradientBottom").isJsonPrimitive()) {
            this.gradientBottom = json.get("gradientBottom").getAsString();
         }

         if (json.has("guiCards")) {
            this.guiCards = json.get("guiCards").getAsBoolean();
         }

         if (json.has("presence")) {
            this.presence = json.get("presence").getAsBoolean();
         }

         if (json.has("guiKeybind")) {
            this.guiKeybind = json.get("guiKeybind").getAsInt();
         }

         if (json.has("msClientId") && json.get("msClientId").isJsonPrimitive()) {
            this.msClientId = json.get("msClientId").getAsString();
         }

         if (json.has("configVersion")) {
            this.configVersion = json.get("configVersion").getAsInt();
         }

         if (json.has("textEffect")) {
            this.textEffect = TextEffect.parse(json.get("textEffect").getAsString()).name();
         }

         if (json.has("glassLevel")) {
            this.glassLevel = GlassSurface.parse(json.get("glassLevel").getAsString()).name();
         }
      } catch (Throwable var3) {
         BlueClient.LOGGER.debug("Could not load client settings, using defaults", var3);
      }

      if (this.configVersion < 2) {
         this.configVersion = 2;
      }
   }

   public void save() {
      try {
         JsonObject json = new JsonObject();
         json.addProperty("customMainMenu", this.customMainMenu);
         json.addProperty("customPauseMenu", this.customPauseMenu);
         json.addProperty("animations", this.animations);
         json.addProperty("renderScale", this.renderScale);
         json.addProperty("chunkThreads", this.chunkThreads);
         json.addProperty("menuButtonOpacity", this.menuButtonOpacity);
         json.addProperty("menuIntroAnim", this.menuIntroAnim);
         json.addProperty("chunkPreload", this.chunkPreload);
         json.addProperty("lightTheme", this.lightTheme);
         json.addProperty("theme", this.theme);
         json.addProperty("perfOptimizer", this.perfOptimizer);
         json.addProperty("perfParticles", this.perfParticles);
         json.addProperty("perfCulling", this.perfCulling);
         json.addProperty("perfAdaptive", this.perfAdaptive);
         json.addProperty("hudGridSnap", this.hudGridSnap);
         json.addProperty("modulesEnabledFirst", this.modulesEnabledFirst);
         json.addProperty("menuBackground", this.menuBackground);
         json.addProperty("gradientTop", this.gradientTop);
         json.addProperty("gradientBottom", this.gradientBottom);
         json.addProperty("guiCards", this.guiCards);
         json.addProperty("presence", this.presence);
         json.addProperty("guiKeybind", this.guiKeybind);
         json.addProperty("msClientId", this.msClientId);
         json.addProperty("configVersion", this.configVersion);
         json.addProperty("textEffect", this.textEffect);
         json.addProperty("glassLevel", this.glassLevel);
         Files.createDirectories(path().getParent());
         Files.writeString(path(), json.toString(), StandardCharsets.UTF_8);
      } catch (Throwable var2) {
         BlueClient.LOGGER.debug("Could not save client settings", var2);
      }
   }

   private static Path path() {
      return FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("client-settings.json");
   }

   public boolean customMainMenu() {
      return this.customMainMenu;
   }

   public void customMainMenu(boolean v) {
      this.customMainMenu = v;
      this.save();
   }

   public boolean customPauseMenu() {
      return this.customPauseMenu;
   }

   public void customPauseMenu(boolean v) {
      this.customPauseMenu = v;
      this.save();
   }

   public boolean animations() {
      return this.animations;
   }

   public void animations(boolean v) {
      this.animations = v;
      this.save();
   }

   public int renderScale() {
      return this.renderScale;
   }

   public void renderScale(int v) {
      this.renderScale = Math.max(0, Math.min(4, v));
      this.save();
   }

   public int chunkThreads() {
      return this.chunkThreads;
   }

   public void chunkThreads(int v) {
      this.chunkThreads = Math.max(0, Math.min(3, v));
      this.save();
   }

   public boolean presence() {
      return this.presence;
   }

   public void presence(boolean v) {
      this.presence = v;
      this.save();
   }

   public int guiKeybind() {
      return this.guiKeybind;
   }

   public void guiKeybind(int key) {
      this.guiKeybind = key;
      this.save();
   }

   public String msClientId() {
      return this.msClientId;
   }

   public void msClientId(String id) {
      this.msClientId = id == null ? "" : id.trim();
      this.save();
   }

   public int configVersion() {
      return this.configVersion;
   }

   public boolean lightTheme() {
      return this.lightTheme;
   }

   public void lightTheme(boolean light) {
      this.theme(light ? "LIGHT" : "DARK");
   }

   public String themeName() {
      return this.theme;
   }

   public void theme(String name) {
      this.theme = name;
      this.lightTheme = "LIGHT".equals(name);
      ThemeManager.applyByName(name);
      this.save();
   }

   public boolean perfOptimizer() {
      return this.perfOptimizer;
   }

   public void perfOptimizer(boolean v) {
      this.perfOptimizer = v;
      this.save();
   }

   public boolean perfParticles() {
      return this.perfParticles;
   }

   public void perfParticles(boolean v) {
      this.perfParticles = v;
      this.save();
   }

   public boolean perfCulling() {
      return this.perfCulling;
   }

   public void perfCulling(boolean v) {
      this.perfCulling = v;
      this.save();
   }

   public boolean perfAdaptive() {
      return this.perfAdaptive;
   }

   public void perfAdaptive(boolean v) {
      this.perfAdaptive = v;
      this.save();
   }

   /** Modules menu: sort enabled modules to the top (v0.16.11 toggle). */
   public boolean modulesEnabledFirst() {
      return this.modulesEnabledFirst;
   }

   public void modulesEnabledFirst(boolean v) {
      this.modulesEnabledFirst = v;
      this.save();
   }

   public boolean hudGridSnap() {
      return this.hudGridSnap;
   }

   public void hudGridSnap(boolean v) {
      this.hudGridSnap = v;
      this.save();
   }

   public int menuButtonOpacity() {
      return this.menuButtonOpacity;
   }

   public void menuButtonOpacity(int v) {
      this.menuButtonOpacity = Math.max(0, Math.min(100, v));
      this.save();
   }

   public boolean menuIntroAnim() {
      return this.menuIntroAnim;
   }

   public void menuIntroAnim(boolean v) {
      this.menuIntroAnim = v;
      this.save();
   }

   public int chunkPreload() {
      return this.chunkPreload;
   }

   public void chunkPreload(int v) {
      this.chunkPreload = Math.max(100, Math.min(5000, v));
      this.save();
   }

   public int menuBackground() {
      return this.menuBackground;
   }

   public void menuBackground(int background) {
      this.menuBackground = Math.max(0, Math.min(4, background));
      this.save();
   }

   public String gradientTop() {
      return this.gradientTop;
   }

   public void gradientTop(String hex) {
      this.gradientTop = hex;
      this.save();
   }

   public String gradientBottom() {
      return this.gradientBottom;
   }

   public void gradientBottom(String hex) {
      this.gradientBottom = hex;
      this.save();
   }

   public boolean guiCards() {
      return this.guiCards;
   }

   public void guiCards(boolean cards) {
      this.guiCards = cards;
      this.save();
   }

   public void configVersion(int v) {
      this.configVersion = v;
      this.save();
   }

   /* ---- v2 appearance settings ---- */

   /** Global text style: Shadow & Glow (default) / Shadow / None. */
   public TextEffect textEffect() {
      return TextEffect.parse(this.textEffect);
   }

   public void textEffect(TextEffect effect) {
      this.textEffect = effect == null ? TextEffect.defaultEffect().name() : effect.name();
      this.save();
   }

   /** Global glass level: Glass (default) / Matte / Flat. */
   public GlassSurface glassLevel() {
      return GlassSurface.parse(this.glassLevel);
   }

   public void glassLevel(GlassSurface level) {
      this.glassLevel = level == null ? GlassSurface.defaultSurface().name() : level.name();
      this.save();
   }

   private static int clampInt(int v, int min, int max) {
      return Math.max(min, Math.min(max, v));
   }
}