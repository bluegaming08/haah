package net.bluenetwork.client.config;

import net.bluenetwork.client.BlueColors;

/**
 * Theme system from the premium pack, wired for real: every theme writes a
 * full palette into BlueColors, which every screen reads, so themes apply
 * instantly and survive restarts via ClientSettings ("theme" key).
 *
 * DARK and LIGHT keep the exact original Blue Client palettes; the five
 * premium themes derive their panels from the pack's base colors.
 */
public final class ThemeManager {
   /**
    * v0.16.1: the old "LUNAR" and "DAWN" themes were renamed to COSMIC and
    * EMBER (feedback 2026-09-11) — saved configs that still mention the old
    * names are migrated in {@link #normalize(String)} below.
    */
   public static final String[] THEMES = new String[]{"DARK", "LIGHT", "COSMIC", "EMBER", "MIDNIGHT", "NEON", "EMERALD"};

   /** The client's original accent (#2FA5FF) - captured before ACCENT became theme-mutable. */
   public static final int DEFAULT_ACCENT = -13673473;

   private static String current = "DARK";

   private ThemeManager() {
   }

   public static String currentTheme() {
      return current;
   }

   public static void applyByName(String name) {
      String target = normalize(name);
      current = target;
      int accent = switch (target) {
         case "LIGHT" -> DEFAULT_ACCENT;
         case "COSMIC" -> 0xFF8F7BFF;
         case "EMBER" -> 0xFFFF8A5C;
         case "MIDNIGHT" -> 0xFF2A9FFF;
         case "NEON" -> 0xFFFF00FF;
         case "EMERALD" -> 0xFF00FF6B;
         default -> DEFAULT_ACCENT;
      };
      int bg = switch (target) {
         case "COSMIC" -> 0x16142E;
         case "EMBER" -> 0x2E1B12;
         case "MIDNIGHT" -> 0x0A0A1A;
         case "NEON" -> 0x0A0A0A;
         case "EMERALD" -> 0x0A1A0A;
         default -> 0;
      };
      boolean light = "LIGHT".equals(target);
      applyPalette(accent, bg, light);
   }

   /** Cycles to the next theme and returns its name. */
   public static String cycle() {
      int next = 0;
      for (int i = 0; i < THEMES.length; i++) {
         if (THEMES[i].equals(current)) {
            next = (i + 1) % THEMES.length;
         }
      }
      applyByName(THEMES[next]);
      return current;
   }

   private static void applyPalette(int accent, int bg, boolean light) {
      // Base light/dark panel palette (original Blue Client values)
      BlueColors.applyTheme(light);
      BlueColors.ACCENT = accent;
      BlueColors.ACCENT_SOFT = 0x66000000 | accent & 0xFFFFFF;
      if (!light && bg != 0) {
         // Premium dark themes: tint panels with the theme's base color
         BlueColors.PANEL_BG = 0x99000000 | bg;
         BlueColors.PANEL_BG_HOVER = 0xB3000000 | brighten(bg, 30);
         BlueColors.PANEL_BORDER = 0x1F000000 | brighten(bg, 90) | 0x555555;
         BlueColors.GLASS_TINT = 0x18000000 | accent & 0xFFFFFF;
      }
   }

   private static int brighten(int rgb, int amount) {
      int r = Math.min(255, (rgb >> 16 & 0xFF) + amount);
      int g = Math.min(255, (rgb >> 8 & 0xFF) + amount);
      int b = Math.min(255, (rgb & 0xFF) + amount);
      return r << 16 | g << 8 | b;
   }

   private static String normalize(String name) {
      if (name != null) {
         String trimmed = name.trim();
         // Legacy migration: pre-0.16.1 configs may still store the old names.
         if (trimmed.equalsIgnoreCase("LUNAR")) {
            return "COSMIC";
         }
         if (trimmed.equalsIgnoreCase("DAWN")) {
            return "EMBER";
         }
         for (String t : THEMES) {
            if (t.equalsIgnoreCase(trimmed)) {
               return t;
            }
         }
      }
      return "DARK";
   }
}
