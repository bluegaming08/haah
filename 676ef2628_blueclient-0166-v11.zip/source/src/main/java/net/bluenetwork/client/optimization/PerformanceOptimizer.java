package net.bluenetwork.client.optimization;

import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticlesMode;

/**
 * Performance optimizer from the premium pack, made real:
 * - FPS cap management (user-set cap, restored on disable)
 * - Particle mode reduction (ALL -> MINIMAL, restored on disable)
 * - Adaptive framerate: drops the cap while the window is unfocused
 * - Live FPS/memory stats via the client's own counters
 * - Entity culling: distant entities skip rendering (see EntityRendererMixin,
 *   gated on cullingEnabled() and cullDistance)
 *
 * The master toggle + sub-toggles persist in ClientSettings.
 *
 * <p>v0.16.1: option writes go through {@link OptionGuard} so FrameSmooth /
 * Adaptive Render Distance / Custom FOV can't capture this optimizer's values
 * as "the user's original" (and vice versa).
 */
public final class PerformanceOptimizer {
   private static final Object OWNER = PerformanceOptimizer.class;

   private static boolean enabled = false;
   private static boolean particleOptimization = true;
   private static boolean adaptiveFramerate = true;
   private static boolean entityCulling = true;
   private static int maxFps = 144;
   private static int cullDistance = 48;
   private static boolean unfocusedCapped = false;

   private PerformanceOptimizer() {
   }

   /** Enables or disables all optimizations, capturing/restoring vanilla option values. */
   public static void setEnabled(boolean value) {
      if (enabled == value) {
         return;
      }
      enabled = value;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null) {
         return;
      }
      if (enabled) {
         applyFpsCap(mc);
         if (particleOptimization) {
            applyParticles(mc, ParticlesMode.MINIMAL);
         }
      } else {
         OptionGuard.release(mc.options.getMaxFps(), OWNER);
         OptionGuard.release(mc.options.getParticles(), OWNER);
         unfocusedCapped = false;
      }
   }

   /** The cap we apply while focused: the user's cap if it is higher, ours otherwise. */
   private static void applyFpsCap(MinecraftClient mc) {
      Integer original = OptionGuard.original(mc.options.getMaxFps());
      int effective = Math.max(maxFps, original != null && original > 0 ? original : 0);
      effective = Math.max(30, effective);
      OptionGuard.hold(mc.options.getMaxFps(), effective, OWNER);
   }

   private static void applyParticles(MinecraftClient mc, ParticlesMode mode) {
      OptionGuard.hold(mc.options.getParticles(), mode, OWNER);
   }

   /** Called once per client tick from the main tick loop. */
   public static void tick() {
      if (!enabled) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }
      if (!OptionGuard.isHeldBy(mc.options.getMaxFps(), OWNER)) {
         applyFpsCap(mc);
      }
      if (adaptiveFramerate) {
         boolean focused = mc.isWindowFocused();
         if (!focused && !unfocusedCapped) {
            OptionGuard.setValue(mc.options.getMaxFps(), 10, OWNER);
            unfocusedCapped = true;
         } else if (focused && unfocusedCapped) {
            Integer original = OptionGuard.original(mc.options.getMaxFps());
            int effective = Math.max(maxFps, original != null && original > 0 ? original : 0);
            OptionGuard.setValue(mc.options.getMaxFps(), Math.max(30, effective), OWNER);
            unfocusedCapped = false;
         }
      }
   }

   public static boolean isOptimizationEnabled() {
      return enabled;
   }

   public static boolean isParticleOptimizationEnabled() {
      return enabled && particleOptimization;
   }

   public static void setParticleOptimization(boolean value) {
      particleOptimization = value;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (enabled && mc != null && mc.options != null && OptionGuard.areOptionsReady()) {
         if (particleOptimization) {
            applyParticles(mc, ParticlesMode.MINIMAL);
         } else {
            OptionGuard.release(mc.options.getParticles(), OWNER);
         }
      }
   }

   public static boolean isAdaptiveFramerateEnabled() {
      return adaptiveFramerate;
   }

   public static void setAdaptiveFramerate(boolean value) {
      adaptiveFramerate = value;
   }

   public static boolean isEntityCullingEnabled() {
      return enabled && entityCulling;
   }

   public static void setEntityCulling(boolean value) {
      entityCulling = value;
   }

   public static int getCullDistance() {
      return cullDistance;
   }

   public static void setCullDistance(int distance) {
      cullDistance = Math.max(16, Math.min(128, distance));
   }

   public static void setMaxFps(int fps) {
      maxFps = Math.max(30, Math.min(480, fps));
      MinecraftClient mc = MinecraftClient.getInstance();
      if (enabled && mc != null && mc.options != null && OptionGuard.areOptionsReady() && !unfocusedCapped) {
         applyFpsCap(mc);
      }
   }

   public static int getMaxFps() {
      return maxFps;
   }

   /** Real current FPS straight from the client's own frame counter. */
   public static double getCurrentFPS() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc != null ? mc.getCurrentFps() : 0.0;
   }

   public static long getMemoryUsage() {
      Runtime runtime = Runtime.getRuntime();
      return (runtime.totalMemory() - runtime.freeMemory()) / 1024L / 1024L;
   }

   public static long getMaxMemory() {
      return Runtime.getRuntime().maxMemory() / 1024L / 1024L;
   }

   /** Explicit, user-triggered GC (never called automatically - silent GC calls are not an optimization). */
   public static void optimizeMemory() {
      System.gc();
   }
}
