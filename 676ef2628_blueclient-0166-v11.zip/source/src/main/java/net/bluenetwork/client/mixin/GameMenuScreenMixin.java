package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.gui.PauseMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Vanilla pause menu integration:
 * <ul>
 *   <li>when the custom pause menu is ON, init is cancelled and replaced with
 *       our PauseMenuScreen.</li>
 *   <li>when the VANILLA pause menu is showing, two square glass buttons are
 *       placed top-right: the Blue Client switch (back to the custom menu)
 *       and a settings shortcut (Client Settings). Their skins are drawn by
 *       ScreenMixin (opaque dark squares with a logo / gear icon).</li>
 * </ul>
 */
@Mixin({GameMenuScreen.class})
public abstract class GameMenuScreenMixin {
   @Inject(
      method = {"init"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$replacePauseMenu(CallbackInfo ci) {
      if (BlueClient.getInstance().settings().customPauseMenu()) {
         MinecraftClient.getInstance().setScreen(new PauseMenuScreen());
         ci.cancel();
      }
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void blueclient$positionSquares(CallbackInfo ci) {
      if (!BlueClient.getInstance().settings().customPauseMenu()) {
         net.bluenetwork.client.gui.PauseSquares.position((Screen)(Object)this);
      }
   }
}
