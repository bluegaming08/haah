package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.gui.AccountsScreen;
import net.bluenetwork.client.gui.ClientSettingsScreen;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.impl.MenuCustomizer;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.ui.motion.Easing;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * ModuleMenuScreen v5 - "Blue Console, Lunar anatomy" (feedback 2026-09-11).
 *
 * <p>The v4 panel sized itself from the raw window and could end up wider or
 * taller than the space left around it, which is exactly why users saw the
 * background border box "cut off" with cards spilling past the right edge.
 * v5 fixes that for good:</p>
 * <ul>
 *   <li>The whole menu renders in a virtual resolution and an extra
 *       <i>fit factor</i> shrinks the menu whenever the window is smaller
 *       than the design size - the panel (and its border) ALWAYS fits fully
 *       inside the window with a margin on every side.</li>
 *   <li>The scrollable module area is scissored to its own rectangle only,
 *       so nothing can ever paint over the panel border or the chrome.</li>
 * </ul>
 *
 * <p>Visual language follows Lunar Client's mods menu (attached reference
 * shots): top bar with logo, centre tabs and a close button; left sidebar;
 * a filter-chip row with a grid/list view toggle and search; then either
 * <b>cards</b> (big centred icon, name, OPTIONS bar, ENABLED/DISABLED bar)
 * or the compact <b>list</b> grid (bordered rows, green = on, red = off,
 * gear button on the right).</p>
 */
public class ModuleMenuScreen extends Screen {
   /* virtual-space design constants */
   private static final int DESIGN_W = 700;
   private static final int DESIGN_H = 430;
   private static final int TOP_BAR_H = 34;
   private static final int SIDEBAR_W = 128;
   private static final int TOOLBAR_H = 30;
   private static final int PAD = 10;
   private static final int GAP = 8;
   private static final int CARD_MIN_W = 176;
   private static final int CARD_H = 112;
   private static final int LIST_MIN_W = 196;
   private static final int LIST_H = 24;
   private static final int SEARCH_W = 150;
   private static final int SEARCH_H = 20;

   private static final int GREEN = 0xFF3CB860;
   private static final int GREEN_DIM = 0x9943B581;
   private static final int CRIMSON = 0xFFC9405E;
   private static final int CRIMSON_DIM = 0x99B03060;

   private final BlueClient blue;
   private final Screen parent;

   private String query = "";
   private boolean searchFocused = false;
   private Category category; // null = All
   /** Session override from the grid/list buttons; null = follow the style setting. */
   private Boolean viewOverride = null;

   private float targetScroll;
   private float smoothScroll;

   private final Map<String, Long> toggleAnim = new HashMap<>();
   private long revealStartMs = System.currentTimeMillis();

   private final List<RectHit> chipHits = new ArrayList<>();
   private final List<RectHit> tabHits = new ArrayList<>();
   private final List<RectHit> sideHits = new ArrayList<>();
   private final List<ModuleHit> optionHits = new ArrayList<>();
   private final List<ModuleHit> toggleHits = new ArrayList<>();
   private final List<ModuleHit> gearHits = new ArrayList<>();
   private final List<ModuleHit> bodyHits = new ArrayList<>();
   private Rect searchBox;
   private Rect gridBtn;
   private Rect listBtn;
   private Rect sortBtn;
   private Rect closeBtn;
   private Rect saveBtn;
   private Rect hudBtn;
   private float listTop;
   private float listBottom;
   private float drawScale = 1.0F;
   private boolean draggingThumb;
   private float thumbGrabOff;
   private float thumbX = Float.MIN_VALUE;
   private float trackTop;
   private float trackH;
   private float thumbHf = 24.0F;
   private float scrollMaxF;

   public ModuleMenuScreen(BlueClient blue) {
      this(blue, null);
   }

   public ModuleMenuScreen(BlueClient blue, Screen parent) {
      super(Text.literal("Modules"));
      this.blue = blue;
      this.parent = parent;
   }

   /**
    * Cards or list layout, read LIVE every frame: the toolbar toggle's
    * session override wins, otherwise the Menu Customizer's Menu Style
    * setting decides (cards when the customizer is missing), so changing
    * the setting or the toggle always applies immediately.
    */
   private boolean cardsView() {
      if (this.viewOverride != null) {
         return this.viewOverride;
      }
      MenuCustomizer mc = this.customizer();
      return mc == null ? true : "CARDS".equals(mc.style());
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   protected void init() {
      this.revealStartMs = System.currentTimeMillis();
   }

   /* ================================================================ DATA */

   private List<Module> all() {
      return new ArrayList<>(this.blue.moduleManager().getModules());
   }

   private List<Module> visible() {
      List<Module> out = new ArrayList<>();
      String q = this.query.toLowerCase(Locale.ROOT);
      for (Module m : this.all()) {
         if (this.category != null && m.getCategory() != this.category) {
            continue;
         }
         if (!q.isEmpty() && !m.getName().toLowerCase(Locale.ROOT).contains(q)
            && !m.getDescription().toLowerCase(Locale.ROOT).contains(q)) {
            continue;
         }
         out.add(m);
      }
      // v0.16.9: enabled modules sort to the top of every category
      // (v0.16.11: toggleable from the toolbar pill + Client Settings)
      java.util.Comparator<Module> byName =
         java.util.Comparator.comparing(m -> m.getName().toLowerCase(Locale.ROOT));
      if (this.blue.settings().modulesEnabledFirst()) {
         out.sort(java.util.Comparator.comparing(Module::isEnabled).reversed().thenComparing(byName));
      } else {
         out.sort(byName);
      }
      return out;
   }

   private int enabledCount(Category cat) {
      int n = 0;
      for (Module m : this.all()) {
         if ((cat == null || m.getCategory() == cat) && m.isEnabled()) {
            n++;
         }
      }
      return n;
   }

   private boolean animated() {
      try {
         return this.blue.settings().animations();
      } catch (Throwable t) {
         return true;
      }
   }

   /* ---- menu style: driven by the optional "Menu Customizer" module ---- */

   private MenuCustomizer customizer() {
      for (Module m : this.all()) {
         if (m instanceof MenuCustomizer mc) {
            return mc;
         }
      }
      return null;
   }

   private MenuCustomizer activeCustomizer() {
      MenuCustomizer mc = this.customizer();
      return mc != null && mc.isEnabled() ? mc : null;
   }

   /**
    * UI scale of the whole modules menu. The setting is displayed as
    * 90% - 100% (default 90%, feedback 2026-09-11); 100% is the size users
    * know (0.75 of the raw screen resolution), so the real factor is
    * percent * 0.0075.
    */
   private float uiScale() {
      MenuCustomizer mc = this.activeCustomizer();
      int pct = mc != null ? Math.max(90, Math.min(100, mc.scalePercent())) : MenuCustomizer.DEFAULT_SCALE;
      return pct * 0.0075F;
   }

   private float roundness() {
      MenuCustomizer mc = this.activeCustomizer();
      int r = mc != null ? Math.max(0, Math.min(24, mc.roundnessValue())) : MenuCustomizer.DEFAULT_ROUNDNESS;
      return r;
   }

   private int bodyOpacity() {
      MenuCustomizer mc = this.activeCustomizer();
      int o = mc != null ? Math.max(0, Math.min(100, mc.opacityPercent())) : MenuCustomizer.DEFAULT_OPACITY;
      return o;
   }

   private int dimStrength() {
      MenuCustomizer mc = this.activeCustomizer();
      int d = mc != null ? Math.max(0, Math.min(100, mc.dimPercent())) : MenuCustomizer.DEFAULT_DIM;
      return d;
   }

   private boolean menuShadow() {
      MenuCustomizer mc = this.activeCustomizer();
      return mc == null || mc.shadowEnabled();
   }

   private int menuIconColor() {
      MenuCustomizer mc = this.activeCustomizer();
      return mc != null ? mc.iconArgb(System.currentTimeMillis()) : 0xFF000000 | MenuCustomizer.DEFAULT_ICON_COLOR;
   }

   private int menuTextColor() {
      MenuCustomizer mc = this.activeCustomizer();
      return mc != null ? mc.textArgb(System.currentTimeMillis()) : 0xFF000000 | MenuCustomizer.DEFAULT_TEXT_COLOR;
   }

   private int cardFill(int baseArgb) {
      float pct = this.bodyOpacity() / 100.0F;
      float alpha = 0.15F + 0.85F * pct;
      return withAlpha(baseArgb & 0x00FFFFFF, alpha);
   }

   /* ====================================================== ICON MAPPING */

   private static String categoryIcon(Category cat) {
      if (cat == null) {
         return "layout-grid";
      }
      return switch (cat) {
         case HUD -> "layout-dashboard";
         case COMBAT -> "swords";
         case MOVEMENT -> "footprints";
         case RENDER -> "eye";
         case MISC -> "sliders-horizontal";
      };
   }

   private static String iconFor(Module m) {
      String n = m.getName().toLowerCase(Locale.ROOT);
      if (n.contains("fps")) return "gauge";
      if (n.contains("coord") || n.contains("position")) return "compass";
      if (n.contains("ping") || n.contains("latency")) return "wifi";
      if (n.contains("keystroke")) return "keyboard";
      if (n.contains("armor")) return "shield";
      if (n.contains("sprint") || n.contains("sneak")) return "footprints";
      if (n.contains("direction")) return "compass";
      if (n.contains("speed")) return "zap";
      if (n.contains("clock") || n.contains("time")) return "clock";
      if (n.contains("biome")) return "trees";
      if (n.contains("watermark")) return "droplet";
      if (n.contains("zoom")) return "zoom-in";
      if (n.contains("bright") || n.contains("sun")) return "sun";
      if (n.contains("weather") || n.contains("snow")) return "snowflake";
      if (n.contains("cloud") || n.contains("fog") || n.contains("sky")) return "cloud";
      if (n.contains("music")) return "music";
      if (n.contains("server")) return "server";
      if (n.contains("crosshair")) return "crosshair";
      if (n.contains("target") || n.contains("combo") || n.contains("reach")) return "target";
      if (n.contains("cps") || n.contains("click") || n.contains("attack")) return "mouse-pointer-click";
      if (n.contains("chat") || n.contains("message")) return "message-square";
      if (n.contains("mention")) return "at-sign";
      if (n.contains("screenshot") || n.contains("image")) return "image";
      if (n.contains("hitbox")) return "square";
      if (n.contains("timer") || n.contains("countdown")) return "timer";
      if (n.contains("blur") || n.contains("eye")) return "eye";
      return categoryIcon(m.getCategory());
   }

   private static String keyName(int key) {
      return switch (key) {
         case 32 -> "SPACE";
         case 340 -> "LSHIFT";
         case 341 -> "RSHIFT";
         case 342 -> "ALT";
         default -> {
            String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(key, 0);
            yield name != null ? name.toUpperCase(Locale.ROOT) : ("KEY " + key);
         }
      };
   }

   /* ========================================================== RENDERING */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();

      int dimA = (int) (0.70F * 255.0F * this.dimStrength() / 100.0F);
      context.fill(0, 0, w, h, dimA << 24 | 0x0B0E14);

      // Base menu scale from settings, then an extra fit factor so the panel
      // + margins ALWAYS fit the window (the v4 "cut off border" bug).
      float base = this.uiScale();
      float fit = Math.min(1.0F, Math.min(w / (base * DESIGN_W + 12.0F), h / (base * DESIGN_H + 12.0F)));
      float scale = base * Math.max(0.35F, fit);
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int vmx = (int) (mouseX / scale);
      int vmy = (int) (mouseY / scale);

      float panelW = Math.min(vw - 24, 980);
      float panelH = Math.min(vh - 24, 640);
      float panelX = (vw - panelW) / 2.0F;
      float panelY = (vh - panelH) / 2.0F;
      float radius = this.roundness();

      this.chipHits.clear();
      this.tabHits.clear();
      this.sideHits.clear();
      this.optionHits.clear();
      this.toggleHits.clear();
      this.gearHits.clear();
      this.bodyHits.clear();

      if (this.menuShadow()) {
         PremiumRender.drawShadow(context, (int) panelX - 2, (int) panelY - 2, (int) panelW + 4, (int) panelH + 4, 0x77000000, 14);
      }

      float bodyAlpha = Math.min(1.0F, 0.35F + 0.65F * (this.bodyOpacity() / 100.0F));
      SmoothRect.fill(context, panelX, panelY, panelW, panelH, radius, withAlpha(DesignTokens.panelBg() & 0x00FFFFFF, bodyAlpha));

      this.drawTopBar(context, panelX, panelY, panelW, vmx, vmy);
      this.drawSidebar(context, panelX, panelY, panelH, vmx, vmy);

      float contentX = panelX + SIDEBAR_W;
      float contentW = panelW - SIDEBAR_W;
      this.drawToolbar(context, contentX, contentW, panelY + TOP_BAR_H, vmx, vmy);

      float listX = contentX + PAD;
      float listW = contentW - PAD * 2 - 6;
      float top = panelY + TOP_BAR_H + TOOLBAR_H + 6;
      float bottom = panelY + panelH - PAD;
      this.drawModules(context, listX, listW, top, bottom, scale, vmx, vmy);

      // Border LAST and never scissored: the box outline is always complete.
      int borderBase = DesignTokens.panelBorder();
      float borderAlpha = Math.max(0.55F, ((borderBase >>> 24) & 0xFF) / 255.0F);
      SmoothRect.outline(context, panelX, panelY, panelW, panelH, radius, 1.5F, withAlpha(borderBase & 0xFFFFFF, borderAlpha));

      context.getMatrices().popMatrix();

      if (this.animated()) {
         this.smoothScroll += (this.targetScroll - this.smoothScroll) * Math.min(1.0F, delta * 14.0F);
         if (Math.abs(this.targetScroll - this.smoothScroll) < 0.25F) {
            this.smoothScroll = this.targetScroll;
         }
      } else {
         this.smoothScroll = this.targetScroll;
      }
      // Custom immediate-mode screen: super.render() is never called, so draw
      // toasts here (the ScreenMixin hook only fires for vanilla render paths).
      if (this.client != null && this.client.player == null) {
         BlueClient.getInstance().notificationManager().render(context);
      }
   }

   /* ---------------------------------------------------------- top bar */

   private void drawTopBar(DrawContext context, float px, float py, float pw, int mx, int my) {
      SmoothRect.fill(context, px + 1, py + 1, pw - 2, TOP_BAR_H - 1, Math.max(0.0F, this.roundness() - 1.0F), this.cardFill(0x80141A26));
      SmoothRect.fill(context, px + 1, py + TOP_BAR_H - 1, pw - 2, 1, 0.5F, 0x22FFFFFF);

      RenderUtil.drawLogo(context, (int) (px + 10), (int) (py + 8), 18);
      TextPainter.drawPoppins(context, "BLUE CLIENT", px + 10 + RenderUtil.logoWidth(18) + 8, py + 11, DesignTokens.textHi(), 11.0F);

      // centre tabs
      String[] tabs = new String[]{"MODS", "SETTINGS", "HUD", "ACCOUNTS"};
      float tabW = 62;
      float total = tabs.length * tabW + (tabs.length - 1) * 6;
      float tx = px + pw / 2 - total / 2;
      for (int i = 0; i < tabs.length; i++) {
         float x = tx + i * (tabW + 6);
         boolean active = i == 0;
         boolean hovered = mx >= x && mx < x + tabW && my >= py + 7 && my < py + 7 + 20;
         SmoothRect.fill(context, x, py + 7, tabW, 20, 5.0F,
            active ? withAlpha(DesignTokens.accent(), 0.22F) : hovered ? 0x1FFFFFFF : 0x0DFFFFFF);
         if (active) {
            SmoothRect.outline(context, x, py + 7, tabW, 20, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.6F));
         }
         TextPainter.drawPoppins(context, tabs[i], x + tabW / 2 - TextPainter.poppinsWidth(tabs[i], 8.5F) / 2.0F,
            py + 12, active ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);
         if (!active) {
            this.tabHits.add(new RectHit(x, py + 7, tabW, 20, i));
         }
      }

      // close button
      float cx = px + pw - 30;
      this.closeBtn = new Rect(cx, py + 7, 22, 20);
      boolean closeHover = this.closeBtn.contains(mx, my);
      SmoothRect.fill(context, cx, py + 7, 22, 20, 5.0F, closeHover ? 0x33FF5C5C : 0x14FFFFFF);
      RenderUtil.drawIcon(context, "x", (int) (cx + 6), (int) (py + 11), 10, closeHover ? 0xFFFF8A8A : DesignTokens.textMid());
   }

   /* ---------------------------------------------------------- sidebar */

   private void drawSidebar(DrawContext context, float px, float py, float ph, int mx, int my) {
      float x = px + 1;
      float y = py + TOP_BAR_H;
      float w = SIDEBAR_W - 1;
      float h = ph - TOP_BAR_H - 1;
      SmoothRect.fill(context, x, y, w, h, Math.max(0.0F, this.roundness() - 1.0F), this.cardFill(0x66141A26));
      SmoothRect.fill(context, x + w - 1, y + 6, 1, h - 12, 0.5F, 0x22FFFFFF);

      float ey = y + 10;
      TextPainter.drawPoppins(context, "FILTER", x + 10, ey, DesignTokens.textMid(), 7.5F);
      ey += 13;

      List<Category> order = new ArrayList<>();
      order.add(null);
      for (Category c : Category.values()) {
         order.add(c);
      }
      for (Category c : order) {
         boolean active = this.category == c;
         boolean hovered = mx >= x + 6 && mx < x + w - 6 && my >= ey && my < ey + 22;
         if (active) {
            SmoothRect.fill(context, x + 6, ey, w - 12, 22, 5.0F, DesignTokens.accentSoft());
            SmoothRect.outline(context, x + 6, ey, w - 12, 22, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.55F));
         } else if (hovered) {
            SmoothRect.fill(context, x + 6, ey, w - 12, 22, 5.0F, 0x14FFFFFF);
         }
         String icon = categoryIcon(c);
         RenderUtil.drawIcon(context, icon, (int) (x + 12), (int) (ey + 5), 12,
            active ? DesignTokens.accent() : DesignTokens.textMid());
         String label = c == null ? "All Modules" : c.displayName();
         TextPainter.drawPoppins(context, label, x + 30, ey + 7,
            active ? DesignTokens.textHi() : DesignTokens.textMid(), 9.0F);
         int on = this.enabledCount(c);
         if (on > 0) {
            String badge = String.valueOf(on);
            float bw = TextPainter.poppinsWidth(badge, 7.5F) + 8;
            SmoothRect.fill(context, x + w - 12 - bw, ey + 6, bw, 11, 5.5F,
               active ? withAlpha(DesignTokens.accent(), 0.85F) : 0x26FFFFFF);
            TextPainter.drawPoppins(context, badge, x + w - 12 - bw + 4, ey + 7.5F,
               active ? 0xFFFFFFFF : DesignTokens.textHi(), 7.5F);
         }
         this.chipHits.add(new RectHit(x + 6, ey, w - 12, 22, c == null ? -1 : c.ordinal()));
         ey += 26;
      }

      float bottomY = py + ph - 78;
      this.hudBtn = new Rect(x + 8, bottomY, w - 16, 24);
      boolean hudHover = this.hudBtn.contains(mx, my);
      SmoothRect.fill(context, this.hudBtn.x, this.hudBtn.y, this.hudBtn.w, this.hudBtn.h, 5.0F,
         hudHover ? 0x22FFFFFF : this.cardFill(0x11FFFFFF));
      RenderUtil.drawIcon(context, "move", (int) (this.hudBtn.x + 8), (int) (this.hudBtn.y + 6), 12,
         hudHover ? DesignTokens.textHi() : DesignTokens.textMid());
      TextPainter.drawPoppins(context, "EDIT HUD", this.hudBtn.x + 26, this.hudBtn.y + 8,
         hudHover ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);

      this.saveBtn = new Rect(x + 8, bottomY + 28, w - 16, 24);
      boolean saveHover = this.saveBtn.contains(mx, my);
      SmoothRect.fill(context, this.saveBtn.x, this.saveBtn.y, this.saveBtn.w, this.saveBtn.h, 5.0F,
         saveHover ? 0x22FFFFFF : this.cardFill(0x11FFFFFF));
      RenderUtil.drawIcon(context, "download", (int) (this.saveBtn.x + 8), (int) (this.saveBtn.y + 6), 12,
         saveHover ? DesignTokens.textHi() : DesignTokens.textMid());
      TextPainter.drawPoppins(context, "SAVE", this.saveBtn.x + 26, this.saveBtn.y + 8,
         saveHover ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);

      TextPainter.drawPoppins(context, "v" + BlueClient.MOD_VERSION, x + 10, py + ph - 18, 0x66FFFFFF, 7.0F);
   }

   /* ---------------------------------------------------------- toolbar */

   private void drawToolbar(DrawContext context, float cx, float cw, float ty, int mx, int my) {
      float x = cx + PAD;
      float w = cw - PAD * 2;

      // stat chip
      int total = this.all().size();
      int on = this.enabledCount(null);
      String stat = on + " / " + total + " ON";
      float statW = TextPainter.poppinsWidth(stat, 8.5F) + 14;
      SmoothRect.fill(context, x, ty + 5, statW, 18, 5.0F, this.cardFill(0x14FFFFFF));
      SmoothRect.outline(context, x, ty + 5, statW, 18, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.35F));
      TextPainter.drawPoppins(context, stat, x + 7, ty + 10, DesignTokens.textHi(), 8.5F);

      // view toggle: grid / list
      float toggleX = x + w - SEARCH_W - 8 - 52;
      // v0.16.11: enabled-first sorting pill
      this.sortBtn = new Rect(toggleX - 32, ty + 4, 24, 20);
      boolean enabledFirst = this.blue.settings().modulesEnabledFirst();
      boolean sortHover = this.sortBtn.contains(mx, my);
      SmoothRect.fill(context, this.sortBtn.x, this.sortBtn.y, 24, 20, 5.0F,
         enabledFirst ? withAlpha(DesignTokens.accent(), 0.25F) : sortHover ? 0x1FFFFFFF : 0x0DFFFFFF);
      if (enabledFirst) {
         SmoothRect.outline(context, this.sortBtn.x, this.sortBtn.y, 24, 20, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.55F));
      }
      RenderUtil.drawIcon(context, "zap", (int) (this.sortBtn.x + 6), (int) (ty + 9), 11,
         enabledFirst ? DesignTokens.accent() : DesignTokens.textMid());
      boolean cards = this.cardsView();
      this.gridBtn = new Rect(toggleX, ty + 4, 24, 20);
      this.listBtn = new Rect(toggleX + 28, ty + 4, 24, 20);
      boolean gridHover = this.gridBtn.contains(mx, my);
      boolean listHover = this.listBtn.contains(mx, my);
      SmoothRect.fill(context, this.gridBtn.x, this.gridBtn.y, 24, 20, 5.0F,
         cards ? withAlpha(DesignTokens.accent(), 0.25F) : gridHover ? 0x1FFFFFFF : 0x0DFFFFFF);
      SmoothRect.fill(context, this.listBtn.x, this.listBtn.y, 24, 20, 5.0F,
         !cards ? withAlpha(DesignTokens.accent(), 0.25F) : listHover ? 0x1FFFFFFF : 0x0DFFFFFF);
      RenderUtil.drawIcon(context, "layout-grid", (int) (this.gridBtn.x + 6), (int) (ty + 9), 11,
         cards ? DesignTokens.accent() : DesignTokens.textMid());
      RenderUtil.drawIcon(context, "list-music", (int) (this.listBtn.x + 6), (int) (ty + 9), 11,
         !cards ? DesignTokens.accent() : DesignTokens.textMid());

      // search
      float sx = x + w - SEARCH_W;
      this.searchBox = new Rect(sx, ty + 4, SEARCH_W, SEARCH_H);
      boolean hovered = this.searchBox.contains(mx, my);
      boolean focused = this.searchFocused;
      SmoothRect.fill(context, sx, ty + 4, SEARCH_W, SEARCH_H, 6.0F, this.cardFill(0x99101520));
      SmoothRect.outline(context, sx, ty + 4, SEARCH_W, SEARCH_H, 6.0F, 1.0F,
         focused ? withAlpha(DesignTokens.accent(), 0.9F) : hovered ? 0x3DFFFFFF : 0x22FFFFFF);
      RenderUtil.drawIcon(context, "search", (int) sx + 7, (int) (ty + 9), 10,
         focused || !this.query.isEmpty() ? DesignTokens.accent() : DesignTokens.textMid());
      if (this.query.isEmpty()) {
         TextPainter.drawPoppins(context, "Search...", sx + 22, ty + 9.5F, DesignTokens.textMid(), 9.0F);
      } else {
         String shown = fitTextPoppins(this.query, (int) (SEARCH_W - 28), 9.0F);
         TextPainter.drawPoppins(context, shown, sx + 22, ty + 9.5F, DesignTokens.textHi(), 9.0F);
      }
      if (focused && (System.currentTimeMillis() / 500) % 2 == 0) {
         float textW = this.query.isEmpty() ? 0 : TextPainter.poppinsWidth(this.query, 9.0F);
         SmoothRect.fill(context, sx + 23 + Math.min(textW, SEARCH_W - 30), ty + 8, 1, 12, 0.5F, DesignTokens.accent());
      }
   }

   /* ---------------------------------------------------------- modules */

   private void drawModules(DrawContext context, float x, float w, float top, float bottom, float sc, int mx, int my) {
      this.listTop = top;
      this.listBottom = bottom;
      List<Module> modules = this.visible();

      int cols;
      float itemW;
      int itemH;
      if (this.cardsView()) {
         cols = Math.max(1, Math.min(4, (int) Math.floor((w + GAP) / (float) CARD_MIN_W)));
         itemW = (w - (cols - 1) * GAP) / cols;
         itemH = CARD_H;
      } else {
         cols = Math.max(1, Math.min(4, (int) Math.floor((w + GAP) / (float) LIST_MIN_W)));
         itemW = (w - (cols - 1) * GAP) / cols;
         itemH = LIST_H;
      }
      int rows = (modules.size() + cols - 1) / cols;
      int step = itemH + GAP;
      float viewH = bottom - top;
      // Only whole rows are ever shown: snap the scroll to the row grid and
      // clip at a row boundary, so no card/row is ever drawn half-cut.
      int visibleRows = Math.max(1, (int) Math.floor((viewH + GAP) / (float) step));
      float maxScroll = Math.max(0, (rows - visibleRows) * step);
      this.targetScroll = Math.max(0, Math.min(this.targetScroll, maxScroll));
      float snapped = Math.round(this.targetScroll / (float) step) * step;
      this.targetScroll = Math.max(0, Math.min(snapped, maxScroll));
      float contentHeight = rows * step;
      float clipBottom = Math.min(bottom, top + visibleRows * step - GAP);

      if (modules.isEmpty()) {
         this.drawEmptyState(context, x, w, top, bottom);
         return;
      }

      // Scissor EXACTLY the scrollable area (whole rows only) - nothing
      // paints over chrome and nothing is ever clipped mid-card.
      // NOTE: enableScissor transforms by the current matrix itself, so the
      // virtual coordinates go in untouched (pre-scaling them double-scales
      // the clip and cuts the right side off - the old "cut off" bug).
      context.enableScissor((int) Math.floor(x - 2), (int) Math.floor(top),
         (int) Math.ceil(x + w + 8), (int) Math.ceil(clipBottom + 2));

      long now = System.currentTimeMillis();
      for (int i = 0; i < modules.size(); i++) {
         Module m = modules.get(i);
         int col = i % cols;
         int rowIdx = i / cols;
         float itemX = x + col * (itemW + GAP);
         float baseY = top - this.smoothScroll + rowIdx * (itemH + GAP);
         if (baseY + itemH < top || baseY > bottom) {
            continue;
         }

         float reveal = 1.0F;
         float revealOffY = 0;
         if (this.animated()) {
            long sinceOpen = now - this.revealStartMs;
            long itemDelay = 40 + (long) (i * 10.0F);
            if (sinceOpen < itemDelay) {
               reveal = 0;
            } else {
               float t = Math.min(1.0F, (sinceOpen - itemDelay) / 200.0F);
               reveal = Easing.EASE_OUT_CUBIC.apply(t);
               revealOffY = (1.0F - reveal) * 6.0F;
            }
         }
         if (reveal <= 0) {
            continue;
         }

         if (this.cardsView()) {
            this.drawCard(context, m, itemX, baseY + revealOffY, itemW, mx, my);
         } else {
            this.drawRow(context, m, itemX, baseY + revealOffY, itemW, mx, my);
         }
      }

      context.disableScissor();

      if (contentHeight > viewH) {
         float thumbH = Math.max(24, viewH * (viewH / contentHeight));
         float thumbY = top + (this.smoothScroll / maxScroll) * (viewH - thumbH);
         SmoothRect.fill(context, x + w + 3, top, 3, viewH, 1.5F, draggingThumb ? 0x33FFFFFF : 0x14FFFFFF);
         SmoothRect.fill(context, x + w + 3, thumbY, 3, thumbH, 1.5F, withAlpha(DesignTokens.accent(), draggingThumb ? 1.0F : 0.75F));
         // remember the thumb geometry so the mouse handlers can drag it
         this.thumbX = x + w + 3;
         this.trackTop = top;
         this.trackH = viewH;
         this.thumbHf = thumbH;
         this.scrollMaxF = maxScroll;
      } else {
         this.thumbX = Float.MIN_VALUE;
      }
   }

   /** Lunar-style card: centred icon + name, OPTIONS bar, ENABLED bar. */
   private void drawCard(DrawContext context, Module m, float x, float y, float w, int mx, int my) {
      boolean enabled = m.isEnabled();
      boolean hovered = mx >= x && mx < x + w && my >= y && my < y + CARD_H;

      SmoothRect.fill(context, x, y, w, CARD_H, 6.0F, this.cardFill(hovered ? 0xE6151B29 : 0xB3121724));
      SmoothRect.outline(context, x, y, w, CARD_H, 6.0F, 1.0F,
         enabled ? withAlpha(DesignTokens.accent(), 0.35F) : hovered ? 0x26FFFFFF : 0x14FFFFFF);

      RenderUtil.drawIcon(context, iconFor(m), (int) (x + w / 2 - 13), (int) (y + 12), 26,
         enabled ? this.menuIconColor() : withAlpha(this.menuIconColor() & 0xFFFFFF, 0.55F));

      String name = fitTextPoppins(m.getName(), (int) (w - 14), 10.5F);
      TextPainter.drawPoppins(context, name, x + w / 2 - TextPainter.poppinsWidth(name, 10.5F) / 2.0F, y + 46,
         enabled ? this.menuTextColor() : withAlpha(this.menuTextColor() & 0xFFFFFF, 0.6F), 10.5F);

      boolean hasSettings = !visibleSettings(m).isEmpty();

      // OPTIONS bar
      float optY = y + 64;
      SmoothRect.fill(context, x + 8, optY, w - 16, 17, 4.0F, 0xCC1B2230);
      SmoothRect.outline(context, x + 8, optY, w - 16, 17, 4.0F, 1.0F, 0x33FFFFFF);
      String optLabel = "OPTIONS";
      TextPainter.drawPoppins(context, optLabel, x + w / 2 - TextPainter.poppinsWidth(optLabel, 7.5F) / 2.0F - 5,
         optY + 5, hasSettings ? DesignTokens.textHi() : DesignTokens.textMid(), 7.5F);
      RenderUtil.drawIcon(context, "settings", (int) (x + w - 8 - 15), (int) (optY + 3), 11,
         hasSettings ? DesignTokens.textMid() : 0x55FFFFFF);
      if (hasSettings) {
         this.optionHits.add(new ModuleHit(m, x + 8, optY, w - 16, 17));
      }

      // ENABLED / DISABLED bar
      float togY = y + 86;
      boolean togHover = mx >= x + 8 && mx < x + w - 8 && my >= togY && my < togY + 17;
      int fillColor = enabled ? GREEN : CRIMSON;
      if (togHover) {
         fillColor = enabled ? 0xFF46CE6C : 0xFFDF5573;
      }
      SmoothRect.fill(context, x + 8, togY, w - 16, 17, 4.0F, fillColor);
      String state = enabled ? "ENABLED" : "DISABLED";
      TextPainter.drawPoppins(context, state, x + w / 2 - TextPainter.poppinsWidth(state, 7.5F) / 2.0F,
         togY + 5, 0xFFFFFFFF, 7.5F);
      this.toggleHits.add(new ModuleHit(m, x + 8, togY, w - 16, 17));

      int bind = m.getKeybind();
      if (bind > 0) {
         String label = keyName(bind);
         float kw = TextPainter.poppinsWidth(label, 6.5F) + 8;
         SmoothRect.fill(context, x + w - 8 - kw, y + 8, kw, 11, 3.5F, 0x26FFFFFF);
         TextPainter.drawPoppins(context, label, x + w - 8 - kw + 4, y + 9.5F, DesignTokens.textMid(), 6.5F);
      }

      this.bodyHits.add(new ModuleHit(m, x, y, w, CARD_H));
   }

   /** Compact bordered row grid (green = on, crimson = off) + gear box. */
   private void drawRow(DrawContext context, Module m, float x, float y, float w, int mx, int my) {
      boolean enabled = m.isEnabled();
      boolean hasSettings = !visibleSettings(m).isEmpty();
      float gearW = hasSettings ? 24 : 0;
      float rowW = w - gearW - (hasSettings ? 4 : 0);

      boolean hovered = mx >= x && mx < x + w && my >= y && my < y + LIST_H;
      int border = enabled ? GREEN_DIM : CRIMSON_DIM;
      if (hovered) {
         border = enabled ? GREEN : CRIMSON;
      }
      SmoothRect.fill(context, x, y, rowW, LIST_H, 5.0F, this.cardFill(hovered ? 0xE6151B29 : 0xB3121724));
      SmoothRect.outline(context, x, y, rowW, LIST_H, 5.0F, 1.0F, border);

      RenderUtil.drawIcon(context, iconFor(m), (int) (x + 6), (int) (y + 6), 12,
         enabled ? this.menuIconColor() : withAlpha(this.menuIconColor() & 0xFFFFFF, 0.55F));
      String name = fitTextPoppins(m.getName(), (int) (rowW - 26), 8.5F);
      TextPainter.drawPoppins(context, name, x + 22, y + 7.5F,
         enabled ? this.menuTextColor() : withAlpha(this.menuTextColor() & 0xFFFFFF, 0.6F), 8.5F);
      this.toggleHits.add(new ModuleHit(m, x, y, rowW, LIST_H));

      if (hasSettings) {
         float gx = x + rowW + 4;
         boolean gearHover = mx >= gx && mx < gx + gearW && my >= y && my < y + LIST_H;
         SmoothRect.fill(context, gx, y, gearW, LIST_H, 5.0F, this.cardFill(gearHover ? 0xE61B2230 : 0xB3161C29));
         SmoothRect.outline(context, gx, y, gearW, LIST_H, 5.0F, 1.0F, gearHover ? withAlpha(DesignTokens.accent(), 0.7F) : border);
         RenderUtil.drawIcon(context, "settings", (int) (gx + gearW / 2 - 6), (int) (y + 6), 12,
            gearHover ? DesignTokens.accent() : DesignTokens.textMid());
         this.gearHits.add(new ModuleHit(m, gx, y, gearW, LIST_H));
      }
   }

   private void drawEmptyState(DrawContext context, float x, float w, float top, float bottom) {
      float cx = x + w / 2;
      float cy = (top + bottom) / 2 - 20;
      RenderUtil.drawIcon(context, "search", (int) cx - 14, (int) cy, 28, withAlpha(DesignTokens.textMid(), 0.45F));
      String msg = this.query.isEmpty() ? "Nothing here yet" : "No modules match";
      TextPainter.drawPoppins(context, msg, cx - TextPainter.poppinsWidth(msg, 12.0F) / 2, cy + 40, DesignTokens.textHi(), 12.0F);
      String sub = this.query.isEmpty() ? "Check another category" : "Try a different search";
      RenderUtil.drawText(context, sub, (int) (cx - RenderUtil.textWidth(sub) / 2), (int) cy + 54, DesignTokens.textMid());
   }

   /* ============================================================= HELPERS */

   private static List<Setting<?>> visibleSettings(Module m) {
      List<Setting<?>> out = new ArrayList<>();
      for (Setting<?> s : m.getSettings()) {
         try {
            if (s.isVisible()) {
               out.add(s);
            }
         } catch (Throwable t) {
            out.add(s);
         }
      }
      return out;
   }

   private static String fitTextPoppins(String text, int maxWidth, float size) {
      String t = text == null ? "" : text;
      while (TextPainter.poppinsWidth(t, size) > maxWidth && t.length() > 2) {
         t = t.substring(0, t.length() - 1);
      }
      return t.equals(text == null ? "" : text) ? t : t + "...";
   }

   private static String fitText(String text, int maxWidth) {
      if (text == null || text.isEmpty()) {
         return "";
      }
      String t = text;
      while (RenderUtil.textWidth(t) > maxWidth && t.length() > 2) {
         t = t.substring(0, t.length() - 1);
      }
      return t.equals(text) ? t : t + "...";
   }

   private static int withAlpha(int color, float alpha) {
      int a = (int) (alpha * 255.0F) & 0xFF;
      return (a << 24) | (color & 0x00FFFFFF);
   }

   /* ============================================================== INPUT */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      float s = this.drawScale;
      int mx = (int) (click.x() / s);
      int my = (int) (click.y() / s);

      // v0.16.12: the scrollbar is draggable - grab the thumb, or jump to a
      // position when the track itself is clicked.
      if (this.thumbX != Float.MIN_VALUE && this.scrollMaxF > 0
         && mx >= this.thumbX - 4 && mx <= this.thumbX + 7
         && my >= this.trackTop && my <= this.trackTop + this.trackH) {
         float thumbY = this.trackTop + (this.smoothScroll / this.scrollMaxF) * (this.trackH - this.thumbHf);
         if (my >= thumbY && my <= thumbY + this.thumbHf) {
            this.thumbGrabOff = my - thumbY;
         } else {
            this.thumbGrabOff = this.thumbHf / 2.0F;
            this.targetScroll = Math.max(0, Math.min(
               (my - this.trackTop - this.thumbGrabOff) / Math.max(1, this.trackH - this.thumbHf) * this.scrollMaxF, this.scrollMaxF));
         }
         this.draggingThumb = true;
         RenderUtil.clickSound();
         return true;
      }

      if (this.closeBtn != null && this.closeBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.close();
         return true;
      }
      for (RectHit tab : this.tabHits) {
         if (tab.contains(mx, my)) {
            RenderUtil.clickSound();
            switch (tab.index()) {
               case 1 -> this.client.setScreen(new ClientSettingsScreen(this));
               case 2 -> this.client.setScreen(new HudEditScreen(this.blue, this));
               case 3 -> this.client.setScreen(new AccountsScreen(this));
               default -> {
               }
            }
            return true;
         }
      }
      if (this.hudBtn != null && this.hudBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.client.setScreen(new HudEditScreen(this.blue, this));
         return true;
      }
      if (this.saveBtn != null && this.saveBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         try {
            this.blue.configManager().save();
            this.blue.notificationManager().add("Config saved", -13673473);
         } catch (Throwable t) {
            this.blue.notificationManager().add("Couldn't save config", 0xFFFF5C5C);
         }
         return true;
      }
      for (RectHit chip : this.chipHits) {
         if (chip.contains(mx, my)) {
            this.category = chip.index() < 0 ? null : Category.values()[chip.index()];
            this.revealStartMs = System.currentTimeMillis();
            this.targetScroll = 0;
            this.smoothScroll = 0;
            RenderUtil.clickSound();
            return true;
         }
      }
      if (this.sortBtn != null && this.sortBtn.contains(mx, my)) {
         boolean now = !this.blue.settings().modulesEnabledFirst();
         this.blue.settings().modulesEnabledFirst(now);
         RenderUtil.clickSound();
         return true;
      }
      if (this.gridBtn != null && this.gridBtn.contains(mx, my) && !this.cardsView()) {
         this.setView(true);
         return true;
      }
      if (this.listBtn != null && this.listBtn.contains(mx, my) && this.cardsView()) {
         this.setView(false);
         return true;
      }
      if (this.searchBox != null && this.searchBox.contains(mx, my)) {
         this.searchFocused = true;
         return true;
      }
      this.searchFocused = false;

      for (ModuleHit hit : this.optionHits) {
         if (hit.contains(mx, my)) {
            RenderUtil.clickSound();
            this.client.setScreen(new ModuleSettingsScreen(this.blue, this, hit.module()));
            return true;
         }
      }
      for (ModuleHit hit : this.gearHits) {
         if (hit.contains(mx, my)) {
            RenderUtil.clickSound();
            this.client.setScreen(new ModuleSettingsScreen(this.blue, this, hit.module()));
            return true;
         }
      }
      for (ModuleHit hit : this.toggleHits) {
         if (hit.contains(mx, my)) {
            this.toggleAnim.put(hit.module().getName(), System.currentTimeMillis());
            hit.module().toggle();
            RenderUtil.clickSound();
            return true;
         }
      }
      for (ModuleHit hit : this.bodyHits) {
         if (hit.contains(mx, my)) {
            Module m = hit.module();
            if (!visibleSettings(m).isEmpty()) {
               RenderUtil.clickSound();
               this.client.setScreen(new ModuleSettingsScreen(this.blue, this, m));
            } else {
               this.toggleAnim.put(m.getName(), System.currentTimeMillis());
               m.toggle();
               RenderUtil.clickSound();
            }
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   private void setView(boolean cards) {
      this.viewOverride = cards;
      this.targetScroll = 0;
      this.smoothScroll = 0;
      RenderUtil.clickSound();
      MenuCustomizer mc = this.customizer();
      if (mc != null) {
         for (Setting<?> setting : mc.getSettings()) {
            if (setting.getName().equals("Menu Style") && setting instanceof net.bluenetwork.client.setting.ModeSetting mode) {
               mode.set(cards ? "CARDS" : "LIST");
            }
         }
      }
   }

   @Override
   public boolean mouseDragged(Click click, double dx, double dy) {
      if (this.draggingThumb && this.scrollMaxF > 0) {
         float s = this.drawScale;
         float my = (float) (click.y() / s);
         this.targetScroll = Math.max(0, Math.min(
            (my - this.trackTop - this.thumbGrabOff) / Math.max(1, this.trackH - this.thumbHf) * this.scrollMaxF, this.scrollMaxF));
         return true;
      }
      return super.mouseDragged(click, dx, dy);
   }

   @Override
   public boolean mouseReleased(Click click) {
      this.draggingThumb = false;
      return super.mouseReleased(click);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
      float s = this.drawScale;
      if (my / s >= this.listTop && my / s <= this.listBottom) {
         this.targetScroll -= (float) vAmount * 40.0F;
         return true;
      }
      return super.mouseScrolled(mx, my, hAmount, vAmount);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (key == 259) {
         if (!this.query.isEmpty()) {
            this.query = this.query.substring(0, this.query.length() - 1);
            this.targetScroll = 0;
         }
         return true;
      }
      if (key == 256) {
         if (!this.query.isEmpty()) {
            this.query = "";
            this.targetScroll = 0;
            this.searchFocused = false;
            return true;
         }
         this.close();
         return true;
      }
      if (key == 264 || key == 265) {
         this.targetScroll += key == 264 ? 40 : -40;
         return true;
      }
      if (key == 266 || key == 267) {
         this.targetScroll += key == 266 ? 160 : -160;
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (input.isValidChar()) {
         char ch = (char) input.codepoint();
         if (ch >= 32 && ch < 127) {
            this.query += ch;
            this.targetScroll = 0;
            this.revealStartMs = System.currentTimeMillis();
            return true;
         }
      }
      return super.charTyped(input);
   }

   @Override
   public void removed() {
      try {
         this.blue.configManager().save();
      } catch (Throwable ignored) {
      }
      super.removed();
   }

   @Override
   public void close() {
      if (this.parent != null) {
         this.client.setScreen(this.parent);
      } else {
         super.close();
      }
   }

   /* ========================================================= HIT RECORDS */

   private static final class Rect {
      final float x, y, w, h;

      Rect(float x, float y, float w, float h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }

   private record RectHit(float x, float y, float w, float h, int index) {
      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }

   private record ModuleHit(Module module, float x, float y, float w, float h) {
      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
