package net.bluenetwork.client.gui;

import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;

/**
 * Shared state for the two square glass buttons drawn top-right of the
 * VANILLA pause menu (Blue Client switch + Client Settings shortcut).
 * Kept out of the mixin itself because sponge-mixin requires every member
 * of a mixin class to be private.
 */
public final class PauseSquares {
   /** Side length of each square. */
   public static final int SQUARE = 20;

   private static int switchX;
   private static int switchY;
   private static int settingsX;
   private static int settingsY;

   private PauseSquares() {
   }

   /** Recomputes the square bounds for the given GameMenuScreen. */
   public static void position(Screen self) {
      switchX = self.width - SQUARE * 2 - 8 - 4;
      switchY = 8;
      settingsX = self.width - SQUARE - 8;
      settingsY = 8;
   }

   /** Side length of the pause-menu squares, read by ScreenMixin. */
   public static int squareSize() {
      return SQUARE;
   }

   /** Bounds of the two squares for the ScreenMixin skin pass: {switchX, switchY, settingsX, settingsY}. */
   public static int[] squareBounds() {
      return new int[]{switchX, switchY, settingsX, settingsY};
   }

   /** True when the vanilla pause menu is up and our squares should render. */
   public static boolean squaresVisible() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return !BlueClient.getInstance().settings().customPauseMenu()
         && mc.currentScreen instanceof GameMenuScreen;
   }
}
