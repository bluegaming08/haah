package net.bluenetwork.client.module.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.ModuleActions;
import net.bluenetwork.client.music.LyricsProvider;
import net.bluenetwork.client.music.MusicEngine;
import net.bluenetwork.client.music.TrackResolver;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.setting.StringSetting;
import net.bluenetwork.client.ui.text.TextPainter;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Music Player v3 (feedback 2026-09-11: "the music player module isn't
 * working, make it support youtube, Spotify and other website links").
 *
 * <p>What's new over v2:</p>
 * <ul>
 *   <li><b>YouTube</b> links (watch / youtu.be / shorts / music) are resolved
 *       to a playable AAC stream through public Piped / Invidious instances
 *       and decoded in-client (bundled pure-Java AAC decoder).</li>
 *   <li><b>Spotify</b> links pull the track name & artist from Spotify's
 *       public oEmbed and play the matching upload (Spotify audio itself is
 *       DRM-locked, so no client can stream it directly).</li>
 *   <li><b>Any other website link</b> plays when it points at an audio file
 *       (mp3 / ogg / wav / m4a / aac), sniffed by extension or Content-Type.</li>
 *   <li><b>Track info HUD</b> (on by default): track name plus elapsed and
 *       total time with a progress bar.</li>
 *   <li><b>Lyrics HUD</b> with three effects: FADING, POP_OUT and
 *       POP_OUT_AND_FADE (timed lyrics from LRCLIB).</li>
 * </ul>
 */
public class MusicPlayer extends HudModule implements ModuleActions {
   private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BlueClient/1.1";
   private static final int CONNECT_TIMEOUT_MS = 12000;
   private static final int READ_TIMEOUT_MS = 15000;
   private static final int MAX_TITLE_PX = 200;

   private final NumberSetting volume = new NumberSetting("Volume", "Playback volume %", 50.0, 0.0, 100.0, 5.0);
   private final BooleanSetting showInfo = new BooleanSetting("Show Track Info", "Draw the track name and time on the HUD", true);
   private final BooleanSetting showLyrics = new BooleanSetting("Show Lyrics", "Draw the current lyric line under the panel", false);
   private final ModeSetting lyricEffect = new ModeSetting("Lyric Effect", "How a new lyric line appears",
      List.of("FADING", "POP_OUT", "POP_OUT_AND_FADE"), "POP_OUT_AND_FADE");

   private volatile TrackResolver.Resolved meta;
   private volatile LyricsProvider.Lyrics lyrics;
   private volatile String status = "";

   public MusicPlayer() {
      super("Music Player", "Play music from YouTube, Spotify or direct links", Category.MISC, 4, 4);
      this.lyricEffect.visibleWhen(this.showLyrics::get);
      this.addSettings(new Setting[]{this.volume, this.showInfo, this.showLyrics, this.lyricEffect});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_LEFT, 4, 60);
      this.volume.onChange(() -> MusicEngine.INSTANCE.setVolume(this.volumePercent()));
      // Enabled by default (feedback 2026-09-11): the HUD simply stays empty
      // until something plays, so this costs nothing.
      songsDir();
      this.setEnabled(true);
   }

   @Override
   public List<String> actionLabels() {
      List<String> labels = new ArrayList<>();
      labels.add("STOP");
      return labels;
   }

   @Override
   public void onAction(int index) {
      // "OPEN MUSIC" action removed (2026-09-12): it crashed the user's game.
      // STOP is the only action now.
      if (index == 0) {
         MusicEngine.INSTANCE.stop();
         this.status = "";
      }
   }

   /* ---------------- local songs folder ---------------- */

   /** The {@code songs/} folder next to your Minecraft directory (created on use). */
   public static Path songsDir() {
      Path dir = FabricLoader.getInstance().getGameDir().resolve("songs");
      try {
         Files.createDirectories(dir);
      } catch (IOException ignored) {
      }
      return dir;
   }

   /** Every playable audio file in {@link #songsDir()}, sorted by name. */
   public static List<Path> listSongs() {
      List<Path> out = new ArrayList<>();
      try (Stream<Path> stream = Files.list(songsDir())) {
         stream.filter(Files::isRegularFile).filter(MusicPlayer::isSong).sorted((a, b) ->
            a.getFileName().toString().compareToIgnoreCase(b.getFileName().toString())).forEach(out::add);
      } catch (IOException ignored) {
      }
      return out;
   }

   private static boolean isSong(Path p) {
      String n = p.getFileName().toString().toLowerCase();
      return n.endsWith(".mp4") || n.endsWith(".m4a") || n.endsWith(".aac")
         || n.endsWith(".mp3") || n.endsWith(".wav") || n.endsWith(".ogg");
   }

   /** Plays a file from the songs folder through the engine. */
   public static void playSongFile(Path file) {
      String name = file.getFileName().toString();
      String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1).toLowerCase() : "";
      String format = switch (ext) {
         case "mp4", "m4a", "aac" -> "m4a";
         case "mp3" -> "mp3";
         case "wav" -> "wav";
         default -> ext;
      };
      float vol = 0.7F;
      for (net.bluenetwork.client.module.Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof MusicPlayer mp) {
            vol = mp.volumePercent();
         }
      }
      BlueClient.LOGGER.info("Playing song {} [format={} volume={}]", name, format, vol);
      BlueClient.getInstance().notificationManager().add("Playing " + name, 0xFF3CB860);
      if (vol <= 0.01F) {
         // A silent "successful" play at volume 0 looks exactly like a dead click.
         BlueClient.getInstance().notificationManager().add("Volume is 0 — raise it with the Volume slider", 0xFFFFB84D);
      }
      MusicEngine.INSTANCE.playFile(file, format, vol, name, err -> {
         BlueClient.LOGGER.error("Song playback failed for {}: {}", name, err);
         BlueClient.getInstance().notificationManager().add("Can't play: " + err, 0xFFFF5C5C);
      });
   }

   private void fetchLyrics(TrackResolver.Resolved resolved) {
      new Thread(() -> {
         try {
            this.lyrics = LyricsProvider.fetch(resolved.title(), resolved.artist(), resolved.durationSec());
         } catch (Throwable ignored) {
            this.lyrics = null;
         }
      }, "Blue Client Lyrics").start();
   }


   /* ---------------- fetching ---------------- */


   private void download(String url, Path target) throws IOException {
      HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
      connection.setRequestProperty("User-Agent", USER_AGENT);
      connection.setInstanceFollowRedirects(true);
      connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
      connection.setReadTimeout(READ_TIMEOUT_MS);
      try (InputStream in = connection.getInputStream(); OutputStream out = Files.newOutputStream(target)) {
         in.transferTo(out);
      } finally {
         connection.disconnect();
      }
   }

   /**
    * Direct-file opener: browser-like User-Agent, follows redirects, format
    * resolved from the final URL extension OR the HTTP Content-Type.
    */

   private static String resolveFormat(String url, String contentType) {
      String lower = url.toLowerCase();
      int query = lower.indexOf('?');
      if (query >= 0) {
         lower = lower.substring(0, query);
      }
      if (lower.endsWith(".mp3")) {
         return "mp3";
      }
      if (lower.endsWith(".ogg") || lower.endsWith(".oga")) {
         return "ogg";
      }
      if (lower.endsWith(".wav")) {
         return "wav";
      }
      if (lower.endsWith(".m4a") || lower.endsWith(".aac")) {
         return "m4a";
      }
      if (contentType != null) {
         String ct = contentType.toLowerCase();
         if (ct.contains("mpeg") || ct.contains("mp3")) {
            return "mp3";
         }
         if (ct.contains("ogg")) {
            return "ogg";
         }
         if (ct.contains("wav") || ct.contains("x-wav")) {
            return "wav";
         }
         if (ct.contains("mp4") || ct.contains("aac")) {
            return "m4a";
         }
      }
      return null;
   }

   private float volumePercent() {
      return Math.max(0.0F, Math.min(1.0F, this.volume.getInt() / 100.0F));
   }

   /* ---------------- naming & cache ---------------- */

   private static String fileName(String url, String format) {
      int slash = url.lastIndexOf('/');
      String name = slash >= 0 ? url.substring(slash + 1) : url;
      int query = name.indexOf('?');
      if (query >= 0) {
         name = name.substring(0, query);
      }
      name = name.replaceAll("[^a-zA-Z0-9 ._\\-()\\[\\]]", "_");
      if (name.isBlank() || name.equals("_")) {
         name = "track";
      }
      if (!name.toLowerCase().endsWith(".mp3") && !name.toLowerCase().endsWith(".ogg")
         && !name.toLowerCase().endsWith(".wav") && !name.toLowerCase().endsWith(".m4a")) {
         name = name + "." + format;
      }
      return name;
   }

   public static Path cacheDir() {
      Path dir = FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("music");
      try {
         Files.createDirectories(dir);
      } catch (Throwable ignored) {
      }
      return dir;
   }

   public static List<Path> cachedFiles() {
      List<Path> files = new ArrayList<>();
      try (Stream<Path> stream = Files.list(cacheDir())) {
         stream.filter(file -> {
            String name = file.getFileName().toString().toLowerCase();
            return name.endsWith(".mp3") || name.endsWith(".ogg") || name.endsWith(".wav") || name.endsWith(".m4a");
         }).sorted().forEach(files::add);
      } catch (Throwable ignored) {
      }
      return files;
   }

   /* ---------------- HUD ---------------- */

   private String titleLine() {
      TrackResolver.Resolved current = this.meta;
      if (MusicEngine.INSTANCE.isPlaying()) {
         String name = MusicEngine.INSTANCE.nowPlaying();
         if (!name.isEmpty()) {
            return name;
         }
      }
      if (current != null) {
         return current.displayTitle();
      }
      return "";
   }

   private String timeLine() {
      long pos = MusicEngine.INSTANCE.positionMs();
      long dur = MusicEngine.INSTANCE.durationMs();
      if (dur > 0) {
         return LyricsProvider.clock(pos) + " / " + LyricsProvider.clock(dur);
      }
      return LyricsProvider.clock(pos);
   }

   @Override
   public void render(DrawContext context) {
      String title = this.titleLine();
      String statusNow = this.status;
      boolean playing = MusicEngine.INSTANCE.isPlaying();
      boolean drawPanel = this.showInfo.get() && (!title.isEmpty() || !statusNow.isEmpty());
      if (!drawPanel && !this.showLyrics.get()) {
         return;
      }

      if (drawPanel) {
         int w = this.getWidthCached();
         int h = this.getHeightCached();
         this.drawPanel(context, w, h);

         int color = this.textColor();
         if (!statusNow.isEmpty()) {
            RenderUtil.drawText(context, fit(statusNow, w - 16), this.x + 8, this.y + 6, color);
            return;
         }

         RenderUtil.drawText(context, fit(title, w - 16), this.x + 8, this.y + 5, color);
         String time = this.timeLine();
         RenderUtil.drawText(context, time, this.x + 8, this.y + 16, (color & 0x00FFFFFF) | 0xB0000000);

         // progress bar along the panel bottom
         long dur = MusicEngine.INSTANCE.durationMs();
         if (dur > 0 && playing) {
            float progress = Math.min(1.0F, MusicEngine.INSTANCE.positionMs() / (float) dur);
            context.fill(this.x + 6, this.y + h - 4, this.x + w - 6, this.y + h - 3, 0x33FFFFFF);
            context.fill(this.x + 6, this.y + h - 4, (int) (this.x + 6 + (w - 12) * progress), this.y + h - 3, 0xFF2FA5FF);
         }
      }

      if (this.showLyrics.get()) {
         float lyricY = drawPanel ? this.y + this.getHeightCached() + 12.0F : this.y;
         this.drawLyrics(context, lyricY);
      }
   }

   /** Current lyric line with the configured appearance effect. */
   private void drawLyrics(DrawContext context, float cy) {
      LyricsProvider.Lyrics current = this.lyrics;
      if (current == null || !MusicEngine.INSTANCE.isPlaying()) {
         return;
      }
      long pos = MusicEngine.INSTANCE.positionMs();
      LyricsProvider.Line line = current.at(pos);
      if (line == null || line.text().isBlank()) {
         return;
      }
      LyricsProvider.Line next = current.after(line);
      long lineDur = next != null ? Math.max(500L, next.ms() - line.ms()) : 5000L;
      long age = pos - line.ms();

      float alpha = 1.0F;
      float scale = 1.0F;
      String effect = this.lyricEffect.get();
      if (!"POP_OUT".equals(effect)) {
         float fadeIn = Math.min(1.0F, age / 400.0F);
         float fadeOut = Math.min(1.0F, Math.max(0.0F, lineDur - age) / 400.0F);
         alpha = Math.min(fadeIn, fadeOut);
      }
      if (!"FADING".equals(effect)) {
         float t = Math.min(1.0F, age / 300.0F);
         float eased = 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
         scale = 1.35F - 0.35F * eased;
      }

      float cx = this.x + Math.max(this.getWidthCached(), 180) / 2.0F;
      int argb = (int) (alpha * 255.0F) << 24 | 0xFFFFFF;

      context.getMatrices().pushMatrix();
      context.getMatrices().translate(cx, cy);
      context.getMatrices().scale(scale, scale);
      context.getMatrices().translate(-cx, -cy);
      TextPainter.drawPoppins(context, line.text(),
         cx - TextPainter.poppinsWidth(line.text(), 11.0F) / 2.0F, cy - 5.0F, argb, 11.0F);
      context.getMatrices().popMatrix();

      if (next != null && !next.text().isBlank()) {
         TextPainter.drawPoppins(context, next.text(),
            cx - TextPainter.poppinsWidth(next.text(), 8.5F) / 2.0F, cy + 8.0F, 0x66FFFFFF, 8.5F);
      }
   }

   private static String fit(String text, int maxWidth) {
      if (text == null) {
         return "";
      }
      String t = text;
      while (RenderUtil.textWidth(t) > maxWidth && t.length() > 2) {
         t = t.substring(0, t.length() - 1);
      }
      return t.equals(text) ? t : t + "...";
   }

   @Override
   public int getWidth() {
      if (!this.showInfo.get()) {
         return 40;
      }
      String statusNow = this.status;
      if (!statusNow.isEmpty()) {
         return RenderUtil.textWidth(fit(statusNow, MAX_TITLE_PX)) + 16;
      }
      String title = this.titleLine();
      if (title.isEmpty()) {
         return 40;
      }
      int titleW = RenderUtil.textWidth(fit(title, MAX_TITLE_PX));
      int timeW = RenderUtil.textWidth(this.timeLine());
      return Math.max(60, Math.max(titleW, timeW) + 16);
   }

   @Override
   public int getHeight() {
      return this.showInfo.get() ? 30 : 21;
   }

   /* ---------------- helpers ---------------- */

   private void notifyError(String message) {
      String text = message == null || message.isBlank() ? "Unknown error" : message;
      this.notify("Music: " + text);
   }

   private void notify(String message) {
      try {
         BlueClient.getInstance().notificationManager().add(message, -13673473);
      } catch (Throwable ignored) {
      }
   }
}
