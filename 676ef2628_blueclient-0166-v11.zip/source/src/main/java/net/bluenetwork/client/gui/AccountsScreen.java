package net.bluenetwork.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.account.Account;
import net.bluenetwork.client.account.AccountManager;
import net.bluenetwork.client.account.MsAuth;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public class AccountsScreen extends Screen {
   private final Screen parent;
   private final List<AccountsScreen.Hit> hits = new ArrayList<>();
   private boolean typingName = false;
   private String typedName = "";
   private String notice = "";
   private MsAuth.State msState = null;

   public AccountsScreen(Screen parent) {
      super(Text.literal("Accounts"));
      this.parent = parent;
   }

   public boolean shouldPause() {
      return false;
   }

   private AccountManager accounts() {
      return BlueClient.getInstance().accountManager();
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      this.hits.clear();
      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();
      context.fill(0, 0, width, height, -1726933982);
      String title = "ACCOUNTS";
      RenderUtil.drawText(context, title, (width - RenderUtil.textWidth(title)) / 2, 14, BlueColors.TEXT_PRIMARY);
      context.fill(width / 2 - 60, 25, width / 2 + 60, 26, -13673473);
      String current = "Playing as: " + this.accounts().currentUsername();
      RenderUtil.drawText(context, current, (width - RenderUtil.textWidth(current)) / 2, 31, BlueColors.TEXT_MUTED);
      int cx = width / 2;
      int bw = 180;
      int bh = 17;
      int gap = 4;
      int y = 44;

      for (Account account : this.accounts().getAccounts()) {
         boolean active = this.accounts().isActive(account);
         String badge = account.isMicrosoft() ? "[MSA]" : "[CRACKED]";
         String label = account.username() + " " + badge + (active ? " - CURRENT" : "");
         int ry = y;
         this.row(context, this.hits, mouseX, mouseY, cx - bw / 2, ry, bw, bh, label, active, () -> this.accounts().use(account), () -> {
            this.accounts().remove(account);
            this.notice = "Removed " + account.username();
         });
         net.minecraft.util.Identifier head = net.bluenetwork.client.util.HeadFetch.head(account.username());
         if (head != null) {
            int hx = cx - bw / 2 + 2;
            int hy = ry + 1;
            int hs = bh - 2;
            context.drawTexturedQuad(head, hx, hy, hx + hs, hy + hs, 0.125F, 0.25F, 0.125F, 0.25F);
         }
         y += bh + gap;
      }

      if (this.accounts().getAccounts().isEmpty()) {
         String empty = "No saved accounts yet";
         RenderUtil.drawText(context, empty, (width - RenderUtil.textWidth(empty)) / 2, y + 2, BlueColors.TEXT_MUTED);
         y += 14;
      }

      y += 6;
      if (this.typingName) {
         String label = "NAME: " + this.typedName + "_";
         this.row(context, this.hits, mouseX, mouseY, cx - bw / 2, y, bw, bh, label, true, () -> {}, () -> {});
         String hint = "ENTER to add - BACKSPACE to erase - ESC to cancel";
         RenderUtil.drawText(context, hint, (width - RenderUtil.textWidth(hint)) / 2, y + bh + 1, BlueColors.TEXT_MUTED);
         y += bh + gap + 12;
      } else {
         this.row(context, this.hits, mouseX, mouseY, cx - bw / 2, y, bw, bh, "+ CRACKED ACCOUNT", false, () -> {
            this.typingName = true;
            this.typedName = "";
         }, null);
         y += bh + gap;
      }

      if (this.msState != null && !this.msState.done) {
         String line1 = "MS LOGIN: open " + this.msState.verificationUri;
         RenderUtil.drawText(context, line1, (width - RenderUtil.textWidth(line1)) / 2, y + 2, BlueColors.TEXT_MUTED);
         y += 12;
         String code = this.msState.userCode;
         int codeW = RenderUtil.textWidth(code) + 12;
         RenderUtil.drawRoundedPanel(context, cx - codeW / 2, y, codeW, 16);
         RenderUtil.drawText(context, code, cx - RenderUtil.textWidth(code) / 2, y + 4, BlueColors.TEXT_PRIMARY);
         y += 18;
         String waiting = "Waiting for sign-in...";
         RenderUtil.drawText(context, waiting, (width - RenderUtil.textWidth(waiting)) / 2, y, BlueColors.TEXT_MUTED);
         y += 12;
      } else {
         this.row(context, this.hits, mouseX, mouseY, cx - bw / 2, y, bw, bh, "+ MICROSOFT ACCOUNT", false, () -> {
            this.msState = MsAuth.start();
         }, null);
         y += bh + gap;
      }

      if (this.msState != null && this.msState.done) {
         if (this.msState.success && this.msState.account != null) {
            this.accounts().addMicrosoft(this.msState.account);
            this.notice = "Added Microsoft account: " + this.msState.account.username();
         } else if (this.msState.error != null && !this.msState.error.isEmpty()) {
            this.notice = this.msState.error;
         }

         this.msState = null;
      }

      if (!this.notice.isEmpty()) {
         RenderUtil.drawText(context, this.notice, (width - RenderUtil.textWidth(this.notice)) / 2, y + 1, BlueColors.TEXT_MUTED);
         y += 13;
      }

      y += 6;
      int dw = 90;
      RenderUtil.drawRoundedPanel(context, cx - dw / 2, y, dw, 18);
      String done = "DONE";
      RenderUtil.drawText(context, done, cx - RenderUtil.textWidth(done) / 2, y + 5, BlueColors.TEXT_PRIMARY);
      this.hits.add(new AccountsScreen.Hit(cx - dw / 2, y, dw, 18, () -> this.client.setScreen(this.parent), null));
      String hint = "Click an account to switch - right-click removes it";
      RenderUtil.drawText(context, hint, (width - RenderUtil.textWidth(hint)) / 2, height - 12, BlueColors.TEXT_MUTED);
   }

   private void row(
      DrawContext context,
      List<AccountsScreen.Hit> hits,
      int mx,
      int my,
      int x,
      int y,
      int w,
      int h,
      String label,
      boolean bright,
      Runnable action,
      Runnable altAction
   ) {
      boolean hovered = mx >= x && mx < x + w && my >= y && my < y + h;
      int body = hovered ? BlueColors.PANEL_BG_HOVER : BlueColors.PANEL_BG;
      if (bright) {
         body = BlueColors.PANEL_BG_HOVER;
      }

      context.fill(x + 1, y, x + w - 1, y + h, body);
      context.fill(x, y + 1, x + w, y + h - 1, body);
      context.fill(x + 1, y, x + w - 1, y + 1, bright ? -2144379905 : BlueColors.PANEL_BORDER);
      context.fill(x + 1, y + h - 1, x + w - 1, y + h, bright ? -2144379905 : BlueColors.PANEL_BORDER);
      context.fill(x, y + 1, x + 1, y + h - 1, bright ? -2144379905 : BlueColors.PANEL_BORDER);
      context.fill(x + w - 1, y + 1, x + w, y + h - 1, bright ? -2144379905 : BlueColors.PANEL_BORDER);
      int textColor = bright ? BlueColors.TEXT_PRIMARY : BlueColors.TEXT_MUTED;
      RenderUtil.drawText(context, label, x + 6, y + (h - 9) / 2 + 1, hovered ? BlueColors.TEXT_PRIMARY : textColor);
      hits.add(new AccountsScreen.Hit(x, y, w, h, action, altAction));
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int)click.x();
      int my = (int)click.y();
      boolean right = click.button() == 1;

      for (int i = this.hits.size() - 1; i >= 0; i--) {
         AccountsScreen.Hit hit = this.hits.get(i);
         if (mx >= hit.x && mx < hit.x + hit.w && my >= hit.y && my < hit.y + hit.h) {
            if (right && hit.altAction != null) {
               hit.altAction.run();
            } else {
               hit.action.run();
            }

            return true;
         }
      }

      return super.mouseClicked(click, doubled);
   }

   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.typingName) {
         if (key == 257) {
            if (!this.typedName.isEmpty()) {
               String error = this.accounts().addCracked(this.typedName);
               if (error == null) {
                  this.notice = "Added " + this.typedName;
               } else {
                  this.notice = error;
               }
            }

            this.typingName = false;
            this.typedName = "";
            return true;
         } else if (key == 256) {
            this.typingName = false;
            this.typedName = "";
            return true;
         } else if (key == 259 && !this.typedName.isEmpty()) {
            this.typedName = this.typedName.substring(0, this.typedName.length() - 1);
            return true;
         } else {
            return true;
         }
      } else if (key == 256) {
         this.client.setScreen(this.parent);
         return true;
      } else {
         return super.keyPressed(input);
      }
   }

   public boolean charTyped(CharInput input) {
      if (this.typingName && input.isValidChar()) {
         String ch = input.asString();
         if (ch.length() == 1 && this.typedName.length() < 16) {
            this.typedName = this.typedName + ch;
            return true;
         }
      }

      return super.charTyped(input);
   }

   private record Hit(int x, int y, int w, int h, Runnable action, Runnable altAction) {
   }
}
