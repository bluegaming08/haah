package net.bluenetwork.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.bluenetwork.client.module.impl.Fullbright;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Real fullbright. Since 1.19 the gamma option is a validated SimpleOption
 * clamped to 0.0–1.0, so writing 16.0 through the option is rejected and the
 * old "set gamma to 16" trick silently does nothing. Instead we swap the gamma
 * read inside the lightmap update for our own unbounded option while the
 * Fullbright module is on — the vanilla options file is never touched.
 *
 * <p>Uses MixinExtras @ModifyExpressionValue instead of a plain @Redirect on
 * purpose: MixinExtras 0.5.4 (bundled with fabric-loader 0.19.x) fails with
 * ClassCastException on @Redirect's array-form `at` member (fixed only in
 * 0.5.5), and ModifyExpressionValue composes with other handlers on the same
 * call instead of hard-replacing them.</p>
 */
@Mixin(LightmapTextureManager.class)
public abstract class LightmapTextureManagerMixin {
   @ModifyExpressionValue(
      method = "update",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/option/GameOptions;getGamma()Lnet/minecraft/client/option/SimpleOption;"
      )
   )
   private SimpleOption<Double> blueclient$fullbright(SimpleOption<Double> original) {
      SimpleOption<Double> boosted = Fullbright.brightGamma();
      if (boosted != null) {
         return boosted;
      }
      return original;
   }
}
