package net.bluenetwork.client.hud;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.optimization.PerfMeter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class HudManager {
   private final BlueClient client;

   public HudManager(BlueClient client) {
      this.client = client;
   }

   /**
    * Once per client tick, AFTER tickModules(): re-measures every visible HUD
    * module so the per-frame render path never calls getWidth()/getHeight().
    */
   public void tick() {
      for (HudModule module : this.client.moduleManager().getHudModules()) {
         if (module.isEnabled() || module.isRequired()) {
            module.refreshSizeCache();
         }
      }
   }

   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && !mc.options.hudHidden) {
         int screenW = mc.getWindow().getScaledWidth();
         int screenH = mc.getWindow().getScaledHeight();

         boolean metered = PerfMeter.active();
         if (metered) {
            PerfMeter.beginFrame();
         }

         for (HudModule module : this.client.moduleManager().getHudModules()) {
            if (module.isEnabled() || module.isRequired()) {
               long start = metered ? System.nanoTime() : 0L;
               try {
                  module.resolvePosition(screenW, screenH);
                  module.render(context);
               } catch (Throwable var6) {
                  BlueClient.LOGGER.error("HUD module '{}' failed to render", module.getName(), var6);
               } finally {
                  if (metered) {
                     PerfMeter.record(module.getName(), System.nanoTime() - start);
                  }
               }
            }
         }

         if (metered) {
            PerfMeter.endFrame();
         }

         this.client.notificationManager().render(context);
      }
   }
}
