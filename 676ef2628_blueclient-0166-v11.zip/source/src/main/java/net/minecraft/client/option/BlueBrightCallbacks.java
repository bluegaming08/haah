package net.minecraft.client.option;

import com.mojang.serialization.Codec;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

/**
 * Blue Client: unbounded-gamma callbacks for the Fullbright module.
 *
 * <p>SimpleOption's {@code Callbacks} interface is package-private, and gamma's
 * vanilla callbacks clamp the value to 0.0–1.0 (which is why "set gamma to 16"
 * stopped working in 1.19+). This class lives in {@code net.minecraft.client.option}
 * (the same split-package pattern as BlueDrawContextAccessor in
 * {@code net.minecraft.client.gui}) so it can implement the interface and let
 * the module build a private, UNBOUNDED gamma option that the lightmap mixin
 * hands to the lightmap update while Fullbright is enabled. The vanilla options
 * file is never touched; turning the module off restores the real gamma.</p>
 */
public final class BlueBrightCallbacks implements SimpleOption.Callbacks<Double> {
   @Override
   public Optional<Double> validate(Double value) {
      // Unbounded: 16.0 passes. That is the whole point.
      return Optional.of(value);
   }

   @Override
   public Codec<Double> codec() {
      return Codec.DOUBLE;
   }

   @Override
   public Function<SimpleOption<Double>, ClickableWidget> getWidgetCreator(
         SimpleOption.TooltipFactory<Double> tooltipFactory, GameOptions options,
         int x, int y, int width, Consumer<Double> changeCallback) {
      // Never shown in vanilla UIs, so no widget is needed.
      return option -> null;
   }
}
