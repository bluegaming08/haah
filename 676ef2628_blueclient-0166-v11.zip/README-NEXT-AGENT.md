# Blue Client v0.16.13 — build v11 (2026-09-15)

## What this build fixes (user bug: "clicking a song in the SONGS list does nothing")
1. **Song click parse bug (ROOT CAUSE)** — `ModuleSettingsScreen.mouseClicked` handled
   tags `"songs:play:<i>"` with `Integer.parseInt(tag.substring(10))`. "songs:play:" is
   11 chars, so substring(10) kept the colon (":0") → NumberFormatException → silently
   caught → NOTHING happened (no toast, no playback, no log). Present since the SONGS
   dropdown shipped. Fix: substring(11) + explanatory comment.
2. **jaad decoder not loading in production** — Fabric loader only nests jars that
   contain a fabric.mod.json. jlayer had one (loom-generated, id `javazoom_jlayer`);
   plain jaad-0.9.4.jar was silently SKIPPED → `NoClassDefFoundError: net/sourceforge/jaad/aac/Receiver`
   at first song click. Fix: `libs/jaad-0.9.4-fabric.jar` = jaad + fabric.mod.json
   (id `net_sourceforge_jaad`), nested as `META-INF/jars/jaad-0.9.4.jar` via gradle
   rename so the fabric.mod.json "jars" entry still matches. Loader now shows BOTH
   nested libs at startup.
3. **Toasts invisible on custom screens** — ModuleMenuScreen + ModuleSettingsScreen
   override render() WITHOUT calling super.render(), so ScreenMixin's @At(TAIL)
   toast hook never fired on them; "Playing X"/"Songs folder opened" toasts were
   invisible exactly where music feedback matters. Fix: both screens now draw
   `notificationManager().render(context)` at the end of their own render (guarded
   by `client.player == null`; in-game HudManager still owns toasts).

Also added: `MusicPlayer.playSongFile` logs "Playing song <name> [format= volume=]" at
INFO; volume<=0.01 triggers a yellow warning toast ("Volume is 0 — raise it…") because
a silent successful play at volume 0 looks identical to a dead click.

## Verified in prod-style sandbox (fabric-loader 0.19.3, MixinExtras 0.5.4, 1.21.11)
- Both nested libs load: `javazoom_jlayer 1.0.1`, `net_sourceforge_jaad 0.9.4`.
- Menu → CLIENT SETTINGS → MODS → search "music" → Music Player card → SONGS →
  click "fake-track" → log: `Playing song fake-track.mp3 [format=mp3 volume=0.5]`,
  NO playback errors, toast "Playing fake-track.mp3" renders top-right, playing-row
  accent shows. Screenshot-verified.
- Game stable through the whole flow (no crash/mixin errors).
- Headless has no audio device, so audible playback must be confirmed on the user's
  machine — but the decoder + engine path now provably starts.

## Project / build
- Source root: `src/` (Fabric, yarn 1.21.11+build.6, Java 21). Build:
  `gradle build -x test` with Gradle 9.5 (/tmp/gradle95) + JDK21 (/root/.jdk/jdk-21.0.12.1+1).
- Jar: `build/libs/blue-client-0.16.13.jar` (also in this zip).
- Nested decoder jars live in `libs/`; jaad MUST keep its fabric.mod.json wrapper
  (see fix #2) — do not swap back the plain upstream jar.
- Prod-test recipe for the sandbox is in /tmp/prodtest (fabric-installer headless,
  vanilla 1.21.11 + assets index 29, xvfb-run + xdotool + tesseract OCR at the
  +213+272 window). GOTCHA: pkill "[K]notClient" in the SAME bash call as the new
  launch kills the new launch — pkill/cp in one call, setsid nohup launch in the next.

## Next agent TODOs (unchanged from v10)
- Performance phase (lazy chunk loading, FPS) is the user's planned next milestone.
- In-game (in-world) verification of Third Person Nametag styling still can't be done
  headless — world creation stalls without GPU; needs the user's confirmation.
