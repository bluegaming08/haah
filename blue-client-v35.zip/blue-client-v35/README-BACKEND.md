# Blue Client — Backend Setup (Friends System)

This guide sets up the **online backend** that powers the Friends system:
accounts, friend requests, presence, blocking and privacy.

It is written for someone who has **never used a database before**. Follow the
steps in order. Nothing here requires coding, a credit card, or a server.

**Time needed:** about 15 minutes.

> **The client works fine without this.** If you skip this guide entirely,
> Blue Client still launches and plays normally — the Friends screen just
> shows *"Friends services are currently unavailable."* Nothing else breaks.

---

## Table of contents

| # | Step |
|---|------|
| 1 | What Supabase is and why we use it |
| 2 | Create your Supabase account |
| 3 | Create the project |
| 4 | Turn OFF email confirmation (**required**) |
| 5 | Find your two connection values |
| 6 | Create the database tables |
| 7 | Check the tables were created |
| 8 | Understand what each table stores |
| 9 | Put your values into the client |
| 10 | Build the client |
| 11 | Test it: create two accounts |
| 12 | Test friend requests |
| 13 | Test blocking |
| 14 | Test the privacy settings |
| 15 | Which keys are safe to share (**important**) |
| 16 | How the security actually works (RLS) |
| 17 | The username trick (why accounts have a hidden email) |
| 18 | Free plan limits and the 1-week pause |
| 19 | Keeping the project awake |
| 20 | Common problems and fixes |
| 21 | Viewing and moderating your users |
| 22 | Moving to your own project / going to production |
| 23 | **v20 — the second schema file (`schema_v2.sql`)** |
| 24 | **v20 — deploying the Edge Function (Minecraft linking)** |
| 25 | **v20 — what each new table does** |
| 26 | **v20 — testing the new features** |

---

## 1. What Supabase is and why we use it

The Friends system needs a computer on the internet that is always on, so your
friend list exists even when your game is closed. That is a **backend**.

[Supabase](https://supabase.com) gives you one for free. It provides:

* a **database** (a set of tables — like very strict spreadsheets),
* **authentication** (usernames and passwords, stored securely — we never see
  or store the actual password),
* a **web API** so the Minecraft mod can talk to it over HTTPS.

We chose it because the free plan is generous, it needs no server
administration, and its security rules run on *their* servers — which matters,
because a Minecraft mod on someone's PC can be modified and must never be
trusted.

---

## 2. Create your Supabase account

1. Go to **<https://supabase.com>**.
2. Click **Start your project**.
3. Sign in with GitHub, or with an email and password.
4. No payment details are required for the free plan.

---

## 3. Create the project

1. Click **New project**.
2. Pick your organisation (one was made for you automatically).
3. Fill in:
   * **Name** — for example `blue-client`.
   * **Database Password** — click **Generate a password** and let it create a
     strong one.

     > ⚠️ **You will never need to type this password into Blue Client.** It is
     > only for connecting to the database directly with admin tools. Save it
     > in a password manager. **Never put it in the mod, in a config file, or
     > in a chat message.** If it ever leaks, come back here and click
     > *Settings → Database → Reset database password*.
   * **Region** — pick the one closest to most of your players. This is the
     single biggest factor in how fast Friends feels.
4. Click **Create new project** and wait ~2 minutes while it sets up.

---

## 4. Turn OFF email confirmation (**required**)

Blue Client accounts are **username + password** — players never enter an
email. To make that work we give each account a hidden placeholder email
(see step 17). Nobody can receive mail at those addresses, so Supabase must
not try to send any.

1. In the left sidebar click **Authentication**.
2. Click **Sign In / Providers**.
3. Click **Email** in the list of providers.
4. Find **Confirm email** and switch it **OFF**.
5. Click **Save**.

> **If you skip this step**, players will create an account and then be unable
> to log in, and you will hit an *"over_email_send_rate_limit"* error after a
> handful of signups. The client detects this case and shows:
> *"Account created but login is blocked: turn OFF email confirmation in
> Supabase."*

---

## 5. Find your two connection values

1. Click the **Settings** gear (bottom left).
2. Click **API Keys** (or **Data API**).
3. Copy these two values into a scratch file:

| Value | Looks like | What it is |
|---|---|---|
| **Project URL** | `https://abcdefgh.supabase.co` | your project's address |
| **Publishable / anon key** | `sb_publishable_...` or a long `eyJ...` string | the public key the game uses |

> There is a third key on that page called **`service_role`** (sometimes shown
> as *secret*). **Never copy that one into the mod.** See step 15.

---

## 6. Create the database tables

1. In the left sidebar click **SQL Editor**.
2. Click **New query**.
3. Open the file **`backend/schema.sql`** that ships with the Blue Client
   source, select **all** of it, and copy it.
4. Paste it into the SQL Editor.
5. Click **Run** (or press Ctrl+Enter).

You should see **Success. No rows returned.** That is the correct result — the
script creates things, it does not look anything up.

This one script creates all five tables, the security rules, the helper
functions and the indexes. It is safe to run more than once.

---

## 7. Check the tables were created

1. Click **Table Editor** in the sidebar.
2. You should see five tables:
   `profiles`, `settings`, `friendships`, `friend_requests`, `blocks`.
3. They will all be empty. That is correct — nobody has signed up yet.

A stronger check: go back to the **SQL Editor** and run

```sql
select count(*) from public.profiles;
```

It should return `0`. If it returns an **error**, the schema did not apply —
re-do step 6 and read the red error message.

---

## 8. Understand what each table stores

You do not need to memorise this, but it helps when something looks wrong.

| Table | One row per… | Key columns |
|---|---|---|
| `profiles` | Blue Client account | `username`, `is_online`, `server_name`, `last_seen` |
| `settings` | account | the four privacy choices + notification toggle |
| `friendships` | **accepted** friendship | `user_a`, `user_b` |
| `friend_requests` | **pending** request | `sender_id`, `receiver_id` |
| `blocks` | block | `blocker_id`, `blocked_id` |

Two design details worth knowing:

* A friendship is stored as **one row, not two**. The two ids are always saved
  smallest-first, which makes a duplicate or half-deleted friendship
  structurally impossible.
* A request row is **deleted** when it is accepted or declined. So
  `friend_requests` only ever contains genuinely pending ones.

---

## 9. Put your values into the client

Open:

```
src/main/java/net/bluenetwork/client/social/BlueBackend.java
```

Change the two constants to the values you copied in step 5:

```java
public static final String URL = "https://YOUR-PROJECT.supabase.co";
public static final String ANON_KEY = "sb_publishable_YOUR_KEY";
```

There is a third setting just below:

```java
public static final String ACCOUNT_EMAIL_DOMAIN = "blueclient.app";
```

This is the domain used for the hidden placeholder emails (step 17). Supabase
rejects obviously fake domains such as `.invalid` or `.local`, so it has to
look like a real domain. **If you own a domain, use it here.**

---

## 10. Build the client

From the project folder:

```bash
./release.sh v19 0.25.2
```

That produces `blue-client-v19-0.25.2.jar`. Put it in your `mods` folder.

---

## 11. Test it: create two accounts

You need two accounts to test friends, so use two Minecraft launches (or a
friend).

1. Launch Minecraft and open the main menu.
2. Click **FRIENDS** in the bottom dock (it is also in the pause menu).
3. Click **New here? Create an account**.
4. Enter a username (3–16 letters, numbers or `_`) and a password (6+
   characters). Click **CREATE ACCOUNT**.
5. You should land straight on the friends list.

Now check the database: **Table Editor → profiles**. Your new account should
be listed, with `is_online` set to `true`.

Repeat with a second, different username.

> The username is **completely separate from your Minecraft name**, and works
> on cracked/offline accounts. That is the whole point — no Microsoft or
> Mojang account is involved anywhere.

---

## 12. Test friend requests

1. On account A, open **ADD**, type the first few letters of account B's name.
   Results appear after a short pause (the search waits until you stop typing).
2. Click **ADD** next to account B.
3. On account B, open **REQUESTS** — the request from A is listed.
4. Click **ACCEPT**.
5. Both accounts now show each other under **FRIENDS**, with a green dot when
   online and the server they are playing on.

Things to try, all of which are refused by the **database** (not just the UI):

* sending the same request twice,
* sending a request to someone who is already your friend,
* sending a request to yourself.

---

## 13. Test blocking

1. On account A, open **FRIENDS** and click **BLOCK** next to account B.
2. Account B disappears from A's friend list — blocking also **ends the
   friendship**.
3. On account B, try to search for account A: **no results**.
4. Account B cannot send A a friend request.
5. Account B is never told they were blocked — from their side, A has simply
   vanished.
6. To reverse it, go to **BLOCKED** on account A and click **UNBLOCK**.

---

## 14. Test the privacy settings

Open the **PRIVACY** tab. Each row cycles when clicked, and saves instantly.

| Setting | Options | Effect |
|---|---|---|
| Who can send me requests | Everyone / Friends of friends / Nobody | rejects unwanted requests at the database |
| Who can see I am online | Everyone / Friends / Nobody | hides the green dot |
| Who can see my server | Everyone / Friends / Nobody | hides "Playing on …" |
| Who can see my last seen | Everyone / Friends / Nobody | hides "Last seen 2 hours ago" |
| Notify me when friends come online | On / Off | the pop-up toast |

To prove it works: set **Who can see my server** to *Nobody* on account B, then
look at account A's friend list. B still shows as online, but the server line
is gone — because the server never sent it.

---

## 15. Which keys are safe to share (**important**)

| Value | Safe in the jar? | Why |
|---|---|---|
| Project URL | ✅ Yes | it is just an address |
| Publishable / anon key | ✅ Yes | designed to be public; protected by RLS |
| **Database password** | ❌ **NEVER** | full admin access to all data |
| **`service_role` key** | ❌ **NEVER** | **ignores all security rules** |

The publishable key **is** inside the jar, and anyone can extract it. That is
normal and expected — it is exactly what a website ships in its JavaScript.
It is safe **because** the security rules in step 16 run on Supabase's servers.

The `service_role` key is the opposite: it bypasses every rule. If it ever ends
up in a jar, anyone can read and delete every user's data. Never paste it into
any file under `src/`.

---

## 16. How the security actually works (RLS)

Since the key is public, what stops a modified client deleting everyone's
friends?

**Row Level Security (RLS).** Every table has rules attached that Postgres
applies to *every* query, no matter who sends it or what client they use.
Roughly:

* `profiles` — you may only edit **your own** row.
* `settings` — you may only read or edit **your own** row.
* `friendships` — **no insert rule at all.** A friendship can only be created
  by the `accept_friend_request` function, which first verifies a real request
  existed and that *you* are the receiver. This is what makes it impossible to
  add yourself to someone else's friend list.
* `friend_requests` — you may only send *as yourself*, not to yourself, not if
  either side has blocked the other, not if you are already friends, and only
  if the receiver's privacy setting allows it.
* `blocks` — only the blocker can see or remove their own blocks. The blocked
  person cannot detect it.

These rules were **tested adversarially**: a suite of 53 simulated attacks
(forging requests from other users, self-inserting friendships, reading other
people's settings, probing who blocked whom, dumping the user list through
search) is run against the schema, and all 53 are refused.

Two subtleties that are easy to get wrong if you edit the schema:

* The policy helpers (`are_friends`, `block_exists`, …) are
  `security definer` **and** carry an anti-probing guard: you may only ask
  about a pair that includes yourself. Without the guard, a hostile client
  could map the entire social graph one question at a time.
* `search_users` requires **2+ characters**, escapes `%` and `_`, and caps
  results at 20 — otherwise a single query could dump every username.

---

## 17. The username trick (why accounts have a hidden email)

Supabase Auth has **no username login** — it requires an email address. Blue
Client wants usernames and no email at all.

So the client builds a placeholder address: the username `BlueDev` becomes
`bluedev@blueclient.app`. The player never sees or types this. Because those
addresses cannot receive mail, email confirmation must be off (step 4).

Two consequences:

* **Usernames are case-insensitive for logging in** — `BlueDev` and `bluedev`
  are the same account — but the original capitalisation is preserved for
  display. That is enforced by a unique index on a lowercased copy of the name,
  so two people can never register names that differ only in case.
* **There is no password recovery.** Blue Client accounts have no real email
  address, so there is nothing to send a reset link to. An earlier build had
  an optional *"link an email"* box in the Privacy tab; it was **removed** —
  it collected personal data for a feature almost nobody used, and it made the
  privacy tab confusing. If a player forgets their password they register a
  new username. You can delete the old row for them from the dashboard
  (section 21).

---

## 18. Free plan limits and the 1-week pause

The free plan gives roughly:

* 500 MB of database space — that is **hundreds of thousands** of friendships;
  you will not run out.
* 50,000 monthly active users.
* Unlimited API requests.

The one limit that will actually affect you:

> **A free project is paused after ~1 week with no activity.**

A paused project stops answering, and Friends shows *"Friends services are
currently unavailable."* Nothing breaks and no data is lost — you just
un-pause it from the dashboard.

---

## 19. Keeping the project awake

* **If people play regularly**, the heartbeat traffic keeps it awake by itself.
* **If it goes quiet**, open the dashboard and click **Restore** / **Resume**.
* For a public release, the paid tier (~$25/month) removes the pause entirely.

---

## 20. Common problems and fixes

| What you see | Cause | Fix |
|---|---|---|
| *Friends services are currently unavailable.* | Project paused, wrong URL, or no internet | Check the dashboard; re-check step 9 |
| *Account created but login is blocked…* | Email confirmation is still ON | Do step 4 |
| `Email address "…" is invalid` | Supabase rejected the fake domain | Use a real-looking domain in step 9 |
| `over_email_send_rate_limit` | Supabase tried to send confirmation mail | Do step 4 |
| *That username is already taken.* | Someone has it (case-insensitively) | Pick another |
| *They are not accepting friend requests.* | Their privacy setting refused it | Working as intended |
| *Please log in again.* | Session expired or password changed | Log in again |
| Tables missing / `PGRST205` | Schema never ran | Re-do step 6 |
| Friends list empty but rows exist in the DB | Schema partly applied | Re-run `schema.sql`; it is safe |

To see the real error, check **Logs** in the Supabase sidebar, or run Minecraft
with `-Dblueclient.dev=true` for verbose client logging.

---

## 21. Viewing and moderating your users

**Authentication → Users** lists every account and lets you delete one.
Deleting a user there removes their profile, friendships, requests and blocks
automatically (that is the `on delete cascade` in the schema).

Useful queries for the SQL Editor:

```sql
-- How many accounts exist?
select count(*) from public.profiles;

-- Who is online right now?
select username, server_name, last_seen
from public.profiles
where is_online = true
order by username;

-- The 20 newest accounts
select username, created_at
from public.profiles
order by created_at desc
limit 20;

-- Ban an abusive user (this also removes all their relationships)
delete from auth.users where id = 'PASTE-THE-UUID-HERE';
```

---

## 22. Moving to your own project / going to production

To point the client at a different Supabase project:

1. Do steps 3–6 on the new project.
2. Update `URL` and `ANON_KEY` in `BlueBackend.java`.
3. Rebuild.

Before a public release, also consider:

* **Buy a domain** and use it for `ACCOUNT_EMAIL_DOMAIN`. Owning it means you
  can later add a real inbox and turn on genuine email verification.
* **Turn on leaked-password protection** — *Authentication → Policies* — which
  rejects passwords found in known breaches.
* **Set rate limits** — *Authentication → Rate Limits* — to slow down someone
  script-creating thousands of accounts.
* **Enable daily backups** (a paid feature, but worth it once you have real
  users).
* **Upgrade off the free plan** so the project never pauses.
* **Re-run the attack tests** if you modify `schema.sql`. Changing a policy is
  very easy to get subtly wrong — during development, one innocent-looking
  policy rejected *every* friend request, because a sub-query on the settings
  table was itself being filtered by that table's own security rule.

---

### Quick reference

| Thing | Where |
|---|---|
| Schema to run | `backend/schema.sql` |
| URL + key | `social/BlueBackend.java` |
| Network layer | `social/SupabaseClient.java` |
| State + caching + presence | `social/FriendsManager.java` |
| The screen | `ui/screen/FriendsScreen.java` |

**Never ship:** the database password, or the `service_role` key.

---

# v20 additions

Everything above still applies and still works. v20 adds **messaging, groups,
statuses, followers, about-me, badges, buddies, server joining and Minecraft
account linking**. All of it lives in a **second** SQL file so you never have
to re-run the first one.

---

## 23. The second schema file (`schema_v2.sql`)

**Run this once, after `schema.sql`.**

1. Open your project at [supabase.com](https://supabase.com).
2. Click **SQL Editor** in the left sidebar.
3. Click **+ New query**.
4. Open `backend/schema_v2.sql` from the mod source, select **all** of it
   (Ctrl+A) and copy it.
5. Paste it into the editor and press **Run** (or Ctrl+Enter).
6. You should see *"Success. No rows returned."*

That is the whole step. The file is safe to run twice — every statement uses
`if not exists` or `create or replace` — so if you are unsure whether it ran,
just run it again.

> **If you get an error mentioning `profiles` or `settings` does not exist**,
> you skipped `schema.sql`. Run step 6 of the original guide first.

---

## 24. Deploying the Edge Function (Minecraft linking)

This is the only step in the whole guide that needs a terminal. **You can skip
it** — everything else keeps working, players just cannot link a *premium*
Minecraft name (cracked names still link fine, and the client shows a clear
message).

### Why a function is needed at all

A player links their Minecraft name so friends can see who they are in game.
The rule you asked for is:

> A player may not claim a premium account's username unless that account is
> in their account manager.

The only unforgeable proof of that is the **access token** Minecraft itself
hands out when you log in with Microsoft. We send that token to Mojang:

```
GET https://api.minecraftservices.com/minecraft/profile
Authorization: Bearer <token>
```

Mojang replies with the name and UUID that token really owns, or `401` if the
token is fake. A token cannot be forged — only Microsoft can mint one.

**Why this cannot be done in the mod.** The mod runs on the player's PC. Any
check it performs can be deleted with a text editor, so "the mod checked and
it was fine" is worth nothing. The database has to do the check itself, and
the database cannot make outbound HTTP calls. An Edge Function — a tiny
program that runs on Supabase's servers — is the bridge.

### Deploy it

1. Install the Supabase CLI: <https://supabase.com/docs/guides/cli> (on
   Windows: `winget install Supabase.CLI`).
2. Open a terminal in the mod source folder (the one containing `backend/`).
3. Log in and link your project — the project ref is the random-looking part
   of your project URL, e.g. `mzomulrpfffrvoennzlb`:

   ```bash
   supabase login
   supabase link --project-ref YOUR-PROJECT-REF
   ```

4. Deploy:

   ```bash
   supabase functions deploy verify-minecraft
   ```

5. Give the function the key it needs to write to the database.
   In the dashboard: **Edge Functions → verify-minecraft → Secrets**, and add

   | Name | Value |
   |---|---|
   | `SERVICE_ROLE_KEY` | *Project Settings → API → `service_role` key* |

   > The `service_role` key bypasses all security rules. It is safe **only**
   > here, on Supabase's own servers. **Never put it in the mod.** If it ever
   > leaks, rotate it immediately in Project Settings → API.

### Check it worked

```
https://YOUR-PROJECT-REF.supabase.co/functions/v1/verify-minecraft
```

Opening that in a browser should give a JSON error about a missing token —
**not** a 404. A 404 means it is not deployed.

### What the function does, step by step

1. Reads the caller's Blue Client login (the `Authorization` header) — so it
   knows *which* profile is asking. No login, no link.
2. Reads the Minecraft access token from the request body.
3. Asks Mojang who owns that token.
4. Calls `apply_minecraft_link(...)` in the database with the **real** name and
   UUID from Mojang's reply — never the name the client asked for.

`apply_minecraft_link` is deliberately **not callable by players**
(`authenticated` has no EXECUTE permission on it). Only the function, holding
the service-role key, can reach it. That is what makes the rule enforceable.

### Cracked (offline) names

Cracked names need no token, so they are handled entirely in SQL by
`link_cracked_minecraft(name)`, which refuses when:

* a premium account owns that name (checked against `mojang_premium_names`,
  see below), or
* someone else has already **verified** that name, or
* the name is not a valid Minecraft name (`^[A-Za-z0-9_]{3,16}$`).

A cracked link is stored with `mc_verified = false` and the deterministic
offline UUID, `UUID.nameUUIDFromBytes("OfflinePlayer:" + name)`, computed in
SQL so it matches exactly what the game itself produces. The UI shows cracked
links as *(cracked)* and verified ones as *(verified)* with a tick, so nobody
can impersonate a premium player.

---

## 25. What each new table does

| Table | What it holds |
|---|---|
| `conversations` | One row per DM or group. `is_group` tells them apart. |
| `conversation_members` | Who is in each conversation, and their `last_read_at` (that is where the unread counter comes from). |
| `messages` | The messages. Body capped at 256 characters. |
| `badges` | The six badges: Tester, Founder, Helper, Supporter, Famous, Beta Tester. Seeded by the schema. |
| `user_badges` | Which player has earned which badge. **You grant these by hand** — see below. |
| `follows` | One-click following. No approval, no request. |
| `cosmetics` | The catalogue of cosmetic items. **Empty and unused in v20.** |
| `user_cosmetics` | Who owns which cosmetic, and whether it is equipped. **Empty and unused in v20.** |
| `mojang_premium_names` | A cache of "this name is owned by a paid account", so the cracked-name check does not hammer Mojang. |

The two cosmetics tables are created now, empty, so a future version can add
capes, wings and hats without a migration that touches live user data. See
README-NEXT-AGENT.

New columns on `profiles`: `mc_name`, `mc_uuid`, `mc_verified`, `about`
(50 chars), `status` (40 chars), `equipped_badge`, `buddy_id`.

New columns on `settings`: `show_badge` (let others see my badge) and
`see_badges` (show me other people's badges). These are two independent
toggles, exactly as specified — hiding yours does not hide theirs.

### Granting a badge to someone

SQL Editor → New query:

```sql
insert into public.user_badges (user_id, badge_id)
select p.id, b.id
from public.profiles p, public.badges b
where p.username_low = lower('TheirUsername')
  and b.code = 'founder';          -- tester | founder | helper
                                   -- supporter | famous | beta_tester
```

They must then **equip** it on their profile screen for it to appear in their
nametag. Only the equipped badge is ever shown, and only in the nametag —
never in the tab list.

To take one away:

```sql
delete from public.user_badges
where user_id = (select id from public.profiles where username_low = lower('TheirUsername'))
  and badge_id = (select id from public.badges where code = 'founder');
```

---

## 26. Testing the new features

Use the two accounts from section 11.

| Test | Expected |
|---|---|
| Friends tab → **MSG** on a friend | Chat opens; typing and Enter sends |
| Second account | Sees CHATS with an unread counter |
| **CHATS → NEW GROUP**, name it, tick both friends | Group appears for everyone in it |
| Type a 300-character message | Input stops at 256 |
| Profile → set a status and an about | Shows on the other account's view of you |
| Follow, then follow again | Counter goes up once, never twice |
| Privacy → **LINK** while logged into a cracked account whose name a premium player owns | Refused with a clear message |
| Equip a badge, then turn off *show my badge* | Your badge disappears from other players' nametags |
| Friend on a server → **JOIN** | You connect to their server |

### The attack tests

`backend_test/attack.sql` (53 tests) and `backend_test/attack_v2.sql`
(59 tests) try to break every rule from the outside: reading other people's
messages, joining groups uninvited, claiming premium names, following blocked
users, calling `apply_minecraft_link` directly. **112 of 112 pass.**

Re-run them after any schema edit. Both files print a `PASS`/`FAIL` line per
test and a summary at the end.

---

### Quick reference (v20)

| Thing | Where |
|---|---|
| Second schema | `backend/schema_v2.sql` |
| Edge Function | `backend/functions/verify-minecraft/index.ts` |
| Attack tests | `backend_test/attack.sql`, `backend_test/attack_v2.sql` |
| Messaging + profiles in the client | `social/FriendsManager.java` |
| Chat UI | `ui/screen/ChatScreen.java`, `ui/screen/NewGroupScreen.java` |
| Profile UI | `ui/screen/ProfileScreen.java` |
| Badge lookup (hot path) | `social/BadgeCache.java` |
| Nametag badge rendering | `mixin/PlayerEntityRendererMixin.java` |

**Never ship:** the database password, or the `service_role` key.
