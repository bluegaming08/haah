# Blue Client — Launcher Integration Guide

**For:** whoever builds the Blue Client launcher (a human or the next AI).
**Client version this describes:** `0.24.0` (v12), Minecraft `1.21.11`, Fabric Loader `0.19.3`.

This document has two halves:

1. **Integration** — the concrete, factual contract between the launcher and the mod jar. Get this right and the client just works.
2. **Feature plan** — what the launcher *should* do, in priority order.

---

## Part 1 — Integration

### 1.1 What the launcher actually has to do

Minimum viable launcher, in order:

1. Authenticate the user with Microsoft (MSA OAuth device-code flow) and hold a valid Minecraft access token.
2. Ensure a Java **21** runtime is present (bundle it — do not trust the system JVM).
3. Ensure the Minecraft `1.21.11` client jar, asset index and libraries are downloaded.
4. Install **Fabric Loader 0.19.3** for `1.21.11`.
5. Drop `blue-client-0.24.0.jar` and `fabric-api-0.141.6+1.21.11.jar` into the profile's `mods/` folder.
6. Launch with the right classpath, main class and JVM arguments.

### 1.2 Exact version matrix

Do not deviate from these. The mod is compiled against them.

| Component | Version |
|---|---|
| Minecraft | `1.21.11` |
| Yarn mappings | `1.21.11+build.6` |
| Fabric Loader | `0.19.3` |
| Fabric API | `0.141.6+1.21.11` |
| Java | **21** (the mod targets release 21) |
| Blue Client | `0.24.0` |

### 1.3 Recommended JVM arguments

```
-Xms2G
-Xmx4G
-XX:+UseG1GC
-XX:+ParallelRefProcEnabled
-XX:MaxGCPauseMillis=130
-XX:+UnlockExperimentalVMOptions
-XX:+DisableExplicitGC
-XX:+AlwaysPreTouch
-XX:G1NewSizePercent=28
-XX:G1HeapRegionSize=16M
-XX:G1ReservePercent=20
-XX:SurvivorRatio=32
-XX:MaxTenuringThreshold=1
-Dfabric.debug.disableClassPathIsolation=false
```

Notes:
* `-Xmx4G` is a good default for 8 GB machines. Expose it as a slider; **do not** go above half the machine's RAM.
* G1 with a low pause target is what the major clients ship and what keeps frame times flat.
* The **Screen Recorder** encodes on a background thread. If a user records at 1440p/60 on a 4-core CPU, frames will be dropped (by design — see `VideoRecorder`). The launcher's recorder settings page should warn about this.

### 1.4 Bundled dependencies (already inside the jar)

The mod ships these as Fabric nested jars in `META-INF/jars/` — the launcher does **not** need to supply them:

* `jlayer-1.0.1.jar` — MP3 decode (music player)
* `jaad-0.9.4.jar` — AAC/M4A decode (music player)
* `jcodec-0.2.5.jar` — H.264 encode (screen recorder)
* JNA is compiled in for native window calls.

### 1.5 Files and folders the client uses

All relative to the game directory:

| Path | What |
|---|---|
| `config/blueclient/config.json` | all module state, HUD positions, settings, theme |
| `songs/` | drop-in folder for the music player |
| `recordings/` | screen recorder output, `blue-<timestamp>.mp4` (+ `.wav` if audio is on) |
| `screenshots/` | vanilla screenshots |

**The launcher must never write `config.json` while the game is running.** The client owns that file and rewrites it wholesale on save.

### 1.6 Share codes

The in-game modules menu can emit a `BLUE1-...` profile code (see `config/ProfileCode.java`). It is URL-safe Base64 of GZIP'd text — safe to put in a URL, a database column or a Discord message. A launcher-side "profile cloud" feature can store these strings verbatim and paste them back into the client's clipboard; no parsing needed on the launcher side.

### 1.7 Detecting Blue Client server-side

See `README-PLUGIN.md`. Short version: the client announces itself over a plugin message channel, and the server plugin grants 2× shards. The launcher plays no part in this.

---

## Part 2 — What the launcher should have

Ordered by value. Everything here is modelled on what the major clients actually ship.

### Tier 1 — you cannot launch without these

1. **Microsoft account login**, multi-account with a switcher, token refresh in the background, "remember me".
2. **Bundled Java 21** per-platform, so the user never installs anything.
3. **Version + mod management**: download and verify Minecraft, Fabric, Fabric API and Blue Client; checksum everything; self-heal a corrupt install.
4. **One big PLAY button** with a live progress bar and a clear error panel when something fails. Most launcher bug reports are "it says nothing and doesn't start" — always surface the log.
5. **Auto-update** for both the launcher and the client jar, with a changelog dialog.

### Tier 2 — the premium experience

6. **Discord Rich Presence.** Show: current server IP (or "Singleplayer"), game mode, elapsed time, and the Blue Client logo as the large asset. *Do this in the launcher, not the mod* — the launcher outlives the game session and keeps presence alive in the menus.
   * Application ID: register one at <https://discord.com/developers>.
   * Large image key: the Blue logo. Small image: the server icon if you have one.
   * Add a **"Join Blue Network"** button linking to the Discord invite.
7. **Settings page** mirroring what people actually change: RAM slider, JVM args (advanced, collapsed), game directory, resolution, "keep launcher open after launch", "close to tray".
8. **News / changelog feed** on the home page, driven by a JSON endpoint you control, so you can announce client updates without shipping a launcher build.
9. **Server list with one-click join** — pass `--quickPlayMultiplayer <ip>` on the command line (vanilla supports it since 1.20).
10. **Profile / cosmetics preview**: render the user's skin with their equipped Blue Client cape, using the same PNGs the mod ships in `assets/blueclient/textures/capes/`.

### Tier 3 — polish that makes it feel premium

11. **Crash reporting**: on a non-zero exit, capture `latest.log` + the crash report, show the last 40 lines, and offer "copy report".
12. **Performance profiles**: "Potato / Balanced / Max FPS" presets that write both JVM args and a starting `config.json`.
13. **Mod add-ons page**: let users add Sodium / Iris alongside Blue Client. Sodium warning: with Motion Blur on, "CPU Render-Ahead Limit" must be ≥ 5.
14. **Cloud profiles**: store `BLUE1-` share codes per account so settings follow the user between PCs.
15. **Built-in FFmpeg** for the screen recorder. This is the single biggest quality win available. The in-game recorder uses pure-Java JCodec because it must ship inside a mod jar; if the launcher places an `ffmpeg` binary in the game directory, a future client version can pipe raw frames to it and get hardware-accelerated encoding with audio muxed in. **This is the intended long-term path for recording — the current recorder is deliberately the conservative version.**
16. **Theming** matching the client: Black / Glass / White, same `#0B0E14` panel colour, same `#2FA5FF` accent, 2 px corner radius.

### Tier 4 — nice to have

17. Playtime statistics per server.
18. Screenshot gallery that reads `screenshots/` and `recordings/`.
19. "Repair installation" button.
20. Beta channel toggle.

---

## Part 3 — Things that will bite you

* **Do not repackage the mod jar.** It contains nested jars and a mixin config; re-zipping it with the wrong compression breaks Fabric's nested-jar loader.
* **Do not pass `-XX:+UseZGC`.** Minecraft's allocation pattern does badly with it; G1 wins in every benchmark that matters here.
* **Do not launch with Java 17 or 22+.** 21 exactly.
* **The mod writes its config on exit.** If you kill the process instead of letting it close, the user loses their last session's changes.
* **Mixin failures are fatal and loud.** If the client fails to start after a Minecraft update, the log will name the mixin. That is the next AI's starting point, not a mystery.
