# Microsoft login — why it fails and how to make it work

**Short version: this is not a bug in the code. Microsoft and Mojang will not
issue Minecraft tokens to an app they have not approved, and the app id shipped
in this build is a placeholder.**

You need your own Azure app id, approved for the Minecraft API, and you need to
put it in the config. That is the whole fix. It takes about ten minutes plus
Mojang's review wait.

---

## 1. What actually happens when you click "+ MICROSOFT ACCOUNT"

The client uses the **OAuth 2.0 device code flow**, the same one smart TVs use:

```
1. POST login.microsoftonline.com/consumers/oauth2/v2.0/devicecode
      -> returns a user_code ("ABCD-EFGH") and a URL (microsoft.com/link)
2. You open that URL on any device and type the code
3. The client polls  .../oauth2/v2.0/token  until you finish
      -> returns a Microsoft access token
4. POST user.auth.xboxlive.com/user/authenticate      -> Xbox Live token
5. POST xsts.auth.xboxlive.com/xsts/authorize         -> XSTS token + userhash
6. POST api.minecraftservices.com/authentication/login_with_xbox
      -> Minecraft access token                        <-- THE WALL IS HERE
7. GET  api.minecraftservices.com/minecraft/profile   -> your name + UUID
```

Steps 1–5 work with any Azure app. **Step 6 is gated**: Mojang returns

```
HTTP 403
{"path":"/authentication/login_with_xbox",
 "errorMessage":"Invalid app registration, see https://aka.ms/AppRegInfo"}
```

for every app that has not been through their approval process.

## 2. What v0.24.2 changed in the code

The flow was already written correctly. Two real bugs made it *undiagnosable*:

| Bug | Effect | Fix |
|-----|--------|-----|
| `code.get("user_code").getAsString()` ran before checking for an error response | A rejected app id threw a bare `NullPointerException`, and the accounts screen showed a blank notice — looking like "nothing happens" | Every response is validated; unknown/invalid client ids produce *"This Blue Client build has no valid Microsoft app id"* |
| HTTP status codes were thrown away (`.body()` only) | A 403 was indistinguishable from malformed JSON | Responses now carry `status` + `body`; a 403 at step 6 reports the app-registration problem by name |

So the login still will not work without an approved id — but it now **tells you
exactly why** instead of failing silently.

## 3. Register your own app (10 minutes)

1. Go to <https://portal.azure.com> → **Microsoft Entra ID** → **App registrations** → **New registration**.
2. Name it anything ("Blue Client").
3. **Supported account types**: *Personal Microsoft accounts only* (Minecraft accounts are personal accounts — this matters, and it must match the `/consumers/` endpoint the client uses).
4. Leave the redirect URI empty. Device code flow does not use one.
5. Register, then open **Authentication** → scroll to **Advanced settings** → set
   **Allow public client flows** to **Yes**. **This is mandatory.** Without it the
   token endpoint replies `AADSTS7000218` and demands a client secret that a
   desktop app cannot safely hold.
6. Copy the **Application (client) ID** from the Overview page.

## 4. Get it approved for the Minecraft API

Fill in Mojang's form: <https://aka.ms/mce-reviewappid>

They ask for the app id, what you are building, and contact details. Approval is
manual and takes anywhere from a few days to a few weeks. Until it lands, step 6
keeps returning 403 — that is expected and not something the client can bypass.

## 5. Put the id in the config

Edit `.minecraft/config/blueclient/config.json` (or use the in-game field in
*Accounts → app id*) and set:

```json
{
  "msClientId": "your-application-client-id-here"
}
```

Restart the game, click **+ MICROSOFT ACCOUNT**, and follow the code prompt.

## 6. Error messages you may now see

| Message | Meaning |
|---------|---------|
| "This Blue Client build has no valid Microsoft app id" | `msClientId` is the placeholder or an id Azure does not know. Do step 3. |
| "Microsoft app is not approved for Minecraft" | Steps 1–5 worked; Mojang has not approved the app. Do step 4. |
| "Xbox Live rejected the sign-in" | The account has no Xbox profile — sign in once at xbox.com to create one. |
| "This Microsoft account has no Xbox profile" (XErr 2148916233) | Same as above. |
| "Child accounts need adult sign-in" (XErr 2148916238) | The account is in a family group and needs an adult to approve it. |
| "This account does not own Minecraft" | Profile lookup returned 404 — Java Edition is not on this account. |
| "The code expired - try again" | The 15-minute device-code window elapsed. |

## 7. A note on what this feature can and cannot do

An account manager **stores and switches session tokens**. It cannot grant a
session for an account you do not own, and it cannot bypass Mojang's app review.
If you only need to change your display name on offline-mode servers, the
**cracked/offline** account option already works and needs none of the above.

## 8. For the next AI

- Code lives in `account/MsAuth.java` (flow + errors), `account/AccountManager.java`
  (storage), `gui/AccountsScreen.java` (UI).
- `MsAuth.State` is polled from the render loop: `done`, `success`, `error`,
  `userCode`, `verificationUri`, `account`. It is mutated from a daemon thread,
  hence every field is `volatile`.
- Do **not** "fix" this by hardcoding a client id scraped from another launcher.
  Those ids are tied to someone else's approval, they get rotated, and using them
  violates the Microsoft Identity Platform terms of use.
