# Blue Client v21 — Social release

Everything in v21 in one place: what shipped, what YOU still have to do, and
what the next AI needs to know before touching any of it.

---

## 1. WHAT YOU MUST DO BEFORE v21 WORKS

v21 is roughly half Java and half database. The jar alone will run, but every
social feature stays dark until the SQL is applied. **Three steps, in order.**

### Step 1 — apply the schema (Supabase SQL Editor)

Open your project → SQL Editor → paste and run, **in this order**:

1. `backend/schema_v2.sql`
2. `backend/schema_v3.sql`

Neither has been applied yet. `schema.sql` (v1) is already live — do not run it
again. Running them out of order will fail, because v3 alters tables v2 creates.

They are safe to re-run: every statement is `create or replace`,
`drop ... if exists`, or `add column if not exists`.

### Step 2 — deploy the join-verifier

```
supabase functions deploy verify-join
```

Then set its secret (Project Settings → Edge Functions → Secrets):

```
SERVICE_ROLE_KEY = <your service role key>
```

This is what proves someone owns the Minecraft account they claim. Without it,
premium verification silently fails and everybody stays unverified.

### Step 3 — create the staff accounts

Register `Blue` and `Cyan` in the client like normal users, then run:

```sql
select public.setup_staff();
```

This grants Founder (Blue) / Co-Founder (Cyan), every badge, forced
verification, and makes every new account auto-follow them.

**It is safe to run before either account exists** — it only touches whichever
of the two it finds, so run it again after the second one registers. Cyan
exists today and Blue does not; that is exactly the case it was built for.

### Optional but recommended

```sql
update private.app_secrets set value = '<a long random string>' where key = 'ip_salt';
```

This salts the per-IP account hashes. Change it **once, before launch** —
changing it later invalidates every existing hash and resets the 3-accounts-per-IP
counter for everyone.

---

## 2. WHAT'S NEW IN v21

### Social (was "Friends")

The screen is renamed and now has nine tabs, which **wrap onto a second line**
when the panel is too narrow. New tabs:

| Tab | What it does |
|-----|--------------|
| **POSTS** | Public timeline, X-style. Everyone sees everyone. Unlimited history. |
| **TOP** | Leaderboard of the five most-followed accounts. |
| **BLUE+** | Perks, price, and the redeem box. Shows your status if subscribed. |
| **SEARCH** | Was "ADD"; finds people by username. |

### Posts

- 25 characters free, 100 on Blue+
- 2 posts/hour free, 4/hour on Blue+
- The counter turns red **before** you hit send, so you are never surprised
- You can delete your own posts; nobody else's

### Verified badge

Automatic at **100 followers**, granted the instant you cross it — and **lost
if you drop below**. Blue and Cyan are force-verified and exempt.

### Buddies (fixed)

A buddy now needs **both people to agree**, and you get **one**. Sending a
request to someone who already sent you one pairs you both immediately.
Clearing a buddy clears it on both sides.

The old `set_buddy()` did none of this — it just wrote the column. It has been
dropped, and `buddy_id` is no longer writable by clients at all.

### Presence

A pill in the Social header cycles:

- **Online** — green dot, notifications arrive
- **Do Not Disturb** — red dot, notifications suppressed entirely
- **Appear Offline** — grey dot; you show as offline, your server is hidden,
  your last-seen is hidden, and you cannot be joined

Appear-offline is enforced **in SQL**, not in the client. A hidden player's
location is never sent to anyone, so no modified client can read it back out.

### Clickable notifications (right side)

Chat messages and server invites now slide in on the right and **respond to
clicks**: a message opens that conversation, an invite joins the server. The
little `x` dismisses. Nothing is queued at all while you are on DND.

### LAN invites (UPnP)

Inviting a friend while in a singleplayer world will:

1. open the world to LAN,
2. ask your router to forward that port over UPnP,
3. send your friend `publicIp:port`.

**UPnP only** — no relay, no VPS, nothing piggybacked on e4mc or World Host.
If your router refuses (UPnP disabled, or carrier-grade NAT), you are told so
plainly and offered the plain LAN port for people on your own network. The port
mapping is handed back when the game closes.

### Coloured nameplates

Blue+ subscribers can colour their name — solid hex, or a gradient, with
optional bold/italic. Gradients are rendered per character.

This costs **zero extra network requests**: the colour rides along on the bulk
badge lookup the nametag renderer already made. An expired subscription stops
colouring immediately, because entitlement is checked server-side per request.

### Social skin

Your Social avatar is set from a **Minecraft username**, so it works whether or
not that account is premium.

---

## 3. LIMITS

Defined **once** in SQL (`limit_of()`) and mirrored in `social/Limits.java` for
the UI. Changing the SQL changes the real limit for every client instantly,
including old jars — the Java copy only affects what the counter displays.

| | Free | Blue+ |
|---|---|---|
| About me | 50 | 100 |
| Status | 25 | 40 |
| Post | 25 | 100 |
| Posts/hour | 2 | 4 |
| Friends | 15 | 40 |
| Following | 15 | 50 |
| Followers | unlimited | unlimited |
| Coloured name | no | yes |

---

## 4. REDEEM CODES

One-time use, locked the moment they are redeemed, atomic (two people racing
the same code — only one wins).

Create one:

```sql
insert into public.redeem_codes (code, grants, plus_days, plus_permanent, note)
values ('SUMMER2026', 'plus', 30, false, 'summer promo');
```

- `grants` — `'plus'`, `'badge:<id>'`, or `'cosmetic:<id>'`
- `plus_days` — length of subscription; ignored when `plus_permanent` is true
- `plus_permanent` — **true = forever**

`CYANBLUEPLUS` and `BLUEPLUS` are seeded as **permanent** Blue+, as requested.

See who redeemed what:

```sql
select code, redeemed_by, redeemed_at from public.redeem_codes
 where redeemed_at is not null order by redeemed_at desc;
```

---

## 5. ANTI-ABUSE

**Max 3 accounts per IP.** The IP is never stored — only a salted SHA-256 hash
of it, so the table is useless to anyone who steals it.

Whitelist a shared connection (school, LAN cafe, your own house):

```sql
insert into private.ip_whitelist (ip_hash, note)
values (private.hash_ip('203.0.113.7'), 'my house');
```

Supabase Auth separately limits sign-ups to 30 per 5 minutes per IP.

---

## 6. EFFICIENCY — READ THIS BEFORE ADDING FEATURES

The constraint that shaped this whole release: **Supabase's free tier bills on
egress (5 GB/month, per organisation), not on request count.** Requests are
unlimited. Bytes are not.

What that bought us:

- **`sync(since)`** — one delta call replaces polling five separate endpoints.
  An idle client transfers **under 200 bytes** per poll.
- **The badge RPC carries colours and verification too**, so nameplates cost
  nothing extra.
- **`badges_for_players` omits players with nothing to show** — a server full
  of non-users returns an empty array, not a row each.
- **The badge cache refetches only when the player list actually changes.**
  Standing still on a server costs **zero** requests after the first.

Two rules for whoever works on this next:

1. **Never add a polling loop.** Extend `sync()` instead.
2. **Never fetch per player.** Batch it, and filter server-side so empty
   results are actually empty.

There was also a real MAU bug, now fixed: rotated refresh tokens were being
discarded, so one person re-authenticating constantly looked like ~150 monthly
active users. `setSessionListener` now persists the rotated token.

---

## 7. TESTING

The database has an adversarial test suite. **Run it after any schema edit.**

```bash
export PATH=/usr/lib/postgresql/17/bin:$PATH PGHOST=/tmp PGPORT=5433 PGUSER=postgres
pg_ctl -D /pgdata -l /tmp/pg.log -o "-p 5433 -k /tmp" start
psql -d postgres -c "drop database if exists bluetest;" -c "create database bluetest;"

# apply in this order
psql -d bluetest -f backend_test/00_supabase_shim.sql
psql -d bluetest -f work/backend/schema.sql
psql -d bluetest -f work/backend/schema_v2.sql
psql -d bluetest -f work/backend/schema_v3.sql

# then run the three suites
psql -d bluetest -f backend_test/attack.sql
psql -d bluetest -f backend_test/attack_v2.sql
psql -d bluetest -f backend_test/attack_v3.sql
```

**Current: 53 + 59 + 139 = 251 passing, 0 failing.**

### Three traps this suite has actually caught

1. **PASS lines are NOTICEs on stderr.** Count them with
   `2>&1 | grep -c 'NOTICE:  PASS'`, and grep for `ERROR:` separately.

2. **Compare PASS counts per suite, not just the failure count.** Dropping
   `set_buddy` made `attack_v2` silently fall from 59 to 55 — the tests did not
   *fail*, they *errored out*, which is invisible if you only watch for FAIL.
   The same thing happened again when `get_join_address` changed return type.

3. **The suite is not idempotent — rebuild the database every time.** It
   inserts fixed-id fixtures and redeems one-time codes. Re-running against a
   dirty database produces failures that are not real.

And the meta-lesson, which cost real time twice: **when a test fails, check the
test before you "fix" the code.** One failure here was a fixture that had
redeemed a *permanent* Blue+ code earlier in the file, which made a later
expiry assertion meaningless. The code was right; the test was wrong.

---

## 8. CROSS-PLATFORM (Linux + Mac)

There was no crash log for the Linux report, so this was done by auditing the
source for platform-specific hazards. **Two real defects were found** — the
suspect the owner named (window colour/title code) was *not* one of them.

### Fixed: AWT clipboard on macOS

`Screenshots.copyImageToClipboard` called `Toolkit.getDefaultToolkit()`. Since
LWJGL3, Minecraft runs with `java.awt.headless=true` and GLFW owns the first
thread; on macOS, AWT and GLFW both want the AppKit run loop, and touching AWT
can **deadlock the entire game**. A `try/catch` cannot save you from a deadlock
— the only fix is not to make the call. It is now refused on macOS and under
any headless JVM. The screenshot still saves; only the clipboard copy is
skipped.

### Fixed: FreeType buffer use-after-free

`BlueFont` loaded fonts with `FT_New_Memory_Face`, which does **not** copy —
the face reads from your buffer for its entire life. That buffer was a local
variable, so the memory was never freed *and* nothing kept a reference to free
it later. It is now a field, and `close()` destroys the face **before**
releasing the bytes. Getting that order backwards is a use-after-free, which on
Linux and macOS is typically a hard JVM crash rather than an exception.

### Checked and cleared

- `WindowStyle` — already guarded to Windows and to JNA being present
- `DiscordPresence` — `%APPDATA%` with a `user.home` fallback, correct
- No `sun.misc`, no `jdk.internal`, no hardcoded Windows paths
- No uppercase resource identifiers (these break on case-sensitive filesystems)
- `Util.getOperatingSystem().open(...)` used for opening files, which is
  already cross-platform

### Still open

The Java 27 `IllegalAccessError` in `Fullbright` was fixed in v21 (a
split-package class implementing a package-private Minecraft interface). If the
friend on Arch hits anything else, **a log would settle it in minutes** —
`.minecraft/logs/latest.log` or the `crash-reports/` folder.

---

## 9. NOTES FOR THE NEXT AI

Hard-won, in rough order of how much time each one cost:

- **`javap` the Minecraft class before you mixin.** `Screen` does **not**
  declare `mouseClicked` — it inherits the default from `ParentElement`. v11
  injected into `Screen.mouseClicked`, the hook never bound, and the pause menu
  was broken for a whole release with no error message. The new
  `SocialToastClickMixin` targets `ParentElement` for exactly this reason.
  `verify_mixins.py` checks all 41 mixin classes; **never disable it.**

- **RLS grants are the real enforcement surface.** Adding a consent RPC is
  worthless if the column stays in `grant update (...)`. A direct-UPDATE test
  caught precisely this for `buddy_id`.

- **A subquery inside an RLS policy is itself RLS-filtered.** Route cross-user
  checks through a `security definer` helper. This trap was hit twice.

- **`create or replace function` cannot change a return type** — `drop` first.
  Hit again in v21 with `get_join_address`.

- **Scripted edits produce plausible garbage.** Re-read every patched region.
  A patch referencing a method you have not written yet compiles only after you
  write it — which happened with `ProfileScreen.notice` and again with
  `drawPosts`/`drawTop`/`drawPlus`.

- **Centring text: measure with the same font you draw with, and round once.**
  The off-centre "Joining Blue Network" was `interTextWidth()` (which ceils)
  divided by an integer 2 — two roundings in the same direction. v21 swept
  every occurrence of this, not just the reported one.

- **A cosmetic feature must never be able to kill the game.** Everything that
  touches native code, reflection, or another player's data is wrapped and
  fails to "off" rather than throwing.

- **`runClient` is impossible in this sandbox.** The owner's reports are the
  only runtime signal that exists. Compile-time and database checks are
  therefore worth far more here than they would be normally.
