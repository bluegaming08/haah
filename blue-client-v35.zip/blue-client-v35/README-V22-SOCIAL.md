# Blue Client v22 (0.25.5) — what changed and why

This is the handover for the next AI **and** for the owner. Read the
"Owner must do this" section first; two of the items below do not work until
you run something.

---

## 1. Owner must do this

### 1.1 Apply the schema (REQUIRED — most of v22 is server-side)

In the Supabase SQL editor, in this order:

```
backend/schema_v2.sql      <- if not already applied
backend/schema_v3.sql      <- contains the new sections 16-19
```

`schema_v3.sql` is **idempotent** — safe to re-run. Then:

```sql
select public.setup_staff();
```

Nothing in Posts (like / reply / repost / For You) works until this is applied,
because those RPCs do not exist in the database yet.

### 1.2 Microsoft login — this one needs YOUR Azure app

You reported: *"no valid microsoft app id, set msClientId in config"*.

**That message is correct behaviour, not a bug.** I tested the device-code
endpoint with three client ids, including the one built into the client:

| client id used | Microsoft's reply |
|---|---|
| `00000000402b5328` | `unauthorized_client` / AADSTS700016 |
| `c36a9fb6-…` (built-in fallback) | `unauthorized_client` / AADSTS700016 |
| `389b1b32-…` | `unauthorized_client` / AADSTS700016 |

AADSTS700016 means *"application not found in the directory"*. There is **no
public Microsoft app id** that a third-party client may use — Microsoft
removed them. So there are exactly two ways forward:

* **A.** Register a free Azure app yourself (Azure Portal → App registrations →
  new → allow public client flows → copy the Application (client) ID into
  `msClientId` in the config). Ten minutes, no cost.
* **B.** Use the Azure-free path already built: `joinServer` / `hasJoined`. It
  proves Minecraft ownership through Mojang's own session server and never
  touches Azure. See `README-MICROSOFT-LOGIN.md`.

I cannot do either for you — A needs your Microsoft account, B needs the
`verify-join` Edge Function deployed with a service-role key.

---

## 2. The stuck-friend-request bug — root cause

You reported: *"when I accept a friend request it shows in requests AND
friends, and I have to close the menu and reopen."* Those are one bug.

`sync()` ended with `json_strip_nulls()` wrapped around the **whole** payload.
`json_agg` returns SQL `NULL` for zero rows, so when your last request cleared,
the `r` key was not sent as an empty list — **it was deleted from the JSON
entirely**. Proof:

```sql
select json_strip_nulls(json_build_object('v',1,'r',null::json,'f',json_build_array(1)));
-- {"v":1,"f":[1]}      <- no "r" at all
```

And the client contract (`FriendsManager.applySync`) says an **absent key means
"unchanged"**, not "now empty". So the client kept the old list forever. The
request only disappeared when you reopened the screen and did a full reload.

**Fixed in schema_v3 section 16.** Every list is now
`coalesce(..., '[]'::json)`, so "now empty" is stated explicitly.
`json_strip_nulls` is still applied **per row** — null fields inside a row are
pure waste — but never to the envelope again.

> **Rule for the next AI:** in any delta protocol, "empty" and "unchanged" must
> be different messages on the wire. Never strip nulls from a delta envelope.

Two further gaps found while fixing it:

* **`ro` (outgoing requests) did not exist.** The *sender* was never told their
  request had been resolved, so it sat in their list forever. Added, and
  handled in `applySync`.
* **The `since` cursor was a timestamp**, which cannot detect deletes at all —
  a removed row has no timestamp to compare. Replaced with a **revision
  counter** (section 17): `profiles.social_rev`, bumped by triggers on
  friendships, requests, invites and presence.

---

## 3. "I shouldn't have to close and reopen the menu"

Two causes, both fixed:

1. `REFRESH_OPEN_MS` was **30 seconds**. Half a minute of stale data looks
   identical to a broken screen. Now **3 seconds**.
2. Actions did not refresh — they waited for the next poll. There is now
   `FriendsManager.refreshNow()`, called after accept / block / redeem / etc.,
   which also **resets the poll timer** (otherwise a tick firing moments later
   overwrites the fresh data with stale data).

**This does not cost more egress**, which is why it is safe. With the revision
cursor, a poll where nothing changed returns only the cursor and your own
counters — about **90 bytes** instead of the full lists. Twenty polls a minute
is ~1.8 KB/min against a 5 GB/month ceiling. Measured: an idle payload went
from **299 B → 233 B → ~90 B**.

---

## 4. The blue check mark "isn't working"

It was drawn as the Unicode character **U+2713** through the Poppins renderer.
I checked all three bundled fonts with fontTools:

```
poppins-semibold.ttf    -> U+2713 MISSING
poppins-medium.ttf      -> U+2713 MISSING
minecraft-five-bold.ttf -> U+2713 MISSING
```

The glyph does not exist, so it rendered as **nothing at all**. Silently.

**Fixed:** `ui/VerifiedBadge.java` draws the badge as **geometry** — a blue
seal with a white tick built from primitives. It cannot break if the font
changes, and scales to any size. It now appears in Social lists, posts,
replies, the leaderboard and profiles.

In-world **nametags** cannot use a draw call (they build a `Text`), so they use
`VerifiedBadge.NAMETAG_GLYPH` = **U+2714**, which *is* covered by Minecraft's
own font. Verified by the same audit.

> **Rule for the next AI:** a missing glyph fails silently. Check font coverage
> before drawing a symbol — do not assume Unicode means available.

---

## 5. The profile-picture bug

*"I typed a username and pressed done and it didn't do anything."*

`ProfileScreen.commitEdit()` handled `"about"` and `"status"` — and simply had
**no branch for `"skin"`**. Pressing Enter dropped the value on the floor. (The
APPLY SKIN button worked; Enter, which is what people actually press, did not.)

Fixed, and it now also calls `PlayerHeads.forget(name)` so the new skin is
fetched instead of the old one being served from cache.

---

## 6. Posts: like, reply, repost, and a real feed algorithm

### Schema (sections 18–19)

* `post_likes` and `post_reposts`, both keyed `(post_id, user_id)` — a double
  like is impossible **at the schema level**, not by client discipline.
* A **reply is just a post with `parent_id` set**. One table, one code path.
* A **repost is a row, not a copied post**, so deleting the original cleanly
  removes every repost of it by cascade.
* Counters (`like_count`, `reply_count`, `repost_count`) are denormalised onto
  `posts` and kept by triggers — counting rows per post per feed render would
  be the most expensive query in the app.
* Writes go **only** through `toggle_like` / `toggle_repost` / `reply_to_post`.
  The tables have `revoke insert, update, delete ... from authenticated`, so a
  crafted client cannot like on someone else's behalf or bypass a block.
* Replies obey the **same** character cap and hourly rate limit as posts — a
  reply is a post, so exempting it would make the limits meaningless.

### Two feeds

**`get_feed()` — Following.** Strictly reverse-chronological: people you
follow, plus yourself, plus **their reposts** (tagged with who boosted it, so
the UI can draw "Alice reposted"). No ranking — if you deliberately followed
someone you want everything, in order.

**`get_for_you()` — the algorithm.** Hacker-News-style score:

```
score = (2*likes + 3*reposts + 2*replies + 1) / (hours_old + 2)^1.5
```

* Reposts weigh most — resharing is the strongest signal.
* The `+1` keeps brand-new posts with no engagement visible.
* The `1.5` exponent makes a post decay over hours, so the feed keeps moving
  instead of freezing on one viral post.
* Posts from people you follow get a **1.5× boost**.
* **Your own posts are excluded** — nobody needs an algorithm to show them
  their own writing.
* Capped to a **7-day window**, and it reads only the denormalised counters
  (no joins onto the like tables), so it stays a small indexed scan.

Both feeds exclude replies from the timeline — a reply belongs under its
parent, which is what the new **thread view** shows.

---

## 7. UI — making it feel premium

You said the account manager feels premium and Social does not. The difference
was **motion**: Social had literally zero animation and snapped between states.

* **`ui/Anim.java`** — a small easing helper. Crucially it is
  **frame-rate independent**: the step comes from elapsed milliseconds, not a
  per-frame increment, so animations take the same wall-clock time at 30 fps
  and 240 fps. (A fixed increment is a classic bug that makes the whole UI run
  at double speed on a fast machine.)
* Animated: tab pills, post cards (fill *and* border ease toward the accent),
  engagement buttons (a liked heart pops slightly larger), the feed switcher,
  and a **panel entrance** that eases up to full size over 180 ms.
* **Avatars everywhere** — posts, replies, friend rows, the leaderboard, and
  notifications. Friend rows now put the presence dot **on the avatar corner**,
  the way every chat app does, instead of a lone dot beside the name.
* Avatars fall back to the player's initial on a stable tinted disc while the
  skin loads, so the layout never jumps.

### Badges now have icons

Nine badges, each mapped to a shipped sprite in `ui/BadgeArt.java`:

| badge | icon | badge | icon |
|---|---|---|---|
| founder / co_founder | `gem` | tester | `flag` |
| verified | `check` | beta_tester | `flame` |
| plus | `sparkles` | supporter | `award` |
| helper | `hand` | famous | `trending-up` |

They render as a tinted pill (icon + label washed in the badge's own colour).

> **Warning for the next AI:** `RenderUtil.drawIcon` with an unknown sprite
> name draws **nothing** and throws no error. Every name above was checked
> against `textures/gui/sprites/icon/`. There is no `monitor` or `star` sprite
> — I tried both and had to correct them.

---

## 8. Instagram-style notifications

`SocialToasts.Kind` now covers **eight** events: MESSAGE, INVITE, LIKE, REPLY,
REPOST, FOLLOW, REQUEST, ACCEPTED — each with its own colour, icon and
click action. Toasts show the sender's **face** with the event icon on the
corner, exactly like Instagram.

**`notification/NotificationInbox.java`** is the new Activity list. A toast
lives four seconds; if you are mining when someone likes your post you would
never know. Every toast also lands in the inbox, shown in the new **ACTIVITY
tab** with an unread red dot.

It is **memory-only on purpose** — writing an activity row per like would
multiply database writes for something nobody reads twice, and egress is the
real ceiling. Capped at 60 entries.

Notifications fire by **diffing sync state**, and deliberately:
* never announce on the **first** sync (`syncCursor == 0`), or logging in would
  fire a burst of toasts for things you already knew;
* stay silent when your presence is **dnd**;
* say nothing when a request is **declined** — nobody needs a notification
  telling them they were rejected.

---

## 9. Blue+

* **New settings category.** `Category.BLUE_PLUS` is **hidden entirely** for
  free users (`Category.visible()`), not greyed out — an empty locked category
  is clutter, and the Blue+ tab is where the upsell belongs. It holds the new
  `BluePlusPerks` module (logo / coloured name / badge / supporter duration).
* **Entitlement is never trusted from the client.** Every accessor re-checks
  `friends().plus()`, which reflects what the *server* said. Flipping a toggle
  cannot grant a perk — the database decides, and the data is not sent to
  non-subscribers at all.
* **The logo.** Your PNG (`i.postimg.cc/MHZTLqtF/Blue-Plus.png`) arrived as
  532×800 **RGB with no alpha** — a gold "B" on solid black, which would have
  drawn as an opaque black rectangle. I keyed it to transparency on a luminance
  threshold with a feathered edge, cropped to the glyph (462×717), and padded
  it into the same 512×512 / 340-wide geometry the normal logo uses so the two
  are interchangeable.
* It replaces the Blue logo **everywhere** for subscribers via a single
  `RenderUtil.brandSprite()` — one chokepoint, rather than editing a dozen call
  sites and missing some.
* **Price is now `$4.99/month`** with `PLUS_TERMS = "One-time payment - no
  auto-renewal"`. The UI no longer says *"Renews"* anywhere — it says **"Active
  until"**, because there is no auto-renewal.

---

## 10. Main menu

* **SOCIAL** is now a fourth big button under OPTIONS, filled with the brand
  accent, with a breathing glow and a live badge counting pending requests +
  unread messages. Uses the same `users` icon Friends had.
* The floating **VANILLA** chip that sat under the account card looked like a
  stray tag; it moved into the bottom dock next to QUIT GAME with the other
  client-level actions.

---

## 11. Test status

```
attack.sql      53 PASS   0 FAIL   0 ERROR
attack_v2.sql   59 PASS   0 FAIL   0 ERROR
attack_v3.sql  173 PASS   0 FAIL   0 ERROR
                ---
TOTAL          285 PASS
```

Up from 251 at the v21 baseline. The new blocks are **16** (the emptied-list
contract), **18** (engagement: idempotent likes, RPC-only writes, reply caps,
cascade deletes, no self-reposts) and **19** (the ranking: hot beats cold, your
own posts excluded, the 7-day window, blocks respected, reposts attributed).

Build: `BUILD OK`, **41 mixin classes all resolve**, `verify_jar` clean.

### How to re-run

```bash
export PATH=/usr/lib/postgresql/17/bin:$PATH PGHOST=/tmp PGPORT=5433 PGUSER=postgres
pg_ctl -D /pgdata -l /tmp/pg.log -o "-p 5433 -k /tmp" start
psql -d postgres -c "drop database if exists bluetest;" -c "create database bluetest;"
psql -d bluetest -f backend_test/00_supabase_shim.sql
psql -d bluetest -f backend/schema.sql
psql -d bluetest -f backend/schema_v2.sql
psql -d bluetest -f backend/schema_v3.sql
for f in attack attack_v2 attack_v3; do psql -d bluetest -f backend_test/$f.sql; done
```

**PASS lines are NOTICEs on stderr** — use `2>&1 | grep -c 'NOTICE:  PASS'`.
**Always rebuild the database**: the adversarial fixtures mutate shared state
and the suites are not idempotent. **Always compare per-suite counts** — a
schema change can silently cost an older suite several passes while the total
still looks healthy.

---

## 12. Two lessons worth keeping

**A failing old test can be hiding a real new bug.** The "idle sync is under
200 bytes" assertion failed after the section-16 fix. The lazy move was to
relax the threshold. Investigating instead exposed *two* genuine regressions:
per-row nulls were being emitted, and the friends list ignored the cursor
entirely. Both are now fixed, and the idle payload is ~90 B.

**But a test can also just be wrong.** One of the four failures was my own new
fixture calling `public.send_friend_request(...)`, which **does not exist** —
requests are created by a direct INSERT guarded by RLS. The test was fixed to
do what the client actually does, rather than the schema being changed to suit
a bad test.

---

## 13. Not done

* **Microsoft login** — blocked on your Azure app or the Edge Function (§1.2).
* **Follow / like / repost notifications are not yet pushed from the server.**
  REQUEST and ACCEPTED fire from sync diffing; LIKE, REPLY, REPOST and FOLLOW
  raise correctly when something calls `SocialToasts.social(...)`, but the
  server has no channel to tell you about engagement on *your* post while you
  are offline. That needs either a `notifications` table in the sync payload or
  Supabase Realtime. **Deliberately deferred** — a notifications table is a
  write per like, and I did not want to spend your egress without asking.
* **Nothing in v16–v22 has run in a real game.** `runClient` is not possible in
  this environment, so your reports are the only runtime signal.
