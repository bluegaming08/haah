# Blue Client v23 (0.25.6) — X-style Social + launcher bridge

Two things shipped in this release:

1. **The Social GUI was rebuilt to look like X (Twitter)** — new layout, new
   components, new palette, every pane.
2. **The launcher integration contract** — three interchange files so the Blue
   Client launcher can sign you in, read live social state with zero API calls,
   and hand over a Minecraft session.

---

## 1. The Social GUI rebuild

### 1.1 Why it looked wrong before

The old screen was a 560×420 box with **ten tab pills wrapping onto three
lines**. That is the single biggest reason it read as a debug menu: ten
equal-weight chips with no hierarchy, no icons, and no room to breathe. Next to
the account manager — which has big avatars, generous spacing and a clear
focal point — it looked unfinished, and the owner was right to say so.

### 1.2 The new layout

The canvas is now **880×470** and uses X's three-column structure:

```
┌──────────────┬───────────────────────────┬──────────────────┐
│  NAV RAIL    │  CENTRE COLUMN            │  SIDEBAR         │
│  logo        │  sticky header + tabs     │  your stats      │
│  Home        │                           │  get verified    │
│  Notifs  (4) │  composer                 │  who to follow   │
│  Messages    │  ─────────────────────    │                  │
│  Friends     │  post                     │                  │
│  Requests(1) │  ─────────────────────    │                  │
│  Explore     │  post                     │                  │
│  Top         │  ─────────────────────    │                  │
│  Blue+       │                           │                  │
│  [ Post ]    │                           │                  │
│  @you        │                           │                  │
└──────────────┴───────────────────────────┴──────────────────┘
```

* **Left rail** — icons + labels, unread badges, the big **Post** button, and
  your account card pinned to the bottom. Secondary destinations (Blocked,
  Privacy) are visually demoted the way X demotes Settings.
* **Centre column** — a sticky header with the page title, and for the timeline
  a **For you / Following** switcher with X's growing underline (not a filled
  pill).
* **Right sidebar** — your follower/following/friend counts, a **verified
  progress bar** toward 100 followers, and "Who to follow" built from the
  leaderboard. It **auto-hides below 700px** so a small window degrades to two
  columns instead of crushing three.

### 1.3 `ui/XKit.java` — the new design system

Every control now comes from one kit, so consistency is structural rather than
a matter of discipline. It provides `pill`, `navItem`, `action`, `avatar`,
`inputBox`, `divider`, plus `compact()` (1.2K / 3.4M), `shortAge()` (2h / 3d /
1w), `wrap()` and `fit()`.

**Palette** (X's dark theme):

```
canvas  #000000   surface #16181C   divider #2F3336
text    #E7E9EA   muted   #71767B
accent  #1D9BF0   like    #F91880   repost  #00BA7C
gold    #FFD400   danger  #F4212E
```

The old local `GREEN` / `RED` / `GREY` / `PLUS_GOLD` constants were **near-misses
of these values** and were quietly making panes look inconsistent with each
other. They are deleted; there are now **zero** `DesignTokens.` references left
in the Social screen and 228 `XKit.` ones.

### 1.4 Post cards

Rebuilt to X's timeline item: fixed avatar gutter, one content column holding
the author line (name → verified tick → Blue+ → badge → `@handle · 2h`), the
**wrapped** body, then the action row. No border, no card fill — items are
separated by hairlines only.

* **Body text now wraps.** It previously ran straight off the side of the card.
* Card height is computed from the wrapped line count, so posts are no longer
  all forced to one fixed height.
* Actions use X's tinted hover disc; a liked flame pops one pixel larger.
* **The Share button is gone**, per the owner's request.
* Clicking anywhere on the card opens the thread; clicking the name opens the
  profile.

### 1.5 Every other pane

| Pane | What it is now |
|---|---|
| **Friends** | Full-bleed rows, 30px avatar with a **ringed presence dot on the corner**, verified/Blue+/badge inline, and **icon-only actions with tooltips** instead of five permanent text buttons. |
| **Requests** | Incoming / Sent sections, avatars, Accept (filled) + Decline (outlined) pills. |
| **Messages** | 28px avatar (or a group icon disc), title, preview, blue unread pill. |
| **Explore** | X's rounded search field with the magnifier inside, result rows with avatars and an **Add** pill, or "Friends" / "Requested" state text. |
| **Notifications** | Event icon in the gutter tinted by kind, actor avatar, terse age. |
| **Top** | Ranked rows with gold/silver/bronze medals, avatars, `@handle`, follower counts. |

Every empty state is now an **icon + headline + explanation** (`emptyState()`)
rather than a bare grey line. X never just says "nothing here" — it tells you
what will appear and why.

### 1.6 Blue+ settings — the missing feature

The owner asked twice: *"where are the Blue+ settings I wanted"* and *"the
coloured names aren't there because you didn't add Blue+ settings."*

**They were right, and the diagnosis was exact.** The server RPC
(`set_name_color`) and the renderer (`NameColor.parse` / `blend`) both already
existed and worked. **Nothing in the UI ever called them**, so coloured names
could not be switched on at all.

The Blue+ tab now branches:

* **Non-subscribers** — the pitch: hero mark, `$4.99/month`, "One-time payment,
  no auto-renewal", the perk list, and the redeem box.
* **Subscribers** — the actual **settings panel**:
  * status card (Permanent / Active until … — never *"renews"*)
  * a **name-colour studio**: 10 swatches, gradient / bold / italic toggles, a
    start-vs-end colour selector, and a **live preview of your own username**
    rendered with a per-character gradient blend
  * **Apply** and **Clear**
  * redeem-another-code box

The draft seeds from your saved colour on first open, so the studio shows what
you currently have rather than a default blue. Colours apply on an explicit
**Apply** — a live picker would fire a network write on every drag.

There is also a `BLUE_PLUS` module category, **hidden entirely for free users**
(not greyed out), holding the `BluePlusPerks` module. Entitlement is re-checked
against the server on every access; flipping a toggle cannot grant a perk.

### 1.7 Main menu fixes

* **The SOCIAL button's glow is gone.** It now uses the identical
  `menuButton` material as Singleplayer / Multiplayer / Options.
* **FRIENDS removed from the bottom dock** — the SOCIAL button replaces it.
* **The logo is now genuinely high-res.** Both `brand/logo.png` and
  `brand/blueplus.png` were rebuilt at **1024×1024** (was 512). The old sprite
  squeezed the 532×800 master into a 340×512 art column, discarding ~36% of its
  vertical detail — that softness was the bug. The **340/512 ratio is
  preserved** at 680/1024, so no layout code changed.

---

## 2. The launcher bridge

`social/LauncherBridge.java`. Three files in `config/blueclient/`.

### 2.1 `social-state.json` — written by the mod

The launcher reads this to render a **live friends sidebar during gameplay with
zero API calls**.

```json
{
  "schema": 1, "written_by": "blueclient",
  "updated_at": "…", "logged_in": true, "username": "BlueDev",
  "social_rev": 12345,
  "blue_plus": { "active": true, "expires_at": 1741996800, "permanent": false },
  "unread": { "friend_requests": 1, "messages": 0, "notifications": 4 },
  "friends": [ { "id": "…", "username": "Cyan", "online": true,
                 "server": "…", "presence": "online", "skin": "…",
                 "verified": true, "plus": true, "badge": "co_founder",
                 "name_color": "…" } ]
}
```

Three properties that matter:

* **Atomic write** (tmp + rename). The launcher can read at any instant; a
  plain write can be observed half-finished and would parse as truncated JSON.
* **Write-on-change only.** The sync loop runs every 3s; the payload is compared
  against the last one written and skipped if identical. `updated_at` is
  deliberately excluded from that comparison — including it would change every
  call and defeat the optimisation entirely.
* **`social_rev`** lets the launcher resume `sync(since=rev)` when the game
  exits, with no full-payload re-fetch.

**Why the full friends list and not just counts:** the launcher raised the size
concern, but friends are **server-capped at 15 free / 40 Blue+**, so worst case
is ~5 KB. Counts-only would have left the launcher still polling Supabase to
render anything useful, which defeats the point of the file.

### 2.2 `launcher-handoff.json` — written by the launcher

Metadata only: username, launcher version, Blue+ hint. **No token.**

The Supabase refresh token stays in `social-session.txt`, single owner. Supabase
*rotates* refresh tokens and the mod persists every rotation; if the token also
lived in a launcher-written JSON the two could disagree, and the stale one would
force a full sign-in — which Supabase bills as a **new monthly active user**.
The launcher proposed this split and it is correct.

Every field is a **hint**. The `sync()` response always wins.

### 2.3 `minecraft-session.json` — written by the launcher

`access_token` + `minecraft_uuid` + `expires_at`. The UUID is **required**, not
optional: the call is `joinServer(uuid, accessToken, serverId)`.

When present and unexpired the mod skips its own Microsoft flow. The Azure-free
`joinServer`/`hasJoined` path remains the fallback.

**Why:** the mod's Microsoft login is dead. Three client IDs were tested,
including the built-in fallback, and all returned **AADSTS700016** — "application
not found in the directory". Microsoft no longer publishes a usable public app
ID. A launcher with its own Azure registration is the real fix. The in-game
error message now says so, and detects when a launcher session is already
present.

### 2.4 The `Friend` record was extended

`sync()` has always sent `sk` / `v` / `pl` / `b` / `c` / `pr` for each friend and
**the client was throwing them away**. They are now kept, which is what lets
friend rows show avatars, ticks and coloured names — and what populates
`social-state.json`.

A 5-arg convenience constructor is retained so older call sites still compile.

---

## 3. Status

```
Build            BUILD OK
Mixins           41 classes, all targets resolve
Backend tests    53 + 59 + 173 = 285 PASS, 0 FAIL, 0 ERROR
```

Schema unchanged this release — **`schema_v3.sql` from v22 is still what you
need to run** if you have not already.

---

## 4. Still outstanding

* **The release manifest URL** for the launcher's update system. Until it
  exists, the launcher pins `0.25.5` + its SHA-256 locally and reports "update
  service not configured". Current jar hash:
  `33bc398fe5bdc2003bb157a767b47f47ab1cd914e927b1bbce13f7114af62cc4`
* **Server-pushed engagement notifications.** Likes/replies/reposts/follows
  raise toasts correctly client-side, but the server has no channel to tell you
  about engagement on your post while you are offline. Needs a `notifications`
  table or Supabase Realtime — deliberately deferred, since a table means a
  write per like and that spends egress.
* **Nothing in v16–v23 has run in a real game.** `runClient` is not possible in
  this environment, so owner reports remain the only runtime signal.
