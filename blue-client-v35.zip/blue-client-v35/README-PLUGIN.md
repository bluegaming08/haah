# Blue Network — "BlueClientBoost" Server Plugin Specification

**For:** whoever writes the Paper/Spigot plugin for Blue Network (a human or the next AI).
**Goal, in the owner's words:**

> make another readme for a plugin that i can add to my server, blue network, that detects blue client users and gives them 2x shards. it must link with the donutcore plugin that already handles shards, not override it.

**The single hardest rule in this document: DonutCore owns shards. This plugin never does.**

---

## 1. What the plugin does

1. Detects, reliably, whether a joining player is running Blue Client.
2. When such a player is about to be awarded shards by **DonutCore**, doubles the amount.
3. Shows a small "2× Shards — Blue Client" indicator and logs the multiplier for staff.
4. Does nothing at all to players who are not on Blue Client.

That is the whole scope. Resist adding a shard command, a shard balance, or a shard database — those exist in DonutCore already and duplicating them is how economies get corrupted.

---

## 2. Detecting Blue Client

### 2.1 The mechanism: a plugin message channel

Blue Client announces itself over Minecraft's plugin-messaging system, the same mechanism the major clients use. It is the only detection method that is both reliable and impossible to confuse with a vanilla client.

**Channel:** `blueclient:hello`

**Client → server**, sent once, about one second after the player finishes joining (long enough that the server has registered its own channel listener):

| Field | Type | Meaning |
|---|---|---|
| protocol | VarInt | currently `1` |
| version | String | client version, e.g. `"0.24.0"` |
| mc | String | Minecraft version, e.g. `"1.21.11"` |

**Server → client**, optional reply on the same channel:

| Field | Type | Meaning |
|---|---|---|
| accepted | Boolean | server acknowledges the client |
| multiplier | Float | shard multiplier in effect, e.g. `2.0` |

The client uses the reply only to show the player a "2× Shards active" toast. If the server never replies, nothing breaks.

### 2.2 Registering the channel (Paper)

```java
@Override
public void onEnable() {
    getServer().getMessenger()
        .registerIncomingPluginChannel(this, "blueclient:hello", new HelloListener(this));
    getServer().getMessenger()
        .registerOutgoingPluginChannel(this, "blueclient:hello");
}
```

### 2.3 Trust model — read this before you "improve" detection

A plugin message can be forged by any modded client. **This detection is a convenience, not a security boundary.**

That is acceptable here because the reward is a soft economy bonus, not an admin permission. What you must *not* do:

* do not tie a permission, a rank or a purchase to this signal;
* do not ban or punish anyone based on it;
* do not treat absence of the message as proof of anything (a slow connection can delay it).

If you later need real proof, the answer is a signed token from your own auth backend, not a cleverer packet.

### 2.4 Fallback: brand detection

Blue Client also sets the client brand (`minecraft:brand`) to `fabric (BlueClient/0.24.0)`. Use this only as a secondary signal. It is weaker than the hello packet and just as forgeable.

---

## 3. Linking with DonutCore — the important part

### 3.1 Three integration strategies, best first

#### Strategy A — DonutCore's own multiplier API (do this if it exists)

Most shard/economy cores expose a multiplier or booster registry. Look in DonutCore's source or javadoc for something like `MultiplierRegistry`, `BoosterAPI`, `registerMultiplier`, or a `ShardMultiplierProvider` interface. If one exists, use it:

```java
DonutCoreAPI.multipliers().register(new ShardMultiplier() {
    @Override public String id() { return "blueclient"; }
    @Override public double multiplierFor(Player player) {
        return BlueClientTracker.isBlueClient(player) ? 2.0 : 1.0;
    }
});
```

This is by far the best option: DonutCore stays the only thing that adds shards, it decides how our multiplier stacks with its own boosters, and nothing can double-apply.

#### Strategy B — a cancellable shard event (do this if A is unavailable)

If DonutCore fires an event before awarding shards, listen at `MONITOR`-adjacent priority and modify the amount:

```java
@EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
public void onShardGain(DonutShardGainEvent event) {
    Player player = event.getPlayer();
    if (!BlueClientTracker.isBlueClient(player)) return;
    if (event.getSource() == ShardSource.ADMIN) return;   // never double a staff grant
    event.setAmount(event.getAmount() * 2);
    // Do NOT also call an API that adds shards. Modify the event, full stop.
}
```

Use `HIGH`, not `HIGHEST` or `MONITOR`: other plugins may legitimately want the final say, and `MONITOR` must never mutate an event.

#### Strategy C — top-up (last resort, and be careful)

If DonutCore offers neither an API nor an event, the only route left is to observe a shard gain and add the same amount again:

```java
DonutCoreAPI.shards().give(player, gained, "blueclient-2x");
```

Dangers, all of which have bitten people before:

* **Re-entrancy** — your top-up triggers the same observation and loops forever. Guard with a per-player `ThreadLocal`/`Set<UUID>` re-entrancy flag.
* **Double-counting on reload.** Never persist your own shard state.
* **Races** across async event handlers. Always mutate the economy on the main thread.

Only use Strategy C if you have confirmed A and B do not exist.

### 3.2 The rules, restated

* **Never write to DonutCore's database directly.** Always go through its API.
* **Never register your own `/shards` command or balance display.** DonutCore owns those.
* **Soft-depend, never hard-fail.** In `plugin.yml`:
  ```yaml
  name: BlueClientBoost
  version: 1.0.0
  main: net.bluenetwork.boost.BlueClientBoostPlugin
  api-version: '1.21'
  softdepend: [DonutCore]
  ```
  On enable, if DonutCore is missing, log a clear warning and disable the multiplier — do not crash the server.
* **Load order matters.** `softdepend` makes DonutCore load first, so its API is ready when you hook it.

---

## 4. Suggested file layout

```
BlueClientBoost/
├── pom.xml
├── src/main/resources/
│   ├── plugin.yml
│   └── config.yml
└── src/main/java/net/bluenetwork/boost/
    ├── BlueClientBoostPlugin.java   plugin entry point, wires everything
    ├── HelloListener.java           reads blueclient:hello, marks the player
    ├── BlueClientTracker.java       Set<UUID> of detected players, cleared on quit
    ├── DonutCoreBridge.java         ALL DonutCore contact lives here, nowhere else
    └── BoostListener.java           the multiplier hook (Strategy A/B/C)
```

Keeping every DonutCore call inside `DonutCoreBridge` matters: when DonutCore updates and its API changes, exactly one file needs editing.

---

## 5. `config.yml`

```yaml
# How much to multiply shard gains for Blue Client users.
multiplier: 2.0

# Turn the whole boost off without uninstalling the plugin.
enabled: true

# Message shown once, when a Blue Client user joins. Empty string = silent.
join-message: "&b&lBLUE CLIENT &7detected — &b2x shards &7active!"

# Shard sources that must NEVER be multiplied (admin grants, purchases,
# refunds). Match these against DonutCore's source enum.
excluded-sources:
  - ADMIN
  - PURCHASE
  - REFUND

# Log every multiplied award. Noisy, but invaluable the first week.
debug-logging: false
```

---

## 6. Sketch of `HelloListener`

```java
public class HelloListener implements PluginMessageListener {

    private final BlueClientBoostPlugin plugin;

    public HelloListener(BlueClientBoostPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!channel.equals("blueclient:hello")) return;

        ByteArrayDataInput in = ByteStreams.newDataInput(message);
        try {
            int protocol = in.readInt();
            String clientVersion = in.readUTF();
            String mcVersion = in.readUTF();

            plugin.tracker().mark(player.getUniqueId(), clientVersion);

            if (plugin.getConfig().getBoolean("debug-logging")) {
                plugin.getLogger().info(player.getName()
                    + " is on Blue Client " + clientVersion + " (mc " + mcVersion
                    + ", protocol " + protocol + ")");
            }

            // Reply so the client can show its "2x shards" toast.
            ByteArrayDataOutput out = ByteStreams.newDataOutput();
            out.writeBoolean(true);
            out.writeFloat((float) plugin.getConfig().getDouble("multiplier", 2.0));
            player.sendPluginMessage(plugin, "blueclient:hello", out.toByteArray());

            String join = plugin.getConfig().getString("join-message", "");
            if (!join.isEmpty()) {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', join));
            }
        } catch (Exception e) {
            // A malformed packet is someone poking at the server. Ignore it.
            plugin.getLogger().fine("Bad blueclient:hello from " + player.getName());
        }
    }
}
```

`BlueClientTracker` must clear its entry on `PlayerQuitEvent`, or a reconnecting player keeps a stale flag.

---

## 7. Testing checklist

1. Join with vanilla → no message, no multiplier, DonutCore behaves exactly as before.
2. Join with Blue Client → join message appears, log line appears with debug on.
3. Earn shards on Blue Client → the amount is exactly double, and DonutCore's balance matches the sum.
4. `/donutcore givesards <player> 100` (or whatever the admin command is) → **not** doubled.
5. Stop DonutCore, keep this plugin → warning logged, server stays up, no multiplier.
6. Relog five times in a row → no drift in the balance, no duplicated flags.
7. Two players, one on each client, earning at the same time → no cross-contamination.

---

## 8. Client-side status — DONE as of `0.24.3`

The hello packet is **implemented**, in `net.bluenetwork.client.net.BlueHelloPacket`. The server side is still yours to write; this section tells you exactly what the client will do so you can match it.

### What the client does

* Registers `blueclient:hello` in **both** directions at client init (`PayloadTypeRegistry.playC2S()` for `Hello`, `playS2C()` for `HelloReply`).
* **20 ticks (1 s) after `ClientPlayConnectionEvents.JOIN`** it sends `Hello{protocol=1, version, mc}`.
* It first checks `ClientPlayNetworking.canSend(...)`, which is only true once **your plugin has registered the channel**. On a vanilla server the client stays silent — no wasted packets, no log spam.
* On `HelloReply{accepted, multiplier}` it shows a toast: `"2x shards active"` when `multiplier > 1`, otherwise `"Blue Network connected"`. A trailing `.0` is trimmed, so `2.0 → "2x"` while `1.5 → "1.5x"`.
* `accepted=false` is silently ignored. No reply at all is also fine — nothing breaks.

### Implementation notes that matter to you

* **1.21.11 uses `CustomPayload`, not raw `PacketByteBuf` channels.** The old `ClientSidePacketRegistry` API is long gone.
* **The same `Identifier` is used for both payloads.** That is legal and intentional: `playC2S` and `playS2C` are separate registries, so one channel carries a different shape in each direction — exactly as §2 specifies.
* String reads are **length-bounded (64)**, so a malicious server cannot make the client allocate an oversized string.
* The receive handler hops to the client thread via `context.client().execute(...)` before touching the UI. Do not remove that — handlers run on the netty thread.
* Everything is wrapped in `try/catch (Throwable)`: a networking fault must never abort `onInitializeClient`.

### Bumping the protocol
`PROTOCOL` is `1`. If you change the wire shape, bump it on both sides and have the plugin reject unknown versions gracefully rather than disconnecting the player.

---

## 9. Buddies — 3 shards instead of 2 (v20)

> **The rule:** every Blue Client user gets **2× shards**. If two players are
> each other's **buddy**, and **both** are online, on Blue Network, running
> Blue Client, they get **3× shards instead of 2×** — for as long as they are
> both online together.

Buddies are the client's "best friend" slot: **one buddy each**, chosen on the
profile screen. It only counts when it is **mutual** — A picks B *and* B picks
A. A one-sided pick is worth nothing, which is what stops someone farming the
bonus by naming a player who never named them back.

### Where the buddy data lives

In the same Supabase database the Friends system uses (see README-BACKEND).
`profiles.buddy_id` holds each player's chosen buddy. Both players also have a
**linked Minecraft account** (`profiles.mc_name` / `mc_uuid` / `mc_verified`).

The plugin asks one question and gets one answer:

```sql
select public.are_buddies_mc('PlayerOne', 'PlayerTwo');
```

`are_buddies_mc(name_a, name_b)` returns `true` only when **all** of these
hold:

* both names are linked to Blue Client profiles,
* **both links are verified** (`mc_verified = true` — a premium account proved
  by a real Mojang token, see README-BACKEND §24),
* and the buddy choice is **mutual**.

Requiring verification matters on a server that allows cracked logins: without
it, two people could link each other's names and mint the bonus from names
they do not own.

### How the plugin should use it

1. Keep the set of online Blue Client users you already track from the hello
   packet (§2).
2. When a player joins, for each **other** online Blue Client user, call
   `are_buddies_mc`. In practice you will call it a handful of times per join —
   cheap, and you can stop at the first `true` because a player has only one
   buddy.
3. Cache the result in memory per session. Buddies change rarely; hitting the
   database on every shard award is wasteful.
4. Clear a player's cached buddy state on quit, and re-evaluate the **other**
   player's multiplier — when your buddy logs off you drop back to 2×.

Talk to Supabase over its REST endpoint with the **`service_role` key**, kept
in the plugin config and never given to players:

```
POST https://YOUR-PROJECT-REF.supabase.co/rest/v1/rpc/are_buddies_mc
apikey: <service_role key>
Authorization: Bearer <service_role key>
Content-Type: application/json

{"name_a":"PlayerOne","name_b":"PlayerTwo"}
```

Response body is just `true` or `false`.

> Do this **asynchronously** (`runTaskAsynchronously`). Never make an HTTP call
> on the main thread — it freezes the whole server for the duration of the
> request.

### Applying it

Nothing changes structurally: the buddy bonus is still just a **multiplier
value**, so it goes through the exact same `DonutCoreBridge` path as the 2×
boost (§3). Only the number differs.

```java
// In whichever strategy you chose in §3:
double multiplier = plugin.isBlueClient(player)
    ? (plugin.hasOnlineBuddy(player) ? config.buddyMultiplier   // 3.0
                                     : config.multiplier)       // 2.0
    : 1.0;
```

**Never** stack the two — a buddy pair gets 3×, not 2× × 3×. Compute one
number and hand DonutCore that one number.

### Config additions

```yaml
# Multiplier when a mutual buddy pair is online together.
# Must be a single total multiplier, NOT something added on top of `multiplier`.
buddy-multiplier: 3.0

# Message shown to both players when a buddy pair becomes active.
buddy-message: "&b&lBUDDY BONUS &7— &b3x shards &7while &f%buddy% &7is online!"

# Supabase connection for buddy lookups. Leave url empty to disable
# the buddy bonus entirely (the plain 2x boost keeps working).
supabase:
  url: ""
  service-role-key: ""
  # Seconds to cache a buddy lookup before asking again.
  cache-seconds: 300
```

### Failure behaviour

If Supabase is unreachable, paused, or misconfigured, `hasOnlineBuddy` must
return `false` and log **once** — not once per award. The player quietly gets
the normal 2×. A shard economy must never depend on an external service being
up.

### Things that will bite you

* **Do not trust a name the client sends you.** Use the server-side
  `player.getName()`. The buddy check is keyed on the Minecraft name the
  *server* knows.
* **Re-check on both joins and quits.** The bonus is a property of a *pair*,
  so one player's event changes the other player's multiplier.
* **Do not persist buddy state.** It lives in Supabase; a stale local copy is
  how people keep a bonus they no longer qualify for.
* **Cap it there.** No triple-buddy chains, no groups of three. One buddy each,
  mutual, 3× — that is the whole feature.
