#!/bin/bash
# Fast compile check. Usage: ./cc.sh   (add "jar" to also build the jar)
#
# NOTE: the toolchain under /home/user/.tools is OUTSIDE the workspace snapshot
# and gets deleted between sessions. This script locates it rather than
# hardcoding a version, and tells you plainly when it needs re-provisioning.
cd /home/user/work || exit 1

JDK=$(ls -d /home/user/.tools/jdk21 2>/dev/null | head -1)
GRADLE=$(ls /home/user/.tools/gradle-*/bin/gradle 2>/dev/null | head -1)

if [ ! -x "$JDK/bin/javac" ] || [ ! -x "$GRADLE" ]; then
  echo "TOOLCHAIN MISSING - re-provision before building."
  echo "  need: JDK 21 at /home/user/.tools/jdk21"
  echo "        Gradle 9.5.0 at /home/user/.tools/gradle-9.5.0  (Loom 1.17.20 requires exactly 9.5.0)"
  echo "  found JDK=[$JDK] GRADLE=[$GRADLE]"
  exit 127
fi

TASK=compileJava
OFFLINE=--offline
if [ "$1" = "jar" ]; then
  TASK=build
  # A real jar needs :remapJar, which must reach the network for jtracy and
  # the LWJGL natives. Never pass --offline for this path.
  OFFLINE=
fi

JAVA_HOME="$JDK" "$GRADLE" $TASK -x test --no-daemon --console=plain $OFFLINE \
  > /home/user/build.log 2>&1
CODE=$?
if [ $CODE -eq 0 ]; then
  echo "BUILD OK"
  [ "$1" = "jar" ] && ls -la /home/user/work/build/libs/*.jar
else
  grep -E "error:" -A3 /home/user/build.log | head -80
  tail -5 /home/user/build.log
fi
exit $CODE
