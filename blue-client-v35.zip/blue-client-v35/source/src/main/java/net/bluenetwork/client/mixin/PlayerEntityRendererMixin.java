package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.brand.BlueBrand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerEntityRenderer.class})
public abstract class PlayerEntityRendererMixin {
   // v0.21.1: one-time confirmation that the equipped-cape override pipeline
   // is active (check the log when cape rendering seems broken).
   private static boolean blueclient$capeOverrideLogged = false;
   /*
    * v0.24.3 — THE DOUBLE BADGE BUG
    * ------------------------------
    * Owner: "the 3rd person nametag has the blue client logo but it has it
    *         2 times copied and it looks trash"
    *
    * PlayerEntityRenderer declares THREE `updateRenderState` overloads:
    *
    *   updateRenderState(PlayerLikeEntity, PlayerEntityRenderState, float)  <- real
    *   updateRenderState(LivingEntity,     LivingEntityRenderState,  float)  <- bridge
    *   updateRenderState(Entity,           EntityRenderState,        float)  <- bridge
    *
    * The two bridges are compiler-generated: they checkcast their arguments and
    * delegate to the real method. Writing `method = "updateRenderState"` with no
    * descriptor matches ALL THREE, so Mixin injected the badge code into a
    * bridge AND into the real method. Calling the bridge therefore ran our
    * append twice and produced "B B Name".
    *
    * The fix is to pin the exact descriptor so only the real method is patched.
    * The SAME trap applies to OwnNametagMixin and to any future hook on an
    * overridden generic method — always give the full descriptor.
    */
   @Inject(
      // Full descriptor on ONE line: string concatenation here would defeat
      // both Mixin's parser and tools/verify_mixins.py.
      method = {"updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V"},
      at = {@At("TAIL")}
   )
   private void blueclient$nametagIcon(PlayerLikeEntity entity, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
      if (entity == null || state == null || state.displayName == null) {
         return;
      }
      // 1) Blue Client logo badge for Blue Client users - and since v0.19.0
      //    also on YOUR OWN nametag, with a Nametags-module option to put the
      //    badge on the LEFT side of the name instead of after it.
      /*
       * Belt-and-braces: never append a badge to a name that already has one.
       * The descriptor fix above is the real cure, but a render state can also
       * be REUSED between frames, and a second append would be permanent.
       */
      if (state.displayName.getString().contains(BlueBrand.ICON_GLYPH)) {
         return;
      }

      boolean blueUser = BlueClient.getInstance().presence().isBlueClientUser(entity.getUuid());
      MinecraftClient self = MinecraftClient.getInstance();
      boolean own = self != null && self.player != null && self.player.getUuid().equals(entity.getUuid());
      if (net.bluenetwork.client.module.impl.BlueLogo.showOnNametags() && blueUser) {
         state.displayName = net.bluenetwork.client.module.impl.BlueLogo.logoOnLeft()
            ? BlueBrand.withIconLeft(state.displayName)
            : BlueBrand.withIcon(state.displayName);
      } else if (own && net.bluenetwork.client.module.impl.Nametags.ownNametag()) {
         // your own tag in third person always carries the badge
         state.displayName = net.bluenetwork.client.module.impl.BlueLogo.logoOnLeft()
            ? BlueBrand.withIconLeft(state.displayName)
            : BlueBrand.withIcon(state.displayName);
      }
      // 1a) v20: profile badge (Founder / Helper / ...) on in-world nametags.
      //
      // NAMETAGS ONLY - never the tab list; that is what the spec asked for
      // and it is why this lives here and not in PlayerListHudMixin.
      //
      // Two independent switches:
      //   seeOtherBadges() - do I want to see other people's badges?
      //   the owner's show_badge - enforced SERVER-SIDE, so a hidden badge is
      //   never even sent to us. Checking it here too would be pointless.
      //
      // Cost: one HashMap lookup. BadgeCache never does I/O on this path.
      try {
         if (net.bluenetwork.client.module.impl.BlueLogo.showBadgesOnNametags()) {
            // getNameForScoreboard() is the raw Minecraft username (no team
            // prefixes or display-name decoration), which is exactly what the
            // badge cache is keyed by.
            String mcName = entity.getNameForScoreboard();
            boolean isSelf = self != null && self.player != null
               && self.player.getUuid().equals(entity.getUuid());

            // Show other people's badges only if we opted in; always show our own.
            if (mcName != null
               && (isSelf || net.bluenetwork.client.module.impl.BlueLogo.seeOtherBadges())) {
               net.bluenetwork.client.social.BadgeCache.Badge badge =
                  BlueClient.getInstance().friends().badges().badgeFor(mcName);
               if (badge != null) {
                  // v21 COLOURED NAMEPLATES.
                  //
                  // Applied BEFORE the badge is appended, so the colour styles
                  // the name only and the badge keeps its own colour.
                  //
                  // Minecraft styles cannot express a per-character gradient on
                  // a single Text, so a gradient name is rebuilt one character
                  // at a time with an interpolated colour each. That is a few
                  // extra Text objects for a handful of subscribers per server,
                  // and only for players who actually set one.
                  if (badge.plus() && badge.nameColor() != null) {
                     var spec = net.bluenetwork.client.social.NameColor
                        .parse(badge.nameColor(), 0xFFFFFFFF);
                     String plain = state.displayName.getString();

                     if (spec.gradient() && plain.length() > 1) {
                        var built = net.minecraft.text.Text.empty();
                        for (int i = 0; i < plain.length(); i++) {
                           float t = i / (float) (plain.length() - 1);
                           int col = net.bluenetwork.client.social.NameColor
                              .blend(spec, t);
                           final boolean bold = spec.bold();
                           final boolean italic = spec.italic();
                           built.append(net.minecraft.text.Text
                              .literal(String.valueOf(plain.charAt(i)))
                              .styled(st -> st.withColor(col & 0xFFFFFF)
                                 .withBold(bold).withItalic(italic)));
                        }
                        state.displayName = built;
                     } else {
                        final int col = spec.flat();
                        final boolean bold = spec.bold();
                        final boolean italic = spec.italic();
                        state.displayName = state.displayName.copy().styled(
                           st -> st.withColor(col & 0xFFFFFF)
                              .withBold(bold).withItalic(italic));
                     }
                  }

                  // Verified tick sits directly after the name, before any badge.
                  if (badge.verified()) {
                     state.displayName = state.displayName.copy()
                        .append(net.minecraft.text.Text.literal(" "
                           + net.bluenetwork.client.ui.VerifiedBadge.NAMETAG_GLYPH)
                           .styled(st -> st.withColor(0x2FA5FF)));
                  }

                  if (badge.hasBadge()) {
                     state.displayName = state.displayName.copy()
                        .append(net.minecraft.text.Text.literal(" "))
                        .append(net.minecraft.text.Text.literal("[" + badge.label() + "]")
                           .styled(st -> st.withColor(badge.colour() & 0xFFFFFF)));
                  }
               }
            }
         }
      } catch (Throwable ignored) {
         // A badge must never break nametag rendering.
      }

      // 1b) v0.19.0 Nametags "more info": health / ping suffix on player tags
      try {
         String suffix = entity instanceof net.minecraft.entity.player.PlayerEntity player
            ? net.bluenetwork.client.module.impl.Nametags.infoSuffix(player) : "";
         if (!suffix.isEmpty()) {
            state.displayName = state.displayName.copy().append(net.minecraft.text.Text.literal(suffix));
         }
      } catch (Throwable ignored) {
      }
      // 2) v0.16.13: Third Person Nametag - restyle YOUR OWN nametag
      //    (color / bold / shadow), visible in F5 third person.
      try {
         MinecraftClient client = MinecraftClient.getInstance();
         if (net.bluenetwork.client.module.impl.ThirdPersonNametag.active()
            && client != null && client.player != null
            && client.player.getUuid().equals(entity.getUuid())
            && !client.player.isInvisible()) {
            Text base = state.displayName;
            state.displayName = base.copy().styled(style -> {
               style = style.withColor(net.bluenetwork.client.module.impl.ThirdPersonNametag.colorRgb());
               if (net.bluenetwork.client.module.impl.ThirdPersonNametag.boldOn()) {
                  style = style.withBold(true);
               }
               if (net.bluenetwork.client.module.impl.ThirdPersonNametag.shadowOn()) {
                  style = style.withShadowColor(0xFF000000);
               }
               return style;
            });
         }
      } catch (Throwable ignored) {
         // styling is cosmetic - never let it break entity rendering
      }
      // 3) v0.20.0 Cosmetics: swap in the equipped cape texture for the
      //    LOCAL player only (Phase 1 - no backend, see
      //    README-BACKEND-COSMETICS.md for cross-player visibility).
      try {
         if (own && state.skinTextures != null) {
            net.bluenetwork.client.cosmetics.Cape cape = net.bluenetwork.client.cosmetics.CosmeticsManager.equippedCape();
            if (cape != null) {
               var override = net.minecraft.entity.player.SkinTextures.SkinOverride.create(
                  java.util.Optional.empty(),
                  java.util.Optional.of(new net.minecraft.util.AssetInfo.TextureAssetInfo(cape.textureId())),
                  java.util.Optional.empty(),
                  java.util.Optional.empty());
               state.skinTextures = state.skinTextures.withOverride(override);
               state.capeVisible = true;
               if (!blueclient$capeOverrideLogged) {
                  blueclient$capeOverrideLogged = true;
                  BlueClient.LOGGER.info("Cosmetics: equipped cape '{}' now overrides the vanilla cape for the local player", cape.id());
               }
            }
         }
      } catch (Throwable t) {
         // cosmetics must never break entity rendering - but a swallowed cape
         // failure looks like "the vanilla cape still overrides mine", so
         // leave a trail in the log.
         BlueClient.LOGGER.debug("Cape override failed", t);
      }
   }
}
