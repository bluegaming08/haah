package net.bluenetwork.client.render;

import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.reflect.Field;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Blue Client custom GUI render pipelines for 1.21.11.
 *
 * <p>ROUNDED_RECT draws rects whose four corners are quarter-circle fans; UV0 carries the
 * pixel offset from the corner centre divided by the radius, so the fragment shader can
 * compute a signed distance field and produce per-pixel anti-aliased corners. GLYPH draws
 * glyphs from the FreeType atlas built by {@link BlueFont}.
 *
 * <p>The GUI renderer batches SimpleGuiElementRenderStates per pipeline and sorts them by
 * the pipeline's internal sort key (an instantiation counter). Both custom keys are
 * aligned with a vanilla pipeline via reflection so layering matches call order the way
 * vanilla fills and icons already behave: rounded rects sort with plain fills, glyphs
 * sort with textured icons.
 */
public final class BluePipelines {
    public static final RenderPipeline ROUNDED_RECT;

    public static final RenderPipeline GLYPH;

    static {
        ROUNDED_RECT = builder("core/roundrect")
            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
            .withCull(false)
            .build();
        GLYPH = builder("core/bluetext")
            .withSampler("Sampler0")
            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
            .withCull(false)
            .build();
        matchSortKey(ROUNDED_RECT, RenderPipelines.GUI);
        matchSortKey(GLYPH, RenderPipelines.GUI_TEXTURED);
    }

    private static RenderPipeline.Builder builder(String shader) {
        Identifier id = Identifier.of("blueclient", shader);
        return RenderPipeline.builder()
            .withLocation(Identifier.of("blueclient", shader.substring(shader.lastIndexOf('/') + 1) + "_pipeline"))
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
            .withVertexShader(id)
            .withFragmentShader(id)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST);
    }

    private static void matchSortKey(RenderPipeline pipeline, RenderPipeline vanilla) {
        try {
            Field field = RenderPipeline.class.getDeclaredField("sortKey");
            field.setAccessible(true);
            field.setInt(pipeline, vanilla.getSortKey());
        } catch (Throwable t) {
            // Non-fatal: sorting still works, elements just batch after vanilla's.
        }
    }

    private BluePipelines() {
    }
}
