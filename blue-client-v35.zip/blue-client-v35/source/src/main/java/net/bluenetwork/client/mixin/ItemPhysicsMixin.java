package net.bluenetwork.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.bluenetwork.client.module.impl.ItemPhysics;
import net.bluenetwork.client.render.ItemPhysicsState;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Item Physics — lays dropped items flat instead of floating them upright.
 *
 * <h2>How vanilla draws a dropped item</h2>
 * Read off {@code javap -c}, {@code ItemEntityRenderer.render} does, in order:
 * {@code push()} → {@code translate(0, bob, 0)} (a sine wave on
 * {@code age + uniqueOffset}) → {@code multiply(POSITIVE_Y.rotation(spin))} →
 * draw → {@code pop()}.
 *
 * <p>Rather than cancel and reimplement all of that (which would break every
 * other mod touching item rendering, and silently drop future vanilla
 * changes), this hook:</p>
 * <ol>
 *   <li><b>zeroes the bob</b> by modifying the sine expression's value, when
 *       "keep bobbing" is off;</li>
 *   <li><b>zeroes the spin</b> the same way, once the item has landed;</li>
 *   <li><b>adds its own rotation</b> right after {@code push()}, tipping the
 *       item onto its face and easing it down as it settles.</li>
 * </ol>
 *
 * <p>Uses {@code @ModifyExpressionValue}, never a plain {@code @Redirect}
 * (forbidden here — MixinExtras 0.5.4 throws a CCE). All hooks are
 * {@code require = 0}: if a Minecraft update moves these expressions the module
 * quietly stops working instead of preventing the game from starting.</p>
 *
 * <p><b>Rendering only.</b> The entity's real position and hitbox are never
 * touched, so pickup behaves exactly as vanilla and no packets change.</p>
 */
@Mixin(ItemEntityRenderer.class)
public abstract class ItemPhysicsMixin {

   /*
    * NOTE on the handler signatures below.
    *
    * MixinExtras lets a @ModifyExpressionValue handler receive "the expression's
    * resultant value, optionally followed by the enclosing method's parameters".
    * That is ALL of them or NONE - a prefix subset does not bind, and because
    * these hooks are require = 0 the failure would be SILENT (the module would
    * simply do nothing in game). Hence the full four-parameter tail even though
    * only the render state is actually used.
    */

   /**
    * Kills the vanilla bob.
    *
    * <p>Targets the {@code MathHelper.sin} call that produces the vertical
    * float. Returning 0 leaves the item at its true Y.</p>
    */
   @ModifyExpressionValue(
      method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;sin(D)F"),
      require = 0
   )
   private float blueclient$flattenBob(float original,
                                       ItemEntityRenderState state,
                                       MatrixStack matrices,
                                       net.minecraft.client.render.command.OrderedRenderCommandQueue queue,
                                       net.minecraft.client.render.state.CameraRenderState camera) {
      try {
         ItemPhysics.Snapshot cfg = ItemPhysics.snapshot();
         if (cfg == null || cfg.keepBobbing()) {
            return original;
         }
         // Fade the bob out as the item settles, rather than snapping.
         float settled = blueclient$settleProgress(state, cfg);
         return original * (1.0F - settled);
      } catch (Throwable t) {
         return original;
      }
   }

   /**
    * Stops the spin once the item is down.
    *
    * <p>Targets {@code ItemEntity.getRotation}, which supplies the Y angle.
    * While airborne the item keeps spinning (if enabled); as it settles the
    * angle is frozen to its resting value so it does not rotate on the floor
    * like a record.</p>
    */
   @ModifyExpressionValue(
      method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/ItemEntity;getRotation(FF)F"),
      require = 0
   )
   private float blueclient$freezeSpin(float original,
                                       ItemEntityRenderState state,
                                       MatrixStack matrices,
                                       net.minecraft.client.render.command.OrderedRenderCommandQueue queue,
                                       net.minecraft.client.render.state.CameraRenderState camera) {
      try {
         ItemPhysics.Snapshot cfg = ItemPhysics.snapshot();
         if (cfg == null || !cfg.lieFlat()) {
            return original;
         }
         float settled = blueclient$settleProgress(state, cfg);
         if (settled <= 0.0F) {
            return cfg.spinInAir() ? original : 0.0F;
         }
         // Resting angle: stable per item so it does not jitter between frames.
         float resting = cfg.randomRotation()
            ? (blueclient$seedOf(state) % 360)
            : 0.0F;
         return MathHelper.lerp(settled, cfg.spinInAir() ? original : 0.0F, resting);
      } catch (Throwable t) {
         return original;
      }
   }

   /**
    * Tips the item onto its face and lifts it clear of the ground.
    *
    * <p>Injected immediately after vanilla's {@code push()}, so the transform
    * applies to the item and is undone by vanilla's matching {@code pop()}.</p>
    */
   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;push()V", shift = At.Shift.AFTER),
      require = 0
   )
   private void blueclient$layFlat(ItemEntityRenderState state, MatrixStack matrices,
                                   net.minecraft.client.render.command.OrderedRenderCommandQueue queue,
                                   net.minecraft.client.render.state.CameraRenderState camera,
                                   CallbackInfo ci) {
      try {
         ItemPhysics.Snapshot cfg = ItemPhysics.snapshot();
         if (cfg == null) {
            return;
         }
         float scale = cfg.scale();
         if (scale != 1.0F) {
            matrices.scale(scale, scale, scale);
         }
         if (!cfg.lieFlat()) {
            return;
         }
         float settled = blueclient$settleProgress(state, cfg);
         if (settled <= 0.0F) {
            return;
         }
         // Rotate forward onto the ground, easing in as it settles, and lift
         // slightly so the flat quad does not z-fight with the block below.
         matrices.translate(0.0F, cfg.groundOffset() * settled, 0.0F);
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F * settled));
      } catch (Throwable ignored) {
      }
   }

   /**
    * 0 while falling, easing to 1 once the item has rested.
    *
    * <p>Driven by how long the item has been on the ground. The render state
    * is tagged with that by {@code ItemEntityRenderStateMixin}; if the tag is
    * missing (another mod replaced the state) it degrades to "not settled",
    * i.e. vanilla behaviour.</p>
    */
   @org.spongepowered.asm.mixin.Unique
   private static float blueclient$settleProgress(ItemEntityRenderState state,
                                                  ItemPhysics.Snapshot cfg) {
      if (!(state instanceof ItemPhysicsState physics) || !physics.blueclient$isOnGround()) {
         return 0.0F;
      }
      float speed = Math.max(1.0F, cfg.settleSpeed());
      // age is in ticks; divide so a higher "settle speed" lands sooner.
      float progress = physics.blueclient$getAge() * (speed / 20.0F);
      return Math.max(0.0F, Math.min(1.0F, progress));
   }

   @org.spongepowered.asm.mixin.Unique
   private static int blueclient$seedOf(ItemEntityRenderState state) {
      return state instanceof ItemPhysicsState physics
         ? Math.abs(physics.blueclient$getSeed()) : 0;
   }
}
