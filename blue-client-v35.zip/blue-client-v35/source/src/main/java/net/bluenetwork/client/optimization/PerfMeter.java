package net.bluenetwork.client.optimization;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * PerfMeter (Performance Charter §0.2, engine piece 1) — measures how long
 * each enabled module spends inside its per-tick and per-frame callbacks and
 * reports it against the frame budget. Sampling is a simple nanoTime wrapper
 * around callbacks that already exist (see HudManager and ModuleManager) and is
 * entirely OFF until {@link #setActive(boolean)} is called, so it costs nothing
 * when nobody is watching.
 *
 * <p>Charter budget: HUD family ≤ 0.6 ms/module per frame; anything over
 * {@link #MAX_HUD_BUDGET_MS} is flagged in {@link #summary()}.</p>
 */
public final class PerfMeter {
   /** HUD render budget from the charter (0.6 ms/module). */
   public static final double MAX_HUD_BUDGET_MS = 0.6;

   private static volatile boolean active = false;

   /** name → exponentially weighted moving average in nanoseconds. */
   private static final Map<String, double[]> ROLLING = new ConcurrentHashMap<>();
   private static double lastFrameTotalMs = 0.0;
   private static long frameStartNanos = 0L;

   private PerfMeter() {
   }

   public static void setActive(boolean value) {
      active = value;
      if (!value) {
         ROLLING.clear();
      }
   }

   public static boolean active() {
      return active;
   }

   /** Begin a frame measurement (render thread, once per frame). */
   public static void beginFrame() {
      frameStartNanos = System.nanoTime();
   }

   /** End the frame measurement and stash the total ms. */
   public static void endFrame() {
      long now = System.nanoTime();
      if (frameStartNanos > 0L) {
         lastFrameTotalMs = (now - frameStartNanos) / 1_000_000.0;
      }
      frameStartNanos = 0L;
   }

   /** Record one callback duration (ns) for a named module. */
   public static void record(String moduleName, long elapsedNanos) {
      if (!active) {
         return;
      }
      double[] state = ROLLING.computeIfAbsent(moduleName, n -> new double[]{0.0});
      double alpha = 0.2;
      state[0] = state[0] == 0.0 ? elapsedNanos : alpha * elapsedNanos + (1.0 - alpha) * state[0];
   }

   public static double avgMs(String moduleName) {
      double[] state = ROLLING.get(moduleName);
      return state == null ? 0.0 : state[0] / 1_000_000.0;
   }

   /** Names with their running average ms, sorted by cost, hottest first. */
   public static List<Entry> snapshot() {
      List<Entry> out = new ArrayList<>();
      for (Map.Entry<String, double[]> e : ROLLING.entrySet()) {
         out.add(new Entry(e.getKey(), e.getValue()[0] / 1_000_000.0));
      }
      out.sort((a, b) -> Double.compare(b.ms, a.ms));
      return out;
   }

   public static double lastFrameMs() {
      return lastFrameTotalMs;
   }

   public static double frameLoadPct() {
      return lastFrameTotalMs <= 0.0 ? 0.0 : Math.min(100.0, lastFrameTotalMs / 16.67 * 100.0);
   }

   public static boolean overBudget(String moduleName) {
      return avgMs(moduleName) > MAX_HUD_BUDGET_MS;
   }

   public record Entry(String name, double ms) {
   }
}
