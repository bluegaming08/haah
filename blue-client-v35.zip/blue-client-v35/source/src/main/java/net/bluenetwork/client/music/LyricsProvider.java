package net.bluenetwork.client.music;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Timed lyrics for the Music Player HUD, fetched from the public LRCLIB
 * API (no key required). Synced lyrics are preferred; when a track only has
 * plain lyrics they are shown as evenly spaced blocks so the lyric effects
 * still animate.
 */
public final class LyricsProvider {
   /** One lyric line and the playback position (ms) it belongs to. */
   public record Line(long ms, String text) {
   }

   public record Lyrics(List<Line> lines, boolean synced) {
      public Line at(long positionMs) {
         Line current = null;
         for (Line line : this.lines) {
            if (line.ms() <= positionMs) {
               current = line;
            } else {
               break;
            }
         }
         return current;
      }

      public Line after(Line line) {
         for (int i = 0; i < this.lines.size(); i++) {
            if (this.lines.get(i) == line && i + 1 < this.lines.size()) {
               return this.lines.get(i + 1);
            }
         }
         return null;
      }
   }

   private static final long PLAIN_LINE_MS = 6000L;

   private LyricsProvider() {
   }

   /** Returns lyrics for the track, or null when none exist. */
   /**
    * Finds the best LRCLIB match for a track.
    *
    * <h3>v0.24.7 scoring rewrite</h3>
    * The old scorer was {@code diff = |candidateDuration - durationSec|}, minus
    * 1000 for anything synced, and it treated an <b>unknown</b> duration as a
    * flat 999 for every candidate. That had two consequences:
    * <ul>
    *   <li>with no duration (which was ALWAYS the case before this version,
    *       because nothing ever called {@code setDurationMs}) every candidate
    *       tied, so the <b>first synced result won</b>;</li>
    *   <li>a wildly wrong length still beat a slightly-wrong one only by raw
    *       seconds, and the title was never considered at all.</li>
    * </ul>
    *
    * <p>LRCLIB returns 19 entries for "catch me" including a <b>177 s</b> and a
    * <b>303 s</b> version, so picking the wrong one loads timings from a
    * different master - the lyrics then slide further behind the longer the
    * song runs, exactly the reported symptom.</p>
    *
    * <p>Now scored on three things, lowest wins:</p>
    * <ol>
    *   <li><b>Duration</b> - the strongest signal. Within 2 s is treated as
    *       exact; beyond {@value #MAX_DURATION_DRIFT_SEC} s the candidate is
    *       rejected outright rather than merely penalised.</li>
    *   <li><b>Title / artist similarity</b> - an exact (case-insensitive)
    *       match is preferred over a substring, which beats a fuzzy hit.</li>
    *   <li><b>Synced over plain</b> - still a large bonus, but it can no
    *       longer drag in a track of obviously the wrong length.</li>
    * </ol>
    */
   /**
    * Fetches lyrics, trying progressively simpler queries.
    *
    * <p>A single query is brittle: "Kesariya - Brahmastra" misses when the
    * database stores only "Kesariya". The ladder from {@link TrackName} tries
    * title+artist, then title, then the title without its subtitle - stopping
    * at the first query that yields a usable match.</p>
    */
   public static Lyrics fetch(String title, String artist, int durationSec) {
      for (String query : TrackName.queryLadder(title, artist)) {
         Lyrics found = fetchOne(query, title, artist, durationSec);
         if (found != null && !found.lines().isEmpty()) {
            return found;
         }
      }
      return null;
   }

   /** One search request plus scoring. */
   private static Lyrics fetchOne(String query, String title, String artist,
                                  int durationSec) {
      if (query == null || query.isBlank()) {
         return null;
      }
      try {
         String body = TrackResolver.httpGetWithAgent("https://lrclib.net/api/search?q="
            + java.net.URLEncoder.encode(query, java.nio.charset.StandardCharsets.UTF_8),
               TrackResolver.LYRICS_USER_AGENT);
         JsonArray results = JsonParser.parseString(body).getAsJsonArray();

         JsonObject best = null;
         int bestScore = Integer.MAX_VALUE;
         for (JsonElement element : results) {
            if (!element.isJsonObject()) {
               continue;
            }
            JsonObject candidate = element.getAsJsonObject();

            boolean hasSynced = candidate.has("syncedLyrics")
               && !candidate.get("syncedLyrics").isJsonNull()
               && !candidate.get("syncedLyrics").getAsString().isBlank();
            boolean hasPlain = candidate.has("plainLyrics")
               && !candidate.get("plainLyrics").isJsonNull()
               && !candidate.get("plainLyrics").getAsString().isBlank();
            if (!hasSynced && !hasPlain) {
               continue;                      // nothing usable at all
            }
            if (candidate.has("instrumental") && !candidate.get("instrumental").isJsonNull()
               && candidate.get("instrumental").getAsBoolean()) {
               continue;                      // instrumental: no words to show
            }

            int candidateDuration = readInt(candidate, "duration");

            int score = 0;
            if (durationSec > 0 && candidateDuration > 0) {
               int drift = Math.abs(candidateDuration - durationSec);
               if (drift > MAX_DURATION_DRIFT_SEC) {
                  continue;                   // a different master - reject
               }
               score += drift <= 2 ? 0 : drift * 4;
            } else {
               // Unknown duration: mild, EQUAL penalty. It must not look like
               // a good match, but it must not beat a real length match either.
               score += 60;
            }

            score += nameScore(readString(candidate, "trackName"), title);
            score += nameScore(readString(candidate, "artistName"), artist) / 2;

            if (hasSynced) {
               score -= 200;                  // synced is what we actually want
            }

            if (score < bestScore) {
               bestScore = score;
               best = candidate;
            }
         }

         if (best == null) {
            return null;
         }
         String synced = readString(best, "syncedLyrics");
         if (!synced.isBlank()) {
            Lyrics parsed = parseSynced(synced);
            if (parsed != null && !parsed.lines().isEmpty()) {
               return parsed;
            }
         }
         String plain = readString(best, "plainLyrics");
         if (!plain.isBlank()) {
            return parsePlain(plain);
         }
         return null;
      } catch (Throwable t) {
         if (Boolean.getBoolean("blueclient.lyricsDebug")) {
            t.printStackTrace();
         }
         return null;
      }
   }

   /** Reject a candidate whose length differs by more than this many seconds. */
   private static final int MAX_DURATION_DRIFT_SEC = 12;

   /** 0 = exact, 10 = one contains the other, 30 = weak/no relation. */
   private static int nameScore(String candidate, String wanted) {
      if (wanted == null || wanted.isBlank() || candidate == null || candidate.isBlank()) {
         return 15;
      }
      String a = candidate.toLowerCase(Locale.ROOT).trim();
      String b = wanted.toLowerCase(Locale.ROOT).trim();
      if (a.equals(b)) {
         return 0;
      }
      if (a.contains(b) || b.contains(a)) {
         return 10;
      }
      return 30;
   }

   private static String readString(JsonObject object, String key) {
      return object.has(key) && !object.get(key).isJsonNull() ? object.get(key).getAsString() : "";
   }

   private static int readInt(JsonObject object, String key) {
      try {
         return object.has(key) && object.get(key).isJsonPrimitive()
            && object.getAsJsonPrimitive(key).isNumber()
               ? object.getAsJsonPrimitive(key).getAsInt() : -1;
      } catch (Throwable t) {
         return -1;
      }
   }

   /** Exposed for {@link LyricsCache}, which stores lyrics in LRC form. */
   public static Lyrics parseSyncedPublic(String raw) {
      return parseSynced(raw);
   }

   /** Exposed for {@link LyricsCache}. */
   public static Lyrics parsePlainPublic(String raw) {
      return parsePlain(raw);
   }

   /**
    * Loads lyrics from a local {@code .lrc} sidecar sitting next to the audio
    * file, e.g. {@code songs/Artist - Title.lrc} for {@code .../Title.mp3}.
    *
    * <p>Checked <b>before</b> the LRCLIB network lookup: a file the user placed
    * themselves is authoritative, works offline, and is instant. Returns
    * {@code null} when there is no sidecar or it contains nothing usable, in
    * which case the caller should fall back to the online search.</p>
    *
    * <p>Both flavours are accepted — timestamped {@code [mm:ss.xx]} lines give
    * synced lyrics, a plain text file gives unsynced ones.</p>
    */
   public static Lyrics fromSidecar(java.nio.file.Path audioFile) {
      try {
         if (audioFile == null) {
            return null;
         }
         String name = audioFile.getFileName().toString();
         int dot = name.lastIndexOf('.');
         java.nio.file.Path lrc =
            audioFile.resolveSibling((dot > 0 ? name.substring(0, dot) : name) + ".lrc");
         if (!java.nio.file.Files.isRegularFile(lrc)) {
            return null;
         }
         String raw = java.nio.file.Files.readString(lrc, java.nio.charset.StandardCharsets.UTF_8);
         if (raw.isBlank()) {
            return null;
         }
         Lyrics synced = parseSynced(raw);
         if (synced != null && !synced.lines().isEmpty()) {
            return synced;
         }
         Lyrics plain = parsePlain(raw);
         return plain != null && !plain.lines().isEmpty() ? plain : null;
      } catch (Throwable t) {
         // A malformed sidecar must never stop the online lookup.
         return null;
      }
   }

   private static Lyrics parseSynced(String raw) {
      List<Line> lines = new ArrayList<>();
      for (String row : raw.split("\n")) {
         String line = row.trim();
         if (line.isEmpty() || !line.startsWith("[")) {
            continue;
         }
         int close = line.indexOf(']');
         if (close < 0) {
            continue;
         }
         long ms = parseTimestamp(line.substring(1, close));
         String text = line.substring(close + 1).trim();
         // Skip metadata tags like [ar: ...] / [ti: ...]
         if (text.isEmpty() || text.startsWith("[")) {
            if (text.isEmpty()) {
               continue;
            }
         }
         if (ms >= 0) {
            lines.add(new Line(ms, text.isEmpty() ? "…" : text));
         }
      }
      lines.sort((a, b) -> Long.compare(a.ms(), b.ms()));
      return lines.isEmpty() ? null : new Lyrics(lines, true);
   }

   private static Lyrics parsePlain(String raw) {
      List<Line> lines = new ArrayList<>();
      long ms = 0;
      for (String row : raw.split("\n")) {
         String text = row.trim();
         if (text.isEmpty()) {
            continue;
         }
         lines.add(new Line(ms, text));
         ms += PLAIN_LINE_MS;
      }
      return lines.isEmpty() ? null : new Lyrics(lines, false);
   }

   /** Parses mm:ss.xx (or hh:mm:ss.xx) into milliseconds; -1 when invalid. */
   private static long parseTimestamp(String stamp) {
      try {
         String[] parts = stamp.split(":");
         double seconds;
         long total = 0;
         if (parts.length == 2) {
            total = Long.parseLong(parts[0].trim()) * 60_000L;
            seconds = Double.parseDouble(parts[1].trim());
         } else if (parts.length == 3) {
            total = Long.parseLong(parts[0].trim()) * 3_600_000L + Long.parseLong(parts[1].trim()) * 60_000L;
            seconds = Double.parseDouble(parts[2].trim());
         } else {
            return -1;
         }
         return total + (long) (seconds * 1000.0D);
      } catch (Throwable t) {
         return -1;
      }
   }

   /** m:ss formatter shared by the HUD. */
   public static String clock(long ms) {
      long totalSeconds = Math.max(0, ms / 1000);
      long minutes = totalSeconds / 60;
      long seconds = totalSeconds % 60;
      return String.format(Locale.ROOT, "%d:%02d", minutes, seconds);
   }
}
