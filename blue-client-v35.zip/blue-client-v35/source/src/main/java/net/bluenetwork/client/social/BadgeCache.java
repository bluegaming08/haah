package net.bluenetwork.client.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

/**
 * Knows which badge each nearby player has equipped.
 *
 * <h2>Why a cache is mandatory here</h2>
 * Nametags are drawn <b>every frame for every visible player</b>. A network
 * call - or even a map miss that triggers one - in that path would destroy
 * frame times. So:
 *
 * <ul>
 *   <li>The renderer only ever reads {@link #badgeFor(String)}, which is a
 *       plain {@code HashMap} lookup on a pre-built immutable map. No
 *       allocation, no locking, no I/O.</li>
 *   <li>Refreshes happen on a timer (every 60s) from the tick thread, and only
 *       when the tab list has actually changed. Standing still on a server
 *       costs <b>zero</b> requests after the first.</li>
 *   <li>One request covers every visible player - the {@code badges_for_players}
 *       RPC takes an array of names and is capped at 100 server-side.</li>
 * </ul>
 *
 * <p>If the backend is unavailable the map simply stays empty and no badges
 * are drawn. Nothing breaks.</p>
 */
public final class BadgeCache {

   /** How often to re-check, when the player list has changed. */
   private static final long REFRESH_MS = 60_000L;

   /**
    * Everything the nametag renderer needs for one player.
    *
    * <p>v21 widened this beyond the badge: the same bulk RPC now also carries
    * the Blue+ name colour and the verified flag, so colouring a nameplate
    * costs ZERO extra requests. {@code id}/{@code label} are null when the
    * player has no equipped badge but does have a colour or a tick.</p>
    */
   public record Badge(String id, String label, int colour,
                       String nameColor, boolean plus, boolean verified) {

      /** True when there is an actual badge to draw, not just a colour. */
      public boolean hasBadge() {
         return this.id != null && this.label != null;
      }
   }

   /** Lowercased Minecraft name -> badge. Replaced wholesale, never mutated. */
   private volatile Map<String, Badge> badges = Map.of();

   private final AtomicBoolean fetching = new AtomicBoolean(false);
   private volatile long lastFetch;
   private volatile int lastPlayerHash;

   private final SupabaseClient api;

   public BadgeCache(SupabaseClient api) {
      this.api = api;
   }

   /**
    * The badge for a Minecraft name, or null.
    *
    * <p><b>This is the hot path.</b> Keep it to a map lookup.</p>
    */
   public Badge badgeFor(String mcName) {
      if (mcName == null) {
         return null;
      }
      Map<String, Badge> map = this.badges;
      return map.isEmpty() ? null : map.get(mcName.toLowerCase(Locale.ROOT));
   }

   public boolean isEmpty() {
      return this.badges.isEmpty();
   }

   public void clear() {
      this.badges = Map.of();
      this.lastPlayerHash = 0;
   }

   /**
    * Called from the client tick. Cheap when nothing changed.
    *
    * <p>Refetches when either the refresh interval elapsed OR the set of
    * players on the server changed (someone joined/left), so a new player's
    * badge shows up promptly without polling.</p>
    */
   public void onTick(boolean loggedIn) {
      if (!loggedIn || !BlueBackend.configured()) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.world == null || mc.getNetworkHandler() == null) {
         return;
      }

      List<String> names = visibleNames(mc);
      if (names.isEmpty()) {
         return;
      }

      int hash = names.hashCode();
      long now = System.currentTimeMillis();
      boolean stale = now - this.lastFetch >= REFRESH_MS;
      boolean changed = hash != this.lastPlayerHash;

      if (!stale && !changed) {
         return;
      }
      if (!this.fetching.compareAndSet(false, true)) {
         return;
      }
      this.lastFetch = now;
      this.lastPlayerHash = hash;
      fetch(names);
   }

   private static List<String> visibleNames(MinecraftClient mc) {
      List<String> names = new ArrayList<>();
      try {
         for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            if (e != null && e.getProfile() != null) {
               String n = e.getProfile().name();
               if (n != null && !n.isBlank()) {
                  names.add(n);
               }
               // The RPC caps at 100 anyway; stop early on huge servers.
               if (names.size() >= 100) {
                  break;
               }
            }
         }
      } catch (Throwable ignored) {
         // A missing network handler mid-disconnect is normal.
      }
      Collections.sort(names);   // stable hash regardless of list order
      return names;
   }

   private void fetch(List<String> names) {
      JsonArray arr = new JsonArray();
      for (String n : names) {
         arr.add(n);
      }
      JsonObject args = new JsonObject();
      args.add("names", arr);

      this.api.rpc("badges_for_players", args)
         .thenAccept(el -> {
            Map<String, Badge> map = new HashMap<>();
            if (el != null && el.isJsonArray()) {
               for (JsonElement e : el.getAsJsonArray()) {
                  if (!e.isJsonObject()) {
                     continue;
                  }
                  JsonObject o = e.getAsJsonObject();
                  String mc = str(o, "mc_name");
                  String id = str(o, "badge_id");
                  String label = str(o, "label");
                  // v21: a row may now carry only a colour or only a tick, so
                  // a null badge id is no longer a reason to skip it.
                  if (mc == null) {
                     continue;
                  }
                  int colour = o.has("colour") && !o.get("colour").isJsonNull()
                     ? o.get("colour").getAsInt() : 0xFF2FA5FF;
                  boolean plus = o.has("is_plus") && !o.get("is_plus").isJsonNull()
                     && o.get("is_plus").getAsBoolean();
                  boolean verified = o.has("verified") && !o.get("verified").isJsonNull()
                     && o.get("verified").getAsBoolean();
                  map.put(mc.toLowerCase(Locale.ROOT),
                     new Badge(id, id == null ? null : (label == null ? id : label),
                        colour, str(o, "name_color"), plus, verified));
               }
            }
            this.badges = Map.copyOf(map);
         })
         .exceptionally(e -> {
            BlueClient.LOGGER.debug("[Social] badge fetch failed", e);
            return null;
         })
         .whenComplete((x, e) -> this.fetching.set(false));
   }

   private static String str(JsonObject o, String key) {
      return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
   }
}
