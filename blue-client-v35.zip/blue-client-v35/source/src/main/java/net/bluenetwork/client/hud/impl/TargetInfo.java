package net.bluenetwork.client.hud.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * Target Info (v3 catalogue A6) — shows what entity you're aiming at: name,
 * health, distance. Reads the vanilla crosshair hit test, so it always agrees
 * with what the game itself targets. Living entities only.
 */
public class TargetInfo extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Name colour", 0xFFFFFFFF);
   private final ColorSetting hpColor = new ColorSetting("HP color", "Health readout colour", 0xFFFF5C5C);
   private final NumberSetting maxRange = new NumberSetting("Max range", "Ignore targets farther than this", 32.0, 4.0, 64.0, 1.0);
   private final BooleanSetting showHp = new BooleanSetting("Show HP", "Health line", true);
   private final BooleanSetting showDistance = new BooleanSetting("Show distance", "Distance line", true);

   public TargetInfo() {
      super("Target Info", "What you're looking at: name / HP / distance", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.hpColor, this.maxRange, this.showHp, this.showDistance});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_LEFT, 6, 108);
   }

   private LivingEntity target() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.crosshairTarget == null) {
         return null;
      }
      if (mc.crosshairTarget.getType() != HitResult.Type.ENTITY || !(mc.crosshairTarget instanceof EntityHitResult hit)) {
         return null;
      }
      Entity entity = hit.getEntity();
      if (!(entity instanceof LivingEntity living)) {
         return null;
      }
      double dist = mc.player.distanceTo(living);
      if (dist > this.maxRange.get()) {
         return null;
      }
      return living;
   }

   private String nameOf(LivingEntity living) {
      if (living instanceof PlayerEntity player && player.getGameProfile() != null) {
         return player.getGameProfile().name();
      }
      return living.getDisplayName() != null ? living.getDisplayName().getString() : living.getType().getName().getString();
   }

   private List<String> cachedRows = new ArrayList<>();

   @Override
   public void onTick() {
      LivingEntity target = this.target();
      this.cachedRows = target != null ? this.rows(target) : new ArrayList<>();
   }

   private List<String> currentRows() {
      if (this.cachedRows.isEmpty()) {
         LivingEntity target = this.target();
         this.cachedRows = target != null ? this.rows(target) : new ArrayList<>();
      }
      return this.cachedRows;
   }

   private List<String> rows(LivingEntity target) {
      MinecraftClient mc = MinecraftClient.getInstance();
      List<String> out = new ArrayList<>();
      out.add(this.nameOf(target));
      if (this.showHp.get()) {
         int hp = (int) Math.ceil(target.getHealth());
         out.add("HP " + hp + " / " + (int) Math.ceil(target.getMaxHealth()));
      }
      if (this.showDistance.get()) {
         double dist = mc.player.distanceTo(target);
         out.add(String.format("%.1f m", dist));
      }
      return out;
   }

   @Override
   public void render(DrawContext context) {
      List<String> rows = this.currentRows();
      if (rows.isEmpty() || MinecraftClient.getInstance().player == null) {
         return;
      }
      this.drawPanel(context, this.getWidthCached(), this.getHeightCached());
      int ty = this.y + 6;
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      int hp = this.hpColor.currentRgb(System.currentTimeMillis());
      for (int i = 0; i < rows.size(); i++) {
         boolean hpRow = i == 1 && rows.size() > 1;
         RenderUtil.drawText(context, rows.get(i), this.x + 6 + 2, ty, hpRow ? hp : color);
         ty += 9;
      }
   }

   @Override
   public int getWidth() {
      List<String> rows = this.currentRows();
      if (rows.isEmpty()) {
         return 20;
      }
      int max = 0;
      for (String row : rows) {
         max = Math.max(max, RenderUtil.textWidth(row));
      }
      return Math.max(20, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      List<String> rows = this.currentRows();
      if (rows.isEmpty()) {
         return 21;
      }
      return Math.max(21, rows.size() * 9 + 12);
   }
}
