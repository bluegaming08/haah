package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

/**
 * Drop Warning (v3 catalogue E6, advisory) — when you press the drop key while
 * holding an item that carries a custom name, you get a toast + tone before it
 * leaves your hand. A safety reminder only; it never blocks or reverts the drop
 * (that would be server-authoritative tampering).
 */
public class DropWarning extends Module {
   private final BooleanSetting sound = new BooleanSetting("Sound", "Soft alert tone", true);
   private boolean prevPressed = false;

   public DropWarning() {
      super("Drop Warning", "Heads-up before you drop a named item", Category.MISC);
      this.addSettings(new Setting[]{this.sound});
   }

   @Override
   protected void onDisable() {
      this.prevPressed = false;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity p = mc.player;
      if (p == null || mc.currentScreen != null) {
         this.prevPressed = mc.options.dropKey.isPressed();
         return;
      }
      boolean pressed = mc.options.dropKey.isPressed();
      if (pressed && !this.prevPressed) {
         ItemStack held = p.getMainHandStack();
         if (held != null && !held.isEmpty() && held.getCustomName() != null) {
            if (this.sound.get()) {
               Sounds.softAlert();
            }
            try {
               BlueClient.getInstance().notificationManager().add(
                  "Drop " + held.getName().getString() + "?", 0xFFFFD15C);
            } catch (Throwable ignored) {
            }
         }
      }
      this.prevPressed = pressed;
   }
}
