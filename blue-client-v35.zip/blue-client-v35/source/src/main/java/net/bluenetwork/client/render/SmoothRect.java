package net.bluenetwork.client.render;

import net.bluenetwork.client.mixin.BlueDrawContextAccessor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import org.joml.Matrix3x2f;
import org.joml.Vector2f;

/**
 * Public drawing helpers for per-pixel anti-aliased rounded rectangles and outline rings,
 * backed by the ROUNDED_RECT pipeline. Every screen in the client draws panels through
 * this class, so corners stay smooth at any GUI scale.
 */
public final class SmoothRect {
    private SmoothRect() {
    }

    public static void fill(DrawContext context, float x, float y, float w, float h, float radius, int color) {
        if (w <= 0.0F || h <= 0.0F) {
            return;
        }
        float x1 = x + w;
        float y1 = y + h;
        Matrix3x2f pose = new Matrix3x2f(context.getMatrices());
        ScreenRect bounds = bounds(context, x, y, x1, y1);
        RoundedRectGuiElement element = new RoundedRectGuiElement(pose, x, y, x1, y1, radius, color, scissor(context), bounds);
        ((BlueDrawContextAccessor) (Object) context).blueclient$guiState().addSimpleElement(element);
    }

    /** Outline ring of the given thickness; the interior keeps whatever is behind it. */
    public static void outline(DrawContext context, float x, float y, float w, float h, float radius, float thickness, int color) {
        if (w <= 0.0F || h <= 0.0F || thickness <= 0.0F) {
            return;
        }
        float x1 = x + w;
        float y1 = y + h;
        Matrix3x2f pose = new Matrix3x2f(context.getMatrices());
        ScreenRect bounds = bounds(context, x, y, x1, y1);
        RoundedRingGuiElement element = new RoundedRingGuiElement(pose, x, y, x1, y1, radius, thickness, color, scissor(context), bounds);
        ((BlueDrawContextAccessor) (Object) context).blueclient$guiState().addSimpleElement(element);
    }

    /** Panel with a 1px border: background fill plus a ring in the border colour. */
    public static void panel(DrawContext context, float x, float y, float w, float h, float radius, int border, int background) {
        fill(context, x, y, w, h, radius, background);
        outline(context, x, y, w, h, radius, 1.0F, border);
    }

    static ScreenRect scissor(DrawContext context) {
        return BlueScissors.current();
    }

    static ScreenRect bounds(DrawContext context, float x0, float y0, float x1, float y1) {
        Matrix3x2f pose = context.getMatrices();
        Vector2f a = pose.transformPosition(x0, y0, new Vector2f());
        Vector2f b = pose.transformPosition(x1, y1, new Vector2f());
        int left = (int) Math.floor(Math.min(a.x, b.x));
        int top = (int) Math.floor(Math.min(a.y, b.y));
        int right = (int) Math.ceil(Math.max(a.x, b.x));
        int bottom = (int) Math.ceil(Math.max(a.y, b.y));
        return new ScreenRect(left, top, right - left, bottom - top);
    }
}
