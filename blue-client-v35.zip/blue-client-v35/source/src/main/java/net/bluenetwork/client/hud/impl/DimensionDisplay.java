package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;

/**
 * Dimension Display (bonus HUD) — shows which dimension you're in
 * (Overworld / The Nether / The End / custom dimension id). Helps when server
 * hubs or data packs teleport you somewhere unexpected.
 */
public class DimensionDisplay extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);

   public DimensionDisplay() {
      super("Dimension Display", "Which dimension you are in", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 27);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) {
         return "Dimension --";
      }
      RegistryKey<World> dim = mc.world.getRegistryKey();
      if (dim == World.OVERWORLD) {
         return "Overworld";
      }
      if (dim == World.NETHER) {
         return "The Nether";
      }
      if (dim == World.END) {
         return "The End";
      }
      return dim.getValue().getPath().replace('_', ' ');
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
