package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Sprint Modes (v3 catalogue F4) — pick how sprinting behaves:
 * Always (sprint while walking forward), Toggle (press sprint to toggle it
 * on/off), Hold (vanilla-style: sprint while you hold the sprint key), or
 * Off (vanilla default, no forcing). One mode at a time; when enabled it
 * replaces the bare ToggleSprint behaviour for sprinting.
 */
public class SprintModes extends Module {
   private static final String[] MODES = {"Always", "Toggle", "Hold", "Off"};
   private final ModeSetting mode = new ModeSetting("Mode", "Sprint behaviour", List.of(MODES), "Always");

   private boolean toggled = false;
   private boolean prevSprintKey = false;

   public SprintModes() {
      super("Sprint Modes", "Choose Always / Toggle / Hold / vanilla sprint", Category.MOVEMENT);
      this.addSettings(new Setting[]{this.mode});
   }

   @Override
   protected void onDisable() {
      this.toggled = false;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.player != null) {
         mc.player.setSprinting(false);
      }
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity p = mc.player;
      if (p == null) {
         this.prevSprintKey = false;
         return;
      }
      boolean sprintKey = mc.options.sprintKey.isPressed();
      if (sprintKey && !this.prevSprintKey) {
         if ("Toggle".equals(this.mode.get())) {
            this.toggled = !this.toggled;
         } else if ("Hold".equals(this.mode.get())) {
            this.toggled = true;
         }
      } else if (!sprintKey && this.prevSprintKey && "Hold".equals(this.mode.get())) {
         this.toggled = false;
      }
      this.prevSprintKey = sprintKey;

      boolean forward = mc.options.forwardKey.isPressed();
      boolean hungry = p.getHungerManager().getFoodLevel() > 6;
      boolean want = forward && hungry && !p.isSneaking();
      switch (this.mode.get()) {
         case "Always" -> p.setSprinting(want);
         case "Toggle" -> p.setSprinting(this.toggled && forward && hungry && !p.isSneaking());
         case "Hold" -> p.setSprinting(this.toggled && want);
         default -> {
            // Off = vanilla behaviour; don't force anything.
            if (!sprintKey && !forward && p.isSprinting()) {
               p.setSprinting(false);
            }
         }
      }
   }
}
