package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;

/**
 * Low Food Alert (bonus audio alert, sibling of Low Health Alert) — a toast +
 * soft tone when hunger drops to the threshold, with a cooldown so it never
 * spams. Pure client-side read of the hunger manager.
 */
public class LowFoodAlert extends Module {
   private final NumberSetting threshold = new NumberSetting("Hunger at/below", "Alert when hunger is at or below this", 6.0, 1.0, 20.0, 1.0);
   private final NumberSetting cooldown = new NumberSetting("Cooldown", "Seconds between alerts", 15.0, 5.0, 120.0, 5.0);
   private final BooleanSetting sound = new BooleanSetting("Sound", "Soft alert tone", true);

   private boolean wasLow = false;
   private long lastAlert = 0L;

   public LowFoodAlert() {
      super("Low Food Alert", "Alert when hunger runs low", Category.MISC);
      this.addSettings(new Setting[]{this.threshold, this.cooldown, this.sound});
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         this.wasLow = false;
         return;
      }
      int hunger = mc.player.getHungerManager().getFoodLevel();
      boolean low = hunger <= this.threshold.getInt();
      long now = System.currentTimeMillis();
      if (low) {
         if (!this.wasLow || now - this.lastAlert >= (long) (this.cooldown.get() * 1000.0)) {
            this.lastAlert = now;
            if (this.sound.get()) {
               Sounds.softAlert();
            }
            try {
               BlueClient.getInstance().notificationManager().add("Hunger low - eat something!", 0xFFFFD15C);
            } catch (Throwable ignored) {
            }
         }
         this.wasLow = true;
      } else {
         this.wasLow = false;
      }
   }
}
