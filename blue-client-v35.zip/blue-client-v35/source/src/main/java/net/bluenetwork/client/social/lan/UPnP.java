package net.bluenetwork.client.social.lan;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.bluenetwork.client.BlueClient;

/**
 * A minimal, dependency-free UPnP (IGD) port mapper.
 *
 * <h2>What this is for</h2>
 * The owner chose option (a) for LAN invites: <b>UPnP only</b>. No relay, no
 * VPS, no piggybacking on e4mc or World Host. When a player opens their world
 * to LAN and invites a friend, we ask the router to forward the LAN port to
 * the internet, then hand the friend {@code publicIp:port}.
 *
 * <h2>How UPnP works, briefly</h2>
 * <ol>
 *   <li><b>Discover.</b> Broadcast an SSDP {@code M-SEARCH} to 239.255.255.250:1900.
 *       Routers that speak IGD reply with a {@code LOCATION:} header pointing
 *       at an XML device description.</li>
 *   <li><b>Describe.</b> GET that XML and find the control URL of the
 *       {@code WANIPConnection} or {@code WANPPPConnection} service.</li>
 *   <li><b>Act.</b> POST SOAP envelopes to that control URL:
 *       {@code AddPortMapping}, {@code DeletePortMapping},
 *       {@code GetExternalIPAddress}.</li>
 * </ol>
 *
 * <h2>Why hand-rolled</h2>
 * The usual library (weupnp / cling) is another jar to ship and shade into a
 * Minecraft mod. The three SOAP calls we need are about thirty lines of XML
 * between them, so the dependency is not worth it.
 *
 * <h2>Failure is normal and must be quiet</h2>
 * Plenty of routers have UPnP disabled, and carrier-grade NAT defeats it
 * entirely. Every method here returns a result rather than throwing, and the
 * UI is expected to say "your router would not open a port" and offer the
 * plain LAN address instead. <b>Nothing here may ever crash the game.</b>
 */
public final class UPnP {

   /** SSDP multicast endpoint. */
   private static final String SSDP_ADDR = "239.255.255.250";
   private static final int SSDP_PORT = 1900;

   /** How long to listen for router replies. */
   private static final int DISCOVER_TIMEOUT_MS = 3000;
   /** SOAP calls are local network - they should be near-instant. */
   private static final int SOAP_TIMEOUT_MS = 5000;

   /** The two service types an IGD may expose for port mapping. */
   private static final String[] SERVICE_TYPES = {
      "urn:schemas-upnp-org:service:WANIPConnection:1",
      "urn:schemas-upnp-org:service:WANPPPConnection:1",
      "urn:schemas-upnp-org:service:WANIPConnection:2",
   };

   private static final Pattern LOCATION =
      Pattern.compile("(?im)^LOCATION:\\s*(\\S+)\\s*$");

   /** Result of a mapping attempt. */
   public record Result(boolean ok, String address, String error) {
      public static Result fail(String why) {
         return new Result(false, null, why);
      }
   }

   /** The gateway we found, and the service we can talk to. */
   private record Gateway(String controlUrl, String serviceType) {
   }

   private static volatile Gateway cached;
   /** Ports we opened, so they can be closed again on shutdown. */
   private static final List<Integer> OPENED = new ArrayList<>();

   private UPnP() {
   }

   /**
    * Opens {@code port} to the internet and resolves the public address.
    *
    * <p>Runs entirely off the render thread - never call this inline.</p>
    */
   public static CompletableFuture<Result> open(int port) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            Gateway gw = gateway();
            if (gw == null) {
               return Result.fail("No UPnP router found. "
                  + "Enable UPnP in your router settings, or use Hamachi/Radmin.");
            }

            // A refused mapping is usually a duplicate from a previous session,
            // so drop any stale one first and retry once.
            if (!addMapping(gw, port)) {
               deleteMapping(gw, port);
               if (!addMapping(gw, port)) {
                  return Result.fail("Your router refused to open port " + port + ".");
               }
            }

            String ip = externalIp(gw);
            if (ip == null || ip.isBlank() || ip.startsWith("0.")) {
               return Result.fail("Port opened, but the router would not report "
                  + "your public IP.");
            }

            synchronized (OPENED) {
               if (!OPENED.contains(port)) {
                  OPENED.add(port);
               }
            }
            return new Result(true, ip + ":" + port, null);
         } catch (Throwable t) {
            BlueClient.LOGGER.warn("[UPnP] open failed", t);
            return Result.fail("UPnP failed: " + t.getClass().getSimpleName());
         }
      });
   }

   /** Closes a mapping we opened. Best effort - errors are swallowed. */
   public static CompletableFuture<Void> close(int port) {
      return CompletableFuture.runAsync(() -> {
         try {
            Gateway gw = gateway();
            if (gw != null) {
               deleteMapping(gw, port);
            }
            synchronized (OPENED) {
               OPENED.remove(Integer.valueOf(port));
            }
         } catch (Throwable ignored) {
            // Leaving a mapping behind is untidy but harmless; most routers
            // drop them on reboot and we reuse them on the next session.
         }
      });
   }

   /** Closes everything we opened. Wired to the client shutdown hook. */
   public static void closeAll() {
      List<Integer> copy;
      synchronized (OPENED) {
         copy = List.copyOf(OPENED);
      }
      for (int port : copy) {
         try {
            Gateway gw = cached;
            if (gw != null) {
               deleteMapping(gw, port);
            }
         } catch (Throwable ignored) {
         }
      }
      synchronized (OPENED) {
         OPENED.clear();
      }
   }

   /* ------------------------------------------------------------ discovery */

   private static Gateway gateway() {
      Gateway local = cached;
      if (local != null) {
         return local;
      }
      for (String type : SERVICE_TYPES) {
         String location = discover(type);
         if (location == null) {
            continue;
         }
         Gateway gw = describe(location);
         if (gw != null) {
            cached = gw;
            return gw;
         }
      }
      return null;
   }

   /** Sends an SSDP M-SEARCH and returns the first LOCATION offered. */
   private static String discover(String serviceType) {
      String request = "M-SEARCH * HTTP/1.1\r\n"
         + "HOST: " + SSDP_ADDR + ":" + SSDP_PORT + "\r\n"
         + "MAN: \"ssdp:discover\"\r\n"
         + "MX: 2\r\n"
         + "ST: " + serviceType + "\r\n\r\n";

      try (DatagramSocket socket = new DatagramSocket()) {
         socket.setSoTimeout(DISCOVER_TIMEOUT_MS);
         byte[] out = request.getBytes(StandardCharsets.UTF_8);
         socket.send(new DatagramPacket(out, out.length,
            InetAddress.getByName(SSDP_ADDR), SSDP_PORT));

         long deadline = System.currentTimeMillis() + DISCOVER_TIMEOUT_MS;
         byte[] buf = new byte[2048];
         while (System.currentTimeMillis() < deadline) {
            DatagramPacket in = new DatagramPacket(buf, buf.length);
            try {
               socket.receive(in);
            } catch (IOException timeout) {
               return null;
            }
            String reply = new String(in.getData(), 0, in.getLength(),
               StandardCharsets.UTF_8);
            Matcher m = LOCATION.matcher(reply);
            if (m.find()) {
               return m.group(1);
            }
         }
      } catch (Throwable ignored) {
         // No network, no multicast permission, no router: all the same to us.
      }
      return null;
   }

   /** Fetches the device XML and digs out a usable control URL. */
   private static Gateway describe(String location) {
      try {
         URL url = URI.create(location).toURL();
         HttpURLConnection conn = (HttpURLConnection) url.openConnection();
         conn.setConnectTimeout(SOAP_TIMEOUT_MS);
         conn.setReadTimeout(SOAP_TIMEOUT_MS);
         String xml;
         try (var in = conn.getInputStream()) {
            xml = new String(in.readAllBytes(), StandardCharsets.UTF_8);
         }

         for (String type : SERVICE_TYPES) {
            int at = xml.indexOf(type);
            if (at < 0) {
               continue;
            }
            // controlURL appears after the serviceType inside the same
            // <service> block, so searching forward from here is safe.
            int open = xml.indexOf("<controlURL>", at);
            int close = xml.indexOf("</controlURL>", open);
            if (open < 0 || close < 0) {
               continue;
            }
            String path = xml.substring(open + 12, close).trim();
            String base = url.getProtocol() + "://" + url.getHost()
               + (url.getPort() > 0 ? ":" + url.getPort() : "");
            String control = path.startsWith("http") ? path
               : base + (path.startsWith("/") ? path : "/" + path);
            return new Gateway(control, type);
         }
      } catch (Throwable ignored) {
      }
      return null;
   }

   /* ----------------------------------------------------------------- SOAP */

   private static boolean addMapping(Gateway gw, int port) {
      String localIp = localAddress();
      if (localIp == null) {
         return false;
      }
      // Lease 0 = "until I delete it or the router reboots". Some routers
      // reject non-zero leases outright, so 0 is the compatible choice.
      String body = """
         <NewRemoteHost></NewRemoteHost>
         <NewExternalPort>%d</NewExternalPort>
         <NewProtocol>TCP</NewProtocol>
         <NewInternalPort>%d</NewInternalPort>
         <NewInternalClient>%s</NewInternalClient>
         <NewEnabled>1</NewEnabled>
         <NewPortMappingDescription>Blue Client LAN</NewPortMappingDescription>
         <NewLeaseDuration>0</NewLeaseDuration>
         """.formatted(port, port, localIp);
      return soap(gw, "AddPortMapping", body) != null;
   }

   private static void deleteMapping(Gateway gw, int port) {
      String body = """
         <NewRemoteHost></NewRemoteHost>
         <NewExternalPort>%d</NewExternalPort>
         <NewProtocol>TCP</NewProtocol>
         """.formatted(port);
      soap(gw, "DeletePortMapping", body);
   }

   private static String externalIp(Gateway gw) {
      String reply = soap(gw, "GetExternalIPAddress", "");
      if (reply == null) {
         return null;
      }
      int open = reply.indexOf("<NewExternalIPAddress>");
      int close = reply.indexOf("</NewExternalIPAddress>");
      if (open < 0 || close < 0) {
         return null;
      }
      return reply.substring(open + 22, close).trim();
   }

   /** Posts one SOAP action. Returns the body on success, null on failure. */
   private static String soap(Gateway gw, String action, String innerXml) {
      String envelope = """
         <?xml version="1.0"?>
         <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" \
         s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
         <s:Body><u:%s xmlns:u="%s">%s</u:%s></s:Body></s:Envelope>
         """.formatted(action, gw.serviceType(), innerXml, action);

      try {
         HttpURLConnection conn =
            (HttpURLConnection) URI.create(gw.controlUrl()).toURL().openConnection();
         conn.setRequestMethod("POST");
         conn.setDoOutput(true);
         conn.setConnectTimeout(SOAP_TIMEOUT_MS);
         conn.setReadTimeout(SOAP_TIMEOUT_MS);
         conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
         conn.setRequestProperty("SOAPAction",
            "\"" + gw.serviceType() + "#" + action + "\"");

         byte[] payload = envelope.getBytes(StandardCharsets.UTF_8);
         conn.setRequestProperty("Content-Length", String.valueOf(payload.length));
         try (var out = conn.getOutputStream()) {
            out.write(payload);
         }

         if (conn.getResponseCode() != 200) {
            return null;
         }
         try (var in = conn.getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
         }
      } catch (Throwable ignored) {
         return null;
      }
   }

   /**
    * This machine's LAN address.
    *
    * <p>{@code InetAddress.getLocalHost()} famously returns 127.0.0.1 on many
    * Linux setups, which the router would reject as an internal client. Opening
    * a throwaway UDP socket to a public address and reading back the local end
    * makes the OS pick the interface it would really route through - no packet
    * is actually sent.</p>
    */
   private static String localAddress() {
      try (DatagramSocket probe = new DatagramSocket()) {
         probe.connect(new InetSocketAddress("1.1.1.1", 80));
         String ip = probe.getLocalAddress().getHostAddress();
         if (ip != null && !ip.startsWith("127.") && !ip.equals("0.0.0.0")) {
            return ip;
         }
      } catch (Throwable ignored) {
      }
      try {
         return InetAddress.getLocalHost().getHostAddress();
      } catch (Throwable ignored) {
         return null;
      }
   }

   /** True when something is actually listening - a cheap sanity check. */
   public static boolean portIsListening(int port) {
      try (Socket s = new Socket()) {
         s.connect(new InetSocketAddress("127.0.0.1", port), 500);
         return true;
      } catch (Throwable t) {
         return false;
      }
   }

   /** Human-readable summary for logs. */
   public static String describeState() {
      Gateway gw = cached;
      synchronized (OPENED) {
         return (gw == null ? "no gateway" : "gateway "
            + gw.serviceType().toLowerCase(Locale.ROOT))
            + ", " + OPENED.size() + " port(s) open";
      }
   }
}
