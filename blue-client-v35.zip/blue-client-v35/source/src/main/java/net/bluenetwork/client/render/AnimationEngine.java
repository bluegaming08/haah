package net.bluenetwork.client.render;

/**
 * Easing helpers from the premium pack, merged into the render package.
 * Pure math - used by HUD/GUI animations where BlueAnim's stateful
 * helpers are not needed.
 */
public final class AnimationEngine {
   private AnimationEngine() {
   }

   public static float easeInOutCubic(float t) {
      return t < 0.5F ? 4.0F * t * t * t : 1.0F - (float)Math.pow(-2.0F * t + 2.0F, 3.0D) / 2.0F;
   }

   public static float easeOutQuart(float t) {
      return 1.0F - (float)Math.pow(1.0D - t, 4.0D);
   }

   public static float easeInOutExpo(float t) {
      if (t == 0.0F) {
         return 0.0F;
      } else if (t == 1.0F) {
         return 1.0F;
      } else {
         return t < 0.5F ? (float)Math.pow(2.0D, 20.0D * t - 10.0D) / 2.0F : (2.0F - (float)Math.pow(2.0D, -20.0D * t + 10.0D)) / 2.0F;
      }
   }

   public static float easeOutElastic(float t) {
      float c5 = (float)(2.0D * Math.PI) / 4.5F;
      if (t != 0.0F && t != 1.0F) {
         return (float)Math.pow(2.0D, -10.0D * t) * (float)Math.sin((t * 10.0F - 0.75F) * c5) + 1.0F;
      } else {
         return t == 0.0F ? 0.0F : 1.0F;
      }
   }

   public static float easeOutBounce(float t) {
      float n1 = 7.5625F;
      float d1 = 2.75F;
      if (t < 1.0F / d1) {
         return n1 * t * t;
      } else if (t < 2.0F / d1) {
         float var = t - 1.5F / d1;
         return n1 * var * var + 0.75F;
      } else if (t < 2.5F / d1) {
         float var = t - 2.25F / d1;
         return n1 * var * var + 0.9375F;
      } else {
         float var = t - 2.625F / d1;
         return n1 * var * var + 0.984375F;
      }
   }

   public static float smoothstep(float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      return t * t * (3.0F - 2.0F * t);
   }

   public static float lerp(float a, float b, float t) {
      return a + (b - a) * t;
   }

   public static int lerpInt(int a, int b, float t) {
      return a + (int)((float)(b - a) * t);
   }
}
