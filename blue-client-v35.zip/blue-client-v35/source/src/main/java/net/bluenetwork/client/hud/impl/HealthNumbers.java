package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Health Numbers (v3 catalogue A3) — numeric health (with optional absorption)
 * rendered as a small panel. Colour lerps from the low colour (near 0 HP) to
 * the healthy colour (full HP), so the number shades red→white as you heal.
 */
public class HealthNumbers extends HudModule {
   private final ColorSetting lowColor = new ColorSetting("Low color", "Colour near 0 HP", 0xFFFF5C5C);
   private final ColorSetting highColor = new ColorSetting("High color", "Colour at full HP", 0xFFFFFFFF);
   private final BooleanSetting absorption = new BooleanSetting("Show absorption", "Show +absorption on a second line", true);
   private final BooleanSetting decimals = new BooleanSetting("Decimals", "Show halves (e.g. 7.5) instead of rounded HP", false);

   public HealthNumbers() {
      super("Health Numbers", "Numeric health + absorption over your hearts", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.lowColor, this.highColor, this.absorption, this.decimals});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 102);
   }

   private float health() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.player == null ? 0.0F : mc.player.getHealth();
   }

   private float maxHealth() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.player == null ? 20.0F : Math.max(1.0F, mc.player.getMaxHealth());
   }

   private float absorption() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.player == null ? 0.0F : Math.max(0.0F, mc.player.getAbsorptionAmount());
   }

   private String mainLine() {
      float h = this.health();
      float max = this.maxHealth();
      if (this.decimals.get()) {
         return String.format("%.1f / %.1f", h, max);
      }
      return Math.round(h) + " / " + Math.round(max);
   }

   private int healthColor() {
      float ratio = Math.max(0.0F, Math.min(1.0F, this.health() / this.maxHealth()));
      int lo = this.lowColor.currentRgb(System.currentTimeMillis());
      int hi = this.highColor.currentRgb(System.currentTimeMillis());
      return lerpArgb(lo, hi, ratio);
   }

   private static int lerpArgb(int a, int b, float t) {
      int ar = a >> 16 & 0xFF;
      int ag = a >> 8 & 0xFF;
      int ab = a & 0xFF;
      int br = b >> 16 & 0xFF;
      int bg = b >> 8 & 0xFF;
      int bb = b & 0xFF;
      int r = Math.round(ar + (br - ar) * t);
      int g = Math.round(ag + (bg - ag) * t);
      int bl = Math.round(ab + (bb - ab) * t);
      return 0xFF000000 | r << 16 | g << 8 | bl;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      int rows = 1 + (this.absorption.get() && this.absorption() > 0.0F ? 1 : 0);
      int panelH = Math.max(21, rows * 9 + 12);
      this.drawPanel(context, this.getWidthCached(), panelH);
      RenderUtil.drawText(context, this.mainLine(), this.x + 6 + 2, this.y + 6, this.healthColor());
      if (rows > 1) {
         String abs = this.decimals.get()
            ? String.format("+%.1f", this.absorption())
            : "+" + Math.round(this.absorption());
         RenderUtil.drawText(context, abs, this.x + 6 + 2, this.y + 15, 0xFF9BE7FF);
      }
   }

   @Override
   public int getWidth() {
      int w0 = RenderUtil.textWidth(this.mainLine());
      if (this.absorption.get() && this.absorption() > 0.0F) {
         String abs = this.decimals.get()
            ? String.format("+%.1f", this.absorption())
            : "+" + Math.round(this.absorption());
         w0 = Math.max(w0, RenderUtil.textWidth(abs));
      }
      return Math.max(20, w0 + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = 1 + (this.absorption.get() && this.absorption() > 0.0F ? 1 : 0);
      return Math.max(21, rows * 9 + 12);
   }
}
