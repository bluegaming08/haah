package net.bluenetwork.client.ui.theme;

/**
 * The three Blue Client themes (v0.24.0).
 *
 * <h2>Owner spec, verbatim</h2>
 * <pre>
 *   there should be 3 themes, black, glass and white.
 *   black should be the default theme when u start the game.
 *   the buttons in black theme should be like a black to dark gray gradient,
 *   and the background should be 100% opaque.
 *   glass is the current theme (10% opacity).
 *   white should be white to gray gradient.
 * </pre>
 *
 * <h2>Why an enum and not strings</h2>
 * v11 stored the theme as a free-text string and had SEVEN of them
 * (DARK, LIGHT, COSMIC, EMBER, MIDNIGHT, NEON, EMERALD). Any typo silently
 * fell through to a default, and every screen had its own switch. Now the enum
 * is the single source of truth, {@link #fromId(String)} migrates every legacy
 * name, and the colours live in one place ({@link ThemePalette}).
 *
 * <h2>Migration from older configs</h2>
 * <pre>
 *   DARK, MIDNIGHT, NEON, COSMIC, EMBER, EMERALD -> BLACK
 *   LIGHT                                        -> WHITE
 *   anything unrecognised / null                 -> BLACK (the default)
 * </pre>
 * The five "premium" themes collapse into BLACK because the owner replaced
 * them; keeping them alive would contradict "there should be 3 themes".
 */
public enum ThemeStyle {

   /**
    * BLACK — the default. Fully opaque near-black surfaces, buttons drawn as a
    * black → dark-grey vertical gradient. This is what the client starts on.
    */
   BLACK("Black"),

   /**
    * GLASS — the v11 look: translucent (~10 % opacity) panels over the game,
    * with visible hairline borders so the edges read against any background.
    */
   GLASS("Glass"),

   /**
    * WHITE — the light theme. Opaque white surfaces, buttons drawn as a
    * white → grey vertical gradient, and dark text so it stays readable.
    */
   WHITE("White");

   private final String displayName;

   ThemeStyle(String displayName) {
      this.displayName = displayName;
   }

   /** Human-facing name, e.g. for the theme cycler button. */
   public String displayName() {
      return this.displayName;
   }

   /** True for themes designed on a light background (drives text colour). */
   public boolean isLight() {
      return this == WHITE;
   }

   /** True when panels are see-through, so borders must be drawn. */
   public boolean isTranslucent() {
      return this == GLASS;
   }

   /** The next theme in the cycle, for the one-click theme button. */
   public ThemeStyle next() {
      ThemeStyle[] all = values();
      return all[(this.ordinal() + 1) % all.length];
   }

   /**
    * Resolves a stored/config theme name, migrating every legacy value.
    * Never returns null — unknown input yields {@link #BLACK}.
    */
   public static ThemeStyle fromId(String id) {
      if (id == null || id.isBlank()) {
         return BLACK;
      }
      String key = id.trim().toUpperCase(java.util.Locale.ROOT);
      /*
       * Only three themes exist now (BLACK / GLASS / WHITE). Older builds
       * shipped several dark variants that were folded into BLACK, and any of
       * those names can still be sitting in a user's config file or in a
       * shared BLUE1- profile code.
       *
       * The `default -> BLACK` arm already maps every retired dark name to the
       * right place, so they no longer need to be listed individually. WHITE
       * and GLASS must stay explicit: they are the only values that must NOT
       * fall through to BLACK.
       */
      return switch (key) {
         case "WHITE", "LIGHT" -> WHITE;
         case "GLASS" -> GLASS;
         default -> BLACK;
      };
   }

   /** Theme ids in cycle order — used by settings screens. */
   public static final String[] IDS = {BLACK.name(), GLASS.name(), WHITE.name()};
}
