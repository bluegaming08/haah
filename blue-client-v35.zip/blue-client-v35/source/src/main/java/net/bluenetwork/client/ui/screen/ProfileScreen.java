package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.account.PlayerHeads;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.social.FriendsManager;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * A player's profile card.
 *
 * <h2>The design</h2>
 * A single tall card, built around the player's <b>bust render</b> (the same
 * {@code mc-api.io} art the account manager uses, so heads look consistent
 * across the client). Layout, top to bottom:
 *
 * <pre>
 *   +----------------------------------+
 *   |          [ bust render ]         |   96px, centred, soft glow behind
 *   |            Username              |   large
 *   |          [ BADGE CHIP ]          |   coloured pill, equipped badge only
 *   |        "about me" line           |   50 chars max
 *   |  1,204 Followers   37 Following  |   two stat columns with a divider
 *   |  [ FOLLOW ] [ MESSAGE ] [ JOIN ] |   action row
 *   +----------------------------------+
 * </pre>
 *
 * <p>Everything below the bust is optional and the card shrinks to fit, so a
 * brand-new account with no badge and no bio still looks deliberate rather
 * than empty.</p>
 *
 * <h2>Own profile vs someone else's</h2>
 * Viewing yourself swaps the action row for edit controls: set status, set
 * about, and equip a badge from the ones you own.
 */
public class ProfileScreen extends Screen {

   private static final int DESIGN_W = 700;
   private static final int DESIGN_H = 430;
   private static final int GREEN = 0xFF43D17A;
   private static final int GREY = 0xFF8A94A6;

   private final Screen parent;
   private final String userId;
   private final boolean self;

   private FriendsManager.Profile profile;
   private boolean loading = true;
   /** Transient message from the last action (e.g. a refused buddy request). */
   private volatile String notice;

   /* editing state (own profile only) */
   private String editField;         // "about" | "status" | null
   private String draftAbout = "";
   private String draftStatus = "";
   /** Minecraft username the social avatar is rendered from. */
   private String draftSkin = "";
   private volatile String skinNotice;
   /** True when {@link #skinNotice} is a success message, not an error. */
   private volatile boolean skinOk;

   private float drawScale = 1.0F;
   private float scroll;
   private final List<Hit> hits = new ArrayList<>();

   public ProfileScreen(Screen parent, String userId, boolean self) {
      super(Text.literal("Profile"));
      this.parent = parent;
      this.userId = userId;
      this.self = self;
   }

   private static FriendsManager social() {
      return BlueClient.getInstance().friends();
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   protected void init() {
      social().loadProfile(this.userId, p -> {
         this.profile = p;
         this.loading = false;
         if (p != null) {
            this.draftAbout = p.about() == null ? "" : p.about();
            this.draftStatus = p.status() == null ? "" : p.status();
            String sk = social().skinName();
            this.draftSkin = sk == null ? "" : sk;
         }
      });
   }

   /* ====================================================================== */
   /*  Render                                                                */
   /* ====================================================================== */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0xB20B0E14);

      float base = 0.75F;
      float fit = Math.min(1.0F,
         Math.min(w / (base * DESIGN_W + 12.0F), h / (base * DESIGN_H + 12.0F)));
      float scale = base * Math.max(0.35F, fit);
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int mx = (int) (mouseX / scale);
      int my = (int) (mouseY / scale);

      float pw = Math.min(vw - 24, 300);
      float ph = Math.min(vh - 24, 390);
      float px = (vw - pw) / 2.0F;
      float py = (vh - ph) / 2.0F;

      this.hits.clear();
      PremiumRender.drawShadow(context, (int) px - 2, (int) py - 2,
         (int) pw + 4, (int) ph + 4, 0x77000000, 14);
      SmoothRect.fill(context, px, py, pw, ph, 10.0F, DesignTokens.panelBg());
      SmoothRect.outline(context, px, py, pw, ph, 10.0F, 1.0F, DesignTokens.panelBorder());

      // close
      boolean hovX = hit(mx, my, px + pw - 24, py + 10, 14, 14);
      TextPainter.drawPoppins(context, "X", px + pw - 20, py + 13,
         hovX ? DesignTokens.textHi() : GREY, 10.0F);
      this.hits.add(new Hit(px + pw - 24, py + 10, 14, 14, "close"));

      // Show why the last action was refused (e.g. "They already have a
      // buddy."). Sits just under the panel so it never covers the content.
      String msg = this.notice;
      if (msg != null && !msg.isBlank()) {
         centered(context, msg, px + pw / 2.0F, py + ph - 14, 0xFFE35D5D, 8.0F);
      }

      if (this.loading) {
         centered(context, "Loading...", px + pw / 2.0F, py + ph / 2.0F - 4, GREY, 9.0F);
         context.getMatrices().popMatrix();
         return;
      }
      if (this.profile == null) {
         centered(context, "Profile unavailable.", px + pw / 2.0F, py + ph / 2.0F - 4, GREY, 9.0F);
         context.getMatrices().popMatrix();
         return;
      }

      drawCard(context, px, py, pw, ph, mx, my);
      context.getMatrices().popMatrix();
   }

   private void drawCard(DrawContext ctx, float px, float py, float pw, float ph,
                         int mx, int my) {
      FriendsManager.Profile p = this.profile;
      float cx = px + pw / 2.0F;
      float y = py + 22;

      /* ---- bust render ------------------------------------------------- */
      // A soft accent glow behind the bust makes the flat PNG feel placed
      // rather than pasted.
      int bust = 84;
      float bx = cx - bust / 2.0F;
      SmoothRect.fill(ctx, bx - 6, y - 4, bust + 12, bust + 8, 10.0F,
         withAlpha(DesignTokens.accent(), 0.10F));

      String mcName = p.mcName();
      boolean drew = false;
      if (mcName != null) {
         Identifier tex = PlayerHeads.bust(mcName);
         if (tex != null) {
            // Same call the account manager uses to draw busts.
            ctx.drawTexturedQuad(tex, (int) bx, (int) y,
               (int) bx + bust, (int) y + bust, 0.0F, 1.0F, 0.0F, 1.0F);
            drew = true;
         }
      }
      if (!drew) {
         // No linked Minecraft account (or the art has not loaded yet).
         SmoothRect.fill(ctx, bx, y, bust, bust, 8.0F, 0x33FFFFFF);
         centered(ctx, mcName == null ? "No MC" : "...", cx, y + bust / 2.0F - 4, GREY, 8.0F);
      }
      y += bust + 10;

      /* ---- username + online dot --------------------------------------- */
      float nameW = TextPainter.poppinsWidth(p.username(), 14.0F);
      TextPainter.drawPoppins(ctx, p.username(), cx - nameW / 2.0F, y,
         DesignTokens.textHi(), 14.0F);
      if (p.online()) {
         ctx.fill((int) (cx + nameW / 2.0F + 5), (int) y + 4,
            (int) (cx + nameW / 2.0F + 10), (int) y + 9, GREEN);
      }
      y += 18;

      // Minecraft name underneath, with a tick when it is genuinely verified.
      if (mcName != null) {
         String mcLine = mcName + (p.premium() ? "  verified" : "");
         float mw = TextPainter.poppinsWidth(mcLine, 7.5F);
         TextPainter.drawPoppins(ctx, mcLine, cx - mw / 2.0F, y,
            p.premium() ? GREEN : GREY, 7.5F);
         y += 12;
      }

      /* ---- badge chip --------------------------------------------------- */
      if (p.badgeId() != null && p.badgeLabel() != null) {
         // Icon + label chip. A bare coloured word looked bland and was hard
         // to tell apart from the other eight badges at this size.
         int col = p.badgeColour() | 0xFF000000;
         float chipW = net.bluenetwork.client.ui.BadgeArt.chipWidth(p.badgeLabel(), 8.0F);
         net.bluenetwork.client.ui.BadgeArt.drawChip(ctx, p.badgeId(),
            p.badgeLabel(), col, cx - chipW / 2.0F, y, 8.0F);
         y += 22;
      }

      /* ---- status ------------------------------------------------------- */
      if (p.status() != null && !p.status().isBlank()) {
         centered(ctx, "\"" + p.status() + "\"", cx, y, DesignTokens.textMid(), 8.5F);
         y += 14;
      }

      /* ---- about -------------------------------------------------------- */
      if (p.about() != null && !p.about().isBlank()) {
         centered(ctx, p.about(), cx, y, GREY, 8.0F);
         y += 16;
      } else if (this.self) {
         centered(ctx, "No about me yet", cx, y, 0x55FFFFFF, 8.0F);
         y += 16;
      }

      /* ---- follower stats ----------------------------------------------- */
      y += 4;
      float half = pw / 4.0F;
      drawStat(ctx, px + half, y, String.valueOf(p.followers()), "FOLLOWERS");
      drawStat(ctx, px + pw - half, y, String.valueOf(p.following()), "FOLLOWING");
      // subtle divider between the two columns
      ctx.fill((int) cx, (int) y + 2, (int) cx + 1, (int) y + 24, 0x22FFFFFF);
      y += 34;

      /* ---- actions ------------------------------------------------------ */
      if (this.self) {
         drawOwnActions(ctx, px, y, pw, mx, my);
      } else {
         drawOtherActions(ctx, p, px, y, pw, mx, my);
      }
   }

   private void drawStat(DrawContext ctx, float centreX, float y, String value, String label) {
      float vw = TextPainter.poppinsWidth(value, 12.0F);
      TextPainter.drawPoppins(ctx, value, centreX - vw / 2.0F, y, DesignTokens.textHi(), 12.0F);
      float lw = TextPainter.poppinsWidth(label, 6.5F);
      TextPainter.drawPoppins(ctx, label, centreX - lw / 2.0F, y + 15, GREY, 6.5F);
   }

   private void drawOtherActions(DrawContext ctx, FriendsManager.Profile p,
                                 float px, float y, float pw, int mx, int my) {
      float bw = (pw - 36) / 3.0F;
      float x = px + 12;

      button(ctx, p.isFollowing() ? "FOLLOWING" : "FOLLOW", x, y, bw, 20, mx, my,
         p.isFollowing() ? "unfollow" : "follow", true, p.isFollowing());
      x += bw + 6;

      // DMs are friends-only, enforced server-side too.
      button(ctx, "MESSAGE", x, y, bw, 20, mx, my, "message", p.isFriend(), false);
      x += bw + 6;

      boolean canJoin = p.isFriend() && p.online() && p.server() != null;
      button(ctx, "JOIN", x, y, bw, 20, mx, my, "join", canJoin, false);

      y += 26;
      if (p.isFriend()) {
         boolean isBuddy = p.isBuddy();
         String label = isBuddy ? "REMOVE BUDDY" : "SET AS BUDDY";
         button(ctx, label, px + 12, y, pw - 24, 18, mx, my,
            isBuddy ? "unbuddy" : "buddy", true, isBuddy);
         y += 22;
         centered(ctx, isBuddy
               ? "Mutual buddies earn 3x shards on Blue Network"
               : "Both of you must pick each other for the 3x bonus",
            px + pw / 2.0F, y, GREY, 6.5F);
      } else {
         centered(ctx, "Add them as a friend to message or join",
            px + pw / 2.0F, y + 4, GREY, 7.0F);
      }
   }

   private void drawOwnActions(DrawContext ctx, float px, float y, float pw, int mx, int my) {
      // status / about editors. The caps come from FriendsManager.limitOf(),
      // which mirrors the SQL limit_of() - so a Blue+ subscriber gets the
      // longer allowance here without the number being hardcoded twice.
      editRow(ctx, "STATUS", this.draftStatus, "status",
         social().limitOf("status"), px, y, pw, mx, my);
      y += 34;
      editRow(ctx, "ABOUT ME", this.draftAbout, "about",
         social().limitOf("about"), px, y, pw, mx, my);
      y += 38;

      // SOCIAL SKIN - the avatar shown next to you in the Social screens is
      // rendered from a Minecraft username, so it works whether or not the
      // account is premium. 16 is the Minecraft username limit.
      editRow(ctx, "SKIN (MINECRAFT NAME)", this.draftSkin, "skin",
         16, px, y, pw, mx, my);
      button(ctx, "APPLY SKIN", px + pw - 92, y + 11, 80, 18, mx, my,
         "applyskin", !this.draftSkin.isBlank(), false);
      if (this.skinNotice != null) {
         // Red for a problem, green for success. A silent success looks
         // exactly like a silent failure, which is what "I clicked apply and
         // nothing happened" actually was.
         TextPainter.drawPoppins(ctx, this.skinNotice, px + 12, y + 31,
            this.skinOk ? 0xFF00BA7C : 0xFFF4212E, 7.0F);
         y += 10;
      }
      y += 38;

      // badge picker
      List<FriendsManager.Badge> owned = social().myBadges();
      TextPainter.drawPoppins(ctx, "EQUIPPED BADGE", px + 12, y, DesignTokens.textMid(), 7.5F);
      y += 13;

      if (owned.isEmpty()) {
         TextPainter.drawPoppins(ctx, "You have no badges yet.", px + 12, y, GREY, 7.5F);
         return;
      }

      String current = social().equippedBadge();
      float x = px + 12;
      float rowTop = y;
      for (FriendsManager.Badge b : owned) {
         String label = b.label().toUpperCase(java.util.Locale.ROOT);
         float lw = TextPainter.poppinsWidth(label, 7.0F);
         float chipW = lw + 14;
         if (x + chipW > px + pw - 12) {
            x = px + 12;
            rowTop += 19;
         }
         boolean on = b.id().equals(current);
         int col = b.colour();
         SmoothRect.fill(ctx, x, rowTop, chipW, 16, 8.0F,
            on ? withAlpha(col, 0.30F) : 0x22FFFFFF);
         SmoothRect.outline(ctx, x, rowTop, chipW, 16, 8.0F, 1.0F,
            on ? withAlpha(col, 0.9F) : 0x22FFFFFF);
         TextPainter.drawPoppins(ctx, label, x + 7, rowTop + 4.5F,
            on ? (col | 0xFF000000) : GREY, 7.0F);
         this.hits.add(new Hit(x, rowTop, chipW, 16, "badge:" + b.id()));
         x += chipW + 5;
      }

      if (current != null) {
         rowTop += 22;
         button(ctx, "UNEQUIP", px + 12, rowTop, 70, 16, mx, my, "badge:none", true, false);
      }
   }

   private void editRow(DrawContext ctx, String label, String value, String id,
                        int max, float px, float y, float pw, int mx, int my) {
      TextPainter.drawPoppins(ctx, label, px + 12, y, DesignTokens.textMid(), 7.5F);
      float count = max - value.length();
      String cnt = (int) count + " left";
      float cw = TextPainter.poppinsWidth(cnt, 6.5F);
      TextPainter.drawPoppins(ctx, cnt, px + pw - 12 - cw, y + 1,
         count <= 5 ? 0xFFE35D5D : GREY, 6.5F);

      boolean focused = id.equals(this.editField);
      float fy = y + 11;
      SmoothRect.fill(ctx, px + 12, fy, pw - 24, 18, 4.0F, 0x33000000);
      SmoothRect.outline(ctx, px + 12, fy, pw - 24, 18, 4.0F, 1.0F,
         focused ? DesignTokens.accent() : DesignTokens.panelBorder());

      String shown = value.isEmpty() ? ("Set your " + label.toLowerCase(java.util.Locale.ROOT)) : value;
      TextPainter.drawPoppins(ctx, shown, px + 18, fy + 5,
         value.isEmpty() ? GREY : DesignTokens.textHi(), 8.0F);

      if (focused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         float w = TextPainter.poppinsWidth(value, 8.0F);
         ctx.fill((int) (px + 19 + w), (int) fy + 4, (int) (px + 20 + w), (int) fy + 14,
            DesignTokens.textHi());
      }
      this.hits.add(new Hit(px + 12, fy, pw - 24, 18, "edit:" + id));
   }

   /* ====================================================================== */
   /*  Helpers                                                               */
   /* ====================================================================== */

   private static int withAlpha(int argb, float a) {
      int alpha = Math.max(0, Math.min(255, (int) (a * 255.0F)));
      return (alpha << 24) | (argb & 0xFFFFFF);
   }

   private void centered(DrawContext ctx, String t, float cx, float y, int c, float size) {
      float w = TextPainter.poppinsWidth(t, size);
      TextPainter.drawPoppins(ctx, t, Math.round(cx - w / 2.0F), y, c, size);
   }

   private void button(DrawContext ctx, String label, float x, float y, float w, float h,
                       int mx, int my, String tag, boolean enabled, boolean active) {
      boolean over = enabled && hit(mx, my, x, y, w, h);
      int bg = !enabled ? 0x18FFFFFF
         : active ? withAlpha(DesignTokens.accent(), 0.30F)
         : over ? DesignTokens.accent() : 0x44FFFFFF;
      SmoothRect.fill(ctx, x, y, w, h, 4.0F, bg);
      float tw = TextPainter.poppinsWidth(label, 7.5F);
      TextPainter.drawPoppins(ctx, label, Math.round(x + w / 2.0F - tw / 2.0F),
         y + h / 2.0F - 4.0F, enabled ? DesignTokens.textHi() : 0x55FFFFFF, 7.5F);
      if (enabled) {
         this.hits.add(new Hit(x, y, w, h, tag));
      }
   }

   private static boolean hit(int mx, int my, float x, float y, float w, float h) {
      return mx >= x && mx <= x + w && my >= y && my <= y + h;
   }

   /* ====================================================================== */
   /*  Input                                                                 */
   /* ====================================================================== */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) (click.x() / this.drawScale);
      int my = (int) (click.y() / this.drawScale);
      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit h = this.hits.get(i);
         if (mx >= h.x && mx <= h.x + h.w && my >= h.y && my <= h.y + h.h) {
            act(h.tag);
            return true;
         }
      }
      commitEdit();
      this.editField = null;
      return super.mouseClicked(click, doubled);
   }

   private void act(String tag) {
      FriendsManager s = social();
      if (tag.equals("close")) {
         close();
         return;
      }
      if (tag.startsWith("edit:")) {
         commitEdit();
         this.editField = tag.substring(5);
         return;
      }
      if (tag.equals("applyskin")) {
         this.skinNotice = null;
         String want = this.draftSkin.trim();
         s.setSkinName(want, err -> {
            this.skinOk = err == null;
            this.skinNotice = err == null ? "Skin set to " + want : err;
            if (err == null) {
               net.bluenetwork.client.account.PlayerHeads.forget(want);
               reload();
            }
         });
         return;
      }
      if (tag.startsWith("badge:")) {
         String id = tag.substring(6);
         s.equipBadge("none".equals(id) ? null : id, this::reload);
         return;
      }
      switch (tag) {
         case "follow" -> s.follow(this.userId, this::reload);
         case "unfollow" -> s.unfollow(this.userId, this::reload);
         // v21: buddies need BOTH sides to agree, so this sends a request
         // (or accepts theirs). The message explains which happened.
         case "buddy" -> s.requestBuddy(this.userId, msg -> {
            if (msg != null) {
               this.notice = msg;
            }
            reload();
         });
         case "unbuddy" -> s.clearBuddy(this::reload);
         case "join" -> s.joinFriend(this.userId);
         case "message" -> s.openDm(this.userId, convId ->
            this.client.execute(() ->
               this.client.setScreen(new ChatScreen(this, convId))));
         default -> {
         }
      }
   }

   private void reload() {
      social().loadProfile(this.userId, p -> {
         if (p != null) {
            this.profile = p;
         }
      });
   }

   /** Saves an edited field, but only when it actually changed. */
   private void commitEdit() {
      if (this.editField == null || this.profile == null) {
         return;
      }
      if ("about".equals(this.editField)) {
         String old = this.profile.about() == null ? "" : this.profile.about();
         if (!this.draftAbout.equals(old)) {
            social().setAbout(this.draftAbout, this::reload);
         }
      } else if ("status".equals(this.editField)) {
         String old = this.profile.status() == null ? "" : this.profile.status();
         if (!this.draftStatus.equals(old)) {
            social().setStatus(this.draftStatus, this::reload);
         }
      } else if ("skin".equals(this.editField)) {
         // THE BUG: this branch did not exist, so pressing Enter (or clicking
         // away) in the skin field dropped the value on the floor and nothing
         // happened at all. The APPLY SKIN button worked; Enter did not, which
         // is the one people actually press.
         String old = social().skinName() == null ? "" : social().skinName();
         String want = this.draftSkin.trim();
         if (!want.equals(old)) {
            this.skinNotice = null;
            social().setSkinName(want, err -> {
               this.skinOk = err == null;
               this.skinNotice = err == null ? "Skin set to " + want : err;
               if (err == null) {
                  // Clear the cached bust so the new skin is fetched, not the
                  // old one served from cache.
                  net.bluenetwork.client.account.PlayerHeads.forget(want);
                  reload();
               }
            });
         }
      }
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.editField == null) {
         return super.charTyped(input);
      }
      String c = input.asString();
      if (c == null || c.isEmpty()) {
         return true;
      }
      if ("about".equals(this.editField)
         && this.draftAbout.length() < social().limitOf("about")) {
         this.draftAbout += c;
      } else if ("status".equals(this.editField)
         && this.draftStatus.length() < social().limitOf("status")) {
         this.draftStatus += c;
      } else if ("skin".equals(this.editField) && this.draftSkin.length() < 16) {
         // Minecraft usernames are [A-Za-z0-9_] only, so reject anything else
         // at the keystroke rather than letting the server bounce it later.
         if (c.matches("[A-Za-z0-9_]")) {
            this.draftSkin += c;
         }
      }
      return true;
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      if (this.editField != null) {
         int key = input.key();
         if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if ("about".equals(this.editField) && !this.draftAbout.isEmpty()) {
               this.draftAbout = this.draftAbout.substring(0, this.draftAbout.length() - 1);
            } else if ("status".equals(this.editField) && !this.draftStatus.isEmpty()) {
               this.draftStatus = this.draftStatus.substring(0, this.draftStatus.length() - 1);
            } else if ("skin".equals(this.editField) && !this.draftSkin.isEmpty()) {
               this.draftSkin = this.draftSkin.substring(0, this.draftSkin.length() - 1);
            }
            return true;
         }
         if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            commitEdit();
            this.editField = null;
            return true;
         }
         if (key == GLFW.GLFW_KEY_ESCAPE) {
            this.editField = null;
            return true;
         }
      }
      return super.keyPressed(input);
   }

   @Override
   public void removed() {
      commitEdit();
      super.removed();
   }

   @Override
   public void close() {
      if (this.parent != null) {
         this.client.setScreen(this.parent);
      } else {
         super.close();
      }
   }

   private record Hit(float x, float y, float w, float h, String tag) {
   }
}
