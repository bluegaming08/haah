package net.bluenetwork.client.module.impl;

import java.util.List;
import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.setting.StringSetting;
import net.minecraft.util.Formatting;

/**
 * Highlight Manager (v3 catalogue C2) — when a chat message contains any of
 * your highlight words the whole line is recoloured in your chosen highlight
 * colour (and a soft ping plays). Words list is persisted.
 */
public class HighlightManager extends Module {
   private static final String[] COLORS = {"Aqua", "Yellow", "Gold", "Green", "Pink", "Red"};
   private final StringSetting words = new StringSetting("Words", "Comma-separated words to highlight", "");
   private final ModeSetting color = new ModeSetting("Color", "Highlight colour", List.of(COLORS), "Aqua");

   public HighlightManager() {
      super("Highlight Manager", "Colour chat lines that contain your words", Category.MISC);
      this.addSettings(new Setting[]{this.words, this.color});
   }

   /** Returns the highlight formatting for a message, or null when it does not match. */
   public static Formatting highlight(String content) {
      try {
         if (content == null || content.isEmpty()) {
            return null;
         }
         Module m = BlueClient.getInstance().moduleManager().byName("Highlight Manager");
         if (!(m instanceof HighlightManager hm) || !hm.isEnabled()) {
            return null;
         }
         String raw = hm.words.get();
         if (raw == null || raw.isBlank()) {
            return null;
         }
         String text = content.toLowerCase(Locale.ROOT);
         for (String w : raw.split(",")) {
            String word = w.trim().toLowerCase(Locale.ROOT);
            if (!word.isEmpty() && text.contains(word)) {
               return fromName(hm.color.get());
            }
         }
      } catch (Throwable ignored) {
      }
      return null;
   }

   private static Formatting fromName(String name) {
      if (name == null) {
         return Formatting.AQUA;
      }
      switch (name) {
         case "Yellow":
            return Formatting.YELLOW;
         case "Gold":
            return Formatting.GOLD;
         case "Green":
            return Formatting.GREEN;
         case "Pink":
            return Formatting.LIGHT_PURPLE;
         case "Red":
            return Formatting.RED;
         default:
            return Formatting.AQUA;
      }
   }
}
