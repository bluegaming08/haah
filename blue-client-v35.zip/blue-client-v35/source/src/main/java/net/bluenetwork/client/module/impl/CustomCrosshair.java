package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HitReactor;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Crosshair+ — the configurable crosshair.
 *
 * <p>This is the original "Crosshair" module grown up. It kept its registered
 * name so existing configs and share codes keep working (module settings are
 * saved by display name), but it now covers types, presets, outlines, a centre
 * dot, outer lines, hit feedback and dynamic spread.</p>
 *
 * <h2>Drawing lives elsewhere</h2>
 * {@link net.bluenetwork.client.render.CrosshairRenderer} does the actual
 * drawing, so the exact same code paints the in-game crosshair and the live
 * preview in the settings screen. That is the only way a preview can be
 * trusted to match what you get in game.
 *
 * <h2>Hit colour</h2>
 * Implemented through the existing {@link HitReactor} interface — the same
 * hook Hit Marker, Hit Sound and Hit Color already use — so no new event
 * system was added. It is <b>purely visual feedback</b> for an attack you
 * already made: nothing is automated, nothing is sent.
 *
 * <h2>Performance</h2>
 * Rendering reads a {@link Style} record built once per frame; there are no
 * per-frame allocations beyond it, no trigonometry outside the circle type
 * (which uses a precomputed table), and no state that grows over time.
 */
public class CustomCrosshair extends Module implements HitReactor {

   /** Built-in presets. "Custom" means "leave my sliders alone". */
   private static final List<String> PRESETS = List.of(
      "Custom", "Classic", "Minimal", "PvP", "Dot", "Small", "Circle", "Competitive");

   private static final List<String> TYPES = List.of(
      "Classic", "Dot", "Circle", "Cross", "Minimal", "PvP", "Custom");

   /* ------------------------------ settings ----------------------------- */

   private final ModeSetting preset = new ModeSetting("Preset",
      "Load a built-in look. Changing any slider afterwards switches this to Custom.",
      PRESETS, "Classic");
   private final ModeSetting type = new ModeSetting("Type", "Crosshair shape", TYPES, "Classic");
   private final NumberSetting size = new NumberSetting("Size",
      "Arm length / radius in pixels", 5.0, 1.0, 20.0, 1.0);
   private final NumberSetting thickness = new NumberSetting("Thickness",
      "How thick each arm is", 1.0, 1.0, 6.0, 1.0);
   private final NumberSetting gap = new NumberSetting("Gap",
      "Empty space between the centre and the arms", 3.0, 0.0, 16.0, 1.0);
   private final NumberSetting opacity = new NumberSetting("Opacity",
      "Crosshair opacity (%)", 100.0, 10.0, 100.0, 5.0);
   private final ColorSetting color = new ColorSetting("Color",
      "Crosshair colour (supports the rainbow option)", 0xFFFFFFFF);

   private final BooleanSetting outline = new BooleanSetting("Outline",
      "Dark outline so the crosshair stays visible on light terrain", true);
   private final NumberSetting outlineThickness = new NumberSetting("Outline thickness",
      "Outline width in pixels", 1.0, 1.0, 3.0, 1.0);

   private final BooleanSetting centerDot = new BooleanSetting("Center dot",
      "Draw a dot in the middle", false);
   private final NumberSetting centerDotSize = new NumberSetting("Center dot size",
      "Dot size in pixels", 1.0, 1.0, 6.0, 1.0);

   private final BooleanSetting outerLines = new BooleanSetting("Outer lines",
      "Extra tick marks outside the arms", false);
   private final NumberSetting outerLineLength = new NumberSetting("Outer line length",
      "Length of the outer tick marks", 3.0, 1.0, 12.0, 1.0);
   private final NumberSetting outerLineThickness = new NumberSetting("Outer line thickness",
      "Thickness of the outer tick marks", 1.0, 1.0, 4.0, 1.0);

   private final BooleanSetting hitColorEnabled = new BooleanSetting("Hit color",
      "Briefly recolour the crosshair when you hit something", true);
   private final ColorSetting hitColor = new ColorSetting("Hit color value",
      "Colour flashed after a successful hit", 0xFFFF5555);
   private final NumberSetting hitDuration = new NumberSetting("Hit color duration",
      "How long the hit colour lasts (milliseconds)", 250.0, 50.0, 1000.0, 10.0);

   private final BooleanSetting dynamicMovement = new BooleanSetting("Dynamic movement",
      "Spread the crosshair while moving", false);
   private final BooleanSetting dynamicAttack = new BooleanSetting("Dynamic attack",
      "Spread briefly when you attack", false);
   private final NumberSetting dynamicAmount = new NumberSetting("Dynamic amount",
      "How far the crosshair spreads (pixels)", 3.0, 1.0, 10.0, 1.0);

   private final NumberSetting overallScale = new NumberSetting("Overall scale",
      "Scales the whole crosshair (%)", 100.0, 50.0, 300.0, 10.0);

   /* -------------------------------- state ------------------------------ */

   /** When the last hit landed, for the hit colour and attack spread. */
   private volatile long lastHitMs = 0L;

   /** Guard so applying a preset does not recursively re-trigger itself. */
   private boolean applyingPreset = false;

   public CustomCrosshair() {
      super("Crosshair", "Crosshair+ — fully configurable crosshair with presets and hit feedback",
         Category.RENDER);
      this.addSettings(new Setting[]{
         this.preset, this.type, this.size, this.thickness, this.gap, this.opacity,
         this.color, this.outline, this.outlineThickness,
         this.centerDot, this.centerDotSize,
         this.outerLines, this.outerLineLength, this.outerLineThickness,
         this.hitColorEnabled, this.hitColor, this.hitDuration,
         this.dynamicMovement, this.dynamicAttack, this.dynamicAmount,
         this.overallScale
      });

      this.outlineThickness.visibleWhen(this.outline::get);
      this.centerDotSize.visibleWhen(this.centerDot::get);
      this.outerLineLength.visibleWhen(this.outerLines::get);
      this.outerLineThickness.visibleWhen(this.outerLines::get);
      this.hitColor.visibleWhen(this.hitColorEnabled::get);
      this.hitDuration.visibleWhen(this.hitColorEnabled::get);
      this.dynamicAmount.visibleWhen(() -> this.dynamicMovement.get() || this.dynamicAttack.get());

      this.preset.onChange(this::applyPreset);
      // Touching any shape slider means the user has gone off-preset. Saying so
      // is more honest than leaving the dropdown claiming "PvP" after edits.
      Setting<?>[] shapeSettings = {
         this.type, this.size, this.thickness, this.gap,
         this.centerDot, this.outerLines, this.outline
      };
      for (Setting<?> setting : shapeSettings) {
         setting.onChange(this::markCustom);
      }
   }

   private void markCustom() {
      if (!this.applyingPreset && !"Custom".equals(this.preset.get())) {
         this.preset.set("Custom");
      }
   }

   /** Applies a built-in preset's shape values. */
   private void applyPreset() {
      String chosen = this.preset.get();
      if ("Custom".equals(chosen)) {
         return;
      }
      this.applyingPreset = true;
      try {
         switch (chosen) {
            case "Classic" -> this.set("Classic", 5, 1, 3, false, false, true);
            case "Minimal" -> this.set("Minimal", 3, 1, 2, false, false, false);
            case "PvP" -> this.set("PvP", 6, 1, 4, true, true, true);
            case "Dot" -> this.set("Dot", 2, 2, 0, true, false, true);
            case "Small" -> this.set("Small".equals(chosen) ? "Cross" : "Cross", 3, 1, 1, false, false, true);
            case "Circle" -> this.set("Circle", 5, 1, 0, true, false, true);
            case "Competitive" -> this.set("Cross", 4, 1, 3, true, false, true);
            default -> {
            }
         }
      } finally {
         this.applyingPreset = false;
      }
   }

   private void set(String shape, double sz, double thick, double gp,
                    boolean dot, boolean outer, boolean line) {
      this.type.set(shape);
      this.size.set(sz);
      this.thickness.set(thick);
      this.gap.set(gp);
      this.centerDot.set(dot);
      this.outerLines.set(outer);
      this.outline.set(line);
   }

   @Override
   public void onHit(PlayerEntity attacker, Entity target) {
      this.lastHitMs = System.currentTimeMillis();
   }

   /**
    * Everything the renderer needs, resolved once.
    *
    * <p>Immutable so the preview and the in-game crosshair can share one code
    * path, and so the renderer performs no setting lookups while drawing.</p>
    */
   public record Style(String type, int size, int thickness, int gap, int color,
                       boolean outline, int outlineThickness,
                       boolean centerDot, int centerDotSize,
                       boolean outerLines, int outerLineLength, int outerLineThickness,
                       float scale, int spread) {
   }

   /**
    * Builds the style for this frame.
    *
    * @param includeDynamic false for the settings preview, so it does not
    *                       twitch while the player happens to be walking.
    */
   public Style style(boolean includeDynamic) {
      long now = System.currentTimeMillis();
      int rgb = this.color.currentRgb(now) & 0xFFFFFF;

      // Hit colour wins over the base colour while it is active.
      if (this.hitColorEnabled.get() && now - this.lastHitMs < (long) this.hitDuration.get().doubleValue()) {
         rgb = this.hitColor.currentRgb(now) & 0xFFFFFF;
      }
      int alpha = (int) Math.round(this.opacity.get() / 100.0 * 255.0) & 0xFF;
      int argb = (alpha << 24) | rgb;

      return new Style(
         this.type.get(),
         this.size.getInt(),
         this.thickness.getInt(),
         this.gap.getInt(),
         argb,
         this.outline.get(),
         this.outlineThickness.getInt(),
         this.centerDot.get(),
         this.centerDotSize.getInt(),
         this.outerLines.get(),
         this.outerLineLength.getInt(),
         this.outerLineThickness.getInt(),
         (float) (this.overallScale.get() / 100.0),
         includeDynamic ? this.dynamicSpread(now) : 0);
   }

   /**
    * Extra gap from movement / recent attacks, in pixels.
    *
    * <p>Deliberately conservative: the default is off, and even enabled the
    * spread is a few pixels. A crosshair that jumps around is worse than no
    * feedback at all in a fight.</p>
    */
   private int dynamicSpread(long now) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null) {
         return 0;
      }
      float amount = this.dynamicAmount.getFloat();
      float spread = 0.0F;
      if (this.dynamicMovement.get()) {
         var velocity = mc.player.getVelocity();
         // Horizontal speed only - falling should not spread the crosshair.
         double speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
         spread += (float) Math.min(1.0, speed / 0.28) * amount;
      }
      if (this.dynamicAttack.get()) {
         long age = now - this.lastHitMs;
         long window = 200L;
         if (age < window) {
            spread += (1.0F - age / (float) window) * amount;
         }
      }
      return Math.round(spread);
   }

   /** Draws the crosshair at a given centre — shared by HUD and preview. */
   public void draw(DrawContext context, int cx, int cy, boolean includeDynamic) {
      net.bluenetwork.client.render.CrosshairRenderer.draw(context, cx, cy,
         this.style(includeDynamic));
   }
}
