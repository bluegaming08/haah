package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Third Person Nametag - restyles YOUR OWN floating nametag (the one you see
 * above your head in F5 / third person): pick a name colour, make it bold,
 * or add a text shadow. Only affects your own tag; other players stay vanilla.
 */
public class ThirdPersonNametag extends Module {
   private final ColorSetting nameColor = new ColorSetting("Name color", "Colour of your nametag text", 0xFFFFFFFF);
   private final BooleanSetting bold = new BooleanSetting("Bold", "Draw your name in bold", false);
   private final BooleanSetting shadow = new BooleanSetting("Shadow", "Add a text shadow behind your name", false);

   public ThirdPersonNametag() {
      super("Third Person Nametag", "Style your own nametag in F5 third person", Category.RENDER);
      this.addSettings(new Setting[]{this.nameColor, this.bold, this.shadow});
   }

   public static boolean active() {
      ThirdPersonNametag self = Module.find(ThirdPersonNametag.class);
      return self != null && self.isEnabled();
   }

   public static int colorRgb() {
      ThirdPersonNametag self = Module.find(ThirdPersonNametag.class);
      return self == null ? 0xFFFFFF : self.nameColor.rgb() & 0xFFFFFF;
   }

   public static boolean boldOn() {
      ThirdPersonNametag self = Module.find(ThirdPersonNametag.class);
      return self != null && self.bold.get();
   }

   public static boolean shadowOn() {
      ThirdPersonNametag self = Module.find(ThirdPersonNametag.class);
      return self != null && self.shadow.get();
   }
}
