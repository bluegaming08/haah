package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

/**
 * Hotbar Info (bonus HUD) — the name and remaining durability % of the item in
 * your selected hotbar slot, as a small panel. Turns red below the configured
 * durability threshold.
 */
public class HotbarInfo extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Low-durability colour", 0xFFFF5C5C);

   public HotbarInfo() {
      super("Hotbar Info", "Selected item name + durability", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.warnColor});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_RIGHT, 6, 40);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return "--";
      }
      ItemStack stack = mc.player.getInventory().getSelectedStack();
      if (stack == null || stack.isEmpty()) {
         return "Empty hand";
      }
      if (!stack.isDamageable() || stack.getMaxDamage() <= 0) {
         return stack.getName().getString();
      }
      int remaining = stack.getMaxDamage() - stack.getDamage();
      int pct = Math.max(0, remaining * 100 / stack.getMaxDamage());
      return stack.getName().getString() + " " + pct + "%";
   }

   private int color() {
      ItemStack stack = MinecraftClient.getInstance().player.getInventory().getSelectedStack();
      boolean low = stack != null && !stack.isEmpty() && stack.isDamageable() && stack.getMaxDamage() > 0
         && (stack.getMaxDamage() - stack.getDamage()) * 100 / stack.getMaxDamage() <= 15;
      return low
         ? this.warnColor.currentRgb(System.currentTimeMillis())
         : this.textColor.currentRgb(System.currentTimeMillis());
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, this.color());
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
