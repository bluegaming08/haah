package net.bluenetwork.client.module.impl;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;

public class ChatTimestamps extends Module {
   private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

   public ChatTimestamps() {
      super("Chat Timestamps", "[HH:MM] prefix on every message", Category.MISC);
   }

   public static String prefix() {
      return TIME.format(LocalTime.now());
   }
}
