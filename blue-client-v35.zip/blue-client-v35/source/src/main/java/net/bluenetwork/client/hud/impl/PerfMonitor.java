package net.bluenetwork.client.hud.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.optimization.PerfMeter;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Performance Monitor (charter HUD-family budget panel) — while enabled it
 * switches {@link PerfMeter} sampling on and shows the live frame time vs the
 * 16.7 ms budget plus the costliest modules, flagged in the warn colour when
 * they exceed the 0.6 ms/module HUD budget.
 */
public class PerfMonitor extends HudModule {
   private final ColorSetting okColor = new ColorSetting("OK color", "Within budget", 0xFF7CFF9B);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Over the 0.6 ms module budget", 0xFFFF5C5C);
   private final BooleanSetting showModules = new BooleanSetting("Show modules", "List the costliest modules", true);

   public PerfMonitor() {
      super("Performance Monitor", "Frame budget + per-module costs", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.okColor, this.warnColor, this.showModules});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 4);
   }

   @Override
   protected void onEnable() {
      PerfMeter.setActive(true);
   }

   @Override
   protected void onDisable() {
      PerfMeter.setActive(false);
   }

   private java.util.List<String> lines() {
      MinecraftClient mc = MinecraftClient.getInstance();
      java.util.List<String> out = new java.util.ArrayList<>();
      if (mc == null) {
         return out;
      }
      int fps = (int) Math.round(mc.getCurrentFps());
      out.add(String.format("%d FPS  %.1f ms  %.0f%%", fps, PerfMeter.lastFrameMs(), PerfMeter.frameLoadPct()));
      if (this.showModules.get()) {
         List<PerfMeter.Entry> entries = PerfMeter.snapshot();
         int shown = 0;
         for (PerfMeter.Entry entry : entries) {
            if (shown >= 4 || entry.ms() <= 0.03) {
               break;
            }
            out.add(String.format("%.2f ms  %s", entry.ms(), entry.name()));
            shown++;
         }
      }
      return out;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      java.util.List<String> lines = this.lines();
      this.drawPanel(context);
      int ty = this.y + 6;
      int ok = this.okColor.currentRgb(System.currentTimeMillis());
      int warn = this.warnColor.currentRgb(System.currentTimeMillis());
      boolean first = true;
      for (String line : lines) {
         int color = first ? (PerfMeter.frameLoadPct() > 100.0 ? warn : ok) : ok;
         if (!first && line.startsWith("0.")) {
            color = warn;
         }
         RenderUtil.drawText(context, line, this.x + 6 + 2, ty, color);
         ty += 9;
         first = false;
      }
   }

   @Override
   public int getWidth() {
      int max = 0;
      for (String line : this.lines()) {
         max = Math.max(max, RenderUtil.textWidth(line));
      }
      return Math.max(40, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = this.lines().size();
      return Math.max(21, rows * 9 + 12);
   }
}
