package net.bluenetwork.client.hud.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/**
 * Armor Durability — worn armor + offhand durability as text (v3 catalogue A4).
 * Colours drop to the warning colour below the threshold; every colour is a v2
 * colour setting (swatches / hex / RGB / rainbow).
 */
public class ArmorDurability extends HudModule {
   private static final String[] SLOT_NAMES = {"Helm", "Chest", "Legs", "Boots"};
   private final ColorSetting textColor = new ColorSetting("Text color", "Normal durability colour", 0xFFFFFFFF);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Colour when below the warning threshold", 0xFFFF5C5C);
   private final NumberSetting warnAt = new NumberSetting("Warn at", "Percent that triggers the warning colour", 25.0, 1.0, 100.0, 1.0);
   private final BooleanSetting showOffhand = new BooleanSetting("Show offhand", "Also list your offhand item", true);

   public ArmorDurability() {
      super("Armor Durability", "Worn armor durability percentages", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.warnColor, this.warnAt, this.showOffhand});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 30);
   }

   private List<String> lines() {
      List<String> out = new ArrayList<>();
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return out;
      }
      EquipmentSlot[] armorSlots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
      for (int i = 0; i < SLOT_NAMES.length; i++) {
         ItemStack stack = mc.player.getEquippedStack(armorSlots[i]);
         if (stack == null || stack.isEmpty()) {
            continue;
         }
         out.add(SLOT_NAMES[i] + " " + this.percent(stack));
      }
      if (this.showOffhand.get()) {
         ItemStack offhand = mc.player.getOffHandStack();
         if (offhand != null && !offhand.isEmpty()) {
            out.add("Offhand " + this.percent(offhand));
         }
      }
      if (out.isEmpty()) {
         out.add("No armor");
      }
      return out;
   }

   private String percent(ItemStack stack) {
      if (!stack.isDamageable() || stack.getMaxDamage() <= 0) {
         return "\u2014";
      }
      int remaining = stack.getMaxDamage() - stack.getDamage();
      int pct = Math.max(0, remaining * 100 / stack.getMaxDamage());
      return pct + "%";
   }

   private int lineColor(String line) {
      // Lines that are purely numeric may dip below the threshold - but we only
      // colour-warn actual armor pieces; skip the "No armor" placeholder.
      int pct = parsePercent(line);
      if (pct >= 0 && pct <= this.warnAt.getInt()) {
         return this.warnColor.currentRgb(System.currentTimeMillis());
      }
      return this.textColor.currentRgb(System.currentTimeMillis());
   }

   private int parsePercent(String line) {
      int i = line.indexOf('%');
      if (i <= 0) {
         return -1;
      }
      int start = i;
      while (start > 0 && Character.isDigit(line.charAt(start - 1))) {
         start--;
      }
      try {
         return Integer.parseInt(line.substring(start, i));
      } catch (NumberFormatException e) {
         return -1;
      }
   }

   @Override
   public void render(DrawContext context) {
      List<String> lines = this.lines();
      if (lines.isEmpty() || MinecraftClient.getInstance().player == null) {
         return;
      }
      int panelW = this.getWidth();
      int panelH = this.getHeight();
      this.drawPanel(context, panelW, panelH);
      int ty = this.y + 6;
      for (String line : lines) {
         RenderUtil.drawText(context, line, this.x + 6 + 2, ty, this.lineColor(line));
         ty += 9;
      }
   }

   @Override
   public int getWidth() {
      int max = 0;
      for (String line : this.lines()) {
         max = Math.max(max, RenderUtil.textWidth(line));
      }
      return Math.max(20, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = this.lines().size();
      return Math.max(21, rows * 9 + 12);
   }
}
