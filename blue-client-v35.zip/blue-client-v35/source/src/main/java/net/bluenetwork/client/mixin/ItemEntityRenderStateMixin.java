package net.bluenetwork.client.mixin;

import net.bluenetwork.client.render.ItemPhysicsState;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Adds the Item Physics fields to the vanilla item render state.
 *
 * <p>"Duck typing": the mixin makes {@link ItemEntityRenderState} implement
 * {@link ItemPhysicsState}, so {@code ItemPhysicsMixin} can read per-item
 * physics data with a plain interface check. The alternative — a map keyed by
 * entity id — would need manual eviction when items despawn and would be a
 * memory leak waiting to happen.</p>
 *
 * <p>The values are written each frame by {@code ItemPhysicsUpdateMixin}.</p>
 */
@Mixin(ItemEntityRenderState.class)
public abstract class ItemEntityRenderStateMixin implements ItemPhysicsState {

   @Unique
   private boolean blueclient$onGround;

   @Unique
   private float blueclient$groundAge;

   @Unique
   private int blueclient$seed;

   @Override
   public boolean blueclient$isOnGround() {
      return this.blueclient$onGround;
   }

   @Override
   public void blueclient$setOnGround(boolean onGround) {
      this.blueclient$onGround = onGround;
   }

   @Override
   public float blueclient$getAge() {
      return this.blueclient$groundAge;
   }

   @Override
   public void blueclient$setAge(float age) {
      this.blueclient$groundAge = age;
   }

   @Override
   public int blueclient$getSeed() {
      return this.blueclient$seed;
   }

   @Override
   public void blueclient$setSeed(int seed) {
      this.blueclient$seed = seed;
   }
}
