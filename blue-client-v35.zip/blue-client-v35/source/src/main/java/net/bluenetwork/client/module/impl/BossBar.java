package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Boss Bar (v0.19.0) — control over the boss health bar: hide it
 * entirely, or move/scale it anywhere on screen. The mixin translates the
 * render around the vanilla top-center position.
 */
public class BossBar extends Module {
   private final BooleanSetting hide = new BooleanSetting("Hide boss bar", "Don't draw the boss bar at all", false);
   private final NumberSetting scale = new NumberSetting("Scale", "Size of the boss bar (1.0 = vanilla)", 1.0, 0.5, 2.0, 0.05);
   private final NumberSetting xOffset = new NumberSetting("X offset", "Nudge the boss bar left/right (px)", 0.0, -500.0, 500.0, 5.0);
   private final NumberSetting yOffset = new NumberSetting("Y offset", "Nudge the boss bar up/down (px)", 0.0, -500.0, 500.0, 5.0);

   public BossBar() {
      super("Boss Bar", "Hide, move or resize the boss health bar", Category.RENDER);
      this.addSettings(new Setting[]{this.hide, this.scale, this.xOffset, this.yOffset});
   }

   /** True when the bar should not render at all. */
   public static boolean hidden() {
      Module m = BlueClient.getInstance().moduleManager().byName("Boss Bar");
      return m instanceof BossBar b && m.isEnabled() && b.hide.get();
   }

   /** True when any transform is needed (scale / offsets). */
   public static boolean transform() {
      Module m = BlueClient.getInstance().moduleManager().byName("Boss Bar");
      if (m instanceof BossBar b && m.isEnabled()) {
         return Math.abs(b.scale.get() - 1.0) > 0.001 || b.xOffset.get() != 0.0 || b.yOffset.get() != 0.0;
      }
      return false;
   }

   /** Configured scale factor (1.0 when off). */
   public static float scale() {
      Module m = BlueClient.getInstance().moduleManager().byName("Boss Bar");
      return m instanceof BossBar b && m.isEnabled() ? b.scale.get().floatValue() : 1.0F;
   }

   /** Configured X shift in pixels. */
   public static double offsetX() {
      Module m = BlueClient.getInstance().moduleManager().byName("Boss Bar");
      return m instanceof BossBar b && m.isEnabled() ? b.xOffset.get() : 0.0;
   }

   /** Configured Y shift in pixels. */
   public static double offsetY() {
      Module m = BlueClient.getInstance().moduleManager().byName("Boss Bar");
      return m instanceof BossBar b && m.isEnabled() ? b.yOffset.get() : 0.0;
   }
}
