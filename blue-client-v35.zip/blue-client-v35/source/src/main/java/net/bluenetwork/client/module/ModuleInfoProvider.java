package net.bluenetwork.client.module;

/**
 * Implemented by v3 modules that want full metadata in the Module Library.
 * Legacy modules (no provider) get synthesised {@link ModuleInfo} from their
 * name/description/category via {@link ModuleCatalogue}.
 */
public interface ModuleInfoProvider {
   ModuleInfo moduleInfo();
}
