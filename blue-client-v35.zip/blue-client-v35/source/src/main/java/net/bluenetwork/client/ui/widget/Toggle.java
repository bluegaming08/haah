package net.bluenetwork.client.ui.widget;

import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.DrawContext;

/**
 * Glass pill toggle switch (BLUE_CLIENT_V3_MASTER_PLAN.md §4.2). Renders a
 * rounded track + knob with an accent fill when on; clicking flips the value
 * and fires {@code onChange}. Width is auto ~ = h * 2.
 */
public class Toggle extends Widget {
   private boolean value;
   private final Runnable onChange;

   public Toggle(boolean initialValue, Runnable onChange) {
      this.value = initialValue;
      this.onChange = onChange;
   }

   public boolean value() {
      return value;
   }

   public void setValue(boolean value) {
      if (this.value != value) {
         this.value = value;
         if (onChange != null) {
            onChange.run();
         }
      }
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, long nowMs) {
      int trackH = Math.max(6, Math.min(12, h));
      int trackW = Math.max(14, w);
      int ty = y + (h - trackH) / 2;
      int radius = trackH / 2;

      int trackColor = value ? DesignTokens.toggleOn() : DesignTokens.toggleOff();
      // track
      context.fill(x + 1, ty + 1, x + trackW - 1, ty + trackH - 1, trackColor);
      // 1px border edge (simplified to keep AA corners via fill look crisp at GUI scale)
      context.fill(x + 1, ty, x + trackW - 1, ty + 1, (value ? DesignTokens.accent() : DesignTokens.panelBorder()));
      context.fill(x + 1, ty + trackH - 1, x + trackW - 1, ty + trackH, (value ? DesignTokens.accent() : DesignTokens.panelBorder()));
      context.fill(x, ty + 1, x + 1, ty + trackH - 1, (value ? DesignTokens.accent() : DesignTokens.panelBorder()));
      context.fill(x + trackW - 1, ty + 1, x + trackW, ty + trackH - 1, (value ? DesignTokens.accent() : DesignTokens.panelBorder()));

      int knobSize = trackH - 2;
      int knobX = value ? x + trackW - knobSize - 1 : x + 1;
      int knobY = ty + 1;
      context.fill(knobX, knobY, knobX + knobSize, knobY + knobSize, value ? 0xFFFFFFFF : DesignTokens.textMid());
   }

   @Override
   public boolean mouseClicked(int mouseX, int mouseY, int button) {
      if (button == 0 && contains(mouseX, mouseY)) {
         RenderUtil.clickSound();
         setValue(!value);
         return true;
      }
      return false;
   }
}
