package net.bluenetwork.client.cosmetics;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.brand.BlueBrand;
import net.minecraft.client.MinecraftClient;

/**
 * Ticks Blue Stars accrual (1 star per minute online on Blue Network — AFK
 * counts, per owner decision) and is the single access point the rest of
 * the mod (mixin, Locker screen, Cosmetics module) reads/writes through.
 */
public final class CosmeticsManager {
   private static final int TICKS_PER_STAR = 1200; // 60s * 20 ticks/s

   private final CosmeticsProfile profile = new CosmeticsProfile();
   private int tickAccumulator;

   public void start() {
      this.profile.load();
   }

   public void tick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      // v0.20.2: re-check seeded grants while in-game — the username may not
      // have been available at load() time (launcher/offline setups), which
      // is why blue_kzz never saw the 15000 stars.
      if (mc.player != null) {
         this.profile.applySeededGrantIfAny();
      }
      if (mc.player == null || mc.getCurrentServerEntry() == null) {
         this.tickAccumulator = 0;
         return;
      }
      if (!BlueBrand.isBlueNetwork(mc.getCurrentServerEntry().address)) {
         this.tickAccumulator = 0;
         return;
      }
      // AFK intentionally counts - no idle detection, per owner instruction.
      this.tickAccumulator++;
      if (this.tickAccumulator >= TICKS_PER_STAR) {
         this.tickAccumulator = 0;
         this.profile.addStar();
      }
   }

   public CosmeticsProfile profile() {
      return this.profile;
   }

   /* ---- locker preview (transient, not saved) ---- */

   private static volatile Cape previewOverride;

   /** While the locker screen is open, the hovered/selected cape shows on the preview mannequin. */
   public static void preview(Cape cape) {
      previewOverride = cape;
   }

   /* ---- convenience static accessors (mirrors Waypoints/Nametags style) ---- */

   public static CosmeticsProfile profileStatic() {
      return BlueClient.getInstance().cosmetics().profile();
   }

   /** The cape the local player currently has equipped (or the locker preview), or null. */
   public static Cape equippedCape() {
      if (previewOverride != null) {
         return previewOverride;
      }
      String id = profileStatic().equipped();
      return id == null ? null : CapeRegistry.byId(id);
   }
}
