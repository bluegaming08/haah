package net.bluenetwork.client.hud.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

/**
 * Potion Timers (v3 catalogue A1) — your active status effects with remaining
 * time. Lines tick down and switch to the warn colour (blinking) under the
 * warn threshold. Names come straight from the effect registry id, so no
 * translation-table dependency.
 */
public class PotionTimers extends HudModule {
   private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

   private final ColorSetting textColor = new ColorSetting("Text color", "Effect line colour", 0xFFFFFFFF);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Blink colour under the warn threshold", 0xFFFF5C5C);
   private final NumberSetting warnAt = new NumberSetting("Warn under", "Blink when fewer than this many seconds remain", 10.0, 1.0, 60.0, 1.0);
   private final BooleanSetting hideAmbient = new BooleanSetting("Hide ambient", "Hide beacon/conduit ambient effects", true);
   private final BooleanSetting showLevel = new BooleanSetting("Show level", "Append the amplifier (II, III, ...)", true);

   public PotionTimers() {
      super("Potion Timers", "Active effects with countdowns", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.warnColor, this.warnAt, this.hideAmbient, this.showLevel});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 4);
   }

   private List<Line> cachedLines = new ArrayList<>();

   /** Lines are rebuilt once per tick (see onTick) — never per frame. */
   private List<Line> currentLines() {
      if (this.cachedLines.isEmpty()) {
         this.cachedLines = this.lines();
      }
      return this.cachedLines;
   }

   @Override
   public void onTick() {
      this.cachedLines = this.lines();
   }

   private List<Line> lines() {
      List<Line> out = new ArrayList<>();
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return out;
      }
      long nowMs = System.currentTimeMillis();
      for (StatusEffectInstance inst : mc.player.getStatusEffects()) {
         if (this.hideAmbient.get() && inst.isAmbient()) {
            continue;
         }
         String name = nameOf(inst);
         int duration = inst.getDuration();
         int amplifier = inst.getAmplifier();
         if (this.showLevel.get() && amplifier > 0) {
            String lvl = amplifier < ROMAN.length ? ROMAN[amplifier] : String.valueOf(amplifier + 1);
            name = name + " " + lvl;
         }
         String time = duration < 0 ? "\u221e" : format(duration);
         String text = name + " " + time;
         boolean warn = duration >= 0 && duration <= (int) Math.round(this.warnAt.get() * 20.0);
         boolean blinkOn = ((nowMs / 500L) & 1L) == 0L;
         out.add(new Line(text, warn && blinkOn));
      }
      out.sort(Comparator.comparingInt(l -> l.warn ? 0 : 1));
      return out;
   }

   private static String nameOf(StatusEffectInstance inst) {
      String id = inst.getEffectType().getIdAsString();
      int colon = id.indexOf(':');
      if (colon >= 0) {
         id = id.substring(colon + 1);
      }
      String spaced = id.replace('_', ' ');
      if (spaced.isEmpty()) {
         return "Effect";
      }
      return Character.toUpperCase(spaced.charAt(0)) + spaced.substring(1);
   }

   private static String format(int ticks) {
      int totalSeconds = Math.max(0, ticks / 20);
      int m = totalSeconds / 60;
      int s = totalSeconds % 60;
      return String.format("%d:%02d", m, s);
   }

   @Override
   public void render(DrawContext context) {
      List<Line> lines = this.currentLines();
      MinecraftClient mc = MinecraftClient.getInstance();
      if (lines.isEmpty() || mc.player == null) {
         return;
      }
      this.drawPanel(context);
      int ty = this.y + 6;
      int normal = this.textColor.currentRgb(System.currentTimeMillis());
      int warn = this.warnColor.currentRgb(System.currentTimeMillis());
      for (Line line : lines) {
         RenderUtil.drawText(context, line.text, this.x + 6 + 2, ty, line.warn ? warn : normal);
         ty += 9;
      }
   }

   @Override
   public int getWidth() {
      int max = 0;
      for (Line line : this.currentLines()) {
         max = Math.max(max, RenderUtil.textWidth(line.text));
      }
      return Math.max(20, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = this.currentLines().size();
      return Math.max(21, rows * 9 + 12);
   }

   private record Line(String text, boolean warn) {
   }
}
