package net.bluenetwork.client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public class QuickMenuScreen extends Screen {
   private final List<QuickMenuScreen.Hit> hits = new ArrayList<>();
   private final long openedAt = System.currentTimeMillis();

   public QuickMenuScreen() {
      super(Text.literal("Blue Client"));
   }

   public boolean shouldPause() {
      return false;
   }

   public boolean shouldCloseOnEsc() {
      return true;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      this.hits.clear();
      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();
      int centerX = width / 2;
      int centerY = height / 2;

      /*
       * Rebuilt to the owner's reference: the PLAYER'S HEAD in the middle with
       * the four destinations arranged around it, rather than a logo card and
       * a row of three buttons.
       *
       * The head comes from mc-api.io's HEAD render (PlayerHeads.head), which
       * is the square face rather than the bust used elsewhere - it sits
       * better inside a circular frame at this size.
       */
      float intro = 1.0F;
      if (BlueClient.getInstance().settings().menuIntroAnim()) {
         long el = System.currentTimeMillis() - this.openedAt;
         intro = Math.max(0.0F, Math.min(1.0F, el / 220.0F));
      }
      float eased = 1.0F - (1.0F - intro) * (1.0F - intro);
      int alpha = (int) (255.0F * eased);
      int dy = Math.round((1.0F - eased) * 10.0F);

      /* ---------------- the head, dead centre ---------------- */
      int headSize = 72;
      int hx = centerX - headSize / 2;
      int hy = centerY - headSize / 2 - 10 + dy;

      String name = MinecraftClient.getInstance().getGameProfile() != null
         ? MinecraftClient.getInstance().getGameProfile().name() : "Player";

      // Ring behind the head so it reads as a deliberate frame.
      RenderUtil.drawRoundedRect(context, hx - 5, hy - 5, headSize + 10,
         headSize + 10, (alpha << 24) | 0x11151C, 10);
      RenderUtil.drawRoundedOutline(context, hx - 5, hy - 5, headSize + 10,
         headSize + 10, (Math.min(alpha, 160) << 24) | 0x2FA5FF, 10);

      net.minecraft.util.Identifier face =
         net.bluenetwork.client.account.PlayerHeads.head(name);
      if (face != null) {
         context.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,
            face, hx, hy, 0.0F, 0.0F, headSize, headSize, headSize, headSize);
      } else {
         // Still loading, or the name has no render: show the logo instead of
         // an empty hole.
         int lh = headSize - 12;
         RenderUtil.drawLogo(context, centerX - RenderUtil.logoWidth(lh) / 2,
            hy + 6, lh);
      }

      /* ---------------- name + version under the head ---------------- */
      RenderUtil.drawInterText(context, name,
         Math.round(centerX - RenderUtil.popinsWidth(name, 9.0F) / 2.0F),
         hy + headSize + 12, BlueColors.TEXT_PRIMARY);
      String version = BlueClient.displayVersion() + " \u00b7 1.21.11";
      RenderUtil.drawInterText(context, version,
         Math.round(centerX - RenderUtil.popinsWidth(version, 9.0F) / 2.0F),
         hy + headSize + 24, -13673473);

      /* ---------------- the four destinations, flanking the head ---------- */
      int bw = 104;
      int bh = 26;
      int gapX = 14;
      int rowGap = 8;

      int leftX = centerX - headSize / 2 - 20 - bw - gapX;
      int rightX = centerX + headSize / 2 + 20 + gapX;
      int rowTop = centerY - bh - rowGap / 2 - 10 + dy;
      int rowBottom = rowTop + bh + rowGap;

      this.quickButton(context, mouseX, mouseY, leftX, rowTop, bw, bh,
         "layout-grid", "Mods", () -> {
            BlueClient blue = BlueClient.getInstance();
            MinecraftClient.getInstance().setScreen(
               new net.bluenetwork.client.ui.screen.ModuleMenuScreen(blue, this));
         }, alpha);

      this.quickButton(context, mouseX, mouseY, leftX, rowBottom, bw, bh,
         "settings", "Settings",
         () -> MinecraftClient.getInstance().setScreen(new ClientSettingsScreen(this)),
         alpha);

      this.quickButton(context, mouseX, mouseY, rightX, rowTop, bw, bh,
         "move", "HUD", () -> {
            BlueClient blue = BlueClient.getInstance();
            MinecraftClient.getInstance().setScreen(
               new net.bluenetwork.client.ui.screen.HudEditScreen(blue, this));
         }, alpha);

      this.quickButton(context, mouseX, mouseY, rightX, rowBottom, bw, bh,
         "users", "Social",
         () -> MinecraftClient.getInstance().setScreen(
            new net.bluenetwork.client.ui.screen.FriendsScreen(this)),
         alpha);

      String hint = "ESC to close";
      RenderUtil.drawText(context, hint,
         Math.round(centerX - RenderUtil.textWidth(hint) / 2.0F),
         hy + headSize + 42, BlueColors.TEXT_MUTED);
   }

   private void quickButton(DrawContext context, int mouseX, int mouseY, int x, int y, int w, int h, String icon, String label, Runnable action) {
      this.quickButton(context, mouseX, mouseY, x, y, w, h, icon, label, action, 255);
   }

   private void quickButton(DrawContext context, int mouseX, int mouseY, int x, int y, int w, int h, String icon, String label, Runnable action, int alpha) {
      boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
      String id = "quick:" + label;
      float progress = net.bluenetwork.client.util.HoverAnim.progress(id, hovered,
         net.bluenetwork.client.util.HoverAnim.rate(BlueClient.getInstance().settings().animations()));
      int body = lerpColor(-1441720801, -300211404, progress);
      RenderUtil.drawRoundedRect(context, x, y, w, h, body, 7);
      int borderColor = lerpColor(1728053247, -299744001, progress);
      RenderUtil.drawRoundedOutline(context, x, y, w, h, borderColor, 7);
      if (progress > 0.05F) {
         int glow = (int)(96.0F * progress);
         context.fill(x + 5, y, x + w - 5, y + 1, glow << 24 | 16777215);
      }

      int iconColor = lerpColor(BlueColors.TEXT_MUTED, -11699713, progress);
      float labelW = RenderUtil.popinsWidth(label, 9.0F);
      float groupW = 15 + labelW;
      int startX = Math.round(x + (w - groupW) / 2.0F);
      RenderUtil.drawIcon(context, icon, startX, y + (h - 11) / 2 + 1, 11, iconColor);
      RenderUtil.drawInterText(context, label, startX + 15, y + (h - 10) / 2 + 1, BlueColors.TEXT_PRIMARY);
      this.hits.add(new QuickMenuScreen.Hit(x, y, w, h, action));
   }

   private static int lerpColor(int a, int b, double t) {
      int aR = a >> 16 & 0xFF;
      int aG = a >> 8 & 0xFF;
      int aB = a & 0xFF;
      int bR = b >> 16 & 0xFF;
      int bG = b >> 8 & 0xFF;
      int bB = b & 0xFF;
      return 0xFF000000 | (int)(aR + (bR - aR) * t) << 16 | (int)(aG + (bG - aG) * t) << 8 | (int)(aB + (bB - aB) * t);
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int)click.x();
      int my = (int)click.y();
      if (click.button() == 0) {
         for (QuickMenuScreen.Hit hit : this.hits) {
            if (mx >= hit.x && mx < hit.x + hit.w && my >= hit.y && my < hit.y + hit.h) {
               RenderUtil.clickSound();
               hit.action.run();
               return true;
            }
         }
      }

      return super.mouseClicked(click, doubled);
   }

   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      int guiKey = BlueClient.getInstance().settings().guiKeybind();
      if (key == guiKey && System.currentTimeMillis() - this.openedAt < 250L) {
         return true;
      } else if (key != 256 && (guiKey <= 0 || key != guiKey)) {
         return super.keyPressed(input);
      } else {
         this.close();
         return true;
      }
   }

   private record Hit(int x, int y, int w, int h, Runnable action) {
   }
}
