package net.bluenetwork.client.render;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;

/**
 * Global holder for the active GUI scissor rectangle, mirrored from vanilla's
 * per-DrawContext scissor stack by {@code BlueScissorTrackerMixin}. The scissor
 * state is a global render fact (the GPU scissor is also global), so a single
 * holder is sound even with multiple DrawContext instances.
 */
public final class BlueScissors {
    private static volatile ScreenRect current;

    private BlueScissors() {
    }

    /** Called only by the scissor tracker mixin on push/pop. */
    public static void set(ScreenRect rect) {
        current = rect;
    }

    /** Current scissor rectangle, or null when nothing is clipped. */
    public static ScreenRect current() {
        return current;
    }

    /** Compatibility shim: scissor is now global, the context is irrelevant. */
    public static ScreenRect current(DrawContext context) {
        return current;
    }
}
