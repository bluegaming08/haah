package net.bluenetwork.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2fc;

/**
 * Anti-aliased rounded outline ring. Four straight strips plus four quarter-annulus quad
 * strips. UV0.x carries the signed distance from the stroke centreline in half-thickness
 * units; UV0.y carries the feather width for the shader. Both edges of the ring fade
 * smoothly, so 1px outlines stay clean at any GUI scale.
 */
final class RoundedRingGuiElement implements SimpleGuiElementRenderState {
    private static final int SEGMENTS = 8;
    private static final float AA = 0.5F;
    private static final float EXT = 1.5F;

    private final Matrix3x2fc pose;
    private final float x0;
    private final float y0;
    private final float x1;
    private final float y1;
    private final float radius;
    private final float thickness;
    private final int color;
    private final ScreenRect scissorArea;
    private final ScreenRect bounds;

    RoundedRingGuiElement(Matrix3x2fc pose, float x0, float y0, float x1, float y1, float radius, float thickness, int color, ScreenRect scissor, ScreenRect bounds) {
        this.pose = pose;
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
        this.radius = radius;
        this.thickness = thickness;
        this.color = color;
        this.scissorArea = scissor;
        this.bounds = bounds;
    }

    @Override
    public void setupVertices(VertexConsumer consumer) {
        float r = Math.min(radius, Math.min((x1 - x0) * 0.5F, (y1 - y0) * 0.5F));
        float half = thickness * 0.5F;

        // Straight strips along each edge, from the corner centres.
        stripX(consumer, x0 + r, x1 - r, y0 + half, half);
        stripX(consumer, x0 + r, x1 - r, y1 - half, half);
        stripY(consumer, y0 + r, y1 - r, x0 + half, half);
        stripY(consumer, y0 + r, y1 - r, x1 - half, half);

        // Quarter annuli at each corner, from inner to outer arc.
        annulus(consumer, x0 + r, y0 + r, r, half, (float) Math.PI, (float) (Math.PI * 1.5));
        annulus(consumer, x1 - r, y0 + r, r, half, (float) (Math.PI * 1.5), (float) (Math.PI * 2.0));
        annulus(consumer, x1 - r, y1 - r, r, half, 0.0F, (float) (Math.PI * 0.5));
        annulus(consumer, x0 + r, y1 - r, r, half, (float) (Math.PI * 0.5), (float) Math.PI);
    }

    /** Horizontal strip: quad spanning x in [xa, xb] around centreline y at +-half*EXT. */
    private void stripX(VertexConsumer consumer, float xa, float xb, float centerY, float half) {
        float lo = centerY - half * EXT;
        float hi = centerY + half * EXT;
        quad(consumer, xa, lo, -EXT, xb, lo, -EXT, xb, hi, EXT, xa, hi, EXT);
    }

    /** Vertical strip: quad spanning y in [ya, yb] around centreline x at +-half*EXT. */
    private void stripY(VertexConsumer consumer, float ya, float yb, float centerX, float half) {
        float lo = centerX - half * EXT;
        float hi = centerX + half * EXT;
        quad(consumer, lo, ya, -EXT, hi, ya, EXT, hi, yb, EXT, lo, yb, -EXT);
    }

    private void annulus(VertexConsumer consumer, float cx, float cy, float r, float half, float from, float to) {
        float mid = r - half;
        float pInX = arcX(cx, mid - half * EXT, from);
        float pInY = arcY(cy, mid - half * EXT, from);
        float pOutX = arcX(cx, mid + half * EXT, from);
        float pOutY = arcY(cy, mid + half * EXT, from);
        for (int i = 1; i <= SEGMENTS; i++) {
            float angle = from + (to - from) * i / SEGMENTS;
            float inX = arcX(cx, mid - half * EXT, angle);
            float inY = arcY(cy, mid - half * EXT, angle);
            float outX = arcX(cx, mid + half * EXT, angle);
            float outY = arcY(cy, mid + half * EXT, angle);
            quad(consumer, pInX, pInY, -EXT, pOutX, pOutY, EXT, outX, outY, EXT, inX, inY, -EXT);
            pInX = inX;
            pInY = inY;
            pOutX = outX;
            pOutY = outY;
        }
    }

    private void quad(VertexConsumer consumer, float ax, float ay, float au, float bx, float by, float bu, float cx, float cy, float cu, float dx, float dy, float du) {
        consumer.vertex(pose, ax, ay).texture(au, AA).color(color);
        consumer.vertex(pose, bx, by).texture(bu, AA).color(color);
        consumer.vertex(pose, cx, cy).texture(cu, AA).color(color);
        consumer.vertex(pose, dx, dy).texture(du, AA).color(color);
    }

    private static float arcX(float cx, float radius, float angle) {
        return (float) (cx + Math.cos(angle) * radius);
    }

    private static float arcY(float cy, float radius, float angle) {
        return (float) (cy + Math.sin(angle) * radius);
    }

    @Override
    public RenderPipeline pipeline() {
        return BluePipelines.ROUNDED_RECT;
    }

    @Override
    public TextureSetup textureSetup() {
        return TextureSetup.empty();
    }

    @Override
    public ScreenRect scissorArea() {
        return scissorArea;
    }

    @Override
    public ScreenRect bounds() {
        return bounds;
    }
}
