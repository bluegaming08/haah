package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.optimization.LoadGovernor;
import net.bluenetwork.client.optimization.PerformanceOptimizer;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Auto Quality — user-facing driver for {@link LoadGovernor}: holds a target
 * FPS and lets the governor step the UI quality ladder (Glass+glow → Matte →
 * Flat/no-fx + minimal particles) down when frames drop and back up when they
 * recover. Everything is restored when the module is switched off.
 */
public class AutoQuality extends Module {
   private final NumberSetting targetFps = new NumberSetting("Target FPS", "Hold at least this many frames", 60.0, 30.0, 240.0, 5.0);
   private final NumberSetting hysteresis = new NumberSetting("Hysteresis", "Headroom before quality steps back up", 15.0, 5.0, 60.0, 5.0);

   private int ticks = 0;

   public AutoQuality() {
      super("Auto Quality", "Auto-tune visuals to keep your FPS", Category.MISC);
      this.addSettings(new Setting[]{this.targetFps, this.hysteresis});
   }

   @Override
   protected void onEnable() {
      LoadGovernor.enable();
   }

   @Override
   protected void onDisable() {
      LoadGovernor.disable();
   }

   @Override
   public void onTick() {
      if (++this.ticks % 4 != 0) {
         return;
      }
      LoadGovernor.tick(PerformanceOptimizer.getCurrentFPS(), this.targetFps.get(), this.hysteresis.get());
   }
}
