package net.bluenetwork.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;

public class ModeSetting extends Setting<String> {
   private final List<String> modes;

   public ModeSetting(String name, String description, List<String> modes, String defaultMode) {
      super(name, description, defaultMode);
      this.modes = modes;
   }

   public void set(String value) {
      if (this.modes.contains(value)) {
         super.set(value);
      }
   }

   public List<String> getModes() {
      return this.modes;
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.get());
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
         this.set(element.getAsString());
      }
   }
}
