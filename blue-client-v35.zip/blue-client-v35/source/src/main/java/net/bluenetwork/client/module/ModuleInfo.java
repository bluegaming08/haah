package net.bluenetwork.client.module;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * v3 module metadata (BLUE_CLIENT_V3_MASTER_PLAN.md §3.1). Declared by a module
 * through {@link ModuleInfoProvider} (new modules) or synthesised from legacy
 * fields by the catalogue for the existing 29. Drives the Library UI, search,
 * the smoke test and conflict detection — no hand-maintained module lists.
 */
public final class ModuleInfo {
   private final String id;
   private final String name;
   private final String description;
   private final Family family;
   private final String icon;
   private final int accent;         // 0xRRGGBB for the row/icon tint
   private final int defaultKey;     // GLFW code, 0 = none
   private final boolean requiresWorld;
   private final boolean experimental;
   private final Set<ModuleTag> tags;
   private final String since;

   private ModuleInfo(Builder b) {
      this.id = b.id;
      this.name = b.name;
      this.description = b.description;
      this.family = b.family == null ? Family.UTILITY : b.family;
      this.icon = b.icon == null ? "square" : b.icon;
      this.accent = b.accent != 0 ? b.accent : 0x4D8DFF;
      this.defaultKey = b.defaultKey;
      this.requiresWorld = b.requiresWorld;
      this.experimental = b.experimental;
      this.tags = Set.copyOf(b.tags);
      this.since = b.since == null ? "1.0.0" : b.since;
   }

   public String id() {
      return id;
   }

   public String name() {
      return name;
   }

   public String description() {
      return description;
   }

   public Family family() {
      return family;
   }

   public String icon() {
      return icon;
   }

   /** 0xRRGGBB row tint / icon accent. */
   public int accent() {
      return accent;
   }

   public int defaultKey() {
      return defaultKey;
   }

   public boolean requiresWorld() {
      return requiresWorld;
   }

   public boolean experimental() {
      return experimental;
   }

   public Set<ModuleTag> tags() {
      return tags;
   }

   public boolean hasTag(ModuleTag tag) {
      return tags.contains(tag);
   }

   public String since() {
      return since;
   }

   public static Builder builder() {
      return new Builder();
   }

   public static final class Builder {
      private String id;
      private String name;
      private String description = "";
      private Family family;
      private String icon = "square";
      private int accent;
      private int defaultKey;
      private boolean requiresWorld;
      private boolean experimental;
      private final Set<ModuleTag> tags = new LinkedHashSet<>();
      private String since;

      public Builder id(String id) {
         this.id = id;
         return this;
      }

      public Builder name(String name) {
         this.name = name;
         return this;
      }

      public Builder description(String description) {
         this.description = description;
         return this;
      }

      public Builder family(Family family) {
         this.family = family;
         return this;
      }

      public Builder icon(String icon) {
         this.icon = icon;
         return this;
      }

      public Builder accent(int rgb) {
         this.accent = rgb & 0xFFFFFF;
         return this;
      }

      public Builder defaultKey(int glfwCode) {
         this.defaultKey = glfwCode;
         return this;
      }

      public Builder requiresWorld(boolean requiresWorld) {
         this.requiresWorld = requiresWorld;
         return this;
      }

      public Builder experimental(boolean experimental) {
         this.experimental = experimental;
         return this;
      }

      public Builder tags(ModuleTag... tags) {
         this.tags.addAll(Arrays.asList(tags));
         return this;
      }

      public Builder since(String since) {
         this.since = since;
         return this;
      }

      public ModuleInfo build() {
         if (this.id == null || this.name == null) {
            throw new IllegalStateException("ModuleInfo requires an id and a name");
         }
         return new ModuleInfo(this);
      }
   }
}
