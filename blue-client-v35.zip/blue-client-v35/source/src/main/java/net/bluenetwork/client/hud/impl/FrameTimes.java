package net.bluenetwork.client.hud.impl;

import java.util.Arrays;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * Live frametime graph with 1% low tracking. Frame times are sampled from the
 * HUD render cadence (one sample per rendered frame), so the graph reflects
 * real frame pacing, not the averaged FPS counter.
 */
public class FrameTimes extends HudModule {
   private static final int SAMPLES = 240;
   private static final float MAX_MS = 50.0F;
   private static final int PANEL_WIDTH = 116;
   private static final int PANEL_HEIGHT = 46;
   private static final int GRAPH_HEIGHT = 26;

   private final BooleanSetting showLows = new BooleanSetting("1% Lows", "Show the 1% low line with second row", true);
   private final float[] samples = new float[SAMPLES];
   private int sampleIndex;
   private int sampleCount;
   private long lastFrameNanos;

   public FrameTimes() {
      super("Frame Times", "Live frametime graph with 1% low tracking.", Category.HUD, 4, 250);
      this.addSettings(new Setting[]{this.showLows});
   }

   private void push(float ms) {
      this.samples[this.sampleIndex] = ms;
      this.sampleIndex = (this.sampleIndex + 1) % SAMPLES;
      this.sampleCount = Math.min(this.sampleCount + 1, SAMPLES);
   }

   private float average() {
      if (this.sampleCount == 0) {
         return 0.0F;
      }

      float sum = 0.0F;
      int from = (this.sampleIndex - this.sampleCount + SAMPLES) % SAMPLES;
      for (int i = 0; i < this.sampleCount; i++) {
         sum += this.samples[(from + i) % SAMPLES];
      }
      return sum / this.sampleCount;
   }

   /** Average of the worst 1% of frames (the classic "1% low"). */
   private float onePercentLow() {
      if (this.sampleCount < 20) {
         return 0.0F;
      }

      float[] copy = new float[this.sampleCount];
      int from = (this.sampleIndex - this.sampleCount + SAMPLES) % SAMPLES;
      for (int i = 0; i < this.sampleCount; i++) {
         copy[i] = this.samples[(from + i) % SAMPLES];
      }

      Arrays.sort(copy);
      int worst = Math.max(1, this.sampleCount / 100);
      float sum = 0.0F;
      for (int i = 0; i < worst; i++) {
         sum += copy[this.sampleCount - 1 - i];
      }
      return sum / worst;
   }

   private static int fpsFor(float ms) {
      return ms > 0.01F ? Math.max(1, Math.round(1000.0F / ms)) : 0;
   }

   @Override
   public void render(DrawContext context) {
      long now = System.nanoTime();
      if (this.lastFrameNanos != 0L) {
         float ms = (float)((double)(now - this.lastFrameNanos) / 1000000.0);
         this.push(Math.min(ms, 250.0F));
      }
      this.lastFrameNanos = now;

      int x = this.getX();
      int y = this.getY();
      RenderUtil.drawRoundedPanel(context, x, y, PANEL_WIDTH, PANEL_HEIGHT);

      float avg = this.average();
      float low = this.onePercentLow();
      boolean twoRows = this.showLows.get() && low > 0.0F;

      int graphBottom = twoRows ? y + 27 : y + 37;
      int graphWidth = PANEL_WIDTH - 4;
      int from = (this.sampleIndex - Math.min(this.sampleCount, graphWidth) + SAMPLES) % SAMPLES;
      int visible = Math.min(this.sampleCount, graphWidth);
      for (int i = 0; i < visible; i++) {
         float ms = this.samples[(from + i) % SAMPLES];
         int barH = Math.max(1, Math.round(Math.min(ms, MAX_MS) / MAX_MS * (float)GRAPH_HEIGHT));
         int barX = x + 2 + i;
         int color = ms > MAX_MS * 0.8F ? BlueColors.TOGGLE_OFF : BlueColors.ACCENT;
         context.fill(barX, graphBottom - barH, barX + 1, graphBottom, color);
      }

      int textY = twoRows ? y + 30 : y + 38;
      RenderUtil.drawText(context, String.format("%.1fms · %dfps", avg, fpsFor(avg)), x + 4, textY, BlueColors.TEXT_PRIMARY);
      if (twoRows) {
         RenderUtil.drawText(context, String.format("1%% low %.1fms · %dfps", low, fpsFor(low)), x + 4, textY + 10, BlueColors.TEXT_MUTED);
      }
   }

   @Override
   public int getWidth() {
      return PANEL_WIDTH;
   }

   @Override
   public int getHeight() {
      return PANEL_HEIGHT;
   }
}
