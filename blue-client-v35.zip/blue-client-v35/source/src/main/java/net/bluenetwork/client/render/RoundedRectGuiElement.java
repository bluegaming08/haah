package net.bluenetwork.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2fc;

/**
 * A rounded rectangle recorded into the vanilla GUI render state. The rect is drawn as
 * five solid quads (centre plus four edges) and four quarter-circle fans. Solid pieces
 * use UV (0,aa) which the shader treats as fully inside; fan arc vertices carry
 * arcRadius/radius in UV.x, so interpolation yields the radial distance in radius units
 * and the fragment shader feathers the edge with a smoothstep. Fans are written as
 * degenerate quads (centre, a, b, centre) so the whole element batches in QUADS mode.
 */
final class RoundedRectGuiElement implements SimpleGuiElementRenderState {
    private static final int SEGMENTS = 8;
    private static final float AA = 0.15F;
    private static final float UV_PAD = 1.35F;

    private final Matrix3x2fc pose;
    private final float x0;
    private final float y0;
    private final float x1;
    private final float y1;
    private final float radius;
    private final int color;
    private final ScreenRect scissorArea;
    private final ScreenRect bounds;

    RoundedRectGuiElement(Matrix3x2fc pose, float x0, float y0, float x1, float y1, float radius, int color, ScreenRect scissor, ScreenRect bounds) {
        this.pose = pose;
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
        this.radius = radius;
        this.color = color;
        this.scissorArea = scissor;
        this.bounds = bounds;
    }

    @Override
    public void setupVertices(VertexConsumer consumer) {
        float r = Math.min(radius, Math.min((x1 - x0) * 0.5F, (y1 - y0) * 0.5F));

        // Centre plus four edge strips, all solid (UV 0 -> inside the distance field).
        quad(consumer, x0 + r, y0, x1 - r, y0 + r);
        quad(consumer, x0 + r, y1 - r, x1 - r, y1);
        quad(consumer, x0, y0 + r, x0 + r, y1 - r);
        quad(consumer, x1 - r, y0 + r, x1, y1 - r);
        quad(consumer, x0 + r, y0 + r, x1 - r, y1 - r);

        // Corner fans: TL, TR, BR, BL.
        fan(consumer, x0 + r, y0 + r, r, (float) Math.PI, (float) (Math.PI * 1.5));
        fan(consumer, x1 - r, y0 + r, r, (float) (Math.PI * 1.5), (float) (Math.PI * 2.0));
        fan(consumer, x1 - r, y1 - r, r, 0.0F, (float) (Math.PI * 0.5));
        fan(consumer, x0 + r, y1 - r, r, (float) (Math.PI * 0.5), (float) Math.PI);
    }

    private void quad(VertexConsumer consumer, float ax, float ay, float bx, float by) {
        consumer.vertex(pose, ax, ay).texture(0.0F, AA).color(color);
        consumer.vertex(pose, bx, ay).texture(0.0F, AA).color(color);
        consumer.vertex(pose, bx, by).texture(0.0F, AA).color(color);
        consumer.vertex(pose, ax, by).texture(0.0F, AA).color(color);
    }

    private void fan(VertexConsumer consumer, float cx, float cy, float r, float from, float to) {
        float arc = r * UV_PAD;
        float prevX = (float) (cx + Math.cos(from) * arc);
        float prevY = (float) (cy + Math.sin(from) * arc);
        for (int i = 1; i <= SEGMENTS; i++) {
            float angle = from + (to - from) * i / SEGMENTS;
            float x = (float) (cx + Math.cos(angle) * arc);
            float y = (float) (cy + Math.sin(angle) * arc);
            // Degenerate quad: renders one fan triangle, keeps the 4-vertex stride.
            consumer.vertex(pose, cx, cy).texture(0.0F, AA).color(color);
            consumer.vertex(pose, prevX, prevY).texture(UV_PAD, AA).color(color);
            consumer.vertex(pose, x, y).texture(UV_PAD, AA).color(color);
            consumer.vertex(pose, cx, cy).texture(0.0F, AA).color(color);
            prevX = x;
            prevY = y;
        }
    }

    @Override
    public RenderPipeline pipeline() {
        return BluePipelines.ROUNDED_RECT;
    }

    @Override
    public TextureSetup textureSetup() {
        return TextureSetup.empty();
    }

    @Override
    public ScreenRect scissorArea() {
        return scissorArea;
    }

    @Override
    public ScreenRect bounds() {
        return bounds;
    }
}
