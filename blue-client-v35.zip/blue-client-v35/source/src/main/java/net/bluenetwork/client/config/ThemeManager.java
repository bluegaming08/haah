package net.bluenetwork.client.config;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.ui.theme.ThemePalette;
import net.bluenetwork.client.ui.theme.ThemeStyle;

/**
 * Live theme state for the whole client (v0.24.0 rewrite).
 *
 * <h2>What changed from v11</h2>
 * v11 had seven themes stored as free-text strings, and every theme change
 * mutated a pile of {@code public static int} fields on {@link BlueColors}.
 * v12 has exactly three themes ({@link ThemeStyle}) and all colour lives in an
 * immutable {@link ThemePalette}.
 *
 * <h2>Why BlueColors is still written</h2>
 * Around a hundred v11 screens read {@code BlueColors.PANEL_BG} and friends
 * directly. Rewriting all of them in one change would be a huge, risky diff, so
 * {@link #apply} <b>mirrors</b> the active palette into those legacy fields.
 * The result: old screens follow the new themes for free, and new code can use
 * {@code DesignTokens} / {@code palette()} properly.
 *
 * <p>Next AI: when you touch an old screen, migrate it to {@code DesignTokens}
 * and delete its {@code BlueColors} usage. When the last one is gone, delete
 * {@code BlueColors} and the mirroring block below.</p>
 *
 * <h2>Usage rule</h2>
 * Call {@link #palette()} <b>once per frame</b> and pass it down; never cache
 * it in a field, or your screen will freeze on whatever theme was active when
 * it was constructed.
 */
public final class ThemeManager {

   /** Theme ids in cycle order. Kept as strings for the settings UI + config. */
   public static final String[] THEMES = ThemeStyle.IDS;

   /** The client's brand accent (#2FA5FF). */
   public static final int DEFAULT_ACCENT = ThemePalette.BRAND_ACCENT;

   /** Owner's requirement: the client starts on BLACK. */
   private static ThemeStyle current = ThemeStyle.BLACK;

   private static ThemePalette palette = ThemePalette.of(ThemeStyle.BLACK);

   private ThemeManager() {
   }

   /* ===================================================================== */
   /* Reads                                                                 */
   /* ===================================================================== */

   /** The active palette. Call per frame; never cache. */
   public static ThemePalette palette() {
      return palette;
   }

   /** The active theme. */
   public static ThemeStyle style() {
      return current;
   }

   /** The active theme's id, e.g. {@code "BLACK"} — what the config stores. */
   public static String currentTheme() {
      return current.name();
   }

   /** True when panels are opaque (BLACK and WHITE). */
   public static boolean opaque() {
      return !current.isTranslucent();
   }

   /* ===================================================================== */
   /* Writes                                                                */
   /* ===================================================================== */

   /** Applies a theme by enum. */
   public static void apply(ThemeStyle style) {
      current = style == null ? ThemeStyle.BLACK : style;
      palette = ThemePalette.of(current);
      mirrorToLegacyBlueColors(palette);
   }

   /** Applies a theme by name, migrating legacy names such as {@code DARK}. */
   public static void applyByName(String name) {
      apply(ThemeStyle.fromId(name));
   }

   /** Cycles BLACK → GLASS → WHITE → BLACK and returns the new theme's id. */
   public static String cycle() {
      apply(current.next());
      return currentTheme();
   }

   /* ===================================================================== */
   /* Legacy bridge                                                         */
   /* ===================================================================== */

   /**
    * Copies the palette into the old {@link BlueColors} statics so every v11
    * screen follows the current theme without being rewritten.
    * See the class docs for why this exists and when to delete it.
    */
   private static void mirrorToLegacyBlueColors(ThemePalette p) {
      BlueColors.ACCENT = p.accent();
      BlueColors.ACCENT_SOFT = p.accentSoft();
      BlueColors.PANEL_BG = p.panelBg();
      BlueColors.PANEL_BG_HOVER = p.panelBgHover();
      BlueColors.PANEL_BORDER = p.panelBorder();
      BlueColors.TEXT_PRIMARY = p.textHi();
      BlueColors.TEXT_MUTED = p.textMid();
      BlueColors.TOGGLE_OFF = p.toggleOff();
      BlueColors.GLASS_TINT = ThemePalette.fade(p.accent(), 0.10F);
   }
}
