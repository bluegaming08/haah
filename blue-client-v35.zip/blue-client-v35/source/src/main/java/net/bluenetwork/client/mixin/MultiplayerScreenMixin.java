package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.brand.BlueBrand;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.network.ServerInfo.ServerType;
import net.minecraft.client.option.ServerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MultiplayerScreen.class})
public abstract class MultiplayerScreenMixin {
   @Shadow
   private ServerList serverList;

   @Inject(
      method = {"init"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/option/ServerList;loadFile()V",
         shift = Shift.AFTER
      )}
   )
   private void blueclient$pinOnLoad(CallbackInfo ci) {
      this.pin();
   }

   private int rePinCountdown = 0;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void blueclient$rePin(CallbackInfo ci) {
      // Re-pin periodically (fresh entries, saved-list reload), not every tick —
      // pin() walks and rebuilds the whole server list.
      if (this.rePinCountdown-- > 0) {
         return;
      }
      this.rePinCountdown = 40;
      if (this.serverList != null) {
         this.pin();
      }
   }

   private void pin() {
      try {
         if (this.serverList.size() > 0) {
            ServerInfo top = this.serverList.get(0);
            if (BlueBrand.isBlueNetwork(top.address)) {
               return;
            }
         }

         for (int i = 0; i < this.serverList.size(); i++) {
            ServerInfo info = this.serverList.get(i);
            if (BlueBrand.isBlueNetwork(info.address)) {
               this.serverList.remove(info);
               i--;
            }
         }

         ServerInfo blueNetwork = new ServerInfo("Blue Network", "play.sennahosting.com", ServerType.OTHER);
         this.serverList.add(blueNetwork, false);

         for (int ix = this.serverList.size() - 1; ix > 0; ix--) {
            this.serverList.swapEntries(ix, ix - 1);
         }
      } catch (Throwable var3) {
         BlueClient.LOGGER.debug("Could not pin Blue Network to the server list", var3);
      }
   }
}
