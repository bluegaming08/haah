package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.CpsHud;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public abstract class MouseMixin {
   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")}
   )
   private void blueclient$recordClick(long window, MouseInput input, int action, CallbackInfo ci) {
      if (action == 1 || action == 2) {
         CpsHud.onPress(input.button());
      }
   }
}
