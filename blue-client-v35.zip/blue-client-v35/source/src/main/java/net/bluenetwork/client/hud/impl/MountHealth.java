package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

/**
 * Mount Health (bonus HUD) — health of whatever you are riding (horse, strider,
 * …). Hides itself when you are not riding a living entity.
 */
public class MountHealth extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Low-health colour", 0xFFFF5C5C);

   public MountHealth() {
      super("Mount Health", "Health of the entity you ride", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.warnColor});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_LEFT, 6, 240);
   }

   private LivingEntity mount() {
      if (MinecraftClient.getInstance().player == null) {
         return null;
      }
      return MinecraftClient.getInstance().player.getVehicle() instanceof LivingEntity living ? living : null;
   }

   private String text(LivingEntity m) {
      int pct = m.getMaxHealth() <= 0.0F ? 100 : Math.max(0, (int) (m.getHealth() * 100.0F / m.getMaxHealth()));
      return "Mount " + pct + "%";
   }

   @Override
   public void render(DrawContext context) {
      LivingEntity m = this.mount();
      if (m == null) {
         return;
      }
      this.drawPanel(context);
      boolean low = m.getMaxHealth() > 0.0F && m.getHealth() / m.getMaxHealth() < 0.3F;
      int color = low ? this.warnColor.currentRgb(System.currentTimeMillis()) : this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(m), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Mount 100%") + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
