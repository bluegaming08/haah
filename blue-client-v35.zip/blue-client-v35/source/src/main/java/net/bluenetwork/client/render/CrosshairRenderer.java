package net.bluenetwork.client.render;

import net.bluenetwork.client.module.impl.CustomCrosshair;
import net.minecraft.client.gui.DrawContext;

/**
 * Draws a {@link CustomCrosshair.Style}.
 *
 * <p>Deliberately the <b>only</b> place a crosshair is drawn, so the live
 * preview in the settings screen and the real in-game crosshair cannot drift
 * apart. A preview that is "close enough" is worse than none — people tune
 * against it and then find the game looks different.</p>
 *
 * <h2>Performance</h2>
 * Everything here is integer rectangle fills. There are no allocations per
 * frame, no floating-point trigonometry (the circle uses a precomputed unit
 * table), and no state. Outlines are drawn as slightly larger rectangles
 * underneath rather than per-pixel borders, which keeps the fill count low.
 *
 * <h2>Resolution independence</h2>
 * All geometry is in <b>scaled GUI pixels</b> and centred on the coordinates
 * passed in, so the crosshair lands dead centre at every GUI scale, window
 * size and aspect ratio. Scaling is applied around the centre point, meaning
 * "Overall scale" grows the crosshair symmetrically instead of drifting it
 * toward a corner.
 */
public final class CrosshairRenderer {

   /** Outline colour: near-black, slightly transparent so it reads as a shadow. */
   private static final int OUTLINE_ARGB = 0xC0000000;

   /**
    * Unit circle, precomputed. 32 steps is smooth at every size the module
    * allows, and avoids calling sin/cos every frame.
    */
   private static final float[] CIRCLE_X = new float[32];
   private static final float[] CIRCLE_Y = new float[32];

   static {
      for (int i = 0; i < 32; i++) {
         double angle = i * Math.PI * 2.0 / 32.0;
         CIRCLE_X[i] = (float) Math.cos(angle);
         CIRCLE_Y[i] = (float) Math.sin(angle);
      }
   }

   private CrosshairRenderer() {
   }

   /** Draws the crosshair centred on {@code (cx, cy)}. */
   public static void draw(DrawContext context, int cx, int cy, CustomCrosshair.Style s) {
      if (s == null) {
         return;
      }
      float scale = s.scale();
      boolean scaled = Math.abs(scale - 1.0F) > 0.001F;
      if (scaled) {
         // Scale about the centre so the crosshair stays on the crosshair.
         context.getMatrices().pushMatrix();
         context.getMatrices().translate(cx, cy);
         context.getMatrices().scale(scale, scale);
         context.getMatrices().translate(-cx, -cy);
      }
      try {
         drawShape(context, cx, cy, s);
      } finally {
         if (scaled) {
            context.getMatrices().popMatrix();
         }
      }
   }

   private static void drawShape(DrawContext context, int cx, int cy, CustomCrosshair.Style s) {
      int size = Math.max(1, s.size());
      int thick = Math.max(1, s.thickness());
      int gap = Math.max(0, s.gap()) + Math.max(0, s.spread());

      switch (s.type()) {
         case "Dot" -> drawDot(context, cx, cy, Math.max(1, size), s);
         case "Circle" -> drawCircle(context, cx, cy, size + gap, thick, s);
         case "Minimal" -> {
            // Just the two horizontal arms: the least obtrusive useful shape.
            arm(context, cx - gap - size, cy - thick / 2, size, thick, s);
            arm(context, cx + gap + 1, cy - thick / 2, size, thick, s);
         }
         case "PvP" -> {
            // Four arms plus a deliberate hole in the middle for target clarity.
            drawFourArms(context, cx, cy, size, thick, gap, s);
         }
         default -> drawFourArms(context, cx, cy, size, thick, gap, s);
      }

      if (s.centerDot()) {
         int d = Math.max(1, s.centerDotSize());
         rect(context, cx - d / 2, cy - d / 2, d, d, s);
      }

      if (s.outerLines()) {
         int len = Math.max(1, s.outerLineLength());
         int t = Math.max(1, s.outerLineThickness());
         int out = gap + size + 2;
         arm(context, cx - out - len, cy - t / 2, len, t, s);
         arm(context, cx + out, cy - t / 2, len, t, s);
         arm(context, cx - t / 2, cy - out - len, t, len, s);
         arm(context, cx - t / 2, cy + out, t, len, s);
      }
   }

   private static void drawFourArms(DrawContext context, int cx, int cy,
                                    int size, int thick, int gap,
                                    CustomCrosshair.Style s) {
      // Left / right / top / bottom. Offsetting by thick/2 keeps odd and even
      // thicknesses both visually centred.
      arm(context, cx - gap - size, cy - thick / 2, size, thick, s);
      arm(context, cx + gap + 1, cy - thick / 2, size, thick, s);
      arm(context, cx - thick / 2, cy - gap - size, thick, size, s);
      arm(context, cx - thick / 2, cy + gap + 1, thick, size, s);
   }

   private static void drawDot(DrawContext context, int cx, int cy, int size,
                               CustomCrosshair.Style s) {
      rect(context, cx - size / 2, cy - size / 2, Math.max(1, size), Math.max(1, size), s);
   }

   private static void drawCircle(DrawContext context, int cx, int cy, int radius,
                                  int thick, CustomCrosshair.Style s) {
      int r = Math.max(1, radius);
      int t = Math.max(1, thick);
      for (int i = 0; i < CIRCLE_X.length; i++) {
         int px = cx + Math.round(CIRCLE_X[i] * r);
         int py = cy + Math.round(CIRCLE_Y[i] * r);
         rect(context, px - t / 2, py - t / 2, t, t, s);
      }
   }

   /** An arm: the outline underneath, then the coloured bar. */
   private static void arm(DrawContext context, int x, int y, int w, int h,
                           CustomCrosshair.Style s) {
      rect(context, x, y, w, h, s);
   }

   /** Fills a rectangle, with its outline first when enabled. */
   private static void rect(DrawContext context, int x, int y, int w, int h,
                            CustomCrosshair.Style s) {
      if (w <= 0 || h <= 0) {
         return;
      }
      if (s.outline()) {
         int o = Math.max(1, s.outlineThickness());
         context.fill(x - o, y - o, x + w + o, y + h + o, OUTLINE_ARGB);
      }
      context.fill(x, y, x + w, y + h, s.color());
   }
}
