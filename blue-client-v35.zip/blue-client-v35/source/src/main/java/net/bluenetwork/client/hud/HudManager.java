package net.bluenetwork.client.hud;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.optimization.PerfMeter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class HudManager {
   private final BlueClient client;

   public HudManager(BlueClient client) {
      this.client = client;
   }

   /**
    * Once per client tick, AFTER tickModules(): re-measures every visible HUD
    * module so the per-frame render path never calls getWidth()/getHeight().
    */
   public void tick() {
      for (HudModule module : this.client.moduleManager().getHudModules()) {
         if (module.isEnabled() || module.isRequired()) {
            module.refreshSizeCache();
         }
      }
   }

   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && !mc.options.hudHidden) {
         int screenW = mc.getWindow().getScaledWidth();
         int screenH = mc.getWindow().getScaledHeight();

         boolean metered = PerfMeter.active();
         if (metered) {
            PerfMeter.beginFrame();
         }

         for (HudModule module : this.client.moduleManager().getHudModules()) {
            if (module.isEnabled() || module.isRequired()) {
               long start = metered ? System.nanoTime() : 0L;
               try {
                  module.resolvePosition(screenW, screenH);
                  renderScaled(context, module);
               } catch (Throwable var6) {
                  BlueClient.LOGGER.error("HUD module '{}' failed to render", module.getName(), var6);
               } finally {
                  if (metered) {
                     PerfMeter.record(module.getName(), System.nanoTime() - start);
                  }
               }
            }
         }

         if (metered) {
            PerfMeter.endFrame();
         }

         this.client.notificationManager().render(context);

         // Clickable social toasts sit UNDER the plain ones so the two stacks
         // never overlap. In-game there is no cursor, so they are display-only
         // here; they become clickable as soon as a screen is open.
         net.bluenetwork.client.notification.SocialToasts.render(context, -1, -1, 8 + 25 * 5);
         // Staff announcements, drawn in-world.
         net.bluenetwork.client.notification.Announcements.render(context);
      }
   }

   /**
    * Renders one HUD module, applying its user-chosen scale.
    *
    * <h3>How scaling works</h3>
    * The module draws at its own coordinates as usual; we wrap the draw in a
    * transform that translates the origin to the module's top-left, scales,
    * then translates back. That pins the top-left corner while the panel grows
    * or shrinks, which is what makes dragging and scaling feel independent in
    * the HUD editor.
    *
    * <p>Scale 1.0 skips the matrix work entirely — the overwhelmingly common
    * case must not pay for a feature it is not using.</p>
    */
   private static void renderScaled(DrawContext context, HudModule module) {
      float scale = module.getScale();
      if (Math.abs(scale - 1.0F) < 0.001F) {
         module.render(context);
         return;
      }
      int x = module.getX();
      int y = module.getY();
      context.getMatrices().pushMatrix();
      context.getMatrices().translate(x, y);
      context.getMatrices().scale(scale, scale);
      context.getMatrices().translate(-x, -y);
      try {
         module.render(context);
      } finally {
         context.getMatrices().popMatrix();
      }
   }
}
