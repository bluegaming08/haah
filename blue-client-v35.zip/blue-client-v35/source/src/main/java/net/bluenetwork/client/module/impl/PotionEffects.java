package net.bluenetwork.client.module.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

/**
 * Potion Effects (v0.19.0) — a movable, colour-coded list of your active
 * status effects: name, amplifier (II, III...) and a mm:ss countdown that
 * blinks red in the last 5 seconds. Each line is tinted with the effect's own
 * potion colour, and the vanilla top-right icon overlay can be hidden.
 */
public class PotionEffects extends HudModule {
   private final BooleanSetting hideVanilla = new BooleanSetting("Hide vanilla icons", "Remove the default top-right potion overlay", true);
   private final BooleanSetting showAmplifier = new BooleanSetting("Show level", "Append II / III to the effect name", true);
   private final BooleanSetting showSeconds = new BooleanSetting("Show countdown", "Append the remaining time", true);
   private final BooleanSetting colorDot = new BooleanSetting("Color dot", "Draw the effect colour as a dot before the name", true);
   private final NumberSetting blink = new NumberSetting("Low time blink", "Blink the timer under this many seconds", 5.0, 0.0, 30.0, 1.0);

   public PotionEffects() {
      super("Potion Effects", "Movable list of your active effects with countdowns", Category.HUD, 4, 4);
      this.addSettings(new Setting[]{this.hideVanilla, this.showAmplifier, this.showSeconds, this.colorDot, this.blink});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 4, 4);
   }

   private int cachedWidth = 2;
   private int cachedHeight = 0;

   /** Called by the InGameHud mixin to decide whether to cancel the vanilla overlay. */
   public static boolean vanillaHidden() {
      Module m = BlueClient.getInstance().moduleManager().byName("Potion Effects");
      return m instanceof PotionEffects p && m.isEnabled() && p.hideVanilla.get();
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      List<StatusEffectInstance> effects = new ArrayList<>(mc.player.getStatusEffects());
      if (effects.isEmpty()) {
         this.cachedWidth = 0;
         this.cachedHeight = 0;
         return;
      }
      effects.sort((a, b) -> Integer.compare(a.getDuration(), b.getDuration()));

      int x = this.x;
      int y = this.y;
      int rowH = 11;
      int widest = 0;
      boolean blinkOn = (System.currentTimeMillis() / 300L) % 2L == 0L;
      int index = 0;
      for (StatusEffectInstance effect : effects) {
         int color = effect.getEffectType().value().getColor() & 0xFFFFFF;
         String label = effect.getEffectType().value().getName().getString();
         if (this.showAmplifier.get() && effect.getAmplifier() > 0) {
            label = label + " " + roman(effect.getAmplifier() + 1);
         }
         String time = this.showSeconds.get() ? remaining(effect) : "";
         String line = label + (time.isEmpty() ? "" : " " + time);
         widest = Math.max(widest, RenderUtil.textWidth(line) + (this.colorDot.get() ? 8 : 2));
         index++;
         y += rowH;
      }
      this.cachedWidth = widest;
      this.cachedHeight = effects.size() * rowH;

      y = this.y;
      for (StatusEffectInstance effect : effects) {
         int color = effect.getEffectType().value().getColor() & 0xFFFFFF;
         String label = effect.getEffectType().value().getName().getString();
         if (this.showAmplifier.get() && effect.getAmplifier() > 0) {
            label = label + " " + roman(effect.getAmplifier() + 1);
         }
         String time = this.showSeconds.get() ? remaining(effect) : "";
         int seconds = effect.isInfinite() ? Integer.MAX_VALUE : effect.getDuration() / 20;
         boolean lowTime = !time.isEmpty() && !effect.isInfinite() && seconds <= this.blink.getInt();
         if (this.colorDot.get()) {
            context.fill(this.x, y + 2, this.x + 5, y + 7, color | 0xFF000000);
            RenderUtil.drawText(context, label + (time.isEmpty() ? "" : " " + time), this.x + 8, y,
               lowTime && blinkOn ? 0xFFFF5555 : color | 0xFF000000);
         } else {
            RenderUtil.drawText(context, label + (time.isEmpty() ? "" : " " + time), this.x, y,
               lowTime && blinkOn ? 0xFFFF5555 : color | 0xFF000000);
         }
         y += rowH;
      }
   }

   @Override
   public int getWidth() {
      return Math.max(2, this.cachedWidth);
   }

   @Override
   public int getHeight() {
      return Math.max(this.cachedHeight, 11);
   }

   private String remaining(StatusEffectInstance effect) {
      if (effect.isInfinite()) {
         return "∞";
      }
      int seconds = Math.max(0, effect.getDuration() / 20);
      return String.format("%d:%02d", seconds / 60, seconds % 60);
   }

   private static String roman(int level) {
      return switch (level) {
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         default -> String.valueOf(level);
      };
   }
}
