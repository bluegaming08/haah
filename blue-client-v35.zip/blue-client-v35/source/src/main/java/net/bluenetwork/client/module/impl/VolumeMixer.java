package net.bluenetwork.client.module.impl;

import java.util.EnumMap;
import java.util.Map;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.sound.SoundCategory;

/**
 * Volume Mixer (v3 catalogue D1) — per-category volume control that keeps your
 * levels applied while enabled and restores whatever you had before when it is
 * switched off. Categories map to vanilla {@link SoundCategory}.
 *
 * <p>v0.16.1: holds are routed through {@link OptionGuard} so nothing can
 * capture our levels as "the user's original".
 */
public class VolumeMixer extends Module {
   private final NumberSetting master = new NumberSetting("Master", "Everything", 1.0, 0.0, 1.0, 0.05);
   private final NumberSetting music = new NumberSetting("Music", "Game music", 1.0, 0.0, 1.0, 0.05);
   private final NumberSetting weather = new NumberSetting("Weather", "Rain / thunder", 1.0, 0.0, 1.0, 0.05);
   private final NumberSetting blocks = new NumberSetting("Blocks", "Block place/break etc.", 1.0, 0.0, 1.0, 0.05);
   private final NumberSetting hostile = new NumberSetting("Hostile", "Monster sounds", 1.0, 0.0, 1.0, 0.05);
   private final NumberSetting players = new NumberSetting("Players", "Other players", 1.0, 0.0, 1.0, 0.05);
   private final NumberSetting ambient = new NumberSetting("Ambient", "Cave / ambience", 1.0, 0.0, 1.0, 0.05);

   private final Map<SoundCategory, Double> applied = new EnumMap<>(SoundCategory.class);

   public VolumeMixer() {
      super("Volume Mixer", "Per-category volume control", Category.MISC);
      this.addSettings(new Setting[]{this.master, this.music, this.weather, this.blocks, this.hostile, this.players, this.ambient});
   }

   @Override
   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         for (SoundCategory category : SoundCategory.values()) {
            OptionGuard.release(mc.options.getSoundVolumeOption(category), this);
         }
      }
      this.applied.clear();
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }
      this.apply(mc, SoundCategory.MASTER, this.master.get());
      this.apply(mc, SoundCategory.MUSIC, this.music.get());
      this.apply(mc, SoundCategory.WEATHER, this.weather.get());
      this.apply(mc, SoundCategory.BLOCKS, this.blocks.get());
      this.apply(mc, SoundCategory.HOSTILE, this.hostile.get());
      this.apply(mc, SoundCategory.PLAYERS, this.players.get());
      this.apply(mc, SoundCategory.AMBIENT, this.ambient.get());
   }

   private void apply(MinecraftClient mc, SoundCategory category, double value) {
      Double last = this.applied.get(category);
      if (last != null && Math.abs(last - value) < 1.0E-4) {
         return;
      }
      this.applied.put(category, value);
      SimpleOption<Double> option = mc.options.getSoundVolumeOption(category);
      OptionGuard.hold(option, Math.max(0.0, Math.min(1.0, value)), this);
   }
}
