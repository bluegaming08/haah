package net.bluenetwork.client.optimization;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;

/**
 * Chunk pre-rendering — v0.24.0: a SETTING, no longer a module.
 *
 * <h2>Why it moved</h2>
 * Owner: <i>"make the pre render chunks a setting instead of a module"</i>.
 * It was never a thing you toggle mid-fight like ToggleSprint — it is a
 * one-shot performance behaviour that runs when you join a world. As a module
 * it wasted a slot in the modules menu, could be bound to a keybind that did
 * nothing useful, and appeared in share codes where it had no meaning.
 *
 * <h2>Where the switch lives now</h2>
 * {@code ClientSettings.chunkPreloadEnabled()} (Client Settings ▸ Performance).
 * Radius is {@code chunkPreload()} in blocks (100..5000); the join-window
 * thread boost is {@code chunkPreloadBoost()}.
 *
 * <h2>How it works</h2>
 * On the first tick after a world appears we build a spiral of {@link ChunkPos}
 * outward from the player, then touch <b>two chunks per tick</b>. Two is the
 * important number: fast enough to finish a 300-block radius in a few seconds,
 * slow enough that the chunk builder never spikes and causes the very stutter
 * this exists to remove. Do not raise it without profiling.
 */
public final class ChunkPreloader {

   /** Chunks touched per tick. Read the class docs before changing. */
   private static final int CHUNKS_PER_TICK = 2;

   private static boolean preloadedThisSession;
   private static int cursor;
   private static List<ChunkPos> queue = new ArrayList<>();

   private ChunkPreloader() {
   }

   /**
    * Should the chunk builder run extra threads right now?
    * Read by {@code WorldRendererMixin}.
    */
   public static boolean boostThreads() {
      var settings = BlueClient.getInstance().settings();
      return settings.chunkPreloadEnabled() && settings.chunkPreloadBoost();
   }

   /** Pre-render radius in blocks, or 0 when the feature is off. */
   public static int radiusBlocks() {
      var settings = BlueClient.getInstance().settings();
      return settings.chunkPreloadEnabled() ? settings.chunkPreload() : 0;
   }

   /** Called once per client tick. Cheap no-op when disabled or finished. */
   public static void tick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientWorld world = mc.world;

      if (world == null) {
         reset();                       // left the world: re-arm for next join
         return;
      }
      if (!BlueClient.getInstance().settings().chunkPreloadEnabled()) {
         return;
      }
      if (!preloadedThisSession) {
         preloadedThisSession = true;
         int radius = radiusBlocks();
         if (radius > 0) {
            queue = spiral(radius);
            cursor = 0;
         }
         return;                        // build the queue now, walk it next tick
      }
      if (mc.player == null || cursor >= queue.size()) {
         return;
      }
      for (int i = 0; i < CHUNKS_PER_TICK && cursor < queue.size(); i++) {
         ChunkPos pos = queue.get(cursor++);
         try {
            world.getChunk(pos.x, pos.z);
         } catch (Throwable ignored) {
            // Best-effort: a chunk we cannot fetch is simply skipped. This must
            // never be able to interrupt the client tick loop.
         }
      }
   }

   private static void reset() {
      preloadedThisSession = false;
      queue = new ArrayList<>();
      cursor = 0;
   }

   /** Chunk positions in spiral order, centre outwards. */
   private static List<ChunkPos> spiral(int radiusBlocks) {
      List<ChunkPos> out = new ArrayList<>();
      int chunkRadius = Math.max(1, radiusBlocks / 16);
      MinecraftClient mc = MinecraftClient.getInstance();
      int cx = mc.player != null ? mc.player.getBlockX() >> 4 : 0;
      int cz = mc.player != null ? mc.player.getBlockZ() >> 4 : 0;
      for (int r = 0; r <= chunkRadius; r++) {
         for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
               if (Math.max(Math.abs(dx), Math.abs(dz)) == r) {
                  out.add(new ChunkPos(cx + dx, cz + dz));
               }
            }
         }
      }
      return out;
   }
}
