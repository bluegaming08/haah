package net.bluenetwork.client.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Frame-rate independent hover easing. Screens used to do
 * {@code progress += (target - progress) * 0.3F} once per rendered frame,
 * which animates ~4x faster at 240 FPS than at 60 FPS. This helper integrates
 * an exponential decay in real time instead, so hover transitions take the
 * same wall-clock duration on any refresh rate.
 */
public final class HoverAnim {
   /** [0] = current progress, [1] = last sample time in nanos. */
   private static final Map<String, float[]> STATE = new ConcurrentHashMap<>();

   private HoverAnim() {
   }

   /**
    * Advances and returns the hover progress for {@code id} (0 = resting, 1 = fully hovered).
    *
    * @param ratePerSecond decay rate; ~12 gives the old 60 FPS feel. Values above ~500 snap instantly.
    */
   public static float progress(String id, boolean hovered, float ratePerSecond) {
      long now = System.nanoTime();
      float[] state = STATE.computeIfAbsent(id, k -> new float[]{0.0F, now});
      float last = state[1];
      state[1] = now;
      float dt = Math.min(0.25F, (now - (long) last) / 1.0E9F);
      float target = hovered ? 1.0F : 0.0F;
      if (ratePerSecond >= 500.0F) {
         state[0] = target;
         return target;
      }
      float factor = 1.0F - (float) Math.exp(-dt * ratePerSecond);
      float next = state[0] + (target - state[0]) * factor;
      if (next > 0.999F) {
         next = 1.0F;
      } else if (next < 0.001F) {
         next = 0.0F;
      }
      state[0] = next;
      return next;
   }

   /** Animation rate that matches the client's global animations setting. */
   public static float rate(boolean animationsEnabled) {
      return animationsEnabled ? 12.0F : 1000.0F;
   }
}
