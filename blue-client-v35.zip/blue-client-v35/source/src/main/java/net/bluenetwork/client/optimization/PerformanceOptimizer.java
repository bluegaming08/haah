package net.bluenetwork.client.optimization;

import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticlesMode;

/**
 * Performance optimizer from the premium pack, made real:
 * - FPS cap management (user-set cap, restored on disable)
 * - Particle mode reduction (ALL -> MINIMAL, restored on disable)
 * - Adaptive framerate: drops the cap while the window is unfocused
 * - Live FPS/memory stats via the client's own counters
 * - Entity culling: distant entities skip rendering (see EntityRendererMixin,
 *   gated on cullingEnabled() and cullDistance)
 *
 * The master toggle + sub-toggles persist in ClientSettings.
 *
 * <p>v0.16.1: option writes go through {@link OptionGuard} so FrameSmooth /
 * Adaptive Render Distance / Custom FOV can't capture this optimizer's values
 * as "the user's original" (and vice versa).
 */
public final class PerformanceOptimizer {
   private static final Object OWNER = PerformanceOptimizer.class;

   private static boolean enabled = false;
   private static boolean particleOptimization = true;
   private static boolean adaptiveFramerate = true;
   private static boolean entityCulling = true;
   private static int maxFps = 144;
   private static int cullDistance = 48;
   private static boolean unfocusedCapped = false;
   /**
    * The FPS limit the player themselves last chose, if they changed it while
    * the optimizer was running. Takes priority over {@link #maxFps}, because a
    * value the player deliberately set must always win over our default.
    */
   private static Integer userOverride = null;

   private PerformanceOptimizer() {
   }

   /** Enables or disables all optimizations, capturing/restoring vanilla option values. */
   public static void setEnabled(boolean value) {
      if (enabled == value) {
         return;
      }
      enabled = value;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null) {
         return;
      }
      if (enabled) {
         applyFpsCap(mc);
         if (particleOptimization) {
            applyParticles(mc, ParticlesMode.MINIMAL);
         }
      } else {
         OptionGuard.release(mc.options.getMaxFps(), OWNER);
         OptionGuard.release(mc.options.getParticles(), OWNER);
         unfocusedCapped = false;
         userOverride = null;
      }
   }

   /** The cap we apply while focused: the user's cap if it is higher, ours otherwise. */
   private static void applyFpsCap(MinecraftClient mc) {
      OptionGuard.hold(mc.options.getMaxFps(), effectiveCap(mc), OWNER);
   }

   /**
    * The cap to apply while focused.
    *
    * <p>Order of precedence: a limit the player set themselves always wins;
    * otherwise the higher of our configured cap and whatever they had before
    * we started. We never LOWER someone's framerate - the optimizer exists to
    * stop runaway rendering, not to take away a 240 Hz monitor.</p>
    */
   private static int effectiveCap(MinecraftClient mc) {
      if (userOverride != null && userOverride > 0) {
         return Math.max(30, userOverride);
      }
      Integer original = OptionGuard.original(mc.options.getMaxFps());
      int effective = Math.max(maxFps, original != null && original > 0 ? original : 0);
      return Math.max(30, effective);
   }

   private static void applyParticles(MinecraftClient mc, ParticlesMode mode) {
      OptionGuard.hold(mc.options.getParticles(), mode, OWNER);
   }

   /** Called once per client tick from the main tick loop. */
   public static void tick() {
      if (!enabled) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }
      if (!OptionGuard.isHeldBy(mc.options.getMaxFps(), OWNER)) {
         applyFpsCap(mc);
      } else if (!unfocusedCapped) {
         /*
          * Did the player just change their FPS limit?
          *
          * We hold this option, so the live value should equal what we last
          * wrote. If it does not, something outside this class set it - the
          * vanilla video menu, Sodium's, or another mod - and that is a
          * deliberate act we must not undo.
          *
          * Previously tick() simply re-applied our own value, which is why
          * changing the limit in Sodium appeared to "snap back" to 140/144
          * within a tick. Adopt the new value as the baseline instead.
          */
         Integer live = mc.options.getMaxFps().getValue();
         Integer held = OptionGuard.heldValueOf(mc.options.getMaxFps(), OWNER);
         if (live != null && held != null && !live.equals(held)) {
            userOverride = live;
            OptionGuard.adoptOriginal(mc.options.getMaxFps(), live);
            OptionGuard.setValue(mc.options.getMaxFps(), live, OWNER);
         }
      }
      if (adaptiveFramerate) {
         boolean focused = mc.isWindowFocused();
         if (!focused && !unfocusedCapped) {
            OptionGuard.setValue(mc.options.getMaxFps(), 10, OWNER);
            unfocusedCapped = true;
         } else if (focused && unfocusedCapped) {
            OptionGuard.setValue(mc.options.getMaxFps(), effectiveCap(mc), OWNER);
            unfocusedCapped = false;
         }
      }
   }

   public static boolean isOptimizationEnabled() {
      return enabled;
   }

   public static boolean isParticleOptimizationEnabled() {
      return enabled && particleOptimization;
   }

   public static void setParticleOptimization(boolean value) {
      particleOptimization = value;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (enabled && mc != null && mc.options != null && OptionGuard.areOptionsReady()) {
         if (particleOptimization) {
            applyParticles(mc, ParticlesMode.MINIMAL);
         } else {
            OptionGuard.release(mc.options.getParticles(), OWNER);
         }
      }
   }

   public static boolean isAdaptiveFramerateEnabled() {
      return adaptiveFramerate;
   }

   public static void setAdaptiveFramerate(boolean value) {
      adaptiveFramerate = value;
   }

   public static boolean isEntityCullingEnabled() {
      return enabled && entityCulling;
   }

   public static void setEntityCulling(boolean value) {
      entityCulling = value;
   }

   public static int getCullDistance() {
      return cullDistance;
   }

   public static void setCullDistance(int distance) {
      cullDistance = Math.max(16, Math.min(128, distance));
   }

   public static void setMaxFps(int fps) {
      maxFps = Math.max(30, Math.min(480, fps));
      // Setting it here is an explicit choice in OUR menu, so it supersedes a
      // value previously adopted from the vanilla/Sodium menu.
      userOverride = null;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (enabled && mc != null && mc.options != null && OptionGuard.areOptionsReady() && !unfocusedCapped) {
         applyFpsCap(mc);
      }
   }

   public static int getMaxFps() {
      return maxFps;
   }

   /** Real current FPS straight from the client's own frame counter. */
   public static double getCurrentFPS() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc != null ? mc.getCurrentFps() : 0.0;
   }

   public static long getMemoryUsage() {
      Runtime runtime = Runtime.getRuntime();
      return (runtime.totalMemory() - runtime.freeMemory()) / 1024L / 1024L;
   }

   public static long getMaxMemory() {
      return Runtime.getRuntime().maxMemory() / 1024L / 1024L;
   }

   /** Explicit, user-triggered GC (never called automatically - silent GC calls are not an optimization). */
   public static void optimizeMemory() {
      System.gc();
   }
}
