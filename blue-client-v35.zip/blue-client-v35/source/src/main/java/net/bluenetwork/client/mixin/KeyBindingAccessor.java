package net.bluenetwork.client.mixin;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Read access to the CURRENT key a binding is bound to. Modules that simulate
 * key presses (Auto Walk, Anti AFK) must press the bound key — the previous
 * code used {@code getDefaultKey()}, which silently does nothing for anyone
 * who re-bound forward/jump.
 */
@Mixin(KeyBinding.class)
public interface KeyBindingAccessor {
   @Accessor("boundKey")
   InputUtil.Key blueclient$getBoundKey();
}
