package net.bluenetwork.client.module.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;

/**
 * Chunk Pre-Render - after joining a world, quietly loads the chunks around
 * you ahead of time (two per tick so nothing hitches), so exploring outwards
 * is smooth instead of stuttering over fresh terrain. Can also let the chunk
 * builder boost its threads during the join window.
 */
public class ChunkPreload extends Module {
   private final BooleanSetting threadBoost = new BooleanSetting("Join thread boost", "Extra chunk-builder threads while joining", true);

   private boolean preloadedThisSession = false;
   private int cursor = 0;
   private List<ChunkPos> queue = new ArrayList<>();

   public ChunkPreload() {
      super("Chunk Pre-Render", "Pre-loads chunks around you when you join a world", Category.MISC);
      this.addSettings(new Setting[]{this.threadBoost});
   }

   public static boolean boostThreads() {
      ChunkPreload self = Module.find(ChunkPreload.class);
      return self != null && self.isEnabled() && self.threadBoost.get();
   }

   public static int radiusBlocks() {
      int cfg = BlueClient.getInstance().settings().chunkPreload();
      ChunkPreload self = Module.find(ChunkPreload.class);
      if (self == null || !self.isEnabled()) {
         return 0;
      }
      return cfg;
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      this.reset();
   }

   private void reset() {
      this.preloadedThisSession = false;
      this.queue = new ArrayList<>();
      this.cursor = 0;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientWorld world = mc.world;
      if (world == null) {
         this.reset();
         return;
      }
      if (!this.preloadedThisSession) {
         this.preloadedThisSession = true;
         int r = radiusBlocks();
         if (r > 0) {
            this.queue = ring(r);
            this.cursor = 0;
         }
         return;
      }
      if (mc.player == null || this.cursor >= this.queue.size()) {
         return;
      }
      for (int i = 0; i < 2 && this.cursor < this.queue.size(); i++) {
         ChunkPos pos = this.queue.get(this.cursor++);
         try {
            world.getChunk(pos.x, pos.z);
         } catch (Throwable ignored) {
         }
      }
   }

   /** Spiral order from the centre outwards. */
   private static List<ChunkPos> ring(int radiusBlocks) {
      List<ChunkPos> out = new ArrayList<>();
      int chunkR = Math.max(1, radiusBlocks / 16);
      MinecraftClient mc = MinecraftClient.getInstance();
      int cx = mc.player != null ? mc.player.getBlockX() >> 4 : 0;
      int cz = mc.player != null ? mc.player.getBlockZ() >> 4 : 0;
      for (int r = 0; r <= chunkR; r++) {
         for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
               if (Math.max(Math.abs(dx), Math.abs(dz)) != r) {
                  continue;
               }
               out.add(new ChunkPos(cx + dx, cz + dz));
            }
         }
      }
      return out;
   }
}
