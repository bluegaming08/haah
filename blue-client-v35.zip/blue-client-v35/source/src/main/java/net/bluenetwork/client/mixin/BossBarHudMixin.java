package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.BossBar;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.BossBarHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Boss Bar module hooks (v0.19.0). HEAD cancel hides the bar; a pushed
 * matrix (popped at TAIL) applies the scale around the top-center pivot and
 * the user's X/Y offsets.
 */
@Mixin(BossBarHud.class)
public abstract class BossBarHudMixin {
   @Unique
   private boolean blueclient$transformed = false;

   @Inject(method = {"render"}, at = {@At("HEAD")}, cancellable = true)
   private void blueclient$hideOrMoveHead(DrawContext context, CallbackInfo ci) {
      if (BossBar.hidden()) {
         ci.cancel();
         return;
      }
      if (!BossBar.transform()) {
         return;
      }
      float scale = BossBar.scale();
      double dx = BossBar.offsetX();
      double dy = BossBar.offsetY();
      if (scale == 1.0F && dx == 0.0 && dy == 0.0) {
         return;
      }
      int cx = context.getScaledWindowWidth() / 2;
      var matrices = context.getMatrices();
      matrices.pushMatrix();
      // pivot: the vanilla bar is centred on the top middle of the screen
      matrices.translate((float) cx, 0.0F);
      matrices.scale(scale, scale);
      matrices.translate(-(float) cx, 0.0F);
      matrices.translate((float) dx, (float) dy);
      this.blueclient$transformed = true;
   }

   @Inject(method = {"render"}, at = {@At("TAIL")})
   private void blueclient$moveTail(DrawContext context, CallbackInfo ci) {
      if (this.blueclient$transformed) {
         context.getMatrices().popMatrix();
         this.blueclient$transformed = false;
      }
   }
}
