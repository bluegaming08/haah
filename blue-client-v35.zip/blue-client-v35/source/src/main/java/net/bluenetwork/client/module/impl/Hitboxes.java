package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Hitboxes — entity hitbox outlines.
 *
 * <p>Vanilla can already draw hitboxes, but only via the F3+B debug view: it
 * shows them for <em>every</em> entity, adds the eye-line and the blue
 * "looking at" vector, and cannot be recoloured. This draws a clean box
 * instead, with the options people actually want.</p>
 *
 * <h2>Behaviour</h2>
 * <ul>
 *   <li><b>Players only</b> (on by default, as requested) — item frames, mobs
 *       and dropped items stay unboxed so a fight is readable.</li>
 *   <li><b>Dynamic colour</b> — the entity currently under your crosshair is
 *       drawn in the hover colour, everything else in the normal colour. This
 *       makes it obvious what you are actually about to hit.</li>
 * </ul>
 *
 * <h2>Why this is not anticheat-flaggable</h2>
 * This module is <b>purely visual</b>. It reads the hitbox the client already
 * has and draws lines around it. It does not change the box used for
 * attacks, does not alter reach, and sends nothing to the server — unlike the
 * "hitbox expander" cheats that share the name.
 *
 * <h2>Performance: the {@link Snapshot} pattern</h2>
 * Rendering asks about <i>every entity, every frame</i>. The first version
 * called {@code moduleManager().byName("Hitboxes")} inside each of those
 * questions — a {@code toLowerCase()} allocation plus a map lookup, hundreds of
 * times per frame, on a machine with an Intel HD 615 and a 4 GB heap.
 *
 * <p>{@link #snapshot()} now resolves the module and reads every setting
 * <b>once per frame</b>, returning an immutable record the renderer queries
 * directly. Colours are resolved through {@code currentRgb(now)} so the
 * rainbow option actually animates — the old code called {@code get()}, which
 * silently ignored rainbow mode.</p>
 */
public class Hitboxes extends Module {

   private final BooleanSetting playersOnly = new BooleanSetting("Players only",
      "Only draw hitboxes for players, not mobs or items", true);
   private final BooleanSetting dynamicColor = new BooleanSetting("Dynamic colour",
      "Use a different colour for whoever is in your crosshair", true);
   private final ColorSetting normalColor = new ColorSetting("Normal colour",
      "Hitbox colour for entities you are not looking at", 0xFFFFFFFF);
   private final ColorSetting hoverColor = new ColorSetting("Hover colour",
      "Hitbox colour for the entity in your crosshair", 0xFF2FA5FF);
   private final NumberSetting lineWidth = new NumberSetting("Line width",
      "Thickness of the hitbox lines", 2.0, 0.5, 6.0, 0.5);
   private final NumberSetting range = new NumberSetting("Range",
      "Only draw hitboxes within this many blocks", 48.0, 8.0, 128.0, 4.0);
   private final BooleanSetting showSelf = new BooleanSetting("Show own hitbox",
      "Draw your own hitbox in third person", false);
   private final BooleanSetting seeThrough = new BooleanSetting("See through walls",
      "Draw hitboxes even when the entity is behind blocks", false);

   public Hitboxes() {
      super("Hitboxes", "Entity hitbox outlines with a crosshair highlight",
         Category.RENDER);
      this.addSettings(new Setting[]{
         this.playersOnly, this.dynamicColor, this.normalColor, this.hoverColor,
         this.lineWidth, this.range, this.showSelf, this.seeThrough
      });
      // Colour pickers are pointless when dynamic colour is off.
      this.hoverColor.visibleWhen(this.dynamicColor::get);
   }

   /**
    * Every setting the renderer needs, read once and frozen for the frame.
    *
    * <p>Immutable on purpose: the renderer loops over entities and must not
    * see a setting change halfway through, and a record costs one small
    * allocation per frame instead of one map lookup per entity.</p>
    */
   public record Snapshot(
      boolean playersOnly,
      boolean dynamicColor,
      int normalColor,
      int hoverColor,
      float lineWidth,
      double rangeSquared,
      boolean showSelf,
      boolean seeThrough) {

      /** @return true if a box should be drawn for this entity. */
      public boolean shouldDraw(Entity entity, PlayerEntity self) {
         if (entity == null || self == null) {
            return false;
         }
         if (this.playersOnly && !(entity instanceof PlayerEntity)) {
            return false;
         }
         if (entity == self && !this.showSelf) {
            return false;
         }
         return entity.squaredDistanceTo(self) <= this.rangeSquared;
      }

      /** @return the colour for this entity's box. */
      public int colorFor(Entity entity) {
         return this.dynamicColor && isTargeted(entity) ? this.hoverColor : this.normalColor;
      }
   }

   private static Hitboxes active() {
      Module m = BlueClient.getInstance().moduleManager().byName("Hitboxes");
      return m instanceof Hitboxes h && h.isEnabled() ? h : null;
   }

   /**
    * Reads the module's state for this frame.
    *
    * @return a frozen {@link Snapshot}, or {@code null} when the module is off
    *         (which tells the renderer to skip all of its work).
    */
   public static Snapshot snapshot() {
      Hitboxes h = active();
      if (h == null) {
         return null;
      }
      long now = System.currentTimeMillis();
      double max = h.range.get();
      return new Snapshot(
         h.playersOnly.get(),
         h.dynamicColor.get(),
         // currentRgb honours the rainbow option; plain get() does not.
         h.normalColor.currentRgb(now),
         h.hoverColor.currentRgb(now),
         h.lineWidth.getFloat(),
         max * max,
         h.showSelf.get(),
         h.seeThrough.get());
   }

   /** @return the configured range in blocks, for the broad-phase query. */
   public static double range() {
      Hitboxes h = active();
      return h == null ? 0.0 : h.range.get();
   }

   /** True when this entity is the one the crosshair is currently on. */
   private static boolean isTargeted(Entity entity) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null) {
         return false;
      }
      // targetedEntity is set by the same raycast that drives attacks, so it
      // matches what you would actually hit. crosshairTarget is the fallback
      // for when the field has not been refreshed yet this frame.
      if (mc.targetedEntity != null && mc.targetedEntity == entity) {
         return true;
      }
      return mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() == entity;
   }
}
