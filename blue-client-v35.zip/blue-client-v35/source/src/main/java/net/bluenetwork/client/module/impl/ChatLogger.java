package net.bluenetwork.client.module.impl;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * Chat Logger (v3 catalogue C5) — appends every chat message to a local file
 * while enabled. File lives in the Minecraft run directory as chat.log and is
 * appended (never rewritten) per message with an optional timestamp.
 *
 * <p>v0.16.1: writes are asynchronous. Messages are handed to a bounded queue
 * and flushed by a daemon writer thread, so a slow disk never stalls the chat /
 * render thread mid-message.</p>
 */
public class ChatLogger extends Module {
   private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
   /** Hard cap so a spam-flood can never balloon memory; oldest lines drop first. */
   private static final int MAX_PENDING = 4096;

   private static final ConcurrentLinkedQueue<String> PENDING = new ConcurrentLinkedQueue<>();
   private static volatile Thread flusher;
   private Path target = null;

   public ChatLogger() {
      super("Chat Logger", "Append chat to chat.log while enabled", Category.MISC);
   }

   /** Called from the chat mixin for every message that survives cleaning. */
   public static void log(Text message) {
      try {
         Module module = BlueClient.getInstance().moduleManager().byName("Chat Logger");
         if (!(module instanceof ChatLogger logger) || !logger.isEnabled() || message == null) {
            return;
         }
         logger.append(message);
      } catch (Throwable ignored) {
      }
   }

   private void append(Text message) {
      String content = message.getString();
      if (content == null || content.isEmpty()) {
         return;
      }
      StringBuilder line = new StringBuilder(64 + content.length());
      line.append('[').append(LocalDateTime.now().format(TIME)).append("] ");
      String escaped = content.replace('\n', ' ');
      line.append(escaped).append('\n');

      synchronized (PENDING) {
         while (PENDING.size() >= MAX_PENDING) {
            PENDING.poll();
         }
         PENDING.add(line.toString());
         PENDING.notifyAll();
      }
      startFlusher();
   }

   /** Lazily starts the single daemon writer thread. */
   private static void startFlusher() {
      if (flusher != null) {
         return;
      }
      synchronized (ChatLogger.class) {
         if (flusher != null) {
            return;
         }
         Thread thread = new Thread(ChatLogger::flushLoop, "Blue Client Chat Log");
         thread.setDaemon(true);
         thread.start();
         flusher = thread;
      }
   }

   private static void flushLoop() {
      while (true) {
         String next;
         synchronized (PENDING) {
            while (PENDING.isEmpty()) {
               try {
                  PENDING.wait(5000L);
               } catch (InterruptedException e) {
                  return;
               }
            }
            next = PENDING.poll();
         }
         ChatLogger self = current();
         if (self != null) {
            self.write(next);
         }
      }
   }

   private static ChatLogger current() {
      try {
         Module module = BlueClient.getInstance().moduleManager().byName("Chat Logger");
         if (module instanceof ChatLogger logger) {
            return logger;
         }
      } catch (Throwable ignored) {
      }
      return null;
   }

   /** Makes sure the file handle / parent dir exist (called on the writer thread). */
   private Path file() {
      if (this.target == null) {
         MinecraftClient mc = MinecraftClient.getInstance();
         this.target = (mc != null && mc.runDirectory != null ? mc.runDirectory.toPath() : Path.of(".")).resolve("chat.log");
      }
      return this.target;
   }

   private void write(String line) {
      try {
         Path path = this.file();
         if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
         }
         Files.writeString(path, line, StandardCharsets.UTF_8,
            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
      } catch (IOException ignored) {
      }
   }
}
