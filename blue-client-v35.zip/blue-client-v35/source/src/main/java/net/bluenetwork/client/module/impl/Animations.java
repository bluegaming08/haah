package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Animations (v0.19.0) — first-person hand animation control:
 * turn off the arm swing, the item-swap pop, or the eat/drink wobble
 * independently. Everything else (camera, third person) stays vanilla.
 */
public class Animations extends Module {
   private final BooleanSetting swing = new BooleanSetting("Arm swing", "Show the first person swing animation", true);
   private final BooleanSetting equip = new BooleanSetting("Equip pop", "Show the item swap raise animation", true);
   private final BooleanSetting eatDrink = new BooleanSetting("Eat / drink", "Show the eating and drinking wobble", true);

   public Animations() {
      super("Animations", "Choose which first person hand animations play", Category.RENDER);
      this.addSettings(new Setting[]{this.swing, this.equip, this.eatDrink});
   }

   private static boolean off(BooleanSetting setting) {
      Module m = BlueClient.getInstance().moduleManager().byName("Animations");
      return m instanceof Animations && m.isEnabled() && !setting.get();
   }

   /** True when the first-person arm swing should be suppressed. */
   public static boolean noSwing() {
      Module m = BlueClient.getInstance().moduleManager().byName("Animations");
      return m instanceof Animations a ? off(a.swing) : false;
   }

   /** True when the item-swap equip pop should be suppressed. */
   public static boolean noEquip() {
      Module m = BlueClient.getInstance().moduleManager().byName("Animations");
      return m instanceof Animations a ? off(a.equip) : false;
   }

   /** True when the eat/drink wobble should be suppressed. */
   public static boolean noEatDrink() {
      Module m = BlueClient.getInstance().moduleManager().byName("Animations");
      return m instanceof Animations a ? off(a.eatDrink) : false;
   }
}
