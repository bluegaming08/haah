package net.bluenetwork.client.hud.impl;

import java.io.ByteArrayInputStream;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.ServerIconFetcher;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

/**
 * Server IP / address HUD — the address of the server you're connected to
 * (or "Singleplayer"), optionally with the server's favicon drawn to the
 * LEFT of the text (v0.16.1, feedback 2026-09-11).
 *
 * <p>New settings:</p>
 * <ul>
 *   <li><b>Show Server Icon</b> (on by default, so enabling the module shows
 *       the icon straight away) — draws the server favicon left of the
 *       address.</li>
 *   <li><b>Icon Scale</b> — 50% - 300% of the 16px favicon.</li>
 * </ul>
 *
 * <p>The icon comes from a lightweight status ping
 * ({@link ServerIconFetcher}) because vanilla only stores favicons for
 * servers the multiplayer screen has pinged.</p>
 */
public class ServerIp extends HudModule {
   private static final Identifier ICON_TEXTURE = Identifier.of("blueclient", "server_ip_icon");

   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);
   private final BooleanSetting showIcon = new BooleanSetting("Show Server Icon", "Draw the server favicon left of the address", true);
   private final NumberSetting iconScale = new NumberSetting("Icon Scale", "Size of the server icon, 50% - 300%", 1.0D, 0.5D, 3.0D, 0.1D);

   private String lastAddress = "";
   private byte[] uploadedPng = null;
   private NativeImageBackedTexture texture = null;
   private boolean textureOk = false;

   public ServerIp() {
      super("Server IP", "Address of the current server", Category.HUD, 4, 4);
      this.iconScale.visibleWhen(this.showIcon::get);
      this.addSettings(new Setting[]{this.textColor, this.showIcon, this.iconScale});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 72);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return "IP --";
      }
      try {
         ServerInfo info = mc.getCurrentServerEntry();
         return info != null ? info.address : "Singleplayer";
      } catch (Throwable t) {
         return "IP --";
      }
   }

   /** Raw address for the icon ping (empty when singleplayer/unknown). */
   private String address() {
      MinecraftClient mc = MinecraftClient.getInstance();
      try {
         ServerInfo info = mc.getCurrentServerEntry();
         return info != null ? info.address : "";
      } catch (Throwable t) {
         return "";
      }
   }

   private int iconSize() {
      return Math.max(6, Math.round(16.0F * this.iconScale.getFloat()));
   }

   private boolean iconVisible() {
      return this.showIcon.get() && !this.address().isEmpty();
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);

      String address = this.address();
      if (!address.equals(this.lastAddress)) {
         // Server changed: drop the old icon and ask for the new one.
         this.lastAddress = address;
         this.uploadedPng = null;
         this.textureOk = false;
         if (!address.isEmpty()) {
            ServerIconFetcher.request(address);
         }
      }

      int size = this.iconSize();
      boolean drawIcon = false;
      if (this.iconVisible()) {
         byte[] png = ServerIconFetcher.cached(address);
         if (png != null) {
            if (png != this.uploadedPng) {
               this.upload(png, mc);
            }
            drawIcon = this.textureOk;
         }
      }

      int iconRoom = drawIcon ? size + 5 : 0;
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      int textY = this.y + Math.max(6, (this.getHeight() - 9) / 2);
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2 + iconRoom, textY, color);

      if (drawIcon) {
         int iy = this.y + Math.max(6, (this.getHeight() - size) / 2);
         context.drawTexturedQuad(ICON_TEXTURE, this.x + 8, iy, this.x + 8 + size, iy + size,
            0.0F, 1.0F, 0.0F, 1.0F);
      }
   }

   /** Uploads (or re-uploads) the favicon on the client thread. */
   private void upload(byte[] png, MinecraftClient mc) {
      this.uploadedPng = png;
      this.textureOk = false;
      try {
         NativeImage image = NativeImage.read(new ByteArrayInputStream(png));
         NativeImageBackedTexture next = new NativeImageBackedTexture(() -> "blueclient server icon", image);
         NativeImageBackedTexture old = this.texture;
         this.texture = next;
         mc.getTextureManager().registerTexture(ICON_TEXTURE, next);
         this.textureOk = true;
         if (old != null) {
            old.close();
         }
      } catch (Throwable t) {
         this.textureOk = false;
      }
   }

   @Override
   public int getWidth() {
      int iconRoom = this.iconVisible() ? this.iconSize() + 5 : 0;
      return RenderUtil.textWidth(this.text()) + 12 + 2 + iconRoom;
   }

   @Override
   public int getHeight() {
      return Math.max(21, this.iconVisible() ? this.iconSize() + 10 : 21);
   }
}
