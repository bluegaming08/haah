package net.bluenetwork.client.gui;

import net.bluenetwork.client.brand.BlueBrand;
import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.presence.NetworkStats;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.bluenetwork.client.ui.theme.ThemePalette;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * Custom "connecting to Blue Network" screen.
 *
 * <p>Owner: "can you make a custom blue network join/connecting screen".</p>
 *
 * <h2>How it hooks in</h2>
 * {@code ConnectScreen} keeps no reference to the server it is dialling, so
 * {@link #arm(String)} is called from the static {@code ConnectScreen.connect}
 * entry point (see {@code ConnectScreenMixin}) to record the address. The
 * overlay then replaces the vanilla render <b>only</b> when that address is a
 * Blue Network one — connecting to any other server keeps the stock screen, so
 * nothing about normal multiplayer changes.
 *
 * <h2>Design</h2>
 * Dark branded backdrop, the Blue logo, an animated progress bar, the live
 * vanilla status line ("Logging in...", "Negotiating..."), the address being
 * joined, and a rotating tip. Everything is theme-aware.
 */
public final class BlueConnectOverlay {

   private static final Identifier LOGO = Identifier.of("blueclient", "textures/logo.png");

   /** Tips cycled on the connect screen, one every few seconds. */
   private static final String[] TIPS = {
      "Press RIGHT SHIFT to open the Blue Client menu.",
      "Drag a server by the grip on its left edge to reorder your list.",
      "Save your whole config as a share code from the modules menu.",
      "Hold a HUD element in the HUD editor to scale it.",
      "Blue Client users show a logo next to their name in tab.",
      "Change your theme in Settings: Black, Glass or White."
   };

   /** Address of the server currently being connected to, or null. */
   private static volatile String address = null;

   /** When the current connection attempt started, for the animations. */
   private static volatile long startedAtMs = 0L;

   private BlueConnectOverlay() {
   }

   /** Records the server being dialled. Called from ConnectScreen.connect. */
   public static void arm(String serverAddress) {
      address = serverAddress;
      startedAtMs = System.currentTimeMillis();
   }

   /** True when the custom screen should replace the vanilla one. */
   public static boolean shouldRender() {
      return address != null && BlueBrand.isBlueNetwork(address);
   }

   /** Clears the armed address once the attempt is over. */
   public static void disarm() {
      address = null;
   }

   /**
    * Draws the whole screen.
    *
    * @param status the live vanilla status line, may be null
    */
   public static void render(DrawContext context, String status) {
      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();
      ThemePalette p = ThemeManager.palette();
      long elapsed = System.currentTimeMillis() - startedAtMs;

      /* ---- backdrop: brand gradient ---- */
      context.fill(0, 0, width, height, DesignTokens.scrim());
      for (int i = 0; i < height; i++) {
         // A subtle accent wash that fades out towards the bottom.
         float t = 1.0F - (i / (float) Math.max(1, height));
         int a = (int) (46 * t * t);
         if (a > 0) {
            context.fill(0, i, width, i + 1, (a << 24) | (DesignTokens.accent() & 0xFFFFFF));
         }
      }

      // Use the EXACT float centre. The old code did `width / 2` (integer
      // division) and then subtracted a width that interTextWidth() had
      // already rounded UP with ceil(). Two roundings in the same expression,
      // both biased the same way, is what made "Joining Blue Network" sit
      // visibly left of centre. centreText() below does it in one step.
      float cx = width / 2.0F;
      int cy = height / 2;

      /* ---- logo ---- */
      int logoH = Math.min(96, Math.max(48, height / 6));
      int logoW = (int) (logoH * (532.0F / 800.0F));   // source art is 532x800
      // Gentle float so the screen never looks frozen on a slow connection.
      int bob = (int) (Math.sin(elapsed / 600.0) * 2.0);
      int logoX = Math.round(cx - logoW / 2.0F);
      context.drawTexturedQuad(LOGO, logoX, cy - logoH - 40 + bob,
         logoX + logoW, cy - 40 + bob, 0.0F, 1.0F, 0.0F, 1.0F);

      /* ---- title ---- */
      String title = "BLUE NETWORK";
      centreText(context, title, cx, cy - 26, p.textHi(), 18.0F);

      /* ---- status line ---- */
      String line = status == null || status.isBlank() ? "Connecting..." : status;
      centreText(context, line, cx, cy + 2, p.textMid(), 10.0F);

      /* ---- indeterminate progress bar ---- */
      int barW = Math.min(280, width - 80);
      int barX = Math.round(cx - barW / 2.0F);
      int barY = cy + 22;
      SmoothRect.fill(context, barX, barY, barW, 4, 2.0F, ThemePalette.withAlpha(p.textMid(), 40));
      /*
       * We cannot know real progress, so this is a "knight rider" sweep: a
       * short segment eased back and forth. It communicates "still working"
       * without ever implying a percentage.
       */
      float phase = (elapsed % 1600L) / 1600.0F;
      float eased = (float) (0.5 - 0.5 * Math.cos(phase * Math.PI * 2.0));
      int segW = Math.max(30, barW / 4);
      int segX = barX + (int) ((barW - segW) * eased);
      SmoothRect.fill(context, segX, barY, segW, 4, 2.0F, p.accent());

      /* ---- player count, when we know it ---- */
      int online = NetworkStats.onlineCount();
      if (online > 0) {
         String players = online + " players online right now";
         centreText(context, players, cx, barY + 14, p.textMid(), 8.0F);
      }

      /* ---- address ---- */
      String addr = address == null ? "" : address;
      centreText(context, addr, cx, height - 52,
         ThemePalette.withAlpha(p.textMid(), 160), 8.0F);

      /* ---- rotating tip ---- */
      String tip = "TIP  ·  " + TIPS[(int) ((elapsed / 4000L) % TIPS.length)];
      centreText(context, tip, cx, height - 34, p.textMid(), 8.0F);
   }

   /**
    * Draws text horizontally centred on {@code centreX}.
    *
    * <p>Measures with the SAME font it draws with (Poppins), at full float
    * precision, and rounds only once at the very end. Measuring with one
    * metric and drawing with another - which is what the old
    * {@code interTextWidth} + {@code drawPoppinsShadow} pairing did - is the
    * classic way to get text that is almost, but not quite, centred.</p>
    */
   private static void centreText(DrawContext context, String text, float centreX,
                                  float y, int color, float size) {
      if (text == null || text.isEmpty()) {
         return;
      }
      float w = RenderUtil.popinsWidth(text, size);
      RenderUtil.drawPoppinsShadow(context, text, Math.round(centreX - w / 2.0F),
         y, color, size);
   }
}
