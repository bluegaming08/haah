package net.bluenetwork.client.optimization;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;

/**
 * RenderCache (Performance Charter §0.2, engine piece 3) — memoization for
 * repeated, allocation-heavy measures on the render path. Today that is text
 * width measurement (the legacy helper built a {@code Text.literal(...)} object
 * for every measurement, every frame — garbage churn). This cache measures
 * plain strings directly and remembers the widths, so per-frame width queries
 * are map hits with zero string/Text allocation.
 *
 * <p>Surfaces themselves are not GPU-cached here yet (FBO layer reserved for
 * later); the geometry/value cache lands first because it is risk-free.</p>
 */
public final class RenderCache {
   private static final int MAX_ENTRIES = 1024;
   private static final Map<String, Integer> WIDTHS = new LinkedHashMap<>(128, 0.75F, true) {
      @Override
      protected boolean removeEldestEntry(Map.Entry<String, Integer> eldest) {
         return size() > MAX_ENTRIES;
      }
   };

   private RenderCache() {
   }

   /** Cached MC text-renderer width for a plain string (no Text allocation). */
   public static int textWidth(String text) {
      if (text == null || text.isEmpty()) {
         return 0;
      }
      Integer cached = WIDTHS.get(text);
      if (cached != null) {
         return cached;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      int width = 0;
      if (mc != null && mc.textRenderer != null) {
         width = mc.textRenderer.getWidth(text);
      }
      WIDTHS.put(text, width);
      return width;
   }

   /** Clear all cached measurements (font scale / resource reload). */
   public static void clear() {
      WIDTHS.clear();
   }

   public static int size() {
      return WIDTHS.size();
   }
}
