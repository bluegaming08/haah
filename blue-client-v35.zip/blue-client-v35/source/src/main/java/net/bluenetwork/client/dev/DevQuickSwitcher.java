package net.bluenetwork.client.dev;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.event.KeyEvent;
import net.bluenetwork.client.gui.AccountsScreen;
import net.bluenetwork.client.gui.ClientSettingsScreen;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextEffect;
import net.minecraft.client.MinecraftClient;

/**
 * Dev-only screen switcher / appearance cycler (Phase 0 + 1). Active only when
 * the client was launched with {@code -Dblueclient.dev=true}.
 *
 * <ul>
 *   <li>F6 — Modules menu (ModuleMenuScreen) [needs to be in a world]</li>
 *   <li>F7 — Client Settings</li>
 *   <li>F8 — Accounts</li>
 *   <li>F9 — cycle global text effect (Shadow &amp; Glow → Shadow → None)</li>
 *   <li>F10 — cycle glass level (Glass → Matte → Flat)</li>
 * </ul>
 *
 * GLFW key codes: F1..F12 are 290..301.
 */
public final class DevQuickSwitcher {
   private static final int F6 = 295;
   private static final int F7 = 296;
   private static final int F8 = 297;
   private static final int F9 = 298;
   private static final int F10 = 299;

   private DevQuickSwitcher() {
   }

   public static void install(BlueClient blue) {
      blue.eventBus().subscribe(KeyEvent.class, event -> {
         if (!DevFlags.enabled() || event.action() != 1) {
            return;
         }
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc == null) {
            return;
         }
         switch (event.key()) {
            case F6 -> {
               if (mc.player != null) {
                  mc.setScreen(new net.bluenetwork.client.ui.screen.ModuleMenuScreen(blue));
               }
            }
            case F7 -> mc.setScreen(new ClientSettingsScreen(mc.currentScreen));
            case F8 -> mc.setScreen(new AccountsScreen(mc.currentScreen));
            case F9 -> cycleTextEffect(blue);
            case F10 -> cycleGlassLevel(blue);
            default -> {
            }
         }
      });
   }

   private static void cycleTextEffect(BlueClient blue) {
      TextEffect[] all = TextEffect.values();
      TextEffect next = all[(blue.settings().textEffect().ordinal() + 1) % all.length];
      blue.settings().textEffect(next);
      BlueClient.LOGGER.info("[Dev] text effect -> {}", next.name());
   }

   private static void cycleGlassLevel(BlueClient blue) {
      GlassSurface[] all = GlassSurface.values();
      GlassSurface next = all[(blue.settings().glassLevel().ordinal() + 1) % all.length];
      blue.settings().glassLevel(next);
      BlueClient.LOGGER.info("[Dev] glass level -> {}", next.name());
   }
}
