package net.bluenetwork.client.mixin;

import net.bluenetwork.client.optimization.PerformanceOptimizer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Entity culling for PerformanceOptimizer: while culling is enabled,
 * entities beyond the configured distance are skipped entirely instead of
 * being frustum-checked and rendered.
 */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity> {
   @Inject(
      method = "shouldRender",
      at = @At("HEAD"),
      cancellable = true
   )
   private void blueclient$cullDistant(T entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
      if (PerformanceOptimizer.isEntityCullingEnabled()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null && entity != mc.player) {
            double dx = entity.getX() - mc.player.getX();
            double dy = entity.getY() - mc.player.getY();
            double dz = entity.getZ() - mc.player.getZ();
            double cull = PerformanceOptimizer.getCullDistance();
            if (dx * dx + dy * dy + dz * dz > cull * cull) {
               cir.setReturnValue(false);
            }
         }
      }
   }
}
