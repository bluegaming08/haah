package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.settings.ClientSettings;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Backs the Settings &gt; Performance &gt; Render Resolution preset. The preset
 * forces the window GUI scale factor (1x potato ... 4x "4K class"), which is
 * what every screen, font atlas and widget rasterises at - so the whole
 * interface genuinely renders at higher or lower pixel density.
 */
@Mixin({Window.class})
public abstract class WindowMixin {
   @Inject(
      method = {"calculateScaleFactor(IZ)I"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void blueclient$resolutionPreset(int guiScale, boolean forceUnicodeFont, CallbackInfoReturnable<Integer> cir) {
      // v0.16.8: the vanilla GUI Scale option always wins. The Blue Client
      // resolution preset only applies while the player's GUI Scale is set
      // to Auto (0) - changing the vanilla setting used to be completely
      // ignored, which read as "my GUI Scale is broken".
      if (guiScale != 0) {
         return;
      }
      try {
         BlueClient blue = BlueClient.getInstance();
         if (blue == null) {
            return;
         }
         int override = ClientSettings.RESOLUTION_SCALE[blue.settings().renderScale()];
         if (override > 0) {
            cir.setReturnValue(override);
         }
      } catch (Throwable ignored) {
      }
   }
}
