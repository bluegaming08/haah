package net.bluenetwork.client.account;

public record Account(String type, String username, String uuid, String accessToken, String refreshToken, String xuid) {
   public boolean isMicrosoft() {
      return "msa".equals(this.type);
   }
}
