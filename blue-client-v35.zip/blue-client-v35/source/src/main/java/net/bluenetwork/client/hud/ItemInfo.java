package net.bluenetwork.client.hud;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;

/**
 * Turns an {@link ItemStack} into the short lines the Item Hold Display shows.
 *
 * <p>Kept separate from the HUD module on purpose: extracting item facts and
 * drawing a panel are different jobs, and this half is the part worth reading
 * in isolation. The module decides <i>when</i> and <i>where</i> to draw; this
 * decides <i>what</i> the text says.</p>
 *
 * <h2>Why the result is a snapshot</h2>
 * The lines are built <b>once</b> when the player switches slots, not every
 * frame. Enchantment names go through the translation system and potion
 * durations format text, which are far too expensive to redo 60+ times a
 * second for a panel whose content cannot change while it is on screen.
 */
public final class ItemInfo {

   /** Ticks per second, for converting potion durations to mm:ss. */
   private static final int TPS = 20;

   private ItemInfo() {
   }

   /**
    * One fully-resolved description of a held item.
    *
    * @param title    the item's display name, e.g. {@code "Diamond Sword"}
    * @param details  short supporting lines (enchantments, duration, count)
    * @param count    stack size, or 1
    * @param damage   current damage, or 0 when not damageable
    * @param maxDamage max durability, or 0 when not damageable
    */
   public record Snapshot(String title, List<String> details, int count,
                          int damage, int maxDamage) {

      public boolean damageable() {
         return this.maxDamage > 0;
      }

      /** @return remaining durability as 0..1, or 1 when not damageable. */
      public float durabilityFraction() {
         if (!this.damageable()) {
            return 1.0F;
         }
         return Math.max(0.0F, Math.min(1.0F,
            (this.maxDamage - this.damage) / (float) this.maxDamage));
      }
   }

   /**
    * Builds the description for a stack.
    *
    * @param stack        the held item
    * @param showCount    include the stack count
    * @param showDurability include "1234 / 1561" for damageable items
    * @param showEnchants include enchantment lines
    * @param maxEnchants  how many enchantment lines at most
    * @param showPotion   include potion effect names
    * @param showDuration include potion durations
    */
   public static Snapshot of(ItemStack stack, boolean showCount, boolean showDurability,
                             boolean showEnchants, int maxEnchants,
                             boolean showPotion, boolean showDuration) {
      List<String> details = new ArrayList<>(4);
      String title = stack.getName().getString();

      int damage = 0;
      int maxDamage = 0;
      if (stack.isDamageable()) {
         damage = stack.getDamage();
         maxDamage = stack.getMaxDamage();
      }

      // --- potions -------------------------------------------------------
      // A potion's real identity is its effect, so that is promoted to the
      // title: "Strength II" reads better than "Potion of Strength".
      PotionContentsComponent potion = stack.get(DataComponentTypes.POTION_CONTENTS);
      if (showPotion && potion != null) {
         boolean firstEffect = true;
         for (StatusEffectInstance effect : potion.getEffects()) {
            String name = effect.getEffectType().value().getName().getString();
            String level = romanLevel(effect.getAmplifier() + 1);
            String label = level.isEmpty() ? name : name + " " + level;
            if (firstEffect) {
               title = label;
               firstEffect = false;
               if (showDuration && effect.getDuration() > 0) {
                  details.add(formatDuration(effect.getDuration()) + " remaining");
               }
            } else {
               details.add(showDuration && effect.getDuration() > 0
                  ? label + " (" + formatDuration(effect.getDuration()) + ")"
                  : label);
            }
         }
      }

      // --- enchantments ---------------------------------------------------
      if (showEnchants && maxEnchants > 0) {
         ItemEnchantmentsComponent enchants = stack.getEnchantments();
         if (enchants != null && !enchants.isEmpty()) {
            int shown = 0;
            int total = enchants.getSize();
            for (RegistryEntry<Enchantment> entry : enchants.getEnchantments()) {
               if (shown >= maxEnchants) {
                  break;
               }
               int level = enchants.getLevel(entry);
               details.add(Enchantment.getName(entry, level).getString());
               shown++;
            }
            // Never silently hide enchantments - say how many were cut.
            if (total > shown) {
               details.add("+" + (total - shown) + " more");
            }
         }
      }

      // --- durability ------------------------------------------------------
      if (showDurability && maxDamage > 0) {
         details.add((maxDamage - damage) + " / " + maxDamage);
      }

      // --- count ------------------------------------------------------------
      // Only meaningful for real stacks; "1 remaining" is noise.
      int count = stack.getCount();
      if (showCount && count > 1) {
         details.add(count + " remaining");
      }

      return new Snapshot(title, List.copyOf(details), count, damage, maxDamage);
   }

   /** Formats a tick duration as {@code m:ss}, e.g. {@code 1:30}. */
   public static String formatDuration(int ticks) {
      int seconds = Math.max(0, ticks / TPS);
      return (seconds / 60) + ":" + String.format("%02d", seconds % 60);
   }

   /**
    * Roman numeral for an item/effect level.
    *
    * <p>Level 1 returns {@code ""} because Minecraft writes "Sharpness",
    * not "Sharpness I". Above 10 it falls back to digits rather than
    * producing an unreadable string of Xs.</p>
    */
   public static String romanLevel(int level) {
      return switch (level) {
         case 1 -> "";
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         case 6 -> "VI";
         case 7 -> "VII";
         case 8 -> "VIII";
         case 9 -> "IX";
         case 10 -> "X";
         default -> level <= 0 ? "" : String.valueOf(level);
      };
   }
}
