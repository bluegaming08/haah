package net.bluenetwork.client.hud.impl;

import java.util.List;
import net.bluenetwork.client.hud.ItemInfo;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

/**
 * Item Hold Display — briefly shows what you just switched to.
 *
 * <p>When you change hotbar slot, a small panel fades in with the item's name
 * and the few facts that actually matter for it: enchantments on a sword,
 * duration on a potion, remaining count on pearls. It fades out on its own.</p>
 *
 * <h2>Positioning</h2>
 * This is a {@link HudModule}, so it uses the <b>existing HUD editor</b> —
 * drag it anywhere, scale it, restyle it, exactly like every other HUD element.
 * A separate positioning system would have been a second thing to learn for no
 * benefit. The {@code Position} setting is a convenience that jumps the panel
 * to a common spot; choosing {@code Custom} (or simply dragging it in the HUD
 * editor) leaves your own placement alone.
 *
 * <h2>Rapid switching</h2>
 * Scrolling Sword → Pearl → Rod does <b>not</b> stack three panels. There is
 * exactly one panel; switching slots re-points it at the new item and restarts
 * its timer. That is the whole mechanism — there is no notification queue to
 * overflow.
 *
 * <h2>Performance</h2>
 * The item's text is resolved <b>once per switch</b> into an
 * {@link ItemInfo.Snapshot}, never per frame. Enchantment names go through the
 * translation system and potion durations format strings; doing that every
 * frame for a static panel would be pure waste. While the panel is hidden the
 * render path costs one timestamp comparison.
 */
public class ItemHoldDisplay extends HudModule {

   /* ----------------------------- settings ----------------------------- */

   private final NumberSetting duration = new NumberSetting("Display duration",
      "How long the panel stays on screen (seconds)", 2.5, 0.5, 10.0, 0.5);
   private final ModeSetting position = new ModeSetting("Position",
      "Where the panel appears. Custom keeps wherever you dragged it in the HUD editor.",
      List.of("Center", "Top Center", "Bottom Center", "Custom"), "Bottom Center");
   private final NumberSetting scale = new NumberSetting("Scale",
      "Panel size (%)", 100.0, 50.0, 200.0, 5.0);
   private final BooleanSetting showIcon = new BooleanSetting("Show item icon",
      "Draw the item's sprite next to the text", true);
   private final BooleanSetting showName = new BooleanSetting("Show item name",
      "Draw the item's name", true);
   private final BooleanSetting showCount = new BooleanSetting("Show count",
      "Show how many you have when holding a stack", true);
   private final BooleanSetting showDurability = new BooleanSetting("Show durability",
      "Show remaining durability for tools, weapons and armor", true);
   private final BooleanSetting showEnchants = new BooleanSetting("Show enchantments",
      "List enchantments on the item", true);
   private final NumberSetting maxEnchants = new NumberSetting("Max enchantments",
      "Most enchantment lines to show before summarising the rest", 3.0, 1.0, 8.0, 1.0);
   private final BooleanSetting showPotion = new BooleanSetting("Show potion effects",
      "Show the effect name for potions", true);
   private final BooleanSetting showPotionDuration = new BooleanSetting("Show potion duration",
      "Show how long a potion's effect lasts", true);
   private final ModeSetting animation = new ModeSetting("Animation",
      "How the panel appears and disappears",
      List.of("Fade", "Slide", "Scale", "None"), "Fade");
   private final NumberSetting animationSpeed = new NumberSetting("Animation speed",
      "Length of the in/out animation (milliseconds)", 180.0, 50.0, 600.0, 10.0);

   /* ------------------------------ state ------------------------------- */

   /** The item description currently being shown, or null when hidden. */
   private volatile ItemInfo.Snapshot shown = null;

   /** When the current panel was triggered. */
   private volatile long shownAtMs = 0L;

   /** Slot we last reacted to, so we only rebuild on an actual change. */
   private int lastSlot = -1;

   /** Identity of the last stack, to catch item changes within one slot. */
   private ItemStack lastStack = ItemStack.EMPTY;

   /** Cached panel size, recomputed with the text rather than per frame. */
   private int panelW = 80;
   private int panelH = 24;

   public ItemHoldDisplay() {
      super("Item Hold Display", "Briefly shows details of the item you switch to",
         Category.HUD, 0, 0);
      this.addSettings(new Setting[]{
         this.duration, this.position, this.scale, this.showIcon, this.showName,
         this.showCount, this.showDurability, this.showEnchants, this.maxEnchants,
         this.showPotion, this.showPotionDuration, this.animation, this.animationSpeed
      });
      this.maxEnchants.visibleWhen(this.showEnchants::get);
      this.showPotionDuration.visibleWhen(this.showPotion::get);
      this.animationSpeed.visibleWhen(() -> !"None".equals(this.animation.get()));
      // Applying the preset on change keeps the dropdown honest: pick
      // "Top Center" and the panel moves immediately.
      this.position.onChange(this::applyPositionPreset);
      this.setAnchorAndOffsets(Anchor.BOTTOM_LEFT, 0, 60);
   }

   @Override
   protected void onDisable() {
      // Do not leave a panel frozen on screen when the module is turned off.
      this.shown = null;
      this.lastSlot = -1;
      this.lastStack = ItemStack.EMPTY;
   }

   /** Moves the panel to the chosen preset spot. "Custom" is left alone. */
   private void applyPositionPreset() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.getWindow() == null) {
         return;
      }
      int screenW = mc.getWindow().getScaledWidth();
      int screenH = mc.getWindow().getScaledHeight();
      int w = Math.max(1, this.panelW);
      switch (this.position.get()) {
         case "Center" -> this.setAnchorAndOffsets(Anchor.TOP_LEFT,
            Math.max(0, (screenW - w) / 2), Math.max(0, screenH / 2 - 40));
         case "Top Center" -> this.setAnchorAndOffsets(Anchor.TOP_LEFT,
            Math.max(0, (screenW - w) / 2), 24);
         case "Bottom Center" -> this.setAnchorAndOffsets(Anchor.BOTTOM_LEFT,
            Math.max(0, (screenW - w) / 2), 60);
         default -> {
            // "Custom": the user's HUD-editor placement wins.
         }
      }
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null) {
         return;
      }
      int slot = mc.player.getInventory().getSelectedSlot();
      ItemStack stack = mc.player.getInventory().getSelectedStack();

      // Trigger on a slot change, or when the stack in this slot becomes a
      // different item (e.g. the last pearl is thrown and a rod slides in).
      boolean slotChanged = slot != this.lastSlot;
      boolean itemChanged = !ItemStack.areItemsEqual(stack, this.lastStack);
      if (slotChanged || itemChanged) {
         this.lastSlot = slot;
         this.lastStack = stack.copy();
         if (stack.isEmpty()) {
            this.shown = null;             // nothing useful to say about air
         } else {
            this.show(stack);
         }
      }

      // Expire the panel once its time is up.
      ItemInfo.Snapshot current = this.shown;
      if (current != null && this.elapsed() > this.totalVisibleMs()) {
         this.shown = null;
      }
   }

   /** Resolves the item's text once and (re)starts the display timer. */
   private void show(ItemStack stack) {
      ItemInfo.Snapshot snap = ItemInfo.of(stack,
         this.showCount.get(), this.showDurability.get(),
         this.showEnchants.get(), this.maxEnchants.getInt(),
         this.showPotion.get(), this.showPotionDuration.get());
      this.shown = snap;
      this.shownAtMs = System.currentTimeMillis();
      this.measure(snap);
      // Re-centre presets against the new width so the panel stays centred.
      if (!"Custom".equals(this.position.get())) {
         this.applyPositionPreset();
      }
   }

   private long elapsed() {
      return System.currentTimeMillis() - this.shownAtMs;
   }

   private long totalVisibleMs() {
      return (long) (this.duration.get() * 1000.0);
   }

   /** Measures the panel for the given text. Called on switch, not per frame. */
   private void measure(ItemInfo.Snapshot snap) {
      int widest = 0;
      if (this.showName.get()) {
         widest = RenderUtil.textWidth(snap.title());
      }
      for (String line : snap.details()) {
         widest = Math.max(widest, RenderUtil.textWidth(line));
      }
      int iconSpace = this.showIcon.get() ? 20 : 0;
      this.panelW = Math.max(60, widest + 16 + iconSpace);

      int lines = (this.showName.get() ? 1 : 0) + snap.details().size();
      this.panelH = Math.max(this.showIcon.get() ? 26 : 16, 8 + Math.max(1, lines) * 10);
   }

   /**
    * Animation progress as 0..1 — 0 fully hidden, 1 fully shown.
    *
    * <p>Eases in at the start and out at the end. Both halves are clamped to
    * at most a third of the total display time, so a short duration with a
    * long animation still spends most of its life fully visible instead of
    * permanently mid-fade (the bug that made the music lyrics look dim).</p>
    */
   private float progress() {
      if ("None".equals(this.animation.get())) {
         return 1.0F;
      }
      long total = this.totalVisibleMs();
      long age = this.elapsed();
      float anim = Math.min(this.animationSpeed.getFloat(), total / 3.0F);
      if (anim <= 1.0F) {
         return 1.0F;
      }
      float in = Math.min(1.0F, age / anim);
      float out = Math.min(1.0F, Math.max(0.0F, total - age) / anim);
      return Math.max(0.0F, Math.min(in, out));
   }

   @Override
   public void render(DrawContext context) {
      ItemInfo.Snapshot snap = this.shown;
      if (snap == null) {
         return;                            // hidden: one null check per frame
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null) {
         return;
      }
      float t = this.progress();
      if (t <= 0.01F) {
         return;
      }

      String mode = this.animation.get();
      float userScale = (float) (this.scale.get() / 100.0);
      // "Scale" eases size as well as opacity; the others stay full size.
      float animScale = "Scale".equals(mode) ? (0.88F + 0.12F * t) : 1.0F;
      // "Slide" drifts up into place rather than appearing in position.
      float slideY = "Slide".equals(mode) ? (1.0F - t) * 8.0F : 0.0F;
      float alpha = "Scale".equals(mode) || "Fade".equals(mode) ? t : 1.0F;
      if ("Slide".equals(mode)) {
         alpha = t;                          // slide still fades, or it pops
      }

      float total = userScale * animScale;
      int cx = this.x + this.panelW / 2;
      int cy = this.y + this.panelH / 2;

      context.getMatrices().pushMatrix();
      context.getMatrices().translate(cx, cy + slideY);
      context.getMatrices().scale(total, total);
      context.getMatrices().translate(-cx, -cy);

      this.drawPanel(context, this.panelW, this.panelH);

      int textX = this.x + 8;
      if (this.showIcon.get() && !this.lastStack.isEmpty()) {
         context.drawItem(this.lastStack, this.x + 5, this.y + (this.panelH - 16) / 2);
         textX += 20;
      }

      int alphaBits = ((int) (alpha * 255.0F) & 0xFF) << 24;
      int y = this.y + 5;
      if (this.showName.get()) {
         RenderUtil.drawText(context, snap.title(), textX, y,
            alphaBits | (this.previewTextColor() & 0xFFFFFF));
         y += 10;
      }
      for (String line : snap.details()) {
         RenderUtil.drawText(context, line, textX, y, alphaBits | 0xB8C4D4);
         y += 10;
      }

      context.getMatrices().popMatrix();
   }

   @Override
   public int getWidth() {
      return this.panelW;
   }

   @Override
   public int getHeight() {
      return this.panelH;
   }
}
