package net.bluenetwork.client.brand;

import com.sun.jna.Library;
import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import org.lwjgl.glfw.GLFWNativeWin32;

/**
 * The JNA-dependent half of {@link WindowStyle}. Only loaded after
 * {@code WindowStyle.isJnaAvailable()} confirms JNA is on the classpath, so
 * this class (and the JNA imports) never link when another mod provides no
 * JNA — the dark titlebar simply stays off instead of throwing.
 */
final class WindowStyleJna {
   private WindowStyleJna() {
   }

   static void setDarkTitleBar(long hwnd) {
      DwmLibrary dwm = (DwmLibrary) Native.load("dwmapi", DwmLibrary.class);
      Pointer hwndPointer = new Pointer(hwnd);
      Memory value = new Memory(4L);
      value.setInt(0L, 1); // TRUE = dark mode attribute
      // 20 = DWMWA_USE_IMMERSIVE_DARK_MODE (Win11+); fall back to 19 (Win10 20H1+)
      int result = dwm.DwmSetWindowAttribute(hwndPointer, 20, value, 4);
      if (result != 0) {
         dwm.DwmSetWindowAttribute(hwndPointer, 19, value, 4);
      }
   }

   private interface DwmLibrary extends Library {
      int DwmSetWindowAttribute(Pointer var1, int var2, Pointer var3, int var4);
   }
}
