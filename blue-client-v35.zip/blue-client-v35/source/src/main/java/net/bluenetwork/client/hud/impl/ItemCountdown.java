package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public class ItemCountdown extends HudModule {
   public ItemCountdown() {
      super("Item Countdown", "Durability percent on held item", Category.HUD, 0, 0);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity player = mc.player;
      if (player != null) {
         ItemStack held = player.getMainHandStack();
         if (!held.isEmpty() && held.isDamageable()) {
            int maxDamage = held.getMaxDamage();
            int damage = held.getDamage();
            int percent = (int)(100L - damage * 100L / maxDamage);
            String text = percent + "%";
            int x = mc.getWindow().getScaledWidth() / 2 - 91 + 36;
            int y = mc.getWindow().getScaledHeight() - 36;
            int color = percent > 50 ? BlueColors.TEXT_PRIMARY : (percent > 20 ? -10138 : -38294);
            context.drawTextWithShadow(mc.textRenderer, Text.literal(text), x, y, color);
         }
      }
   }

   @Override
   public int getWidth() {
      return 24;
   }

   @Override
   public int getHeight() {
      return 10;
   }

   @Override
   public int getX() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.getWindow().getScaledWidth() / 2 - 91 + 36;
   }

   @Override
   public int getY() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.getWindow().getScaledHeight() - 36;
   }
}
