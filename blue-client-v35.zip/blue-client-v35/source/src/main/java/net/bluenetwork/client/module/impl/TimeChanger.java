package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;

/**
 * Time Changer — pick the time of day you actually want to play in.
 *
 * <h2>Owner spec</h2>
 * <pre>
 *   add a time changer, with presets (day, night, midnight, etc) and also a
 *   freeform slider where i can set the time to whatever i want
 * </pre>
 *
 * <h2>How it works (and why it is safe)</h2>
 * This is <b>client-side only</b>. Minecraft keeps two clocks:
 * <ul>
 *   <li>{@code time} — the world age, used for scheduled ticks.</li>
 *   <li>{@code timeOfDay} — what the sky, sun, moon and light level are
 *       computed from.</li>
 * </ul>
 * We overwrite only the client's copy of {@code timeOfDay} via
 * {@link ClientWorld#setTime(long, long, boolean)}, whose third argument is
 * "should the client keep ticking time forward". We pass {@code false} so our
 * value sticks instead of drifting a tick per tick.
 *
 * <p>The server is never told anything, no packet is sent, and no player
 * movement or combat behaviour changes — an anticheat has nothing to see. It is
 * exactly the same category of change as turning up your gamma. (Do note that
 * on a server the actual mob spawning still follows the SERVER's time; you are
 * only changing what you see.)</p>
 *
 * <p>Because vanilla overwrites {@code timeOfDay} every time the server sends a
 * {@code WorldTimeUpdate} packet, we reapply on every client tick rather than
 * once on enable. That is a single field write per tick — free.</p>
 */
public class TimeChanger extends Module {

   /* Vanilla tick values. Reference: the /time set command.
      day 1000 · noon 6000 · sunset 12000 · night 13000 · midnight 18000 */
   private static final long DAY = 1000L;
   private static final long NOON = 6000L;
   private static final long SUNSET = 12000L;
   private static final long NIGHT = 13000L;
   private static final long MIDNIGHT = 18000L;

   /** One full Minecraft day. */
   private static final long DAY_LENGTH = 24000L;

   private final ModeSetting preset = new ModeSetting("Preset", "Quick time of day",
      List.of("DAY", "NOON", "SUNSET", "NIGHT", "MIDNIGHT", "CUSTOM"), "DAY");

   private final NumberSetting customTicks = new NumberSetting("Custom time",
      "Exact tick of the day (0 - 23999). 0 = sunrise, 6000 = noon, 18000 = midnight",
      6000.0, 0.0, 23999.0, 100.0);

   private final BooleanSetting flow = new BooleanSetting("Let time flow",
      "Keep the clock moving forward from your chosen time instead of freezing it", false);

   /** Ticks added since enable while "Let time flow" is on. */
   private long flowTicks;

   public TimeChanger() {
      super("Time Changer", "Set the client-side time of day (visual only)", Category.RENDER);
      // The slider is only meaningful for the CUSTOM preset.
      this.customTicks.visibleWhen(() -> "CUSTOM".equals(this.preset.get()));
      this.addSettings(new Setting[]{this.preset, this.customTicks, this.flow});
   }

   @Override
   protected void onEnable() {
      this.flowTicks = 0L;
   }

   @Override
   protected void onDisable() {
      // Hand control back to the server: re-enable client time ticking with the
      // world's current value, so the sky snaps back to the real time.
      ClientWorld world = MinecraftClient.getInstance().world;
      if (world != null) {
         world.setTime(world.getTime(), world.getTimeOfDay(), true);
      }
   }

   @Override
   public void onTick() {
      ClientWorld world = MinecraftClient.getInstance().world;
      if (world == null) {
         return;
      }
      if (this.flow.get()) {
         this.flowTicks++;
      }
      long target = Math.floorMod(this.targetTicks() + this.flowTicks, DAY_LENGTH);
      // Third argument false = stop the client advancing timeOfDay itself,
      // otherwise our write would drift by one tick every tick.
      world.setTime(world.getTime(), target, false);
   }

   /** The tick-of-day the current preset asks for. */
   private long targetTicks() {
      return switch (this.preset.get()) {
         case "NOON" -> NOON;
         case "SUNSET" -> SUNSET;
         case "NIGHT" -> NIGHT;
         case "MIDNIGHT" -> MIDNIGHT;
         case "CUSTOM" -> (long) this.customTicks.get().doubleValue();
         default -> DAY;
      };
   }

   /** Convenience for other code / the HUD: is a time override active right now? */
   public static boolean active() {
      Module module = BlueClient.getInstance().moduleManager().byName("Time Changer");
      return module != null && module.isEnabled();
   }
}
