package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

/**
 * Nametags (v0.19.0) — richer nametags:
 *
 * <ul>
 *   <li><b>Show own nametag</b>: vanilla never draws YOUR name above your own
 *       head (the renderer hard-codes {@code entity == cameraEntity → no
 *       label}); this forces it on while you are in third person (F5).</li>
 *   <li><b>Client logo</b>: the Blue badge renders on the LEFT side of
 *       Blue-Client nametags (and on your own), instead of after the name.</li>
 *   <li><b>More info</b>: optional health (❤ 20/20) and ping (as in tab) are
 *       appended to player nametags.</li>
 * </ul>
 */
public class Nametags extends Module {
   private final BooleanSetting showOwn = new BooleanSetting("Show own nametag", "Draw your name above your own head in third person (F5)", true);
   private final BooleanSetting showHealth = new BooleanSetting("Show health", "Append player health to nametags", false);
   private final BooleanSetting showPing = new BooleanSetting("Show ping", "Append player ping to nametags", false);

   public Nametags() {
      super("Nametags", "Own nametag, left-side client logo and extra info on tags", Category.RENDER);
      this.addSettings(new Setting[]{this.showOwn, this.showHealth, this.showPing});
   }

   /** True when your own nametag should render (third person only). */
   public static boolean ownNametag() {
      Module m = BlueClient.getInstance().moduleManager().byName("Nametags");
      if (!(m instanceof Nametags n) || !m.isEnabled() || !n.showOwn.get()) {
         return false;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc != null && mc.player != null && !mc.options.getPerspective().isFirstPerson();
   }

   /**
    * True when the badge goes before the name.
    *
    * @deprecated v0.24.2 - the side now lives on the Blue Logo module so the
    *     tab list and nametags always agree. Kept as a delegate so existing
    *     call sites keep working.
    */
   @Deprecated
   public static boolean logoOnLeft() {
      return BlueLogo.logoOnLeft();
   }

   /** Builds the "more info" suffix (health / ping) for a player nametag. */
   public static String infoSuffix(net.minecraft.entity.player.PlayerEntity viewOf) {
      Module m = BlueClient.getInstance().moduleManager().byName("Nametags");
      if (!(m instanceof Nametags n) || !m.isEnabled()) {
         return "";
      }
      StringBuilder sb = new StringBuilder();
      if (n.showHealth.get() && viewOf != null) {
         int hp = Math.round(viewOf.getHealth() + viewOf.getAbsorptionAmount());
         int max = Math.round(viewOf.getMaxHealth() + viewOf.getAbsorptionAmount());
         sb.append(" ❤ ").append(hp).append('/').append(max);
      }
      if (n.showPing.get() && viewOf != null) {
         int ping = 0;
         try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null && mc.player.networkHandler != null) {
               var entry = mc.player.networkHandler.getPlayerListEntry(viewOf.getUuid());
               if (entry != null) {
                  ping = entry.getLatency();
               }
            }
         } catch (Throwable ignored) {
         }
         sb.append(" ⛭ ").append(ping).append("ms");
      }
      return sb.toString();
   }
}
