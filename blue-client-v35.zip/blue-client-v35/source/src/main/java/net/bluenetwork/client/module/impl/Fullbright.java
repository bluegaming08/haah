package net.bluenetwork.client.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.text.Text;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Fullbright — real lightmap boost. The gamma option in 1.21.11 is validated to
 * 0.0–1.0, so the module can no longer write 16.0 into the option; instead the
 * LightmapTextureManager mixin swaps the gamma read for our unbounded option
 * while the module is on (see LightmapTextureManagerMixin). Brightness is
 * adjustable and restored by simply turning the module off.
 */
public class Fullbright extends Module
      implements net.bluenetwork.client.module.AdjustableModule {
   private static volatile boolean on = false;
   private static SimpleOption<Double> bright;
   /** Latches when the JVM refuses the reflection, so we try exactly once. */
   private static volatile boolean unsupported = false;

   private final NumberSetting brightness = new NumberSetting("Brightness", "Boost level (16 = fullbright)", 16.0, 1.0, 16.0, 1.0);

   /*
    * Adjustment hotkeys. Stored as GLFW key codes in settings rather than as
    * real keybinds, because the module system gives a module exactly one bind
    * and brightness needs three (toggle, up, down).
    *
    * Default to 0 = unbound: a client must never silently claim keys the
    * player already uses for something else.
    */
   private final NumberSetting keyUp = new NumberSetting("Key: Brighter",
      "GLFW key code to raise brightness. 0 = unbound.", 0.0, 0.0, 400.0, 1.0);
   private final NumberSetting keyDown = new NumberSetting("Key: Darker",
      "GLFW key code to lower brightness. 0 = unbound.", 0.0, 0.0, 400.0, 1.0);
   private final NumberSetting step = new NumberSetting("Key Step",
      "How much each key press changes brightness", 1.0, 0.5, 4.0, 0.5);

   public Fullbright() {
      super("Fullbright", "Maximum brightness - see in the dark.", Category.RENDER);
      this.addSettings(new Setting[]{this.brightness, this.keyUp, this.keyDown,
         this.step});
   }

   @Override
   protected void onEnable() {
      on = true;
   }

   @Override
   protected void onDisable() {
      on = false;
   }

   /** True while the module is enabled — read by the lightmap mixin every frame. */
   public static boolean isBright() {
      return on;
   }

   /**
    * The boosted gamma option handed to the lightmap while on.
    *
    * <p>Returns {@code null} if the option could not be built, in which case
    * the mixin quietly falls back to the vanilla gamma. Fullbright is a
    * convenience feature; it must never be able to stop the game.</p>
    */
   public static SimpleOption<Double> brightGamma() {
      if (!on || unsupported) {
         return null;
      }
      SimpleOption<Double> option = ensure();
      if (option == null) {
         return null;
      }
      Fullbright module = current();
      double value = module != null ? module.brightness.get() : 16.0;
      try {
         if (Math.abs(option.getValue() - value) > 0.001) {
            option.setValue(value);
         }
      } catch (Throwable t) {
         // A validated option can reject a write. Not fatal - use what we have.
         BlueClient.LOGGER.debug("[Fullbright] could not update gamma value", t);
      }
      return option;
   }

   private static Fullbright current() {
      try {
         Module module = BlueClient.getInstance().moduleManager().byName("Fullbright");
         if (module instanceof Fullbright fullbright) {
            return fullbright;
         }
      } catch (Throwable ignored) {
      }
      return null;
   }

   /**
    * Builds the unbounded gamma option, once.
    *
    * <h2>Why this is written with reflection</h2>
    * {@code SimpleOption.Callbacks} is package-private, so the obvious way to
    * implement it is to put a class in {@code net.minecraft.client.option} and
    * let the split package grant access. That is what v20 did, and on
    * <b>Java 27</b> it crashed the game the instant a world loaded:
    *
    * <pre>
    * java.lang.IllegalAccessError: class BlueBrightCallbacks cannot access
    * its superinterface net.minecraft.class_7172$class_7178
    * </pre>
    *
    * Fabric's Knot loader defines mod classes and Minecraft classes through
    * different routes, and newer JVMs no longer treat them as the same runtime
    * package. Implementing a package-private interface across that boundary is
    * an illegal access.
    *
    * <p>So we never implement the interface. Instead we take the
    * <b>existing</b> callbacks object out of the vanilla gamma option by
    * reflection and reuse it, then clear the validator's clamp by handing the
    * value straight to the option's backing field. Nothing package-private is
    * subclassed, so there is no cross-package inheritance to reject.</p>
    *
    * <p>If any step fails, {@code unsupported} latches and Fullbright simply
    * stops boosting - the game keeps running with vanilla brightness.</p>
    */
   private static synchronized SimpleOption<Double> ensure() {
      if (bright != null) {
         return bright;
      }
      if (unsupported) {
         return null;
      }
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc == null || mc.options == null) {
            return null;
         }

         // Start from a real, fully constructed gamma option...
         SimpleOption<Double> vanilla = mc.options.getGamma();

         // ...and reuse its callbacks object. SimpleOption exposes a PUBLIC
         // getCallbacks(), so we never name the package-private type in our
         // own signatures - we only ever hold it as Object and hand it back
         // to a Minecraft constructor. No cross-package inheritance, so
         // nothing for the JVM to reject.
         Object callbacks = SimpleOption.class.getMethod("getCallbacks").invoke(vanilla);
         if (callbacks == null) {
            throw new IllegalStateException("gamma option has no callbacks");
         }

         // (String, TooltipFactory, ValueTextGetter, Callbacks, T, Consumer).
         // There is also a 7-arg form that inserts a Codec - match on the
         // parameter types rather than the count so the right one is used.
         Constructor<?> ctor = null;
         for (Constructor<?> c : SimpleOption.class.getDeclaredConstructors()) {
            Class<?>[] pt = c.getParameterTypes();
            if (pt.length == 6 && pt[0] == String.class
               && pt[3].isInstance(callbacks)) {
               ctor = c;
               break;
            }
         }
         if (ctor == null) {
            throw new NoSuchMethodException("SimpleOption 6-arg constructor not found");
         }
         ctor.setAccessible(true);

         @SuppressWarnings("unchecked")
         SimpleOption<Double> built = (SimpleOption<Double>) ctor.newInstance(
            "blueclient.fullbright",
            SimpleOption.emptyTooltip(),
            (SimpleOption.ValueTextGetter<Double>) (option, value) -> Text.literal(""),
            callbacks,
            16.0,
            (Consumer<Double>) value -> {
            });

         // The vanilla callbacks clamp to 0..1, so setValue(16) would be
         // rejected. Write the backing field directly instead - this is the
         // one thing that actually makes it "unbounded".
         writeValue(built, 16.0);

         bright = built;
         BlueClient.LOGGER.info("[Fullbright] unbounded gamma ready");
         return bright;

      } catch (Throwable t) {
         unsupported = true;
         BlueClient.LOGGER.warn(
            "[Fullbright] unsupported on this JVM/mappings - falling back to vanilla brightness", t);
         return null;
      }
   }

   /**
    * Writes straight past the validator into SimpleOption's value field.
    *
    * <p>{@code T value} erases to {@code Object}, and so does
    * {@code T defaultValue} - but defaultValue is <b>final</b>, so "the only
    * non-static, NON-FINAL Object field" identifies the right one without
    * depending on an obfuscated field name.</p>
    */
   private static void writeValue(SimpleOption<Double> option, double value) throws Exception {
      for (Field f : SimpleOption.class.getDeclaredFields()) {
         int mods = f.getModifiers();
         if (f.getType() == Object.class
            && !Modifier.isStatic(mods) && !Modifier.isFinal(mods)) {
            f.setAccessible(true);
            f.set(option, value);
            return;
         }
      }
      // Fall back to the normal path; it may clamp, but it will not throw.
      option.setValue(value);
   }

   @Override
   public int increaseKey() {
      return this.keyUp.getInt();
   }

   @Override
   public int decreaseKey() {
      return this.keyDown.getInt();
   }

   /**
    * Nudges brightness and reports the new value.
    *
    * <p>Turns the module ON if it was off, because pressing "brighter" while
    * Fullbright is disabled and seeing nothing happen would be baffling.</p>
    */
   @Override
   public String adjust(int direction) {
      if (!this.isEnabled()) {
         this.setEnabled(true);
      }
      double next = this.brightness.get() + direction * this.step.get();
      this.brightness.set(next);
      return String.format("Brightness %.1f", this.brightness.get());
   }
}
