package net.bluenetwork.client.hud;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;

/**
 * Premium-pack HUD manager, combined with Blue Client's real module system:
 * - grid snapping drives the existing HUD editor drag (HudEditScreen)
 * - groups are the HUD module categories; toggling a group flips every
 *   HUD module in it - used by the editor's group buttons
 * - per-HUD settings map to the existing HudModule scale support
 */
public final class PremiumHudManager {
   public static final int GRID_SIZE = 5;
   private static final Map<String, Boolean> GROUP_OVERRIDES = new LinkedHashMap<>();

   private PremiumHudManager() {
   }

   public static boolean shouldSnapToGrid() {
      return BlueClient.getInstance().settings().hudGridSnap();
   }

   public static int snap(int value) {
      return Math.round((float)value / GRID_SIZE) * GRID_SIZE;
   }

   /** All HUD modules grouped by category, in registration order. */
   public static Map<String, List<HudModule>> getHudGroups() {
      Map<String, List<HudModule>> groups = new LinkedHashMap<>();
      for (HudModule module : BlueClient.getInstance().moduleManager().getHudModules()) {
         groups.computeIfAbsent(module.getCategory().name(), c -> new ArrayList<>()).add(module);
      }
      return groups;
   }

   public static List<HudModule> getHudGroup(String category) {
      List<HudModule> group = getHudGroups().get(category.toUpperCase());
      return group != null ? group : List.of();
   }

   /** Toggles every HUD module in a group on or off. Returns true if the group is now fully enabled. */
   public static boolean toggleHudGroup(String category) {
      List<HudModule> group = getHudGroup(category);
      boolean anyOff = group.stream().anyMatch(m -> !m.isEnabled());
      for (HudModule module : group) {
         if (!module.isRequired()) {
            module.setEnabled(anyOff);
         }
      }
      GROUP_OVERRIDES.put(category.toUpperCase(), anyOff);
      BlueClient.getInstance().configManager().save();
      return anyOff;
   }

   /** Enables or disables every HUD module across all groups. */
   public static void setAllHud(boolean enabled) {
      for (HudModule module : BlueClient.getInstance().moduleManager().getHudModules()) {
         if (!module.isRequired()) {
            module.setEnabled(enabled);
         }
      }
      BlueClient.getInstance().configManager().save();
   }
}
