package net.bluenetwork.client.recorder;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;
import org.jcodec.api.SequenceEncoder;
import org.jcodec.common.Codec;
import org.jcodec.common.Format;
import org.jcodec.common.io.NIOUtils;
import org.jcodec.common.io.SeekableByteChannel;
import org.jcodec.common.model.ColorSpace;
import org.jcodec.common.model.Picture;
import org.jcodec.common.model.Rational;

/**
 * The video-encoding half of the in-game Screen Recorder.
 *
 * <h2>Design: never block the render thread</h2>
 * <pre>
 *   render thread            encoder thread (this class)
 *   ------------             ---------------------------
 *   submit(argb,w,h)  --->   [bounded queue]  --->  scale + RGB->YUV420  --->  H.264 --->  .mp4
 * </pre>
 * The render thread does one array copy and returns. All the expensive work —
 * downscaling to the target resolution, colour conversion and H.264 encoding —
 * happens on a single daemon worker.
 *
 * <p>The queue is <b>bounded</b> and {@link #submit} <b>drops</b> the frame when
 * it is full. That is the single most important decision in this file: JCodec
 * is a pure-Java encoder and on a slow CPU it simply cannot keep up with 60 fps
 * at 1440p. An unbounded queue would eat every gigabyte of heap and crash the
 * game; blocking would tank the frame rate. Dropping frames makes the video a
 * little choppy and keeps the game smooth, which is the right trade for a
 * "lightweight" recorder. Drops are counted and reported when you stop.</p>
 *
 * <h2>Why JCodec and not FFmpeg</h2>
 * JCodec is a ~700 KB pure-Java jar that ships inside our mod. FFmpeg would be
 * far faster but means shipping (or downloading) a per-OS native binary, which
 * is a launcher-level concern — see {@code README-LAUNCHER.md}.
 *
 * <h2>Output</h2>
 * {@code .minecraft/recordings/blue-YYYY-MM-DD_HH.mm.ss.mp4}
 */
public final class VideoRecorder {

   /** Max frames waiting to be encoded before we start dropping. */
   private static final int QUEUE_CAPACITY = 8;

   /** One frame handed over from the render thread. */
   private record Frame(int[] argb, int width, int height) {
   }

   private final BlockingQueue<Frame> queue = new ArrayBlockingQueue<>(QUEUE_CAPACITY);
   private final AtomicBoolean running = new AtomicBoolean();
   private final AtomicLong encodedFrames = new AtomicLong();
   private final AtomicLong droppedFrames = new AtomicLong();

   private Thread worker;
   private Path outputFile;
   private long startedAtMs;

   /* Encode settings, snapshotted at start() so changing a slider mid-record
      cannot corrupt the stream. */
   private int targetHeight;
   private int fps;

   /* ===================================================================== */
   /* Lifecycle                                                             */
   /* ===================================================================== */

   /** True while a recording is in progress. */
   public boolean isRecording() {
      return this.running.get();
   }

   /** Milliseconds since the recording started, or 0. */
   public long elapsedMs() {
      return this.running.get() ? System.currentTimeMillis() - this.startedAtMs : 0L;
   }

   /** Current size of the output file in bytes (0 if unknown). */
   public long fileSizeBytes() {
      try {
         return this.outputFile != null && Files.exists(this.outputFile) ? Files.size(this.outputFile) : 0L;
      } catch (Exception e) {
         return 0L;
      }
   }

   public long encodedFrames() {
      return this.encodedFrames.get();
   }

   public long droppedFrames() {
      return this.droppedFrames.get();
   }

   public Path outputFile() {
      return this.outputFile;
   }

   /**
    * Starts recording.
    *
    * @param targetHeight output height in pixels (720, 1080, 1440, 2160); the
    *                     width follows the window's aspect ratio
    * @param fps          frames per second written into the container
    * @return true if recording actually started
    */
   public synchronized boolean start(int targetHeight, int fps) {
      if (this.running.get()) {
         return false;
      }
      this.targetHeight = Math.max(240, targetHeight);
      this.fps = Math.max(10, Math.min(60, fps));
      this.encodedFrames.set(0);
      this.droppedFrames.set(0);
      this.queue.clear();

      try {
         Path dir = FabricLoader.getInstance().getGameDir().resolve("recordings");
         Files.createDirectories(dir);
         String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH.mm.ss"));
         this.outputFile = dir.resolve("blue-" + stamp + ".mp4");
      } catch (Exception e) {
         BlueClient.LOGGER.error("Recorder: cannot create the recordings folder", e);
         return false;
      }

      this.running.set(true);
      this.startedAtMs = System.currentTimeMillis();
      this.worker = new Thread(this::encodeLoop, "Blue Client Recorder");
      this.worker.setDaemon(true);
      // Below normal: the game must always win the CPU fight against the encoder.
      this.worker.setPriority(Thread.MIN_PRIORITY);
      this.worker.start();
      return true;
   }

   /** Stops recording and waits (briefly) for the encoder to flush. */
   public synchronized void stop() {
      if (!this.running.getAndSet(false)) {
         return;
      }
      try {
         if (this.worker != null) {
            // Generous: finishing an MP4 means writing the index (moov atom).
            this.worker.join(10_000L);
         }
      } catch (InterruptedException e) {
         Thread.currentThread().interrupt();
      }
      this.worker = null;
   }

   /* ===================================================================== */
   /* Frame intake (render thread)                                          */
   /* ===================================================================== */

   /**
    * Hands one captured frame to the encoder. Called from the render thread —
    * this must stay O(1) and never block.
    *
    * @param argb   pixels in 0xAARRGGBB, row-major, top row first
    * @param width  frame width
    * @param height frame height
    */
   public void submit(int[] argb, int width, int height) {
      if (!this.running.get()) {
         return;
      }
      // offer() returns false instead of blocking when the encoder is behind.
      if (!this.queue.offer(new Frame(argb, width, height))) {
         this.droppedFrames.incrementAndGet();
      }
   }

   /* ===================================================================== */
   /* Encoder thread                                                        */
   /* ===================================================================== */

   private void encodeLoop() {
      SeekableByteChannel channel = null;
      SequenceEncoder encoder = null;
      try {
         channel = NIOUtils.writableFileChannel(new File(this.outputFile.toString()).getAbsolutePath());
         encoder = new SequenceEncoder(channel, Rational.R(this.fps, 1), Format.MOV, Codec.H264, null);

         Picture picture = null;
         while (this.running.get() || !this.queue.isEmpty()) {
            Frame frame = this.queue.poll(200, TimeUnit.MILLISECONDS);
            if (frame == null) {
               continue;
            }
            // H.264 requires even dimensions (chroma is half resolution).
            int outH = even(Math.min(this.targetHeight, frame.height()));
            int outW = even(Math.round(outH * (frame.width() / (float) frame.height())));
            if (picture == null || picture.getWidth() != outW || picture.getHeight() != outH) {
               picture = Picture.create(outW, outH, ColorSpace.YUV420J);
            }
            toYuv420(frame, picture, outW, outH);
            encoder.encodeNativeFrame(picture);
            this.encodedFrames.incrementAndGet();
         }
      } catch (Throwable t) {
         BlueClient.LOGGER.error("Recorder: encoding stopped", t);
      } finally {
         this.running.set(false);
         try {
            if (encoder != null) {
               encoder.finish();
            }
         } catch (Throwable ignored) {
            // Already logged above; a half-written file is better than a crash.
         }
         NIOUtils.closeQuietly(channel);
      }
   }

   private static int even(int v) {
      return v % 2 == 0 ? v : v - 1;
   }

   /**
    * Nearest-neighbour downscale plus BT.601 RGB to YUV 4:2:0 conversion.
    *
    * <p>Two things that are easy to get wrong and cost hours:</p>
    * <ol>
    *   <li>JCodec planes are <b>signed bytes centred on -128</b>, not 0..255.
    *       Every sample must have 128 subtracted.</li>
    *   <li>The chroma planes are <b>quarter size</b> (half width, half height),
    *       so their stride is {@code w / 2}.</li>
    * </ol>
    * Nearest-neighbour rather than a proper filter is a deliberate speed
    * choice: this runs per frame and a box filter roughly triples its cost for
    * a difference nobody notices in a game clip.
    */
   private static void toYuv420(Frame frame, Picture out, int w, int h) {
      int[] src = frame.argb();
      int srcW = frame.width();
      int srcH = frame.height();
      byte[] yPlane = out.getPlaneData(0);
      byte[] uPlane = out.getPlaneData(1);
      byte[] vPlane = out.getPlaneData(2);
      int chromaW = w / 2;

      for (int y = 0; y < h; y++) {
         int sy = y * srcH / h;
         int srcRow = sy * srcW;
         int dstRow = y * w;
         for (int x = 0; x < w; x++) {
            int pixel = src[srcRow + x * srcW / w];
            int r = (pixel >> 16) & 0xFF;
            int g = (pixel >> 8) & 0xFF;
            int b = pixel & 0xFF;

            int luma = (77 * r + 150 * g + 29 * b) >> 8;
            yPlane[dstRow + x] = (byte) (luma - 128);

            // One chroma sample per 2x2 block: only compute it on even pixels.
            if ((x & 1) == 0 && (y & 1) == 0) {
               int cb = ((-43 * r - 85 * g + 128 * b) >> 8) + 128;
               int cr = ((128 * r - 107 * g - 21 * b) >> 8) + 128;
               int ci = (y / 2) * chromaW + (x / 2);
               uPlane[ci] = (byte) (clamp(cb) - 128);
               vPlane[ci] = (byte) (clamp(cr) - 128);
            }
         }
      }
   }

   private static int clamp(int v) {
      return v < 0 ? 0 : Math.min(v, 255);
   }
}
