package net.bluenetwork.client.module.impl;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.Setting;

/**
 * Discord Presence (v0.19.0) — the mod side of the Blue Client launcher's
 * Rich Presence. Every 5 seconds this exports a tiny
 * {@code .blueclient/presence.json} describing what you are doing (title
 * screen / on a server / in singleplayer). The launcher's Discord RPC picks
 * that file up and updates the activity, so presence is accurate without
 * the mod talking to Discord's IPC itself.
 */
public class DiscordPresence extends Module {
   private long lastWrite = 0L;

   public DiscordPresence() {
      super("Discord Presence", "Share your game state with the launcher for Discord Rich Presence", Category.MISC);
   }

   @Override
   public void onTick() {
      long now = System.currentTimeMillis();
      if (now - this.lastWrite < 5000L) {
         return;
      }
      this.lastWrite = now;
      writePresence();
   }

   /** Best-effort presence export; never throws into the tick loop. */
   private void writePresence() {
      try {
         var mc = net.minecraft.client.MinecraftClient.getInstance();
         StringBuilder sb = new StringBuilder("{");
         sb.append("\"client\":\"Blue Client 1.21.11\"");
         long ts = System.currentTimeMillis() / 1000L;
         sb.append(",\"timestamp\":").append(ts);
         if (mc != null && mc.world != null && mc.player != null) {
            sb.append(",\"state\":\"in-game\"");
            String server = "Singleplayer";
            if (mc.getCurrentServerEntry() != null && mc.getCurrentServerEntry().address != null) {
               server = mc.getCurrentServerEntry().address;
            }
            sb.append(",\"server\":\"").append(escape(server)).append("\"");
            String dimension = mc.world.getRegistryKey().getValue().getPath();
            sb.append(",\"dimension\":\"").append(escape(dimension)).append("\"");
            sb.append(",\"username\":\"").append(escape(mc.player.getName().getString())).append("\"");
         } else {
            sb.append(",\"state\":\"menu\"");
         }
         sb.append("}");
         Path dir = blueclientDir();
         Files.createDirectories(dir);
         Files.writeString(dir.resolve("presence.json"), sb.toString(), StandardCharsets.UTF_8);
      } catch (Throwable t) {
         // presence is cosmetic - a failed write just means stale info
      }
   }

   private static String escape(String s) {
      String out = s == null ? "" : s;
      return out.replace("\\", "\\\\").replace("\"", "\\\"")
         .replace("\n", " ").replace("\r", " ").trim();
   }

   /** %APPDATA%\.blueclient on Windows, ~/.blueclient elsewhere. */
   public static Path blueclientDir() {
      String appData = System.getenv("APPDATA");
      String base = appData != null && !appData.isBlank() ? appData : System.getProperty("user.home");
      return Paths.get(base, ".blueclient");
   }

   /** True when the module is on (the launcher can also read presence.json). */
   public static boolean enabled() {
      Module m = BlueClient.getInstance().moduleManager().byName("Discord Presence");
      return m instanceof DiscordPresence && m.isEnabled();
   }
}
