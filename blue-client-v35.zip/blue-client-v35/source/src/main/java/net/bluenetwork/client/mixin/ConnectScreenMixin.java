package net.bluenetwork.client.mixin;

import net.bluenetwork.client.gui.BlueConnectOverlay;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.CookieStorage;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Swaps in the branded Blue Network connecting screen.
 *
 * <p>Owner: "can you make a custom blue network join/connecting screen".</p>
 *
 * <p>Two hooks:</p>
 * <ol>
 *   <li>the static {@code connect(...)} factory records which server is being
 *       dialled — the screen itself never stores the address, so this is the
 *       only place to learn it;</li>
 *   <li>{@code render} is cancelled and replaced by our own drawing, but
 *       <b>only for Blue Network</b>. Every other server keeps the vanilla
 *       screen untouched.</li>
 * </ol>
 *
 * <p>The vanilla Cancel button still exists underneath: we skip vanilla's
 * background/label drawing but call {@code super.render} through the widget
 * pass so the button stays clickable and visible.</p>
 */
@Mixin(ConnectScreen.class)
public abstract class ConnectScreenMixin extends Screen {

   @Shadow
   private Text status;

   private ConnectScreenMixin(Text title) {
      super(title);
   }

   /** Remembers the address so the overlay knows whether to take over. */
   @Inject(method = "connect(Lnet/minecraft/client/gui/screen/Screen;Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/client/network/ServerAddress;Lnet/minecraft/client/network/ServerInfo;ZLnet/minecraft/client/network/CookieStorage;)V", at = @At("HEAD"))
   private static void blueclient$armOverlay(Screen parent, MinecraftClient client,
         ServerAddress address, ServerInfo info, boolean quickPlay, CookieStorage cookies,
         CallbackInfo ci) {
      try {
         BlueConnectOverlay.arm(info != null ? info.address : address.getAddress());
      } catch (Throwable ignored) {
      }
   }

   /** Replaces the vanilla connect screen for Blue Network only. */
   @Inject(method = "render", at = @At("HEAD"), cancellable = true)
   private void blueclient$customRender(DrawContext context, int mouseX, int mouseY,
         float delta, CallbackInfo ci) {
      try {
         if (!BlueConnectOverlay.shouldRender()) {
            return;
         }
         BlueConnectOverlay.render(context, this.status == null ? null : this.status.getString());

         /*
          * Draw the vanilla widgets (the Cancel button) on top of our art so
          * the player can always back out.
          *
          * Screen.drawables is private, so we walk children() instead — every
          * ClickableWidget is both an Element and a Drawable, and ConnectScreen
          * only ever adds the one button.
          */
         for (net.minecraft.client.gui.Element child : this.children()) {
            if (child instanceof net.minecraft.client.gui.Drawable drawable) {
               drawable.render(context, mouseX, mouseY, delta);
            }
         }
         ci.cancel();
      } catch (Throwable ignored) {
         // On any failure fall through to the vanilla screen.
      }
   }

   /** Clears the armed address when the screen goes away. */
   @Inject(method = "removed", at = @At("TAIL"), require = 0)
   private void blueclient$disarm(CallbackInfo ci) {
      BlueConnectOverlay.disarm();
   }
}
