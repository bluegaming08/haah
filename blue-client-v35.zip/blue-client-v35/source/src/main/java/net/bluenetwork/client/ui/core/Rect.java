package net.bluenetwork.client.ui.core;

/**
 * Immutable integer rectangle used by the v2 widget/hit-test layer. Pure value
 * type — no rendering, no allocations beyond construction.
 */
public record Rect(int x, int y, int w, int h) {

   public int right() {
      return x + w;
   }

   public int bottom() {
      return y + h;
   }

   public boolean contains(int px, int py) {
      return px >= x && px < x + w && py >= y && py < y + h;
   }

   public Rect inset(int amount) {
      int n = Math.max(0, amount);
      return new Rect(x + n, y + n, Math.max(0, w - 2 * n), Math.max(0, h - 2 * n));
   }

   public Rect offset(int dx, int dy) {
      return new Rect(x + dx, y + dy, w, h);
   }

   public static Rect of(int x, int y, int w, int h) {
      return new Rect(Math.max(0, x), Math.max(0, y), Math.max(0, w), Math.max(0, h));
   }
}
