package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Mouse Strokes - shows mouse aim as a moving dot or trail, like Keystrokes
 * does for the keyboard.
 *
 * <h2>What it is</h2>
 * A square pad. Your mouse movement pushes a marker around inside it, so
 * viewers (and you, on a recording) can see the aim itself rather than only
 * the result. Optional LMB/RMB buttons sit underneath with live CPS.
 *
 * <p>Modelled on the Badlion mod of the same name: dot or snake display, a
 * sensitivity control, toggleable mouse buttons, and a centre reference dot.</p>
 *
 * <h2>Why it reads mouse DELTAS, not cursor position</h2>
 * While the game has pointer lock there is no cursor position to read - the
 * OS keeps sending relative motion. So the marker integrates deltas and
 * springs back toward the centre, which is also what makes it useful: it shows
 * the <i>gesture</i>, not an absolute coordinate. A sharp flick throws the
 * marker to the edge; holding still lets it settle.
 *
 * <h2>Not anticheat-flaggable</h2>
 * It only reads input the client already received and draws a HUD element. No
 * packets, no input synthesis, no game state.
 */
public class MouseStrokes extends HudModule {

   private static final int TRAIL_MAX = 24;

   private final ModeSetting style = new ModeSetting("Style",
      "Dot shows a single marker; Snake leaves a fading trail",
      java.util.List.of("Dot", "Snake"), "Snake");

   private final NumberSetting sensitivity = new NumberSetting("Sensitivity",
      "How far the marker travels for a given mouse movement",
      1.0, 0.1, 4.0, 0.1);

   private final NumberSetting padSize = new NumberSetting("Pad Size",
      "Width and height of the movement pad", 48.0, 24.0, 96.0, 2.0);

   private final BooleanSetting showButtons = new BooleanSetting("Mouse Buttons",
      "Show LMB and RMB under the pad", true);

   private final BooleanSetting showCps = new BooleanSetting("Show CPS",
      "Show clicks per second on each button", true);

   private final BooleanSetting showCentre = new BooleanSetting("Centre Dot",
      "Draw a reference dot in the middle of the pad", true);

   private final BooleanSetting hideOnF3 = new BooleanSetting("Hide on F3",
      "Hide while the debug screen is open", true);

   /* ---- live state ---- */

   /** Marker position, -1..1 on each axis. */
   private float markerX;
   private float markerY;

   /** Trail history, newest last. Fixed arrays: this runs every frame. */
   private final float[] trailX = new float[TRAIL_MAX];
   private final float[] trailY = new float[TRAIL_MAX];
   private int trailCount;

   private boolean seeded;

   /** Click timestamps for CPS, oldest first. */
   private final long[] leftClicks = new long[32];
   private final long[] rightClicks = new long[32];
   private int leftHead;
   private int rightHead;
   private boolean leftWasDown;
   private boolean rightWasDown;

   public MouseStrokes() {
      super("Mouse Strokes", "Shows your mouse movement and clicks",
         Category.HUD, 4, 150);
      this.addSettings(new Setting[]{this.style, this.sensitivity, this.padSize,
         this.showButtons, this.showCps, this.showCentre, this.hideOnF3});
      this.showCps.visibleWhen(this.showButtons::get);
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.mouse == null) {
         return;
      }

      /*
       * Drive the marker from the CAMERA, not the cursor.
       *
       * mc.mouse.getScaledX/Y need a Window and, more importantly, are pinned
       * to the screen centre while the game holds pointer lock - so they
       * report no movement at all during normal play. Yaw and pitch change is
       * the only signal that survives, and it is exactly what the player's
       * hand did.
       */
      if (mc.player == null) {
         return;
      }
      float yaw = mc.player.getYaw();
      float pitch = mc.player.getPitch();
      if (!this.seeded) {
         this.lastYaw = yaw;
         this.lastPitch = pitch;
         this.seeded = true;
         return;
      }
      double dx = net.minecraft.util.math.MathHelper.wrapDegrees(yaw - this.lastYaw) * 4.0;
      double dy = (pitch - this.lastPitch) * 4.0;
      this.lastYaw = yaw;
      this.lastPitch = pitch;

      float scale = this.sensitivity.getFloat() * 0.02F;
      this.markerX += (float) (dx * scale);
      this.markerY += (float) (dy * scale);

      // Spring back toward centre, so the pad shows the gesture and then
      // settles instead of drifting into a corner and sticking there.
      this.markerX *= 0.82F;
      this.markerY *= 0.82F;
      this.markerX = clamp(this.markerX);
      this.markerY = clamp(this.markerY);

      pushTrail(this.markerX, this.markerY);
      trackClicks(mc);
   }

   private float lastYaw;
   private float lastPitch;

   private static float clamp(float v) {
      return v < -1.0F ? -1.0F : (v > 1.0F ? 1.0F : v);
   }

   private void pushTrail(float x, float y) {
      if (this.trailCount < TRAIL_MAX) {
         this.trailX[this.trailCount] = x;
         this.trailY[this.trailCount] = y;
         this.trailCount++;
         return;
      }
      System.arraycopy(this.trailX, 1, this.trailX, 0, TRAIL_MAX - 1);
      System.arraycopy(this.trailY, 1, this.trailY, 0, TRAIL_MAX - 1);
      this.trailX[TRAIL_MAX - 1] = x;
      this.trailY[TRAIL_MAX - 1] = y;
   }

   /** Records click edges so CPS can be counted. */
   private void trackClicks(MinecraftClient mc) {
      long now = System.currentTimeMillis();
      boolean left = mc.options != null && mc.options.attackKey.isPressed();
      boolean right = mc.options != null && mc.options.useKey.isPressed();

      if (left && !this.leftWasDown) {
         this.leftClicks[this.leftHead++ % this.leftClicks.length] = now;
      }
      if (right && !this.rightWasDown) {
         this.rightClicks[this.rightHead++ % this.rightClicks.length] = now;
      }
      this.leftWasDown = left;
      this.rightWasDown = right;
   }

   private static int cps(long[] stamps) {
      long cutoff = System.currentTimeMillis() - 1000L;
      int n = 0;
      for (long s : stamps) {
         if (s > cutoff) {
            n++;
         }
      }
      return n;
   }

   /* ====================================================================== */

   @Override
   public int getWidth() {
      return this.padSize.getInt();
   }

   @Override
   public int getHeight() {
      return this.padSize.getInt() + (this.showButtons.get() ? 18 : 0);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (this.hideOnF3.get() && mc != null && mc.getDebugHud() != null
         && mc.getDebugHud().shouldShowDebugHud()) {
         return;
      }

      float pad = this.padSize.getInt();
      float x = this.x;
      float y = this.y;

      if (this.panelBackground()) {
         SmoothRect.fill(context, x, y, pad, pad, this.panelRadius(),
            this.panelBodyArgb());
      }
      if (this.panelBorderEnabled()) {
         SmoothRect.outline(context, x, y, pad, pad, this.panelRadius(), 1.0F,
            this.panelBorderArgb());
      }

      float cx = x + pad / 2.0F;
      float cy = y + pad / 2.0F;
      float reach = pad / 2.0F - 3.0F;

      if (this.showCentre.get()) {
         SmoothRect.fill(context, cx - 1.0F, cy - 1.0F, 2.0F, 2.0F, 1.0F,
            0x66FFFFFF);
      }

      int accent = this.textColor();
      if ("Snake".equals(this.style.get()) && this.trailCount > 1) {
         // Older points fade out, newest is solid.
         for (int i = 0; i < this.trailCount; i++) {
            float t = i / (float) Math.max(1, this.trailCount - 1);
            int alpha = (int) (t * 200.0F) & 0xFF;
            float size = 1.0F + t * 2.0F;
            float px = cx + this.trailX[i] * reach - size / 2.0F;
            float py = cy + this.trailY[i] * reach - size / 2.0F;
            SmoothRect.fill(context, px, py, size, size, size / 2.0F,
               (alpha << 24) | (accent & 0xFFFFFF));
         }
      } else {
         float size = 3.5F;
         SmoothRect.fill(context, cx + this.markerX * reach - size / 2.0F,
            cy + this.markerY * reach - size / 2.0F, size, size, size / 2.0F,
            accent);
      }

      if (!this.showButtons.get()) {
         return;
      }

      /* ---- LMB / RMB with CPS ---- */
      float bw = (pad - 2.0F) / 2.0F;
      float by = y + pad + 2.0F;
      drawButton(context, x, by, bw, "LMB", this.leftWasDown,
         cps(this.leftClicks));
      drawButton(context, x + bw + 2.0F, by, bw, "RMB", this.rightWasDown,
         cps(this.rightClicks));
   }

   private void drawButton(DrawContext context, float x, float y, float w,
                           String label, boolean pressed, int cps) {
      SmoothRect.fill(context, x, y, w, 14.0F, 2.0F,
         pressed ? 0xCC2FA5FF : 0x66000000);
      String text = this.showCps.get() ? label + " " + cps : label;
      float tw = RenderUtil.textWidth(text);
      RenderUtil.drawText(context, text, (int) (x + (w - tw) / 2.0F),
         (int) (y + 3.0F), pressed ? 0xFFFFFFFF : this.textColor());
   }
}
