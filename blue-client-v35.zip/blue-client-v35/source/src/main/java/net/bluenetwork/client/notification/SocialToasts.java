package net.bluenetwork.client.notification;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.DrawContext;

/**
 * Clickable notifications down the right-hand side: chat messages and server
 * invites from friends.
 *
 * <h2>Why these are separate from {@link NotificationManager}</h2>
 * The existing toasts are decoration - "Fullbright on", "Friend request sent".
 * They fade out, nothing can be done with them, and they are drawn from the
 * HUD layer where the mouse is not even captured.
 *
 * <p>These carry an <b>action</b>: clicking a message opens the reply box,
 * clicking an invite joins the server. That means they need hit testing, a
 * hover state, and a close button, so they live in their own class rather
 * than complicating the simple toasts.</p>
 *
 * <h2>Do Not Disturb</h2>
 * Nothing is ever queued while the player is on DND - the check happens at the
 * point of creation in {@code FriendsManager}, so a DND player does not even
 * build the toast, let alone see it.
 */
public final class SocialToasts {

   /** How long a toast stays before it slides away. */
   private static final long LIFETIME_MS = 12_000L;
   private static final long SLIDE_MS = 220L;

   private static final int WIDTH = 150;
   private static final int HEIGHT = 34;
   private static final int GAP = 4;
   private static final int MAX_SHOWN = 4;

   /**
    * What a toast is about - decides its accent colour, icon and click action.
    *
    * <p>Owner: "add notifications for everything in Social, like Instagram."
    * Everything that happens to you now raises one of these.</p>
    */
   public enum Kind {
      /** A chat message - clicking opens that conversation. */
      MESSAGE,
      /** A server invite - clicking joins. */
      INVITE,
      /** Someone liked your post - clicking opens the thread. */
      LIKE,
      /** Someone replied to your post. */
      REPLY,
      /** Someone reposted your post. */
      REPOST,
      /** Someone followed you - clicking opens their profile. */
      FOLLOW,
      /** Someone sent you a friend request. */
      REQUEST,
      /** Someone accepted your friend request. */
      ACCEPTED,
      /** Someone you follow posted. */
      POSTED,
      /** Blue or Cyan pinned a post for everyone. */
      PINNED;

      /** Accent colour for this kind. */
      public int colour() {
         return switch (this) {
            case INVITE, ACCEPTED -> 0xFF43D17A;
            case LIKE -> 0xFFE35D5D;
            case REPOST -> 0xFF43D17A;
            case FOLLOW, REQUEST -> 0xFFFFD600;
            case PINNED -> 0xFFFFD400;
            default -> 0xFF2FA5FF;
         };
      }

      /** Sprite name - all of these exist in the shipped icon set. */
      public String icon() {
         return switch (this) {
            case MESSAGE -> "message-square";
            case INVITE -> "send";
            case LIKE -> "flame";
            case REPLY -> "message-square";
            case REPOST -> "share-2";
            case FOLLOW -> "user-round";
            case REQUEST -> "users";
            case ACCEPTED -> "check";
            case POSTED -> "send";
            case PINNED -> "sparkles";
         };
      }

      /** The call-to-action shown in the corner. */
      public String cue() {
         return switch (this) {
            case INVITE -> "JOIN";
            case MESSAGE -> "REPLY";
            case FOLLOW, REQUEST, ACCEPTED -> "VIEW";
            case POSTED, PINNED -> "READ";
            default -> "OPEN";
         };
      }
   }

   /** One live toast. */
   public static final class Toast {
      final Kind kind;
      final String who;
      final String body;
      /** Conversation id or invite id, depending on {@link #kind}. */
      final String targetId;
      final long born = System.currentTimeMillis();
      boolean dismissed;

      Toast(Kind kind, String who, String body, String targetId) {
         this.kind = kind;
         this.who = who;
         this.body = body;
         this.targetId = targetId;
      }

      /** Conversation id (MESSAGE) or invite id (INVITE). */
      public String conversationId() {
         return this.targetId;
      }

      /** Who the toast is from. */
      public String who() {
         return this.who;
      }

      long age() {
         return System.currentTimeMillis() - this.born;
      }

      boolean expired() {
         return this.dismissed || age() > LIFETIME_MS;
      }

      /** 0 while sliding in, 1 once settled. */
      float slide() {
         return Math.min(1.0F, age() / (float) SLIDE_MS);
      }

      /** Fades over the last half second. */
      float fade() {
         long left = LIFETIME_MS - age();
         return left > 500L ? 1.0F : Math.max(0.0F, left / 500.0F);
      }
   }

   private static final CopyOnWriteArrayList<Toast> LIVE = new CopyOnWriteArrayList<>();

   /** Where each toast was last drawn, for hit testing. */
   private record Box(float x, float y, float w, float h, Toast toast) {
   }

   private static volatile List<Box> boxes = List.of();

   /** Called when the player clicks a message toast. */
   public static volatile java.util.function.Consumer<Toast> onMessageClick;
   /** Called when the player clicks an invite toast. */
   public static volatile java.util.function.Consumer<Toast> onInviteClick;

   private SocialToasts() {
   }

   /** The sender's bust, or their initial on a disc while it loads. */
   private static void drawFace(DrawContext ctx, String name, float x, float y,
                                float size, float fade) {
      if (name != null && !name.isBlank()
          && !net.bluenetwork.client.account.PlayerHeads.unavailable(name)) {
         var tex = net.bluenetwork.client.account.PlayerHeads.bust(name);
         if (tex != null) {
            ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,
               tex, Math.round(x), Math.round(y), 0.0F, 0.0F,
               Math.round(size), Math.round(size),
               Math.round(size), Math.round(size));
            return;
         }
      }
      SmoothRect.fill(ctx, x, y, size, size, size / 2.0F,
         alpha(0xFF2A3344, fade));
      String ch = name == null || name.isEmpty()
         ? "?" : name.substring(0, 1).toUpperCase(java.util.Locale.ROOT);
      float cw = TextPainter.poppinsWidth(ch, size * 0.5F);
      TextPainter.drawPoppins(ctx, ch, x + (size - cw) / 2.0F, y + size * 0.24F,
         alpha(DesignTokens.textHi(), fade), size * 0.5F);
   }

   /** Queues a chat-message toast. */
   public static void message(String from, String body, String conversationId) {
      push(new Toast(Kind.MESSAGE, from, body, conversationId));
   }

   /** Queues a server-invite toast. */
   public static void invite(String from, String label, String inviteId) {
      push(new Toast(Kind.INVITE, from, label == null ? "wants you to join" : label, inviteId));
   }

   /**
    * Queues any other social event.
    *
    * @param kind     what happened
    * @param who      the player who did it
    * @param targetId post id, profile id or conversation id to open on click
    */
   /**
    * As {@link #social(Kind, String, String)}, with a snippet of the post.
    *
    * <p>The owner asked for "&lt;person&gt; posted &lt;few words&gt;", so the
    * preview goes in the body and clicking opens the post.</p>
    */
   public static void social(Kind kind, String who, String targetId, String preview) {
      String snippet = preview == null ? "" : preview.trim();
      if (snippet.length() > 34) {
         snippet = snippet.substring(0, 33).trim() + "\u2026";
      }
      String body = switch (kind) {
         case POSTED -> snippet.isEmpty() ? "posted" : "posted: " + snippet;
         case PINNED -> snippet.isEmpty() ? "pinned a post" : "pinned: " + snippet;
         default -> null;
      };
      if (body == null) {
         social(kind, who, targetId);
         return;
      }
      push(new Toast(kind, who, body, targetId));
      NotificationInbox.add(kind, who, body, targetId);
   }

   public static void social(Kind kind, String who, String targetId) {
      String body = switch (kind) {
         case LIKE -> "liked your post";
         case REPLY -> "replied to your post";
         case REPOST -> "reposted your post";
         case FOLLOW -> "started following you";
         case REQUEST -> "sent you a friend request";
         case ACCEPTED -> "accepted your friend request";
         case POSTED -> "posted";
         case PINNED -> "pinned a post";
         default -> "";
      };
      push(new Toast(kind, who, body, targetId));
      NotificationInbox.add(kind, who, body, targetId);
   }

   private static void push(Toast t) {
      LIVE.add(t);
      while (LIVE.size() > MAX_SHOWN) {
         LIVE.remove(0);
      }
   }

   public static void clear() {
      LIVE.clear();
      boxes = List.of();
   }

   /**
    * Draws the stack and records where each toast landed.
    *
    * <p>Drawn below the plain toasts so the two never overlap.</p>
    */
   public static void render(DrawContext ctx, int mouseX, int mouseY, int topOffset) {
      LIVE.removeIf(Toast::expired);
      if (LIVE.isEmpty()) {
         boxes = List.of();
         return;
      }

      List<Box> found = new ArrayList<>();
      int y = topOffset;

      for (Toast t : LIVE) {
         float slide = easeOut(t.slide());
         float fade = t.fade();
         float x = ctx.getScaledWindowWidth() - WIDTH - 8 + (1.0F - slide) * (WIDTH + 12);

         boolean hover = mouseX >= x && mouseX <= x + WIDTH
            && mouseY >= y && mouseY <= y + HEIGHT;

         PremiumRender.drawShadow(ctx, (int) x - 1, y - 1, WIDTH + 2, HEIGHT + 2,
            alpha(0x66000000, fade), 8);
         SmoothRect.fill(ctx, x, y, WIDTH, HEIGHT, 5.0F,
            alpha(hover ? DesignTokens.panelBgHover() : DesignTokens.panelBg(), fade));
         SmoothRect.outline(ctx, x, y, WIDTH, HEIGHT, 5.0F, 1.0F,
            alpha(t.kind.colour(), fade));

         // Accent bar on the left edge marks the type at a glance.
         int accent = alpha(t.kind.colour(), fade);
         SmoothRect.fill(ctx, x + 2, y + 3, 2.5F, HEIGHT - 6, 1.0F, accent);

         // Instagram-style: the sender's face, then the event icon over it.
         float av = HEIGHT - 12;
         float avX = x + 9;
         float avY = y + 6;
         drawFace(ctx, t.who, avX, avY, av, fade);
         RenderUtil.drawIcon(ctx, t.kind.icon(),
            Math.round(avX + av - 6), Math.round(avY + av - 6), 8, accent);

         float tx = avX + av + 6;
         float tw = WIDTH - (tx - x) - 10;

         String title = t.kind == Kind.INVITE ? t.who + " invited you" : t.who;
         TextPainter.drawPoppins(ctx, fit(title, tw, 8.0F), tx, y + 6,
            alpha(DesignTokens.textHi(), fade), 8.0F);
         TextPainter.drawPoppins(ctx, fit(t.body, tw, 7.0F), tx, y + 18,
            alpha(DesignTokens.textMid(), fade), 7.0F);

         String cue = t.kind.cue();
         float cw = TextPainter.poppinsWidth(cue, 6.5F);
         TextPainter.drawPoppins(ctx, cue, x + WIDTH - cw - 8, y + HEIGHT - 11,
            alpha(accent, fade), 6.5F);

         // Close cross, top right.
         TextPainter.drawPoppins(ctx, "x", x + WIDTH - 10, y + 4,
            alpha(0xFF8A94A6, fade), 7.5F);

         found.add(new Box(x, y, WIDTH, HEIGHT, t));
         y += HEIGHT + GAP;
      }
      boxes = List.copyOf(found);
   }

   /**
    * Handles a click. Returns true when a toast consumed it.
    *
    * <p>Tested newest-first so the most recent toast wins any overlap.</p>
    */
   public static boolean click(double mouseX, double mouseY) {
      List<Box> snapshot = boxes;
      for (int i = snapshot.size() - 1; i >= 0; i--) {
         Box b = snapshot.get(i);
         if (mouseX < b.x() || mouseX > b.x() + b.w()
            || mouseY < b.y() || mouseY > b.y() + b.h()) {
            continue;
         }

         // The little x in the corner just dismisses.
         if (mouseX >= b.x() + b.w() - 14) {
            b.toast().dismissed = true;
            return true;
         }

         b.toast().dismissed = true;
         if (b.toast().kind == Kind.INVITE) {
            var handler = onInviteClick;
            if (handler != null) {
               handler.accept(b.toast());
            }
         } else {
            var handler = onMessageClick;
            if (handler != null) {
               handler.accept(b.toast());
            }
         }
         return true;
      }
      return false;
   }

   /** True when a toast sits under the cursor - used to grab the click. */
   public static boolean isOver(double mouseX, double mouseY) {
      for (Box b : boxes) {
         if (mouseX >= b.x() && mouseX <= b.x() + b.w()
            && mouseY >= b.y() && mouseY <= b.y() + b.h()) {
            return true;
         }
      }
      return false;
   }

   private static String fit(String text, float maxWidth, float size) {
      if (text == null) {
         return "";
      }
      if (TextPainter.poppinsWidth(text, size) <= maxWidth) {
         return text;
      }
      // Budget the ellipsis INSIDE the loop, or the result overflows by
      // exactly the width of the dots.
      float ellipsis = TextPainter.poppinsWidth("...", size);
      String out = text;
      while (out.length() > 1
         && TextPainter.poppinsWidth(out, size) + ellipsis > maxWidth) {
         out = out.substring(0, out.length() - 1);
      }
      return out + "...";
   }

   private static int alpha(int argb, float fade) {
      int a = (int) ((argb >>> 24 & 0xFF) * Math.max(0.0F, Math.min(1.0F, fade)));
      return (a << 24) | (argb & 0xFFFFFF);
   }

   private static float easeOut(float t) {
      float inv = 1.0F - t;
      return 1.0F - inv * inv * inv;
   }
}
