package net.bluenetwork.client.music;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The parsed lyric document: lines, optional real word timings, and an honest
 * statement of how accurate the timing actually is.
 *
 * <h2>Why syncType exists</h2>
 * The old system had one boolean, {@code synced}, and every display mode
 * pretended word timing existed by splitting a line's duration evenly between
 * its words. That is <b>guessing</b>, and it is why karaoke drifted: real
 * singing is not evenly spaced, so a six-word line would highlight the last
 * word a beat early or late almost every time.
 *
 * <p>{@link SyncType} makes the distinction explicit and impossible to ignore:</p>
 * <ul>
 *   <li>{@link SyncType#WORD} - the provider gave a timestamp per word. Real
 *       karaoke is possible.</li>
 *   <li>{@link SyncType#LINE} - one timestamp per line. Lines are accurate;
 *       word positions are <b>not known</b>.</li>
 *   <li>{@link SyncType#PLAIN} - no timing at all.</li>
 * </ul>
 *
 * <p>Estimated word timing still exists as an opt-in, but it lives behind
 * {@link Word#estimated()} so nothing can mistake it for provider data.</p>
 *
 * <h2>Immutability</h2>
 * Parsed once, then read every frame from the render thread while a worker
 * thread may be fetching the next track. Everything here is deeply immutable
 * and the lists are sorted at construction, so lookup is a binary search with
 * no allocation and no locking.
 */
public final class LyricData {

   /** How trustworthy the timing is. */
   public enum SyncType {
      /** Real per-word timestamps from the provider. */
      WORD,
      /** Per-line timestamps only. */
      LINE,
      /** No timing information. */
      PLAIN;

      /** Short label for the sync indicator in the UI. */
      public String label() {
         return switch (this) {
            case WORD -> "WORD SYNC";
            case LINE -> "LINE SYNC";
            case PLAIN -> "PLAIN";
         };
      }
   }

   /**
    * One word and when it is sung.
    *
    * @param startMs when the word begins, in track time
    * @param endMs   when it ends, or -1 when the provider did not say. The
    *                renderer falls back to the next word's start.
    * @param estimated true when this timing was DERIVED, not provided. Kept as
    *                  a field rather than a parallel list so it travels with
    *                  the data and cannot be lost in a refactor.
    */
   public record Word(long startMs, long endMs, String text, boolean estimated) {

      public Word(long startMs, String text) {
         this(startMs, -1L, text, false);
      }
   }

   /**
    * One lyric line.
    *
    * @param words the words of this line with real timings, or empty when only
    *              the line timestamp is known
    */
   public record Line(long startMs, long endMs, String text, List<Word> words) {

      public Line {
         words = words == null ? List.of() : List.copyOf(words);
      }

      /** True when this line carries real, provider-supplied word timings. */
      public boolean hasWordTiming() {
         if (this.words.isEmpty()) {
            return false;
         }
         for (Word w : this.words) {
            if (w.estimated()) {
               return false;
            }
         }
         return true;
      }
   }

   private final List<Line> lines;
   private final SyncType syncType;
   private final String provider;

   /**
    * Line start times, extracted into a primitive array.
    *
    * <p>The active line is looked up on every rendered frame. Binary searching
    * a {@code long[]} avoids both the pointer chasing of walking records and
    * any allocation, which matters because this runs at frame rate.</p>
    */
   private final long[] lineStarts;

   public LyricData(List<Line> lines, SyncType syncType, String provider) {
      List<Line> copy = new ArrayList<>(lines == null ? List.of() : lines);
      copy.sort((a, b) -> Long.compare(a.startMs(), b.startMs()));
      this.lines = Collections.unmodifiableList(copy);
      this.syncType = syncType == null ? SyncType.PLAIN : syncType;
      this.provider = provider == null ? "unknown" : provider;

      this.lineStarts = new long[this.lines.size()];
      for (int i = 0; i < this.lines.size(); i++) {
         this.lineStarts[i] = this.lines.get(i).startMs();
      }
   }

   public List<Line> lines() {
      return this.lines;
   }

   public SyncType syncType() {
      return this.syncType;
   }

   public String provider() {
      return this.provider;
   }

   public boolean isEmpty() {
      return this.lines.isEmpty();
   }

   /** True when every line carries real word timings. */
   public boolean hasRealWordTiming() {
      return this.syncType == SyncType.WORD;
   }

   /**
    * Index of the line active at {@code positionMs}, or -1 before the first.
    *
    * <p>Binary search, not a scan: a long track can have 150 lines and this is
    * called every frame.</p>
    */
   public int lineIndexAt(long positionMs) {
      int lo = 0;
      int hi = this.lineStarts.length - 1;
      int found = -1;
      while (lo <= hi) {
         int mid = (lo + hi) >>> 1;
         if (this.lineStarts[mid] <= positionMs) {
            found = mid;
            lo = mid + 1;
         } else {
            hi = mid - 1;
         }
      }
      return found;
   }

   /** The line active at {@code positionMs}, or null. */
   public Line lineAt(long positionMs) {
      int i = lineIndexAt(positionMs);
      return i < 0 ? null : this.lines.get(i);
   }

   /** The line after the given index, or null at the end. */
   public Line lineAfter(int index) {
      return index >= 0 && index + 1 < this.lines.size()
         ? this.lines.get(index + 1) : null;
   }

   /**
    * Index of the active word inside a line, or -1 when none is active yet.
    *
    * <p>Returns -1 rather than 0 before the first word starts, so a line that
    * appears slightly ahead of its vocal does not highlight a word that is not
    * being sung.</p>
    */
   public static int wordIndexAt(Line line, long positionMs) {
      List<Word> words = line.words();
      if (words.isEmpty()) {
         return -1;
      }
      int lo = 0;
      int hi = words.size() - 1;
      int found = -1;
      while (lo <= hi) {
         int mid = (lo + hi) >>> 1;
         if (words.get(mid).startMs() <= positionMs) {
            found = mid;
            lo = mid + 1;
         } else {
            hi = mid - 1;
         }
      }
      return found;
   }

   /**
    * Groups a line's words into segments of {@code perSegment} words.
    *
    * <p><b>The timestamp of the first word in each group is preserved exactly.</b>
    * Nothing is averaged or recalculated - grouping only changes how much text
    * is shown at once, never when it is shown.</p>
    *
    * <p>With {@code perSegment == 1} every word is its own segment and the
    * original timings pass through untouched.</p>
    */
   public static List<Word> segment(Line line, int perSegment) {
      List<Word> words = line.words();
      if (words.isEmpty()) {
         return List.of();
      }
      int size = Math.max(1, perSegment);
      if (size == 1) {
         return words;
      }
      List<Word> out = new ArrayList<>((words.size() + size - 1) / size);
      for (int i = 0; i < words.size(); i += size) {
         int end = Math.min(words.size(), i + size);
         StringBuilder sb = new StringBuilder();
         for (int j = i; j < end; j++) {
            if (j > i) {
               // A SPACE between words. Joining without one produced
               // "wordsecondword", which the owner reported.
               sb.append(' ');
            }
            sb.append(words.get(j).text());
         }
         Word first = words.get(i);
         Word last = words.get(end - 1);
         out.add(new Word(first.startMs(), last.endMs(), sb.toString(),
            first.estimated()));
      }
      return out;
   }

   /**
    * Derives approximate word timings by spreading a line across its duration.
    *
    * <p><b>Only for the explicit "estimated" mode.</b> Every word produced is
    * flagged {@code estimated = true} so it can never be mistaken for real
    * provider timing.</p>
    *
    * <p>Words are weighted by length rather than spaced evenly, because a
    * one-letter word plainly does not take as long to sing as a four-syllable
    * one. It is still a guess - just a less wrong one.</p>
    */
   public static List<Word> estimateWords(Line line, long lineDurationMs) {
      String text = line.text() == null ? "" : line.text().trim();
      if (text.isEmpty()) {
         return List.of();
      }
      String[] parts = text.split("\\s+");
      long duration = Math.max(200L, lineDurationMs);

      int total = 0;
      int[] weights = new int[parts.length];
      for (int i = 0; i < parts.length; i++) {
         weights[i] = Math.max(1, parts[i].length());
         total += weights[i];
      }

      List<Word> out = new ArrayList<>(parts.length);
      long cursor = line.startMs();
      for (int i = 0; i < parts.length; i++) {
         long slice = Math.max(80L, duration * weights[i] / total);
         out.add(new Word(cursor, cursor + slice, parts[i], true));
         cursor += slice;
      }
      return out;
   }

   /** An empty document, for "no lyrics found". */
   public static LyricData empty() {
      return new LyricData(List.of(), SyncType.PLAIN, "none");
   }
}
