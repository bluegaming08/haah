package net.bluenetwork.client.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import net.bluenetwork.client.BlueClient;

/**
 * The single place that speaks HTTP to Supabase.
 *
 * <h2>Design rules (these are why the client never freezes)</h2>
 * <ol>
 *   <li><b>Nothing here may be called from the render thread synchronously.</b>
 *       Every public method returns a {@link CompletableFuture} and runs on a
 *       small daemon thread pool. Minecraft's frame loop is never blocked, so
 *       a slow or dead backend costs 0 FPS.</li>
 *   <li><b>Every request has a timeout.</b> A hung TCP connection would
 *       otherwise pin a thread forever.</li>
 *   <li><b>Nothing here throws into game code.</b> Failures arrive as a failed
 *       future, and the UI turns that into the message
 *       "Friends services are currently unavailable."</li>
 *   <li><b>The access token is refreshed automatically</b> when it expires, so
 *       a long play session does not silently stop working.</li>
 * </ol>
 *
 * <p>Threads are daemons: they will never stop Minecraft from exiting.</p>
 */
public final class SupabaseClient {

   /** How long to wait for a connection / a response before giving up. */
   private static final Duration TIMEOUT = Duration.ofSeconds(8L);

   /** Refresh the session this long before it actually expires. */
   private static final long REFRESH_MARGIN_MS = 60_000L;

   private static final ExecutorService POOL = Executors.newFixedThreadPool(2, new ThreadFactory() {
      private final AtomicInteger n = new AtomicInteger(1);

      @Override
      public Thread newThread(Runnable r) {
         Thread t = new Thread(r, "BlueClient-Social-" + this.n.getAndIncrement());
         t.setDaemon(true);
         return t;
      }
   });

   private static final HttpClient HTTP = HttpClient.newBuilder()
      .connectTimeout(TIMEOUT)
      .followRedirects(HttpClient.Redirect.NORMAL)
      .build();

   /* ---- session state (volatile: written on pool threads, read on render) -- */

   private volatile String accessToken;
   private volatile String refreshToken;
   private volatile long expiresAtMs;

   /**
    * Notified whenever the session changes, so the new refresh token can be
    * written to disk.
    *
    * <p>Supabase <b>rotates</b> the refresh token on every refresh: the old
    * one stops working the moment a new one is issued. v20 only saved the
    * token at login, so the file went stale within the hour and the next
    * launch had to do a full password sign-in - which Supabase counts as a
    * new monthly active user. One player was showing up as ~150 MAU. Saving
    * on every rotation keeps it to 1.</p>
    */
   private volatile Runnable onSessionChanged;
   private volatile String userId;

   /** Thrown for any backend failure; carries a player-friendly message. */
   public static class BackendException extends RuntimeException {
      public BackendException(String message) {
         super(message);
      }
   }

   /* ====================================================================== */
   /*  Session                                                               */
   /* ====================================================================== */

   public boolean loggedIn() {
      return this.accessToken != null && this.userId != null;
   }

   public String userId() {
      return this.userId;
   }

   public void clearSession() {
      this.accessToken = null;
      this.refreshToken = null;
      this.userId = null;
      this.expiresAtMs = 0L;
   }

   /** Tokens saved to disk so the player is not logged out every launch. */
   public String refreshTokenForStorage() {
      return this.refreshToken;
   }

   /** Registers the callback that persists a rotated refresh token. */
   public void setSessionListener(Runnable listener) {
      this.onSessionChanged = listener;
   }

   private void adoptSession(JsonObject o) {
      if (o == null || !o.has("access_token")) {
         throw new BackendException("Login failed.");
      }
      this.accessToken = o.get("access_token").getAsString();
      this.refreshToken = o.has("refresh_token") ? o.get("refresh_token").getAsString() : null;
      long expiresIn = o.has("expires_in") ? o.get("expires_in").getAsLong() : 3600L;
      this.expiresAtMs = System.currentTimeMillis() + expiresIn * 1000L;
      if (o.has("user") && o.get("user").isJsonObject()) {
         JsonObject u = o.getAsJsonObject("user");
         if (u.has("id")) {
            this.userId = u.get("id").getAsString();
         }
      }

      // Persist the ROTATED token immediately - see the field note above.
      Runnable listener = this.onSessionChanged;
      if (listener != null) {
         try {
            listener.run();
         } catch (Exception e) {
            BlueClient.LOGGER.debug("[Social] session listener failed", e);
         }
      }
   }

   /**
    * Makes sure the access token is still valid, refreshing it if needed.
    * Runs on a pool thread - never call from the render thread.
    */
   private void ensureFreshToken() {
      if (this.accessToken == null || this.refreshToken == null) {
         return;
      }
      if (System.currentTimeMillis() < this.expiresAtMs - REFRESH_MARGIN_MS) {
         return;
      }
      try {
         JsonObject body = new JsonObject();
         body.addProperty("refresh_token", this.refreshToken);
         JsonElement res = send(
            "POST",
            BlueBackend.URL + "/auth/v1/token?grant_type=refresh_token",
            body.toString(),
            false);
         if (res != null && res.isJsonObject()) {
            adoptSession(res.getAsJsonObject());
         }
      } catch (Exception e) {
         // Refresh failed: drop the session so the UI asks for a fresh login
         // rather than repeating doomed requests.
         BlueClient.LOGGER.debug("[Social] token refresh failed", e);
         clearSession();
      }
   }

   /* ====================================================================== */
   /*  Auth                                                                  */
   /* ====================================================================== */

   /**
    * Creates an account: reserves the username, signs up, creates the profile.
    *
    * <p>Username uniqueness is ultimately enforced by a unique index in the
    * database, so two people registering the same name at the same instant
    * cannot both succeed - one gets a clear error.</p>
    */
   public CompletableFuture<Void> signUp(String username, String password) {
      return CompletableFuture.runAsync(() -> {
         String err = SocialValidation.usernameError(username);
         if (err != null) {
            throw new BackendException(err);
         }
         if (password == null || password.length() < 6) {
            throw new BackendException("Password must be at least 6 characters.");
         }

         JsonObject body = new JsonObject();
         body.addProperty("email", BlueBackend.loginEmail(username));
         body.addProperty("password", password);

         JsonElement res;
         try {
            res = send("POST", BlueBackend.URL + "/auth/v1/signup", body.toString(), false);
         } catch (BackendException be) {
            String m = be.getMessage() == null ? "" : be.getMessage().toLowerCase(java.util.Locale.ROOT);
            if (m.contains("already") || m.contains("registered") || m.contains("exists")) {
               throw new BackendException("That username is already taken.");
            }
            throw be;
         }

         if (res == null || !res.isJsonObject()) {
            throw new BackendException("Sign up failed.");
         }
         JsonObject o = res.getAsJsonObject();

         // With confirmation OFF, signup returns a session directly.
         if (o.has("access_token")) {
            adoptSession(o);
         } else {
            // Confirmation is still ON in the dashboard - tell the owner
            // precisely what is wrong instead of a vague failure.
            if (o.has("id") && !o.has("access_token")) {
               throw new BackendException(
                  "Account created but login is blocked: turn OFF email confirmation in Supabase.");
            }
            throw new BackendException("Sign up failed.");
         }

         // Create the matching profile row. RLS only allows id = our own uid.
         JsonObject profile = new JsonObject();
         profile.addProperty("id", this.userId);
         profile.addProperty("username", username);
         profile.addProperty("username_low", username.toLowerCase(java.util.Locale.ROOT));
         try {
            send("POST", BlueBackend.URL + "/rest/v1/profiles", profile.toString(), true);
         } catch (BackendException be) {
            // The auth user exists but the profile does not; without it the
            // account is unusable, so surface it clearly.
            clearSession();
            String m = be.getMessage() == null ? "" : be.getMessage();
            if (m.contains("duplicate") || m.contains("unique")) {
               throw new BackendException("That username is already taken.");
            }
            throw new BackendException("Could not finish creating your account.");
         }
      }, POOL);
   }

   /** Logs in with a Blue Client username (not an email). */
   public CompletableFuture<Void> logIn(String username, String password) {
      return CompletableFuture.runAsync(() -> {
         JsonObject body = new JsonObject();
         body.addProperty("email", BlueBackend.loginEmail(username));
         body.addProperty("password", password);
         JsonElement res;
         try {
            res = send("POST",
               BlueBackend.URL + "/auth/v1/token?grant_type=password",
               body.toString(), false);
         } catch (BackendException be) {
            String m = be.getMessage() == null ? "" : be.getMessage().toLowerCase(java.util.Locale.ROOT);
            if (m.contains("invalid") || m.contains("credentials")) {
               throw new BackendException("Wrong username or password.");
            }
            throw be;
         }
         adoptSession(res != null && res.isJsonObject() ? res.getAsJsonObject() : null);
      }, POOL);
   }

   /** Restores a saved session from a stored refresh token. */
   public CompletableFuture<Void> resumeSession(String storedRefreshToken) {
      return CompletableFuture.runAsync(() -> {
         if (storedRefreshToken == null || storedRefreshToken.isBlank()) {
            throw new BackendException("No saved session.");
         }
         JsonObject body = new JsonObject();
         body.addProperty("refresh_token", storedRefreshToken);
         JsonElement res = send("POST",
            BlueBackend.URL + "/auth/v1/token?grant_type=refresh_token",
            body.toString(), false);
         adoptSession(res != null && res.isJsonObject() ? res.getAsJsonObject() : null);
      }, POOL);
   }

   /**
    * Attaches a real email address for password recovery (optional).
    *
    * <p>This is the "extra security" path: the account keeps its username
    * login, but gains a way to reset a forgotten password. Supabase will send
    * a confirmation link to the new address.</p>
    */
   public CompletableFuture<Void> linkEmail(String email) {
      return CompletableFuture.runAsync(() -> {
         if (email == null || !email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]{2,}$")) {
            throw new BackendException("That does not look like an email address.");
         }
         if (email.toLowerCase(java.util.Locale.ROOT).endsWith("@" + BlueBackend.ACCOUNT_EMAIL_DOMAIN)) {
            throw new BackendException("Use your own email address.");
         }
         JsonObject body = new JsonObject();
         body.addProperty("email", email);
         send("PUT", BlueBackend.URL + "/auth/v1/user", body.toString(), true);
      }, POOL);
   }

   /** Sends a password-reset email (only works if an email was linked). */
   public CompletableFuture<Void> requestPasswordReset(String email) {
      return CompletableFuture.runAsync(() -> {
         JsonObject body = new JsonObject();
         body.addProperty("email", email);
         send("POST", BlueBackend.URL + "/auth/v1/recover", body.toString(), false);
      }, POOL);
   }

   public CompletableFuture<Void> logOut() {
      return CompletableFuture.runAsync(() -> {
         try {
            if (this.accessToken != null) {
               send("POST", BlueBackend.URL + "/auth/v1/logout", "{}", true);
            }
         } catch (Exception ignored) {
            // Logging out locally matters more than telling the server.
         } finally {
            clearSession();
         }
      }, POOL);
   }

   /* ====================================================================== */
   /*  Data access                                                           */
   /* ====================================================================== */

   /** Calls a Postgres function (an RPC). */
   public CompletableFuture<JsonElement> rpc(String name, JsonObject args) {
      return CompletableFuture.supplyAsync(() -> {
         ensureFreshToken();
         return send("POST", BlueBackend.URL + "/rest/v1/rpc/" + name,
            args == null ? "{}" : args.toString(), true);
      }, POOL);
   }

   /** Runs a PostgREST SELECT. {@code query} is the part after the '?'. */
   public CompletableFuture<JsonArray> select(String table, String query) {
      return CompletableFuture.supplyAsync(() -> {
         ensureFreshToken();
         JsonElement e = send("GET",
            BlueBackend.URL + "/rest/v1/" + table + "?" + query, null, true);
         return e != null && e.isJsonArray() ? e.getAsJsonArray() : new JsonArray();
      }, POOL);
   }

   public CompletableFuture<Void> insert(String table, JsonObject row) {
      return CompletableFuture.runAsync(() -> {
         ensureFreshToken();
         send("POST", BlueBackend.URL + "/rest/v1/" + table, row.toString(), true);
      }, POOL);
   }

   public CompletableFuture<Void> patch(String table, String query, JsonObject values) {
      return CompletableFuture.runAsync(() -> {
         ensureFreshToken();
         send("PATCH", BlueBackend.URL + "/rest/v1/" + table + "?" + query,
            values.toString(), true);
      }, POOL);
   }

   public CompletableFuture<Void> delete(String table, String query) {
      return CompletableFuture.runAsync(() -> {
         ensureFreshToken();
         send("DELETE", BlueBackend.URL + "/rest/v1/" + table + "?" + query, null, true);
      }, POOL);
   }

   /**
    * Calls a Supabase Edge Function.
    *
    * <p>Edge Functions live at a different path than the database API and are
    * how we run code the player cannot tamper with - the Minecraft ownership
    * check in {@code verify-minecraft} is the reason this exists.</p>
    */
   public CompletableFuture<JsonElement> edgeFunction(String name, JsonObject body) {
      return CompletableFuture.supplyAsync(() -> {
         ensureFreshToken();
         return send("POST", BlueBackend.URL + "/functions/v1/" + name,
            body == null ? "{}" : body.toString(), true);
      }, POOL);
   }

   public static String enc(String s) {
      return URLEncoder.encode(s, StandardCharsets.UTF_8);
   }

   /* ====================================================================== */
   /*  The one method that actually performs a request                       */
   /* ====================================================================== */

   private JsonElement send(String method, String url, String body, boolean auth) {
      try {
         HttpRequest.Builder b = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .timeout(TIMEOUT)
            .header("apikey", BlueBackend.ANON_KEY)
            .header("Content-Type", "application/json")
            // Ask PostgREST to return the row(s) it wrote, and to not send
            // back huge payloads we do not use.
            .header("Prefer", "return=representation");

         if (auth && this.accessToken != null) {
            b.header("Authorization", "Bearer " + this.accessToken);
         } else {
            b.header("Authorization", "Bearer " + BlueBackend.ANON_KEY);
         }

         HttpRequest.BodyPublisher pub = body == null
            ? HttpRequest.BodyPublishers.noBody()
            : HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8);
         b.method(method, pub);

         HttpResponse<String> res = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString());
         String text = res.body();

         if (res.statusCode() / 100 != 2) {
            throw new BackendException(errorMessage(res.statusCode(), text));
         }
         if (text == null || text.isBlank()) {
            return null;
         }
         return JsonParser.parseString(text);

      } catch (BackendException be) {
         throw be;
      } catch (java.net.http.HttpTimeoutException te) {
         throw new BackendException("Friends services are currently unavailable.");
      } catch (java.net.ConnectException | java.net.UnknownHostException ne) {
         throw new BackendException("Friends services are currently unavailable.");
      } catch (Exception e) {
         BlueClient.LOGGER.debug("[Social] request failed: {}", url, e);
         throw new BackendException("Friends services are currently unavailable.");
      }
   }

   /**
    * Turns a Supabase error body into something a player can act on.
    * Supabase uses several different error shapes, so we try each.
    */
   private static String errorMessage(int status, String body) {
      try {
         JsonElement e = JsonParser.parseString(body == null ? "" : body);
         if (e != null && e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            for (String key : new String[] {"msg", "message", "error_description", "error", "hint", "details"}) {
               if (o.has(key) && o.get(key).isJsonPrimitive()) {
                  String v = o.get(key).getAsString();
                  if (v != null && !v.isBlank()) {
                     return friendly(status, v);
                  }
               }
            }
         }
      } catch (Exception ignored) {
         // fall through to the generic message
      }
      return friendly(status, "HTTP " + status);
   }

   private static String friendly(int status, String raw) {
      String low = raw.toLowerCase(java.util.Locale.ROOT);

      // Translate the few database errors a player can actually cause.
      if (low.contains("profiles_username_low_key") || low.contains("duplicate key")) {
         return "That username is already taken.";
      }
      if (low.contains("friend_requests_unique_pair")) {
         return "You already sent them a request.";
      }
      if (low.contains("violates row-level security")) {
         return "They are not accepting friend requests.";
      }
      if (low.contains("profiles_username_format")) {
         return "Usernames must be 3-16 letters, numbers or underscores.";
      }
      if (status == 401 || status == 403) {
         return "Please log in again.";
      }
      if (status == 429) {
         return "Too many attempts. Please wait a moment.";
      }
      if (status >= 500) {
         return "Friends services are currently unavailable.";
      }
      return raw;
   }
}
