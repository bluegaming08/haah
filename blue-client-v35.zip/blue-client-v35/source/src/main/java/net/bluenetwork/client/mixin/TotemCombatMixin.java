package net.bluenetwork.client.mixin;

import net.bluenetwork.client.util.TotemTracker;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tells {@link TotemTracker} who you are fighting.
 *
 * <p>Observes your own outgoing attacks — the tracker uses the most recent one
 * to decide whose totem count to display. Purely a read of an action you
 * already performed; it does not attack anything itself.</p>
 */
@Mixin(ClientPlayerInteractionManager.class)
public abstract class TotemCombatMixin {

   @Inject(
      method = "attackEntity(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;)V",
      at = @At("HEAD"),
      require = 0
   )
   private void blueclient$trackOpponent(PlayerEntity player, Entity target, CallbackInfo ci) {
      try {
         TotemTracker.onCombatWith(target);
      } catch (Throwable ignored) {
      }
   }
}
