package net.bluenetwork.client.mixin;

import net.minecraft.entity.passive.AbstractHorseEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Horses module (v0.19.0): reads the protected breeding jump strength stat. */
@Mixin(AbstractHorseEntity.class)
public interface AbstractHorseAccessor {
   @Accessor("jumpStrength")
   float blueclient$getJumpStrength();
}
