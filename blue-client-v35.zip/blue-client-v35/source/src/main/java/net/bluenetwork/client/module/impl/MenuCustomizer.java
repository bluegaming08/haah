package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;

/**
 * "Menu Customizer" — the modules menu's own appearance settings, expressed
 * as a regular module instead of a fixed settings-screen block.
 *
 * <p>This is deliberately optional (feedback 2026-09-10): while this module
 * is <b>disabled</b> the menu uses fixed, sane defaults (100% scale, 10%
 * opacity, roundness 16, dim 70%, shadow on, LIST layout, white icons/text).
 * Enable it to unlock every slider below and have the modules menu itself
 * follow them live — same pattern as any other module: toggle + gear +
 * settings page, nothing new to learn.</p>
 */
public class MenuCustomizer extends Module {
   /* ---- hardcoded defaults used while this module is OFF ---- */
   public static final int DEFAULT_SCALE = 100;
   public static final int DEFAULT_OPACITY = 0;
   public static final int DEFAULT_ROUNDNESS = 24;
   public static final int DEFAULT_DIM = 20;
   public static final boolean DEFAULT_SHADOW = true;
   public static final String DEFAULT_STYLE = "LIST";
   public static final int DEFAULT_ICON_COLOR = 0xFFFFFF;
   public static final int DEFAULT_TEXT_COLOR = 0xFFFFFF;

   private final ModeSetting style;
   private final NumberSetting scale;
   private final NumberSetting opacity;
   private final NumberSetting roundness;
   private final NumberSetting dim;
   private final BooleanSetting shadow;
   private final ColorSetting iconColor;
   private final ColorSetting textColor;
   private final BooleanSetting fiveFont;

   public MenuCustomizer() {
      super("Menu Customizer", "Customize the modules menu's look — optional, off by default", Category.MISC);
      this.style = new ModeSetting("Menu Style", "LIST rows or a responsive CARDS grid", List.of("LIST", "CARDS"), DEFAULT_STYLE);
      this.scale = new NumberSetting("Menu Scale", "Overall size of the modules menu, 90% - 100%", DEFAULT_SCALE, 90.0, 100.0, 1.0);
      this.opacity = new NumberSetting("Menu Opacity", "Panel opacity — low values look glassy", DEFAULT_OPACITY, 0.0, 100.0, 5.0);
      this.roundness = new NumberSetting("Menu Roundness", "Corner roundness of panels, rows and cards", DEFAULT_ROUNDNESS, 0.0, 24.0, 2.0);
      this.dim = new NumberSetting("Menu Dim", "How much the background behind the menu darkens", DEFAULT_DIM, 0.0, 100.0, 10.0);
      this.shadow = new BooleanSetting("Menu Shadow", "Drop shadow behind the menu panel", DEFAULT_SHADOW);
      this.iconColor = new ColorSetting("Icon Color", "Color of module icons", DEFAULT_ICON_COLOR);
      this.textColor = new ColorSetting("Text Color", "Color of module names and menu text", DEFAULT_TEXT_COLOR);
      this.fiveFont = new BooleanSetting("Five Bold Font", "Draw menu text in Minecraft Five Bold instead of the classic font", false);
      this.addSettings(this.style, this.scale, this.opacity, this.roundness, this.dim, this.shadow, this.iconColor, this.textColor, this.fiveFont);
   }

   /** True when menus should draw their classic-font text in Minecraft Five Bold. */
   public static boolean fiveFontEnabled() {
      try {
         for (net.bluenetwork.client.module.Module m : net.bluenetwork.client.BlueClient.getInstance().moduleManager().getModules()) {
            if (m instanceof MenuCustomizer mc && mc.fiveFont != null) {
               return mc.fiveFont.get();
            }
         }
      } catch (Throwable ignored) {
      }
      return false;
   }

   public String style() {
      return this.style.get();
   }

   public int scalePercent() {
      return (int) Math.round(this.scale.get());
   }

   public int opacityPercent() {
      return (int) Math.round(this.opacity.get());
   }

   public int roundnessValue() {
      return (int) Math.round(this.roundness.get());
   }

   public int dimPercent() {
      return (int) Math.round(this.dim.get());
   }

   public boolean shadowEnabled() {
      return this.shadow.get();
   }

   public int iconArgb(long now) {
      return 0xFF000000 | (this.iconColor.currentRgb(now) & 0xFFFFFF);
   }

   public int textArgb(long now) {
      return 0xFF000000 | (this.textColor.currentRgb(now) & 0xFFFFFF);
   }

   /*
    * v0.24.2: lets the menus tell "the owner chose a colour" apart from "this
    * is just the default white". Without this the WHITE theme could not make
    * module names dark, because the default white looked like a deliberate
    * choice. Rainbow mode always counts as customised.
    */

   /** True when the icon colour differs from the built-in default. */
   public boolean iconColorCustomised() {
      return colorCustomised(this.iconColor, DEFAULT_ICON_COLOR);
   }

   /** True when the text colour differs from the built-in default. */
   public boolean textColorCustomised() {
      return colorCustomised(this.textColor, DEFAULT_TEXT_COLOR);
   }

   private static boolean colorCustomised(ColorSetting setting, int defaultRgb) {
      if (setting == null) {
         return false;
      }
      if (setting.rainbowEnabled()) {
         return true;
      }
      return (setting.currentRgb(0L) & 0xFFFFFF) != (defaultRgb & 0xFFFFFF);
   }
}
