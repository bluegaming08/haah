package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.theme.ThemePalette;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * HUD Editor v5 (v0.24.0).
 *
 * <h2>What the owner asked for</h2>
 * <pre>
 *   in hud editor, there should be a remove hud (that disables the module but
 *   saves the location so whenever i enable the module again, the hud is where
 *   it was)
 *
 *   in hud editor there should be a small name above the module saying what
 *   module this hud is for
 *
 *   in hud editor, i should be able to scale the huds how small or big i want,
 *   just set a limit so i dont break my game
 * </pre>
 *
 * <h2>Controls</h2>
 * <pre>
 *   left-drag      move
 *   scroll wheel   scale the HUD under the cursor (0.5x .. 3.0x)
 *   right-click    reset position AND scale
 *   gear icon      open that module's settings
 *   X icon         REMOVE (disable the module, keep its position)
 *   R              show/hide the removed-HUD tray
 *   ESC            save and exit
 * </pre>
 *
 * <h2>Why "remove" is just setEnabled(false)</h2>
 * Position lives on the {@link HudModule} itself — a long-lived singleton that
 * {@code ConfigManager} persists regardless of enabled state. So disabling a
 * module already preserves where its HUD was, and re-enabling restores it
 * exactly. This is documented because it looks like a missing feature: a future
 * agent might "fix" it by adding a separate position store, which would create
 * two sources of truth and an actual bug.
 */
public class HudEditScreen extends Screen {

   /** Extra grab margin around a HUD box, in pixels. */
   private static final int HANDLE = 4;

   /** Icon button size (gear / remove). */
   private static final int ICON = 12;

   /** Scale limits — "just set a limit so i dont break my game". */
   private static final float MIN_SCALE = 0.5F;
   private static final float MAX_SCALE = 3.0F;
   private static final float SCALE_STEP = 0.1F;

   /*
    * v0.24.1 CORNER RESIZE HANDLES
    * -----------------------------
    * Owner: "in the hud editor, the 4 corner things should only be there when
    *         you hover over it or your mouse is near it and you should be able
    *         to drag them to scale the hud"
    *
    * So:
    *  - The corner brackets fade in with PROXIMITY (see #proximity) instead of
    *    being painted on every HUD all the time. At rest the editor is clean.
    *  - When a HUD is hovered, each corner also gets a solid GRAB SQUARE. Drag
    *    any of them and the HUD scales around its OPPOSITE corner, which is how
    *    every image editor behaves and keeps the anchor point stable.
    *  - Scroll wheel still scales (it is faster for small nudges).
    */

   /** Size in pixels of a square corner grab handle. */
   private static final int GRAB = 6;

   /** Distance (px) from a HUD box at which its brackets start fading in. */
   private static final float NEAR = 48.0F;

   private final Screen parent;
   private HudModule dragging;
   private int grabDx;
   private int grabDy;

   /** HUD currently being resized by a corner handle, or null. */
   private HudModule resizing;

   /** Which corner is held: 0=TL, 1=TR, 2=BL, 3=BR. */
   private int resizeCorner;

   /** Scale the HUD had when the resize drag started. */
   private float resizeStartScale;

   /** Diagonal length (px) from the anchor corner to the cursor at drag start. */
   private float resizeStartDist;

   /** True while the removed-HUD tray is expanded. */
   private boolean showRemoved;

   public HudEditScreen(BlueClient blue, Screen parent) {
      this(parent);
   }

   public HudEditScreen(Screen parent) {
      super(Text.literal("HUD Editor"));
      this.parent = parent;
   }

   /* ===================================================================== */
   /* Module lists                                                          */
   /* ===================================================================== */

   /** Enabled HUD modules — the ones you can move. */
   private List<HudModule> huds() {
      List<HudModule> out = new ArrayList<>();
      for (Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof HudModule hud && hud.isEnabled()) {
            out.add(hud);
         }
      }
      return out;
   }

   /** Disabled HUD modules — shown in the removed tray. */
   private List<HudModule> removedHuds() {
      List<HudModule> out = new ArrayList<>();
      for (Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof HudModule hud && !hud.isEnabled()) {
            out.add(hud);
         }
      }
      return out;
   }

   /* ===================================================================== */
   /* Lifecycle                                                             */
   /* ===================================================================== */

   @Override
   public void close() {
      this.saveAndExit();
   }

   private void saveAndExit() {
      BlueClient.getInstance().configManager().save();
      MinecraftClient.getInstance().setScreen(this.parent);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
         this.saveAndExit();
         return true;
      }
      if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_R) {
         this.showRemoved = !this.showRemoved;
         RenderUtil.clickSound();
         return true;
      }
      return super.keyPressed(input);
   }

   /* ===================================================================== */
   /* Geometry                                                              */
   /* ===================================================================== */

   /**
    * Null-safe size probe, multiplied by the module's scale so the editor box
    * matches what is actually drawn. HUDs that need a live player can throw
    * when the editor is opened from the main menu — that used to crash.
    */
   private int safeWidth(HudModule hud) {
      try {
         return Math.max(6, Math.round(hud.getWidthCached() * hud.getScale()));
      } catch (Throwable t) {
         return 40;
      }
   }

   private int safeHeight(HudModule hud) {
      try {
         return Math.max(6, Math.round(hud.getHeightCached() * hud.getScale()));
      } catch (Throwable t) {
         return 12;
      }
   }

   /** Gear icon: just outside the top-right corner, flipped inside if clipped. */
   private int gearX(HudModule hud) {
      int x = hud.getX() + this.safeWidth(hud);
      return x + ICON + 3 > this.width ? hud.getX() + this.safeWidth(hud) - ICON - 2 : x + 3;
   }

   private int iconY(HudModule hud) {
      int y = hud.getY() - ICON + 2;
      return y < 2 ? hud.getY() + 2 : y;
   }

   /** Remove icon: immediately left of the gear. */
   private int removeX(HudModule hud) {
      return this.gearX(hud) - ICON - 3;
   }

   private boolean inIcon(int iconX, int iconY, int mx, int my) {
      return mx >= iconX && mx <= iconX + ICON && my >= iconY && my <= iconY + ICON;
   }

   /**
    * How "close" the mouse is to a HUD box, as 0..1.
    *
    * <p>1 means the cursor is inside the box, 0 means it is {@link #NEAR} or
    * more pixels away. Used to fade the corner brackets in and out so the
    * editor only shows chrome for the HUD you are actually reaching for.</p>
    */
   private float proximity(HudModule hud, int mx, int my) {
      int x = hud.getX();
      int y = hud.getY();
      int w = this.safeWidth(hud);
      int h = this.safeHeight(hud);
      // Distance from the point to the rectangle (0 when inside).
      float ddx = Math.max(Math.max(x - mx, mx - (x + w)), 0);
      float ddy = Math.max(Math.max(y - my, my - (y + h)), 0);
      float dist = (float) Math.sqrt(ddx * ddx + ddy * ddy);
      return Math.max(0.0F, 1.0F - dist / NEAR);
   }

   /** Top-left pixel of corner handle {@code corner} (0=TL,1=TR,2=BL,3=BR). */
   private int handleX(HudModule hud, int corner) {
      int x = hud.getX();
      return (corner == 1 || corner == 3) ? x + this.safeWidth(hud) - GRAB / 2 : x - GRAB / 2;
   }

   private int handleY(HudModule hud, int corner) {
      int y = hud.getY();
      return (corner == 2 || corner == 3) ? y + this.safeHeight(hud) - GRAB / 2 : y - GRAB / 2;
   }

   /** True if the cursor is on corner handle {@code corner} of {@code hud}. */
   private boolean onHandle(HudModule hud, int corner, int mx, int my) {
      int hx = this.handleX(hud, corner);
      int hy = this.handleY(hud, corner);
      // A couple of px of slack - 6px targets are fiddly at high resolutions.
      return mx >= hx - 2 && mx <= hx + GRAB + 2 && my >= hy - 2 && my <= hy + GRAB + 2;
   }

   /** Topmost HUD under the cursor, or null. */
   private HudModule pick(int mx, int my) {
      List<HudModule> list = this.huds();
      for (int i = list.size() - 1; i >= 0; i--) {
         HudModule hud = list.get(i);
         int x = hud.getX();
         int y = hud.getY();
         if (mx >= x - HANDLE && mx <= x + this.safeWidth(hud) + HANDLE
            && my >= y - HANDLE && my <= y + this.safeHeight(hud) + HANDLE) {
            return hud;
         }
      }
      return null;
   }

   /* ===================================================================== */
   /* Input                                                                 */
   /* ===================================================================== */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) click.x();
      int my = (int) click.y();

      if (click.button() == 0) {
         if (this.showRemoved && this.clickRemovedTray(mx, my)) {
            return true;
         }

         List<HudModule> list = this.huds();
         for (int i = list.size() - 1; i >= 0; i--) {
            HudModule hud = list.get(i);
            int iy = this.iconY(hud);

            // REMOVE: disables the module. Position is untouched, so
            // re-enabling puts the HUD back exactly where it was.
            if (this.inIcon(this.removeX(hud), iy, mx, my)) {
               RenderUtil.clickSound();
               hud.setEnabled(false);
               BlueClient.getInstance().configManager().save();
               BlueClient.getInstance().notificationManager()
                  .add(hud.getName() + " » removed (press R to restore)",
                     ThemeManager.palette().toggleOff());
               return true;
            }

            if (this.inIcon(this.gearX(hud), iy, mx, my)) {
               RenderUtil.clickSound();
               MinecraftClient.getInstance().setScreen(
                  new ModuleSettingsScreen(BlueClient.getInstance(), this, hud));
               return true;
            }
         }

         /*
          * Corner handles win over the move-drag: they sit ON the edge of the
          * box, so without this check grabbing a corner would just move it.
          */
         for (int i = list.size() - 1; i >= 0; i--) {
            HudModule hud = list.get(i);
            if (this.proximity(hud, mx, my) <= 0.0F) {
               continue;
            }
            for (int corner = 0; corner < 4; corner++) {
               if (!this.onHandle(hud, corner, mx, my)) {
                  continue;
               }
               this.resizing = hud;
               this.resizeCorner = corner;
               this.resizeStartScale = hud.getScale();
               this.resizeStartDist = Math.max(1.0F, this.anchorDistance(hud, corner, mx, my));
               RenderUtil.clickSound();
               return true;
            }
         }

         HudModule hud = this.pick(mx, my);
         if (hud != null) {
            this.dragging = hud;
            this.grabDx = mx - hud.getX();
            this.grabDy = my - hud.getY();
            RenderUtil.clickSound();
            return true;
         }
      } else if (click.button() == 1) {
         HudModule hud = this.pick(mx, my);
         if (hud != null) {
            hud.resetPosition();
            hud.setScale(1.0F);
            RenderUtil.clickSound();
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   /** Handles a click in the removed tray; returns true if consumed. */
   private boolean clickRemovedTray(int mx, int my) {
      int x = 8;
      int y = this.height - 46;
      for (HudModule hud : this.removedHuds()) {
         int w = RenderUtil.textWidth(hud.getName()) + 14;
         if (x + w > this.width - 8) {
            x = 8;
            y -= 14;
         }
         if (mx >= x && mx <= x + w && my >= y && my <= y + 12) {
            RenderUtil.clickSound();
            hud.setEnabled(true);
            BlueClient.getInstance().configManager().save();
            return true;
         }
         x += w + 4;
      }
      return false;
   }

   @Override
   public boolean mouseDragged(Click click, double dx, double dy) {
      /*
       * Resizing: the HUD's OPPOSITE corner stays pinned, and the new scale is
       * the start scale multiplied by how much further the cursor has moved
       * away from that anchor. Using the diagonal distance (rather than dx or
       * dy alone) means the HUD tracks the mouse naturally in both axes.
       */
      if (this.resizing != null) {
         float now = this.anchorDistance(this.resizing, this.resizeCorner, (int) click.x(), (int) click.y());
         float scale = this.resizeStartScale * (now / this.resizeStartDist);
         this.resizing.setScale(Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale)));
         // Keep it on screen after the size change.
         this.clampIntoScreen(this.resizing);
         return true;
      }

      if (this.dragging != null) {
         int nx = (int) click.x() - this.grabDx;
         int ny = (int) click.y() - this.grabDy;
         int maxX = this.width - this.safeWidth(this.dragging) - 2;
         int maxY = this.height - this.safeHeight(this.dragging) - 2;
         this.dragging.setPosition(
            Math.max(2, Math.min(maxX, nx)),
            Math.max(2, Math.min(maxY, ny)),
            this.width, this.height);
         return true;
      }
      return super.mouseDragged(click, dx, dy);
   }

   @Override
   public boolean mouseReleased(Click click) {
      if (this.resizing != null) {
         this.resizing = null;
         BlueClient.getInstance().configManager().save();
         RenderUtil.clickSound();
         return true;
      }
      if (this.dragging != null) {
         this.dragging = null;
         BlueClient.getInstance().configManager().save();
         RenderUtil.clickSound();
         return true;
      }
      return super.mouseReleased(click);
   }

   /**
    * Scroll wheel scales the HUD under the cursor.
    *
    * <p>Clamped to {@link #MIN_SCALE}..{@link #MAX_SCALE}: an unbounded scale
    * lets one HUD cover the screen and blows up the text-render cache, which
    * is what "don't break my game" is guarding against.</p>
    */
   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
      HudModule hud = this.pick((int) mouseX, (int) mouseY);
      if (hud != null && vertical != 0.0) {
         float next = hud.getScale() + (float) Math.signum(vertical) * SCALE_STEP;
         hud.setScale(Math.max(MIN_SCALE, Math.min(MAX_SCALE, next)));
         BlueClient.getInstance().configManager().save();
         return true;
      }
      return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
   }

   /**
    * Distance from the cursor to the corner OPPOSITE the one being dragged.
    *
    * <p>That opposite corner is the anchor the HUD grows away from, so this
    * distance is directly proportional to the desired scale.</p>
    */
   private float anchorDistance(HudModule hud, int corner, int mx, int my) {
      int ax = this.handleX(hud, 3 - corner) + GRAB / 2;
      int ay = this.handleY(hud, 3 - corner) + GRAB / 2;
      float ddx = mx - ax;
      float ddy = my - ay;
      return (float) Math.sqrt(ddx * ddx + ddy * ddy);
   }

   /** Nudges a HUD back inside the screen after a scale change. */
   private void clampIntoScreen(HudModule hud) {
      int maxX = Math.max(2, this.width - this.safeWidth(hud) - 2);
      int maxY = Math.max(2, this.height - this.safeHeight(hud) - 2);
      hud.setPosition(
         Math.max(2, Math.min(maxX, hud.getX())),
         Math.max(2, Math.min(maxY, hud.getY())),
         this.width, this.height);
   }

   /* ===================================================================== */
   /* Rendering                                                             */
   /* ===================================================================== */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      ThemePalette p = ThemeManager.palette();

      for (HudModule hud : this.huds()) {
         int x = hud.getX();
         int y = hud.getY();
         int w = this.safeWidth(hud);
         int h = this.safeHeight(hud);
         boolean hovered = mouseX >= x - HANDLE && mouseX <= x + w + HANDLE
            && mouseY >= y - HANDLE && mouseY <= y + h + HANDLE;

         /*
          * Brackets + handles only when the mouse is near (owner request).
          * A HUD being actively dragged/resized always shows them, otherwise
          * the chrome would vanish the moment the cursor left the box.
          */
         boolean active = this.dragging == hud || this.resizing == hud;
         float near = active ? 1.0F : this.proximity(hud, mouseX, mouseY);

         if (near > 0.0F) {
            int alpha = (int) (255 * near);
            this.drawBrackets(context, x, y, w, h, ThemePalette.withAlpha(p.accent(), alpha));
            this.drawCornerHandles(context, hud, mouseX, mouseY, alpha, p);
         }

         /* --- module NAME label above the box (owner request) ---
            Drawn above when there is room, otherwise tucked inside the top of
            the box so HUDs pinned to y=0 still show their label. */
         String name = hud.getName();
         int labelW = RenderUtil.textWidth(name) + 6;
         int labelY = y - 11 < 1 ? y + 1 : y - 11;
         SmoothRect.fill(context, x, labelY, labelW, 10, 2.0F,
            hovered ? p.accent() : ThemePalette.withAlpha(p.panelBg(), 220));
         RenderUtil.drawText(context, name, x + 3, labelY + 1,
            hovered ? p.textOnAccent() : p.textHi());

         /* --- scale badge, only while hovered so it is not visual noise --- */
         if (hovered && Math.abs(hud.getScale() - 1.0F) > 0.001F) {
            String scale = String.format(java.util.Locale.ROOT, "%.1fx", hud.getScale());
            int sw = RenderUtil.textWidth(scale) + 6;
            SmoothRect.fill(context, x + w - sw, y + h + 2, sw, 10, 2.0F,
               ThemePalette.withAlpha(p.panelBg(), 220));
            RenderUtil.drawText(context, scale, x + w - sw + 3, y + h + 3, p.textMid());
         }

         /* --- icon buttons: also proximity-gated --- */
         if (near <= 0.0F) {
            continue;
         }

         int iy = this.iconY(hud);
         int gx = this.gearX(hud);
         int rx = this.removeX(hud);

         boolean gearHover = this.inIcon(gx, iy, mouseX, mouseY);
         SmoothRect.fill(context, gx - 2, iy - 2, ICON + 4, ICON + 4, 2.0F,
            gearHover ? p.accent() : ThemePalette.withAlpha(p.panelBg(), 200));
         RenderUtil.drawIcon(context, "settings", gx, iy, ICON,
            gearHover ? p.textOnAccent() : p.textMid());

         boolean removeHover = this.inIcon(rx, iy, mouseX, mouseY);
         SmoothRect.fill(context, rx - 2, iy - 2, ICON + 4, ICON + 4, 2.0F,
            removeHover ? p.toggleOff() : ThemePalette.withAlpha(p.panelBg(), 200));
         RenderUtil.drawIcon(context, "x", rx, iy, ICON,
            removeHover ? 0xFFFFFFFF : p.textMid());
      }

      this.renderRemovedTray(context, mouseX, mouseY);
      this.renderHelpBar(context);
   }

   /**
    * Draws the four square grab handles used to scale a HUD.
    *
    * <p>The hovered handle is filled with the accent colour so it is obvious
    * which one you are about to grab.</p>
    */
   private void drawCornerHandles(DrawContext context, HudModule hud, int mx, int my,
         int alpha, ThemePalette p) {
      for (int corner = 0; corner < 4; corner++) {
         int hx = this.handleX(hud, corner);
         int hy = this.handleY(hud, corner);
         boolean on = this.onHandle(hud, corner, mx, my) || this.resizing == hud;
         context.fill(hx, hy, hx + GRAB, hy + GRAB,
            ThemePalette.withAlpha(on ? p.accent() : p.textHi(), alpha));
         context.fill(hx + 1, hy + 1, hx + GRAB - 1, hy + GRAB - 1,
            ThemePalette.withAlpha(on ? p.textOnAccent() : p.panelBg(), alpha));
      }
   }

   /** Corner brackets marking a draggable HUD. */
   private void drawBrackets(DrawContext context, int x, int y, int w, int h, int color) {
      int len = 7;
      context.fill(x - 1, y - 1, x + len, y, color);
      context.fill(x - 1, y - 1, x, y + len, color);
      context.fill(x + w - len, y - 1, x + w, y, color);
      context.fill(x + w, y - 1, x + w + 1, y + len, color);
      context.fill(x - 1, y + h, x + len, y + h + 1, color);
      context.fill(x - 1, y + h - len, x, y + h + 1, color);
      context.fill(x + w - len, y + h, x + w, y + h + 1, color);
      context.fill(x + w, y + h - len, x + w + 1, y + h + 1, color);
   }

   /** Tray of removed (disabled) HUDs; click a chip to bring one back. */
   private void renderRemovedTray(DrawContext context, int mouseX, int mouseY) {
      if (!this.showRemoved) {
         return;
      }
      ThemePalette p = ThemeManager.palette();
      List<HudModule> removed = this.removedHuds();
      if (removed.isEmpty()) {
         RenderUtil.drawText(context, "No removed HUDs", 8, this.height - 46, p.textMid());
         return;
      }
      RenderUtil.drawText(context, "REMOVED - click to restore", 8, this.height - 58, p.accent());
      int x = 8;
      int y = this.height - 46;
      for (HudModule hud : removed) {
         int w = RenderUtil.textWidth(hud.getName()) + 14;
         if (x + w > this.width - 8) {
            x = 8;
            y -= 14;
         }
         boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + 12;
         SmoothRect.fill(context, x, y, w, 12, 2.0F, hovered ? p.accent() : p.panelBg());
         RenderUtil.drawText(context, hud.getName(), x + 7, y + 2,
            hovered ? p.textOnAccent() : p.textMid());
         x += w + 4;
      }
   }

   private void renderHelpBar(DrawContext context) {
      RenderUtil.drawText(context,
         "DRAG move  ·  CORNERS resize  ·  SCROLL scale  ·  RIGHT-CLICK reset  ·  "
            + "X remove  ·  R removed list  ·  ESC save",
         6, this.height - 12, ThemeManager.palette().textMid());
   }
}
