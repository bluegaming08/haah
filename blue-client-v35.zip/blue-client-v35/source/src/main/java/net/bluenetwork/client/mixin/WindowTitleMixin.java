package net.bluenetwork.client.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public abstract class WindowTitleMixin {
   @Inject(
      method = {"updateWindowTitle"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$brandWindowTitle(CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      mc.getWindow().setTitle("Blue Client 1.21.11 (Beta)");
      ci.cancel();
   }
}
