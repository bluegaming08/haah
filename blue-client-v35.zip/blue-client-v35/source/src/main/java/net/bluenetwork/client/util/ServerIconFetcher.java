package net.bluenetwork.client.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Tiny dependency-free Minecraft STATUS ping used by the Server IP HUD to get
 * a server's favicon (the icon shown left of the address).
 *
 * <p>Vanilla only fills {@code ServerInfo.icon} for entries the multiplayer
 * screen has pinged, so a direct-join session has no icon to show. This
 * fetcher speaks the bare status protocol (handshake -> status request ->
 * JSON response) on a daemon thread and caches the decoded PNG bytes per
 * address. The status handshake does not validate the protocol version, so
 * one implementation serves every server version.</p>
 */
public final class ServerIconFetcher {
   private static final int TIMEOUT_MS = 5000;
   /** Cached results: address -> PNG bytes, or NULL_BYTES when the server has none. */
   private static final Map<String, byte[]> CACHE = new ConcurrentHashMap<>();
   private static final byte[] NULL_BYTES = new byte[0];
   private static final Map<String, Thread> IN_FLIGHT = new ConcurrentHashMap<>();

   private ServerIconFetcher() {
   }

   /** Requests the icon for {@code address} in the background (cached). */
   public static void request(String address) {
      if (address == null || address.isBlank() || CACHE.containsKey(address) || IN_FLIGHT.containsKey(address)) {
         return;
      }
      Thread worker = new Thread(() -> {
         try {
            byte[] png = ping(address);
            CACHE.put(address, png == null ? NULL_BYTES : png);
         } catch (Throwable t) {
            CACHE.put(address, NULL_BYTES);
         } finally {
            IN_FLIGHT.remove(address);
         }
      }, "Blue Client Server Icon");
      worker.setDaemon(true);
      IN_FLIGHT.put(address, worker);
      worker.start();
   }

   /** Cached PNG bytes for {@code address}, or null while unknown/pending. */
   public static byte[] cached(String address) {
      byte[] value = CACHE.get(address);
      return value == null || value.length == 0 ? null : value;
   }

   public static void invalidate(String address) {
      if (address != null) {
         CACHE.remove(address);
      }
   }

   /* ------------------------------------------------------- status ping */

   private static byte[] ping(String address) throws IOException {
      String host = address;
      int port = 25565;
      int colon = host.lastIndexOf(':');
      if (colon > 0 && host.indexOf(':', colon + 1) < 0) {
         String maybePort = host.substring(colon + 1);
         try {
            port = Integer.parseInt(maybePort);
            host = host.substring(0, colon);
         } catch (NumberFormatException ignored) {
            // not a port suffix (e.g. IPv6 literal) - keep default port
         }
      }

      try (Socket socket = new Socket()) {
         socket.connect(new InetSocketAddress(host, port), TIMEOUT_MS);
         socket.setSoTimeout(TIMEOUT_MS);
         DataOutputStream out = new DataOutputStream(socket.getOutputStream());
         DataInputStream in = new DataInputStream(socket.getInputStream());

         byte[] handshake = handshakePacket(host, port);
         writeVarIntPacket(out, handshake);
         writeVarIntPacket(out, new byte[]{0x00}); // status request

         byte[] response = readPacket(in);
         String json = new String(response, 1, response.length - 1, StandardCharsets.UTF_8);
         JsonObject root = JsonParser.parseString(json).getAsJsonObject();
         if (!root.has("favicon")) {
            return null;
         }
         String favicon = root.get("favicon").getAsString();
         int comma = favicon.indexOf(',');
         if (comma < 0 || !favicon.startsWith("data:")) {
            return null;
         }
         return Base64.getDecoder().decode(favicon.substring(comma + 1));
      }
   }

   private static byte[] handshakePacket(String host, int port) throws IOException {
      java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
      DataOutputStream out = new DataOutputStream(bytes);
      out.writeByte(0x00);                       // packet id: handshake
      writeVarInt(out, 770);                     // protocol version (status ignores it)
      writeString(out, host);
      out.writeShort(port);
      writeVarInt(out, 1);                       // next state: status
      return bytes.toByteArray();
   }

   private static void writeVarIntPacket(DataOutputStream out, byte[] body) throws IOException {
      writeVarInt(out, body.length);
      out.write(body);
      out.flush();
   }

   private static byte[] readPacket(DataInputStream in) throws IOException {
      int length = readVarInt(in);
      if (length <= 0 || length > 8 * 1024 * 1024) {
         throw new IOException("Bad status packet length " + length);
      }
      byte[] body = in.readNBytes(length);
      if (body.length != length) {
         throw new IOException("Truncated status packet");
      }
      return body;
   }

   private static void writeVarInt(DataOutputStream out, int value) throws IOException {
      int v = value;
      while (true) {
         if ((v & ~0x7F) == 0) {
            out.writeByte(v);
            return;
         }
         out.writeByte(v & 0x7F | 0x80);
         v >>>= 7;
      }
   }

   private static int readVarInt(DataInputStream in) throws IOException {
      int result = 0;
      int shift = 0;
      while (true) {
         int b = in.readUnsignedByte();
         result |= (b & 0x7F) << shift;
         if ((b & 0x80) == 0) {
            return result;
         }
         shift += 7;
         if (shift >= 32) {
            throw new IOException("VarInt too big");
         }
      }
   }

   private static void writeString(DataOutputStream out, String value) throws IOException {
      byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
      writeVarInt(out, bytes.length);
      out.write(bytes);
   }
}
