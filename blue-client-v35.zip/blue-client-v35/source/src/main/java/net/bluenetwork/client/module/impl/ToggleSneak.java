package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

public class ToggleSneak extends Module {
   private final BooleanSetting keepSneaking = new BooleanSetting("Always sneak", "Sneak the entire time the module is on", false);
   private boolean wasKeySneak = false;

   public ToggleSneak() {
      super("Toggle Sneak", "Toggles sneaking with one press", Category.MOVEMENT);
      this.addSettings(new Setting[]{this.keepSneaking});
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         KeyBinding sneakKey = mc.options.sneakKey;
         if (this.keepSneaking.get() && this.isEnabled()) {
            KeyBinding.setKeyPressed(sneakKey.getDefaultKey(), true);
            mc.player.setSneaking(true);
            this.wasKeySneak = true;
         } else if (this.wasKeySneak) {
            KeyBinding.setKeyPressed(sneakKey.getDefaultKey(), false);
            this.wasKeySneak = false;
         }
      }
   }

   @Override
   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (this.wasKeySneak) {
         KeyBinding.setKeyPressed(mc.options.sneakKey.getDefaultKey(), false);
         this.wasKeySneak = false;
      }
   }
}
