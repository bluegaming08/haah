package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.impl.NoHurtCam;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
   @Inject(
      method = {"tiltViewWhenHurt"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$noHurtCam(MatrixStack matrices, float partialTicks, CallbackInfo ci) {
      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         if (module instanceof NoHurtCam && module.isEnabled()) {
            ci.cancel();
            return;
         }
      }
   }
}
