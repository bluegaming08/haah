package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Chat Location - moves the in-game chat to any screen corner. Vanilla always
 * parks it bottom-left; this offsets the whole chat box, so it plays nice with
 * vanilla chat settings and ChatHeight.
 */
public class ChatLocation extends Module {
   public static final String BOTTOM_LEFT = "BOTTOM LEFT";
   public static final String TOP_LEFT = "TOP LEFT";
   public static final String BOTTOM_RIGHT = "BOTTOM RIGHT";
   public static final String TOP_RIGHT = "TOP RIGHT";

   private final ModeSetting position = new ModeSetting("Position", "Screen corner the chat sits in",
      List.of(BOTTOM_LEFT, TOP_LEFT, BOTTOM_RIGHT, TOP_RIGHT), BOTTOM_LEFT);

   public ChatLocation() {
      super("Chat Location", "Move the chat to any screen corner", Category.MISC);
      this.addSettings(new Setting[]{this.position});
   }

   public static String current() {
      ChatLocation self = Module.find(ChatLocation.class);
      return self != null && self.isEnabled() ? self.position.get() : BOTTOM_LEFT;
   }

   public static boolean relocate() {
      return !BOTTOM_LEFT.equals(current());
   }
}
