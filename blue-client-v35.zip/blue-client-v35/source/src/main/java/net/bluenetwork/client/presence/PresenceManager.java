package net.bluenetwork.client.presence;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.settings.ClientSettings;
import net.minecraft.client.MinecraftClient;

public class PresenceManager {
   private static final String HEARTBEAT_URL = "https://solene-2ebf28bd.base44.app/functions/bluePresenceHeartbeat";
   private static final String QUERY_URL = "https://solene-2ebf28bd.base44.app/functions/bluePresenceQuery";
   private static final long POLL_MS = 20000L;
   private static final long DISABLED_RETRY_MS = 120000L;
   private volatile Set<UUID> blueUsers = Set.of();
   private volatile boolean rejected = false;
   private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4L)).build();

   public void start() {
      Thread thread = new Thread(this::loop, "BlueClient-Presence");
      thread.setDaemon(true);
      thread.start();
   }

   private void loop() {
      while (true) {
         long sleep = this.rejected ? 120000L : 20000L;

         try {
            this.tick();
         } catch (Throwable var5) {
            BlueClient.LOGGER.debug("Presence tick failed", var5);
         }

         try {
            Thread.sleep(sleep);
         } catch (InterruptedException var4) {
            return;
         }
      }
   }

   private void tick() throws Exception {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientSettings settings = BlueClient.getInstance().settings();
      if (settings.presence() && mc.player != null && mc.getCurrentServerEntry() != null) {
         String server = mc.getCurrentServerEntry().address;
         UUID uuid = mc.player.getUuid();
         String username = mc.player.getGameProfile().name();
         this.post(
            "https://solene-2ebf28bd.base44.app/functions/bluePresenceHeartbeat",
            "{\"uuid\":\"" + uuid + "\",\"username\":\"" + escape(username) + "\",\"server\":\"" + escape(server) + "\"}"
         );
         String response = this.post("https://solene-2ebf28bd.base44.app/functions/bluePresenceQuery", "{\"server\":\"" + escape(server) + "\"}");
         Set<UUID> found = new HashSet<>();
         JsonObject json = JsonParser.parseString(response).getAsJsonObject();
         if (json.has("users")) {
            for (JsonElement element : json.getAsJsonArray("users")) {
               JsonObject user = element.getAsJsonObject();

               try {
                  found.add(UUID.fromString(user.get("uuid").getAsString()));
               } catch (IllegalArgumentException var13) {
               }
            }
         }

         found.add(uuid);
         this.blueUsers = Set.copyOf(found);
      } else {
         this.blueUsers = mc.player != null ? Set.of(mc.player.getUuid()) : Set.of();
      }
   }

   private String post(String url, String jsonBody) throws Exception {
      HttpRequest request = HttpRequest.newBuilder()
         .uri(URI.create(url))
         .timeout(Duration.ofSeconds(4L))
         .header("Content-Type", "application/json")
         .POST(BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
         .build();
      HttpResponse<String> response = this.http.send(request, BodyHandlers.ofString());
      if (response.statusCode() != 401 && response.statusCode() != 403) {
         this.rejected = false;
         if (response.statusCode() / 100 != 2) {
            throw new IllegalStateException("Presence API HTTP " + response.statusCode());
         } else {
            return response.body();
         }
      } else {
         this.rejected = true;
         throw new IllegalStateException("Presence API rejected the request (" + response.statusCode() + ")");
      }
   }

   public boolean isBlueClientUser(UUID uuid) {
      if (uuid == null) {
         return false;
      }
      // Your own badge shows instantly, always - even while the presence
      // API is unreachable (private app / 403 / offline).
      net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
      if (mc != null && mc.player != null && uuid.equals(mc.player.getUuid())) {
         return true;
      }
      return this.blueUsers.contains(uuid);
   }

   private static String escape(String s) {
      return s.replace("\\", "\\\\").replace("\"", "\\\"");
   }
}
