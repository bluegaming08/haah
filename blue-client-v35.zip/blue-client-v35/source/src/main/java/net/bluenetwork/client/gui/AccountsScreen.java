package net.bluenetwork.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.account.Account;
import net.bluenetwork.client.account.AccountManager;
import net.bluenetwork.client.account.MsAuth;
import net.bluenetwork.client.account.PlayerHeads;
import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.bluenetwork.client.ui.theme.ThemePalette;
import net.bluenetwork.client.ui.widget.PremiumButton;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Account manager.
 *
 * <h2>v0.24.3 revamp</h2>
 * Owner: "revamp the account manager menu" + "use the mc-api.io BUST render".
 *
 * <p>The old screen was a stack of 17 px bordered strips drawn with raw
 * {@code context.fill} calls, using a flat 8×8 face slice for the avatar. It
 * ignored the theme system entirely.</p>
 *
 * <p>This version is a <b>card grid</b>:</p>
 * <ul>
 *   <li>each account is a tile with its 3D bust render from mc-api.io
 *       ({@link PlayerHeads}), the username, and an MSA/OFFLINE chip;</li>
 *   <li>the active account is marked with an accent border and a check;</li>
 *   <li>a dashed "+" tile opens the add menu, so adding is discoverable
 *       instead of being a button hidden under the list;</li>
 *   <li>remove is an × button on the tile (right-click still works);</li>
 *   <li>everything draws through {@code DesignTokens} / {@link PremiumButton},
 *       so Black / Glass / White all apply.</li>
 * </ul>
 *
 * <p>Layout is computed from the window size each frame — no fixed 180 px
 * column — so it adapts to GUI scale instead of overflowing.</p>
 */
public class AccountsScreen extends Screen {

   /** Tile geometry (virtual px, before GUI scale). */
   private static final int TILE_W = 104;
   private static final int TILE_H = 124;
   private static final int TILE_GAP = 10;

   private final Screen parent;
   private final List<Hit> hits = new ArrayList<>();

   private boolean typingName = false;
   private String typedName = "";
   private String notice = "";
   private long noticeAtMs = 0L;
   private MsAuth.State msState = null;

   public AccountsScreen(Screen parent) {
      super(Text.literal("Accounts"));
      this.parent = parent;
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   private AccountManager accounts() {
      return BlueClient.getInstance().accountManager();
   }

   private void say(String message) {
      this.notice = message == null ? "" : message;
      this.noticeAtMs = System.currentTimeMillis();
   }

   /* ===================================================================== */
   /* Rendering                                                             */
   /* ===================================================================== */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      this.hits.clear();
      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();
      ThemePalette p = ThemeManager.palette();

      context.fill(0, 0, width, height, DesignTokens.scrim());

      /* ---- header ---- */
      TextPainter.drawPoppins(context, "ACCOUNTS",
         width / 2.0F - TextPainter.poppinsWidth("ACCOUNTS", 16.0F) / 2.0F, 16, p.textHi(), 16.0F);
      String sub = "Playing as " + this.accounts().currentUsername();
      TextPainter.drawPoppins(context, sub,
         width / 2.0F - TextPainter.poppinsWidth(sub, 9.0F) / 2.0F, 36, p.textMid(), 9.0F);

      /* ---- tile grid ---- */
      List<Account> list = this.accounts().getAccounts();
      int tiles = list.size() + 1;                       // +1 for the "add" tile
      int perRow = Math.max(1, Math.min(tiles, (width - 40) / (TILE_W + TILE_GAP)));
      int rows = (tiles + perRow - 1) / perRow;
      int gridW = perRow * TILE_W + (perRow - 1) * TILE_GAP;
      int startX = (width - gridW) / 2;
      int startY = 58;

      for (int i = 0; i < list.size(); i++) {
         Account account = list.get(i);
         int col = i % perRow;
         int row = i / perRow;
         int tx = startX + col * (TILE_W + TILE_GAP);
         int ty = startY + row * (TILE_H + TILE_GAP);
         this.drawAccountTile(context, account, tx, ty, mouseX, mouseY, p);
      }

      // "add account" tile, always last
      int addIndex = list.size();
      int addX = startX + (addIndex % perRow) * (TILE_W + TILE_GAP);
      int addY = startY + (addIndex / perRow) * (TILE_H + TILE_GAP);
      this.drawAddTile(context, addX, addY, mouseX, mouseY, p);

      int belowGrid = startY + rows * (TILE_H + TILE_GAP) + 4;

      /* ---- inline "add offline account" field ---- */
      if (this.typingName) {
         int fieldW = Math.min(260, width - 40);
         int fx = (width - fieldW) / 2;
         SmoothRect.fill(context, fx, belowGrid, fieldW, 24, 5.0F, 0x33000000);
         SmoothRect.outline(context, fx, belowGrid, fieldW, 24, 5.0F, 1.0F, p.accent());
         String shown = this.typedName.isEmpty() ? "type a username" : this.typedName;
         boolean blink = (System.currentTimeMillis() / 500L) % 2L == 0L;
         TextPainter.drawPoppins(context, this.typedName.isEmpty() ? shown : shown + (blink ? "_" : ""),
            fx + 8, belowGrid + 8, this.typedName.isEmpty() ? p.textMid() : p.textHi(), 10.0F);
         String hint = "ENTER to add  ·  ESC to cancel";
         TextPainter.drawPoppins(context, hint,
            width / 2.0F - TextPainter.poppinsWidth(hint, 8.0F) / 2.0F, belowGrid + 28, p.textMid(), 8.0F);
         belowGrid += 46;
      }

      /* ---- Microsoft device-code progress ---- */
      if (this.msState != null && !this.msState.done) {
         int panelW = Math.min(300, width - 40);
         int px = (width - panelW) / 2;
         SmoothRect.fill(context, px, belowGrid, panelW, 58, 6.0F, DesignTokens.panelBg());
         SmoothRect.outline(context, px, belowGrid, panelW, 58, 6.0F, 1.0F, p.accent());

         String l1 = "Open " + this.msState.verificationUri;
         TextPainter.drawPoppins(context, l1,
            width / 2.0F - TextPainter.poppinsWidth(l1, 9.0F) / 2.0F, belowGrid + 8, p.textMid(), 9.0F);

         String code = this.msState.userCode == null ? "" : this.msState.userCode;
         float codeW = TextPainter.poppinsWidth(code, 15.0F);
         TextPainter.drawPoppins(context, code, width / 2.0F - codeW / 2.0F, belowGrid + 22, p.textHi(), 15.0F);

         String l3 = "Waiting for sign-in...  (click to copy the code)";
         TextPainter.drawPoppins(context, l3,
            width / 2.0F - TextPainter.poppinsWidth(l3, 8.0F) / 2.0F, belowGrid + 44, p.textMid(), 8.0F);

         final String toCopy = code;
         this.hits.add(new Hit(px, belowGrid, panelW, 58, () -> {
            if (!toCopy.isEmpty()) {
               this.client.keyboard.setClipboard(toCopy);
               this.say("Code copied");
            }
         }, null));
         belowGrid += 66;
      }

      /* ---- Microsoft result ---- */
      if (this.msState != null && this.msState.done) {
         if (this.msState.success && this.msState.account != null) {
            this.accounts().addMicrosoft(this.msState.account);
            this.say("Added " + this.msState.account.username());
            PlayerHeads.forget(this.msState.account.username());
         } else if (this.msState.error != null && !this.msState.error.isEmpty()) {
            this.say(this.msState.error);
         }
         this.msState = null;
      }

      /* ---- notice (fades after 6s) ---- */
      if (!this.notice.isEmpty() && System.currentTimeMillis() - this.noticeAtMs < 6000L) {
         TextPainter.drawPoppins(context, this.notice,
            width / 2.0F - TextPainter.poppinsWidth(this.notice, 9.0F) / 2.0F,
            height - 44, p.textHi(), 9.0F);
      }

      /* ---- DONE ---- */
      int doneW = 110;
      int doneH = 22;
      int doneX = (width - doneW) / 2;
      int doneY = height - 32;
      boolean doneHover = mouseX >= doneX && mouseX < doneX + doneW && mouseY >= doneY && mouseY < doneY + doneH;
      PremiumButton.draw(context, doneX, doneY, doneW, doneH, "DONE", null, doneHover ? 1.0F : 0.0F, false, true);
      this.hits.add(new Hit(doneX, doneY, doneW, doneH, () -> this.client.setScreen(this.parent), null));
   }

   /** One account card: bust, name, type chip, remove button. */
   private void drawAccountTile(DrawContext context, Account account, int x, int y,
         int mouseX, int mouseY, ThemePalette p) {
      boolean hovered = mouseX >= x && mouseX < x + TILE_W && mouseY >= y && mouseY < y + TILE_H;
      boolean active = this.accounts().isActive(account);

      SmoothRect.fill(context, x, y, TILE_W, TILE_H, 8.0F,
         hovered ? DesignTokens.panelBgHover() : DesignTokens.panelBg());
      SmoothRect.outline(context, x, y, TILE_W, TILE_H, 8.0F, active ? 2.0F : 1.0F,
         active ? p.accent() : DesignTokens.panelBorder());

      /* bust render, centred in the upper part of the tile */
      int bust = 64;
      int bx = x + (TILE_W - bust) / 2;
      int by = y + 10;
      Identifier texture = PlayerHeads.bust(account.username());
      if (texture != null) {
         context.drawTexturedQuad(texture, bx, by, bx + bust, by + bust, 0.0F, 1.0F, 0.0F, 1.0F);
      } else {
         // Placeholder while the render downloads (or if it never arrives).
         SmoothRect.fill(context, bx, by, bust, bust, 6.0F, 0x22FFFFFF);
         RenderUtil.drawIcon(context, "user-round", bx + bust / 2 - 12, by + bust / 2 - 12, 24, p.textMid());
      }

      /* username */
      String name = account.username();
      float nameSize = 10.0F;
      while (TextPainter.poppinsWidth(name, nameSize) > TILE_W - 12 && nameSize > 6.0F) {
         nameSize -= 0.5F;
      }
      TextPainter.drawPoppins(context, name,
         x + TILE_W / 2.0F - TextPainter.poppinsWidth(name, nameSize) / 2.0F,
         y + 80, active ? p.accent() : p.textHi(), nameSize);

      /* type chip */
      String chip = account.isMicrosoft() ? "MICROSOFT" : "OFFLINE";
      float chipW = TextPainter.poppinsWidth(chip, 7.0F) + 10;
      float chipX = x + TILE_W / 2.0F - chipW / 2.0F;
      SmoothRect.fill(context, chipX, y + 94, chipW, 12, 6.0F,
         account.isMicrosoft() ? ThemePalette.withAlpha(p.accent(), 60) : 0x22FFFFFF);
      TextPainter.drawPoppins(context, chip, chipX + 5, y + 97, p.textMid(), 7.0F);

      /* status line */
      String status = active ? "CURRENT" : "click to switch";
      TextPainter.drawPoppins(context, status,
         x + TILE_W / 2.0F - TextPainter.poppinsWidth(status, 7.0F) / 2.0F,
         y + 110, active ? p.accent() : p.textMid(), 7.0F);

      /* remove button (top-right), only while the tile is hovered */
      if (hovered && !active) {
         int rx = x + TILE_W - 18;
         int ry = y + 6;
         boolean rHover = mouseX >= rx && mouseX < rx + 12 && mouseY >= ry && mouseY < ry + 12;
         SmoothRect.fill(context, rx, ry, 12, 12, 3.0F, rHover ? 0xFFC9405E : 0x33000000);
         RenderUtil.drawIcon(context, "x", rx, ry, 12, rHover ? 0xFFFFFFFF : p.textMid());
         this.hits.add(new Hit(rx, ry, 12, 12, () -> {
            this.accounts().remove(account);
            PlayerHeads.forget(account.username());
            this.say("Removed " + account.username());
         }, null));
      }

      // Whole tile switches; right-click removes (kept from the old screen).
      this.hits.add(new Hit(x, y, TILE_W, TILE_H, () -> {
         RenderUtil.clickSound();
         this.accounts().use(account);
         this.say("Switched to " + account.username());
      }, () -> {
         this.accounts().remove(account);
         PlayerHeads.forget(account.username());
         this.say("Removed " + account.username());
      }));
   }

   /** The dashed "+" tile that offers the two ways to add an account. */
   private void drawAddTile(DrawContext context, int x, int y, int mouseX, int mouseY, ThemePalette p) {
      boolean hovered = mouseX >= x && mouseX < x + TILE_W && mouseY >= y && mouseY < y + TILE_H;
      SmoothRect.fill(context, x, y, TILE_W, TILE_H, 8.0F,
         hovered ? DesignTokens.panelBgHover() : ThemePalette.withAlpha(DesignTokens.panelBg(), 140));
      SmoothRect.outline(context, x, y, TILE_W, TILE_H, 8.0F, 1.0F,
         hovered ? p.accent() : DesignTokens.panelBorder());

      RenderUtil.drawIcon(context, "user-round", x + TILE_W / 2 - 14, y + 22, 28,
         hovered ? p.accent() : p.textMid());

      String t = "ADD ACCOUNT";
      TextPainter.drawPoppins(context, t,
         x + TILE_W / 2.0F - TextPainter.poppinsWidth(t, 9.0F) / 2.0F, y + 58, p.textHi(), 9.0F);

      // Two stacked mini-buttons so each path is one click.
      int bw = TILE_W - 16;
      int bx = x + 8;
      int msY = y + 74;
      boolean msHover = mouseX >= bx && mouseX < bx + bw && mouseY >= msY && mouseY < msY + 18;
      PremiumButton.draw(context, bx, msY, bw, 18, "MICROSOFT", null, msHover ? 1.0F : 0.0F, false, true);
      this.hits.add(new Hit(bx, msY, bw, 18, () -> {
         RenderUtil.clickSound();
         this.msState = MsAuth.start();
         this.say("Starting Microsoft sign-in...");
      }, null));

      int offY = y + 96;
      boolean offHover = mouseX >= bx && mouseX < bx + bw && mouseY >= offY && mouseY < offY + 18;
      PremiumButton.draw(context, bx, offY, bw, 18, "OFFLINE", null, offHover ? 1.0F : 0.0F, false, false);
      this.hits.add(new Hit(bx, offY, bw, 18, () -> {
         RenderUtil.clickSound();
         this.typingName = true;
         this.typedName = "";
      }, null));
   }

   /* ===================================================================== */
   /* Input                                                                 */
   /* ===================================================================== */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) click.x();
      int my = (int) click.y();
      boolean right = click.button() == 1;

      // Reverse order: the small buttons are added after the tile they sit on,
      // so they must win the hit test.
      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit hit = this.hits.get(i);
         if (mx >= hit.x && mx < hit.x + hit.w && my >= hit.y && my < hit.y + hit.h) {
            if (right && hit.altAction != null) {
               hit.altAction.run();
            } else if (!right) {
               hit.action.run();
            } else {
               continue;
            }
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.typingName) {
         if (key == 257 || key == 335) {                 // ENTER
            if (!this.typedName.isEmpty()) {
               String error = this.accounts().addCracked(this.typedName);
               this.say(error == null ? "Added " + this.typedName : error);
               if (error == null) {
                  PlayerHeads.forget(this.typedName);
               }
            }
            this.typingName = false;
            this.typedName = "";
            return true;
         }
         if (key == 256) {                               // ESC
            this.typingName = false;
            this.typedName = "";
            return true;
         }
         if (key == 259 && !this.typedName.isEmpty()) {  // BACKSPACE
            this.typedName = this.typedName.substring(0, this.typedName.length() - 1);
            return true;
         }
         return true;
      }
      if (key == 256) {
         this.client.setScreen(this.parent);
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.typingName && input.isValidChar()) {
         String ch = input.asString();
         // Minecraft usernames: letters, digits and underscore, max 16.
         if (ch.length() == 1 && this.typedName.length() < 16
            && (Character.isLetterOrDigit(ch.charAt(0)) || ch.charAt(0) == '_')) {
            this.typedName = this.typedName + ch;
            return true;
         }
         return true;
      }
      return super.charTyped(input);
   }

   private record Hit(int x, int y, int w, int h, Runnable action, Runnable altAction) {
   }
}
