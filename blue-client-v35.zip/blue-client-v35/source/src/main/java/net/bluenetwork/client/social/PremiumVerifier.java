package net.bluenetwork.client.social;

import com.google.gson.JsonObject;
import java.util.UUID;
import java.util.function.Consumer;
import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;

/**
 * Proves the player owns their Minecraft account - with no Azure app and
 * without the access token ever leaving this computer.
 *
 * <h2>Why this exists</h2>
 * The obvious way to prove ownership is to send Mojang's access token to our
 * server and let it call {@code api.minecraftservices.com/minecraft/profile}.
 * That works, but it needs an <b>approved Azure application</b>, and Microsoft
 * never approved ours. It also means the token leaves the player's machine,
 * which is a privacy cost we would rather not charge them.
 *
 * <h2>The handshake we use instead</h2>
 * Every online-mode Minecraft server already solves this exact problem, so we
 * borrow its solution:
 *
 * <ol>
 *   <li>Our Edge Function invents a random one-time {@code serverId} and
 *       remembers it against this account.</li>
 *   <li><b>This class</b> calls {@code joinServer(uuid, accessToken, serverId)}
 *       - the same call vanilla makes when connecting to a real server. The
 *       token is used by the game's own session service, right here, and is
 *       never transmitted to us.</li>
 *   <li>The Edge Function asks Mojang's {@code hasJoined} endpoint whether
 *       that join actually happened. Mojang replies with the verified uuid
 *       and name, or nothing at all.</li>
 * </ol>
 *
 * Only someone holding a genuine Mojang session can make step 3 succeed, so
 * the result is exactly as trustworthy as a real server's login check.
 *
 * <h2>Reflection, and why</h2>
 * {@code ApiServices} is a record whose accessor is remapped, so its name
 * differs between mapping sets. Rather than hard-depend on one name we locate
 * the {@code MinecraftSessionService} by TYPE, which is stable. Everything is
 * wrapped so a failure reports a friendly message instead of crashing.
 *
 * <p>Verified against the real 1.21.11 jar:
 * {@code MinecraftClient.getApiServices()} is public,
 * {@code ApiServices} holds a {@code MinecraftSessionService}, and
 * {@code joinServer(UUID, String, String)} exists on it.</p>
 */
public final class PremiumVerifier {

   private PremiumVerifier() {
   }

   /**
    * Runs the whole handshake and reports a human-readable result.
    *
    * @param api      logged-in Supabase client
    * @param username the Minecraft name being claimed
    * @param onResult called on a background thread with (success, message)
    */
   public static void verify(SupabaseClient api, String username,
                             Consumer<Result> onResult) {
      if (!api.loggedIn()) {
         onResult.accept(new Result(false, "Log in to Blue Client first."));
         return;
      }

      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.getSession() == null) {
         onResult.accept(new Result(false, "No Minecraft session found."));
         return;
      }

      String sessionName = mc.getSession().getUsername();
      UUID sessionUuid = mc.getSession().getUuidOrNull();
      String token = mc.getSession().getAccessToken();

      if (sessionUuid == null || token == null || token.isBlank()) {
         onResult.accept(new Result(false,
            "You are playing offline, so ownership cannot be proven. "
               + "Use 'Link cracked name' instead."));
         return;
      }

      // The player can only verify the account they are actually logged in as.
      // Checking here saves a pointless round trip and gives a clearer error.
      if (!sessionName.equalsIgnoreCase(username)) {
         onResult.accept(new Result(false,
            "You are signed in as " + sessionName + ", not " + username + "."));
         return;
      }

      JsonObject start = new JsonObject();
      start.addProperty("step", "start");
      start.addProperty("username", username);

      api.edgeFunction("verify-join", start).thenAccept(el -> {
         if (el == null || !el.isJsonObject()) {
            onResult.accept(new Result(false, "Verification service unavailable."));
            return;
         }
         JsonObject res = el.getAsJsonObject();
         if (!res.has("ok") || !res.get("ok").getAsBoolean()) {
            onResult.accept(new Result(false, message(res, "Could not start verification.")));
            return;
         }

         String serverId = res.has("serverId") ? res.get("serverId").getAsString() : null;
         if (serverId == null || serverId.isBlank()) {
            onResult.accept(new Result(false, "Verification service returned nothing."));
            return;
         }

         // ---- the actual proof: tell Mojang we are joining "serverId" ----
         try {
            joinServer(sessionUuid, token, serverId);
         } catch (Throwable t) {
            BlueClient.LOGGER.warn("[Premium] joinServer failed", t);
            onResult.accept(new Result(false,
               "Could not reach Mojang's session server. Check your connection."));
            return;
         }

         JsonObject finish = new JsonObject();
         finish.addProperty("step", "finish");

         api.edgeFunction("verify-join", finish).thenAccept(fel -> {
            if (fel == null || !fel.isJsonObject()) {
               onResult.accept(new Result(false, "Verification service unavailable."));
               return;
            }
            JsonObject fres = fel.getAsJsonObject();
            boolean ok = fres.has("ok") && fres.get("ok").getAsBoolean();
            if (ok) {
               String name = fres.has("name") ? fres.get("name").getAsString() : username;
               onResult.accept(new Result(true, "Verified as " + name + "."));
            } else {
               onResult.accept(new Result(false, message(fres, "Verification failed.")));
            }
         }).exceptionally(err -> {
            onResult.accept(new Result(false, "Verification failed - try again."));
            return null;
         });

      }).exceptionally(err -> {
         onResult.accept(new Result(false, "Verification failed - try again."));
         return null;
      });
   }

   /**
    * Calls {@code MinecraftSessionService.joinServer(uuid, token, serverId)}.
    *
    * <p>Found by TYPE rather than by accessor name: {@code ApiServices} is a
    * record and its component accessor is remapped, so the name is not stable
    * across mapping sets, but the field's type always is.</p>
    */
   private static void joinServer(UUID uuid, String accessToken, String serverId)
         throws Exception {
      MinecraftClient mc = MinecraftClient.getInstance();
      Object services = mc.getApiServices();
      if (services == null) {
         throw new IllegalStateException("no ApiServices");
      }

      Class<?> sessionServiceType =
         Class.forName("com.mojang.authlib.minecraft.MinecraftSessionService");

      Object sessionService = null;
      for (java.lang.reflect.Field f : services.getClass().getDeclaredFields()) {
         if (sessionServiceType.isAssignableFrom(f.getType())) {
            f.setAccessible(true);
            sessionService = f.get(services);
            break;
         }
      }
      if (sessionService == null) {
         throw new IllegalStateException("no MinecraftSessionService");
      }

      sessionServiceType
         .getMethod("joinServer", UUID.class, String.class, String.class)
         .invoke(sessionService, uuid, accessToken, serverId);
   }

   private static String message(JsonObject o, String fallback) {
      if (o.has("m") && !o.get("m").isJsonNull()) {
         return o.get("m").getAsString();
      }
      return fallback;
   }

   /** Outcome of a verification attempt. */
   public record Result(boolean ok, String message) {
   }
}
