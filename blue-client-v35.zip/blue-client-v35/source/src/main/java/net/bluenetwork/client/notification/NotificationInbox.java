package net.bluenetwork.client.notification;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The Activity list - every social event that has happened to you, kept after
 * its toast has faded.
 *
 * <h2>Why a toast is not enough</h2>
 * A toast lives four seconds. If you are mining when someone likes your post,
 * you never learn it happened. Instagram keeps an Activity tab for exactly
 * this reason, and the owner asked for "notifications for everything in
 * Social, like Instagram" - so every toast also lands here.
 *
 * <h2>Memory only, on purpose</h2>
 * This is <b>not</b> persisted to disk and not stored server-side. Writing an
 * activity row per like would multiply database writes for something nobody
 * reads twice, and the owner's Supabase egress is the real ceiling. The list
 * is capped at {@link #CAPACITY} and cleared on logout.
 */
public final class NotificationInbox {

   /** Hard cap. Old entries fall off the end rather than growing forever. */
   public static final int CAPACITY = 60;

   /** One entry in the Activity list. */
   public record Entry(SocialToasts.Kind kind, String who, String body,
                       String targetId, long at, boolean read) {

      /** A copy of this entry marked as read. */
      public Entry asRead() {
         return new Entry(this.kind, this.who, this.body, this.targetId,
            this.at, true);
      }
   }

   /** Newest first. */
   private static final CopyOnWriteArrayList<Entry> ENTRIES =
      new CopyOnWriteArrayList<>();

   private NotificationInbox() {
   }

   /** Records an event. Called by {@link SocialToasts#social}. */
   public static void add(SocialToasts.Kind kind, String who, String body,
                          String targetId) {
      ENTRIES.add(0, new Entry(kind, who, body, targetId,
         System.currentTimeMillis(), false));
      while (ENTRIES.size() > CAPACITY) {
         ENTRIES.remove(ENTRIES.size() - 1);
      }
   }

   /** Everything, newest first. */
   public static List<Entry> all() {
      return List.copyOf(ENTRIES);
   }

   /** How many have not been opened - drives the red dot. */
   public static int unread() {
      int n = 0;
      for (Entry e : ENTRIES) {
         if (!e.read()) {
            n++;
         }
      }
      return n;
   }

   /** Marks everything read, called when the Activity tab is opened. */
   public static void markAllRead() {
      List<Entry> copy = new ArrayList<>(ENTRIES.size());
      for (Entry e : ENTRIES) {
         copy.add(e.read() ? e : e.asRead());
      }
      ENTRIES.clear();
      ENTRIES.addAll(copy);
   }

   /** Clears everything - on logout, so the next account starts clean. */
   public static void clear() {
      ENTRIES.clear();
   }
}
