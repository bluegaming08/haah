package net.bluenetwork.client.module;

public interface HoldModule {
}
