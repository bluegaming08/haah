package net.bluenetwork.client.util;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;

/** Simple persisted waypoint list: config/blueclient/waypoints.json. */
public final class WaypointStore {
   public record Waypoint(String name, int x, int y, int z, String dimension) {
   }

   private static final List<Waypoint> CACHE = new ArrayList<>();
   private static boolean loaded = false;

   private WaypointStore() {
   }

   private static Path file() {
      return FabricLoader.getInstance().getGameDir().resolve("config").resolve("blueclient").resolve("waypoints.json");
   }

   private static synchronized void load() {
      if (loaded) {
         return;
      }
      loaded = true;
      try {
         if (Files.exists(file())) {
            JsonArray arr = JsonParser.parseString(Files.readString(file(), StandardCharsets.UTF_8)).getAsJsonArray();
            CACHE.clear();
            for (JsonElement el : arr) {
               JsonObject o = el.getAsJsonObject();
               CACHE.add(new Waypoint(
                  o.get("name").getAsString(),
                  o.get("x").getAsInt(),
                  o.get("y").getAsInt(),
                  o.get("z").getAsInt(),
                  o.has("dimension") ? o.get("dimension").getAsString() : "minecraft:overworld"));
            }
         }
      } catch (Throwable t) {
         BlueClient.LOGGER.warn("Could not read waypoints.json", t);
      }
   }

   public static synchronized List<Waypoint> all() {
      load();
      return new ArrayList<>(CACHE);
   }

   public static synchronized void add(Waypoint wp) {
      load();
      remove(wp.name());
      CACHE.add(wp);
      CACHE.sort(Comparator.comparing(Waypoint::name, String.CASE_INSENSITIVE_ORDER));
      save();
   }

   public static synchronized boolean remove(String name) {
      load();
      boolean removed = CACHE.removeIf(w -> w.name().equalsIgnoreCase(name));
      if (removed) {
         save();
      }
      return removed;
   }

   private static void save() {
      try {
         JsonArray arr = new JsonArray();
         for (WaypointStore.Waypoint w : CACHE) {
            JsonObject o = new JsonObject();
            o.addProperty("name", w.name());
            o.addProperty("x", w.x());
            o.addProperty("y", w.y());
            o.addProperty("z", w.z());
            o.addProperty("dimension", w.dimension());
            arr.add(o);
         }
         Files.createDirectories(file().getParent());
         Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(arr), StandardCharsets.UTF_8);
      } catch (Throwable t) {
         BlueClient.LOGGER.warn("Could not save waypoints.json", t);
      }
   }
}
