package net.bluenetwork.client.module.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.util.WaypointStore;
import net.bluenetwork.client.util.WaypointStore.Waypoint;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;

/**
 * Waypoints - a small HUD panel listing your waypoints in the
 * current dimension with distance + direction. Add and remove them with
 * /waypoint add|remove <name>.
 */
public class Waypoints extends HudModule {
   private static final String[] COMPASS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

   public Waypoints() {
      super("Waypoints", "Distance + direction to your /waypoint points", Category.HUD, 4, 4);
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 92);
   }

   private List<Waypoint> visible() {
      MinecraftClient mc = MinecraftClient.getInstance();
      List<Waypoint> out = new ArrayList<>();
      if (mc.world == null) {
         return out;
      }
      String dim = mc.world.getRegistryKey().getValue().toString();
      for (Waypoint w : WaypointStore.all()) {
         if (w.dimension().equals(dim)) {
            out.add(w);
         }
      }
      return out;
   }

   private String line(Waypoint w, MinecraftClient mc) {
      BlockPos pos = mc.player != null ? mc.player.getBlockPos() : BlockPos.ORIGIN;
      int dx = w.x() - pos.getX();
      int dz = w.z() - pos.getZ();
      int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
      double yaw = mc.player != null ? mc.player.getYaw() : 0.0;
      double target = Math.toDegrees(Math.atan2(-dx, dz)); // 0 = +Z (south)
      double rel = (target - yaw + 3600.0) % 360.0;
      int sector = (int) Math.floor((rel + 22.5) / 45.0) % 8;
      return w.name() + "  " + dist + "m " + COMPASS[sector];
   }

   @Override
   public int getWidth() {
      int widest = RenderUtil.textWidth("Waypoints");
      for (Waypoint w : this.visible()) {
         widest = Math.max(widest, RenderUtil.textWidth(w.name() + "  99999m NN"));
      }
      return widest + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 8 + Math.max(1, this.visible().size()) * 12 + 6;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) {
         return;
      }
      this.drawPanel(context);
      RenderUtil.drawText(context, "Waypoints", this.x + 6, this.y + 5, 0xFF9DB2FF);
      int y = this.y + 18;
      List<Waypoint> list = this.visible();
      if (list.isEmpty()) {
         RenderUtil.drawText(context, "None - /waypoint add <name>", this.x + 6, y, 0xFF6B7280);
         return;
      }
      for (Waypoint w : list) {
         RenderUtil.drawText(context, this.line(w, mc), this.x + 6, y, 0xFFFFFFFF);
         y += 12;
      }
   }
}
