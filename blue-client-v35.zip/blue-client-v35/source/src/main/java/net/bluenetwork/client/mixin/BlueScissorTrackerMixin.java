package net.bluenetwork.client.mixin;

import net.minecraft.client.gui.ScreenRect;
import net.bluenetwork.client.render.BlueScissors;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Deque;

/**
 * Mirrors DrawContext$ScissorStack mutations into a global holder so Blue
 * Client's custom GUI elements can read the active scissor rectangle.
 *
 * <p>Why not an @Accessor on DrawContext.scissorStack? The field's type
 * (DrawContext$ScissorStack) is package-private, so no accessor signature
 * outside net.minecraft.client.gui can name it, and a mixin config claiming a
 * vanilla package is forbidden (IllegalClassLoadError on every class load in
 * that package). This behavioural mixin instead shadows the inner class's own
 * {@code stack} deque (public, nameable types) and records the top rect on the
 * only two mutators: push and pop.
 */
@Mixin(targets = "net.minecraft.client.gui.DrawContext$ScissorStack")
public abstract class BlueScissorTrackerMixin {
    @Shadow
    private Deque<ScreenRect> stack;

    @Inject(method = "push", at = @At("RETURN"))
    private void blueclient$onPush(ScreenRect rect, CallbackInfoReturnable<ScreenRect> cir) {
        BlueScissors.set(this.stack.peekLast());
    }

    @Inject(method = "pop", at = @At("RETURN"))
    private void blueclient$onPop(CallbackInfoReturnable<ScreenRect> cir) {
        BlueScissors.set(this.stack.peekLast());
    }
}
