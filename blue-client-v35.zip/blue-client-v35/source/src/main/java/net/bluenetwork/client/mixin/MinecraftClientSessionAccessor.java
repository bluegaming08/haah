package net.bluenetwork.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({MinecraftClient.class})
public interface MinecraftClientSessionAccessor {
   @Accessor("session")
   void blueclient$setSession(Session var1);

   @Accessor("session")
   Session blueclient$getSession();
}
