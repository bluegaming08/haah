package net.bluenetwork.client.mixin;

import net.bluenetwork.client.util.TotemTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Feeds totem pops to {@link TotemTracker}.
 *
 * <p>Status <b>35</b> on {@code EntityStatusS2CPacket} is "totem of undying
 * used" — it is what triggers the vanilla animation, particles and sound. We
 * only observe it; nothing is sent and no behaviour changes, so this cannot
 * trip an anticheat.</p>
 *
 * <p>Injected at TAIL so vanilla has already handled the packet. {@code
 * require = 0} keeps a future rename from blocking startup.</p>
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class TotemTrackerMixin {

   /** Entity status byte meaning "a totem of undying saved this entity". */
   @org.spongepowered.asm.mixin.Unique
   private static final byte BLUECLIENT$TOTEM_USED = 35;

   @Inject(
      method = "onEntityStatus(Lnet/minecraft/network/packet/s2c/play/EntityStatusS2CPacket;)V",
      at = @At("TAIL"),
      require = 0
   )
   private void blueclient$trackTotemPop(EntityStatusS2CPacket packet, CallbackInfo ci) {
      try {
         if (packet.getStatus() != BLUECLIENT$TOTEM_USED) {
            return;
         }
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc == null || mc.world == null) {
            return;
         }
         Entity entity = packet.getEntity(mc.world);
         if (entity != null) {
            TotemTracker.onTotemPop(entity);
         }
      } catch (Throwable ignored) {
         // Statistics must never break packet handling.
      }
   }
}
