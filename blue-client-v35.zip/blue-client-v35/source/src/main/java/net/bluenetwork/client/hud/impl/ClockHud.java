package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class ClockHud extends HudModule {
   public ClockHud() {
      super("Clock", "Shows the in-game time of day.", Category.HUD, 4, 284);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.world != null) {
         long ticks = mc.world.getTimeOfDay();
         long hours = (ticks / 1000L + 6L) % 24L;
         long minutes = ticks % 1000L * 60L / 1000L;
         String text = String.format("Time: %02d:%02d", hours, minutes);
         this.drawTextPanel(context, text);
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Time: 00:00") + 12 + 2;
   }
}
