package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.mixin.AbstractHorseAccessor;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Horses (v0.19.0) — horse stats: while you look at a horse,
 * donkey, mule, llama or skeleton horse, a small panel shows its breeding
 * stats: jump height (blocks), top speed (blocks/s) and max health.
 *
 * <p>Formulas are the standard ones used by stat mods: jump height blocks =
 * -0.18175917s³ + 3.06301489s² + 2.59823431s + 0.83204763, and speed
 * blocks/s ≈ movement-speed attribute × 43.178.</p>
 */
public class Horses extends HudModule {
   private final BooleanSetting showJump = new BooleanSetting("Show jump", "Jump height in blocks", true);
   private final BooleanSetting showSpeed = new BooleanSetting("Show speed", "Top speed in blocks per second", true);
   private final BooleanSetting showHealth = new BooleanSetting("Show health", "Max health in hearts", true);

   public Horses() {
      super("Horses", "Stats of the horse you are looking at", Category.HUD, 4, 4);
      this.addSettings(new Setting[]{this.showJump, this.showSpeed, this.showHealth});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_RIGHT, 60, 40);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.targetedEntity == null || !(mc.targetedEntity instanceof AbstractHorseEntity horse)) {
         return;
      }
      float jumpStrength = ((AbstractHorseAccessor) horse).blueclient$getJumpStrength();
      double jumpBlocks = -0.18175917026644767 * jumpStrength * jumpStrength * jumpStrength
         + 3.06301488966374 * jumpStrength * jumpStrength
         + 2.5982343107448 * jumpStrength
         + 0.8320476293146;
      double speedAttr = horse.getAttributes().getValue(EntityAttributes.MOVEMENT_SPEED);
      double blocksPerSecond = speedAttr * 43.178;
      float maxHealth = horse.getMaxHealth();

      java.util.List<String> lines = new java.util.ArrayList<>();
      lines.add(horse.getDisplayName().getString());
      if (this.showJump.get()) {
         lines.add("Jump: " + String.format("%.1f", MathHelper.clamp(jumpBlocks, 0.0, 8.0)) + " blocks");
      }
      if (this.showSpeed.get()) {
         lines.add("Speed: " + String.format("%.2f", blocksPerSecond) + " blocks/s");
      }
      if (this.showHealth.get()) {
         lines.add("Health: " + (int) Math.ceil(maxHealth / 2.0F) + " hearts");
      }

      int widest = 0;
      for (String line : lines) {
         widest = Math.max(widest, RenderUtil.textWidth(line));
      }
      int w = widest + 16;
      int h = lines.size() * 12 + 10;
      int x = this.x;
      int y = this.y;
      SmoothRect.fill(context, x, y, w, h, 8.0F, 0xA00B0E14);
      SmoothRect.outline(context, x, y, w, h, 8.0F, 1.0F, 0x663D6BFF);
      int ly = y + 6;
      for (int i = 0; i < lines.size(); i++) {
         int color = i == 0 ? 0xFFFFFFFF : 0xFFD7DCE5;
         RenderUtil.drawText(context, lines.get(i), x + 8, ly, color);
         ly += 12;
      }
   }

   @Override
   public int getWidth() {
      return 130;
   }

   @Override
   public int getHeight() {
      return 56;
   }
}
