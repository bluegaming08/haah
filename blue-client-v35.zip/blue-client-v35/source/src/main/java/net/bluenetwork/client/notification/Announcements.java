package net.bluenetwork.client.notification;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.XKit;
import net.bluenetwork.client.ui.text.TextPainter;
import net.minecraft.client.gui.DrawContext;

/**
 * Staff announcements: a banner shown to every Blue Client user at once.
 *
 * <h2>Where it appears</h2>
 * Deliberately <b>everywhere</b> - in a world, in singleplayer, and on the
 * main menu. It is drawn from the HUD render hook AND from a screen hook, so
 * it does not depend on a world being loaded. That is the whole point: an
 * announcement about maintenance is most useful to someone sitting in a menu.
 *
 * <h2>Why it is separate from SocialToasts</h2>
 * Toasts are personal ("Alice liked your post") and stack in the corner.
 * An announcement is from the operators to everyone, so it gets its own
 * centred banner at the top - visually distinct, and it cannot be buried
 * under a pile of like notifications.
 */
public final class Announcements {

   private static final long LIFETIME_MS = 9000L;
   private static final long SLIDE_MS = 280L;
   private static final int MAX_QUEUED = 3;

   private record Banner(String text, int accent, long born) {

      long age() {
         return System.currentTimeMillis() - this.born;
      }

      boolean expired() {
         return age() > LIFETIME_MS;
      }

      /** 0 while sliding in, 1 once settled. */
      float slide() {
         return Math.min(1.0F, age() / (float) SLIDE_MS);
      }

      /** Fades over the final half second. */
      float fade() {
         long left = LIFETIME_MS - age();
         return left > 500L ? 1.0F : Math.max(0.0F, left / 500.0F);
      }
   }

   private static final CopyOnWriteArrayList<Banner> LIVE = new CopyOnWriteArrayList<>();

   private Announcements() {
   }

   /** Queues an announcement banner. */
   public static void show(String text, int accent) {
      if (text == null || text.isBlank()) {
         return;
      }
      LIVE.add(new Banner(text.trim(), accent, System.currentTimeMillis()));
      while (LIVE.size() > MAX_QUEUED) {
         LIVE.remove(0);
      }
   }

   public static void clear() {
      LIVE.clear();
   }

   public static boolean hasAny() {
      LIVE.removeIf(Banner::expired);
      return !LIVE.isEmpty();
   }

   /**
    * Draws the banner stack, centred at the top of the screen.
    *
    * <p>Safe to call from anywhere and on any screen; it draws nothing when
    * the queue is empty.</p>
    */
   public static void render(DrawContext ctx) {
      LIVE.removeIf(Banner::expired);
      if (LIVE.isEmpty()) {
         return;
      }
      int screenW = ctx.getScaledWindowWidth();
      float y = 8.0F;

      for (Banner b : LIVE) {
         float fade = b.fade();
         // Ease-out slide down from above the top edge.
         float t = b.slide();
         float eased = 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
         float offset = (1.0F - eased) * -20.0F;

         float size = 8.5F;
         String text = b.text();
         float textW = TextPainter.poppinsWidth(text, size);
         float w = Math.min(screenW - 20.0F, textW + 40.0F);
         float h = 22.0F;
         float x = (screenW - w) / 2.0F;
         float by = y + offset;

         PremiumRender.drawShadow(ctx, (int) x - 1, (int) by - 1,
            (int) w + 2, (int) h + 2, alpha(0x88000000, fade), 8);
         SmoothRect.fill(ctx, x, by, w, h, 6.0F, alpha(0xFF16181C, fade));
         SmoothRect.outline(ctx, x, by, w, h, 6.0F, 1.0F, alpha(b.accent(), fade));

         // Accent stripe on the left edge marks it as official.
         SmoothRect.fill(ctx, x + 2.0F, by + 3.0F, 2.5F, h - 6.0F, 1.25F,
            alpha(b.accent(), fade));

         RenderUtil.drawIcon(ctx, "bell", (int) (x + 10.0F), (int) (by + 7.0F),
            9, alpha(b.accent(), fade));

         TextPainter.drawPoppins(ctx, XKit.fit(text, w - 44.0F, size),
            x + 24.0F, by + (h - size) / 2.0F + 0.5F,
            alpha(0xFFE7E9EA, fade), size);

         y += h + 5.0F;
      }
   }

   private static int alpha(int argb, float f) {
      int a = (int) (((argb >>> 24) & 0xFF) * Math.max(0.0F, Math.min(1.0F, f)));
      return (a << 24) | (argb & 0xFFFFFF);
   }
}
