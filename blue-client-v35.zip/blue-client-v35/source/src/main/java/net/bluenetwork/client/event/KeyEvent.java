package net.bluenetwork.client.event;

/**
 * Fired from KeyboardMixin for every raw key event, on the render thread.
 * action follows GLFW: 1 = press, 0 = release, 2 = repeat.
 */
public record KeyEvent(int key, int action) {
}
