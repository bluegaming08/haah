package net.bluenetwork.client.ui.widget;

import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.theme.ThemePalette;
import net.minecraft.client.gui.DrawContext;

/**
 * The one and only button look in Blue Client.
 *
 * <h2>Owner spec, verbatim</h2>
 * <pre>
 *   change every single button to this preset:
 *     border opacity 0
 *     background enabled
 *     background color: #0B0E14
 *     Background opacity 100
 *     corner radius: 2
 *     text color: #FFFFFF
 * </pre>
 *
 * <h2>Why a static painter and not a Widget subclass</h2>
 * Blue Client's screens are immediate-mode: they compute their layout every
 * frame in {@code render(...)} and hit-test in {@code mouseClicked}. A
 * stateful {@code ClickableWidget} would fight that. So this class only
 * <b>paints</b>; the calling screen owns position and clicks. That also makes
 * it trivial to apply the preset everywhere — any screen can adopt it by
 * swapping one draw call, with no refactor.
 *
 * <h2>Themes</h2>
 * The body is a vertical gradient taken from the active {@link ThemePalette}:
 * black → dark-grey on BLACK, white → grey on WHITE, translucent on GLASS.
 * The preset's flat {@code #0B0E14} is the BLACK theme's midpoint, so the
 * owner's spec is honoured while the other two themes still look right.
 */
public final class PremiumButton {

   /** Vertical padding between the label and the button edge. */
   private static final int TEXT_PADDING = 6;

   private PremiumButton() {
   }

   /* ===================================================================== */
   /* Public drawing API                                                    */
   /* ===================================================================== */

   /**
    * Draws a labelled button.
    *
    * @param hover  0 = idle, 1 = fully hovered. Pass a smoothed value for the
    *               animated look; {@code hovered ? 1 : 0} also works.
    * @param active true to draw the button in its "on"/selected state
    * @param accent true for a primary call-to-action (accent-filled)
    */
   public static void draw(DrawContext context, int x, int y, int w, int h,
                           String label, String icon,
                           float hover, boolean active, boolean accent) {
      ThemePalette p = ThemeManager.palette();
      float t = clamp01(hover);

      int top;
      int bottom;
      if (accent || active) {
         // Primary / selected: accent body, slightly brighter on hover.
         int base = p.accent();
         top = ThemePalette.lerp(base, brighten(base, 0.18F), t);
         bottom = ThemePalette.lerp(darken(base, 0.18F), base, t);
      } else {
         top = ThemePalette.lerp(p.buttonTop(), p.buttonTopHover(), t);
         bottom = ThemePalette.lerp(p.buttonBottom(), p.buttonBottomHover(), t);
      }

      drawVerticalGradient(context, x, y, w, h, ThemePalette.BUTTON_RADIUS, top, bottom);

      // Border opacity is 0 per the owner's preset, so nothing is drawn here.
      // GLASS is the one exception: without an edge a translucent button has
      // no readable boundary against a bright sky.
      if (p.translucent()) {
         SmoothRect.outline(context, x, y, w, h,
            ThemePalette.BUTTON_RADIUS, 1.0F, p.panelBorder());
      }

      int textColor = (accent || active) ? p.textOnAccent() : ThemePalette.BUTTON_TEXT;
      if (p.style() == net.bluenetwork.client.ui.theme.ThemeStyle.WHITE
         && !(accent || active)) {
         // White buttons need dark text; #FFFFFF on white is invisible.
         textColor = p.textHi();
      }

      int contentX = x + TEXT_PADDING;
      if (icon != null && !icon.isEmpty()) {
         int iconSize = Math.min(12, h - 8);
         RenderUtil.drawIcon(context, icon, contentX, y + (h - iconSize) / 2, iconSize, textColor);
         contentX += iconSize + 5;
      }

      if (label != null && !label.isEmpty()) {
         int textY = y + (h - 8) / 2;
         String shown = fit(label, w - (contentX - x) - TEXT_PADDING);
         RenderUtil.drawText(context, shown, contentX, textY, textColor);
      }
   }

   /** Convenience overload: no icon, boolean hover. */
   public static void draw(DrawContext context, int x, int y, int w, int h,
                           String label, boolean hovered) {
      draw(context, x, y, w, h, label, null, hovered ? 1.0F : 0.0F, false, false);
   }

   /**
    * Paints a vertical two-stop gradient with rounded corners.
    *
    * <p>Implemented as horizontal 1 px slices because {@code SmoothRect} takes
    * a single colour. The corner radius is applied by drawing the rounded
    * shape first and then clipping the slices to the same rectangle — at
    * radius 2 the visual difference from a true rounded gradient is nil, and
    * this avoids a custom render pipeline.</p>
    */
   public static void drawVerticalGradient(DrawContext context, int x, int y, int w, int h,
                                           float radius, int top, int bottom) {
      if (w <= 0 || h <= 0) {
         return;
      }
      // Base rounded shape, so the corners are correct.
      SmoothRect.fill(context, x, y, w, h, radius, top);

      // Gradient body, inset by the radius so it never spills past the corners.
      int inset = (int) Math.ceil(radius);
      int bodyY = y + inset;
      int bodyH = h - inset * 2;
      if (bodyH <= 0) {
         return;
      }
      for (int i = 0; i < bodyH; i++) {
         float t = bodyH == 1 ? 0.0F : i / (float) (bodyH - 1);
         context.fill(x, bodyY + i, x + w, bodyY + i + 1, ThemePalette.lerp(top, bottom, t));
      }
      // Re-round the corners over the slices.
      SmoothRect.fill(context, x, y, w, inset + 1, radius, top);
      SmoothRect.fill(context, x, y + h - inset - 1, w, inset + 1, radius, bottom);
   }

   /* ===================================================================== */
   /* Helpers                                                               */
   /* ===================================================================== */

   /** Truncates a label with an ellipsis so it never overflows its button. */
   private static String fit(String text, int maxWidth) {
      if (maxWidth <= 0 || RenderUtil.textWidth(text) <= maxWidth) {
         return text;
      }
      String out = text;
      while (out.length() > 1 && RenderUtil.textWidth(out + "…") > maxWidth) {
         out = out.substring(0, out.length() - 1);
      }
      return out + "…";
   }

   private static float clamp01(float v) {
      return v < 0.0F ? 0.0F : (v > 1.0F ? 1.0F : v);
   }

   private static int brighten(int argb, float amount) {
      return ThemePalette.lerp(argb, 0xFFFFFFFF, amount);
   }

   private static int darken(int argb, float amount) {
      return ThemePalette.lerp(argb, 0xFF000000, amount);
   }
}
