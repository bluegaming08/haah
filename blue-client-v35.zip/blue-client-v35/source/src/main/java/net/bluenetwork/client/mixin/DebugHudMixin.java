package net.bluenetwork.client.mixin;

import java.util.List;
import net.bluenetwork.client.module.impl.CustomF3;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.DebugHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Custom F3 hooks (v0.19.0). The private drawText(context, lines, rightSide)
 * renders one F3 column; the HEAD inject cancels a whole hidden side, and the
 * argsOnly ModifyVariable swaps the lines for the keyword-filtered list.
 */
@Mixin(DebugHud.class)
public abstract class DebugHudMixin {

   @Inject(method = {"drawText"}, at = {@At("HEAD")}, cancellable = true, require = 0)
   private void blueclient$hideSide(DrawContext context, List<String> lines, boolean rightSide, CallbackInfo ci) {
      if (CustomF3.sideHidden(rightSide)) {
         ci.cancel();
      }
   }

   @ModifyVariable(method = {"drawText"}, at = @At("HEAD"), argsOnly = true, require = 0)
   private List<String> blueclient$filterLines(List<String> lines) {
      return CustomF3.filter(lines);
   }
}
