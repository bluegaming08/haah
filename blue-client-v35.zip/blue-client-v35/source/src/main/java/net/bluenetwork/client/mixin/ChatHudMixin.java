package net.bluenetwork.client.mixin;

import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.impl.ChatCleaner;
import net.bluenetwork.client.module.impl.ChatLogger;
import net.bluenetwork.client.module.impl.ChatTimestamps;
import net.bluenetwork.client.module.impl.FriendPresence;
import net.bluenetwork.client.module.impl.HighlightManager;
import net.bluenetwork.client.module.impl.MentionHighlight;
import net.bluenetwork.client.module.impl.NameFormatter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.bluenetwork.client.module.impl.ChatLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ChatHud.class})
public abstract class ChatHudMixin {
   @Shadow
   private int getWidth() {
      throw new AssertionError();
   }

   @Shadow
   private int getHeight() {
      throw new AssertionError();
   }

   private boolean blueclient$chatMoved = false;

   /**
    * Chat Location module: offsets the whole chat box to another corner by
    * translating the render matrix (pushed at HEAD, popped at TAIL).
    */
   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V"},
      at = {@At("HEAD")}
   )
   private void blueclient$moveChatHead(DrawContext context, net.minecraft.client.font.TextRenderer tr,
                                        int a, int b, int c, boolean d, boolean e, CallbackInfo ci) {
      this.blueclient$chatMoved = false;
      if (!ChatLocation.relocate()) {
         return;
      }
      String mode = ChatLocation.current();
      int sw = context.getScaledWindowWidth();
      int sh = context.getScaledWindowHeight();
      int chatW = this.getWidth();
      int chatH = this.getHeight();
      int dx = 0;
      int dy = 0;
      if (mode.contains("RIGHT")) {
         dx = sw - chatW - 2;
      }
      if (mode.contains("TOP")) {
         dy = -(sh - 40 - chatH);
         if (dy > 0) {
            dy = 0;
         }
      }
      var matrices = context.getMatrices();
      matrices.pushMatrix();
      matrices.translate(dx, dy);
      this.blueclient$chatMoved = true;
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V"},
      at = {@At("TAIL")}
   )
   private void blueclient$moveChatTail(DrawContext context, net.minecraft.client.font.TextRenderer tr,
                                        int a, int b, int c, boolean d, boolean e, CallbackInfo ci) {
      if (this.blueclient$chatMoved) {
         context.getMatrices().popMatrix();
         this.blueclient$chatMoved = false;
      }
   }

   /**
    * Additive: family C hooks that run before decoration — drop blocked
    * messages (cleaner), log survivors, and watch for friend join/leave lines.
    */
   @Inject(method = {"addMessage"}, at = {@At("HEAD")}, cancellable = true)
   private void blueclient$filter(Text message, CallbackInfo ci) {
      if (message == null) {
         return;
      }
      String content = message.getString();
      if (content == null || content.isEmpty()) {
         return;
      }
      if (ChatCleaner.blocks(content)) {
         ci.cancel();
         return;
      }
      ChatLogger.log(message);
      FriendPresence.scan(content);
   }

   /*
    * NOTE for the next AI: @ModifyVariable's `at` must be a SCALAR @At(...).
    * The array form {@At("HEAD")} - which @Inject accepts happily - fails here
    * with "annotation value not of an allowable type".
    */
   @ModifyVariable(
      method = {"addMessage"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private Text blueclient$decorate(Text message) {
      if (message == null) {
         return message;
      } else {
         String content = message.getString();
         if (content != null && !content.isEmpty()) {
            Module timestamps = find(ChatTimestamps.class);
            Module mention = find(MentionHighlight.class);
            MutableText result = null;
            if (mention != null && mention.isEnabled() && this.containsName(content)) {
               result = Text.literal("").append(message.copy().formatted(Formatting.AQUA));

               try {
                  MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7F));
               } catch (Throwable var8) {
               }
            }

            if (timestamps != null && timestamps.isEnabled()) {
               String prefix = "[" + ChatTimestamps.prefix() + "] ";
               MutableText withTime = Text.literal(prefix).formatted(Formatting.GRAY);
               if (result != null) {
                  withTime.append(result);
               } else {
                  withTime.append(message.copy());
               }

               result = withTime;
            }

            // Additive family C colouring: highlight words / own-name colour.
            if (result == null) {
               Formatting fmt = HighlightManager.highlight(content);
               if (fmt == null) {
                  fmt = NameFormatter.forName(content);
               }
               if (fmt != null) {
                  result = Text.literal("").append(message.copy().formatted(fmt));
               }
            }

            return (Text)(result != null ? result : message);
         } else {
            return message;
         }
      }
   }

   private boolean containsName(String content) {
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player != null && player.getGameProfile() != null) {
         String name = player.getGameProfile().name();
         return name != null && !name.isEmpty() && content.toLowerCase(Locale.ROOT).contains(name.toLowerCase(Locale.ROOT));
      } else {
         return false;
      }
   }

   private static Module find(Class<? extends Module> type) {
      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         if (type.isInstance(module)) {
            return module;
         }
      }

      return null;
   }
}
