package net.bluenetwork.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

/**
 * Colour setting, v2 (redesign plan §4.2 / §5.2).
 *
 * <p>Preserves the full legacy surface ({@link #get()}, {@link #set(Integer)},
 * hex draft typing, per-channel accessors) so existing callers — Crosshair and
 * the current click-GUI colour editor — keep working unchanged.</p>
 *
 * <p>Adds the v2 colour model: every colour owns a mode (SOLID / RAINBOW),
 * plus per-colour rainbow {@code speed} (cycles/second) and {@code offset}
 * (0..1 phase), so e.g. Keystrokes can cycle fast while CPS stays slow.</p>
 *
 * <p>Persistence stays backward compatible: SOLID settings serialize exactly as
 * the legacy {@code "%06X"} hex string (identical files to v0.15); RAINBOW
 * settings serialize as a small object {@code {hex, rainbow, speed, offset}}.
 * {@link #fromJson(JsonElement)} accepts both.</p>
 */
public class ColorSetting extends Setting<Integer> {
   private int color;
   private String hexDraft = "";
   private boolean rainbow = false;
   private float rainbowSpeed = 1.0F;
   private float rainbowOffset = 0.0F;

   public ColorSetting(String name, String description, int defaultColor) {
      super(name, description, defaultColor & 16777215);
      this.color = defaultColor;
   }

   /** Legacy solid colour (always 0xFFrrggbb). See {@link #currentRgb()} for the resolved colour. */
   public Integer get() {
      return this.color;
   }

   public int rgb() {
      return this.color & 16777215;
   }

   public String hex() {
      return String.format("#%06X", this.rgb());
   }

   public void set(Integer value) {
      this.color = 0xFF000000 | value & 16777215;
      this.hexDraft = "";
      super.set(this.color);
   }

   public void setRgb(int r, int g, int b) {
      this.set(clamp255(r) << 16 | clamp255(g) << 8 | clamp255(b));
   }

   private static int clamp255(int v) {
      return Math.max(0, Math.min(255, v));
   }

   public int red() {
      return this.rgb() >> 16 & 0xFF;
   }

   public int green() {
      return this.rgb() >> 8 & 0xFF;
   }

   public int blue() {
      return this.rgb() & 0xFF;
   }

   /* ---- v2 colour mode ---- */

   public boolean rainbowEnabled() {
      return this.rainbow;
   }

   public float rainbowSpeed() {
      return this.rainbowSpeed;
   }

   public float rainbowOffset() {
      return this.rainbowOffset;
   }

   /** Switches to rainbow mode with a per-colour speed (cycles/sec) and phase offset. */
   public void setRainbow(boolean enabled, float speed, float offset) {
      this.rainbow = enabled;
      this.rainbowSpeed = speed > 0.0F ? speed : 1.0F;
      this.rainbowOffset = offset - (float) Math.floor(offset);
   }

   /**
    * Resolved colour to draw right now, as 0xFFrrggbb.
    * Returns the animated rainbow colour when rainbow mode is on, else the solid.
    */
   public int currentRgb(long timeMs) {
      if (!this.rainbow) {
         return this.color;
      }
      return 0xFF000000 | net.bluenetwork.client.ui.color.RainbowColor.rgb(timeMs, this.rainbowSpeed, this.rainbowOffset) & 0xFFFFFF;
   }

   /* ---- legacy hex draft typing (kept) ---- */

   public void typeHex(String ch) {
      if (this.hexDraft.length() >= 6) {
         this.hexDraft = "";
      }

      this.hexDraft = this.hexDraft + ch;
      this.applyHexDraft();
   }

   public void backspaceHex() {
      if (!this.hexDraft.isEmpty()) {
         this.hexDraft = this.hexDraft.substring(0, this.hexDraft.length() - 1);
         this.applyHexDraft();
      }
   }

   private void applyHexDraft() {
      if (!this.hexDraft.isEmpty()) {
         try {
            int parsed = Integer.parseInt(this.hexDraft, 16);
            int shift = (6 - this.hexDraft.length()) * 4;
            this.set(parsed << shift);
         } catch (NumberFormatException var3) {
         }
      }
   }

   public String hexDraft() {
      return this.hexDraft;
   }

   /* ---- persistence (backward compatible) ---- */

   @Override
   public JsonElement toJson() {
      if (!this.rainbow) {
         return new JsonPrimitive(String.format("%06X", this.rgb()));
      }
      JsonObject obj = new JsonObject();
      obj.addProperty("hex", String.format("%06X", this.rgb()));
      obj.addProperty("rainbow", true);
      obj.addProperty("speed", Double.valueOf(this.rainbowSpeed));
      obj.addProperty("offset", Double.valueOf(this.rainbowOffset));
      return obj;
   }

   @Override
   public void fromJson(JsonElement element) {
      try {
         if (element == null) {
            return;
         }
         if (element.isJsonPrimitive()) {
            // Legacy v0.15 format: "#RRGGBB" or "RRGGBB"
            String raw = element.getAsString().replace("#", "").trim();
            if (!raw.isEmpty()) {
               this.set((int) Long.parseLong(raw, 16));
            }
            this.rainbow = false;
            return;
         }
         if (element.isJsonObject()) {
            JsonObject obj = element.getAsJsonObject();
            if (obj.has("hex") && obj.get("hex").isJsonPrimitive()) {
               String raw = obj.get("hex").getAsString().replace("#", "").trim();
               if (!raw.isEmpty()) {
                  this.set((int) Long.parseLong(raw, 16));
               }
            }
            this.rainbow = obj.has("rainbow") && obj.get("rainbow").getAsBoolean();
            float speed = obj.has("speed") ? obj.get("speed").getAsFloat() : 1.0F;
            float offset = obj.has("offset") ? obj.get("offset").getAsFloat() : 0.0F;
            this.rainbowSpeed = speed > 0.0F ? speed : 1.0F;
            this.rainbowOffset = offset - (float) Math.floor(offset);
         }
      } catch (Throwable var3) {
      }
   }
}
