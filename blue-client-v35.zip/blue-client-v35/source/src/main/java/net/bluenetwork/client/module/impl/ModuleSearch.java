package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.ui.screen.ModuleMenuScreen;
import net.minecraft.client.MinecraftClient;

/**
 * Module Search (v3 catalogue H1, lightweight) — press the module key and the
 * reworked modules page opens straight into its type-to-filter search, the
 * fastest way to find and toggle any module.
 */
public class ModuleSearch extends Module {
   private boolean pending = false;

   public ModuleSearch() {
      super("Module Search", "Quick-launch the module search page", Category.MISC);
   }

   @Override
   protected void onEnable() {
      // Only arm the launch when the player is already in a world, i.e. the
      // module was turned on by a keypress/click. A config-restored enabled
      // state (player still null at load) must NOT pop the menu open the
      // moment a server is joined (feedback 2026-09-11).
      this.pending = MinecraftClient.getInstance().player != null;
   }

   @Override
   public void onTick() {
      if (!this.pending) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.currentScreen == null) {
         this.pending = false;
         mc.setScreen(new ModuleMenuScreen(BlueClient.getInstance()));
      }
   }
}
