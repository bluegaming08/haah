package net.bluenetwork.client.recorder;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Line;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import net.bluenetwork.client.BlueClient;

/**
 * Microphone / system-audio capture for the Screen Recorder.
 *
 * <h2>What Java can and cannot do</h2>
 * <ul>
 *   <li><b>Microphone</b> — fully supported. {@code javax.sound.sampled} gives
 *       us every input device on the machine through {@link #inputDevices()}
 *       and records it to a WAV file with no native code at all.</li>
 *   <li><b>System / game audio</b> — <b>not</b> capturable from pure Java.
 *       There is no loopback device in the JDK's audio API. It works only if
 *       the user's OS exposes a loopback input ("Stereo Mix" on Windows, a
 *       BlackHole / Loopback device on macOS, a PulseAudio monitor source on
 *       Linux), in which case it simply shows up in the device list and can be
 *       picked like any other mic. {@link #findLoopbackDevice()} tries to spot
 *       one automatically.</li>
 * </ul>
 *
 * <p>This honesty matters: a future agent should not waste a day trying to make
 * "record game sound" work without a native capture library. The proper fix is
 * an FFmpeg-based recorder shipped by the launcher — see
 * {@code README-LAUNCHER.md}.</p>
 *
 * <h2>Output</h2>
 * A WAV file next to the MP4, e.g. {@code blue-....mp4} plus
 * {@code blue-....wav}. They are intentionally left as two files: muxing audio
 * into the MP4 with JCodec means writing our own AAC encoder, which is far past
 * "lightweight". Any editor (or one FFmpeg command) merges them in seconds.
 */
public final class AudioRecorder {

   /** 44.1 kHz, 16-bit, stereo, signed little-endian — universally supported. */
   private static final AudioFormat FORMAT = new AudioFormat(44100.0F, 16, 2, true, false);

   private final AtomicBoolean running = new AtomicBoolean();
   private TargetDataLine line;
   private Thread worker;
   private Path outputFile;

   public boolean isRecording() {
      return this.running.get();
   }

   public Path outputFile() {
      return this.outputFile;
   }

   /* ===================================================================== */
   /* Device discovery                                                      */
   /* ===================================================================== */

   /** Every mixer on this machine that can actually record. Never throws. */
   public static List<String> inputDevices() {
      List<String> names = new ArrayList<>();
      try {
         for (Mixer.Info info : AudioSystem.getMixerInfo()) {
            Mixer mixer = AudioSystem.getMixer(info);
            for (Line.Info lineInfo : mixer.getTargetLineInfo()) {
               if (lineInfo instanceof DataLine.Info dataLine
                  && TargetDataLine.class.isAssignableFrom(dataLine.getLineClass())) {
                  names.add(info.getName());
                  break;
               }
            }
         }
      } catch (Throwable t) {
         BlueClient.LOGGER.warn("Recorder: could not list audio devices", t);
      }
      if (names.isEmpty()) {
         names.add("Default");
      }
      return names;
   }

   /**
    * Best guess at a system-audio loopback device, or {@code null}.
    * Matched by the names the common loopback drivers use.
    */
   public static String findLoopbackDevice() {
      for (String name : inputDevices()) {
         String lower = name.toLowerCase();
         if (lower.contains("stereo mix") || lower.contains("what u hear")
            || lower.contains("loopback") || lower.contains("monitor")
            || lower.contains("blackhole") || lower.contains("soundflower")) {
            return name;
         }
      }
      return null;
   }

   private static Mixer.Info mixerByName(String name) {
      if (name == null || name.isBlank() || "Default".equals(name)) {
         return null;
      }
      for (Mixer.Info info : AudioSystem.getMixerInfo()) {
         if (info.getName().equals(name)) {
            return info;
         }
      }
      return null;
   }

   /* ===================================================================== */
   /* Lifecycle                                                             */
   /* ===================================================================== */

   /**
    * Starts capturing to {@code wavFile}.
    *
    * @param deviceName a name from {@link #inputDevices()}, or null for the
    *                   system default
    * @return true if capture started; false is non-fatal — the video still
    *         records, just silently
    */
   public synchronized boolean start(Path wavFile, String deviceName) {
      if (this.running.get()) {
         return false;
      }
      this.outputFile = wavFile;
      try {
         DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
         Mixer.Info mixer = mixerByName(deviceName);
         this.line = mixer == null
            ? (TargetDataLine) AudioSystem.getLine(info)
            : (TargetDataLine) AudioSystem.getMixer(mixer).getLine(info);
         this.line.open(FORMAT);
         this.line.start();
      } catch (Throwable t) {
         BlueClient.LOGGER.warn("Recorder: audio capture unavailable ({})", t.toString());
         this.line = null;
         return false;
      }

      this.running.set(true);
      this.worker = new Thread(() -> {
         // AudioSystem.write on a live line blocks until the line is closed,
         // streaming straight to disk — no buffering of the whole take in RAM.
         try (AudioInputStream stream = new AudioInputStream(this.line)) {
            AudioSystem.write(stream, AudioFileFormat.Type.WAVE, new File(wavFile.toString()));
         } catch (Throwable t) {
            BlueClient.LOGGER.warn("Recorder: audio write failed", t);
         }
      }, "Blue Client Audio");
      this.worker.setDaemon(true);
      this.worker.start();
      return true;
   }

   /** Stops capture and finalises the WAV header. */
   public synchronized void stop() {
      if (!this.running.getAndSet(false)) {
         return;
      }
      try {
         if (this.line != null) {
            this.line.stop();
            // Closing the line ends the AudioInputStream, which lets
            // AudioSystem.write return and patch the WAV header with the
            // final length. Without this the file is unplayable.
            this.line.close();
         }
         if (this.worker != null) {
            this.worker.join(3000L);
         }
      } catch (InterruptedException e) {
         Thread.currentThread().interrupt();
      } catch (Throwable ignored) {
      }
      this.line = null;
      this.worker = null;
   }
}
