package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;

public class NoHurtCam extends Module {
   public NoHurtCam() {
      super("No Hurt Cam", "Removes the damage camera shake", Category.RENDER);
   }
}
