package net.bluenetwork.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.bluenetwork.client.module.impl.Nametags;
import net.bluenetwork.client.module.impl.ThirdPersonNametag;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Makes YOUR OWN nametag render in third person.
 *
 * <h2>v0.24.1 FIX: "3rd person nametag isnt working"</h2>
 *
 * <h3>Root cause</h3>
 * The {@code ThirdPersonNametag} module was registered and its mixin code was
 * correct — but it restyled a label that <b>Minecraft never draws</b>.
 *
 * <p>Reading {@code EntityRenderer.updateRenderState} bytecode:</p>
 * <pre>
 *   284: invokevirtual hasLabel(Entity, double)      // gate
 *   305: invokevirtual getDisplayName(Entity)
 *   308: putfield      EntityRenderState.displayName
 *   336: putfield      EntityRenderState.displayName  // <- the else branch: null
 * </pre>
 * So {@code displayName} is only populated when {@code hasLabel} returns true.
 * And {@code hasLabel} is:
 * <pre>
 *   entity.shouldRenderName()            // == isCustomNameVisible(), false for players
 *   || (hasCustomName() &amp;&amp; entity == dispatcher.targetedEntity)
 * </pre>
 * For your own player both are false, so {@code displayName} is left null. The
 * styling code in {@code PlayerEntityRendererMixin} begins with
 * {@code if (state.displayName == null) return;} — it was bailing out every
 * single frame. Nothing was broken about the styling; the label simply did not
 * exist.
 *
 * <p>Vanilla also hides your own tag for a second reason: in first person your
 * head is not rendered, so a floating name would hover over nothing.</p>
 *
 * <h3>The fix</h3>
 * Force {@code hasLabel} to return true for the local player, but <b>only</b>
 * when we are in third person and a module that wants the tag is enabled.
 * Once {@code hasLabel} is true, vanilla populates {@code displayName} itself
 * and the existing styling / badge code in {@code PlayerEntityRendererMixin}
 * runs exactly as it was always meant to.
 *
 * <p>{@link ModifyExpressionValue} on the {@code hasLabel} call inside
 * {@code updateRenderState} is the minimal intervention: we change one boolean
 * at one call site and let all of vanilla's label machinery do the rest. A
 * plain {@code @Redirect} is forbidden in this codebase (MixinExtras 0.5.4
 * CCE), and overwriting {@code hasLabel} wholesale would fight every other
 * nametag mod on the user's list (they run WaveyCapes, ETF/EMF and more).</p>
 *
 * <h3>Why first person is excluded</h3>
 * Drawing your own nametag in first person puts a name in the middle of the
 * screen attached to an invisible body. {@code Nametags.ownNametag()} already
 * checks the perspective; this mixin repeats the check so
 * {@code ThirdPersonNametag} on its own behaves correctly too.
 */
@Mixin(EntityRenderer.class)
public abstract class OwnNametagMixin {

   /*
    * SIGNATURE WARNING (fixed v0.25.1).
    *
    * A @ModifyExpressionValue handler takes the expression value, "optionally
    * followed by the enclosing method's parameters" - ALL of them or NONE. A
    * prefix subset does not bind.
    *
    * This handler originally captured only (boolean, Entity) out of
    * updateRenderState(Entity, EntityRenderState, float). It compiled, and the
    * old verifier passed it, but combined with require = 0 it failed SILENTLY:
    * your own third-person nametag simply never appeared and nothing was
    * logged. verify_mixins.py now checks this automatically.
    */

   @ModifyExpressionValue(
      method = "updateRenderState",
      at = @At(value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/EntityRenderer;hasLabel(Lnet/minecraft/entity/Entity;D)Z"),
      require = 0)
   private boolean blueclient$showOwnNametag(boolean original,
                                             Entity entity,
                                             net.minecraft.client.render.entity.state.EntityRenderState state,
                                             float tickDelta) {
      if (original) {
         return true;                       // vanilla already wants a label
      }
      try {
         if (!(entity instanceof PlayerEntity)) {
            return false;
         }
         MinecraftClient client = MinecraftClient.getInstance();
         if (client == null || client.player == null
            || !client.player.getUuid().equals(entity.getUuid())) {
            return false;                   // not us
         }
         // First person: the tag would float over an invisible body.
         if (client.options == null || client.options.getPerspective().isFirstPerson()) {
            return false;
         }
         /*
          * Not while flying with an elytra.
          *
          * The nametag is drawn at a fixed height above the entity origin,
          * which assumes a standing player. Gliding rotates the body flat, so
          * the label detaches and floats through the model - the "3rd person
          * nametag breaks the elytra" report. Vanilla never has to solve this
          * because it does not label you at all.
          *
          * Hiding it while gliding is the honest fix: the tag is for seeing
          * your own cosmetics, and you cannot read it mid-flight anyway.
          */
         if (entity instanceof net.minecraft.entity.LivingEntity living
            && living.isGliding()) {
            return false;
         }
         // Only if a module actually asked for it.
         return ThirdPersonNametag.active() || Nametags.ownNametag();
      } catch (Throwable t) {
         return false;                      // never break entity rendering
      }
   }
}
