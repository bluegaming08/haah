package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.optimization.PerformanceOptimizer;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Memory Watchdog (v3 catalogue G2) — periodically checks JVM heap usage and,
 * when it exceeds a threshold, requests a soft garbage collection (and
 * notifies). Off by default; conservative interval + threshold defaults.
 *
 * <p>Reads the same MB-based counters as the DEV HUD
 * ({@link PerformanceOptimizer#getMemoryUsage()}/{@link #getMaxMemory()}) so
 * the reported percentage matches what the user sees elsewhere.
 */
public class MemoryWatchdog extends Module {
   private final NumberSetting threshold = new NumberSetting("Threshold %", "Heap usage percent that triggers a GC", 80.0, 40.0, 99.0, 1.0);
   private final NumberSetting interval = new NumberSetting("Check every", "Seconds between heap checks", 15.0, 5.0, 300.0, 5.0);
   private final BooleanSetting autoGc = new BooleanSetting("Auto GC", "Run a soft garbage collection when over threshold", true);
   private final BooleanSetting notify = new BooleanSetting("Notify", "Show a toast when a GC is triggered", true);

   private long lastCheck = 0L;

   public MemoryWatchdog() {
      super("Memory Watchdog", "Auto garbage-collect when memory gets high", Category.MISC);
      this.addSettings(new Setting[]{this.threshold, this.interval, this.autoGc, this.notify});
   }

   @Override
   public void onTick() {
      long now = System.currentTimeMillis();
      long intervalMs = (long) (this.interval.get() * 1000.0);
      if (now - this.lastCheck < intervalMs) {
         return;
      }
      this.lastCheck = now;

      long max = PerformanceOptimizer.getMaxMemory();
      long used = PerformanceOptimizer.getMemoryUsage();
      if (max <= 0L) {
         return;
      }
      long pct = used * 100L / max;
      if (pct < this.threshold.getInt()) {
         return;
      }

      if (this.autoGc.get()) {
         // Explicit user-configured trigger; the module's whole purpose is this check.
         PerformanceOptimizer.optimizeMemory();
      }
      if (this.notify.get()) {
         try {
            BlueClient.getInstance().notificationManager().add(
               "Memory " + pct + "% - " + (this.autoGc.get() ? "GC requested" : "high"), 0xFF4D8DFF);
         } catch (Throwable ignored) {
         }
      }
   }
}
