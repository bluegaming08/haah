package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.brand.WindowStyle;
import net.bluenetwork.client.gui.MainMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({TitleScreen.class})
public abstract class TitleScreenMixin {
   private static boolean blueclient$titleSet = false;

   @Inject(
      method = {"init"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$replaceTitleScreen(CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (!blueclient$titleSet) {
         blueclient$titleSet = true;
         mc.getWindow().setTitle("Blue Client 1.21.11 (Beta)");
         WindowStyle.apply();
         BlueClient.LOGGER.info("Blue Client main menu active");
      }

      if (BlueClient.getInstance().settings().customMainMenu()) {
         mc.setScreen(new MainMenuScreen());
         ci.cancel();
      }
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void blueclient$addSwitchButton(CallbackInfo ci) {
      if (!BlueClient.getInstance().settings().customMainMenu()) {
         ((ScreenInvoker)this).blueclient$invokeAddDrawableChild(ButtonWidget.builder(Text.literal("BLUE"), button -> {
            BlueClient.getInstance().settings().customMainMenu(true);
            MinecraftClient.getInstance().setScreen(new MainMenuScreen());
         }).dimensions(4, 4, 46, 14).build());
      }
   }
}
