package net.bluenetwork.client.ui.material;

/**
 * Surface rendering quality for glass UI (plan §3.6). A global preference
 * (default GLASS) picks how much of the material pipeline runs:
 *
 * <ul>
 *   <li>{@link #GLASS} — full liquid-glass material: real translucency, rim
 *       light, sheen, drop shadow, accent hairline on interactive elements.
 *       Real background blur plugs in here once the §7.1 spike lands (Phase 1b).</li>
 *   <li>{@link #MATTE} — translucent but flat: tint + border only. Budget mode.</li>
 *   <li>{@link #FLAT} — legacy opaque panels (v0.15 look). Last-resort/HW-safety.</li>
 * </ul>
 */
public enum GlassSurface {
   GLASS("Glass"),
   MATTE("Matte"),
   FLAT("Flat");

   private final String display;

   GlassSurface(String display) {
      this.display = display;
   }

   public String display() {
      return display;
   }

   public static GlassSurface defaultSurface() {
      return GLASS;
   }

   public static GlassSurface parse(String value) {
      if (value != null) {
         for (GlassSurface s : values()) {
            if (s.name().equalsIgnoreCase(value.trim())) {
               return s;
            }
         }
      }
      return defaultSurface();
   }
}
