package net.bluenetwork.client.module.impl;

import java.util.List;
import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Formatting;

/**
 * Name Formatter (v3 catalogue C7) — visual-only: your own name gets a custom
 * colour whenever it appears in chat or tab messages this client renders.
 * Server-safe (pure local formatting, never re-sent).
 */
public class NameFormatter extends Module {
   private static final String[] COLORS = {"Aqua", "Yellow", "Gold", "Green", "Pink", "White"};
   private final ModeSetting color = new ModeSetting("Name color", "Colour applied to your name", List.of(COLORS), "Gold");

   public NameFormatter() {
      super("Name Formatter", "Colour your name in chat (visual only)", Category.MISC);
      this.addSettings(new Setting[]{this.color});
   }

   /** Formatting if the current player's name appears in this message. */
   public static Formatting forName(String content) {
      try {
         if (content == null || content.isEmpty()) {
            return null;
         }
         Module m = BlueClient.getInstance().moduleManager().byName("Name Formatter");
         if (!(m instanceof NameFormatter nf) || !nf.isEnabled()) {
            return null;
         }
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player == null || mc.player.getGameProfile() == null) {
            return null;
         }
         String name = mc.player.getGameProfile().name();
         if (name == null || name.isEmpty() || !content.toLowerCase(Locale.ROOT).contains(name.toLowerCase(Locale.ROOT))) {
            return null;
         }
         return fromName(nf.color.get());
      } catch (Throwable ignored) {
      }
      return null;
   }

   private static Formatting fromName(String name) {
      if (name == null) {
         return Formatting.GOLD;
      }
      switch (name) {
         case "Yellow":
            return Formatting.YELLOW;
         case "Gold":
            return Formatting.GOLD;
         case "Green":
            return Formatting.GREEN;
         case "Pink":
            return Formatting.LIGHT_PURPLE;
         case "White":
            return Formatting.WHITE;
         default:
            return Formatting.AQUA;
      }
   }
}
