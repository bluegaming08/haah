package net.bluenetwork.client.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public final class JsonUtil {
   private static final Gson PRETTY = new GsonBuilder().setPrettyPrinting().create();

   private JsonUtil() {
   }

   public static String pretty(JsonObject object) {
      return PRETTY.toJson(object);
   }
}
