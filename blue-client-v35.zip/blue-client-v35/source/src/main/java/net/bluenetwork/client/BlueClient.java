package net.bluenetwork.client;

import net.bluenetwork.client.account.AccountManager;
import net.bluenetwork.client.command.CommandManager;
import net.bluenetwork.client.config.ConfigManager;
import net.bluenetwork.client.dev.DevDebugHud;
import net.bluenetwork.client.dev.DevFlags;
import net.bluenetwork.client.dev.DevQuickSwitcher;
import net.bluenetwork.client.dev.DevSmoke;
import net.bluenetwork.client.event.ClientTickEvent;
import net.bluenetwork.client.optimization.PerformanceOptimizer;
import net.bluenetwork.client.event.EventBus;
import net.bluenetwork.client.hud.HudManager;
import net.bluenetwork.client.keybind.KeybindManager;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.ModuleManager;
import net.bluenetwork.client.news.NewsManager;
import net.bluenetwork.client.notification.NotificationManager;
import net.bluenetwork.client.notification.SocialToasts;
import net.minecraft.client.MinecraftClient;
import net.bluenetwork.client.ui.screen.ChatScreen;
import net.bluenetwork.client.presence.PresenceManager;
import net.bluenetwork.client.settings.ClientSettings;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlueClient implements ClientModInitializer {
   public static final String MOD_ID = "blueclient";
   public static final String MOD_NAME = "Blue Client";
   public static String MOD_VERSION = "dev";
   /**
    * Owner-facing release name: "v12", "v13", ...
    *
    * <p>Read from the {@code blueclient:release} custom entry in
    * fabric.mod.json, which Gradle fills from {@code release_name} in
    * gradle.properties. Kept separate from {@link #MOD_VERSION} because Fabric
    * requires that to be strict semver, while the owner tracks builds by
    * release number. Falls back to the semver if the entry is missing.</p>
    */
   public static String RELEASE_NAME = "dev";

   /** e.g. {@code "v13 (0.24.6)"} - what the UI should show. */
   public static String displayVersion() {
      return "dev".equals(RELEASE_NAME) ? MOD_VERSION : RELEASE_NAME + " (" + MOD_VERSION + ")";
   }
   public static final Logger LOGGER = LoggerFactory.getLogger("Blue Client");
   private static BlueClient instance;
   private final EventBus eventBus = new EventBus();
   private final ModuleManager moduleManager = new ModuleManager();
   private final HudManager hudManager = new HudManager(this);
   private final ConfigManager configManager = new ConfigManager(this);
   private final KeybindManager keybindManager = new KeybindManager(this);
   private final CommandManager commandManager = new CommandManager(this);
   private final NotificationManager notificationManager = new NotificationManager();
   private final NewsManager newsManager = new NewsManager();
   private final ClientSettings settings = new ClientSettings();
   private final PresenceManager presence = new PresenceManager();
   private final AccountManager accountManager = new AccountManager();
   private final net.bluenetwork.client.social.FriendsManager friends =
      new net.bluenetwork.client.social.FriendsManager();
   /** v0.24.0: cosmetics (capes + Blue Stars). */
   private final net.bluenetwork.client.cosmetics.CosmeticsManager cosmetics =
      new net.bluenetwork.client.cosmetics.CosmeticsManager();

   public BlueClient() {
      instance = this;
   }

   public static BlueClient getInstance() {
      return instance;
   }

   public void onInitializeClient() {
      MOD_VERSION = FabricLoader.getInstance().getModContainer("blueclient").map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("dev");
      RELEASE_NAME = FabricLoader.getInstance().getModContainer("blueclient")
         .map(c -> c.getMetadata().getCustomValue("blueclient:release"))
         .map(v -> v.getAsString())
         .orElse(MOD_VERSION);
      LOGGER.info("Initializing {} {} (semver {})", "Blue Client", RELEASE_NAME, MOD_VERSION);
      this.settings.load();
      this.moduleManager.registerDefaults();
      PerformanceOptimizer.setParticleOptimization(this.settings.perfParticles());
      PerformanceOptimizer.setEntityCulling(this.settings.perfCulling());
      PerformanceOptimizer.setAdaptiveFramerate(this.settings.perfAdaptive());
      if (this.settings.perfOptimizer()) {
         PerformanceOptimizer.setEnabled(true);
      }
      this.eventBus.subscribe(ClientTickEvent.class, event -> PerformanceOptimizer.tick());
      // blueclient:hello handshake (see README-PLUGIN.md §2). Registers the
      // payload types and the join hook; no-ops on servers without the plugin.
      net.bluenetwork.client.net.BlueHelloPacket.register();
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> {
         this.eventBus.post(new ClientTickEvent());
         this.moduleManager.tickModules();
         net.bluenetwork.client.net.BlueHelloPacket.tick();
         this.hudManager.tick();
         this.cosmetics.tick();
         net.bluenetwork.client.optimization.ChunkPreloader.tick();
         // Friends presence/refresh. Cheap: compares timestamps and only
         // starts a request when one is actually due. Never blocks the tick.
         this.friends.onTick();
      });
      HudElementRegistry.addLast(Identifier.of("blueclient", "hud"), (context, tickCounter) -> this.hudManager.render(context));
      this.keybindManager.init();
      this.commandManager.init();
      this.configManager.load();
      Runtime.getRuntime().addShutdownHook(new Thread(this.configManager::save));
      this.presence.start();
      this.cosmetics.start();
      this.accountManager.load();
      try {
         this.friends.init();
      } catch (Throwable t) {
         // Friends must NEVER prevent the client from launching.
         LOGGER.warn("[Social] Friends system failed to start; continuing without it", t);
      }
      Runtime.getRuntime().addShutdownHook(new Thread(this.friends::shutdown));
      // Hand back any router port we opened for LAN invites, so we do not
      // leave a forwarding rule pointing at a dead port.
      Runtime.getRuntime().addShutdownHook(
         new Thread(net.bluenetwork.client.social.lan.LanInvites::shutdown));

      // What the clickable right-side toasts DO. Registered here rather than
      // inside SocialToasts so that class stays pure rendering + hit testing
      // and has no dependency on screens or the network layer.
      SocialToasts.onMessageClick = toast -> MinecraftClient.getInstance().execute(() -> {
         MinecraftClient mc = MinecraftClient.getInstance();
         mc.setScreen(new ChatScreen(mc.currentScreen, toast.conversationId()));
      });
      SocialToasts.onInviteClick = toast -> {
         // acceptInvite resolves the address and connects on the render thread.
         this.friends.acceptInvite(toast.conversationId());
      };
      if (this.settings.configVersion() < 1) {
         Module zoom = this.moduleManager.byName("Zoom");
         if (zoom != null && zoom.isEnabled()) {
            zoom.setEnabled(false);
         }

         this.settings.configVersion(1);
      }

      LOGGER.info("{} loaded with {} modules", "Blue Client", this.moduleManager.getModules().size());

      // Phase 0 dev tooling — inert unless launched with -Dblueclient.dev=true
      if (DevFlags.enabled()) {
         DevSmoke.selfCheck();
         HudElementRegistry.addLast(Identifier.of(MOD_ID, "dev-debug"),
            (context, tickCounter) -> DevDebugHud.render(context));
         DevQuickSwitcher.install(this);
         LOGGER.info("[Dev] dev mode active (F6 modules menu / F7 settings / F8 accounts / debug HUD)");
      }
   }

   public EventBus eventBus() {
      return this.eventBus;
   }

   public ModuleManager moduleManager() {
      return this.moduleManager;
   }

   public HudManager hudManager() {
      return this.hudManager;
   }

   public ConfigManager configManager() {
      return this.configManager;
   }

   public KeybindManager keybindManager() {
      return this.keybindManager;
   }

   public CommandManager commandManager() {
      return this.commandManager;
   }

   /** The Friends system. Never null; check {@code available()} before use. */
   public net.bluenetwork.client.social.FriendsManager friends() {
      return this.friends;
   }

   public NotificationManager notificationManager() {
      return this.notificationManager;
   }

   public NewsManager newsManager() {
      return this.newsManager;
   }

   public ClientSettings settings() {
      return this.settings;
   }

   public AccountManager accountManager() {
      return this.accountManager;
   }

   public PresenceManager presence() {
      return this.presence;
   }

   /** v0.24.0: cosmetics manager (capes, Blue Stars). */
   public net.bluenetwork.client.cosmetics.CosmeticsManager cosmetics() {
      return this.cosmetics;
   }
}
