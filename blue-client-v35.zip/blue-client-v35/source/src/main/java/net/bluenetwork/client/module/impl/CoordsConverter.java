package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.ui.screen.CoordinatesScreen;
import net.minecraft.client.MinecraftClient;

/**
 * Coords Converter (v3 catalogue H2) — bind a key and enable: your position
 * pops up converted to the other dimension (Overworld ↔ Nether). Closes back to
 * where you were.
 */
public class CoordsConverter extends Module {
   private boolean pending = false;

   public CoordsConverter() {
      super("Coords Converter", "Nether <-> Overworld coordinate popup", Category.MISC);
   }

   @Override
   protected void onEnable() {
      this.pending = true;
   }

   @Override
   protected void onDisable() {
      this.pending = false;
   }

   @Override
   public void onTick() {
      if (!this.pending) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.world != null && mc.currentScreen == null) {
         this.pending = false;
         mc.setScreen(new CoordinatesScreen(BlueClient.getInstance(), null));
      }
   }
}
