package net.bluenetwork.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.bluenetwork.client.module.impl.WeatherChanger;
import net.minecraft.client.render.WeatherRendering;
import net.minecraft.client.render.state.WeatherRenderState;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Makes the Weather Changer's rain / snow actually visible.
 *
 * <h2>What vanilla does</h2>
 * {@code WeatherRendering.buildPrecipitationPieces(World, int, float, Vec3d,
 * WeatherRenderState)} walks every column within the weather radius and, for
 * each one:
 * <pre>
 *   1. asks the private getPrecipitationAt(world, pos) what falls there
 *      -> returns NONE in a dry biome, and the column is skipped
 *   2. places the column top at world.getTopY(MOTION_BLOCKING, x, z)
 *      -> that is the top of your ROOF, so indoors the rain draws above you
 * </pre>
 * Those two lines are exactly why forcing rain "doesn't work under a barrier",
 * which is the bug the owner reported.
 *
 * <h2>What we change</h2>
 * Two {@link ModifyExpressionValue} hooks — surgical value swaps, no vanilla
 * logic is skipped or duplicated:
 * <ul>
 *   <li>the result of {@code getPrecipitationAt} becomes the forced type, so
 *       every column produces weather (or none, in CLEAR);</li>
 *   <li>the result of {@code getTopY} is clamped to just above the camera, so
 *       the column starts in front of your eyes instead of on the roof.</li>
 * </ul>
 *
 * <h3>Why not {@code @Redirect}?</h3>
 * Plain {@code @Redirect} is banned in this project — it blows up with a
 * ClassCastException under MixinExtras 0.5.4. {@code @ModifyExpressionValue} is
 * the supported way to rewrite a call's return value and composes with other
 * mods instead of claiming the call site exclusively.
 *
 * <p>Both hooks are {@code require = 0}: if a future Minecraft version renames
 * or inlines these calls, the weather module quietly loses the roof fix rather
 * than crashing the whole game at startup.</p>
 */
@Mixin(WeatherRendering.class)
public abstract class WeatherRenderingMixin {

   /** How far above the camera a forced precipitation column starts. */
   private static final int BLUECLIENT$ROOF_CLEARANCE = 3;

   @ModifyExpressionValue(
      method = "buildPrecipitationPieces",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WeatherRendering;getPrecipitationAt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"),
      require = 0)
   private Biome.Precipitation blueclient$forcePrecipitation(Biome.Precipitation original) {
      Biome.Precipitation forced = WeatherChanger.forcedPrecipitation();
      return forced == null ? original : forced;
   }

   /**
    * Clamps the column top to just above the camera while "Ignore roof" is on.
    *
    * <p>The trailing parameters mirror the target method's own parameters —
    * MixinExtras passes them through, which is how we get the camera position
    * without storing state on the mixin.</p>
    */
   @ModifyExpressionValue(
      method = "buildPrecipitationPieces",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getTopY(Lnet/minecraft/world/Heightmap$Type;II)I"),
      require = 0)
   private int blueclient$ignoreRoof(int original, World world, int ticks, float tickDelta,
                                     Vec3d cameraPos, WeatherRenderState state) {
      if (!WeatherChanger.ignoreRoofActive()) {
         return original;
      }
      int aboveCamera = (int) Math.floor(cameraPos.y) + BLUECLIENT$ROOF_CLEARANCE;
      // Only ever LOWER the column: outdoors the real terrain height is already
      // correct and looks better than a flat sheet at head height.
      return Math.min(original, aboveCamera);
   }
}
