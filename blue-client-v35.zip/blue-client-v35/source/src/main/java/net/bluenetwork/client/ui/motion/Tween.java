package net.bluenetwork.client.ui.motion;

/**
 * Lightweight one-shot tween for v2 UI. Backs panel opens, drawer expansions,
 * hover glows and colour morphs. Time is supplied by the caller (render frame
 * time) so it stays deterministic and testable — no hidden clock.
 *
 * <pre>{@code
 * Tween open = Tween.of(Motion.PANEL_MS, Easing.EASE_OUT_EXPO);
 * open.forward();
 * ...
 * float p = open.eased(nowMs);   // 0..1 eased
 * }</pre>
 */
public final class Tween {
   private final long durationMs;
   private final Easing easing;
   private long startMs = Long.MIN_VALUE;
   private boolean forward = true;
   private float cachedValue = 0.0F;

   private Tween(long durationMs, Easing easing) {
      this.durationMs = Math.max(1L, durationMs);
      this.easing = easing;
   }

   public static Tween of(long durationMs, Easing easing) {
      return new Tween(durationMs, easing);
   }

   /** Starts playing toward 1. */
   public Tween forward() {
      this.forward = true;
      this.startMs = now();
      return this;
   }

   /** Starts playing toward 0. */
   public Tween backward() {
      this.forward = false;
      this.startMs = now();
      return this;
   }

   /** Snap to an instant value without animating. */
   public Tween snap(float value) {
      this.cachedValue = Math.max(0.0F, Math.min(1.0F, value));
      this.startMs = Long.MIN_VALUE;
      return this;
   }

   public boolean playing() {
      return startMs != Long.MIN_VALUE;
   }

   public boolean isFinished(long nowMs) {
      return playing() && progress(nowMs) >= 1.0F;
   }

   /** Raw linear progress 0..1 in the current direction. */
   public float progress(long nowMs) {
      if (startMs == Long.MIN_VALUE) {
         return forward ? cachedValue : 1.0F - cachedValue;
      }
      float elapsed = (float) (nowMs - startMs) / (float) durationMs;
      float p = Math.max(0.0F, Math.min(1.0F, elapsed));
      if (!forward) {
         p = 1.0F - p;
      }
      return p;
   }

   /** Progress passed through the easing curve. */
   public float eased(long nowMs) {
      float p = progress(nowMs);
      cachedValue = p;
      return easing.apply(p);
   }

   public float value() {
      return cachedValue;
   }

   private static long now() {
      return System.currentTimeMillis();
   }
}
