package net.bluenetwork.client.ui;

import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.DrawContext;

/**
 * The visual language of the Social screen, modelled on X (Twitter).
 *
 * <h2>Why a kit instead of ad-hoc drawing</h2>
 * The old Social screen drew every control inline with its own hand-tuned
 * numbers, which is why it looked like a debug menu next to the account
 * manager. Everything here is one shared set of primitives - the same radii,
 * the same hover easing, the same type scale - so the whole screen is
 * consistent by construction rather than by discipline.
 *
 * <h2>The palette</h2>
 * X's dark theme is a near-black canvas, a slightly lighter rail, hairline
 * dividers at very low alpha, and exactly one saturated accent. The restraint
 * is the point: when almost everything is greyscale, the blue actually means
 * something.
 */
public final class XKit {

   /* ---- palette ---------------------------------------------------- */

   /** Page background - near black, like X's dim canvas. */
   public static final int BG = 0xFF000000;
   /** Raised surface: cards, the composer, hover states. */
   public static final int SURFACE = 0xFF16181C;
   /** Hover wash over a surface. */
   public static final int HOVER = 0x14FFFFFF;
   /** Hairline divider. X uses a very low-contrast grey, not a bright line. */
   public static final int DIVIDER = 0xFF2F3336;
   /** Primary text. */
   public static final int TEXT = 0xFFE7E9EA;
   /** Secondary text: handles, timestamps, counts. */
   public static final int MUTED = 0xFF71767B;
   /** The one accent. */
   public static final int BLUE = 0xFF1D9BF0;
   /** Like. */
   public static final int PINK = 0xFFF91880;
   /** Repost. */
   public static final int GREEN = 0xFF00BA7C;
   /** Blue+ gold. */
   public static final int GOLD = 0xFFFFD400;
   /** Destructive. */
   public static final int RED = 0xFFF4212E;

   private XKit() {
   }

   /* ---- primitives -------------------------------------------------- */

   /** A full-width hairline, as X separates timeline items. */
   public static void divider(DrawContext ctx, float x, float y, float w) {
      SmoothRect.fill(ctx, x, y, w, 1.0F, 0.0F, DIVIDER);
   }

   /**
    * A pill button.
    *
    * @param filled true for the solid accent style (the Post button), false
    *               for the outlined style (Following, secondary actions)
    */
   public static void pill(DrawContext ctx, String label, float x, float y,
                           float w, float h, boolean hovered, boolean filled,
                           int accent, String animKey) {
      float hov = Anim.to(animKey, hovered);
      float r = h / 2.0F;

      if (filled) {
         // Hover darkens rather than lightens, which is what X does.
         SmoothRect.fill(ctx, x, y, w, h, r,
            Anim.mixColor(accent, shade(accent, 0.85F), hov));
      } else {
         SmoothRect.fill(ctx, x, y, w, h, r,
            Anim.mixColor(0x00000000, HOVER, hov));
         SmoothRect.outline(ctx, x, y, w, h, r, 1.0F, DIVIDER);
      }

      float size = 8.5F;
      float tw = TextPainter.poppinsWidth(label, size);
      TextPainter.drawPoppins(ctx, label, x + (w - tw) / 2.0F,
         y + (h - size) / 2.0F + 0.5F,
         filled ? 0xFFFFFFFF : TEXT, size);
   }

   /**
    * A left-rail navigation item: icon, label, and an active pill behind both.
    *
    * @param badge a count to show as a red dot, or 0 for none
    */
   public static void navItem(DrawContext ctx, String icon, String label,
                              float x, float y, float w, float h,
                              boolean active, boolean hovered, int badge,
                              String animKey) {
      float hov = Anim.to(animKey, hovered);
      if (hov > 0.01F) {
         SmoothRect.fill(ctx, x, y, w, h, h / 2.0F,
            Anim.mixColor(0x00000000, HOVER, hov));
      }

      int iconSize = 14;
      float iy = y + (h - iconSize) / 2.0F;
      int col = active ? TEXT : MUTED;
      RenderUtil.drawIcon(ctx, icon, Math.round(x + 10), Math.round(iy),
         iconSize, col);

      // Active items are bold-weight in X; Poppins semibold is our stand-in.
      float size = 9.5F;
      TextPainter.drawPoppins(ctx, label, x + 10 + iconSize + 9,
         y + (h - size) / 2.0F + 0.5F, col, size);

      if (badge > 0) {
         String n = badge > 99 ? "99+" : String.valueOf(badge);
         float bw = TextPainter.poppinsWidth(n, 6.5F) + 7;
         float bx = x + 10 + iconSize - 4;
         SmoothRect.fill(ctx, bx, iy - 3, bw, 9, 4.5F, BLUE);
         TextPainter.drawPoppins(ctx, n, bx + 3.5F, iy - 1.5F, 0xFFFFFFFF, 6.5F);
      }
   }

   /**
    * A circular icon button - the engagement controls under a post.
    *
    * <p>X grows a translucent disc behind the icon on hover, tinted with the
    * action's own colour. That tinted disc is most of why those buttons feel
    * good to press.</p>
    *
    * @return the total width consumed including the count
    */
   public static float action(DrawContext ctx, String icon, int count,
                              float x, float y, boolean hovered, boolean active,
                              int accent, String animKey) {
      float hov = Anim.to(animKey, hovered);
      float act = Anim.to(animKey + ":on", active);

      float disc = 17.0F;
      float cxp = x + disc / 2.0F;
      float cyp = y + disc / 2.0F;

      if (hov > 0.01F) {
         SmoothRect.fill(ctx, cxp - disc / 2.0F, cyp - disc / 2.0F, disc, disc,
            disc / 2.0F, Anim.mixColor(0x00000000, alpha(accent, 0.12F), hov));
      }

      int col = Anim.mixColor(Anim.mixColor(MUTED, accent, hov), accent, act);

      // Active icons pop a touch larger, the way a liked heart does.
      int size = 11 + Math.round(act);
      RenderUtil.drawIcon(ctx, icon, Math.round(cxp - size / 2.0F),
         Math.round(cyp - size / 2.0F), size, col);

      float w = disc;
      if (count > 0) {
         String n = compact(count);
         TextPainter.drawPoppins(ctx, n, x + disc + 1, y + 5.0F, col, 7.5F);
         w += TextPainter.poppinsWidth(n, 7.5F) + 4;
      }
      return w + 14;
   }

   /**
    * Draws a player avatar as a circle, with an initial fallback.
    *
    * <p>The fallback tint is derived from the name so it is stable per player
    * instead of a grey blob for everyone, and the layout never jumps when the
    * real skin finishes loading.</p>
    */
   public static void avatar(DrawContext ctx, String name, float x, float y,
                             float size) {
      /*
       * Resolve the ACCOUNT name to the player's chosen Minecraft skin.
       *
       * Posts pass a skin name (the feeds return one), but notifications,
       * chat headers and a few other rows only ever had a username to hand.
       * The same person therefore rendered with two different faces depending
       * on which screen you were looking at - the mismatch the owner reported
       * twice.
       *
       * Doing the lookup HERE means every caller is correct by default, and a
       * caller that already has the skin passes it through unchanged.
       */
      name = net.bluenetwork.client.social.SkinIndex.resolve(name);

      if (name != null && !name.isBlank()
          && !net.bluenetwork.client.account.PlayerHeads.unavailable(name)) {
         var tex = net.bluenetwork.client.account.PlayerHeads.bust(name);
         if (tex != null) {
            ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,
               tex, Math.round(x), Math.round(y), 0.0F, 0.0F,
               Math.round(size), Math.round(size),
               Math.round(size), Math.round(size));
            return;
         }
      }
      int tint = 0xFF000000 | (Math.abs(java.util.Objects.hashCode(name)) & 0x3F3F3F)
         | 0x1D3040;
      SmoothRect.fill(ctx, x, y, size, size, size / 2.0F, tint);
      String ch = name == null || name.isEmpty()
         ? "?" : name.substring(0, 1).toUpperCase(java.util.Locale.ROOT);
      float cw = TextPainter.poppinsWidth(ch, size * 0.46F);
      TextPainter.drawPoppins(ctx, ch, x + (size - cw) / 2.0F,
         y + size * 0.26F, TEXT, size * 0.46F);
   }

   /** A rounded input row, X's search/composer style. */
   public static void inputBox(DrawContext ctx, float x, float y, float w,
                               float h, boolean focused) {
      SmoothRect.fill(ctx, x, y, w, h, h / 2.0F, focused ? BG : SURFACE);
      SmoothRect.outline(ctx, x, y, w, h, h / 2.0F, 1.0F,
         focused ? BLUE : 0x00000000);
   }

   /* ---- helpers ------------------------------------------------------ */

   /** 1200 -> "1.2K", 3400000 -> "3.4M". X shortens every count this way. */
   public static String compact(long n) {
      if (n < 1000L) {
         return String.valueOf(n);
      }
      if (n < 1_000_000L) {
         float k = n / 1000.0F;
         return (k < 10.0F ? trim1(k) : String.valueOf(Math.round(k))) + "K";
      }
      float m = n / 1_000_000.0F;
      return (m < 10.0F ? trim1(m) : String.valueOf(Math.round(m))) + "M";
   }

   private static String trim1(float v) {
      String s = String.format(java.util.Locale.ROOT, "%.1f", v);
      return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
   }

   /** "2h", "3d" - X's terse relative time for anything under a week. */
   public static String shortAge(long epochSeconds) {
      if (epochSeconds <= 0L) {
         return "";
      }
      long secs = System.currentTimeMillis() / 1000L - epochSeconds;
      if (secs < 60L) {
         return Math.max(1L, secs) + "s";
      }
      if (secs < 3600L) {
         return (secs / 60L) + "m";
      }
      if (secs < 86400L) {
         return (secs / 3600L) + "h";
      }
      if (secs < 604800L) {
         return (secs / 86400L) + "d";
      }
      return (secs / 604800L) + "w";
   }

   /** ARGB with a proportional alpha. */
   public static int alpha(int argb, float a) {
      int al = Math.max(0, Math.min(255, Math.round(a * 255.0F)));
      return (al << 24) | (argb & 0xFFFFFF);
   }

   /** Multiplies RGB toward black, keeping alpha. */
   public static int shade(int argb, float factor) {
      int a = (argb >>> 24) & 0xFF;
      int r = Math.round(((argb >>> 16) & 0xFF) * factor);
      int g = Math.round(((argb >>> 8) & 0xFF) * factor);
      int b = Math.round((argb & 0xFF) * factor);
      return (a << 24) | (r << 16) | (g << 8) | b;
   }

   /** Truncates with an ellipsis so long text never overruns its column. */
   public static String fit(String text, float maxW, float size) {
      if (text == null) {
         return "";
      }
      if (TextPainter.poppinsWidth(text, size) <= maxW) {
         return text;
      }
      String out = text;
      while (out.length() > 1
             && TextPainter.poppinsWidth(out + "...", size) > maxW) {
         out = out.substring(0, out.length() - 1);
      }
      return out + "...";
   }

   /**
    * Wraps text to a width, returning the lines.
    *
    * <p>Posts are free text, so without wrapping a long one simply ran off the
    * side of the card - which the old screen did.</p>
    */
   public static java.util.List<String> wrap(String text, float maxW, float size,
                                             int maxLines) {
      java.util.List<String> out = new java.util.ArrayList<>();
      if (text == null || text.isBlank()) {
         return out;
      }
      StringBuilder line = new StringBuilder();
      for (String word : text.split(" ")) {
         String probe = line.isEmpty() ? word : line + " " + word;
         if (TextPainter.poppinsWidth(probe, size) <= maxW) {
            line.setLength(0);
            line.append(probe);
         } else {
            if (!line.isEmpty()) {
               out.add(line.toString());
            }
            line.setLength(0);
            line.append(word);
            if (out.size() >= maxLines) {
               break;
            }
         }
      }
      if (!line.isEmpty() && out.size() < maxLines) {
         out.add(line.toString());
      }
      return out;
   }
}
