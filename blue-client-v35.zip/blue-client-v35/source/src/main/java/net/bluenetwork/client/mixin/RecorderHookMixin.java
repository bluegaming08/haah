package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.ScreenRecorder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The two capture points for the Screen Recorder.
 *
 * <p>The owner asked for a setting controlling whether the HUD shows up in the
 * recording. Rather than hiding the HUD (which would make the game unusable
 * while recording), we simply grab the framebuffer at a different moment:</p>
 *
 * <pre>
 *   renderWorld  RETURN  -> world only      ("HUD in recording" OFF)
 *   render       RETURN  -> world + HUD + any open screen  (ON)
 * </pre>
 *
 * <p>{@code ScreenRecorder.shouldCapture(afterHud)} decides which hook is live,
 * and also enforces the FPS pacing, so on a 240 fps machine recording at 30 fps
 * this method returns immediately 7 frames out of 8.</p>
 *
 * <p>Both injects are {@code require = 0}: losing the recorder on a future
 * Minecraft version is acceptable; failing to launch is not.</p>
 */
@Mixin(GameRenderer.class)
public abstract class RecorderHookMixin {

   @Inject(method = "renderWorld", at = @At("RETURN"), require = 0)
   private void blueclient$captureWorldOnly(RenderTickCounter counter, CallbackInfo ci) {
      if (ScreenRecorder.shouldCapture(false)) {
         ScreenRecorder.captureFrame();
      }
   }

   @Inject(method = "render", at = @At("RETURN"), require = 0)
   private void blueclient$captureWithHud(RenderTickCounter counter, boolean tick, CallbackInfo ci) {
      if (ScreenRecorder.shouldCapture(true)) {
         ScreenRecorder.captureFrame();
      }
   }
}
