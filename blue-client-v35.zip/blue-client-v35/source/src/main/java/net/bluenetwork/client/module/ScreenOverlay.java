package net.bluenetwork.client.module;

import net.minecraft.client.gui.DrawContext;

/** Implemented by modules that draw a fullscreen HUD overlay (crosshair layer). */
public interface ScreenOverlay {
   void renderOverlay(DrawContext context);
}
