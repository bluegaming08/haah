package net.bluenetwork.client.module;

/**
 * A module whose main value can be nudged up and down with hotkeys.
 *
 * <h2>Why this exists</h2>
 * Every module already gets one keybind, and that key toggles it. But some
 * settings are things you want to change <i>while playing</i> - brightness is
 * the obvious one: you turn Fullbright on, then want a bit more or a bit less
 * without opening a menu, pausing, and hunting for a slider.
 *
 * <p>Rather than bolting a second and third keybind onto every module, this
 * interface marks the few where adjustment makes sense.
 * {@code KeybindManager} checks for it and routes the two adjust keys, so the
 * mechanism is opt-in and costs nothing for modules that do not want it.</p>
 */
public interface AdjustableModule {

   /** GLFW key that increases the value, or 0 when unbound. */
   int increaseKey();

   /** GLFW key that decreases the value, or 0 when unbound. */
   int decreaseKey();

   /**
    * Applies one step of adjustment.
    *
    * @param direction +1 to increase, -1 to decrease
    * @return a short message to show the player, or null for silence
    */
   String adjust(int direction);
}
