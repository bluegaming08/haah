package net.bluenetwork.client.social.lan;

import java.util.function.Consumer;
import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.world.GameMode;

/**
 * Turns "let my friend into my singleplayer world" into an address we can put
 * in an invite.
 *
 * <h2>The flow</h2>
 * <ol>
 *   <li>Make sure we are actually hosting a singleplayer world.</li>
 *   <li>Open it to LAN if it is not already ({@code IntegratedServer.openToLan}),
 *       which picks a port and starts the LAN pinger.</li>
 *   <li>Ask the router to forward that port with {@link UPnP}.</li>
 *   <li>Hand {@code publicIp:port} back so {@code FriendsManager.sendInvite}
 *       can store it.</li>
 * </ol>
 *
 * <h2>Why there is no fallback</h2>
 * The owner explicitly chose UPnP-only (answer A1): no relay, no VPS, no
 * piggybacking on e4mc or World Host. If the router says no, we say so plainly
 * and suggest the alternatives rather than silently doing something clever.
 *
 * <h2>Threading</h2>
 * {@code openToLan} touches the server and must run on the client thread.
 * UPnP does blocking network IO and must not. This class keeps that boundary
 * straight so callers do not have to think about it - the callback always
 * arrives on the client thread.
 */
public final class LanInvites {

   /** The port we opened this session, or -1. */
   private static volatile int openPort = -1;
   /** The public address we last resolved, or null. */
   private static volatile String publicAddress;

   private LanInvites() {
   }

   /** The address to advertise, or null if LAN hosting is not set up. */
   public static String currentAddress() {
      return publicAddress;
   }

   public static boolean isOpen() {
      return openPort > 0 && publicAddress != null;
   }

   /**
    * Prepares this world for a friend to join.
    *
    * @param onResult receives the joinable address, or null plus a reason.
    *                 Always invoked on the client thread.
    */
   public static void prepare(Consumer<Outcome> onResult) {
      MinecraftClient mc = MinecraftClient.getInstance();

      // Already done this session - reuse it rather than re-opening.
      if (isOpen()) {
         onResult.accept(Outcome.ok(publicAddress));
         return;
      }

      if (!mc.isInSingleplayer()) {
         onResult.accept(Outcome.fail(
            "You can only invite friends to your own singleplayer world. "
               + "On a server, share the server address instead."));
         return;
      }

      IntegratedServer server = mc.getServer();
      if (server == null) {
         onResult.accept(Outcome.fail("No world is loaded."));
         return;
      }

      int port;
      try {
         if (server.isRemote()) {
            // isRemote() means "already published to LAN".
            port = server.getServerPort();
         } else {
            // GameMode null keeps each player's current mode; false = no cheats,
            // the safe default for letting someone else in. Port 0 asks the
            // game to pick a free one.
            boolean opened = server.openToLan(GameMode.SURVIVAL, false, 0);
            if (!opened) {
               onResult.accept(Outcome.fail("Could not open the world to LAN."));
               return;
            }
            port = server.getServerPort();
         }
      } catch (Throwable t) {
         BlueClient.LOGGER.warn("[LAN] openToLan failed", t);
         onResult.accept(Outcome.fail("Could not open the world to LAN."));
         return;
      }

      if (port <= 0) {
         onResult.accept(Outcome.fail("The game did not report a LAN port."));
         return;
      }

      final int lanPort = port;
      openPort = lanPort;

      // Blocking network work happens off-thread; the reply is bounced back
      // onto the client thread so callers can touch screens safely.
      UPnP.open(lanPort).thenAccept(result -> mc.execute(() -> {
         if (result.ok()) {
            publicAddress = result.address();
            BlueClient.LOGGER.info("[LAN] world reachable at {} ({})",
               result.address(), UPnP.describeState());
            onResult.accept(Outcome.ok(result.address()));
         } else {
            // The port IS open on the LAN even though the router refused, so
            // tell the player that - someone on the same network can still join.
            publicAddress = null;
            onResult.accept(new Outcome(false, null,
               result.error() + "  Friends on your own network can still join on port "
                  + lanPort + "."));
         }
      }));
   }

   /** Tears down the mapping. Safe to call when nothing is open. */
   public static void shutdown() {
      int port = openPort;
      openPort = -1;
      publicAddress = null;
      if (port > 0) {
         UPnP.close(port);
      }
      UPnP.closeAll();
   }

   /** Result of {@link #prepare}. */
   public record Outcome(boolean ok, String address, String message) {
      static Outcome ok(String address) {
         return new Outcome(true, address, null);
      }

      static Outcome fail(String why) {
         return new Outcome(false, null, why);
      }
   }
}
