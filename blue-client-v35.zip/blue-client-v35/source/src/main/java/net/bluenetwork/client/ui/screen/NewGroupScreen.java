package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.social.FriendsManager;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Create a group conversation: type a name, tick friends, press CREATE.
 *
 * <p>Only friends can be added. The server enforces this too
 * ({@code create_group} silently skips non-friends), but showing only friends
 * means the player never wonders why someone vanished from the group.</p>
 */
public class NewGroupScreen extends Screen {

   private static final int GREY = 0xFF8A94A6;
   private static final int MAX_NAME = 24;

   private final Screen parent;
   private final Set<String> selected = new LinkedHashSet<>();
   private String name = "";
   private boolean nameFocused = true;
   private boolean creating;
   private float scroll;
   private float drawScale = 1.0F;
   private final List<Hit> hits = new ArrayList<>();

   public NewGroupScreen(Screen parent) {
      super(Text.literal("New Group"));
      this.parent = parent;
   }

   private static FriendsManager social() {
      return BlueClient.getInstance().friends();
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0xB20B0E14);

      float base = 0.75F;
      float fit = Math.min(1.0F, Math.min(w / (base * 620.0F), h / (base * 420.0F)));
      float scale = base * Math.max(0.35F, fit);
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int mx = (int) (mouseX / scale);
      int my = (int) (mouseY / scale);

      float pw = Math.min(vw - 24, 340);
      float ph = Math.min(vh - 24, 320);
      float px = (vw - pw) / 2.0F;
      float py = (vh - ph) / 2.0F;

      this.hits.clear();
      PremiumRender.drawShadow(context, (int) px - 2, (int) py - 2,
         (int) pw + 4, (int) ph + 4, 0x77000000, 14);
      SmoothRect.fill(context, px, py, pw, ph, 10.0F, DesignTokens.panelBg());
      SmoothRect.outline(context, px, py, pw, ph, 10.0F, 1.0F, DesignTokens.panelBorder());

      TextPainter.drawPoppins(context, "New group", px + 14, py + 13,
         DesignTokens.textHi(), 11.0F);

      /* name field */
      SmoothRect.fill(context, px + 14, py + 32, pw - 28, 20, 5.0F, 0x33000000);
      SmoothRect.outline(context, px + 14, py + 32, pw - 28, 20, 5.0F, 1.0F,
         this.nameFocused ? DesignTokens.accent() : DesignTokens.panelBorder());
      String shown = this.name.isEmpty() ? "Group name" : this.name;
      TextPainter.drawPoppins(context, shown, px + 21, py + 38,
         this.name.isEmpty() ? GREY : DesignTokens.textHi(), 8.5F);
      this.hits.add(new Hit(px + 14, py + 32, pw - 28, 20, "focus"));

      TextPainter.drawPoppins(context, "Members (" + this.selected.size() + ")",
         px + 14, py + 58, GREY, 7.5F);

      /* friend list */
      float top = py + 70;
      float bottom = py + ph - 36;
      context.enableScissor((int) px + 8, (int) top, (int) (px + pw - 8), (int) bottom);
      float ry = top - this.scroll;
      List<FriendsManager.Friend> friends = social().friends();
      for (FriendsManager.Friend f : friends) {
         if (ry + 22 > top && ry < bottom) {
            boolean on = this.selected.contains(f.id());
            boolean over = mx >= px + 14 && mx <= px + pw - 14 && my >= ry && my <= ry + 20;
            SmoothRect.fill(context, px + 14, ry, pw - 28, 20, 4.0F,
               over ? DesignTokens.panelBgHover() : 0x1AFFFFFF);
            SmoothRect.fill(context, px + 20, ry + 6, 8, 8, 2.0F,
               on ? DesignTokens.accent() : 0x33FFFFFF);
            TextPainter.drawPoppins(context, f.username(), px + 34, ry + 6,
               DesignTokens.textHi(), 8.0F);
            this.hits.add(new Hit(px + 14, ry, pw - 28, 20, "toggle:" + f.id()));
         }
         ry += 23;
      }
      context.disableScissor();
      float overflow = (ry + this.scroll) - bottom;
      if (overflow < 0) {
         this.scroll = 0;
      } else if (this.scroll > overflow) {
         this.scroll = overflow;
      }

      if (friends.isEmpty()) {
         TextPainter.drawPoppins(context, "Add some friends first.",
            px + 14, top + 6, GREY, 8.0F);
      }

      /* footer */
      boolean can = !this.name.isBlank() && !this.selected.isEmpty() && !this.creating;
      float by = py + ph - 28;
      drawButton(context, "CANCEL", px + 14, by, 60, 20, mx, my, "cancel", true);
      drawButton(context, this.creating ? "..." : "CREATE",
         px + pw - 74, by, 60, 20, mx, my, "create", can);

      context.getMatrices().popMatrix();
   }

   private void drawButton(DrawContext ctx, String label, float x, float y, float w, float h,
                           int mx, int my, String tag, boolean enabled) {
      boolean over = enabled && mx >= x && mx <= x + w && my >= y && my <= y + h;
      SmoothRect.fill(ctx, x, y, w, h, 5.0F,
         !enabled ? 0x18FFFFFF : over ? DesignTokens.accent() : 0x33FFFFFF);
      float tw = TextPainter.poppinsWidth(label, 8.0F);
      TextPainter.drawPoppins(ctx, label, x + w / 2.0F - tw / 2.0F, y + h / 2.0F - 4,
         enabled ? DesignTokens.textHi() : 0x55FFFFFF, 8.0F);
      if (enabled) {
         this.hits.add(new Hit(x, y, w, h, tag));
      }
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) (click.x() / this.drawScale);
      int my = (int) (click.y() / this.drawScale);
      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit hit = this.hits.get(i);
         if (mx >= hit.x && mx <= hit.x + hit.w && my >= hit.y && my <= hit.y + hit.h) {
            String tag = hit.tag;
            if (tag.equals("focus")) {
               this.nameFocused = true;
            } else if (tag.equals("cancel")) {
               close();
            } else if (tag.equals("create")) {
               create();
            } else if (tag.startsWith("toggle:")) {
               String id = tag.substring(7);
               if (!this.selected.remove(id)) {
                  this.selected.add(id);
               }
            }
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   private void create() {
      if (this.creating) {
         return;
      }
      this.creating = true;
      social().createGroup(this.name.trim(), new ArrayList<>(this.selected), () ->
         this.client.execute(() -> {
            this.creating = false;
            close();
         }));
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.nameFocused && this.name.length() < MAX_NAME) {
         String c = input.asString();
         if (c != null && !c.isEmpty()) {
            this.name += c;
         }
         return true;
      }
      return super.charTyped(input);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      if (this.nameFocused && input.key() == GLFW.GLFW_KEY_BACKSPACE) {
         if (!this.name.isEmpty()) {
            this.name = this.name.substring(0, this.name.length() - 1);
         }
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double h, double v) {
      this.scroll = Math.max(0.0F, this.scroll - (float) v * 14.0F);
      return true;
   }

   @Override
   public void close() {
      this.client.setScreen(this.parent);
   }

   private record Hit(float x, float y, float w, float h, String tag) {
   }
}
