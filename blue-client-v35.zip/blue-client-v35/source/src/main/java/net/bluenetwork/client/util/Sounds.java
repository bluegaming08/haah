package net.bluenetwork.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

/**
 * Lightweight client-side UI/alert sounds. Mirrors the play path used by
 * {@code RenderUtil.clickSound()} (PositionedSoundInstance.ui) so these always
 * compile and play like the rest of the client's UI sounds. Guards everything:
 * if audio or the sound manager is unavailable the call is a no-op.
 */
public final class Sounds {
   private Sounds() {
   }

   public static void ui(SoundEvent event, float pitch) {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.getSoundManager() != null) {
            mc.getSoundManager().play(PositionedSoundInstance.ui(event, pitch));
         }
      } catch (Throwable ignored) {
      }
   }

   public static void softAlert() {
      ui(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.8F);
   }

   public static void chime() {
      ui(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 1.6F);
   }

   public static void pickup() {
      ui(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F);
   }

   public static void levelUp() {
      ui(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.9F);
   }

   public static void click() {
      UiSoundController.playClick();
   }
}
