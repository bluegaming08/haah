package net.bluenetwork.client.hud.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.util.TotemTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * Totem Counter — your totems and pops, plus your opponent's.
 *
 * <p>Originally just an inventory count. Extended in v0.24.9 at the owner's
 * request to also show <b>pops</b> (yours and theirs) and <b>who you are
 * fighting</b>. Pop detection and opponent selection live in
 * {@link TotemTracker}.</p>
 *
 * <h2>One honest limitation</h2>
 * For the opponent, only totems <b>in their hands</b> can be shown. The server
 * never tells your client what is in another player's inventory, so a "total"
 * would be fabricated. Their <b>pop count</b> is exact, because every pop is
 * broadcast to everyone. The label says "held" so the number is not
 * misread.
 */
public class TotemCounter extends HudModule {

   private final ColorSetting textColor = new ColorSetting("Text color",
      "Normal count colour", 0xFFFFFFFF);
   private final ColorSetting warnColor = new ColorSetting("Warn color",
      "Colour when at/below the warn threshold", 0xFFFF5C5C);
   private final ColorSetting enemyColor = new ColorSetting("Opponent color",
      "Colour of the opponent's line", 0xFFFFB84D);
   private final NumberSetting warnAt = new NumberSetting("Warn at",
      "Count at or below which the warning colour is used", 1.0, 0.0, 8.0, 1.0);
   private final BooleanSetting hideAtZero = new BooleanSetting("Hide at zero",
      "Show nothing when you have no totems and nothing has popped", true);
   private final BooleanSetting showPops = new BooleanSetting("Show my pops",
      "Show how many totems you have popped this session", true);
   private final BooleanSetting showOpponent = new BooleanSetting("Show opponent",
      "Show the totems and pops of whoever you are fighting", true);
   private final BooleanSetting showOpponentName = new BooleanSetting("Show opponent name",
      "Include the opponent's username on their line", true);

   public TotemCounter() {
      super("Totem Counter", "Your totems and pops, plus your opponent's",
         Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{
         this.textColor, this.warnColor, this.enemyColor, this.warnAt,
         this.hideAtZero, this.showPops, this.showOpponent, this.showOpponentName
      });
      this.showOpponentName.visibleWhen(this.showOpponent::get);
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 54);
   }

   /** Totems in your inventory, including the offhand. */
   public int count() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return 0;
      }
      int total = 0;
      for (ItemStack stack : mc.player.getInventory().getMainStacks()) {
         if (!stack.isEmpty() && stack.isOf(Items.TOTEM_OF_UNDYING)) {
            total += stack.getCount();
         }
      }
      ItemStack offhand = mc.player.getOffHandStack();
      if (!offhand.isEmpty() && offhand.isOf(Items.TOTEM_OF_UNDYING)) {
         total += offhand.getCount();
      }
      return total;
   }

   private int displayColor() {
      return this.count() <= this.warnAt.getInt()
         ? this.warnColor.currentRgb(System.currentTimeMillis())
         : this.textColor.currentRgb(System.currentTimeMillis());
   }

   /**
    * The rows to draw, rebuilt once per tick by {@link #onTick()}.
    *
    * <p>{@code render()}, {@code getWidth()} and {@code getHeight()} are all
    * called every frame, and each one used to rebuild this list from scratch —
    * three walks of the player list and three rounds of string building per
    * frame. Building it once per tick instead is both cheaper and safer: all
    * three now see exactly the same data, so the panel can never be sized for
    * different text than it draws.</p>
    *
    * <p>{@code volatile} because the client thread writes it in onTick() while
    * the render thread reads it.</p>
    */
   private volatile List<Line> cachedLines = List.of();

   /**
    * Whether the panel has anything worth showing, decided once per tick.
    *
    * <p>The "hide at zero" test walks your inventory AND the player list, so
    * evaluating it every frame cost as much as building the panel itself.</p>
    */
   private volatile boolean cachedVisible = true;

   @Override
   public void onTick() {
      // HudModule.refreshSizeCache() runs after module ticks, so measuring
      // against this freshly built list is correct.
      this.cachedLines = this.buildLines();
      this.cachedVisible = this.computeVisible();
   }

   /** Only hide when there is genuinely nothing to report. */
   private boolean computeVisible() {
      if (!this.hideAtZero.get()) {
         return true;
      }
      if (this.count() > 0 || TotemTracker.ownPops() > 0) {
         return true;
      }
      return this.showOpponent.get() && TotemTracker.opponent() != null;
   }

   /** Builds the lines to draw, so render and getWidth cannot disagree. */
   private List<Line> buildLines() {
      List<Line> out = new ArrayList<>();
      int total = this.count();
      int myPops = TotemTracker.ownPops();

      String mine = "Totems \u00d7" + total;
      if (this.showPops.get()) {
         mine = mine + "  Popped " + myPops;
      }
      out.add(new Line(mine, this.displayColor()));

      if (this.showOpponent.get()) {
         PlayerEntity enemy = TotemTracker.opponent();
         if (enemy != null) {
            String who = this.showOpponentName.get()
               ? enemy.getGameProfile().name()
               : "Opponent";
            // "held" is deliberate - see the class javadoc.
            String line = who + ": held \u00d7" + TotemTracker.visibleTotems(enemy)
               + "  Popped " + TotemTracker.popsOf(enemy.getUuid());
            out.add(new Line(line, this.enemyColor.currentRgb(System.currentTimeMillis())));
         }
      }
      return out;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      if (!this.cachedVisible) {
         return;
      }
      List<Line> lines = this.cachedLines;
      if (lines.isEmpty()) {
         lines = this.buildLines();       // first frame, before the first tick
      }
      this.drawPanel(context);
      int y = this.y + 6;
      for (Line line : lines) {
         RenderUtil.drawText(context, line.text(), this.x + 6 + 2, y, line.color());
         y += 11;
      }
   }

   @Override
   public int getWidth() {
      int widest = 0;
      for (Line line : this.linesForMeasure()) {
         widest = Math.max(widest, RenderUtil.textWidth(line.text()));
      }
      return widest + 12 + 2;
   }

   @Override
   public int getHeight() {
      int count = Math.max(1, this.linesForMeasure().size());
      return 10 + count * 11;
   }

   /** Cached rows, falling back to a live build before the first tick. */
   private List<Line> linesForMeasure() {
      List<Line> lines = this.cachedLines;
      return lines.isEmpty() ? this.buildLines() : lines;
   }

   /** One rendered row. */
   private record Line(String text, int color) {
   }
}
