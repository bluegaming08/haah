package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.ModuleActions;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;

/**
 * Alarm / Timer (v3 catalogue H3) — a countdown with a finish toast + chime,
 * optional repeat. Start/Stop/Reset are surfaced through the module action
 * buttons (like Music Player). Runs off the per-tick dispatch and pure
 * wall-clock time, so it works in menus too.
 */
public class AlarmTimer extends Module implements ModuleActions {
   private final NumberSetting minutes = new NumberSetting("Minutes", "Countdown minutes", 5.0, 0.0, 480.0, 1.0);
   private final NumberSetting seconds = new NumberSetting("Seconds", "Countdown seconds (added to minutes)", 0.0, 0.0, 59.0, 1.0);
   private final BooleanSetting repeat = new BooleanSetting("Repeat", "Restart the timer when it finishes", false);
   private final BooleanSetting sound = new BooleanSetting("Sound", "Play a chime when it finishes", true);

   private boolean running = false;
   private long endMs = 0L;
   private long remainingMs = 0L;

   public AlarmTimer() {
      super("Alarm Timer", "Countdown with a toast + chime when it finishes", Category.MISC);
      this.addSettings(new Setting[]{this.minutes, this.seconds, this.repeat, this.sound});
   }

   @Override
   public List<String> actionLabels() {
      if (this.running) {
         return List.of("STOP", "RESET");
      }
      return List.of("START", "RESET");
   }

   @Override
   public void onAction(int index) {
      if (this.running) {
         if (index == 0) {
            this.pause();
         } else {
            this.reset();
         }
      } else {
         if (index == 0) {
            this.start();
         } else {
            this.reset();
         }
      }
   }

   private void start() {
      long totalMs = (long) (this.minutes.get() * 60.0 * 1000.0)
         + (long) (this.seconds.get() * 1000.0);
      if (totalMs <= 0L) {
         this.notify("Set a duration first");
         return;
      }
      this.remainingMs = totalMs;
      this.endMs = System.currentTimeMillis() + totalMs;
      this.running = true;
      this.notify("Timer set - " + format(totalMs));
      if (this.sound.get()) {
         Sounds.click();
      }
   }

   private void pause() {
      if (!this.running) {
         return;
      }
      this.remainingMs = Math.max(0L, this.endMs - System.currentTimeMillis());
      this.running = false;
      this.notify("Paused - " + format(this.remainingMs));
   }

   private void reset() {
      this.running = false;
      this.remainingMs = 0L;
      this.notify("Timer reset");
   }

   @Override
   protected void onDisable() {
      this.running = false;
   }

   @Override
   public void onTick() {
      if (!this.running) {
         return;
      }
      long now = System.currentTimeMillis();
      if (now < this.endMs) {
         return;
      }
      long totalMs = (long) (this.minutes.get() * 60.0 * 1000.0)
         + (long) (this.seconds.get() * 1000.0);
      if (this.repeat.get() && totalMs > 0L) {
         this.endMs = now + totalMs;
         this.notify("Timer finished - restarting");
         if (this.sound.get()) {
            Sounds.chime();
         }
         return;
      }
      this.running = false;
      this.notify("Timer finished!");
      if (this.sound.get()) {
         Sounds.levelUp();
      }
   }

   private static String format(long ms) {
      long totalSeconds = Math.max(0L, ms / 1000L);
      long m = totalSeconds / 60L;
      long s = totalSeconds % 60L;
      return String.format("%d:%02d", m, s);
   }

   private void notify(String message) {
      try {
         BlueClient.getInstance().notificationManager().add(message, 0xFF4D8DFF);
      } catch (Throwable ignored) {
      }
   }
}
