package net.bluenetwork.client.keybind;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.event.KeyEvent;
import net.bluenetwork.client.gui.QuickMenuScreen;
import net.bluenetwork.client.module.HoldModule;
import net.bluenetwork.client.module.SelfKeyedModule;
import net.bluenetwork.client.module.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Event-driven keybind handling. Key events arrive directly from the
 * GLFW callback (via KeyboardMixin), so even the fastest tap is caught -
 * no 20Hz polling that can miss short presses.
 */
public class KeybindManager {
   private final BlueClient client;

   public KeybindManager(BlueClient client) {
      this.client = client;
   }

   public void init() {
      this.client.eventBus().subscribe(KeyEvent.class, this::onKey);
   }

   private void onKey(KeyEvent event) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null || mc.currentScreen != null) {
         return;
      }

      if (event.action() == 1) {
         /*
          * Adjustment keys first. A module can expose "increase" and
          * "decrease" hotkeys in addition to its single toggle bind - that is
          * how brightness can be nudged mid-game without opening a menu.
          *
          * Checked before the toggle loop so an adjust key never also toggles
          * the module it belongs to.
          */
         for (Module module : this.client.moduleManager().getModules()) {
            if (!(module instanceof net.bluenetwork.client.module.AdjustableModule adj)) {
               continue;
            }
            int dir = 0;
            if (adj.increaseKey() != 0 && adj.increaseKey() == event.key()) {
               dir = 1;
            } else if (adj.decreaseKey() != 0 && adj.decreaseKey() == event.key()) {
               dir = -1;
            }
            if (dir != 0) {
               String msg = adj.adjust(dir);
               if (msg != null) {
                  BlueClient.getInstance().notificationManager()
                     .add(msg, 0xFF2FA5FF);
               }
               return;
            }
         }

         int guiKey = this.client.settings().guiKeybind();
         if (guiKey > 0 && event.key() == guiKey) {
            mc.setScreen(new QuickMenuScreen());
            return;
         }

         for (Module module : this.client.moduleManager().getModules()) {
            if (module.getKeybind() == event.key() && !(module instanceof SelfKeyedModule)) {
               if (module instanceof HoldModule) {
                  module.setEnabled(true);
               } else {
                  module.toggle();
                  BlueClient.LOGGER.info("Module '{}' toggled via hotkey -> {}", module.getName(), module.isEnabled());
               }
            }
         }
      } else if (event.action() == 0) {
         for (Module module : this.client.moduleManager().getModules()) {
            if (module instanceof HoldModule && !(module instanceof SelfKeyedModule)
               && module.getKeybind() == event.key()) {
               module.setEnabled(false);
            }
         }
      }
   }
}
