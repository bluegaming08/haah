package net.bluenetwork.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.screen.ModuleMenuScreen;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.bluenetwork.client.ui.theme.ThemePalette;
import net.bluenetwork.client.ui.widget.PremiumButton;
import net.bluenetwork.client.util.HoverAnim;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;

/**
 * The custom pause menu — v0.24.0 full revamp.
 *
 * <h2>Layout</h2>
 * <pre>
 *   +---------------------------------------------------------------+
 *   | [logo] BLUE CLIENT                        [theme] [vanilla]    |
 *   |        singleplayer · v0.24.0                                  |
 *   |                                                                |
 *   |  +--- primary column ---+   +--- quick tiles --------------+   |
 *   |  | BACK TO GAME         |   | HUD | COSMETICS | WAYPOINTS  |   |
 *   |  | MODS                 |   +------------------------------+   |
 *   |  | CLIENT SETTINGS      |                                      |
 *   |  | OPTIONS              |   +--- session card -------------+   |
 *   |  | ACCOUNTS             |   | SESSION                      |   |
 *   |  |                      |   | server · fps · ping          |   |
 *   |  | DISCONNECT           |   +------------------------------+   |
 *   |  +----------------------+                                      |
 *   +---------------------------------------------------------------+
 * </pre>
 *
 * <h2>What changed from v11</h2>
 * <ul>
 *   <li><b>Every button is a {@link PremiumButton}</b>, so the owner's preset
 *       (radius 2, #0B0E14, no border, white text) applies everywhere and a
 *       theme switch restyles the whole menu for free.</li>
 *   <li><b>Animated hover</b> via {@link HoverAnim} instead of an instant flip.</li>
 *   <li><b>Quick tiles</b> for the screens you actually open mid-game.</li>
 *   <li><b>A live session card</b> (server, FPS, ping) — the most-copied
 *       pause-menu feature.</li>
 *   <li><b>The logo is centred in its box.</b> v11 drew it at a fixed offset,
 *       which left it visually high and left; it is now measured and centred
 *       on both axes.</li>
 * </ul>
 *
 * <h2>How the button plumbing works</h2>
 * The screen is immediate-mode. {@link #render} clears {@link #hits} and
 * rebuilds it every frame, queueing each button into {@link #buttons} and its
 * clickable rectangle into {@link #hits}. Buttons are painted last so their
 * hover glow always sits above the panels behind them. {@link #mouseClicked}
 * then just walks {@link #hits}. Adding a button is one call — no widget
 * lifecycle to manage.
 */
public class PauseMenuScreen extends Screen {

   /** Header logo box side length. The logo is centred inside this square. */
   private static final int LOGO_BOX = 44;

   private final List<Hit> hits = new ArrayList<>();
   private final List<ButtonSlot> buttons = new ArrayList<>();

   public PauseMenuScreen() {
      super(Text.literal("Blue Client"));
   }

   @Override
   public boolean shouldPause() {
      return true;
   }

   @Override
   public boolean shouldCloseOnEsc() {
      return true;
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      this.hits.clear();
      this.buttons.clear();

      int width = context.getScaledWindowWidth();
      int height = context.getScaledWindowHeight();

      /*
       * Feather-style layout, per the owner's reference screenshot:
       * a centred logo + wordmark, then one narrow column of stacked
       * buttons, with the highlight button in BLUE (Feather's is red).
       *
       * The old layout was a left-aligned column with a separate right-hand
       * block, which looked nothing like the reference.
       */
      context.fill(0, 0, width, height, DesignTokens.scrim());

      int columnW = 220;
      int buttonH = 30;
      int gap = 8;
      int cx = width / 2;
      int left = cx - columnW / 2;

      /* ---------------- brand: logo beside the wordmark ---------------- */
      int logoH = 34;
      int logoW = RenderUtil.logoWidth(logoH);
      float brandSize = 15.0F;
      float nameW = TextPainter.poppinsWidth("BLUE ", brandSize)
         + TextPainter.poppinsWidth("CLIENT", brandSize);
      float brandW = logoW + 10 + nameW;
      float brandX = cx - brandW / 2.0F;

      int brandY = Math.max(18, height / 2 - 150);
      RenderUtil.drawLogo(context, (int) brandX, brandY, logoH);

      float tx = brandX + logoW + 10;
      float ty = brandY + (logoH - brandSize) / 2.0F;
      TextPainter.drawPoppins(context, "BLUE", tx, ty, 0xFFFFFFFF, brandSize);
      TextPainter.drawPoppins(context, "CLIENT",
         tx + TextPainter.poppinsWidth("BLUE ", brandSize), ty,
         0xFF9AA4B2, brandSize);

      /* ---------------- the button stack ---------------- */
      int y = brandY + logoH + 26;

      this.button(mouseX, mouseY, left, y, columnW, buttonH,
         "Back to Game", "play", false, this::close);
      y += buttonH + gap;

      this.button(mouseX, mouseY, left, y, columnW, buttonH,
         "Blue Settings", "settings", false,
         () -> this.client.setScreen(new ClientSettingsScreen(this)));
      y += buttonH + gap;

      // The accented button. Feather puts its STORE here in red; Blue Client's
      // headline destination is Social, in blue.
      this.button(mouseX, mouseY, left, y, columnW, buttonH,
         "SOCIAL", "users", true,
         () -> this.client.setScreen(new net.bluenetwork.client.ui.screen.FriendsScreen(this)));
      y += buttonH + gap;

      this.button(mouseX, mouseY, left, y, columnW, buttonH,
         "Mods", "layout-grid", false,
         () -> this.client.setScreen(new ModuleMenuScreen(BlueClient.getInstance(), this)));
      y += buttonH + gap;

      this.button(mouseX, mouseY, left, y, columnW, buttonH,
         "Options", "sliders-horizontal", false,
         () -> this.client.setScreen(new OptionsScreen(this, this.client.options)));
      y += buttonH + gap;

      String quitLabel = this.client.isInSingleplayer()
         ? "Save & Quit to Title" : "Disconnect";
      this.button(mouseX, mouseY, left, y, columnW, buttonH,
         quitLabel, "log-out", false,
         () -> this.client.disconnect(ClientWorld.QUITTING_MULTIPLAYER_TEXT));

      /*
       * Deliberately absent, per a standing instruction: SESSION, HUD,
       * COSMETICS, WAYPOINTS and ACCOUNTS. None are deleted from the client -
       * each is reachable from Client Settings or the modules menu.
       */

      super.render(context, mouseX, mouseY, deltaTicks);
   }

   private void renderHeader(DrawContext context, int mouseX, int mouseY, int width) {
      ThemePalette p = ThemeManager.palette();
      int left = 20;
      int boxY = 12;

      SmoothRect.fill(context, left, boxY, LOGO_BOX, LOGO_BOX, 4.0F, p.panelBg());

      // FIX (owner: "the logo isn't centered in the box"): measure the logo and
      // centre it on BOTH axes instead of drawing at a fixed top-left offset.
      int logoH = LOGO_BOX - 14;                    // 7 px breathing room
      int logoW = RenderUtil.logoWidth(logoH);
      int logoX = left + (LOGO_BOX - logoW) / 2;
      int logoY = boxY + (LOGO_BOX - logoH) / 2;
      RenderUtil.drawLogo(context, logoX, logoY, logoH);

      int textLeft = left + LOGO_BOX + 12;
      RenderUtil.drawInterText(context, "BLUE CLIENT", textLeft, boxY + 12, p.textHi(), 12.0F);

      // Accent underline sized to the real text width.
      int underlineW = (int) Math.ceil(RenderUtil.popinsWidth("BLUE CLIENT", 12.0F));
      context.fill(textLeft, boxY + 25, textLeft + underlineW, boxY + 26, p.accent());

      String mode = this.client.isInSingleplayer() ? "singleplayer" : "multiplayer";
      RenderUtil.drawInterText(context, mode + "  ·  " + BlueClient.displayVersion(),
         textLeft, boxY + 30, p.textMid());

      /* top-right: theme cycler + switch to the vanilla menu */
      int size = 20;
      int vanillaX = width - size - 12;
      int themeX = vanillaX - size - 6;

      this.squareButton(mouseX, mouseY, themeX, 12, size, "sun", () -> {
         String next = ThemeManager.cycle();
         BlueClient.getInstance().settings().theme(next);
         BlueClient.getInstance().notificationManager()
            .add("Theme » " + ThemeManager.style().displayName(), ThemeManager.palette().accent());
      });

      this.squareButton(mouseX, mouseY, vanillaX, 12, size, "pickaxe", () -> {
         BlueClient.getInstance().settings().customPauseMenu(false);
         this.client.setScreen(new GameMenuScreen(true));
      });
   }



   /* ===================================================================== */
   /* Button plumbing                                                       */
   /* ===================================================================== */

   /** Queues a premium button and registers its hit box. */
   private void button(int mouseX, int mouseY, int x, int y, int w, int h,
                       String label, String icon, boolean accent, Runnable action) {
      boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
      float progress = HoverAnim.progress("pause:" + label, hovered,
         HoverAnim.rate(BlueClient.getInstance().settings().animations()));
      this.buttons.add(new ButtonSlot(x, y, w, h, label, icon, progress, accent));
      this.hits.add(new Hit(x, y, w, h, action));
   }

   /** Small square icon button used by the header controls. */
   private void squareButton(int mouseX, int mouseY, int x, int y, int size,
                             String icon, Runnable action) {
      boolean hovered = mouseX >= x && mouseX < x + size && mouseY >= y && mouseY < y + size;
      float progress = HoverAnim.progress("pauseSq:" + icon, hovered,
         HoverAnim.rate(BlueClient.getInstance().settings().animations()));
      this.buttons.add(new ButtonSlot(x, y, size, size, null, icon, progress, false));
      this.hits.add(new Hit(x, y, size, size, action));
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) click.x();
      int my = (int) click.y();
      for (Hit hit : this.hits) {
         if (hit.contains(mx, my)) {
            RenderUtil.clickSound();
            hit.action().run();
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   /** A button queued for painting after all panels are drawn. */
   private record ButtonSlot(int x, int y, int w, int h, String label, String icon,
                             float hover, boolean accent) {
      void paint(DrawContext context) {
         if (this.label == null) {
            // Icon-only square: centre the glyph.
            ThemePalette p = ThemeManager.palette();
            PremiumButton.drawVerticalGradient(context, this.x, this.y, this.w, this.h,
               ThemePalette.BUTTON_RADIUS,
               ThemePalette.lerp(p.buttonTop(), p.buttonTopHover(), this.hover),
               ThemePalette.lerp(p.buttonBottom(), p.buttonBottomHover(), this.hover));
            int inset = 5;
            RenderUtil.drawIcon(context, this.icon, this.x + inset, this.y + inset,
               this.w - inset * 2,
               ThemePalette.lerp(p.textMid(), p.accent(), this.hover));
            return;
         }
         PremiumButton.draw(context, this.x, this.y, this.w, this.h,
            this.label, this.icon, this.hover, false, this.accent);
      }
   }

   private record Hit(int x, int y, int w, int h, Runnable action) {
      boolean contains(int mx, int my) {
         return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
      }
   }
}
