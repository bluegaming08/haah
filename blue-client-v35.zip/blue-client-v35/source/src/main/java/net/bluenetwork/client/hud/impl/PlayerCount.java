package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Player Count (bonus HUD) — how many players are on the current server,
 * straight from the tab list.
 */
public class PlayerCount extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);

   public PlayerCount() {
      super("Player Count", "Players online right now", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 254);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return "Online --";
      }
      if (mc.isInSingleplayer()) {
         return "Singleplayer";
      }
      try {
         int n = mc.getNetworkHandler() == null ? 0 : mc.getNetworkHandler().getPlayerList().size();
         return "Online " + n;
      } catch (Throwable t) {
         return "Online --";
      }
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
