package net.bluenetwork.client.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;

/**
 * The contract between Blue Client and the Blue Client launcher.
 *
 * <h2>Three files, three owners</h2>
 *
 * <table>
 *   <tr><th>File</th><th>Owner</th><th>Purpose</th></tr>
 *   <tr>
 *     <td>{@code social-state.json}</td><td><b>the mod</b></td>
 *     <td>Live social state so the launcher can render a friends sidebar
 *         while the game runs <b>without a single API call</b>.</td>
 *   </tr>
 *   <tr>
 *     <td>{@code launcher-handoff.json}</td><td>the launcher</td>
 *     <td>Metadata about a launcher-performed sign-in. Hints only.</td>
 *   </tr>
 *   <tr>
 *     <td>{@code minecraft-session.json}</td><td>the launcher</td>
 *     <td>A Minecraft access token, so the mod can skip its own (broken)
 *         Microsoft flow.</td>
 *   </tr>
 * </table>
 *
 * <h2>Why the token is NOT in the JSON</h2>
 * The Supabase refresh token stays in {@code social-session.txt}, exactly where
 * it has always been. Supabase <i>rotates</i> refresh tokens and this mod
 * persists every rotation; if the token also lived in a launcher-written JSON
 * the two copies could disagree, and the stale one would force a full sign-in.
 * A full sign-in is billed by Supabase as a new monthly active user, so that
 * bug costs real quota. One file, one owner, no ambiguity.
 *
 * <h2>Everything the launcher writes is a HINT</h2>
 * {@code launcher-handoff.json} lets the UI show "signed in via launcher" and
 * paint a Blue+ badge immediately instead of blank-for-one-second. It is never
 * authority: the {@code sync()} response always wins. A launcher that lies
 * about Blue+ gains nothing, because every perk is gated server-side.
 */
public final class LauncherBridge {

   /** Bump when the shape of {@code social-state.json} changes. */
   private static final int SCHEMA = 1;

   private static final Path DIR = FabricLoader.getInstance()
      .getConfigDir().resolve("blueclient");

   private static final Path STATE_FILE = DIR.resolve("social-state.json");
   private static final Path HANDOFF_FILE = DIR.resolve("launcher-handoff.json");
   private static final Path MC_SESSION_FILE = DIR.resolve("minecraft-session.json");

   /**
    * The last payload written, so we can skip identical rewrites.
    *
    * <p>The sync loop runs every three seconds. Writing an unchanged file 1200
    * times an hour would be pointless disk churn, and on some systems it also
    * triggers the launcher's file watcher for nothing.</p>
    */
   private static volatile String lastWritten;

   private LauncherBridge() {
   }

   /* ====================================================================== */
   /*  social-state.json  -  written BY US, read by the launcher             */
   /* ====================================================================== */

   /**
    * Publishes the current social state.
    *
    * <p>Call after every sync that changed anything. Cheap: it builds a small
    * JSON object, compares it with the last one written, and returns without
    * touching the disk if nothing moved.</p>
    *
    * <p>Never throws. A launcher integration failing must never break the
    * game.</p>
    */
   public static void publish(FriendsManager s) {
      try {
         if (s == null) {
            return;
         }
         JsonObject root = new JsonObject();
         root.addProperty("schema", SCHEMA);
         root.addProperty("written_by", "blueclient");
         root.addProperty("logged_in", s.loggedIn());

         if (s.loggedIn()) {
            root.addProperty("username", s.username());

            // THE important field. The launcher resumes its own polling with
            // sync(since = social_rev) when the game exits, so it never has to
            // re-fetch a full payload.
            root.addProperty("social_rev", s.syncCursor());

            JsonObject plus = new JsonObject();
            plus.addProperty("active", s.plus());
            plus.addProperty("permanent", s.plusPermanent());
            if (s.plusUntil() > 0L) {
               plus.addProperty("expires_at", s.plusUntil());
            }
            root.add("blue_plus", plus);

            JsonObject unread = new JsonObject();
            unread.addProperty("friend_requests", s.incoming().size());
            unread.addProperty("messages", Math.min(9999L, s.unreadTotal()));
            unread.addProperty("notifications",
               net.bluenetwork.client.notification.NotificationInbox.unread());
            root.add("unread", unread);

            // The full friends list, not just a count. It is bounded - the
            // server caps friends at 40 even for Blue+ - so the whole array is
            // a few KB at worst, and it means the launcher can draw a live
            // sidebar during gameplay with zero API calls.
            JsonArray friends = new JsonArray();
            List<FriendsManager.Friend> all = s.friends();
            for (FriendsManager.Friend f : all) {
               JsonObject o = new JsonObject();
               o.addProperty("id", f.id());
               o.addProperty("username", f.username());
               o.addProperty("online", f.online());
               if (f.server() != null) {
                  o.addProperty("server", f.server());
               }
               if (f.presence() != null) {
                  o.addProperty("presence", f.presence());
               }
               if (f.skin() != null) {
                  o.addProperty("skin", f.skin());
               }
               o.addProperty("verified", f.verified());
               o.addProperty("plus", f.plus());
               if (f.badge() != null) {
                  o.addProperty("badge", f.badge());
               }
               if (f.nameColor() != null) {
                  o.addProperty("name_color", f.nameColor());
               }
               friends.add(o);
            }
            root.add("friends", friends);
         }

         String json = root.toString();

         // updated_at is deliberately compared OUT of the equality check: it
         // changes every call by definition, so including it would defeat the
         // skip-if-unchanged optimisation entirely.
         if (json.equals(lastWritten)) {
            return;
         }
         lastWritten = json;

         root.addProperty("updated_at", Instant.now().toString());
         writeAtomic(STATE_FILE, root.toString());
      } catch (Throwable t) {
         BlueClient.LOGGER.debug("[Launcher] could not publish social state", t);
      }
   }

   /** Removes the state file - on logout, so a stale identity is not left. */
   public static void clearState() {
      try {
         lastWritten = null;
         Files.deleteIfExists(STATE_FILE);
      } catch (Exception ignored) {
         // Nothing useful to do.
      }
   }

   /**
    * Writes via a temp file and an atomic rename.
    *
    * <p>The launcher may read this at any instant. A plain write can be
    * observed half-finished, and the launcher would parse a truncated JSON
    * document. Rename is atomic on every platform we target.</p>
    */
   private static void writeAtomic(Path target, String content) throws IOException {
      Files.createDirectories(target.getParent());
      Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
      Files.writeString(tmp, content, StandardCharsets.UTF_8);
      try {
         Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING,
            StandardCopyOption.ATOMIC_MOVE);
      } catch (Exception atomicUnsupported) {
         // Some filesystems (rare, but network shares do this) refuse
         // ATOMIC_MOVE. A plain replace is still better than a partial write.
         Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
      }
   }

   /* ====================================================================== */
   /*  launcher-handoff.json  -  written by the LAUNCHER, read by us         */
   /* ====================================================================== */

   /** What the launcher told us about a sign-in it performed. */
   public record Handoff(String username, String launcherVersion,
                         boolean plusHint, long plusExpiresAt,
                         boolean plusPermanent) {
   }

   /**
    * Reads the launcher handoff, or null if there is none.
    *
    * <p>Everything in it is a hint. It exists so the UI can say "signed in via
    * launcher" and show a Blue+ badge on the first frame rather than after the
    * first sync round trip.</p>
    */
   public static Handoff readHandoff() {
      try {
         if (!Files.exists(HANDOFF_FILE)) {
            return null;
         }
         JsonObject o = JsonParser
            .parseString(Files.readString(HANDOFF_FILE, StandardCharsets.UTF_8))
            .getAsJsonObject();

         JsonObject plus = o.has("blue_plus") && o.get("blue_plus").isJsonObject()
            ? o.getAsJsonObject("blue_plus") : null;

         return new Handoff(
            o.has("username") ? o.get("username").getAsString() : null,
            o.has("launcher_version") ? o.get("launcher_version").getAsString() : null,
            plus != null && plus.has("active") && plus.get("active").getAsBoolean(),
            plus != null && plus.has("expires_at") ? plus.get("expires_at").getAsLong() : 0L,
            plus != null && plus.has("permanent") && plus.get("permanent").getAsBoolean());
      } catch (Throwable t) {
         // A malformed handoff is the launcher's problem, not a reason to fail
         // startup. Behave exactly as if it were absent.
         BlueClient.LOGGER.debug("[Launcher] ignoring unreadable handoff file", t);
         return null;
      }
   }

   /** True when this session was started by the launcher. */
   public static boolean startedByLauncher() {
      return readHandoff() != null;
   }

   /* ====================================================================== */
   /*  minecraft-session.json  -  written by the LAUNCHER, read by us        */
   /* ====================================================================== */

   /**
    * A Minecraft session supplied by the launcher.
    *
    * @param uuid  required - {@code joinServer(uuid, token, serverId)} takes it
    *              as a parameter, so a token alone is not enough
    */
   public record McSession(String accessToken, String uuid, String name,
                           Instant expiresAt) {

      /** True when this session can still be used. */
      public boolean valid() {
         return this.accessToken != null && !this.accessToken.isBlank()
            && this.uuid != null && !this.uuid.isBlank()
            && (this.expiresAt == null || this.expiresAt.isAfter(Instant.now()));
      }
   }

   /**
    * Reads the launcher-supplied Minecraft session, or null.
    *
    * <p><b>Why this exists:</b> the mod's own Microsoft device-code login is
    * dead. Three client ids were tested, including the built-in fallback, and
    * all returned AADSTS700016 - "application not found in the directory".
    * Microsoft no longer publishes a usable public app id. A launcher with its
    * own Azure registration can do the OAuth properly and hand the result
    * over, which is strictly better than anything the mod can do alone.</p>
    *
    * <p>When this returns null or an expired session, the Azure-free
    * {@code joinServer}/{@code hasJoined} path remains the fallback.</p>
    */
   public static McSession readMcSession() {
      try {
         if (!Files.exists(MC_SESSION_FILE)) {
            return null;
         }
         JsonObject o = JsonParser
            .parseString(Files.readString(MC_SESSION_FILE, StandardCharsets.UTF_8))
            .getAsJsonObject();

         Instant exp = null;
         if (o.has("expires_at") && o.get("expires_at").isJsonPrimitive()) {
            try {
               exp = OffsetDateTime.parse(o.get("expires_at").getAsString()).toInstant();
            } catch (Exception badDate) {
               // Treat an unparseable expiry as "unknown", not as "expired":
               // valid() then relies on the token itself failing, which the
               // session server will report accurately.
               exp = null;
            }
         }

         McSession session = new McSession(
            o.has("access_token") ? o.get("access_token").getAsString() : null,
            o.has("minecraft_uuid") ? o.get("minecraft_uuid").getAsString() : null,
            o.has("minecraft_name") ? o.get("minecraft_name").getAsString() : null,
            exp);

         return session.valid() ? session : null;
      } catch (Throwable t) {
         BlueClient.LOGGER.debug("[Launcher] ignoring unreadable mc session", t);
         return null;
      }
   }
}
