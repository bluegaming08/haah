package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class ReachHud extends HudModule {
   private double lastReach = -1.0;
   private long hitTime = 0L;
   private final NumberSetting showSeconds = new NumberSetting("Show seconds", "How long the reach stays visible after a hit", 3.0, 1.0, 10.0, 1.0);
   /** From the premium pack's ReachDisplay: reach bar out of 6 blocks. */
   private final BooleanSetting showBar = new BooleanSetting("Show bar", "Draw a reach progress bar (out of 6 blocks) under the text", true);

   public ReachHud() {
      super("Reach Display", "Distance of your last attack, in blocks", Category.COMBAT, 4, 350);
      this.addSettings(new Setting[]{this.showSeconds, this.showBar});
   }

   public void onAttack(Entity target) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && target != null) {
         Vec3d eye = mc.player.getEyePos();
         Box box = target.getBoundingBox();
         double dx = Math.max(box.minX - eye.x, Math.max(0.0, eye.x - box.maxX));
         double dy = Math.max(box.minY - eye.y, Math.max(0.0, eye.y - box.maxY));
         double dz = Math.max(box.minZ - eye.z, Math.max(0.0, eye.z - box.maxZ));
         this.lastReach = Math.sqrt(dx * dx + dy * dy + dz * dz);
         this.hitTime = System.currentTimeMillis();
      }
   }

   private boolean visible() {
      return this.lastReach >= 0.0 && System.currentTimeMillis() - this.hitTime < (long)(this.showSeconds.get() * 1000.0);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("3.10 blocks") + 12 + 2;
   }

   @Override
   public int getHeight() {
      return this.showBar.get() ? 31 : 21;
   }

   @Override
   public void render(DrawContext context) {
      if (this.visible()) {
         String text = String.format("%.2f blocks", this.lastReach);
         if (!this.showBar.get()) {
            this.drawTextPanel(context, text);
         } else {
            int panelW = Math.max(RenderUtil.textWidth(text) + 12 + 2, 64);
            RenderUtil.drawRoundedPanel(context, this.x, this.y, panelW, 31);
            RenderUtil.drawText(context, text, this.x + 6 + 2, this.y + 6, BlueColors.TEXT_PRIMARY);
            float reachPercent = (float)Math.max(0.0D, Math.min(1.0D, this.lastReach / 6.0D));
            int barX = this.x + 7;
            int barY = this.y + 21;
            int barW = panelW - 14;
            context.fill(barX, barY, barX + barW, barY + 5, 0x33000000);
            // Low reach = red, far hits = green
            float g = reachPercent;
            int r = (int)(255.0F * (1.0F - g));
            int gr = (int)(200.0F * g);
            context.fill(barX, barY, barX + (int)(barW * reachPercent), barY + 5, 0xFF000000 | r << 16 | gr << 8);
         }
      }
   }
}
