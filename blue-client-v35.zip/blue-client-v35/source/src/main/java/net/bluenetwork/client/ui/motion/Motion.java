package net.bluenetwork.client.ui.motion;

/**
 * Motion timing tokens (redesign plan §3.5). Single source of truth for
 * animation durations so screens stay consistent; respects nothing by itself —
 * callers check {@code ClientSettings.animations()} (master) and the Phase 1b
 * animation-scale setting to decide whether to animate at all.
 */
public final class Motion {
   private Motion() {
   }

   /** Hover tint, colour morph, tiny state nudges. */
   public static final long FAST_MS = 120L;

   /** Toggles, pills, settings drawer expansion. */
   public static final long BASE_MS = 180L;

   /** Window open/close, screen transitions (ease-out expo). */
   public static final long PANEL_MS = 260L;

   /** Stagger delay between list children during reveal. */
   public static final long STAGGER_MS = 14L;

   /** Accent pulse cycle length (module "on" glow). */
   public static final long GLOW_PULSE_MS = 1600L;
}
