package net.bluenetwork.client.social;

import java.util.HashMap;
import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.CookieStorage;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

/**
 * "Join" button behaviour: connect to the server a friend is playing on.
 *
 * <p>Mirrors the connect flow already used by the main menu's news banner, so
 * there is exactly one way this client dials a server.</p>
 *
 * <h2>Threading</h2>
 * The address arrives on a network thread, but Minecraft screens may only be
 * touched on the render thread. {@link #connect(String)} therefore hops via
 * {@code MinecraftClient.execute}. Calling it from the wrong thread was the
 * kind of thing that produces a rare, impossible-to-reproduce crash.
 *
 * <h2>Safety</h2>
 * The address comes from the backend, which only returns it when the friend's
 * privacy settings allow it. We still refuse to disconnect a player who is
 * already in a world without them confirming - that is handled by the UI,
 * which only shows JOIN when it makes sense.
 */
public final class ServerJoiner {

   private ServerJoiner() {
   }

   /** Connects to {@code address}. Safe to call from any thread. */
   public static void connect(String address) {
      if (address == null || address.isBlank()) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null) {
         return;
      }

      mc.execute(() -> {
         try {
            // Leave the current world first; ConnectScreen expects no session.
            if (mc.world != null) {
               mc.disconnect(net.minecraft.text.Text.literal("Joining a friend"));
            }

            Screen parent = mc.currentScreen != null ? mc.currentScreen : new TitleScreen();
            ServerAddress parsed = ServerAddress.parse(address);
            ServerInfo info = new ServerInfo(address, address, ServerInfo.ServerType.OTHER);
            CookieStorage cookies = new CookieStorage(new HashMap<>(), new HashMap<>(), false);

            ConnectScreen.connect(parent, mc, parsed, info, false, cookies);
         } catch (Throwable t) {
            BlueClient.LOGGER.error("[Social] could not join a friend's server", t);
         }
      });
   }
}
