package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;

/**
 * Frame Smooth (v3 catalogue G5) — frame-pacing helpers: optionally disables
 * vsync while on (reduces input lag when you're already above your refresh
 * rate) and keeps the FPS cap at a chosen value. Options are held through
 * {@link OptionGuard}, so stacking it with Adaptive Render Distance or the
 * built-in optimizer no longer corrupts anyone's saved value.
 */
public class FrameSmooth extends Module {
   private static final String[] CAP_STYLES = {"Hard cap", "No cap", "Unchanged"};

   private final ModeSetting capStyle = new ModeSetting("Cap style", "How the FPS cap is handled", java.util.List.of(CAP_STYLES), "Unchanged");
   private final NumberSetting cap = new NumberSetting("Cap FPS", "Target when cap style is Hard cap", 144.0, 30.0, 480.0, 1.0);
   private final BooleanSetting vsyncOff = new BooleanSetting("Disable vsync", "Turn vsync off while enabled", true);

   public FrameSmooth() {
      super("Frame Smooth", "FPS cap + vsync handling", Category.MISC);
      this.addSettings(new Setting[]{this.capStyle, this.cap, this.vsyncOff});
   }

   @Override
   protected void onEnable() {
      this.apply();
   }

   @Override
   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null) {
         return;
      }
      OptionGuard.release(mc.options.getMaxFps(), this);
      OptionGuard.release(mc.options.getEnableVsync(), this);
   }

   @Override
   public void onTick() {
      this.apply();
   }

   private void apply() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }
      switch (this.capStyle.get()) {
         case "Hard cap" -> {
            /*
             * Re-applying blindly every tick means the player can never change
             * their FPS limit anywhere else - the vanilla video menu, Sodium's,
             * another mod - because this overwrites it within 50 ms. That is
             * the "my FPS keeps snapping back to 144" bug.
             *
             * So: notice when the live value differs from what WE last wrote.
             * That can only be someone else setting it deliberately, and the
             * honest response is to follow them rather than fight.
             */
            int want = Math.max(30, (int) Math.round(this.cap.get()));
            Integer held = OptionGuard.heldValueOf(mc.options.getMaxFps(), this);
            Integer live = mc.options.getMaxFps().getValue();
            if (held != null && live != null && !live.equals(held)
               && !live.equals(want)) {
               // The player moved it. Adopt their number as this module's cap
               // so the settings screen shows the truth, and stop overriding.
               this.cap.setExact(live);
               OptionGuard.adoptOriginal(mc.options.getMaxFps(), live);
               OptionGuard.setValue(mc.options.getMaxFps(), live, this);
            } else {
               OptionGuard.hold(mc.options.getMaxFps(), want, this);
            }
         }
         case "No cap" -> OptionGuard.hold(mc.options.getMaxFps(), 480, this);
         default -> OptionGuard.release(mc.options.getMaxFps(), this); // Unchanged
      }
      if (this.vsyncOff.get()) {
         if (mc.options.getEnableVsync().getValue()) {
            OptionGuard.hold(mc.options.getEnableVsync(), false, this);
         }
      } else {
         OptionGuard.release(mc.options.getEnableVsync(), this);
      }
   }
}
