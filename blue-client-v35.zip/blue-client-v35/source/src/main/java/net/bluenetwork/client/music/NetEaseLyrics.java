package net.bluenetwork.client.music;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * NetEase Cloud Music - the only public source of REAL word-level timings.
 *
 * <h2>Why NetEase and not Musixmatch</h2>
 * Musixmatch's rich-sync is the better-known source, so it was tried first and
 * <b>rejected on evidence</b>:
 * <ul>
 *   <li>{@code token.get} returns an all-zero token
 *       ({@code 000...0}) for anonymous callers;</li>
 *   <li>{@code track.richsync.get} then answers <b>404</b>;</li>
 *   <li>{@code macro.subtitles.get} answers 200 but matches the wrong song -
 *       a query for "Blinding Lights / The Weeknd" came back as Drake's
 *       "NOKIA".</li>
 * </ul>
 * Shipping that would mean showing confidently-wrong lyrics. It needs a paid
 * API key, so it is deliberately not implemented; if a key ever exists, add it
 * as a provider above this one and the ladder will prefer it automatically.
 *
 * <h2>The yrc format</h2>
 * NetEase returns a {@code yrc} field when word timing exists:
 * <pre>
 *   [11140,3260](11140,270,0)Hel(11410,270,0)lo (11680,270,0)world
 *    ^line start,duration   ^word start,duration,unused
 * </pre>
 * Both line and word times are absolute milliseconds, so they map straight
 * onto {@link LyricData} with no arithmetic.
 *
 * <h2>Coverage, measured</h2>
 * Of three probed tracks only one had {@code yrc}; the rest had line-level
 * {@code lrc} only. Word timing is a bonus, never something to depend on -
 * which is exactly why {@link LyricData.SyncType} exists and why the caller
 * falls through to LRCLIB.
 */
public final class NetEaseLyrics {

   private static final String SEARCH =
      "https://music.163.com/api/search/get?type=1&limit=5&s=";
   private static final String LYRIC =
      "https://music.163.com/api/song/lyric?lv=1&yv=1&id=";

   /** A line header: [startMs,durationMs] */
   private static final Pattern LINE_HEAD = Pattern.compile("^\\[(\\d+),(\\d+)\\]");
   /** A word: (startMs,durationMs,unused)text */
   private static final Pattern WORD =
      Pattern.compile("\\((\\d+),(\\d+),\\d+\\)([^(]*)");
   /** A classic LRC timestamp, for the line-level fallback. */
   private static final Pattern LRC_TIME =
      Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\]");

   private NetEaseLyrics() {
   }

   /**
    * Looks up lyrics for a track.
    *
    * @param durationSec the playing track's length; used to reject a different
    *                    edit of the same song. 0 when unknown.
    * @return word- or line-synced lyrics, or null when nothing usable matched
    */
   public static LyricData fetch(String title, String artist, int durationSec) {
      try {
         for (String query : TrackName.queryLadder(title, artist)) {
            JsonObject song = bestMatch(query, durationSec);
            if (song == null) {
               continue;
            }
            long id = song.get("id").getAsLong();
            LyricData data = lyricsFor(id);
            if (data != null && !data.isEmpty()) {
               return data;
            }
         }
      } catch (Throwable t) {
         // A lyrics failure must never disturb playback.
         if (Boolean.getBoolean("blueclient.lyricsDebug")) {
            t.printStackTrace();
         }
      }
      return null;
   }

   /**
    * Picks the search result whose length best matches the playing track.
    *
    * <p>Different masters of one song - radio edit, extended, live - carry
    * different timings, so loading the wrong one makes the lyrics drift
    * further behind the longer the track runs. A result more than
    * {@value #MAX_DRIFT_SEC}s away is rejected outright rather than merely
    * scored down.</p>
    */
   private static JsonObject bestMatch(String query, int durationSec) throws Exception {
      String body = TrackResolver.httpGetWithAgent(
         SEARCH + java.net.URLEncoder.encode(query, java.nio.charset.StandardCharsets.UTF_8),
         TrackResolver.LYRICS_USER_AGENT);
      JsonElement root = JsonParser.parseString(body);
      if (!root.isJsonObject()) {
         return null;
      }
      JsonObject result = root.getAsJsonObject().getAsJsonObject("result");
      if (result == null || !result.has("songs")) {
         return null;
      }
      JsonArray songs = result.getAsJsonArray("songs");

      JsonObject best = null;
      int bestDrift = Integer.MAX_VALUE;
      for (JsonElement e : songs) {
         if (!e.isJsonObject()) {
            continue;
         }
         JsonObject s = e.getAsJsonObject();
         if (!s.has("id")) {
            continue;
         }
         if (durationSec <= 0) {
            return s;                       // no length to compare against
         }
         int songSec = s.has("duration") ? s.get("duration").getAsInt() / 1000 : 0;
         if (songSec <= 0) {
            continue;
         }
         int drift = Math.abs(songSec - durationSec);
         if (drift <= MAX_DRIFT_SEC && drift < bestDrift) {
            bestDrift = drift;
            best = s;
         }
      }
      return best;
   }

   /** Reject a candidate whose length differs by more than this many seconds. */
   private static final int MAX_DRIFT_SEC = 12;

   /** Fetches and parses the lyric document for a NetEase song id. */
   private static LyricData lyricsFor(long songId) throws Exception {
      String body = TrackResolver.httpGetWithAgent(LYRIC + songId,
         TrackResolver.LYRICS_USER_AGENT);
      JsonObject o = JsonParser.parseString(body).getAsJsonObject();

      // Prefer yrc: it is the only field with real word timings.
      String yrc = nested(o, "yrc");
      if (yrc != null && !yrc.isBlank()) {
         List<LyricData.Line> lines = parseYrc(yrc);
         if (!lines.isEmpty()) {
            return new LyricData(lines, LyricData.SyncType.WORD, "NetEase (word)");
         }
      }

      String lrc = nested(o, "lrc");
      if (lrc != null && !lrc.isBlank()) {
         List<LyricData.Line> lines = parseLrc(lrc);
         if (!lines.isEmpty()) {
            return new LyricData(lines, LyricData.SyncType.LINE, "NetEase (line)");
         }
      }
      return null;
   }

   private static String nested(JsonObject o, String key) {
      if (!o.has(key) || !o.get(key).isJsonObject()) {
         return null;
      }
      JsonObject inner = o.getAsJsonObject(key);
      return inner.has("lyric") && !inner.get("lyric").isJsonNull()
         ? inner.get("lyric").getAsString() : null;
   }

   /** Parses the word-timed yrc format. */
   static List<LyricData.Line> parseYrc(String yrc) {
      List<LyricData.Line> out = new ArrayList<>();
      for (String raw : yrc.split("\n")) {
         String line = raw.trim();
         if (line.isEmpty() || line.startsWith("{")) {
            continue;                       // a JSON metadata header
         }
         Matcher head = LINE_HEAD.matcher(line);
         if (!head.find()) {
            continue;
         }
         long start = Long.parseLong(head.group(1));
         long dur = Long.parseLong(head.group(2));

         List<LyricData.Word> words = new ArrayList<>();
         StringBuilder full = new StringBuilder();
         Matcher w = WORD.matcher(line);
         while (w.find()) {
            long ws = Long.parseLong(w.group(1));
            long wd = Long.parseLong(w.group(2));
            String text = w.group(3);
            if (text == null || text.isEmpty()) {
               continue;
            }
            // yrc keeps the trailing space INSIDE the word token. Trim it for
            // the stored word but remember it, so rejoining produces
            // "word second" and not "wordsecond".
            String trimmed = text.strip();
            if (trimmed.isEmpty()) {
               continue;
            }
            words.add(new LyricData.Word(ws, ws + wd, trimmed, false));
            if (full.length() > 0) {
               full.append(' ');
            }
            full.append(trimmed);
         }
         if (words.isEmpty()) {
            continue;
         }
         // Skip credit lines: NetEase stamps them all at 0 with no duration.
         if (start == 0L && dur == 0L) {
            continue;
         }
         out.add(new LyricData.Line(start, start + dur, full.toString(), words));
      }
      return out;
   }

   /** Parses classic line-level LRC. */
   static List<LyricData.Line> parseLrc(String lrc) {
      List<LyricData.Line> out = new ArrayList<>();
      for (String raw : lrc.split("\n")) {
         Matcher m = LRC_TIME.matcher(raw);
         List<Long> stamps = new ArrayList<>();
         int end = 0;
         while (m.find()) {
            long mm = Long.parseLong(m.group(1));
            long ss = Long.parseLong(m.group(2));
            String frac = m.group(3);
            long ms = 0L;
            if (frac != null) {
               // Two digits are centiseconds, three are milliseconds.
               ms = frac.length() == 2 ? Long.parseLong(frac) * 10L
                                       : Long.parseLong(frac);
            }
            stamps.add(mm * 60_000L + ss * 1000L + ms);
            end = m.end();
         }
         if (stamps.isEmpty()) {
            continue;
         }
         String text = raw.substring(end).trim();
         if (text.isEmpty()) {
            continue;
         }
         for (long s : stamps) {
            out.add(new LyricData.Line(s, -1L, text, List.of()));
         }
      }
      return out;
   }
}
