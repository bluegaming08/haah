package net.bluenetwork.client.social;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Maps a Blue Client username to the Minecraft skin that player chose.
 *
 * <h2>The bug this fixes</h2>
 * Avatars were drawn from whatever string the calling screen happened to
 * have. Feeds return a {@code skin_name}, so posts were correct - but
 * notifications, chat headers, the leaderboard and search rows only ever had
 * the <i>account</i> username. The same player therefore appeared with two
 * different faces depending on the screen, which is exactly what the owner
 * reported.
 *
 * <p>This is the shared answer to "what face belongs to this name". It is
 * populated from every payload that already carries both values - no extra
 * network calls - and {@code XKit.avatar} consults it automatically, so a
 * screen cannot forget.</p>
 *
 * <h2>Why a plain map</h2>
 * Entries are tiny, bounded by how many distinct players you actually see in
 * a session, and reads happen on the render thread every frame. A
 * {@link ConcurrentHashMap} read is essentially free and needs no locking
 * against the sync worker writing into it.
 */
public final class SkinIndex {

   /** lowercase username -> skin name. */
   private static final Map<String, String> SKINS = new ConcurrentHashMap<>();

   private SkinIndex() {
   }

   /**
    * Records that {@code username} renders as {@code skin}.
    *
    * <p>A null or blank skin REMOVES the mapping rather than storing an empty
    * one: a player who clears their skin should fall back to their username,
    * not to a stale face.</p>
    */
   public static void put(String username, String skin) {
      if (username == null || username.isBlank()) {
         return;
      }
      String key = username.toLowerCase(Locale.ROOT);
      if (skin == null || skin.isBlank()) {
         SKINS.remove(key);
      } else {
         SKINS.put(key, skin.trim());
      }
   }

   /**
    * The skin for a name, or the name itself when none is known.
    *
    * <p>Returning the input unchanged is deliberate: a caller that already
    * passed a skin name gets it straight back, so this is safe to apply
    * everywhere without having to know which callers hold which kind of
    * string.</p>
    */
   public static String resolve(String name) {
      if (name == null || name.isBlank()) {
         return name;
      }
      String mapped = SKINS.get(name.toLowerCase(Locale.ROOT));
      return mapped == null ? name : mapped;
   }

   /** Clears everything - on logout, so the next account starts clean. */
   public static void clear() {
      SKINS.clear();
   }
}
