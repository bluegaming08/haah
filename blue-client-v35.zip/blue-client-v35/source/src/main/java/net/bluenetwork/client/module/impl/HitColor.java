package net.bluenetwork.client.module.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HitReactor;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Hit Color - flashes a coloured glowing outline on anything you attack for a
 * moment, so hits read instantly. Uses the vanilla outline pass (glowing flag
 * + team colour override), purely client-side cosmetics, no gameplay effect.
 */
public class HitColor extends Module implements HitReactor {
   private static final Map<Integer, Long> HITS = new ConcurrentHashMap<>();

   private final ColorSetting color = new ColorSetting("Color", "Outline flash colour on hit", 0x4D9DFF);
   private final NumberSetting duration = new NumberSetting("Duration", "Flash length in milliseconds", 180.0, 50.0, 600.0, 10.0);
   /** v0.16.9: keep the flash visible even when the target is wearing armor. */
   private final BooleanSetting aboveArmor = new BooleanSetting("Show above armor", "Flash through worn armor", true);

   public HitColor() {
      super("Hit Color", "Flashes a coloured outline on entities you hit", Category.COMBAT);
      this.addSettings(new Setting[]{this.color, this.duration, this.aboveArmor});
   }

   @Override
   public void onHit(PlayerEntity attacker, Entity target) {
      HITS.put(target.getId(), System.currentTimeMillis());
      if (HITS.size() > 96) {
         HITS.clear();
      }
   }

   public static boolean flashing(Entity entity) {
      HitColor self = instance();
      if (self == null || entity == null) {
         return false;
      }
      Long at = HITS.get(entity.getId());
      return at != null && self.aboveArmor.get() && System.currentTimeMillis() - at < self.duration.get();
   }

   public static int color() {
      HitColor self = instance();
      return self == null ? 0x4D9DFF : self.color.rgb() & 0xFFFFFF;
   }

   private static HitColor instance() {
      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         if (module instanceof HitColor hc && hc.isEnabled()) {
            return hc;
         }
      }
      return null;
   }
}
