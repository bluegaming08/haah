package net.bluenetwork.client.ui.screen;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.ui.material.GlassPanel;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/**
 * CoordinatesScreen — the "Coords Converter" popup (H2). Shows your current
 * position converted to the other dimension (Overworld ↔ Nether, ÷8 / ×8) and
 * the real position, then returns to where you were when dismissed.
 */
public class CoordinatesScreen extends Screen {
   private final BlueClient blue;
   private final Screen parent;
   private Rect okRect;

   public CoordinatesScreen(BlueClient blue, Screen parent) {
      super(Text.literal("Coords Converter"));
      this.blue = blue;
      this.parent = parent;
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   private String[][] rows() {
      MinecraftClient mc = MinecraftClient.getInstance();
      PlayerEntity p = mc.player;
      if (p == null || mc.world == null) {
         return new String[][]{{"No player in a world", ""}};
      }
      int x = (int) Math.floor(p.getX());
      int y = (int) Math.floor(p.getY());
      int z = (int) Math.floor(p.getZ());
      RegistryKey<World> dim = mc.world.getRegistryKey();
      if (dim == World.NETHER) {
         return new String[][]{
            {"You (Nether)", x + " " + y + " " + z},
            {"Overworld (~x8)", (x * 8) + " " + y + " " + (z * 8)}
         };
      }
      if (dim == World.OVERWORLD) {
         return new String[][]{
            {"You (Overworld)", x + " " + y + " " + z},
            {"Nether (~÷8)", Math.floorDiv(x, 8) + " " + y + " " + Math.floorDiv(z, 8)}
         };
      }
      return new String[][]{{"Not in Overworld/Nether", x + " " + y + " " + z}};
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0x990B0E14);

      int cw = Math.max(230, Math.min(300, w - 40));
      int ch = 120;
      int cx = (w - cw) / 2;
      int cy = (h - ch) / 2;
      GlassPanel.panel(context, cx, cy, cw, ch, 12.0F, GlassSurface.defaultSurface(), true, DesignTokens.accent());
      TextPainter.drawPoppins(context, "COORDS CONVERTER", cx + 16, cy + 10, DesignTokens.textHi(), 12.0F);

      String[][] rows = this.rows();
      int ry = cy + 32;
      for (String[] row : rows) {
         RenderUtil.drawText(context, row[0], cx + 18, ry, net.bluenetwork.client.ui.theme.DesignTokens.textMid());
         RenderUtil.drawText(context, row[1], cx + cw - 18 - RenderUtil.textWidth(row[1]), ry, 0xFFFFFFFF);
         ry += 16;
      }

      this.okRect = new Rect(cx + cw - 62, cy + ch - 26, 46, 15);
      GlassPanel.panel(context, this.okRect.x, this.okRect.y, 46, 15, 8.0F, GlassSurface.defaultSurface(), true, this.okRect.contains(mouseX, mouseY) ? DesignTokens.accent() : 0);
      TextPainter.drawPoppins(context, "OK", this.okRect.x + 23 - TextPainter.poppinsWidth("OK", 8.5F) / 2.0F, this.okRect.y + 3, DesignTokens.textHi(), 8.5F);
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) click.x();
      int my = (int) click.y();
      if (this.okRect != null && this.okRect.contains(mx, my)) {
         RenderUtil.clickSound();
         if (this.parent != null) {
            this.client.setScreen(this.parent);
         } else {
            this.close();
         }
         return true;
      }
      return false;
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      if (input.key() == 256) {
         if (this.parent != null) {
            this.client.setScreen(this.parent);
         } else {
            this.client.setScreen(null);
         }
         return true;
      }
      return super.keyPressed(input);
   }

   private static final class Rect {
      final int x;
      final int y;
      final int w;
      final int h;

      Rect(int x, int y, int w, int h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
