package net.bluenetwork.client.notification;

import net.bluenetwork.client.util.Animation;

public class Notification {
   public static final long DURATION_MS = 2500L;
   public static final long SLIDE_MS = 300L;
   private final String title;
   private final int accent;
   private final Animation slideIn = new Animation(300L);
   private final long created = System.currentTimeMillis();

   public Notification(String title, int accent) {
      this.title = title;
      this.accent = accent;
   }

   public String getTitle() {
      return this.title;
   }

   public int getAccent() {
      return this.accent;
   }

   public double getSlideIn() {
      return this.slideIn.getValue();
   }

   public boolean isExpired() {
      return System.currentTimeMillis() - this.created > 2500L;
   }

   public float getFadeOut() {
      long age = System.currentTimeMillis() - this.created;
      long remaining = 2500L - age;
      return remaining > 400L ? 1.0F : Math.max(0.0F, (float)remaining / 400.0F);
   }
}
