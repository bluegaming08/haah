package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.gui.ClientSettingsScreen;
import net.bluenetwork.client.gui.MainMenuScreen;
import net.bluenetwork.client.gui.PauseMenuScreen;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Screen.class})
public abstract class ScreenMixin {
   @Shadow
   public TextRenderer textRenderer;

   /*
    * v0.24.0 REMOVED: the "pause squares".
    *
    * v11 painted two fake square buttons onto the vanilla pause menu here and
    * hit-tested them with @Inject(method = "mouseClicked") on Screen. That hook
    * could never fire: Screen does NOT declare mouseClicked - it inherits the
    * default method from the Element interface - so Mixin had no target and the
    * injection failed at launch. That is the root cause of the owner's report
    * that "the button in pause menu isn't working".
    *
    * The replacement is a real ButtonWidget added via addDrawableChild in
    * GameMenuScreenMixin, so Minecraft owns hit-testing, hover, focus and
    * narration. See that file for the full write-up.
    */

   private static net.minecraft.client.MinecraftClient blueclient$client() {
      return net.minecraft.client.MinecraftClient.getInstance();
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void blueclient$screenWatermark(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      Screen self = (Screen)(Object)this;
      // toasts (music feedback, config saves...) also show on menu screens;
      // in-game the HudManager draws them instead.
      if (blueclient$client().player == null) {
         BlueClient.getInstance().notificationManager().render(context);
      }
      // Social toasts render on EVERY screen (in game or not) because this is
      // where the cursor exists, which is what makes them clickable.
      net.bluenetwork.client.notification.SocialToasts.render(
         context, mouseX, mouseY, 8 + 25 * 5);
      // Announcements must also appear on the MAIN MENU and in singleplayer,
      // which the HUD hook never reaches - that is why this is duplicated
      // here rather than living in one place.
      net.bluenetwork.client.notification.Announcements.render(context);
      // v0.16.4: the watermark is mandatory - there is intentionally no setting,
      // module or config key that can switch it off.
      if (!(self instanceof MainMenuScreen)
         && !(self instanceof PauseMenuScreen)
         && !(self instanceof ClientSettingsScreen)) {
         int height = context.getScaledWindowHeight();
         RenderUtil.drawLogoTinted(context, 6, height - 28, 22, 0x4DFFFFFF);
      }
   }
}
