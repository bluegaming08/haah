package net.bluenetwork.client.social;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import net.bluenetwork.client.BlueClient;

/**
 * Asks Mojang whether a username belongs to a paid (premium) account.
 *
 * <p>Used for the cracked-linking path: a cracked player may only claim a name
 * that no premium account owns. The endpoint is public and needs no key:</p>
 *
 * <pre>GET https://api.mojang.com/users/profiles/minecraft/&lt;name&gt;</pre>
 *
 * <ul>
 *   <li><b>200</b> - a premium account owns this name.</li>
 *   <li><b>404</b> - nobody does; it is free for a cracked player.</li>
 * </ul>
 *
 * <h2>This is a convenience check, not the security boundary</h2>
 * A modified client could lie about the result. That is fine, because lying
 * only ever yields an <i>unverified cracked</i> link, which grants nothing:
 * {@code mc_premium} and {@code mc_verified} stay false, the buddy shard bonus
 * requires {@code mc_verified} on both sides, and the real owner can still
 * verify properly and take the name (the database has a unique index on it).
 *
 * <p>Results are cached for the session, because the answer for a given name
 * essentially never changes while the game is open.</p>
 */
public final class MojangLookup {

   private static final String LOOKUP = "https://api.mojang.com/users/profiles/minecraft/";
   private static final Duration TIMEOUT = Duration.ofSeconds(6L);

   private static final Map<String, Boolean> CACHE = new ConcurrentHashMap<>();

   private static final HttpClient HTTP = HttpClient.newBuilder()
      .connectTimeout(TIMEOUT)
      .followRedirects(HttpClient.Redirect.NORMAL)
      .build();

   private MojangLookup() {
   }

   /**
    * @return a future of true when a premium account owns the name.
    *         The future fails only if Mojang could not be reached at all,
    *         so callers can distinguish "free" from "unknown".
    */
   public static CompletableFuture<Boolean> isPremium(String name) {
      if (name == null || name.isBlank()) {
         return CompletableFuture.completedFuture(false);
      }
      String key = name.toLowerCase(Locale.ROOT);
      Boolean cached = CACHE.get(key);
      if (cached != null) {
         return CompletableFuture.completedFuture(cached);
      }

      HttpRequest req = HttpRequest.newBuilder()
         .uri(URI.create(LOOKUP + java.net.URLEncoder.encode(name, java.nio.charset.StandardCharsets.UTF_8)))
         .timeout(TIMEOUT)
         .GET()
         .build();

      return HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString())
         .thenApply(res -> {
            int code = res.statusCode();
            if (code == 200) {
               CACHE.put(key, Boolean.TRUE);
               return Boolean.TRUE;
            }
            if (code == 404 || code == 204) {
               CACHE.put(key, Boolean.FALSE);
               return Boolean.FALSE;
            }
            // 429 or a 5xx: do NOT cache, and treat it as unknown by failing,
            // so we never wrongly tell someone a taken name is free.
            throw new IllegalStateException("Mojang HTTP " + code);
         })
         .exceptionally(e -> {
            BlueClient.LOGGER.debug("[Social] Mojang lookup failed for {}", name, e);
            throw new java.util.concurrent.CompletionException(e);
         });
   }
}
