package net.bluenetwork.client.mixin;

import java.io.File;
import java.nio.file.Path;
import java.util.function.Consumer;
import net.bluenetwork.client.module.impl.Screenshots;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.util.Formatting;

/**
 * Screenshots module hook (v0.19.0). Vanilla {@link ScreenshotRecorder} gets
 * the raw success message; this mixin swaps it for a richer line with
 * clickable Copy / Open buttons when the Screenshots module wants them.
 *
 * <p>The capture is deliberately per-call: the HEAD inject stores the target
 * directory + filename, and the argsOnly ModifyVariable wraps the consumer
 * so only the SUCCESS message is replaced — failures pass through untouched.</p>
 */
@Mixin(ScreenshotRecorder.class)
public abstract class ScreenshotRecorderMixin {
   @Unique
   private static File blueclient$shotDir;
   @Unique
   private static String blueclient$shotName;

   @Inject(
      method = {"saveScreenshot(Ljava/io/File;Ljava/lang/String;Lnet/minecraft/client/gl/Framebuffer;ILjava/util/function/Consumer;)V"},
      at = {@At("HEAD")}
   )
   private static void blueclient$capture(File dir, String name, Framebuffer framebuffer, int height,
                                       Consumer<Text> consumer, CallbackInfo ci) {
      blueclient$shotDir = dir;
      blueclient$shotName = name;
   }

   @ModifyVariable(
      method = {"saveScreenshot(Ljava/io/File;Ljava/lang/String;Lnet/minecraft/client/gl/Framebuffer;ILjava/util/function/Consumer;)V"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private static Consumer<Text> blueclient$wrapConsumer(Consumer<Text> original) {
      if (original == null || !Screenshots.chatButtons()) {
         return original;
      }
      return message -> {
         if (blueclient$isSuccess(message)) {
            String name = blueclient$shotName;
            if (name == null || name.isBlank()) {
               name = blueclient$nameFrom(message);
            }
            if (name != null && !name.toLowerCase().endsWith(".png")) {
               name = name + ".png";
            }
            Path file = name != null && blueclient$shotDir != null
               ? blueclient$shotDir.toPath().resolve(name) : null;
            if (file != null && Screenshots.autoCopy()) {
               Screenshots.copyImageToClipboard(file);
            }
            original.accept(blueclient$buildMessage(name, file));
         } else {
            original.accept(message);
         }
      };
   }

   @Unique
   private static boolean blueclient$isSuccess(Text message) {
      if (message == null) {
         return false;
      }
      if (message.getContent() instanceof TranslatableTextContent content) {
         return "screenshot.success".equals(content.getKey());
      }
      String plain = message.getString();
      return plain != null && plain.toLowerCase().contains(".png");
   }

   @Unique
   private static String blueclient$nameFrom(Text message) {
      String plain = message.getString();
      if (plain == null) {
         return null;
      }
      int start = plain.indexOf("screenshot-");
      if (start < 0) {
         // "Screenshot saved: NAME" style
         int colon = plain.lastIndexOf(':');
         if (colon >= 0 && colon + 1 < plain.length()) {
            return plain.substring(colon + 1).trim();
         }
         return null;
      }
      int end = start;
      while (end < plain.length() && !Character.isWhitespace(plain.charAt(end))) {
         end++;
      }
      return plain.substring(start, end);
   }

   @Unique
   private static Text blueclient$buildMessage(String name, Path file) {
      MutableText message = Text.literal("Took screenshot: ").formatted(Formatting.GRAY)
         .append(Text.literal(name == null ? "screenshot" : name).formatted(Formatting.WHITE))
         .append(Text.literal("  "));
      String absolute = file != null ? file.toAbsolutePath().toString() : "";
      MutableText copy = Text.literal("Copy").formatted(Formatting.GREEN, Formatting.BOLD)
         .styled(style -> style
            .withClickEvent(new ClickEvent.CopyToClipboard(absolute))
            .withHoverEvent(new HoverEvent.ShowText(Text.literal("Copy the screenshot file path to your clipboard"))));
      MutableText open = Text.literal("Open").formatted(Formatting.BLUE, Formatting.BOLD)
         .styled(style -> style
            .withClickEvent(new ClickEvent.OpenFile(absolute))
            .withHoverEvent(new HoverEvent.ShowText(Text.literal("Open the screenshot in your image viewer"))));
      message.append(copy).append(Text.literal("  ").formatted(Formatting.GRAY)).append(open);
      return message;
   }
}
