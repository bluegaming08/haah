package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.HitColor;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Powers the Hit Color module: a recently attacked entity is flagged glowing
 * for a moment and its outline colour is replaced with the chosen hit colour,
 * so the vanilla outline pass draws a coloured silhouette flash on every hit.
 * Purely client-side cosmetics.
 */
@Mixin({Entity.class})
public abstract class EntityMixin {
   @Inject(
      method = {"isGlowing()Z"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void blueclient$hitGlow(CallbackInfoReturnable<Boolean> cir) {
      if (HitColor.flashing((Entity)(Object)this)) {
         cir.setReturnValue(true);
      }
   }

   @Inject(
      method = {"getTeamColorValue()I"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void blueclient$hitColor(CallbackInfoReturnable<Integer> cir) {
      if (HitColor.flashing((Entity)(Object)this)) {
         cir.setReturnValue(HitColor.color());
      }
   }
}
