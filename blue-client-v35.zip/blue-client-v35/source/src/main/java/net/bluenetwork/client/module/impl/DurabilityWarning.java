package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/**
 * Durability Warning (v3 catalogue E2) — a toast + soft tone when a held,
 * offhand or worn item drops to (or below) a durability percent. Alerts again
 * only after the configured cooldown while the item stays low, so it never
 * spams. Inventory-only reads; server-safe.
 */
public class DurabilityWarning extends Module {
   private static final String[] ARMOR_LABELS = {"Helmet", "Chestplate", "Leggings", "Boots"};

   private final NumberSetting threshold = new NumberSetting("Warn at", "Warn when durability is at or below this percent", 15.0, 1.0, 100.0, 1.0);
   private final NumberSetting cooldown = new NumberSetting("Cooldown", "Seconds between alerts while still low", 30.0, 5.0, 600.0, 5.0);
   private final BooleanSetting hand = new BooleanSetting("Main hand", "Check the item in your main hand", true);
   private final BooleanSetting offhand = new BooleanSetting("Offhand", "Check the offhand item", true);
   private final BooleanSetting armor = new BooleanSetting("Armor", "Check worn armor", true);
   private final BooleanSetting sound = new BooleanSetting("Sound", "Play a soft alert tone", true);

   private boolean wasLow = false;
   private long lastAlert = 0L;
   private String lastLowLabel = "";

   public DurabilityWarning() {
      super("Durability Warning", "Alert when an item is about to break", Category.MISC);
      this.addSettings(new Setting[]{this.threshold, this.cooldown, this.hand, this.offhand, this.armor, this.sound});
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null) {
         this.wasLow = false;
         return;
      }

      // Find the most-damaged watched item (lowest percent of durability remaining).
      Low worst = null;
      if (this.hand.get()) {
         worst = merge(worst, lowOf(mc.player.getMainHandStack(), "Main hand"));
      }
      if (this.offhand.get()) {
         worst = merge(worst, lowOf(mc.player.getOffHandStack(), "Offhand"));
      }
      if (this.armor.get()) {
         EquipmentSlot[] armorSlots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
         for (int i = 0; i < ARMOR_LABELS.length; i++) {
            worst = merge(worst, lowOf(mc.player.getEquippedStack(armorSlots[i]), ARMOR_LABELS[i]));
         }
      }
      if (worst == null) {
         this.wasLow = false;
         return;
      }

      boolean isLow = worst.pct <= this.threshold.get();
      long now = System.currentTimeMillis();
      long cooldownMs = (long) (this.cooldown.get() * 1000.0);
      if (isLow) {
         boolean changed = !worst.label.equals(this.lastLowLabel);
         if (!this.wasLow || changed || now - this.lastAlert >= cooldownMs) {
            this.lastAlert = now;
            this.lastLowLabel = worst.label;
            if (this.sound.get()) {
               Sounds.softAlert();
            }
            this.notify(worst.label + " " + (int) Math.round(worst.pct) + "% - about to break");
         }
         this.wasLow = true;
      } else {
         this.wasLow = false;
      }
   }

   private Low merge(Low current, Low next) {
      if (next == null) {
         return current;
      }
      if (current == null || next.pct < current.pct) {
         return next;
      }
      return current;
   }

   private Low lowOf(ItemStack stack, String label) {
      double pct = percentOf(stack);
      if (pct < 0.0) {
         return null;
      }
      return new Low(label, pct);
   }

   /** Percent of durability remaining; -1 when not a damageable item. */
   private double percentOf(ItemStack stack) {
      if (stack == null || stack.isEmpty() || !stack.isDamageable() || stack.getMaxDamage() <= 0) {
         return -1.0;
      }
      int remaining = stack.getMaxDamage() - stack.getDamage();
      return Math.max(0, remaining) * 100.0 / stack.getMaxDamage();
   }

   private void notify(String message) {
      try {
         BlueClient.getInstance().notificationManager().add(message, 0xFFFF5C5C);
      } catch (Throwable ignored) {
      }
   }

   private record Low(String label, double pct) {
   }
}
