package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class ToggleSprint extends Module {
   public ToggleSprint() {
      super("ToggleSprint", "Automatically sprint while moving forward.", Category.MOVEMENT);
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         if (mc.options.forwardKey.isPressed()) {
            mc.player.setSprinting(true);
         }
      }
   }
}
