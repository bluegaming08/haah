package net.bluenetwork.client.hud.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Day Counter — in-game day + real-time clock in a compact HUD panel
 * (v3 catalogue A10). Each field is independently customisable (its own
 * settings, including a v2 colour field with rainbow support).
 */
public class DayCounter extends HudModule {
   private static final String[] MODES = {"Day & Time", "Day only", "Time only"};
   private final ModeSetting mode = new ModeSetting("Mode", "What the panel shows", List.of(MODES), "Day & Time");
   private final BooleanSetting twentyFourHour = new BooleanSetting("24-hour", "Use a 24-hour clock", false);
   private final ColorSetting textColor = new ColorSetting("Text color", "HUD text colour (rainbow supported)", 0xFFFFFFFF);

   public DayCounter() {
      super("Day Counter", "In-game day and real-time clock", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.mode, this.twentyFourHour, this.textColor});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 8);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.player.getEntityWorld() == null) {
         return "Day 1";
      }
      long timeOfDay = mc.player.getEntityWorld().getTimeOfDay();
      long day = timeOfDay / 24000L + 1L;
      long tick = timeOfDay % 24000L;
      String dayText = "Day " + day;
      String timeText = formatTime(tick);
      return switch (this.mode.get()) {
         case "Day only" -> dayText;
         case "Time only" -> timeText;
         default -> dayText + " \u00b7 " + timeText;
      };
   }

   private String formatTime(long tick) {
      // Minecraft day starts at tick 0 ≈ 06:00. Map to a normal clock.
      long hour = (tick / 1000L + 6L) % 24L;
      long minute = (tick % 1000L) * 60L / 1000L;
      if (this.twentyFourHour.get()) {
         return String.format("%02d:%02d", hour, minute);
      }
      String suffix = hour < 12L ? "AM" : "PM";
      long h12 = hour % 12L;
      if (h12 == 0L) {
         h12 = 12L;
      }
      return String.format("%d:%02d %s", h12, minute, suffix);
   }

   @Override
   public void render(DrawContext context) {
      if (MinecraftClient.getInstance().player == null) {
         return;
      }
      String text = this.text();
      int panelW = RenderUtil.textWidth(text) + 12 + 2;
      this.drawPanel(context, panelW, this.getHeightCached());
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, text, this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
