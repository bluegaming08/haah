package net.bluenetwork.client.util;

public class Animation {
   private final long durationMs;
   private long startTime;

   public Animation(long durationMs) {
      this.durationMs = Math.max(1L, durationMs);
      this.reset();
   }

   public void reset() {
      this.startTime = System.currentTimeMillis();
   }

   public boolean isFinished() {
      return this.getProgress() >= 1.0;
   }

   public double getProgress() {
      long elapsed = System.currentTimeMillis() - this.startTime;
      return Math.min(1.0, (double)elapsed / this.durationMs);
   }

   public double getValue() {
      return easeOutCubic(this.getProgress());
   }

   private static double easeOutCubic(double t) {
      return 1.0 - Math.pow(1.0 - t, 3.0);
   }
}
