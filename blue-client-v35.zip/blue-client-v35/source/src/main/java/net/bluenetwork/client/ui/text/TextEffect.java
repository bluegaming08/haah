package net.bluenetwork.client.ui.text;

/**
 * Global text-style mode (redesign plan, request #3).
 *
 * <ul>
 *   <li>{@link #GLOW_SHADOW} — text renders with a soft glow pass plus the
 *       classic drop shadow (default).</li>
 *   <li>{@link #SHADOW} — classic drop shadow only (today's look).</li>
 *   <li>{@link #NONE} — crisp text with no effects.</li>
 * </ul>
 *
 * <p>The active mode is stored in {@code client-settings.json} under
 * {@code "textEffect"} and read via {@code ClientSettings.textEffect()}.</p>
 */
public enum TextEffect {
   GLOW_SHADOW("Shadow & Glow"),
   SHADOW("Shadow"),
   NONE("None");

   private final String display;

   TextEffect(String display) {
      this.display = display;
   }

   public String display() {
      return display;
   }

   /** The requested default: flat black shadow, no glow. */
   public static TextEffect defaultEffect() {
      return SHADOW;
   }

   public static TextEffect parse(String value) {
      if (value != null) {
         for (TextEffect fx : values()) {
            if (fx.name().equalsIgnoreCase(value.trim())) {
               return fx;
            }
         }
      }
      return defaultEffect();
   }
}
