package net.bluenetwork.client.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.notification.SocialToasts;
import net.bluenetwork.client.social.lan.LanInvites;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

/**
 * Holds the Friends state the UI draws, and decides WHEN to talk to Supabase.
 *
 * <h2>Why a manager instead of fetching inside the screen</h2>
 * The friends screen redraws 60+ times a second. If it fetched on every frame
 * it would flood the backend and stutter. Instead this class keeps a cached
 * copy of the data, refreshes it on a timer, and the screen just reads the
 * cache. Opening the screen is then instant.
 *
 * <h2>Presence: why not poll every second</h2>
 * Presence uses two separate intervals:
 * <ul>
 *   <li><b>Heartbeat</b> (every 60s) - one tiny RPC saying "I am online, on
 *       this server". Cheap, and enough for "last seen" to stay accurate.</li>
 *   <li><b>Friend refresh</b> (every 30s, and only while the Friends screen is
 *       actually open) - re-reads the friend list. When the screen is closed
 *       we drop to a slow background refresh, because nobody is looking.</li>
 * </ul>
 * That keeps a 100-friend account at roughly 2 requests a minute while idle,
 * instead of the 60+ a naive per-second poll would make.
 *
 * <h2>Threading</h2>
 * Every network call happens on {@link SupabaseClient}'s daemon pool. Fields
 * the render thread reads are {@code volatile} and always replaced wholesale
 * with immutable lists, so the UI can never see a half-updated list or throw
 * {@code ConcurrentModificationException}.
 */
public final class FriendsManager {

   /* ---- tuning ---------------------------------------------------------- */
   private static final long HEARTBEAT_MS = 60_000L;

   /*
    * Poll intervals.
    *
    * v21.1: REFRESH_OPEN_MS was 30 seconds, which is why the owner reported
    * "whenever I do something I need to close the menu and come back". Thirty
    * seconds of staring at stale data is indistinguishable from a broken
    * screen.
    *
    * Three seconds is affordable now because sync() uses a REVISION cursor:
    * when nothing has changed the server replies with about 90 bytes and no
    * list sections at all. Twenty polls a minute of that is ~1.8 KB/min, which
    * is nothing against the 5 GB/month egress ceiling - and the moment
    * anything DOES change, the revision moves and the full lists arrive.
    */
   private static final long REFRESH_OPEN_MS = 3_000L;
   private static final long REFRESH_IDLE_MS = 120_000L;
   /** Wait this long after the last keystroke before searching. */
   public static final long SEARCH_DEBOUNCE_MS = 350L;

   /** An entry in the friend list. Immutable - safe to hand to the renderer. */
   /**
    * One friend.
    *
    * <p>v23: extended with the fields sync() has always sent but the client
    * used to discard - skin, verified, plus, badge, name colour and presence.
    * They are needed to draw a friend row the way a post row is drawn (avatar,
    * tick, coloured name) and to publish {@code social-state.json} for the
    * launcher.</p>
    *
    * @param presence one of online / away / dnd / offline. Note that
    *                 appear-offline is enforced SERVER-side: a friend who set
    *                 offline arrives with online/server/lastSeen already
    *                 nulled, so never try to infer around it.
    */
   public record Friend(String id, String username, boolean online,
                        String server, String lastSeen,
                        String skin, boolean verified, boolean plus,
                        String badge, String nameColor, String presence) {

      /** Convenience for the 5-arg callers that predate the extra fields. */
      public Friend(String id, String username, boolean online,
                    String server, String lastSeen) {
         this(id, username, online, server, lastSeen,
              null, false, false, null, null, null);
      }

      /** The name to render an avatar for. */
      public String avatarName() {
         return this.skin != null && !this.skin.isBlank() ? this.skin : this.username;
      }
   }

   /** A pending friend request (incoming or outgoing). */
   public record Request(String id, String userId, String username, boolean incoming) {
   }

   /** A blocked user. */
   /**
    * A user reference: blocked list entries and search results.
    *
    * <p>v24: carries the skin so an avatar is the player's actual Minecraft
    * face everywhere. Search and the leaderboard previously returned only a
    * username, so those screens rendered a different face for the same
    * person.</p>
    */
   public record Blocked(String id, String username, String skin,
                         boolean verified, boolean plus, String badge,
                         String nameColor) {

      public Blocked(String id, String username) {
         this(id, username, null, false, false, null, null);
      }

      public String avatarName() {
         return this.skin != null && !this.skin.isBlank() ? this.skin : this.username;
      }
   }

   /** A DM or group thread. */
   public record Conversation(String id, boolean group, String name,
                              String otherId, String otherName,
                              String lastBody, long unread) {
      /** What to show in the list: the group name, or the other person. */
      public String title() {
         return this.group ? this.name : (this.otherName == null ? "?" : this.otherName);
      }
   }

   /** One chat message. */
   public record Message(String id, String senderId, String senderName,
                         String body, String at) {
   }

   /** A badge the player owns. */
   /**
    * A badge. {@code description} comes from the database so the owner can
    * edit it without a client update; {@link net.bluenetwork.client.ui.BadgeArt}
    * supplies a fallback for the nine shipped badges.
    */
   public record Badge(String id, String label, int colour, String description) {

      public Badge(String id, String label, int colour) {
         this(id, label, colour, null);
      }
   }

   /** A pending server invite from a friend. */
   public record Invite(String id, String fromName, String label) {
   }

   /** Someone's public profile card. */
   /**
    * A full profile, as shown on the profile PAGE.
    *
    * <p>v24: extended with everything the page needs to render - skin,
    * verified, Blue+ and when it started, name and profile colours, join date,
    * post count and staff flag. The old record predated all of it, which is
    * why the popup could not show any of them.</p>
    */
   public record Profile(String id, String username, String mcName, String mcUuid,
                         boolean premium, String about, String status,
                         String badgeId, String badgeLabel, int badgeColour,
                         long followers, long following,
                         boolean isFollowing, boolean isFriend, boolean isBuddy,
                         boolean online, String server,
                         String skin, boolean verified, boolean plus,
                         String nameColor, String profileColor,
                         long plusSince, long joined, long postCount,
                         boolean staff) {

      /** The name to render an avatar for. */
      public String avatarName() {
         return this.skin != null && !this.skin.isBlank() ? this.skin : this.username;
      }
   }

   /** The player's privacy settings. */
   public record Privacy(String requestsFrom, String onlineStatus,
                         String currentServer, String lastSeen,
                         boolean presenceNotifications) {
      public static Privacy defaults() {
         return new Privacy("everyone", "friends", "friends", "friends", true);
      }
   }

   private final SupabaseClient api = new SupabaseClient();
   private final BadgeCache badgeCache = new BadgeCache(this.api);

   /* ---- cached state read by the render thread -------------------------- */
   private volatile List<Friend> friends = List.of();
   private volatile List<Request> incoming = List.of();
   private volatile List<Request> outgoing = List.of();
   private volatile List<Blocked> blocked = List.of();
   private volatile Privacy privacy = Privacy.defaults();
   private volatile List<Conversation> conversations = List.of();
   private volatile List<Badge> myBadges = List.of();
   private volatile String equippedBadge;
   private volatile String about;
   private volatile String status;
   private volatile String buddyId;
   private volatile String mcName;
   private volatile boolean mcVerified;
   private volatile long unreadTotal = -1L;
   private volatile String username;

   /* ---- v21 ------------------------------------------------------------- */
   /** Cursor for sync(): the server clock at our last successful sync. */
   private volatile long syncCursor;
   private volatile long followers;
   private volatile long following;
   private volatile long friendCount;
   private volatile boolean verified;
   private volatile boolean plus;
   private volatile long plusSince;
   private volatile long plusUntil;
   private volatile boolean plusPermanent;
   private volatile String presence = "online";
   private volatile String skinName;
   private volatile String profileColor;
   /** The globally pinned post, or null. */
   private volatile Post pinned;
   /** True when this account is Blue or Cyan (pin powers). */
   private volatile boolean staff;
   private volatile String nameColor;
   private volatile List<Invite> invites = List.of();

   /** Null when everything is fine; otherwise what to show the player. */
   private volatile String lastError;
   private volatile boolean busy;
   private volatile boolean screenOpen;

   private volatile long lastHeartbeat;
   private volatile long lastRefresh;
   private volatile long lastRequestCount = -1L;

   /** Remembers who was online so we only notify on an actual change. */
   private volatile java.util.Set<String> onlineLastTime = java.util.Set.of();

   private final Path sessionFile = FabricLoader.getInstance()
      .getConfigDir().resolve("blueclient").resolve("social-session.txt");

   /* ====================================================================== */
   /*  Lifecycle                                                             */
   /* ====================================================================== */

   /** Called once at startup. Never blocks, never throws. */
   public void init() {
      if (!BlueBackend.configured()) {
         return;
      }
      // Persist every rotated refresh token, not just the one from login.
      // Without this the saved token goes stale within the hour and the next
      // launch does a full sign-in, which Supabase bills as a new monthly
      // active user. See SupabaseClient.onSessionChanged.
      this.api.setSessionListener(this::saveSession);
      try {
         if (Files.exists(this.sessionFile)) {
            String token = Files.readString(this.sessionFile, StandardCharsets.UTF_8).trim();
            if (!token.isBlank()) {
               this.api.resumeSession(token)
                  .thenRun(this::afterLogin)
                  .exceptionally(e -> {
                     // An expired saved session is normal, not an error to show.
                     BlueClient.LOGGER.debug("[Social] could not resume session");
                     deleteSession();
                     return null;
                  });
            }
         }
      } catch (Exception e) {
         BlueClient.LOGGER.debug("[Social] session restore skipped", e);
      }
   }

   /**
    * Called every client tick. Cheap: it only compares timestamps, and only
    * starts a request when one is actually due.
    */
   public void onTick() {
      if (!BlueBackend.configured() || !this.api.loggedIn()) {
         return;
      }
      long now = System.currentTimeMillis();
      this.badgeCache.onTick(true);

      if (now - this.lastHeartbeat >= HEARTBEAT_MS) {
         this.lastHeartbeat = now;
         sendHeartbeat(true);
      }

      long interval = this.screenOpen ? REFRESH_OPEN_MS : REFRESH_IDLE_MS;
      if (now - this.lastRefresh >= interval) {
         this.lastRefresh = now;
         refreshAll();
      }
   }

   /** Called when the game closes so friends see us go offline promptly. */
   public void shutdown() {
      if (this.api.loggedIn()) {
         try {
            sendHeartbeat(false).get(2, java.util.concurrent.TimeUnit.SECONDS);
         } catch (Exception ignored) {
            // Best effort; last_seen will age out anyway.
         }
      }
   }

   public void setScreenOpen(boolean open) {
      this.screenOpen = open;
      if (open) {
         // Opening the screen should feel live, so refresh immediately.
         this.lastRefresh = System.currentTimeMillis();
         refreshAll();
      }
   }

   /**
    * Forces the next tick to re-sync, and syncs right now.
    *
    * <p>Call this after ANY action that changes what is on screen. Waiting for
    * the next poll is what made the UI feel broken: you accepted a request and
    * the list did not move, so the only way to see the result was to close the
    * screen and reopen it.</p>
    *
    * <p>Cheap by design - if the server's revision has not moved this costs
    * about 90 bytes and changes nothing.</p>
    */
   public void refreshNow() {
      this.lastRefresh = System.currentTimeMillis();
      refreshAll();
   }

   /* ====================================================================== */
   /*  Accessors for the UI                                                  */
   /* ====================================================================== */

   public boolean available() {
      return BlueBackend.configured();
   }

   /**
    * The current sync revision.
    *
    * <p>Published to the launcher in {@code social-state.json} so it can
    * resume polling with {@code sync(since = rev)} when the game exits rather
    * than re-fetching a full payload.</p>
    */
   public long syncCursor() {
      return this.syncCursor;
   }

   public boolean loggedIn() {
      return this.api.loggedIn();
   }

   /**
    * Our username, never null.
    *
    * <p><b>This must not return null.</b> A resumed session reports
    * {@code loggedIn() == true} the moment the refresh token is accepted, but
    * the profile row - and therefore the username - only arrives a round trip
    * later. The Social screen renders in between, and every caller that did
    * {@code username().toLowerCase()} threw an NPE on that first frame, which
    * crashed the game the instant the screen opened.</p>
    */
   public String username() {
      return this.username == null ? "" : this.username;
   }

   /** True once the profile row has actually loaded. */
   public boolean profileReady() {
      return this.username != null && !this.username.isBlank();
   }

   /** Our own profile id, or null when logged out. Used to open our profile. */
   public String ownId() {
      return this.api.userId();
   }

   public List<Friend> friends() {
      return this.friends;
   }

   public List<Request> incoming() {
      return this.incoming;
   }

   public List<Request> outgoing() {
      return this.outgoing;
   }

   public List<Blocked> blocked() {
      return this.blocked;
   }

   public Privacy privacy() {
      return this.privacy;
   }

   /** Badge lookup for the nametag renderer. Hot path - map lookup only. */
   public BadgeCache badges() {
      return this.badgeCache;
   }

   public List<Conversation> conversations() {
      return this.conversations;
   }

   /**
    * A human label for a badge id.
    *
    * <p>Prefers the label the server sent with your owned badges; falls back
    * to prettifying the id so an unknown badge still shows something sensible
    * rather than a raw snake_case key.</p>
    */
   public String badgeLabel(String badgeId) {
      if (badgeId == null) {
         return "";
      }
      for (Badge b : this.myBadges) {
         if (b.id().equals(badgeId)) {
            return b.label();
         }
      }
      String[] parts = badgeId.split("_");
      StringBuilder sb = new StringBuilder();
      for (String part : parts) {
         if (part.isEmpty()) {
            continue;
         }
         if (sb.length() > 0) {
            sb.append(' ');
         }
         sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
      }
      return sb.toString();
   }

   public List<Badge> myBadges() {
      return this.myBadges;
   }

   public String equippedBadge() {
      return this.equippedBadge;
   }

   public String about() {
      return this.about;
   }

   public String status() {
      return this.status;
   }

   public String buddyId() {
      return this.buddyId;
   }

   public String minecraftName() {
      return this.mcName;
   }

   public boolean minecraftVerified() {
      return this.mcVerified;
   }

   /** Total unread messages across every conversation (for the badge dot). */
   public long unreadTotal() {
      return this.unreadTotal;
   }

   public String lastError() {
      return this.lastError;
   }

   public boolean busy() {
      return this.busy;
   }

   public void clearError() {
      this.lastError = null;
   }

   /* ---- v21 accessors --------------------------------------------------- */

   public long followers() {
      return this.followers;
   }

   public long following() {
      return this.following;
   }

   public long friendCount() {
      return this.friendCount;
   }

   public boolean verified() {
      return this.verified;
   }

   /** True while this account has an active Blue+ subscription. */
   public boolean plus() {
      return this.plus;
   }

   public boolean plusPermanent() {
      return this.plusPermanent;
   }

   /** Epoch seconds when Blue+ started, or 0. */
   public long plusSince() {
      return this.plusSince;
   }

   /** Epoch seconds when Blue+ lapses, or 0 when permanent/absent. */
   public long plusUntil() {
      return this.plusUntil;
   }

   /** "online", "dnd" or "offline". */
   public String presence() {
      return this.presence;
   }

   public String nameColor() {
      return this.nameColor;
   }

   /** Minecraft username used for the social avatar, or null. */
   public String skinName() {
      return this.skinName;
   }

   public List<Invite> invites() {
      return this.invites;
   }

   /** The character limit for this account's tier. */
   public int limitOf(String key) {
      return Limits.of(key, this.plus);
   }

   public int onlineCount() {
      int n = 0;
      for (Friend f : this.friends) {
         if (f.online()) {
            n++;
         }
      }
      return n;
   }

   /* ====================================================================== */
   /*  Auth actions                                                          */
   /* ====================================================================== */

   public void signUp(String name, String password, Runnable onDone) {
      run(this.api.signUp(name, password).thenRun(() -> {
         this.username = name;
         afterLogin();
      }), onDone);
   }

   public void logIn(String name, String password, Runnable onDone) {
      run(this.api.logIn(name, password).thenRun(this::afterLogin), onDone);
   }

   public void logOut(Runnable onDone) {
      LauncherBridge.clearState();
      SkinIndex.clear();
      sendHeartbeat(false);
      run(this.api.logOut().thenRun(() -> {
         this.friends = List.of();
         this.incoming = List.of();
         this.outgoing = List.of();
         this.blocked = List.of();
         this.username = null;
         this.conversations = List.of();
         this.myBadges = List.of();
         this.equippedBadge = null;
         this.badgeCache.clear();
         deleteSession();
      }), onDone);
   }

   private void afterLogin() {
      saveSession();
      loadOwnProfile();
      refreshStaffFlag();
      refreshAll();
      refreshFeed();
      refreshLeaderboard();
      sendHeartbeat(true);
   }

   /** Re-reads just our own profile row - used after linking Minecraft. */
   private void refreshProfileBits() {
      loadOwnProfile();
   }

   private void loadOwnProfile() {
      String uid = this.api.userId();
      if (uid == null) {
         return;
      }
      this.api.select("profiles",
            "select=username,about,status,equipped_badge,buddy_id,mc_name,mc_verified,"
               + "presence,name_color,skin_name"
               + "&id=eq." + SupabaseClient.enc(uid))
         .thenAccept(arr -> {
            if (!arr.isEmpty() && arr.get(0).isJsonObject()) {
               JsonObject o = arr.get(0).getAsJsonObject();
               this.username = str(o, "username", this.username);
               this.about = str(o, "about", null);
               this.status = str(o, "status", null);
               this.equippedBadge = str(o, "equipped_badge", null);
               this.buddyId = str(o, "buddy_id", null);
               this.mcName = str(o, "mc_name", null);
               this.mcVerified = o.has("mc_verified") && !o.get("mc_verified").isJsonNull()
                  && o.get("mc_verified").getAsBoolean();
               this.presence = str(o, "presence", "online");
               this.nameColor = str(o, "name_color", null);
               this.skinName = str(o, "skin_name", null);
               // Our own face, so our posts and the account card agree.
               SkinIndex.put(this.username, this.skinName);
            }
         })
         .exceptionally(this::swallow);

      refreshMyBadges();

      this.api.select("settings", "select=*&id=eq." + SupabaseClient.enc(uid))
         .thenAccept(arr -> {
            if (!arr.isEmpty() && arr.get(0).isJsonObject()) {
               JsonObject o = arr.get(0).getAsJsonObject();
               this.privacy = new Privacy(
                  str(o, "allow_requests_from", "everyone"),
                  str(o, "show_online_status", "friends"),
                  str(o, "show_current_server", "friends"),
                  str(o, "show_last_seen", "friends"),
                  !o.has("presence_notifications") || o.get("presence_notifications").getAsBoolean());
            }
         })
         .exceptionally(this::swallow);
   }

   /* ====================================================================== */
   /*  Data refresh                                                          */
   /* ====================================================================== */

   /**
    * Refreshes everything the social UI shows - in ONE request.
    *
    * <h2>Why this replaced four separate calls</h2>
    * v20 fired {@code get_friends}, {@code friend_requests}, {@code blocks}
    * and {@code get_conversations} every refresh. That is four round trips,
    * four sets of HTTP headers, and four full payloads even when nothing had
    * changed. Supabase's free tier caps <b>egress at 5 GB a month across the
    * whole organisation</b>, and that was the ceiling we were heading for.
    *
    * <p>{@code sync(since)} returns only what changed since our cursor, using
    * one- and two-character JSON keys. An idle poll is about 22 bytes.</p>
    *
    * <p>Blocks are deliberately NOT in sync(): they change rarely and are only
    * needed on one tab, so they are fetched when that tab opens.</p>
    */
   public void refreshAll() {
      if (!this.api.loggedIn()) {
         return;
      }
      JsonObject args = new JsonObject();
      args.addProperty("since", this.syncCursor);

      this.api.rpc("sync", args)
         .thenAccept(this::applySync)
         .exceptionally(this::report);
   }

   /**
    * Applies a sync() payload.
    *
    * <p>Keys are short on purpose (see schema_v3.sql section 9):
    * f=friends, r=requests, c=conversations, iv=invites, me=own counters,
    * v=server clock. Absent sections mean "unchanged", NOT "now empty", so
    * each one is only replaced when actually present.</p>
    */
   private void applySync(JsonElement el) {
      if (el == null || !el.isJsonObject()) {
         return;
      }
      JsonObject o = el.getAsJsonObject();

      if (o.has("e")) {
         // Server says we are not authenticated any more.
         this.lastError = "Session expired - log in again.";
         LauncherBridge.clearState();
         return;
      }

      if (o.has("v") && !o.get("v").isJsonNull()) {
         this.syncCursor = o.get("v").getAsLong();
      }

      if (o.has("f") && o.get("f").isJsonArray()) {
         List<Friend> list = new ArrayList<>();
         for (JsonElement e : o.getAsJsonArray("f")) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject f = e.getAsJsonObject();
            // Remember this player's face so notifications, chat headers and
            // any other row can draw the SAME avatar as their posts do.
            SkinIndex.put(str(f, "u", null), str(f, "sk", null));
            list.add(new Friend(
               str(f, "i", ""),
               str(f, "u", "?"),
               bool(f, "o"),
               str(f, "s", null),
               null,
               str(f, "sk", null),
               bool(f, "v"),
               bool(f, "pl"),
               str(f, "b", null),
               str(f, "c", null),
               str(f, "pr", null)));
         }
         List<Friend> now = Collections.unmodifiableList(list);
         notifyPresenceChanges(now);
         this.friends = now;
      }

      if (o.has("r") && o.get("r").isJsonArray()) {
         List<Request> list = new ArrayList<>();
         for (JsonElement e : o.getAsJsonArray("r")) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject r = e.getAsJsonObject();
            list.add(new Request(str(r, "i", ""), null, str(r, "u", "?"), true));
         }
         notifyNewRequests(list);
         this.incoming = Collections.unmodifiableList(list);
      }

      // v21.1: outgoing requests are now synced too. Without this the SENDER
      // never learned their request had been accepted or declined, so it sat
      // in their Requests tab forever - half of the owner's stuck-request bug.
      if (o.has("ro") && o.get("ro").isJsonArray()) {
         List<Request> list = new ArrayList<>();
         for (JsonElement e : o.getAsJsonArray("ro")) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject r = e.getAsJsonObject();
            list.add(new Request(str(r, "i", ""), null, str(r, "u", "?"), false));
         }
         notifyResolvedRequests(list);
         this.outgoing = Collections.unmodifiableList(list);
      }

      if (o.has("c") && o.get("c").isJsonArray()) {
         applyConversations(o.getAsJsonArray("c"));
      }

      if (o.has("iv") && o.get("iv").isJsonArray()) {
         List<Invite> list = new ArrayList<>();
         for (JsonElement e : o.getAsJsonArray("iv")) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject iv = e.getAsJsonObject();
            list.add(new Invite(str(iv, "i", ""), str(iv, "u", "?"), str(iv, "l", null)));
         }
         List<Invite> now = Collections.unmodifiableList(list);
         notifyNewInvites(now);
         this.invites = now;
      }

      // The pinned post. Always present on a fresh payload, '[]' when nothing
      // is pinned - so an unpin genuinely clears it rather than leaving the
      // last value on screen.
      if (o.has("pn") && o.get("pn").isJsonArray()) {
         Post found = null;
         for (JsonElement e : o.getAsJsonArray("pn")) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject q = e.getAsJsonObject();
            found = new Post(
               str(q, "i", ""), str(q, "u", "?"), str(q, "b", ""),
               num(q, "t"), str(q, "bd", null), str(q, "c", null),
               bool(q, "pl"), bool(q, "v"), str(q, "sk", null),
               (int) num(q, "lk"), (int) num(q, "rc"), (int) num(q, "rp"),
               bool(q, "il"), bool(q, "ir"), null);
            break;
         }
         this.pinned = found;
      }

      // Server-side notifications. These carry events the client cannot
      // derive by diffing its own rows - "someone you follow posted" and
      // "staff pinned a post" in particular.
      if (o.has("nt") && o.get("nt").isJsonArray()) {
         applyServerNotifications(o.getAsJsonArray("nt"));
      }

      // Staff announcements. Delivered through sync(), so they arrive
      // wherever the player is - any server, singleplayer, or the main menu.
      if (o.has("an") && o.get("an").isJsonArray()) {
         applyAnnouncements(o.getAsJsonArray("an"));
      }

      if (o.has("me") && o.get("me").isJsonObject()) {
         JsonObject me = o.getAsJsonObject("me");
         this.followers = num(me, "fo");
         this.following = num(me, "fg");
         this.friendCount = num(me, "fr");
         this.verified = bool(me, "v");
         this.plus = bool(me, "pl");
         this.plusSince = num(me, "ps");
         this.plusUntil = num(me, "pu");
         this.plusPermanent = bool(me, "pp");
         this.profileColor = str(me, "pc", null);
         // "st" only exists once schema_v3 is applied. Absent means the old
         // sync() is live - do NOT clear a staff flag we already established
         // some other way, or the Admin button would flicker away on an old
         // backend.
         if (me.has("st")) {
            this.staff = bool(me, "st");
         }
      }

      this.lastError = null;

      // Hand the fresh state to the launcher. Skips the disk entirely when
      // nothing changed, so calling it every sync is effectively free.
      LauncherBridge.publish(this);
   }

   /** Notification ids already turned into toasts, so none fires twice. */
   private final java.util.Set<Long> seenNotifications =
      java.util.concurrent.ConcurrentHashMap.newKeySet();

   /**
    * Turns unread server notifications into toasts.
    *
    * <p>Silent on the FIRST sync: a fresh login would otherwise fire a toast
    * for every unread row at once, which is noise rather than news. The rows
    * stay unread, so they still appear in the Activity tab.</p>
    */
   private void applyServerNotifications(JsonArray rows) {
      boolean first = this.syncCursor == 0L || this.seenNotifications.isEmpty()
         && !this.notificationsPrimed;
      for (JsonElement e : rows) {
         if (!e.isJsonObject()) {
            continue;
         }
         JsonObject n = e.getAsJsonObject();
         long id = (long) num(n, "i");
         if (!this.seenNotifications.add(id)) {
            continue;                       // already shown
         }
         if (first || "dnd".equals(this.presence)) {
            continue;
         }
         String who = str(n, "u", "?");
         String kind = str(n, "k", "");
         String postId = str(n, "p", null);
         String preview = str(n, "pv", "");

         switch (kind) {
            case "post" -> SocialToasts.social(SocialToasts.Kind.POSTED, who,
               postId, preview);
            case "pinned" -> SocialToasts.social(SocialToasts.Kind.PINNED, who,
               postId, preview);
            case "like" -> SocialToasts.social(SocialToasts.Kind.LIKE, who, postId);
            case "reply" -> SocialToasts.social(SocialToasts.Kind.REPLY, who, postId);
            case "repost" -> SocialToasts.social(SocialToasts.Kind.REPOST, who, postId);
            case "follow" -> SocialToasts.social(SocialToasts.Kind.FOLLOW, who, null);
            default -> {
            }
         }
      }
      this.notificationsPrimed = true;
   }

   /** False until the first notification payload has been absorbed. */
   private volatile boolean notificationsPrimed;

   /**
    * Highest announcement id already shown.
    *
    * <p>Persisted in memory only. Re-showing one after a restart is a far
    * smaller annoyance than writing a file on every sync, and the server
    * expires them after a couple of days anyway.</p>
    */
   private volatile long lastAnnouncement;

   /** Shows any announcement newer than the last one seen. */
   private void applyAnnouncements(JsonArray rows) {
      // Ascending, so several queued announcements appear in order.
      java.util.List<JsonObject> items = new ArrayList<>();
      for (JsonElement e : rows) {
         if (e.isJsonObject()) {
            items.add(e.getAsJsonObject());
         }
      }
      items.sort((a, b) -> Long.compare((long) num(a, "i"), (long) num(b, "i")));

      for (JsonObject a : items) {
         long id = (long) num(a, "i");
         if (id <= this.lastAnnouncement) {
            continue;
         }
         this.lastAnnouncement = id;

         // On the very first sync after launch, adopt the latest id WITHOUT
         // showing it: a player logging in should not be greeted by a stack
         // of announcements they already missed.
         if (this.announcementsPrimed) {
            int colour = switch (str(a, "c", "blue")) {
               case "green" -> 0xFF00BA7C;
               case "gold" -> 0xFFFFD400;
               case "red" -> 0xFFF4212E;
               default -> 0xFF1D9BF0;
            };
            net.bluenetwork.client.notification.Announcements
               .show(str(a, "b", ""), colour);
         }
      }
      this.announcementsPrimed = true;
   }

   private volatile boolean announcementsPrimed;

   /** Marks every server notification read. */
   public void markNotificationsRead() {
      this.api.rpc("mark_notifications_read", new JsonObject())
         .exceptionally(this::swallow);
   }

   /** Announces friend requests that arrived since the last sync. */
   private void notifyNewRequests(List<Request> now) {
      // Never announce on the first load - a fresh login would fire a toast
      // for every request already waiting, which is noise, not news.
      if (this.syncCursor == 0L || "dnd".equals(this.presence)) {
         return;
      }
      for (Request r : now) {
         boolean known = this.incoming.stream().anyMatch(i -> i.id().equals(r.id()));
         if (!known) {
            SocialToasts.social(SocialToasts.Kind.REQUEST, r.username(), r.id());
         }
      }
   }

   /**
    * Announces YOUR outgoing requests that are no longer pending.
    *
    * <p>A request leaving the outgoing list means the other side acted on it.
    * If they are now a friend it was accepted; otherwise it was declined, and
    * we deliberately stay silent about that - nobody needs a notification
    * telling them they were rejected.</p>
    */
   private void notifyResolvedRequests(List<Request> now) {
      if (this.syncCursor == 0L || "dnd".equals(this.presence)) {
         return;
      }
      for (Request was : this.outgoing) {
         boolean stillPending = now.stream().anyMatch(r -> r.id().equals(was.id()));
         if (stillPending) {
            continue;
         }
         boolean nowFriends = this.friends.stream()
            .anyMatch(f -> f.username().equalsIgnoreCase(was.username()));
         if (nowFriends) {
            SocialToasts.social(SocialToasts.Kind.ACCEPTED, was.username(), null);
         }
      }
   }

   /** Announces invites we have not seen before. */
   private void notifyNewInvites(List<Invite> now) {
      if (this.invites.isEmpty() && now.isEmpty()) {
         return;
      }
      // Do not announce on the very first load, or a player logging in would
      // get a burst of notifications for invites they already knew about.
      if (this.syncCursor == 0L) {
         return;
      }
      for (Invite inv : now) {
         boolean known = this.invites.stream().anyMatch(i -> i.id().equals(inv.id()));
         if (!known && !"dnd".equals(this.presence)) {
            // Clickable: clicking the toast accepts the invite and connects.
            SocialToasts.invite(inv.fromName(), "Click to join", inv.id());
         }
      }
   }



   private void refreshFriends() {
      this.api.rpc("get_friends", new JsonObject())
         .thenAccept(el -> {
            if (el == null || !el.isJsonArray()) {
               return;
            }
            List<Friend> list = new ArrayList<>();
            for (JsonElement e : el.getAsJsonArray()) {
               if (!e.isJsonObject()) {
                  continue;
               }
               JsonObject o = e.getAsJsonObject();
               list.add(new Friend(
                  str(o, "id", ""),
                  str(o, "username", "?"),
                  o.has("is_online") && !o.get("is_online").isJsonNull()
                     && o.get("is_online").getAsBoolean(),
                  str(o, "server_name", null),
                  str(o, "last_seen", null)));
            }
            List<Friend> now = Collections.unmodifiableList(list);
            notifyPresenceChanges(now);
            this.friends = now;
            this.lastError = null;
         })
         .exceptionally(this::report);
   }

   /**
    * Fires a notification when a friend comes online.
    *
    * <p>Only transitions are announced, and never on the very first load -
    * otherwise logging in would spam one toast per online friend.</p>
    */
   private void notifyPresenceChanges(List<Friend> now) {
      java.util.Set<String> nowOnline = new java.util.HashSet<>();
      for (Friend f : now) {
         if (f.online()) {
            nowOnline.add(f.id());
         }
      }
      boolean first = this.onlineLastTime.isEmpty() && this.friends.isEmpty();
      if (!first && this.privacy.presenceNotifications()) {
         for (Friend f : now) {
            if (f.online() && !this.onlineLastTime.contains(f.id())) {
               notify(f.username() + " is now online", 0xFF43D17A);
            }
         }
      }
      this.onlineLastTime = nowOnline;
   }

   private void refreshRequests() {
      String uid = this.api.userId();
      if (uid == null) {
         return;
      }
      // One query for each direction, with the other user's profile joined in
      // by PostgREST so we get usernames without a second round trip.
      this.api.select("friend_requests",
            "select=id,sender_id,receiver_id,sender:profiles!friend_requests_sender_id_fkey(username),"
               + "receiver:profiles!friend_requests_receiver_id_fkey(username)"
               + "&or=(sender_id.eq." + SupabaseClient.enc(uid)
               + ",receiver_id.eq." + SupabaseClient.enc(uid) + ")")
         .thenAccept(arr -> {
            List<Request> in = new ArrayList<>();
            List<Request> out = new ArrayList<>();
            for (JsonElement e : arr) {
               if (!e.isJsonObject()) {
                  continue;
               }
               JsonObject o = e.getAsJsonObject();
               String id = str(o, "id", "");
               String sender = str(o, "sender_id", "");
               String receiver = str(o, "receiver_id", "");
               if (uid.equals(receiver)) {
                  in.add(new Request(id, sender, nested(o, "sender"), true));
               } else {
                  out.add(new Request(id, receiver, nested(o, "receiver"), false));
               }
            }
            // Notify when a NEW incoming request arrives.
            if (this.lastRequestCount >= 0 && in.size() > this.lastRequestCount) {
               notify("New friend request", 0xFF2FA5FF);
            }
            this.lastRequestCount = in.size();
            this.incoming = Collections.unmodifiableList(in);
            this.outgoing = Collections.unmodifiableList(out);
         })
         .exceptionally(this::report);
   }

   private void refreshBlocked() {
      this.api.select("blocks",
            "select=blocked_id,profiles!blocks_blocked_id_fkey(username)")
         .thenAccept(arr -> {
            List<Blocked> list = new ArrayList<>();
            for (JsonElement e : arr) {
               if (!e.isJsonObject()) {
                  continue;
               }
               JsonObject o = e.getAsJsonObject();
               list.add(new Blocked(str(o, "blocked_id", ""), nested(o, "profiles")));
            }
            this.blocked = Collections.unmodifiableList(list);
         })
         .exceptionally(this::swallow);
   }

   /* ====================================================================== */
   /*  Friend actions                                                        */
   /* ====================================================================== */

   /** Searches usernames. Callers must debounce - see SEARCH_DEBOUNCE_MS. */
   public void search(String query, Consumer<List<Blocked>> onResult) {
      if (!this.api.loggedIn()) {
         return;
      }
      JsonObject args = new JsonObject();
      args.addProperty("q", query);
      this.api.rpc("search_users", args)
         .thenAccept(el -> {
            List<Blocked> list = new ArrayList<>();
            if (el != null && el.isJsonArray()) {
               for (JsonElement e : el.getAsJsonArray()) {
                  if (e.isJsonObject()) {
                     JsonObject o = e.getAsJsonObject();
                     SkinIndex.put(str(o, "username", null), str(o, "skin_name", null));
                     list.add(new Blocked(str(o, "id", ""), str(o, "username", "?"),
                        str(o, "skin_name", null), bool(o, "verified"),
                        bool(o, "is_plus"), str(o, "equipped_badge", null),
                        str(o, "name_color", null)));
                  }
               }
            }
            onResult.accept(Collections.unmodifiableList(list));
         })
         .exceptionally(e -> {
            onResult.accept(List.of());
            return report(e);
         });
   }

   public void sendRequest(String targetId, Runnable onDone) {
      JsonObject row = new JsonObject();
      row.addProperty("sender_id", this.api.userId());
      row.addProperty("receiver_id", targetId);
      run(this.api.insert("friend_requests", row).thenRun(() -> {
         notify("Friend request sent", 0xFF2FA5FF);
         refreshRequests();
      }), onDone);
   }

   public void acceptRequest(String requestId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("request_id", requestId);
      run(this.api.rpc("accept_friend_request", args).thenAccept(x -> {
         notify("Friend added", 0xFF43D17A);
         // refreshNow, not refreshAll: this must also reset the poll timer, or
         // a tick scheduled moments later can overwrite us with stale data.
         refreshNow();
      }), onDone);
   }

   public void declineRequest(String requestId, Runnable onDone) {
      run(this.api.delete("friend_requests", "id=eq." + SupabaseClient.enc(requestId))
         .thenRun(this::refreshRequests), onDone);
   }

   /** Cancelling an outgoing request is the same DELETE as declining. */
   public void cancelRequest(String requestId, Runnable onDone) {
      declineRequest(requestId, onDone);
   }

   public void removeFriend(String friendId, Runnable onDone) {
      String me = this.api.userId();
      if (me == null) {
         return;
      }
      // The row is stored with the smaller uuid first, so match either way.
      String a = me.compareTo(friendId) < 0 ? me : friendId;
      String b = me.compareTo(friendId) < 0 ? friendId : me;
      run(this.api.delete("friendships",
            "user_a=eq." + SupabaseClient.enc(a) + "&user_b=eq." + SupabaseClient.enc(b))
         .thenRun(this::refreshNow), onDone);
   }

   public void blockUser(String targetId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("target", targetId);
      run(this.api.rpc("block_user", args).thenAccept(x -> {
         notify("User blocked", 0xFFE35D5D);
         refreshNow();
      }), onDone);
   }

   public void unblockUser(String targetId, Runnable onDone) {
      run(this.api.delete("blocks",
            "blocker_id=eq." + SupabaseClient.enc(this.api.userId())
               + "&blocked_id=eq." + SupabaseClient.enc(targetId))
         .thenRun(this::refreshNow), onDone);
   }

   public void savePrivacy(Privacy p, Runnable onDone) {
      JsonObject row = new JsonObject();
      row.addProperty("allow_requests_from", p.requestsFrom());
      row.addProperty("show_online_status", p.onlineStatus());
      row.addProperty("show_current_server", p.currentServer());
      row.addProperty("show_last_seen", p.lastSeen());
      row.addProperty("presence_notifications", p.presenceNotifications());
      this.privacy = p;
      run(this.api.patch("settings",
         "id=eq." + SupabaseClient.enc(this.api.userId()), row), onDone);
   }

   /* ====================================================================== */
   /*  Messaging                                                             */
   /* ====================================================================== */

   public void refreshConversations() {
      if (!this.api.loggedIn()) {
         return;
      }
      this.api.rpc("get_conversations", new JsonObject())
         .thenAccept(el -> {
            if (el != null && el.isJsonArray()) {
               applyConversations(el.getAsJsonArray());
            }
         })
         .exceptionally(this::swallow);
   }

   /**
    * Turns a conversation array into the cached list.
    *
    * <p>Shared by {@link #refreshConversations()} and the batched
    * {@code sync()} path so both produce identical state - the get_conversations
    * RPC returns the same shape either way.</p>
    */
   private void applyConversations(JsonArray arr) {
      List<Conversation> list = new ArrayList<>();
      long unread = 0L;
      for (JsonElement e : arr) {
         if (!e.isJsonObject()) {
            continue;
         }
         JsonObject o = e.getAsJsonObject();
         long u = o.has("unread") && !o.get("unread").isJsonNull()
            ? o.get("unread").getAsLong() : 0L;
         unread += u;
         list.add(new Conversation(
            str(o, "id", ""),
            o.has("is_group") && !o.get("is_group").isJsonNull()
               && o.get("is_group").getAsBoolean(),
            str(o, "name", null),
            str(o, "other_id", null),
            str(o, "other_name", null),
            str(o, "last_body", null),
            u));
      }
      // Announce genuinely new unread messages, not the initial load, and
      // stay silent entirely while the player is on Do Not Disturb.
      if (this.unreadTotal >= 0L && unread > this.unreadTotal
         && !"dnd".equals(this.presence)) {
         // Raise a clickable toast for whichever conversation actually grew,
         // so clicking it can open that exact chat rather than a generic list.
         Conversation grew = null;
         for (Conversation c : list) {
            long before = 0L;
            for (Conversation old : this.conversations) {
               if (old.id().equals(c.id())) {
                  before = old.unread();
                  break;
               }
            }
            if (c.unread() > before) {
               grew = c;
               break;
            }
         }
         if (grew != null) {
            SocialToasts.message(
               grew.otherName() == null ? "Friend" : grew.otherName(),
               grew.lastBody() == null ? "sent you a message" : grew.lastBody(),
               grew.id());
         } else {
            notify("New message", 0xFF2FA5FF);
         }
      }
      this.unreadTotal = unread;
      this.conversations = Collections.unmodifiableList(list);
   }

   /** Opens (or finds) the DM with a friend, then hands back its id. */
   public void openDm(String friendId, Consumer<String> onReady) {
      JsonObject args = new JsonObject();
      args.addProperty("target", friendId);
      this.api.rpc("open_dm", args)
         .thenAccept(el -> {
            String id = el != null && el.isJsonPrimitive() ? el.getAsString() : null;
            if (id != null) {
               refreshConversations();
               onReady.accept(id);
            }
         })
         .exceptionally(this::report);
   }

   public void loadMessages(String convId, Consumer<List<Message>> onReady) {
      JsonObject args = new JsonObject();
      args.addProperty("conv", convId);
      args.addProperty("limit_n", 50);
      this.api.rpc("get_messages", args)
         .thenAccept(el -> {
            List<Message> list = new ArrayList<>();
            if (el != null && el.isJsonArray()) {
               for (JsonElement e : el.getAsJsonArray()) {
                  if (!e.isJsonObject()) {
                     continue;
                  }
                  JsonObject o = e.getAsJsonObject();
                  list.add(new Message(str(o, "id", ""), str(o, "sender_id", ""),
                     str(o, "sender_name", "?"), str(o, "body", ""), str(o, "created_at", null)));
               }
            }
            // The RPC returns newest-first; the UI reads oldest-first.
            Collections.reverse(list);
            onReady.accept(Collections.unmodifiableList(list));
         })
         .exceptionally(e -> {
            onReady.accept(List.of());
            return report(e);
         });
   }

   public void sendMessage(String convId, String body, Runnable onDone) {
      String text = body == null ? "" : body.trim();
      if (text.isEmpty()) {
         return;
      }
      if (text.length() > 256) {
         text = text.substring(0, 256);
      }
      JsonObject row = new JsonObject();
      row.addProperty("conversation_id", convId);
      row.addProperty("sender_id", this.api.userId());
      row.addProperty("body", text);
      run(this.api.insert("messages", row), onDone);
   }

   public void markRead(String convId) {
      JsonObject args = new JsonObject();
      args.addProperty("conv", convId);
      this.api.rpc("mark_read", args)
         .thenAccept(x -> refreshConversations())
         .exceptionally(this::swallow);
   }

   public void createGroup(String name, List<String> memberIds, Runnable onDone) {
      JsonArray arr = new JsonArray();
      for (String id : memberIds) {
         arr.add(id);
      }
      JsonObject args = new JsonObject();
      args.addProperty("p_name", name);
      args.add("members", arr);
      run(this.api.rpc("create_group", args).thenAccept(x -> {
         notify("Group created", 0xFF2FA5FF);
         refreshConversations();
      }), onDone);
   }

   public void leaveConversation(String convId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("conv", convId);
      run(this.api.rpc("leave_conversation", args)
         .thenAccept(x -> refreshConversations()), onDone);
   }

   /* ====================================================================== */
   /*  Profile, badges, status, buddy, follows                               */
   /* ====================================================================== */

   public void refreshMyBadges() {
      this.api.rpc("my_badges", new JsonObject())
         .thenAccept(el -> {
            List<Badge> list = new ArrayList<>();
            if (el != null && el.isJsonArray()) {
               for (JsonElement e : el.getAsJsonArray()) {
                  if (!e.isJsonObject()) {
                     continue;
                  }
                  JsonObject o = e.getAsJsonObject();
                  list.add(new Badge(str(o, "badge_id", ""), str(o, "label", "?"),
                     o.has("colour") && !o.get("colour").isJsonNull()
                        ? o.get("colour").getAsInt() : 0xFF2FA5FF));
               }
            }
            this.myBadges = Collections.unmodifiableList(list);
         })
         .exceptionally(this::swallow);
   }

   public void loadProfile(String userId, Consumer<Profile> onReady) {
      JsonObject args = new JsonObject();
      args.addProperty("target", userId);
      this.api.rpc("get_profile", args)
         .thenAccept(el -> {
            if (el == null || !el.isJsonArray() || el.getAsJsonArray().isEmpty()) {
               onReady.accept(null);
               return;
            }
            JsonObject o = el.getAsJsonArray().get(0).getAsJsonObject();
            onReady.accept(new Profile(
               str(o, "id", ""), str(o, "username", "?"),
               str(o, "mc_name", null), str(o, "mc_uuid", null),
               bool(o, "mc_premium"), str(o, "about", null), str(o, "status", null),
               str(o, "badge_id", null), str(o, "badge_label", null),
               o.has("badge_colour") && !o.get("badge_colour").isJsonNull()
                  ? o.get("badge_colour").getAsInt() : 0xFF2FA5FF,
               num(o, "follower_count"), num(o, "following_count"),
               bool(o, "is_following"), bool(o, "is_friend"), bool(o, "is_buddy"),
               bool(o, "is_online"), str(o, "server_name", null),
               str(o, "skin_name", null), bool(o, "verified"), bool(o, "is_plus"),
               str(o, "name_color", null), str(o, "profile_color", null),
               num(o, "plus_since_epoch"), num(o, "joined_epoch"),
               num(o, "post_count"), bool(o, "is_staff")));
         })
         .exceptionally(e -> {
            onReady.accept(null);
            return report(e);
         });
   }

   public void equipBadge(String badgeId, Runnable onDone) {
      JsonObject row = new JsonObject();
      if (badgeId == null) {
         row.add("equipped_badge", com.google.gson.JsonNull.INSTANCE);
      } else {
         row.addProperty("equipped_badge", badgeId);
      }
      this.equippedBadge = badgeId;
      run(this.api.patch("profiles",
         "id=eq." + SupabaseClient.enc(this.api.userId()), row), onDone);
   }

   public void setAbout(String text, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("p_about", text);
      this.about = text;
      run(this.api.rpc("set_about", args), onDone);
   }

   public void setStatus(String text, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("p_status", text);
      this.status = text;
      run(this.api.rpc("set_status", args), onDone);
   }

   /**
    * Asks someone to be your buddy - or accepts, if they asked first.
    *
    * <p>v20 wrote {@code buddy_id} straight onto your own row, so you could
    * name anyone your buddy without them agreeing, and several people could
    * all claim the same person. v21 makes it a two-sided handshake with one
    * buddy per player, enforced in the database.</p>
    *
    * @param onResult receives null on success, otherwise a message to show
    */
   public void requestBuddy(String targetId, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("target", targetId);
      run(this.api.rpc("request_buddy", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         if (o != null && bool(o, "ok")) {
            boolean paired = bool(o, "paired");
            if (paired) {
               this.buddyId = targetId;
               notify("Buddy paired", 0xFF43D17A);
            } else {
               notify("Buddy request sent", 0xFF2FA5FF);
            }
            onResult.accept(null);
            loadOwnProfile();
         } else {
            onResult.accept(o != null ? str(o, "m", "Could not set buddy.")
                                      : "Could not set buddy.");
         }
      }), null);
   }

   /** Declines (or withdraws) a buddy request. */
   public void declineBuddy(String targetId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("target", targetId);
      run(this.api.rpc("decline_buddy", args), onDone);
   }

   /** Ends the pairing - on BOTH sides, never just yours. */
   public void clearBuddy(Runnable onDone) {
      run(this.api.rpc("clear_buddy", new JsonObject()).thenRun(() -> {
         this.buddyId = null;
         notify("Buddy cleared", 0xFF2FA5FF);
      }), onDone);
   }

   public void follow(String targetId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("target", targetId);
      run(this.api.rpc("follow_user", args), onDone);
   }

   public void unfollow(String targetId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("target", targetId);
      run(this.api.rpc("unfollow_user", args), onDone);
   }

   /** Mirrors the nametag badge switches to the server (show_badge is enforced there). */
   public void pushBadgeVisibility(boolean showMine, boolean seeOthers) {
      if (!this.api.loggedIn()) {
         return;
      }
      JsonObject row = new JsonObject();
      row.addProperty("show_badge", showMine);
      row.addProperty("see_others_badges", seeOthers);
      this.api.patch("settings", "id=eq." + SupabaseClient.enc(this.api.userId()), row)
         .exceptionally(this::swallow);
   }

   /* ====================================================================== */
   /*  Minecraft account linking                                             */
   /* ====================================================================== */

   /**
    * Links the Minecraft account the player is currently using.
    *
    * <p>Two very different paths:</p>
    * <ul>
    *   <li><b>Premium</b> - we send the Microsoft access token to the
    *       {@code verify-minecraft} Edge Function, which asks Mojang who the
    *       token really belongs to. The client cannot fake this.</li>
    *   <li><b>Cracked</b> - there is no token to check, so the database
    *       verifies the claim instead: an offline uuid is a pure function of
    *       the name. We first ask Mojang whether a premium account owns the
    *       name, and refuse if so.</li>
    * </ul>
    */
   public void linkMinecraft(Runnable onDone) {
      net.bluenetwork.client.account.Account acc = null;
      try {
         acc = BlueClient.getInstance().accountManager().activeAccount();
      } catch (Throwable ignored) {
         // fall through to the cracked path below
      }

      if (acc != null && acc.isMicrosoft() && acc.accessToken() != null) {
         JsonObject body = new JsonObject();
         body.addProperty("minecraft_token", acc.accessToken());
         run(this.api.edgeFunction("verify-minecraft", body).thenAccept(el -> {
            if (el != null && el.isJsonObject() && el.getAsJsonObject().has("username")) {
               this.mcName = el.getAsJsonObject().get("username").getAsString();
               this.mcVerified = true;
               notify("Minecraft account verified", 0xFF43D17A);
            }
         }), onDone);
         return;
      }

      // Cracked: use the name Minecraft is running as.
      String name;
      try {
         name = MinecraftClient.getInstance().getSession().getUsername();
      } catch (Throwable t) {
         this.lastError = "Could not read your Minecraft username.";
         if (onDone != null) {
            onDone.run();
         }
         return;
      }
      final String mcName = name;

      this.busy = true;
      MojangLookup.isPremium(mcName).whenComplete((premium, err) -> {
         if (err != null) {
            this.busy = false;
            this.lastError = "Could not reach Minecraft services. Try again.";
            if (onDone != null) {
               onDone.run();
            }
            return;
         }
         if (Boolean.TRUE.equals(premium)) {
            this.busy = false;
            this.lastError = "\"" + mcName + "\" belongs to a premium account. "
               + "Log into it in the account manager first.";
            if (onDone != null) {
               onDone.run();
            }
            return;
         }
         JsonObject args = new JsonObject();
         args.addProperty("p_name", mcName);
         args.addProperty("p_premium_taken", false);
         run(this.api.rpc("link_cracked_minecraft", args).thenAccept(x -> {
            this.mcName = mcName;
            this.mcVerified = false;
            notify("Minecraft name linked", 0xFF2FA5FF);
         }), onDone);
      });
   }

   public void unlinkMinecraft(Runnable onDone) {
      run(this.api.rpc("unlink_minecraft", new JsonObject()).thenAccept(x -> {
         this.mcName = null;
         this.mcVerified = false;
      }), onDone);
   }

   /* ====================================================================== */
   /*  Join a friend's server                                                */
   /* ====================================================================== */

   /** Asks the server for the address, then connects. Never blocks. */
   public void joinFriend(String friendId) {
      JsonObject args = new JsonObject();
      args.addProperty("target", friendId);
      this.api.rpc("get_join_address", args)
         .thenAccept(el -> {
            // v21: this RPC now returns {ok, a} or {ok:false, m} so the player
            // is told WHY a join failed (offline / not sharing / not on a
            // server) instead of getting one generic message for everything.
            JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
            if (o == null) {
               this.lastError = "They are not on a joinable server.";
               return;
            }
            if (!bool(o, "ok")) {
               this.lastError = str(o, "m", "They are not on a joinable server.");
               return;
            }
            String addr = str(o, "a", null);
            if (addr == null || addr.isBlank() || "Singleplayer".equals(addr)) {
               this.lastError = "They are not on a joinable server.";
               return;
            }
            ServerJoiner.connect(addr);
         })
         .exceptionally(this::report);
   }

   /* ====================================================================== */
   /*  Presence                                                              */
   /* ====================================================================== */

   private CompletableFuture<Void> sendHeartbeat(boolean online) {
      JsonObject args = new JsonObject();
      args.addProperty("online", online);
      args.addProperty("server", online ? currentServerName() : null);
      return this.api.rpc("heartbeat", args)
         .thenAccept(x -> {
         })
         .exceptionally(this::swallow);
   }

   /** The server the player is on, or null in menus / singleplayer. */
   private static String currentServerName() {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc == null || mc.world == null) {
            return null;
         }
         if (mc.isInSingleplayer()) {
            return "Singleplayer";
         }
         net.minecraft.client.network.ServerInfo info = mc.getCurrentServerEntry();
         return info == null ? null : info.address;
      } catch (Throwable t) {
         return null;
      }
   }

   /* ====================================================================== */
   /*  Helpers                                                               */
   /* ====================================================================== */

   /** Runs a future, tracking "busy" and turning failures into a message. */
   /* ====================================================================== */
   /*  v21 actions                                                           */
   /* ====================================================================== */

   /** A post on the public timeline. */
   /**
    * One post in a feed.
    *
    * @param skin     the Minecraft name to draw an avatar for; falls back to
    *                 the author's name when they have not set a skin
    * @param likes    like count, kept on the row so the UI can update it
    *                 optimistically without a refetch
    * @param liked    whether YOU have liked it, for the filled heart
    * @param reposted whether YOU have reposted it
    * @param boostedBy who reposted this into your feed, or null if it is an
    *                 original post
    */
   public record Post(String id, String author, String body, long at,
                      String badge, String color, boolean plus, boolean verified,
                      String skin, int likes, int replies, int reposts,
                      boolean liked, boolean reposted, String boostedBy) {

      /** The name to render an avatar for. */
      public String avatarName() {
         return this.skin != null && !this.skin.isBlank() ? this.skin : this.author;
      }
   }

   /** One row of the most-followed leaderboard. */
   public record LeaderRow(String username, long followers, String badge,
                           boolean verified, String color, boolean plus,
                           String skin, String id) {

      public String avatarName() {
         return this.skin != null && !this.skin.isBlank() ? this.skin : this.username;
      }
   }

   /** A search result. */
   public record SearchHit(String id, String username, boolean verified, boolean plus) {
   }

   private volatile List<Post> feed = List.of();
   private volatile List<LeaderRow> leaders = List.of();

   public List<Post> feed() {
      return this.feed;
   }

   public List<LeaderRow> leaders() {
      return this.leaders;
   }

   /**
    * Publishes a post.
    *
    * <p>The server truncates to the tier limit and enforces the hourly rate,
    * so this only has to relay the outcome. {@code onResult} receives a
    * message suitable for showing the player.</p>
    */
   public void createPost(String body, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_body", body);
      run(this.api.rpc("create_post", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         if (o != null && bool(o, "ok")) {
            onResult.accept(null);
            refreshFeed();
         } else {
            onResult.accept(o != null ? str(o, "m", "Could not post.") : "Could not post.");
         }
      }), null);
   }

   public void deletePost(String postId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("p_id", postId);
      run(this.api.rpc("delete_post", args).thenRun(this::refreshFeed), onDone);
   }

   /**
    * Which feed the Posts tab is showing.
    *
    * <p>FOLLOWING is strictly chronological; FOR_YOU is the ranked algorithm.
    * Kept here rather than in the screen so the choice survives closing the
    * menu.</p>
    */
   public enum FeedMode { FOR_YOU, FOLLOWING }

   private volatile FeedMode feedMode = FeedMode.FOR_YOU;

   public FeedMode feedMode() {
      return this.feedMode;
   }

   public void feedMode(FeedMode mode) {
      if (mode != null && mode != this.feedMode) {
         this.feedMode = mode;
         this.feed = List.of();
         refreshFeed();
      }
   }

   /** Likes or unlikes a post, then refreshes so the count is authoritative. */
   public void toggleLike(String postId, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("p_post", postId);
      run(this.api.rpc("toggle_like", args).thenAccept(el -> refreshFeed()), onDone);
   }

   /** Reposts or un-reposts. */
   public void toggleRepost(String postId, java.util.function.Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_post", postId);
      this.api.rpc("toggle_repost", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         if (onResult != null) {
            onResult.accept(ok ? null : (o != null ? str(o, "m", "Failed") : "Failed"));
         }
         if (ok) {
            refreshFeed();
         }
      }).exceptionally(this::swallow);
   }

   /** Posts a reply under {@code parentId}. */
   public void replyToPost(String parentId, String body,
                           java.util.function.Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_parent", parentId);
      args.addProperty("p_body", body);
      this.api.rpc("reply_to_post", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         if (onResult != null) {
            onResult.accept(ok ? null : (o != null ? str(o, "m", "Failed") : "Failed"));
         }
         if (ok) {
            refreshFeed();
            loadReplies(parentId);
         }
      }).exceptionally(this::swallow);
   }

   private volatile List<Post> replies = List.of();
   private volatile String repliesFor;

   public List<Post> replies() {
      return this.replies;
   }

   public String repliesFor() {
      return this.repliesFor;
   }

   /**
    * A player's own posts, sortable.
    *
    * @param sort "new", "old" or "top"
    */
   public void loadUserPosts(String userId, String sort,
                             java.util.function.Consumer<List<Post>> onReady) {
      if (!this.api.loggedIn() || userId == null) {
         onReady.accept(List.of());
         return;
      }
      JsonObject args = new JsonObject();
      args.addProperty("p_user", userId);
      args.addProperty("p_sort", sort == null ? "new" : sort);
      this.api.rpc("get_user_posts", args).thenAccept(el -> {
         List<Post> list = new ArrayList<>();
         if (el != null && el.isJsonArray()) {
            for (JsonElement e : el.getAsJsonArray()) {
               if (!e.isJsonObject()) {
                  continue;
               }
               JsonObject o = e.getAsJsonObject();
               list.add(new Post(
                  str(o, "i", ""), str(o, "u", "?"), str(o, "b", ""),
                  num(o, "t"), str(o, "bd", null), str(o, "c", null),
                  bool(o, "pl"), bool(o, "v"), str(o, "sk", null),
                  (int) num(o, "lk"), (int) num(o, "rc"), (int) num(o, "rp"),
                  bool(o, "il"), bool(o, "ir"), null));
            }
         }
         onReady.accept(Collections.unmodifiableList(list));
      }).exceptionally(e -> {
         onReady.accept(List.of());
         return swallow(e);
      });
   }

   /** Pins a post to everyone's Home. Blue and Cyan only; server re-checks. */
   public void pinPost(String postId, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_post", postId);
      run(this.api.rpc("pin_post", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         onResult.accept(ok ? null
            : (o != null ? str(o, "m", "Could not pin.") : "Could not pin."));
         if (ok) {
            refreshNow();
         }
      }).exceptionally(e -> {
         onResult.accept(rootMessage(e));
         return null;
      }), null);
   }

   /** Removes the pinned post. */
   public void unpinPost(Consumer<String> onResult) {
      run(this.api.rpc("unpin_post", new JsonObject()).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         onResult.accept(ok ? null
            : (o != null ? str(o, "m", "Could not unpin.") : "Could not unpin."));
         if (ok) {
            refreshNow();
         }
      }).exceptionally(e -> {
         onResult.accept(rootMessage(e));
         return null;
      }), null);
   }

   /**
    * Every badge a player owns, for the profile page badge row.
    *
    * <p>Separate from {@code get_profile} on purpose: a profile is opened far
    * more often than its badge row changes, and this keeps the main profile
    * payload small.</p>
    */
   public void loadProfileBadges(String userId,
                                 java.util.function.Consumer<List<Badge>> onReady) {
      if (!this.api.loggedIn() || userId == null) {
         onReady.accept(List.of());
         return;
      }
      JsonObject args = new JsonObject();
      args.addProperty("target", userId);
      this.api.rpc("profile_badges", args).thenAccept(el -> {
         List<Badge> list = new ArrayList<>();
         if (el != null && el.isJsonArray()) {
            for (JsonElement e : el.getAsJsonArray()) {
               if (!e.isJsonObject()) {
                  continue;
               }
               JsonObject o = e.getAsJsonObject();
               list.add(new Badge(str(o, "id", ""), str(o, "l", "?"),
                  o.has("c") && !o.get("c").isJsonNull()
                     ? o.get("c").getAsInt() : 0xFF2FA5FF,
                  str(o, "d", null)));
            }
         }
         onReady.accept(Collections.unmodifiableList(list));
      }).exceptionally(e -> {
         onReady.accept(List.of());
         return swallow(e);
      });
   }

   /** Reports a post to staff. */
   public void reportPost(String postId, String reason, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_post", postId);
      args.addProperty("p_reason", reason);
      run(this.api.rpc("report_post", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         onResult.accept(ok ? null
            : (o != null ? str(o, "m", "Could not report.") : "Could not report."));
      }).exceptionally(e -> {
         onResult.accept(rootMessage(e));
         return null;
      }), null);
   }

   /** Loads the admin overview. Returns null for non-staff. */
   public void adminOverview(java.util.function.Consumer<JsonObject> onReady) {
      this.api.rpc("admin_overview", new JsonObject()).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         onReady.accept(o != null && bool(o, "ok") ? o : null);
      }).exceptionally(e -> {
         onReady.accept(null);
         return swallow(e);
      });
   }

   /**
    * True when the backend is missing functions this build needs.
    *
    * <p>Set when an RPC comes back "not found". Postgres reports a missing
    * function as a 404 from PostgREST, which is indistinguishable from a
    * network hiccup unless we look for it - and the old behaviour was to
    * swallow it, so an un-applied schema looked exactly like a broken client.
    * The owner lost real time to that twice.</p>
    */
   private volatile boolean schemaOutdated;

   public boolean schemaOutdated() {
      return this.schemaOutdated;
   }

   /** Notices a "function does not exist" error and latches the flag. */
   private void noteSchema(Throwable e) {
      String m = rootMessage(e);
      if (m == null) {
         return;
      }
      String low = m.toLowerCase(java.util.Locale.ROOT);
      if (low.contains("could not find the function")
         || low.contains("does not exist")
         || low.contains("schema cache")
         || low.contains("pgrst202")) {
         this.schemaOutdated = true;
      }
   }

   /** Staff read: an admin RPC that returns data rather than a status. */
   public void adminAction2(String rpc, JsonObject args,
                            java.util.function.Consumer<JsonObject> onReady) {
      this.api.rpc(rpc, args == null ? new JsonObject() : args)
         .thenAccept(el -> {
            JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
            onReady.accept(o != null && bool(o, "ok") ? o : null);
         }).exceptionally(e -> {
            onReady.accept(null);
            return swallow(e);
         });
   }

   /** Staff action: one entry point for every admin RPC. */
   public void adminAction(String rpc, JsonObject args, Consumer<String> onResult) {
      run(this.api.rpc(rpc, args == null ? new JsonObject() : args)
         .thenAccept(el -> {
            JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
            boolean ok = o != null && bool(o, "ok");
            onResult.accept(ok ? null
               : (o != null ? str(o, "m", "Failed.") : "Failed."));
         }).exceptionally(e -> {
            onResult.accept(rootMessage(e));
            return null;
         }), null);
   }

   /**
    * Permanently deletes this account.
    *
    * <p>{@code confirm} must equal the username exactly - the server checks
    * it too, so a client bug cannot destroy an account by accident.</p>
    */
   public void deleteAccount(String confirm, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_confirm", confirm);
      run(this.api.rpc("delete_my_account", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         onResult.accept(ok ? null
            : (o != null ? str(o, "m", "Could not delete.") : "Could not delete."));
         if (ok) {
            logOut(null);
         }
      }).exceptionally(e -> {
         onResult.accept(rootMessage(e));
         return null;
      }), null);
   }

   /** Resolves a username to its profile id, for opening a profile by name. */
   public void profileIdByName(String name,
                               java.util.function.Consumer<String> onReady) {
      JsonObject args = new JsonObject();
      args.addProperty("p_name", name);
      this.api.rpc("profile_id_by_name", args).thenAccept(el -> {
         String id = el != null && el.isJsonPrimitive() ? el.getAsString() : null;
         onReady.accept(id == null || id.isBlank() || "null".equals(id) ? null : id);
      }).exceptionally(e -> {
         onReady.accept(null);
         return swallow(e);
      });
   }

   /**
    * "3 months" / "18 days" since an epoch-seconds timestamp.
    *
    * <p>Used by the Blue+ badge tooltip, which the owner wants to read
    * "Since: &lt;amount of days/months&gt;".</p>
    */
   public static String sinceDuration(long epochSeconds) {
      if (epochSeconds <= 0L) {
         return "a while";
      }
      long days = Math.max(0L,
         (System.currentTimeMillis() / 1000L - epochSeconds) / 86400L);
      if (days < 1L) {
         return "today";
      }
      if (days < 31L) {
         return days + (days == 1L ? " day" : " days");
      }
      long months = days / 30L;
      if (months < 12L) {
         return months + (months == 1L ? " month" : " months");
      }
      long years = days / 365L;
      long rem = (days % 365L) / 30L;
      String out = years + (years == 1L ? " year" : " years");
      return rem > 0L ? out + ", " + rem + (rem == 1L ? " month" : " months") : out;
   }

   /** Loads the reply thread under one post. */
   public void loadReplies(String postId) {
      if (!this.api.loggedIn() || postId == null) {
         return;
      }
      this.repliesFor = postId;
      JsonObject args = new JsonObject();
      args.addProperty("p_post", postId);
      this.api.rpc("get_replies", args).thenAccept(el -> {
         if (el == null || !el.isJsonArray()) {
            return;
         }
         List<Post> list = new ArrayList<>();
         for (JsonElement e : el.getAsJsonArray()) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject o = e.getAsJsonObject();
            SkinIndex.put(str(o, "u", null), str(o, "sk", null));
            list.add(new Post(
               str(o, "i", ""), str(o, "u", "?"), str(o, "b", ""),
               num(o, "t"), str(o, "bd", null), str(o, "c", null),
               bool(o, "pl"), bool(o, "v"), str(o, "sk", null),
               (int) num(o, "lk"), 0, 0, bool(o, "il"), false, null));
         }
         this.replies = Collections.unmodifiableList(list);
      }).exceptionally(this::swallow);
   }

   /** Loads the timeline. Cheap - capped at 30 rows with short keys. */
   public void refreshFeed() {
      if (!this.api.loggedIn()) {
         return;
      }
      String fn = this.feedMode == FeedMode.FOR_YOU ? "get_for_you" : "get_feed";
      this.api.rpc(fn, new JsonObject()).thenAccept(el -> {
         if (el == null || !el.isJsonArray()) {
            return;
         }
         List<Post> list = new ArrayList<>();
         for (JsonElement e : el.getAsJsonArray()) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject o = e.getAsJsonObject();
            SkinIndex.put(str(o, "u", null), str(o, "sk", null));
            list.add(new Post(
               str(o, "i", ""), str(o, "u", "?"), str(o, "b", ""),
               num(o, "t"), str(o, "bd", null), str(o, "c", null),
               bool(o, "pl"), bool(o, "v"),
               str(o, "sk", null), (int) num(o, "lk"), (int) num(o, "rc"),
               (int) num(o, "rp"), bool(o, "il"), bool(o, "ir"),
               str(o, "rb", null)));
         }
         this.feed = Collections.unmodifiableList(list);
      }).exceptionally(this::swallow);
   }

   /** Loads the top-5 most-followed players. */
   public void refreshLeaderboard() {
      if (!this.api.loggedIn()) {
         return;
      }
      JsonObject args = new JsonObject();
      args.addProperty("limit_n", 5);
      this.api.rpc("leaderboard", args).thenAccept(el -> {
         if (el == null || !el.isJsonArray()) {
            return;
         }
         List<LeaderRow> list = new ArrayList<>();
         for (JsonElement e : el.getAsJsonArray()) {
            if (!e.isJsonObject()) {
               continue;
            }
            JsonObject o = e.getAsJsonObject();
            SkinIndex.put(str(o, "u", null), str(o, "sk", null));
            list.add(new LeaderRow(
               str(o, "u", "?"), num(o, "f"), str(o, "bd", null),
               bool(o, "v"), str(o, "c", null), bool(o, "pl"),
               str(o, "sk", null), str(o, "i", null)));
         }
         this.leaders = Collections.unmodifiableList(list);
      }).exceptionally(this::swallow);
   }

   /** Sets online / dnd / offline. */
   public void setPresence(String mode, Runnable onDone) {
      JsonObject args = new JsonObject();
      args.addProperty("p_mode", mode);
      run(this.api.rpc("set_presence", args).thenRun(() -> {
         this.presence = mode;
      }), onDone);
   }

   /** Redeems a code. {@code onResult} gets the server's message either way. */
   public void redeem(String code, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_code", code);
      run(this.api.rpc("redeem", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         onResult.accept(o != null ? str(o, "m", ok ? "Redeemed." : "Invalid code.")
                                   : "Invalid code.");
         if (ok) {
            // Blue+ may have just switched on - resync so the UI unlocks.
            refreshNow();
            loadOwnProfile();
         }
      }), null);
   }

   /** The profile background colour JSON, or null. */
   public String profileColor() {
      return this.profileColor;
   }

   /** The post Blue or Cyan pinned to everyone's Home, or null. */
   public Post pinnedPost() {
      return this.pinned;
   }

   /**
    * True when this account may use staff powers.
    *
    * <p>Authoritative source is the {@code st} flag from {@code sync()}, which
    * the server computes from the {@code staff_accounts} table. Every admin
    * RPC re-checks {@code is_staff()} server-side regardless, so this only
    * decides whether the button is DRAWN - it grants nothing.</p>
    */
   public boolean staff() {
      return this.staff;
   }

   /**
    * Asks the server directly whether we are staff.
    *
    * <p>Used as a fallback when sync() is the pre-v3 version and never sends
    * the flag: without this the Admin button could not appear at all on an
    * older backend, which is exactly what the owner hit.</p>
    */
   public void refreshStaffFlag() {
      if (!this.api.loggedIn()) {
         return;
      }
      this.api.rpc("is_staff", new JsonObject()).thenAccept(el -> {
         if (el != null && el.isJsonPrimitive()) {
            try {
               this.staff = el.getAsBoolean();
            } catch (Throwable ignored) {
               // Not a boolean: leave the flag alone.
            }
         }
      }).exceptionally(this::swallow);
   }

   /**
    * Sets the profile background colour (Blue+ only; the server re-checks).
    *
    * <p>Same storage shape as the name colour, so one validator and one
    * renderer serve both.</p>
    */
   public void setProfileColor(String json, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_json", json);
      run(this.api.rpc("set_profile_color", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         if (ok) {
            this.profileColor = json == null || json.isBlank() ? null : json;
         }
         onResult.accept(ok ? null
            : (o != null ? str(o, "m", "Could not set colour.") : "Could not set colour."));
      }).exceptionally(e -> {
         onResult.accept(rootMessage(e));
         return null;
      }), null);
   }

   /** Sets the coloured-name JSON (Blue+ only; the server re-checks). */
   public void setNameColor(String json, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_json", json);
      run(this.api.rpc("set_name_color", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         if (o != null && bool(o, "ok")) {
            this.nameColor = json;
            onResult.accept(null);
         } else {
            onResult.accept(o != null ? str(o, "m", "Could not set colour.")
                                      : "Could not set colour.");
         }
      }).exceptionally(e -> {
         // thenAccept only fires on success; without this a failed call is
         // completely silent to the player.
         onResult.accept(rootMessage(e));
         return null;
      }), null);
   }

   /** Sets the Minecraft username used for the social avatar. */
   public void setSkinName(String name, Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("p_name", name);
      run(this.api.rpc("set_skin_name", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         boolean ok = o != null && bool(o, "ok");
         if (ok) {
            // Keep the local copy in step, or the UI keeps showing the old
            // name until the next full sync.
            this.skinName = name == null || name.isBlank() ? null : name.trim();
            SkinIndex.put(this.username, this.skinName);
            net.bluenetwork.client.account.PlayerHeads.forget(this.skinName);
         }
         onResult.accept(ok ? null
            : (o != null ? str(o, "m", "Could not set skin.") : "Could not set skin."));
      }).exceptionally(e -> {
         // THE BUG: thenAccept only runs on SUCCESS. When the RPC throws -
         // which it does when set_skin_name is missing because schema_v3 was
         // never applied - the callback never fired at all, so the notice
         // stayed null and pressing APPLY SKIN appeared to do nothing
         // whatsoever. Silence is the worst possible failure mode; always
         // report.
         onResult.accept(rootMessage(e));
         return null;
      }), null);
   }

   /**
    * Unwraps a CompletionException down to the message worth showing.
    *
    * <p>Async failures arrive wrapped, so {@code e.getMessage()} is usually
    * "java.util.concurrent.CompletionException: ..." which tells the player
    * nothing.</p>
    */
   static String rootMessage(Throwable e) {
      Throwable t = e;
      while (t.getCause() != null && t != t.getCause()) {
         t = t.getCause();
      }
      String m = t.getMessage();
      return m == null || m.isBlank() ? "Request failed." : m;
   }

   /**
    * Invites a friend to wherever we currently are, working out the address
    * automatically.
    *
    * <p>On a multiplayer server that is just the server address. In a
    * singleplayer world it means opening the world to LAN and asking the
    * router to forward the port via UPnP, which can fail - in which case the
    * friend is told why rather than being sent a dead address.</p>
    */
   public void inviteHere(String friendId, Consumer<String> onResult) {
      MinecraftClient mc = MinecraftClient.getInstance();

      // Multiplayer: just pass on the address we are connected to.
      if (!mc.isInSingleplayer()) {
         var entry = mc.getCurrentServerEntry();
         if (entry == null || entry.address == null || entry.address.isBlank()) {
            onResult.accept("Could not work out where you are.");
            return;
         }
         sendInvite(friendId, entry.address,
            entry.name == null ? entry.address : entry.name, onResult);
         return;
      }

      // Singleplayer: open to LAN + UPnP first.
      LanInvites.prepare(outcome -> {
         if (!outcome.ok()) {
            onResult.accept(outcome.message());
            return;
         }
         String label = mc.getServer() != null
            ? mc.getServer().getSaveProperties().getLevelName()
            : "My world";
         sendInvite(friendId, outcome.address(), label, onResult);
      });
   }

   /** Invites a friend to a specific address. */
   public void sendInvite(String friendId, String address, String label,
                          Consumer<String> onResult) {
      JsonObject args = new JsonObject();
      args.addProperty("target", friendId);
      args.addProperty("p_addr", address);
      args.addProperty("p_label", label);
      run(this.api.rpc("send_invite", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         onResult.accept(o != null && bool(o, "ok") ? null
            : (o != null ? str(o, "m", "Could not invite.") : "Could not invite."));
      }), null);
   }

   /** Accepts an invite and connects to the address it carries. */
   public void acceptInvite(String inviteId) {
      JsonObject args = new JsonObject();
      args.addProperty("p_id", inviteId);
      run(this.api.rpc("accept_invite", args).thenAccept(el -> {
         JsonObject o = el != null && el.isJsonObject() ? el.getAsJsonObject() : null;
         if (o != null && bool(o, "ok")) {
            String addr = str(o, "a", null);
            if (addr != null) {
               ServerJoiner.connect(addr);
            }
         } else {
            notify(o != null ? str(o, "m", "Invite expired") : "Invite expired", 0xFFE35D5D);
         }
      }), null);
   }

   /** Verifies Minecraft ownership with no Azure app - see PremiumVerifier. */
   public void verifyPremium(String mcName, Consumer<String> onResult) {
      this.busy = true;
      PremiumVerifier.verify(this.api, mcName, res -> {
         this.busy = false;
         onResult.accept(res.ok() ? null : res.message());
         if (res.ok()) {
            refreshProfileBits();
         }
      });
   }

   private void run(CompletableFuture<?> f, Runnable onDone) {
      this.busy = true;
      this.lastError = null;
      f.whenComplete((ok, err) -> {
         this.busy = false;
         if (err != null) {
            report(err);
         }
         if (onDone != null) {
            onDone.run();
         }
      });
   }

   /** Records a failure for the UI to display. Always returns null. */
   private <T> T report(Throwable e) {
      noteSchema(e);
      Throwable c = e instanceof java.util.concurrent.CompletionException && e.getCause() != null
         ? e.getCause() : e;
      String msg = c.getMessage();
      this.lastError = msg == null || msg.isBlank()
         ? "Friends services are currently unavailable." : msg;
      BlueClient.LOGGER.debug("[Social] {}", this.lastError);
      return null;
   }

   /** For background work whose failure the player does not need to see. */
   private <T> T swallow(Throwable e) {
      noteSchema(e);
      BlueClient.LOGGER.debug("[Social] background call failed", e);
      return null;
   }

   /** Public wrapper so screens can raise a toast through the same path. */
   public void notifyUser(String text, int accent) {
      notify(text, accent);
   }

   private void notify(String text, int accent) {
      try {
         BlueClient c = BlueClient.getInstance();
         if (c != null && c.notificationManager() != null) {
            c.notificationManager().add(text, accent);
         }
      } catch (Throwable ignored) {
         // A notification must never break a network callback.
      }
   }

   private static boolean bool(JsonObject o, String key) {
      return o.has(key) && !o.get(key).isJsonNull() && o.get(key).getAsBoolean();
   }

   private static long num(JsonObject o, String key) {
      return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsLong() : 0L;
   }

   private static String str(JsonObject o, String key, String fallback) {
      return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : fallback;
   }

   /** Reads {"sender":{"username":"X"}} style embedded rows. */
   private static String nested(JsonObject o, String key) {
      if (o.has(key) && o.get(key).isJsonObject()) {
         return str(o.getAsJsonObject(key), "username", "?");
      }
      if (o.has(key) && o.get(key).isJsonArray()) {
         JsonArray a = o.getAsJsonArray(key);
         if (!a.isEmpty() && a.get(0).isJsonObject()) {
            return str(a.get(0).getAsJsonObject(), "username", "?");
         }
      }
      return "?";
   }

   private void saveSession() {
      try {
         String token = this.api.refreshTokenForStorage();
         if (token == null) {
            return;
         }
         Files.createDirectories(this.sessionFile.getParent());
         Files.writeString(this.sessionFile, token, StandardCharsets.UTF_8);
      } catch (Exception e) {
         BlueClient.LOGGER.debug("[Social] could not save session", e);
      }
   }

   private void deleteSession() {
      try {
         Files.deleteIfExists(this.sessionFile);
      } catch (Exception ignored) {
         // Nothing useful to do; a stale token just fails to resume.
      }
   }

   /** Human-friendly "2 hours ago" from an ISO timestamp. */
   public static String relativeTime(String iso) {
      if (iso == null || iso.isBlank()) {
         return "Hidden";
      }
      try {
         java.time.Instant then = java.time.OffsetDateTime.parse(
            iso.length() > 10 && !iso.endsWith("Z") && !iso.contains("+")
               ? iso + "Z" : iso).toInstant();
         long secs = java.time.Duration.between(then, java.time.Instant.now()).getSeconds();
         if (secs < 60L) {
            return "Just now";
         }
         if (secs < 3600L) {
            long m = secs / 60L;
            return m + (m == 1L ? " min ago" : " mins ago");
         }
         if (secs < 86400L) {
            long h = secs / 3600L;
            return h + (h == 1L ? " hour ago" : " hours ago");
         }
         long d = secs / 86400L;
         return d + (d == 1L ? " day ago" : " days ago");
      } catch (Exception e) {
         return "Unknown";
      }
   }
}
