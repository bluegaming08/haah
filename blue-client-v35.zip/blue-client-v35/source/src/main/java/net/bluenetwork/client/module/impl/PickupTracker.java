package net.bluenetwork.client.module.impl;

import java.util.HashMap;
import java.util.Map;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

/**
 * Pickup Tracker (v3 catalogue E7) — toast when items are picked up. Snapshots
 * your inventory a few times a second and reports any item id whose count
 * increased (name + amount). Cheap enough for tick sampling; no hooks.
 */
public class PickupTracker extends Module {
   private final BooleanSetting sound = new BooleanSetting("Sound", "Play a soft pickup tick", true);
   private final BooleanSetting stacks = new BooleanSetting("Include stacks", "Also toast stack-size increases (e.g. cobble piles)", true);

   private Map<String, SlotCount> previous = Map.of();
   private long nextCheck = 0L;

   public PickupTracker() {
      super("Pickup Tracker", "Toast when you pick items up", Category.MISC);
      this.addSettings(new Setting[]{this.sound, this.stacks});
   }

   @Override
   protected void onDisable() {
      this.previous = Map.of();
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity p = mc.player;
      if (p == null || mc.currentScreen != null) {
         return;
      }
      long now = System.currentTimeMillis();
      if (now < this.nextCheck) {
         return;
      }
      this.nextCheck = now + 400L;

      Map<String, SlotCount> current = this.snapshot(p);
      Map<String, SlotCount> prev = this.previous;
      this.previous = current;
      if (prev.isEmpty()) {
         return;
      }

      int shown = 0;
      StringBuilder toast = new StringBuilder();
      for (Map.Entry<String, SlotCount> entry : current.entrySet()) {
         if (shown >= 3) {
            break;
         }
         SlotCount before = prev.get(entry.getKey());
         int gained = before == null ? entry.getValue().count : entry.getValue().count - before.count;
         if (gained > 0) {
            if (toast.length() > 0) {
               toast.append("  ");
            }
            toast.append('+').append(gained).append(' ').append(entry.getValue().name);
            shown++;
         }
      }
      if (shown > 0) {
         if (this.sound.get()) {
            Sounds.pickup();
         }
         try {
            BlueClient.getInstance().notificationManager().add(toast.toString(), 0xFF7CFF9B);
         } catch (Throwable ignored) {
         }
      }
   }

   private Map<String, SlotCount> snapshot(ClientPlayerEntity p) {
      Map<String, SlotCount> map = new HashMap<>();
      int skipIfBelow = this.stacks.get() ? 1 : 2;
      for (ItemStack stack : p.getInventory().getMainStacks()) {
         this.add(map, stack, skipIfBelow);
      }
      this.add(map, p.getOffHandStack(), skipIfBelow);
      return map;
   }

   private void add(Map<String, SlotCount> map, ItemStack stack, int skipIfBelow) {
      if (stack == null || stack.isEmpty()) {
         return;
      }
      int count = stack.getCount();
      if (count < skipIfBelow) {
         return;
      }
      String id = stack.getItem().getRegistryEntry().getIdAsString();
      SlotCount slot = map.get(id);
      if (slot == null) {
         map.put(id, new SlotCount(stack.getName().getString(), count));
      } else {
         map.put(id, new SlotCount(slot.name, slot.count + count));
      }
   }

   private record SlotCount(String name, int count) {
   }
}
