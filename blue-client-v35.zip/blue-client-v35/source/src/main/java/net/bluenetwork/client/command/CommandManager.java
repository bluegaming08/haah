package net.bluenetwork.client.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.gui.AccountsScreen;
import net.bluenetwork.client.module.Module;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public class CommandManager {
   private final BlueClient client;

   public CommandManager(BlueClient client) {
      this.client = client;
   }

   public void init() {
      ClientCommandRegistrationCallback.EVENT.register(
         (dispatcher, registryAccess) -> dispatcher.register(
            ClientCommandManager.literal("waypoint")
               .then(ClientCommandManager.argument("name", StringArgumentType.word())
                  .then(ClientCommandManager.literal("add").executes(context -> {
                     var mc = MinecraftClient.getInstance();
                     if (mc.player == null || mc.world == null) {
                        return 0;
                     }
                     String name = StringArgumentType.getString(context, "name");
                     var pos = mc.player.getBlockPos();
                     String dim = mc.world.getRegistryKey().getValue().toString();
                     net.bluenetwork.client.util.WaypointStore.add(
                        new net.bluenetwork.client.util.WaypointStore.Waypoint(name, pos.getX(), pos.getY(), pos.getZ(), dim));
                     ((FabricClientCommandSource)context.getSource()).sendFeedback(
                        Text.literal("Waypoint '" + name + "' set at " + pos.getX() + " " + pos.getY() + " " + pos.getZ()));
                     return 1;
                  }))
                  .then(ClientCommandManager.literal("remove").executes(context -> {
                     String name = StringArgumentType.getString(context, "name");
                     boolean ok = net.bluenetwork.client.util.WaypointStore.remove(name);
                     ((FabricClientCommandSource)context.getSource()).sendFeedback(
                        Text.literal(ok ? "Waypoint '" + name + "' removed" : "No waypoint named '" + name + "'"));
                     return ok ? 1 : 0;
                  }))
                  .executes(context -> {
                     var mc = MinecraftClient.getInstance();
                     if (mc.player == null || mc.world == null) {
                        return 0;
                     }
                     String name = StringArgumentType.getString(context, "name");
                     var pos = mc.player.getBlockPos();
                     String dim = mc.world.getRegistryKey().getValue().toString();
                     net.bluenetwork.client.util.WaypointStore.add(
                        new net.bluenetwork.client.util.WaypointStore.Waypoint(name, pos.getX(), pos.getY(), pos.getZ(), dim));
                     ((FabricClientCommandSource)context.getSource()).sendFeedback(
                        Text.literal("Waypoint '" + name + "' set at " + pos.getX() + " " + pos.getY() + " " + pos.getZ()));
                     return 1;
                  }))
               .then(ClientCommandManager.literal("list").executes(context -> {
                  var all = net.bluenetwork.client.util.WaypointStore.all();
                  if (all.isEmpty()) {
                     ((FabricClientCommandSource)context.getSource()).sendFeedback(Text.literal("No waypoints yet - /waypoint add <name>"));
                  } else {
                     for (var w : all) {
                        ((FabricClientCommandSource)context.getSource()).sendFeedback(
                           Text.literal(w.name() + " - " + w.x() + " " + w.y() + " " + w.z() + " (" + w.dimension() + ")"));
                     }
                  }
                  return 1;
               }))
               .then(ClientCommandManager.literal("clear").executes(context -> {
                  var all = new java.util.ArrayList<>(net.bluenetwork.client.util.WaypointStore.all());
                  for (var w : all) {
                     net.bluenetwork.client.util.WaypointStore.remove(w.name());
                  }
                  ((FabricClientCommandSource)context.getSource()).sendFeedback(Text.literal("All waypoints cleared"));
                  return 1;
               }))
         )
      );

      ClientCommandRegistrationCallback.EVENT
         .register(
            (ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> dispatcher.register(
               (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal(
                                    "blueclient"
                                 )
                                 .executes(
                                    context -> {
                                       ((FabricClientCommandSource)context.getSource())
                                          .sendFeedback(
                                             Text.literal(
                                                "Blue Client " + BlueClient.displayVersion() + " - /blueclient list | toggle <module> | gui | accounts | save"
                                             )
                                          );
                                       return 1;
                                    }
                                 ))
                              .then(ClientCommandManager.literal("list").executes(context -> {
                                 StringBuilder builder = new StringBuilder("Modules (" + this.client.moduleManager().getModules().size() + "): ");
                                 boolean first = true;

                                 for (Module module : this.client.moduleManager().getModules()) {
                                    if (!first) {
                                       builder.append(", ");
                                    }

                                    first = false;
                                    builder.append(module.getName()).append(module.isEnabled() ? " [on]" : " [off]");
                                 }

                                 ((FabricClientCommandSource)context.getSource()).sendFeedback(Text.literal(builder.toString()));
                                 return 1;
                              })))
                           .then(
                              ClientCommandManager.literal("toggle")
                                 .then(
                                    ClientCommandManager.argument("module", StringArgumentType.word())
                                       .executes(
                                          context -> {
                                             String name = StringArgumentType.getString(context, "module");
                                             Module module = this.client.moduleManager().byName(name);
                                             if (module == null) {
                                                ((FabricClientCommandSource)context.getSource())
                                                   .sendError(Text.literal("Unknown module: " + name + " (try /blueclient list)"));
                                                return 0;
                                             } else {
                                                module.toggle();
                                                ((FabricClientCommandSource)context.getSource())
                                                   .sendFeedback(Text.literal(module.getName() + " → " + (module.isEnabled() ? "on" : "off")));
                                                return 1;
                                             }
                                          }
                                       )
                                 )
                           ))
                        .then(ClientCommandManager.literal("gui").executes(context -> {
                           MinecraftClient.getInstance().setScreen(new net.bluenetwork.client.ui.screen.ModuleMenuScreen(this.client));
                           return 1;
                        })))
                     .then(ClientCommandManager.literal("accounts").executes(context -> {
                        MinecraftClient.getInstance().setScreen(new AccountsScreen(null));
                        return 1;
                     })))
                  .then(ClientCommandManager.literal("save").executes(context -> {
                     this.client.configManager().save();
                     ((FabricClientCommandSource)context.getSource()).sendFeedback(Text.literal("Config saved."));
                     return 1;
                  }))
            )
         );
   }
}
