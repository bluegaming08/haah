package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * The Blue+ subscriber settings, and the single source of truth for whether
 * Blue+ cosmetics are switched on.
 *
 * <h2>Why this module exists</h2>
 * Owner: "when a person becomes a Blue+ user, he should unlock a new category
 * for Blue+ settings." {@link Category#BLUE_PLUS} is hidden for free users, so
 * without a module in it the category would be empty for everyone. This is
 * that module.
 *
 * <h2>Entitlement is never trusted from here</h2>
 * Every accessor re-checks {@code friends().plus()}, which reflects what the
 * SERVER last said. Flipping a setting in this file cannot grant a perk: the
 * database decides who is a subscriber, and the colour/badge data simply is not
 * sent to clients who are not. These toggles only decide whether a subscriber
 * <i>wants</i> a perk displayed.
 */
public class BluePlusPerks extends Module {

   private final BooleanSetting plusLogo = new BooleanSetting(
      "Blue+ Logo",
      "Use the Blue+ mark instead of the normal logo everywhere", true);

   private final BooleanSetting colouredName = new BooleanSetting(
      "Coloured Name",
      "Show your custom name colour to other players", true);

   private final BooleanSetting plusBadge = new BooleanSetting(
      "Blue+ Badge",
      "Show the Blue+ mark next to your name", true);

   private final BooleanSetting sinceBadge = new BooleanSetting(
      "Supporter Duration",
      "Show how long you have been a Blue+ user on your profile", true);

   public BluePlusPerks() {
      super("Blue Plus", "Your Blue+ subscriber perks", Category.BLUE_PLUS);
      this.addSettings(new Setting[]{
         this.plusLogo, this.colouredName, this.plusBadge, this.sinceBadge});
      // On by default: a subscriber who just paid should see their perks
      // immediately rather than hunting for a switch.
      this.setEnabled(true);
   }

   /* ---- static accessors, used by the renderers ---- */

   /** True when the player actually has Blue+ right now. */
   public static boolean subscribed() {
      try {
         return BlueClient.getInstance().friends().plus();
      } catch (Throwable t) {
         return false;
      }
   }

   private static BluePlusPerks self() {
      try {
         Module m = BlueClient.getInstance().moduleManager().byName("Blue Plus");
         return m instanceof BluePlusPerks p && p.isEnabled() ? p : null;
      } catch (Throwable t) {
         return null;
      }
   }

   /**
    * Whether the Blue+ mark should replace the normal Blue logo.
    *
    * <p>Owner: "Blue+ users' main menu logo should also be that, and
    * everywhere that the blue logo is, it should be the plus logo."</p>
    */
   public static boolean useplusLogo() {
      BluePlusPerks p = self();
      return subscribed() && p != null && p.plusLogo.get();
   }

   public static boolean showColouredName() {
      BluePlusPerks p = self();
      return subscribed() && p != null && p.colouredName.get();
   }

   public static boolean showPlusBadge() {
      BluePlusPerks p = self();
      return subscribed() && p != null && p.plusBadge.get();
   }

   public static boolean showSince() {
      BluePlusPerks p = self();
      return subscribed() && p != null && p.sinceBadge.get();
   }
}
