package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;

/**
 * Chunk Position (bonus HUD) — the chunk coordinates (X/Z) and section your
 * player is standing in, handy for slime chunks and building boundaries.
 */
public class ChunkPosition extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);

   public ChunkPosition() {
      super("Chunk Position", "Current chunk X/Z and section", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 180);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return "Chunk --";
      }
      BlockPos pos = mc.player.getBlockPos();
      int cx = pos.getX() >> 4;
      int cz = pos.getZ() >> 4;
      int section = pos.getY() >> 4;
      return "Chunk " + cx + ", " + cz + " (s" + section + ")";
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Chunk 9999, 9999 (s999)") + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
