package net.bluenetwork.client.module.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.ModuleActions;
import net.bluenetwork.client.music.Id3Tags;
import net.bluenetwork.client.music.LyricsProvider;
import net.bluenetwork.client.music.MusicEngine;
import net.bluenetwork.client.music.TrackResolver;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.setting.StringSetting;
import net.bluenetwork.client.ui.text.TextPainter;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Music Player v3 (feedback 2026-09-11: "the music player module isn't
 * working, make it support youtube, Spotify and other website links").
 *
 * <p>What's new over v2:</p>
 * <ul>
 *   <li><b>YouTube</b> links (watch / youtu.be / shorts / music) are resolved
 *       to a playable AAC stream through public Piped / Invidious instances
 *       and decoded in-client (bundled pure-Java AAC decoder).</li>
 *   <li><b>Spotify</b> links pull the track name & artist from Spotify's
 *       public oEmbed and play the matching upload (Spotify audio itself is
 *       DRM-locked, so no client can stream it directly).</li>
 *   <li><b>Any other website link</b> plays when it points at an audio file
 *       (mp3 / ogg / wav / m4a / aac), sniffed by extension or Content-Type.</li>
 *   <li><b>Track info HUD</b> (on by default): track name plus elapsed and
 *       total time with a progress bar.</li>
 *   <li><b>Lyrics HUD</b> with three effects: FADING, POP_OUT and
 *       POP_OUT_AND_FADE (timed lyrics from LRCLIB).</li>
 * </ul>
 */
public class MusicPlayer extends HudModule implements ModuleActions {
   private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BlueClient/1.1";
   private static final int CONNECT_TIMEOUT_MS = 12000;
   private static final int READ_TIMEOUT_MS = 15000;
   private static final int MAX_TITLE_PX = 200;

   private final NumberSetting volume = new NumberSetting("Volume", "Playback volume %", 50.0, 0.0, 100.0, 5.0);
   private final BooleanSetting showInfo = new BooleanSetting("Show Track Info", "Draw the track name and time on the HUD", true);
   private final BooleanSetting showLyrics = new BooleanSetting("Show Lyrics", "Draw the current lyric line under the panel (fetched from LRCLIB)", true);
   private final ModeSetting lyricEffect = new ModeSetting("Lyric Effect", "How a new lyric line appears",
      List.of("FADING", "POP_OUT", "POP_OUT_AND_FADE"), "POP_OUT_AND_FADE");

   /*
    * v0.24.2 LYRICS OPTIONS (owner request)
    * --------------------------------------
    *  - "add a setting for words per segment like show 1 word, 2 3, 8 etc"
    *  - "show next lyric"
    *  - "add shadow to the lyrics the same way minimessage does it"
    *
    * Words per segment: an LRCLIB line can be long. When this is below the
    * line's word count the line is split into chunks of N words, and the chunk
    * shown advances through the line's own time slice.
    *
    * v0.24.3: the owner asked why 0 was even offered ("how can there be 0") —
    * it meant "whole line", which was an unobvious way to spell that. The range
    * now starts at 1 and DEFAULTS TO 3. To get the old whole-line behaviour,
    * turn the slider up: any value >= the line's word count shows it all.
    */
   /**
    * How a lyric line is displayed.
    *
    * <p><b>v0.25.0 — this is the real fix for "the lyrics are unsynced".</b>
    * The timing was correct; the DISPLAY was the problem. LRCLIB only provides
    * LINE-level timestamps, with no word timings anywhere in its data. The old
    * "3 words at a time" mode therefore had to GUESS when each word was sung by
    * dividing the line evenly — but singing is not evenly spaced, so on a line
    * like "Last week, been a whole year, but it feel like last week" (12 words
    * in 4.05 s) you were shown a 3-word window while the vocal had already
    * moved on. It reads as permanently lagging, and no offset can fix it
    * because the error changes within every line.</p>
    *
    * <p><b>Full Line</b> is now the default and has zero structural lag: the
    * whole line appears exactly on its timestamp, which is the one thing
    * LRCLIB actually guarantees. <b>Karaoke</b> also shows the full line but
    * brightens the words as they are sung, so nothing is ever hidden.</p>
    */
   private final ModeSetting lyricMode = new ModeSetting("Lyric Mode",
      "Full Line = whole line on its timestamp (most accurate). "
         + "Karaoke = whole line, highlighted as it is sung. "
         + "Word Window = the old few-words-at-a-time mode.",
      java.util.List.of("Full Line", "Karaoke", "Word Window"), "Full Line");

   private final NumberSetting wordsPerSegment = new NumberSetting("Words Per Segment",
      "Words at a time in Word Window mode", 3.0, 1.0, 12.0, 1.0);
   private final BooleanSetting showNextLyric = new BooleanSetting("Show Next Lyric",
      "Preview the upcoming line under the current one", true);
   private final BooleanSetting lyricShadow = new BooleanSetting("Lyric Shadow",
      "Draw a drop shadow behind the lyrics, like MiniMessage", true);
   /*
    * Manual nudge for stubborn tracks (v0.24.5).
    *
    * The real drift cause was an AAC sample-rate bug (see MusicEngine.playM4a),
    * but even with perfect playback timing LRCLIB timings are crowd-sourced and
    * are sometimes made against a different master (radio edit, remaster, a
    * version with a longer intro). Rather than leave the owner stuck, this
    * shifts every lyric line by up to +/- 5 seconds.
    *
    * POSITIVE = lyrics appear EARLIER (use when they feel late).
    */
   /**
    * The word-level lyric engine.
    *
    * <p>Holds the parsed document and answers "which word is being sung" from
    * the REAL audio position. Populated by the existing fetch worker; falls
    * back silently when a track has no word timing.</p>
    */
   private final net.bluenetwork.client.music.LyricEngine lyricEngine =
      new net.bluenetwork.client.music.LyricEngine();

   /** Active word index for this frame, or -1 when word timing is unknown. */
   private int karaokeWordIndex = -1;

   private final BooleanSetting syncIndicator = new BooleanSetting("Sync Indicator",
      "Show WORD / LINE / PLAIN next to the lyrics", false);

   private final BooleanSetting lyricDebug = new BooleanSetting("Lyric Debug",
      "Developer overlay: audio position, active word, provider", false);

   private final BooleanSetting romanize = new BooleanSetting("Romanize Lyrics",
      "Show Hindi, Russian and Greek lyrics in Latin letters", true);

   /*
    * Step is 10 ms, not 50. The engine now reports the AUDIBLE position rather
    * than the fed position, so any leftover error is small - and a 50 ms step
    * was too coarse to tune it out. Typing an exact value in the settings box
    * still works for anything in between.
    */
   private final NumberSetting lyricOffset = new NumberSetting("Lyric Offset",
      "Nudge lyric timing in milliseconds (+ = show earlier, - = show later)",
      0.0, -5000.0, 5000.0, 10.0);

   /*
    * LOOP (v0.24.0) - the ONLY change the owner allowed to the music player:
    *    "do not touch the music player, only add a loop feature"
    *
    * It is deliberately implemented OUTSIDE MusicEngine: the engine and its
    * decoder threads are untouched. We simply remember the last local file we
    * started and, once the engine reports it has stopped, start it again.
    * A future agent must NOT "clean this up" by moving looping into
    * MusicEngine - that is the file the owner told us to leave alone.
    */
   private final BooleanSetting loop = new BooleanSetting("Loop", "Restart the current song when it finishes", false);

   /**
    * Songs waiting to play, in order.
    *
    * <p>Picking a second track while one is playing used to start it
    * immediately on top of the first. Now it joins the queue and plays when
    * the current track ends, which is what "selecting two songs" should mean.
    * Clicking the SAME track again still plays it at once, because that reads
    * as "play this now".</p>
    */
   private static final java.util.ArrayDeque<Path> QUEUE = new java.util.ArrayDeque<>();

   /** Queue length, for the HUD. */
   public static int queueSize() {
      synchronized (QUEUE) {
         return QUEUE.size();
      }
   }

   /** Adds a track to the queue, or plays it now when nothing is playing. */
   public static void enqueue(Path file) {
      if (file == null) {
         return;
      }
      if (!MusicEngine.INSTANCE.isPlaying()) {
         playSongFile(file);
         return;
      }
      synchronized (QUEUE) {
         QUEUE.addLast(file);
      }
      BlueClient.getInstance().notificationManager()
         .add("Queued " + file.getFileName() + " (" + queueSize() + " waiting)",
            0xFF2FA5FF);
   }

   /** Empties the queue. */
   public static void clearQueue() {
      synchronized (QUEUE) {
         QUEUE.clear();
      }
   }

   /** Last local file handed to the engine; the loop watcher replays this. */
   private static volatile Path lastFile;

   /** True while the engine was playing on the previous tick (edge detection). */
   private boolean wasPlaying;

   /** Guard so a restart cannot fire twice in the same second. */
   private long lastLoopMs;

   private volatile TrackResolver.Resolved meta;
   private volatile LyricsProvider.Lyrics lyrics;
   private volatile String status = "";

   public MusicPlayer() {
      super("Music Player", "Play music from YouTube, Spotify or direct links", Category.MISC, 4, 4);
      // All lyric options collapse away when lyrics are off.
      this.lyricEffect.visibleWhen(this.showLyrics::get);
      this.lyricMode.visibleWhen(this.showLyrics::get);
      // The word-count slider only means anything in Word Window mode.
      this.wordsPerSegment.visibleWhen(
         () -> this.showLyrics.get() && "Word Window".equals(this.lyricMode.get()));
      this.lyricOffset.visibleWhen(this.showLyrics::get);
      this.romanize.visibleWhen(this.showLyrics::get);
      this.showNextLyric.visibleWhen(this.showLyrics::get);
      this.lyricShadow.visibleWhen(this.showLyrics::get);
      this.addSettings(new Setting[]{this.volume, this.loop, this.showInfo, this.showLyrics,
         this.lyricEffect, this.lyricMode, this.wordsPerSegment, this.showNextLyric, this.lyricShadow,
         this.romanize, this.syncIndicator, this.lyricDebug,
         this.lyricOffset});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_LEFT, 4, 60);
      this.volume.onChange(() -> MusicEngine.INSTANCE.setVolume(this.volumePercent()));
      // Enabled by default (feedback 2026-09-11): the HUD simply stays empty
      // until something plays, so this costs nothing.
      songsDir();
      this.setEnabled(true);
   }

   @Override
   public List<String> actionLabels() {
      List<String> labels = new ArrayList<>();
      labels.add("STOP");
      return labels;
   }

   @Override
   public void onAction(int index) {
      // "OPEN MUSIC" action removed (2026-09-12): it crashed the user's game.
      // STOP is the only action now.
      if (index == 0) {
         MusicEngine.INSTANCE.stop();
         this.status = "";
      }
   }

   /* ---------------- local songs folder ---------------- */

   /** The {@code songs/} folder next to your Minecraft directory (created on use). */
   public static Path songsDir() {
      Path dir = FabricLoader.getInstance().getGameDir().resolve("songs");
      try {
         Files.createDirectories(dir);
      } catch (IOException ignored) {
      }
      return dir;
   }

   /** Every playable audio file in {@link #songsDir()}, sorted by name. */
   public static List<Path> listSongs() {
      List<Path> out = new ArrayList<>();
      try (Stream<Path> stream = Files.list(songsDir())) {
         stream.filter(Files::isRegularFile).filter(MusicPlayer::isSong).sorted((a, b) ->
            a.getFileName().toString().compareToIgnoreCase(b.getFileName().toString())).forEach(out::add);
      } catch (IOException ignored) {
      }
      return out;
   }

   private static boolean isSong(Path p) {
      String n = p.getFileName().toString().toLowerCase();
      return n.endsWith(".mp4") || n.endsWith(".m4a") || n.endsWith(".aac")
         || n.endsWith(".mp3") || n.endsWith(".wav") || n.endsWith(".ogg");
   }

   /** Plays a file from the songs folder through the engine. */
   public static void playSongFile(Path file) {
      String name = file.getFileName().toString();
      String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1).toLowerCase() : "";
      String format = switch (ext) {
         case "mp4", "m4a", "aac" -> "m4a";
         case "mp3" -> "mp3";
         case "wav" -> "wav";
         default -> ext;
      };
      float vol = 0.7F;
      for (net.bluenetwork.client.module.Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof MusicPlayer mp) {
            vol = mp.volumePercent();
         }
      }
      lastFile = file;

      BlueClient.LOGGER.info("Playing song {} [format={} volume={}]", name, format, vol);
      BlueClient.getInstance().notificationManager().add("Playing " + name, 0xFF3CB860);
      if (vol <= 0.01F) {
         // A silent "successful" play at volume 0 looks exactly like a dead click.
         BlueClient.getInstance().notificationManager().add("Volume is 0 — raise it with the Volume slider", 0xFFFFB84D);
      }
      /*
       * v0.24.7 LYRIC SYNC FIX - ORDER MATTERS.
       *
       * The lyrics lookup used to run BEFORE playFile(), when the engine still
       * reported durationMs() == 0. LyricsProvider matches LRCLIB entries by
       * duration, so with 0 it could not discriminate and simply took the
       * first synced result. LRCLIB has both a 177 s and a 303 s "catch me" by
       * JVKE, so the client could load timings for a different master - the
       * lyrics then drift further behind the longer the song plays.
       *
       * Playback starts FIRST so the decoder can publish the real track
       * length, then the lookup runs with a duration to match against.
       */
      MusicEngine.INSTANCE.playFile(file, format, vol, name, err -> {
         BlueClient.LOGGER.error("Song playback failed for {}: {}", name, err);
         BlueClient.getInstance().notificationManager().add("Can't play: " + err, 0xFFFF5C5C);
      });

      for (net.bluenetwork.client.module.Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof MusicPlayer mp) {
            mp.fetchLyricsForFile(name, file);
         }
      }
   }

   /**
    * Loop watcher.
    *
    * <p>Runs once per client tick while the module is enabled. When the engine
    * transitions from playing to stopped and "Loop" is on, the last local file
    * is started again. The one-second cooldown stops a fast
    * "failed to open" error from turning into a restart storm.</p>
    */
   /**
    * Stops playback when the module is switched off.
    *
    * <p>Owner (v0.24.5): "the music playing using music player should stop if
    * I disable the music player module". Previously the audio thread just kept
    * going, and because {@link #onTick} only runs while a module is enabled,
    * the loop watcher could not stop it either — the only way out was to open
    * the music screen and press stop.</p>
    *
    * <p>{@code wasPlaying} is cleared too, so re-enabling the module does not
    * see a false "playing -> stopped" edge and immediately re-loop the track.</p>
    */
   @Override
   protected void onDisable() {
      try {
         MusicEngine.INSTANCE.stop();
      } catch (Throwable t) {
         BlueClient.LOGGER.debug("Failed to stop music on module disable", t);
      }
      this.wasPlaying = false;
   }

   @Override
   public void onTick() {
      boolean playing = MusicEngine.INSTANCE.isPlaying();
      if (this.wasPlaying && !playing) {
         long now = System.currentTimeMillis();
         if (now - this.lastLoopMs > 1000L) {
            /*
             * A queued track beats looping.
             *
             * If the player lined up another song, playing it is obviously
             * what they wanted - repeating the current one instead would
             * strand the queue forever. Loop only applies once the queue is
             * empty, so "loop + queue" behaves like a playlist on repeat.
             */
            Path next = null;
            synchronized (QUEUE) {
               next = QUEUE.pollFirst();
            }
            if (next != null && Files.isRegularFile(next)) {
               this.lastLoopMs = now;
               playSongFile(next);
            } else if (this.loop.get() && lastFile != null
               && Files.isRegularFile(lastFile)) {
               this.lastLoopMs = now;
               playSongFile(lastFile);
            }
         }
      }
      this.wasPlaying = playing;
   }

   /**
    * Looks up lyrics for a locally played file.
    *
    * <p>LRCLIB matches on title + artist, and all we have for a local file is
    * its name, so we parse the near-universal "Artist - Title.mp3" convention.
    * If there is no dash we send the whole stem as the title and let LRCLIB's
    * fuzzy search do the work.</p>
    *
    * <p>Duration is read from the engine when known; 0 tells LRCLIB not to
    * filter on length.</p>
    */
   /**
    * Starts a lyrics lookup for the track that is now playing.
    *
    * <h3>Resolution order (v0.24.4)</h3>
    * <ol>
    *   <li><b>Local {@code .lrc} sidecar</b> next to the audio file. A file the
    *       user supplied wins over anything online: it is instant, works with
    *       no connection, and is exactly what they asked for.</li>
    *   <li><b>ID3 tags</b> inside the file ({@code TIT2} / {@code TPE1}). Far
    *       more reliable than a filename, which is often
    *       "{@code 03 - track (Official Video).mp3}".</li>
    *   <li><b>Filename</b>, parsed as {@code Artist - Title} — the old
    *       behaviour, kept as the last resort.</li>
    * </ol>
    *
    * @param fileName display name, used for the filename fallback
    * @param file     the audio file itself; may be null
    */
   public void fetchLyricsForFile(String fileName, java.nio.file.Path file) {
      this.lyrics = null;
      // Drop the previous track's word timings immediately: keeping them would
      // highlight words from the wrong song until the new fetch returns.
      this.lyricEngine.clear();
      this.karaokeWordIndex = -1;

      // 1. A local sidecar beats everything, and needs no network at all.
      LyricsProvider.Lyrics local = LyricsProvider.fromSidecar(file);
      if (local != null && !local.lines().isEmpty()) {
         this.lyrics = local;
         if (this.showLyrics.get()) {
            BlueClient.getInstance().notificationManager()
               .add(local.synced() ? "Synced lyrics (local file)" : "Lyrics (local file)", 0xFF3CB860);
         }
         return;
      }

      String artist = "";
      String title;

      // 2. ID3 tags, when the file carries them. Tags are cleaned too - plenty
      // of downloaded files have "(Official Video)" sitting in the title tag.
      Id3Tags.Tags tags = file == null ? null : Id3Tags.read(file);
      if (tags != null && tags.title() != null && !tags.title().isBlank()) {
         // cleanTag, not clean: an ID3 tag is curated metadata, so stripping
         // "noise" words out of it destroys real names ("Audio Adrenaline").
         title = net.bluenetwork.client.music.TrackName.cleanTag(tags.title());
         if (tags.artist() != null && !tags.artist().isBlank()) {
            artist = net.bluenetwork.client.music.TrackName.cleanTag(tags.artist());
         }
      } else {
         // 3. The filename. This is where detection was failing: real files are
         // named "01. Tum Hi Ho (Official Video) [320kbps].mp3", and searching
         // that verbatim returns ZERO results. Cleaned, the same five test
         // files went from 0/5 to 5/5 hits.
         var guess = net.bluenetwork.client.music.TrackName.fromFileName(fileName);
         title = guess.title();
         artist = guess.artist();
      }

      this.lyricSidecarTarget = file;
      // durationSec is resolved inside the worker thread - see fetchLyrics,
      // which waits briefly for the decoder to publish the track length.
      this.fetchLyrics(new TrackResolver.Resolved(title, artist, 0, "", ""));
   }

   /** Back-compat overload for callers that only have a name. */
   public void fetchLyricsForFile(String fileName) {
      this.fetchLyricsForFile(fileName, null);
   }

   /**
    * File to write an .lrc sidecar for once an online lookup succeeds, so the
    * same song never costs a second network round-trip. Null disables caching.
    */
   private volatile java.nio.file.Path lyricSidecarTarget = null;

   private void fetchLyrics(TrackResolver.Resolved resolved) {
      Thread lyricsWorker = new Thread(() -> {
         try {
            /*
             * Wait (briefly) for the decoder to publish the real track length.
             * The duration is what lets LyricsProvider pick the RIGHT LRCLIB
             * entry when several exist for one title. MP4 publishes it from the
             * header almost immediately, MP3 after the first decoded frame.
             */
            int durationSec = resolved.durationSec();
            if (durationSec <= 0) {
               for (int i = 0; i < 40 && durationSec <= 0; i++) {
                  Thread.sleep(50L);
                  durationSec = (int) (MusicEngine.INSTANCE.durationMs() / 1000L);
               }
            }

            /*
             * Cache first, network second. The key includes the duration, so
             * two masters of one song cache separately. Entries written by
             * pre-0.24.7 builds carry an old version stamp and are discarded,
             * because those were resolved WITHOUT a working duration match.
             */
            LyricsProvider.Lyrics found = net.bluenetwork.client.music.LyricsCache
               .load(resolved.title(), resolved.artist(), durationSec);
            boolean fromCache = found != null && !found.lines().isEmpty();

            /*
             * Word-level pass, on the worker thread.
             *
             * Runs alongside the existing line-level fetch rather than
             * replacing it: word timing exists for only a minority of tracks
             * (1 of 3 in testing), so the proven line-level path stays as the
             * fallback and the karaoke highlight simply upgrades itself when
             * real timings are available.
             */
            /*
             * WORD-LEVEL PASS - word timings only.
             *
             * This used to call lyricEngine.resolve(), which internally ALSO
             * queries LRCLIB. Combined with the LRCLIB fetch below, a single
             * song fired up to EIGHT requests (two ladders of four) before a
             * line appeared, and two of the four queries in each ladder are
             * deliberately vague. That made lyrics feel broken on every track:
             * slow to arrive, and rate-limit prone.
             *
             * Now the word pass asks NetEase only. LRCLIB is fetched exactly
             * once, below, and the result is shared with the engine.
             */
            try {
               net.bluenetwork.client.music.LyricData words =
                  net.bluenetwork.client.music.NetEaseLyrics
                     .fetch(resolved.title(), resolved.artist(), durationSec);
               if (words != null
                  && words.syncType() == net.bluenetwork.client.music.LyricData.SyncType.WORD) {
                  this.lyricEngine.adopt(words);
               }
            } catch (Throwable wordFail) {
               // Never let the word pass break the line-level lyrics.
               BlueClient.LOGGER.debug("[Music] word-level lyric pass failed", wordFail);
            }

            if (!fromCache) {
               found = LyricsProvider.fetch(resolved.title(), resolved.artist(), durationSec);
               if (found != null && !found.lines().isEmpty()) {
                  net.bluenetwork.client.music.LyricsCache
                     .save(resolved.title(), resolved.artist(), durationSec, found);
               }
            }

            this.lyrics = found;
            BlueClient.LOGGER.info(
               "[Music] lyrics for title='{}' artist='{}' duration={}s -> {}",
               resolved.title(), resolved.artist(), durationSec,
               found == null ? "NONE" : found.lines().size() + " lines");

            if (this.showLyrics.get()) {
               if (found == null || found.lines().isEmpty()) {
                  BlueClient.getInstance().notificationManager()
                     .add("No lyrics found for " + resolved.title(), 0xFFFFB84D);
               } else {
                  String how = found.synced() ? "Synced lyrics" : "Plain lyrics";
                  BlueClient.getInstance().notificationManager()
                     .add(how + (fromCache ? " loaded (cached)" : " loaded"), 0xFF3CB860);
               }
            }
         } catch (Throwable t) {
            BlueClient.LOGGER.warn("Lyrics lookup failed: {}", t.toString());
            this.lyrics = null;
         }
      }, "Blue Client Lyrics");
      // Daemon: a pending lyrics fetch must never hold the JVM open when the
      // player quits. Every other worker thread in the client does the same.
      lyricsWorker.setDaemon(true);
      lyricsWorker.start();
   }

   /* ---------------- fetching ---------------- */

   /**
    * Downloads a Spotify / YouTube / direct link into the songs folder.
    *
    * <p>v0.24.1, owner request: "add a thing where you can input a link of a
    * song from spotify or youtube and it downloads the mp4 of it".</p>
    *
    * <p>Everything happens on a worker thread - the whole point is that the
    * game must not freeze while a multi-megabyte file comes down. Progress and
    * failures are reported as notifications. When the download finishes the
    * track is played immediately, which also triggers the lyrics lookup.</p>
    *
    * @param link  what the user pasted; may be a bare "youtu.be/..." with no scheme
    * @param play  true to start playing as soon as the file has landed
    */
   public static void downloadFromLink(String link, boolean play) {
      String input = link == null ? "" : link.trim();
      if (input.isEmpty()) {
         BlueClient.getInstance().notificationManager().add("Paste a link first", 0xFFFFB84D);
         return;
      }
      BlueClient.getInstance().notificationManager().add("Resolving link...", 0xFF3D6BFF);

      Thread downloadWorker = new Thread(() -> {
         try {
            TrackResolver.Resolved resolved = TrackResolver.resolve(input);

            // The owner asked for "the mp4". YouTube/Spotify audio streams are
            // MPEG-4 containers, so .mp4 is both what they asked for and what
            // the engine's m4a path already knows how to decode.
            String ext = switch (resolved.format() == null ? "" : resolved.format()) {
               case "mp3" -> "mp3";
               case "ogg" -> "ogg";
               case "wav" -> "wav";
               default -> "mp4";
            };
            Path target = songsDir().resolve(safeFileName(resolved.displayTitle()) + "." + ext);

            BlueClient.getInstance().notificationManager()
               .add("Downloading " + resolved.displayTitle(), 0xFF3D6BFF);

            // download() is an instance method only for historical reasons;
            // grab any live MusicPlayer instance to reuse it.
            MusicPlayer owner = null;
            for (net.bluenetwork.client.module.Module m
                  : BlueClient.getInstance().moduleManager().getModules()) {
               if (m instanceof MusicPlayer mp) {
                  owner = mp;
                  break;
               }
            }
            if (owner == null) {
               throw new IOException("Music Player module is not loaded");
            }
            owner.download(resolved.streamUrl(), target);

            long bytes = Files.size(target);
            if (bytes < 1024L) {
               Files.deleteIfExists(target);
               throw new IOException("the server returned an empty file");
            }
            BlueClient.getInstance().notificationManager()
               .add("Saved " + target.getFileName() + " (" + (bytes / 1024L / 1024L) + " MB)", 0xFF3CB860);

            if (play) {
               // Back onto the client thread: playback touches the sound system.
               MinecraftClient.getInstance().execute(() -> playSongFile(target));
            }
         } catch (Throwable t) {
            BlueClient.LOGGER.error("Link download failed", t);
            BlueClient.getInstance().notificationManager()
               .add("Download failed: " + t.getMessage(), 0xFFFF5C5C);
         }
      }, "Blue Client Song Download");
      // Daemon: a half-finished download must not block game exit.
      downloadWorker.setDaemon(true);
      downloadWorker.start();
   }

   /** Strips characters Windows refuses in file names. */
   private static String safeFileName(String raw) {
      String clean = raw.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
      if (clean.length() > 80) {
         clean = clean.substring(0, 80).trim();
      }
      return clean.isEmpty() ? "track" : clean;
   }


   private void download(String url, Path target) throws IOException {
      HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
      connection.setRequestProperty("User-Agent", USER_AGENT);
      connection.setInstanceFollowRedirects(true);
      connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
      connection.setReadTimeout(READ_TIMEOUT_MS);
      try (InputStream in = connection.getInputStream(); OutputStream out = Files.newOutputStream(target)) {
         in.transferTo(out);
      } finally {
         connection.disconnect();
      }
   }

   /**
    * Direct-file opener: browser-like User-Agent, follows redirects, format
    * resolved from the final URL extension OR the HTTP Content-Type.
    */

   private static String resolveFormat(String url, String contentType) {
      String lower = url.toLowerCase();
      int query = lower.indexOf('?');
      if (query >= 0) {
         lower = lower.substring(0, query);
      }
      if (lower.endsWith(".mp3")) {
         return "mp3";
      }
      if (lower.endsWith(".ogg") || lower.endsWith(".oga")) {
         return "ogg";
      }
      if (lower.endsWith(".wav")) {
         return "wav";
      }
      if (lower.endsWith(".m4a") || lower.endsWith(".aac")) {
         return "m4a";
      }
      if (contentType != null) {
         String ct = contentType.toLowerCase();
         if (ct.contains("mpeg") || ct.contains("mp3")) {
            return "mp3";
         }
         if (ct.contains("ogg")) {
            return "ogg";
         }
         if (ct.contains("wav") || ct.contains("x-wav")) {
            return "wav";
         }
         if (ct.contains("mp4") || ct.contains("aac")) {
            return "m4a";
         }
      }
      return null;
   }

   private float volumePercent() {
      return Math.max(0.0F, Math.min(1.0F, this.volume.getInt() / 100.0F));
   }

   /* ---------------- naming & cache ---------------- */

   private static String fileName(String url, String format) {
      int slash = url.lastIndexOf('/');
      String name = slash >= 0 ? url.substring(slash + 1) : url;
      int query = name.indexOf('?');
      if (query >= 0) {
         name = name.substring(0, query);
      }
      name = name.replaceAll("[^a-zA-Z0-9 ._\\-()\\[\\]]", "_");
      if (name.isBlank() || name.equals("_")) {
         name = "track";
      }
      if (!name.toLowerCase().endsWith(".mp3") && !name.toLowerCase().endsWith(".ogg")
         && !name.toLowerCase().endsWith(".wav") && !name.toLowerCase().endsWith(".m4a")) {
         name = name + "." + format;
      }
      return name;
   }

   public static Path cacheDir() {
      Path dir = FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("music");
      try {
         Files.createDirectories(dir);
      } catch (Throwable ignored) {
      }
      return dir;
   }

   public static List<Path> cachedFiles() {
      List<Path> files = new ArrayList<>();
      try (Stream<Path> stream = Files.list(cacheDir())) {
         stream.filter(file -> {
            String name = file.getFileName().toString().toLowerCase();
            return name.endsWith(".mp3") || name.endsWith(".ogg") || name.endsWith(".wav") || name.endsWith(".m4a");
         }).sorted().forEach(files::add);
      } catch (Throwable ignored) {
      }
      return files;
   }

   /* ---------------- HUD ---------------- */

   private String titleLine() {
      TrackResolver.Resolved current = this.meta;
      if (MusicEngine.INSTANCE.isPlaying()) {
         String name = MusicEngine.INSTANCE.nowPlaying();
         if (!name.isEmpty()) {
            return name;
         }
      }
      if (current != null) {
         return current.displayTitle();
      }
      return "";
   }

   private String timeLine() {
      long pos = MusicEngine.INSTANCE.positionMs();
      long dur = MusicEngine.INSTANCE.durationMs();
      if (dur > 0) {
         return LyricsProvider.clock(pos) + " / " + LyricsProvider.clock(dur);
      }
      return LyricsProvider.clock(pos);
   }

   @Override
   public void render(DrawContext context) {
      String title = this.titleLine();
      String statusNow = this.status;
      boolean playing = MusicEngine.INSTANCE.isPlaying();
      boolean drawPanel = this.showInfo.get() && (!title.isEmpty() || !statusNow.isEmpty());
      if (!drawPanel && !this.showLyrics.get()) {
         return;
      }

      if (drawPanel) {
         int w = this.getWidthCached();
         int h = this.getHeightCached();
         this.drawPanel(context, w, h);

         int color = this.textColor();
         if (!statusNow.isEmpty()) {
            RenderUtil.drawText(context, fit(statusNow, w - 16), this.x + 8, this.y + 6, color);
            return;
         }

         RenderUtil.drawText(context, fit(title, w - 16), this.x + 8, this.y + 5, color);
         String time = this.timeLine();
         RenderUtil.drawText(context, time, this.x + 8, this.y + 16, (color & 0x00FFFFFF) | 0xB0000000);

         // progress bar along the panel bottom
         long dur = MusicEngine.INSTANCE.durationMs();
         if (dur > 0 && playing) {
            float progress = Math.min(1.0F, MusicEngine.INSTANCE.positionMs() / (float) dur);
            context.fill(this.x + 6, this.y + h - 4, this.x + w - 6, this.y + h - 3, 0x33FFFFFF);
            context.fill(this.x + 6, this.y + h - 4, (int) (this.x + 6 + (w - 12) * progress), this.y + h - 3, 0xFF2FA5FF);
         }
      }

      if (this.showLyrics.get()) {
         float lyricY = drawPanel ? this.y + this.getHeightCached() + 12.0F : this.y;
         this.drawLyrics(context, lyricY);
         if (this.syncIndicator.get() || this.lyricDebug.get()) {
            this.drawSyncInfo(context, lyricY);
         }
      }
   }

   /**
    * Current lyric line with the configured appearance effect.
    *
    * <p>v0.24.2 adds word segmenting, an optional next-line preview and a
    * MiniMessage-style drop shadow.</p>
    */

   /**
    * How long the words of a line plausibly take to sing.
    *
    * <p>Roughly 4 syllables per second is a normal singing rate. Used to tell
    * "this line is still being sung" from "the line ended and we are in an
    * instrumental gap", which LRC data does not state explicitly - it only
    * gives the next line's start.</p>
    */
   private static long estimateSungMs(String text) {
      if (text == null || text.isBlank()) {
         return 0L;
      }
      int syl = 0;
      for (String w : text.trim().split("\\s+")) {
         syl += syllables(w);
      }
      return Math.max(700L, (long) (syl * 250.0));
   }

   /**
    * Picks the segment to show, weighting each by its syllable count.
    *
    * @param through 0..1 through the line
    */
   private static int segmentForProgress(String[] words, int perSegment,
                                         int segments, float through) {
      // Weight of each segment = syllables it contains (minimum 1).
      float[] weights = new float[segments];
      float total = 0.0F;
      for (int seg = 0; seg < segments; seg++) {
         int from = seg * perSegment;
         int to = Math.min(words.length, from + perSegment);
         float w = 0.0F;
         for (int i = from; i < to; i++) {
            w += syllables(words[i]);
         }
         weights[seg] = Math.max(1.0F, w);
         total += weights[seg];
      }
      if (total <= 0.0F) {
         return Math.min(segments - 1, (int) (through * segments));
      }

      float target = through * total;
      float acc = 0.0F;
      for (int seg = 0; seg < segments; seg++) {
         acc += weights[seg];
         if (target < acc) {
            return seg;
         }
      }
      return segments - 1;
   }

   /**
    * Rough syllable count for a word.
    *
    * <p>Counts vowel groups, then applies the usual English correction for a
    * silent trailing "e". It does not need to be linguistically perfect - it
    * only has to rank words by how long they take to sing, and vowel groups do
    * that well enough to remove the flat-timing artefact.</p>
    */
   private static int syllables(String word) {
      if (word == null || word.isEmpty()) {
         return 1;
      }
      String w = word.toLowerCase(java.util.Locale.ROOT)
         .replaceAll("[^a-z\u00e0-\u00ff]", "");
      if (w.isEmpty()) {
         return 1;
      }
      int count = 0;
      boolean prevVowel = false;
      for (int i = 0; i < w.length(); i++) {
         boolean vowel = "aeiouy\u00e0\u00e1\u00e8\u00e9\u00ec\u00ed\u00f2\u00f3\u00f9\u00fa".indexOf(w.charAt(i)) >= 0;
         if (vowel && !prevVowel) {
            count++;
         }
         prevVowel = vowel;
      }
      // A trailing "e" is usually silent ("time" is one syllable, not two).
      if (w.endsWith("e") && count > 1) {
         count--;
      }
      return Math.max(1, count);
   }

   private void drawLyrics(DrawContext context, float cy) {
      LyricsProvider.Lyrics current = this.lyrics;
      if (current == null || !MusicEngine.INSTANCE.isPlaying()) {
         return;
      }
      // Apply the user's manual nudge: a POSITIVE offset means "show earlier",
      // which is the same as pretending we are further into the song.
      long pos = MusicEngine.INSTANCE.positionMs() + (long) this.lyricOffset.get().doubleValue();
      if (pos < 0L) {
         pos = 0L;
      }
      /*
       * Real word timing, when the provider supplied it.
       *
       * Computed from the SAME audible position the line lookup uses, so the
       * highlight can never drift from the line. -1 means "no word timing" and
       * the renderer falls back to whole-line highlighting rather than
       * guessing.
       */
      var wordState = this.lyricEngine.state(
         MusicEngine.INSTANCE.positionMs(),
         Math.max(1, this.wordsPerSegment.getInt()),
         false);
      this.karaokeWordIndex = wordState.data().hasRealWordTiming()
         ? wordState.wordIndex() : -1;

      LyricsProvider.Line line = current.at(pos);
      if (line == null || line.text().isBlank()) {
         return;
      }
      // Romanize at DRAW time, not at fetch time: the setting then applies
      // instantly and the cached/sidecar lyrics stay in their original script.
      String lineText = this.romanize.get()
         ? net.bluenetwork.client.music.Romanizer.romanize(line.text())
         : line.text();
      LyricsProvider.Line next = current.after(line);
      long gap = next != null ? next.ms() - line.ms() : 5000L;
      long age = pos - line.ms();

      /*
       * Instrumental gaps. A blank LRC line, or a long stretch before the next
       * line, means the singer has stopped - LRCLIB marks these with empty
       * timestamps and they are common in intros and bridges.
       *
       * Previously the last line simply stayed frozen on screen through the
       * whole gap, or its segments kept cycling over words nobody was singing.
       * Clearing once the line has had its natural time is what makes the
       * display follow the pauses instead of looping.
       */
      long sung = Math.min(gap, estimateSungMs(lineText));
      if (next != null && age > sung && gap - age > 1200L) {
         return;                              // instrumental: show nothing
      }

      long lineDur = Math.max(500L, sung);

      /*
       * --- what to show ----------------------------------------------------
       *
       * LRCLIB gives LINE-level timestamps only - there is no word timing in
       * the data at all. So the only display that is genuinely in sync is one
       * that shows the whole line on its own timestamp. Anything that reveals
       * words progressively has to invent the word times by dividing the line
       * evenly, and real singing is not evenly spaced.
       */
      String mode = this.lyricMode.get();
      String[] words = lineText.trim().split("\\s+");

      int perSegment;
      int segments;
      int segIndex;
      String shown;
      if ("Word Window".equals(mode)) {
         perSegment = Math.max(1, this.wordsPerSegment.getInt());
         segments = Math.max(1, (int) Math.ceil(words.length / (double) perSegment));
         float through = Math.min(0.999F, Math.max(0.0F, age / (float) lineDur));

         // Segments used to advance on a flat clock: through * segments. That
         // gives every chunk an identical slice no matter what is in it, which
         // is the reported "loop of lyric every 0.25 seconds" - short words sit
         // too long and long words flash past.
         //
         // Singing time tracks SYLLABLES far better than word count, so each
         // segment now gets a share of the line proportional to how much there
         // is to sing in it. No word-level timings exist in LRCLIB, so this is
         // an estimate - but a weighted estimate beats a flat one clearly.
         segIndex = segmentForProgress(words, perSegment, segments, through);
         int from = segIndex * perSegment;
         int to = Math.min(words.length, from + perSegment);
         shown = String.join(" ", java.util.Arrays.copyOfRange(words, from, to));
      } else {
         // Full Line and Karaoke both show everything, so there is exactly one
         // "segment" and the animation timing below spans the whole line.
         perSegment = words.length;
         segments = 1;
         segIndex = 0;
         shown = line.text().trim();
      }

      /*
       * --- animation -------------------------------------------------------
       *
       * v0.24.3 SYNC FIX. Owner: "the lyrics are unsynced now, maybe because
       * the animation is too long (the fading one)". Exactly right:
       *
       * The fade used a FIXED 400 ms in and 400 ms out. With 3-word segments a
       * segment often lasts only ~600-800 ms, so fade-in and fade-out overlapped
       * and alpha NEVER reached 1 - the words stayed dim and looked like they
       * were lagging behind the music.
       *
       * The animation is now a FRACTION of the segment (18% each side, hard
       * capped at 160 ms), so a fast segment gets a quick snap and a long one
       * still gets a graceful fade. Both are always well under half the
       * segment, so the text is fully opaque for the bulk of its slot.
       */
      long segDur = Math.max(1L, lineDur / segments);
      long segAge = Math.max(0L, age - (long) segIndex * segDur);

      float fadeMs = Math.min(160.0F, segDur * 0.18F);

      float alpha = 1.0F;
      float scale = 1.0F;
      String effect = this.lyricEffect.get();
      if (!"POP_OUT".equals(effect)) {
         float fadeIn = Math.min(1.0F, segAge / fadeMs);
         float fadeOut = Math.min(1.0F, Math.max(0.0F, segDur - segAge) / fadeMs);
         alpha = Math.max(0.0F, Math.min(fadeIn, fadeOut));
      }
      if (!"FADING".equals(effect)) {
         // The pop settles in the same window as the fade, so the two effects
         // finish together instead of the scale still moving after the fade.
         float t = Math.min(1.0F, segAge / Math.max(1.0F, fadeMs));
         float eased = 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
         scale = 1.18F - 0.18F * eased;
      }

      float cx = this.x + Math.max(this.getWidthCached(), 180) / 2.0F;
      int argb = (int) (alpha * 255.0F) << 24 | 0xFFFFFF;

      context.getMatrices().pushMatrix();
      context.getMatrices().translate(cx, cy);
      context.getMatrices().scale(scale, scale);
      context.getMatrices().translate(-cx, -cy);
      if ("Karaoke".equals(mode)) {
         float sungProgress = Math.min(1.0F, Math.max(0.0F, age / (float) lineDur));
         this.drawKaraokeText(context, words, this.karaokeWordIndex, sungProgress, cx, cy - 5.0F, 11.0F, alpha);
      } else {
         this.drawLyricText(context, shown, cx, cy - 5.0F, argb, 11.0F, alpha);
      }
      context.getMatrices().popMatrix();

      // --- next line preview ----------------------------------------------
      if (this.showNextLyric.get()) {
         // With segmenting on, "next" means the next SEGMENT of this line
         // until we run out, then the next line - that is what actually helps
         // you sing along.
         String preview = null;
         if (segIndex + 1 < segments) {
            int nextFrom = (segIndex + 1) * perSegment;
            int nextTo = Math.min(words.length, nextFrom + perSegment);
            preview = String.join(" ", java.util.Arrays.copyOfRange(words, nextFrom, nextTo));
         } else if (next != null && !next.text().isBlank()) {
            preview = next.text();
         }
         if (preview != null && !preview.isBlank()) {
            this.drawLyricText(context, preview, cx, cy + 8.0F, 0x99FFFFFF, 8.5F, 0.6F);
         }
      }
   }

   /**
    * Draws one centred lyric string, with an optional MiniMessage-style shadow.
    *
    * <p>MiniMessage / vanilla Minecraft shadows are a solid black copy of the
    * glyphs offset by one pixel down-right at roughly 25% opacity - NOT a blur.
    * We reproduce exactly that: same text, +1/+1, black, alpha scaled with the
    * text's own fade so the shadow never outlives the glyphs.</p>
    */
   /**
    * Draws a full line with the already-sung words brightened (Karaoke mode).
    *
    * <p>The whole line is always visible - that is the point, and why this does
    * not drift the way the old word-window did. The highlight is only a visual
    * hint about roughly where the vocal is, derived by spreading the line's
    * duration across its words. If that estimate is slightly off, you can still
    * read every word, so a small error is harmless. Hiding words based on the
    * same estimate is what made the old mode feel broken.</p>
    */
   /**
    * Karaoke text with a progressive highlight.
    *
    * <p>Words are drawn one at a time so each can be coloured independently,
    * and every word after the first is prefixed with a space. That spacing is
    * what stops the line rendering as "wordsecondword" - measuring the space
    * as part of the piece keeps the advance exactly equal to the full string's
    * width, so the line stays centred.</p>
    *
    * @param activeIndex index of the word currently being sung, or -1. When
    *                    this is >= 0 it comes from REAL provider timestamps.
    * @param fallbackProgress used only when {@code activeIndex} is -1, i.e.
    *                    line-level sync where word positions are unknown. The
    *                    whole line is then highlighted together rather than
    *                    pretending to know where each word falls.
    */
   private void drawKaraokeText(DrawContext context, String[] words,
         int activeIndex, float fallbackProgress,
         float cx, float y, float size, float alpha) {
      if (words.length == 0) {
         return;
      }
      String full = String.join(" ", words);
      float totalW = TextPainter.poppinsWidth(full, size);
      float x = cx - totalW / 2.0F;

      if (this.lyricShadow.get()) {
         int shadowAlpha = (int) (alpha * 0.45F * 255.0F) & 0xFF;
         TextPainter.drawPoppins(context, full, x + 1.0F, y + 1.0F, shadowAlpha << 24, size);
      }

      int sungAlpha = (int) (alpha * 255.0F) & 0xFF;
      int dimAlpha = (int) (alpha * 0.45F * 255.0F) & 0xFF;

      /*
       * With real word timing, a word lights up exactly when the singer
       * reaches it. Without it, do NOT guess per word - highlight the whole
       * line uniformly, because pretending to know word positions is what
       * made the old karaoke drift.
       */
      boolean realTiming = activeIndex >= 0;
      float sungWords = realTiming
         ? activeIndex + 1
         : (fallbackProgress >= 1.0F ? words.length : 0.0F);

      float cursor = x;
      for (int i = 0; i < words.length; i++) {
         // Space BEFORE every word except the first. Measured with the word so
         // the cursor advance matches the centred full-string width.
         String piece = i == 0 ? words[i] : " " + words[i];
         boolean sung = i < sungWords;
         int color = sung
            ? (sungAlpha << 24) | 0xFFFFFF
            : (dimAlpha << 24) | 0xFFFFFF;
         TextPainter.drawPoppins(context, piece, cursor, y, color, size);
         cursor += TextPainter.poppinsWidth(piece, size);
      }
   }

   /**
    * The sync-quality badge and, optionally, the developer overlay.
    *
    * <p>Both are off by default so the normal player stays uncluttered -
    * the indicator only matters when you are wondering WHY the timing looks
    * the way it does.</p>
    */
   private void drawSyncInfo(DrawContext context, float lyricY) {
      var data = this.lyricEngine.data();
      float x = this.x;
      float y = lyricY - 11.0F;

      if (this.syncIndicator.get()) {
         String label = data.syncType().label();
         int colour = switch (data.syncType()) {
            case WORD -> 0xFF00BA7C;     // green: the real thing
            case LINE -> 0xFF1D9BF0;     // blue: good, but line-level
            case PLAIN -> 0xFF8A94A6;    // grey: no timing at all
         };
         TextPainter.drawPoppins(context, label, x, y, colour, 7.0F);
         y -= 10.0F;
      }

      if (!this.lyricDebug.get()) {
         return;
      }
      long audio = MusicEngine.INSTANCE.positionMs();
      var st = this.lyricEngine.state(audio,
         Math.max(1, this.wordsPerSegment.getInt()), false);

      String word = "-";
      long wordStart = -1L;
      if (st.hasLine() && st.wordIndex() >= 0
         && st.wordIndex() < st.line().words().size()) {
         var w = st.line().words().get(st.wordIndex());
         word = w.text();
         wordStart = w.startMs();
      }

      String[] rows = {
         "Audio: " + clock(audio),
         "Word: " + word,
         "Start: " + (wordStart < 0 ? "-" : clock(wordStart)),
         "Offset: " + (this.lyricOffset.getInt() >= 0 ? "+" : "")
            + this.lyricOffset.getInt() + " ms",
         "Provider: " + data.provider(),
         "Sync: " + data.syncType().name()};
      for (int i = rows.length - 1; i >= 0; i--) {
         TextPainter.drawPoppins(context, rows[i], x, y, 0xFFFFD400, 6.5F);
         y -= 9.0F;
      }
   }

   /** mm:ss.mmm, the format the owner asked the debug overlay to use. */
   private static String clock(long ms) {
      long m = ms / 60000L;
      long sec = (ms / 1000L) % 60L;
      long milli = ms % 1000L;
      return String.format("%02d:%02d.%03d", m, sec, milli);
   }

   private void drawLyricText(DrawContext context, String text, float cx, float y,
         int argb, float size, float alpha) {
      float w = TextPainter.poppinsWidth(text, size);
      float x = cx - w / 2.0F;
      if (this.lyricShadow.get()) {
         int shadowAlpha = (int) (alpha * 0.45F * 255.0F) & 0xFF;
         TextPainter.drawPoppins(context, text, x + 1.0F, y + 1.0F, shadowAlpha << 24, size);
      }
      TextPainter.drawPoppins(context, text, x, y, argb, size);
   }

   private static String fit(String text, int maxWidth) {
      if (text == null) {
         return "";
      }
      if (RenderUtil.textWidth(text) <= maxWidth) {
         return text;
      }
      /*
       * The ellipsis must be measured TOO.
       *
       * The old loop trimmed until the bare text fit, then appended "..." -
       * so the returned string was up to ~8px WIDER than maxWidth. Centred
       * labels are drawn at (x + w/2 - width/2), so an over-wide string spills
       * past both edges and reads as off-centre. It only showed up on long
       * labels, which is why the owner saw it "sometimes".
       */
      int ellipsis = RenderUtil.textWidth("...");
      String t = text;
      while (!t.isEmpty() && RenderUtil.textWidth(t) + ellipsis > maxWidth) {
         t = t.substring(0, t.length() - 1);
      }
      return t.isEmpty() ? text.substring(0, 1) : t + "...";
   }

   @Override
   public int getWidth() {
      if (!this.showInfo.get()) {
         return 40;
      }
      String statusNow = this.status;
      if (!statusNow.isEmpty()) {
         return RenderUtil.textWidth(fit(statusNow, MAX_TITLE_PX)) + 16;
      }
      String title = this.titleLine();
      if (title.isEmpty()) {
         return 40;
      }
      int titleW = RenderUtil.textWidth(fit(title, MAX_TITLE_PX));
      int timeW = RenderUtil.textWidth(this.timeLine());
      return Math.max(60, Math.max(titleW, timeW) + 16);
   }

   @Override
   public int getHeight() {
      return this.showInfo.get() ? 30 : 21;
   }

   /* ---------------- helpers ---------------- */

   private void notifyError(String message) {
      String text = message == null || message.isBlank() ? "Unknown error" : message;
      this.notify("Music: " + text);
   }

   private void notify(String message) {
      try {
         BlueClient.getInstance().notificationManager().add(message, -13673473);
      } catch (Throwable ignored) {
      }
   }
}
