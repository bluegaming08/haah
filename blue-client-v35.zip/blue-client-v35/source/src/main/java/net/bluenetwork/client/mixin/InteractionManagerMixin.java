package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.HitReactor;
import net.bluenetwork.client.module.impl.ComboHud;
import net.bluenetwork.client.module.impl.ReachHud;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerInteractionManager.class})
public abstract class InteractionManagerMixin {
   @Inject(
      method = {"attackEntity"},
      at = {@At("HEAD")}
   )
   private void blueclient$onAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
      if (target != null) {
         for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
            if (module.isEnabled()) {
               if (module instanceof ComboHud combo) {
                  combo.onAttack();
               } else if (module instanceof ReachHud reach) {
                  reach.onAttack(target);
               } else if (module instanceof HitReactor reactor) {
                  reactor.onHit(player, target);
               }
            }
         }
      }
   }
}
