package net.bluenetwork.client.ui;

import net.bluenetwork.client.social.NameColor;
import net.bluenetwork.client.ui.text.TextPainter;
import net.minecraft.client.gui.DrawContext;

/**
 * The one place a player's name is drawn with their Blue+ styling.
 *
 * <h2>Why this exists</h2>
 * Gradient names were drawn by an inline per-character loop copied into
 * several screens. Each copy advanced the cursor with
 * {@code poppinsWidth(singleChar)}, which is <b>not</b> the same as the width
 * that character occupies inside a word - kerning and sub-pixel advance mean
 * the errors accumulate, so long names visibly stretched apart or bunched up.
 * That is the "gradient breaks your name" bug.
 *
 * <p>Here the advance is measured against the growing prefix instead, so each
 * glyph lands exactly where the un-styled string would have put it. Bold and
 * italic are applied through {@link TextPainter#drawStyled}, so all three
 * options compose correctly and behave the same on every screen.</p>
 */
public final class NamePainter {

   private NamePainter() {
   }

   /**
    * Draws {@code name} with the player's colour spec.
    *
    * @param json     the stored name_color JSON, may be null
    * @param fallback colour to use when there is no spec
    * @return the advance width
    */
   public static float draw(DrawContext ctx, String name, float x, float y,
                            float size, String json, int fallback) {
      if (name == null || name.isEmpty()) {
         return 0.0F;
      }
      NameColor.Spec spec = NameColor.parse(json, fallback);
      return draw(ctx, name, x, y, size, spec);
   }

   /** As above, with an already-parsed spec. */
   public static float draw(DrawContext ctx, String name, float x, float y,
                            float size, NameColor.Spec spec) {
      if (name == null || name.isEmpty()) {
         return 0.0F;
      }
      boolean bold = spec.bold();
      boolean italic = spec.italic();

      if (!spec.gradient()) {
         return TextPainter.drawStyled(ctx, name, x, y, spec.flat(), size,
            bold, italic);
      }

      // Gradient: colour each glyph, but position it using the width of the
      // PREFIX rather than summing individual glyph widths. Summing is what
      // made long gradient names drift out of shape.
      float total = TextPainter.poppinsWidth(name, size);
      for (int i = 0; i < name.length(); i++) {
         String ch = String.valueOf(name.charAt(i));
         float offset = i == 0 ? 0.0F
            : TextPainter.poppinsWidth(name.substring(0, i), size);
         float t = total <= 0.0F ? 0.0F : offset / total;
         TextPainter.drawStyled(ctx, ch, x + offset, y,
            NameColor.blend(spec, t), size, bold, italic);
      }
      return total;
   }

   /**
    * Width the name will occupy.
    *
    * <p>Always the plain width: bold is synthesised by overdrawing in place
    * and italic only leans glyphs, so neither changes the advance. Callers can
    * lay out before drawing.</p>
    */
   public static float width(String name, float size) {
      return TextPainter.poppinsWidth(name == null ? "" : name, size);
   }
}
