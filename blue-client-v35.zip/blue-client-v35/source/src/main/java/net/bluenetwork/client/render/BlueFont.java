package net.bluenetwork.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.OptionalDouble;
import net.bluenetwork.client.mixin.BlueDrawContextAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.freetype.FreeType;
import org.lwjgl.util.freetype.FT_Bitmap;
import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FT_GlyphSlot;
import org.lwjgl.util.freetype.FT_Vector;

/**
 * Custom TrueType text renderer built on FreeType (the same library Minecraft 1.21.11
 * uses internally for its TTF font provider). Glyphs are rasterized on demand at 4x the
 * logical size into an RGBA atlas, uploaded once, and drawn with linear filtering through
 * the GLYPH pipeline. Proper kerning, real baseline control, and crisp output at every GUI
 * scale - the premium-client font look that the vanilla TTF provider cannot give (it has
 * no baseline shift control and rounds advances to integers).
 *
 * <p>All public methods must be called on the render thread. If anything fails during
 * init, the font silently degrades: draws fall back to the vanilla text renderer so the
 * GUI never crashes over a font problem.
 */
public final class BlueFont {
    public static final int OVERSAMPLE = 4;
    private static final int ATLAS_SIZE = 1024;
    private static final int FT_LOAD_RENDER = 0x4;
    private static final int FT_KERNING_DEFAULT = 0;
    private static final int FT_PIXEL_MODE_GRAY = 2;

    private static final Map<String, BlueFont> FONTS = new HashMap<>();
    private static long library;
    private static GpuSampler linearSampler;

    private final String name;
    private final Identifier asset;
    private final Map<GlyphKey, Glyph> glyphs = new HashMap<>();
    private NativeImage atlas;
    private NativeImageBackedTexture texture;
    private GpuTextureView textureView;
    private FT_Face face;
    private long facePtr;

    /**
     * The font file bytes, in NATIVE memory.
     *
     * <p>This MUST be kept alive for exactly as long as {@link #face} is. The
     * FreeType call below is {@code FT_New_Memory_Face}, which does not copy -
     * the face reads glyph data straight out of this buffer for its whole
     * lifetime.</p>
     *
     * <p>It used to be a local variable, which was wrong twice over: the
     * memory was never freed (a leak of the whole font file per face), and
     * nothing kept a reference for {@code memFree} to use later. Holding it in
     * a field lets {@link #close()} free it in the right order - face first,
     * then the bytes it was reading.</p>
     */
    private ByteBuffer ttfBytes;
    private float ascent;
    private float descent;
    private int cursorX;
    private int cursorY;
    private int rowHeight;
    private boolean atlasDirty;
    private boolean broken;

    private record GlyphKey(int codePoint, int size) {
    }

    private static final class Glyph {
        final float u0;
        final float v0;
        final float u1;
        final float v1;
        final float advance;
        final float bearingX;
        final float bearingY;
        final float width;
        final float height;
        final int glyphIndex;

        Glyph(float u0, float v0, float u1, float v1, float advance, float bearingX, float bearingY, float width, float height, int glyphIndex) {
            this.u0 = u0;
            this.v0 = v0;
            this.u1 = u1;
            this.v1 = v1;
            this.advance = advance;
            this.bearingX = bearingX;
            this.bearingY = bearingY;
            this.width = width;
            this.height = height;
            this.glyphIndex = glyphIndex;
        }
    }

    private BlueFont(String name, Identifier asset) {
        this.name = name;
        this.asset = asset;
    }

    /** Gets (or lazily creates) the named font. "poppins" resolves to the Poppins asset. */
    public static BlueFont get(String name) {
        BlueFont font = FONTS.get(name);
        if (font == null) {
            Identifier asset;
            switch (name) {
                case "poppins-medium" -> asset = Identifier.of("blueclient", "font/poppins-medium.ttf");
                case "minecraft-five" -> asset = Identifier.of("blueclient", "font/minecraft-five-bold.ttf");
                default -> asset = Identifier.of("blueclient", "font/poppins-semibold.ttf");
            }
            font = new BlueFont(name, asset);
            FONTS.put(name, font);
        }
        font.ensureInit();
        return font;
    }

    private void ensureInit() {
        if (broken || face != null) {
            return;
        }
        try {
            synchronized (BlueFont.class) {
                if (linearSampler == null) {
                    linearSampler = RenderSystem.getDevice().createSampler(
                        AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE,
                        FilterMode.LINEAR, FilterMode.LINEAR, 0, OptionalDouble.empty());
                }
                if (library == 0L) {
                    try (MemoryStack stack = MemoryStack.stackPush()) {
                        PointerBuffer buffer = stack.mallocPointer(1);
                        check(FreeType.FT_Init_FreeType(buffer), "init FreeType");
                        library = buffer.get(0);
                    }
                }
            }
            ttfBytes = readAsset();
            try (MemoryStack stack = MemoryStack.stackPush()) {
                PointerBuffer buffer = stack.mallocPointer(1);
                check(FreeType.FT_New_Memory_Face(library, ttfBytes, 0L, buffer),
                    "load " + name);
                facePtr = buffer.get(0);
            }
            face = FT_Face.create(facePtr);
            atlas = new NativeImage(ATLAS_SIZE, ATLAS_SIZE, true);
            texture = new NativeImageBackedTexture(() -> "blueclient_font_" + name, atlas);
            textureView = texture.getGlTextureView();
        } catch (Throwable t) {
            broken = true;
            close();
        }
    }

    private ByteBuffer readAsset() throws IOException {
        byte[] all;
        try (var input = MinecraftClient.getInstance().getResourceManager().open(asset)) {
            all = input.readAllBytes();
        }
        ByteBuffer direct = MemoryUtil.memAlloc(Math.max(64, all.length));
        direct.put(all);
        direct.flip();
        return direct;
    }

    /** Logical line height for a logical size, matching vanilla's 9px line for size 9. */
    public float lineHeight(float logicalSize) {
        return logicalSize + 1.0F;
    }

    public float width(String text, float logicalSize) {
        ensureInit();
        if (broken) {
            return MinecraftClient.getInstance().textRenderer.getWidth(text);
        }
        return measure(text, logicalSize);
    }

    private float measure(String text, float logicalSize) {
        float pen = 0.0F;
        int prevIndex = 0;
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            Glyph glyph = glyph(cp, logicalSize);
            if (glyph == null) {
                pen += vanillaFallbackWidth(text, logicalSize);
                prevIndex = 0;
                continue;
            }
            if (prevIndex != 0) {
                pen += kern(prevIndex, glyph.glyphIndex, logicalSize);
            }
            pen += glyph.advance;
            prevIndex = glyph.glyphIndex;
        }
        return pen;
    }

    private float vanillaFallbackWidth(String text, float logicalSize) {
        return MinecraftClient.getInstance().textRenderer.getWidth(text) * (logicalSize / 9.0F);
    }

    /**
     * Draws the text with the top of the line box at y. Returns the pen position after the
     * last glyph so callers can chain draws.
     */
    public float draw(DrawContext context, String text, float x, float y, int color, boolean shadow, float logicalSize) {
        ensureInit();
        if (broken || MinecraftClient.getInstance().textRenderer == null) {
            var matrices = context.getMatrices();
            matrices.pushMatrix();
            matrices.translate(x, y);
            float scale = logicalSize / 9.0F;
            matrices.scale(scale, scale);
            if (shadow) {
                context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, 0, 0, color);
            } else {
                context.drawText(MinecraftClient.getInstance().textRenderer, text, 0, 0, color, false);
            }
            matrices.popMatrix();
            return x + vanillaFallbackWidth(text, logicalSize);
        }
        if (shadow) {
            int shadowColor = shadowColor(color);
            drawPass(context, text, x + 1.0F, y + 1.0F, shadowColor, logicalSize);
        }
        return drawPass(context, text, x, y, color, logicalSize);
    }

    public void drawCentered(DrawContext context, String text, float centerX, float y, int color, boolean shadow, float logicalSize) {
        draw(context, text, centerX - width(text, logicalSize) / 2.0F, y, color, shadow, logicalSize);
    }

    public void drawRightAligned(DrawContext context, String text, float rightX, float y, int color, boolean shadow, float logicalSize) {
        draw(context, text, rightX - width(text, logicalSize), y, color, shadow, logicalSize);
    }

    private float drawPass(DrawContext context, String text, float x, float y, int color, float logicalSize) {
        flushAtlas();
        float baseline = y + ascentFor(logicalSize);
        float penX = x;
        int prevIndex = 0;
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            int len = Character.charCount(cp);
            String ch = text.substring(i, i + len);
            i += len;
            Glyph glyph = glyph(cp, logicalSize);
            if (glyph == null) {
                // Not in the font: fall back to vanilla rendering for this character.
                var matrices = context.getMatrices();
                matrices.pushMatrix();
                matrices.translate(penX, y);
                float scale = logicalSize / 9.0F;
                matrices.scale(scale, scale);
                context.drawText(MinecraftClient.getInstance().textRenderer, ch, 0, 0, color, false);
                matrices.popMatrix();
                penX += vanillaFallbackWidth(ch, logicalSize);
                prevIndex = 0;
                continue;
            }
            if (prevIndex != 0) {
                penX += kern(prevIndex, glyph.glyphIndex, logicalSize);
            }
            if (glyph.width > 0.0F && glyph.height > 0.0F) {
                float gx = penX + glyph.bearingX;
                float gy = baseline - glyph.bearingY;
                Matrix3x2f pose = new Matrix3x2f(context.getMatrices());
                GlyphQuadGuiElement element = new GlyphQuadGuiElement(
                    textureView, linearSampler, pose,
                    gx, gy, gx + glyph.width, gy + glyph.height,
                    glyph.u0, glyph.v0, glyph.u1, glyph.v1,
                    color, SmoothRect.scissor(context),
                    SmoothRect.bounds(context, gx, gy, gx + glyph.width, gy + glyph.height));
                ((BlueDrawContextAccessor) (Object) context).blueclient$guiState().addSimpleElement(element);
            }
            penX += glyph.advance;
            prevIndex = glyph.glyphIndex;
        }
        return penX;
    }

    private float ascentFor(float logicalSize) {
        ensureInit();
        if (broken) {
            return logicalSize;
        }
        setFaceSize(logicalSize);
        return (face.size().metrics().ascender() / 64.0F) / OVERSAMPLE;
    }

    private int lastPixelSize = -1;

    private void setFaceSize(float logicalSize) {
        int px = Math.max(4, Math.round(logicalSize * OVERSAMPLE));
        if (lastPixelSize != px) {
            check(FreeType.FT_Set_Pixel_Sizes(face, 0, px), "set pixel size");
            lastPixelSize = px;
        }
    }

    private float kern(int leftIndex, int rightIndex, float logicalSize) {
        setFaceSize(logicalSize);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            FT_Vector vector = FT_Vector.malloc(stack);
            check(FreeType.FT_Get_Kerning(face, leftIndex, rightIndex, FT_KERNING_DEFAULT, vector), "kerning");
            return (vector.x() / 64.0F) / OVERSAMPLE;
        } catch (Throwable t) {
            return 0.0F;
        }
    }

    private Glyph glyph(int codePoint, float logicalSize) {
        int size = Math.round(logicalSize);
        GlyphKey key = new GlyphKey(codePoint, size);
        Glyph glyph = glyphs.get(key);
        if (glyph == null) {
            glyph = rasterize(key);
            glyphs.put(key, glyph);
        }
        return glyph;
    }

    private Glyph rasterize(GlyphKey key) {
        setFaceSize(key.size());
        int glyphIndex = FreeType.FT_Get_Char_Index(face, key.codePoint());
        if (glyphIndex == 0) {
            return null;
        }
        check(FreeType.FT_Load_Glyph(face, glyphIndex, FT_LOAD_RENDER), "load glyph " + key.codePoint());
        FT_GlyphSlot slot = face.glyph();
        FT_Bitmap bitmap = slot.bitmap();
        float advanceLog = slot.advance().x() / 64.0F / OVERSAMPLE;
        if (bitmap.pixel_mode() != FT_PIXEL_MODE_GRAY || bitmap.width() <= 0 || bitmap.rows() <= 0) {
            return new Glyph(0, 0, 0, 0, advanceLog, 0, 0, 0, 0, glyphIndex);
        }
        int w = bitmap.width();
        int h = bitmap.rows();
        if (cursorX + w + 2 > ATLAS_SIZE) {
            cursorX = 0;
            cursorY += rowHeight + 2;
            rowHeight = 0;
        }
        if (cursorY + h + 2 > ATLAS_SIZE) {
            return new Glyph(0, 0, 0, 0, advanceLog, 0, 0, 0, 0, glyphIndex);
        }
        ByteBuffer pixels = bitmap.buffer(bitmap.pitch() * h);
        for (int row = 0; row < h; row++) {
            for (int col = 0; col < w; col++) {
                int a = pixels.get(row * bitmap.pitch() + col) & 0xFF;
                if (a != 0) {
                    atlas.setColorArgb(cursorX + col, cursorY + row, (a << 24) | 0xFFFFFF);
                }
            }
        }
        Glyph glyph = new Glyph(
            cursorX / (float) ATLAS_SIZE,
            cursorY / (float) ATLAS_SIZE,
            (cursorX + w) / (float) ATLAS_SIZE,
            (cursorY + h) / (float) ATLAS_SIZE,
            advanceLog,
            slot.bitmap_left() / (float) OVERSAMPLE,
            slot.bitmap_top() / (float) OVERSAMPLE,
            w / (float) OVERSAMPLE,
            h / (float) OVERSAMPLE,
            glyphIndex);
        cursorX += w + 2;
        rowHeight = Math.max(rowHeight, h);
        atlasDirty = true;
        return glyph;
    }

    private void flushAtlas() {
        if (atlasDirty) {
            texture.upload();
            atlasDirty = false;
        }
    }

    /**
     * Flat black drop shadow (the classic MiniMessage / vanilla text-component
     * look) — always pure black regardless of the glyph's own colour, at the
     * same opacity as the glyph. No hue is ever mixed in, so there is no
     * colour-tinted "glow" halo, just a crisp black offset pass.
     */
    private static int shadowColor(int color) {
        return color & 0xFF000000;
    }

    private static void check(int error, String what) {
        if (error != 0) {
            throw new IllegalStateException("BlueFont: FreeType error " + error + " during " + what);
        }
    }

    public boolean isBroken() {
        return broken;
    }

    private void close() {
        // ORDER MATTERS. The face reads from ttfBytes, so the face has to be
        // destroyed before that memory is handed back - freeing it the other
        // way round is a use-after-free, which on Linux/macOS tends to be a
        // hard JVM crash rather than a tidy exception.
        if (facePtr != 0L) {
            FreeType.FT_Done_Face(face);
            facePtr = 0L;
        }
        face = null;
        if (ttfBytes != null) {
            MemoryUtil.memFree(ttfBytes);
            ttfBytes = null;
        }
        if (atlas != null) {
            atlas.close();
            atlas = null;
        }
        if (texture != null) {
            texture.close();
            texture = null;
        }
        textureView = null;
    }
}
