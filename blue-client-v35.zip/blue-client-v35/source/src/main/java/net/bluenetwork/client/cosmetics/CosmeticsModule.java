package net.bluenetwork.client.cosmetics;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.ModuleActions;
import net.bluenetwork.client.module.KeyScreenOpener;

/**
 * Cosmetics module (v0.20.0) — the Cape Locker. Not a toggle: its keybind
 * opens the locker screen (KeyScreenOpener), and its settings screen has an
 * OPEN LOCKER action. Cape rendering itself is always on while a cape is
 * equipped (no reason to ever disable the visual).
 */
public class CosmeticsModule extends Module implements KeyScreenOpener, ModuleActions {

   public CosmeticsModule() {
      super("Cosmetics", "Cape locker + Blue Stars (1/min on Blue Network)", Category.MISC);
   }

   @Override
   public Screen openKeyScreen() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return new net.bluenetwork.client.ui.screen.CosmeticsScreen(mc.currentScreen);
   }

   @Override
   public java.util.List<String> actionLabels() {
      return java.util.List.of("OPEN LOCKER");
   }

   @Override
   public void onAction(int index) {
      MinecraftClient mc = MinecraftClient.getInstance();
      mc.setScreen(new net.bluenetwork.client.ui.screen.CosmeticsScreen(mc.currentScreen));
   }
}
