package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.gui.DrawContext;

public class CpsHud extends HudModule {
   public static final long[] LEFT_TIMES = new long[64];
   public static final long[] RIGHT_TIMES = new long[64];
   public static int leftCount = 0;
   public static int rightCount = 0;
   private final BooleanSetting showRight = new BooleanSetting("Right click", "Also show right-click CPS (bridging speed)", false);
   /** From the premium pack: live click-rate graph under the text. */
   private final BooleanSetting showGraph = new BooleanSetting("Click graph", "Draw a per-second click history sparkline under the text", true);
   private static final int[] HISTORY = new int[20];
   private static int historyIndex = 0;
   private static long lastSample = 0L;

   public CpsHud() {
      super("CPS", "Clicks per second - your click speed", Category.HUD, 4, 306);
      this.addSettings(new Setting[]{this.showRight, this.showGraph});
   }

   public static void onPress(int button) {
      long[] buffer = button == 0 ? LEFT_TIMES : RIGHT_TIMES;
      int index = button == 0 ? leftCount++ : rightCount++;
      buffer[index % buffer.length] = System.currentTimeMillis();
   }

   private static int cps(long[] buffer) {
      long cutoff = System.currentTimeMillis() - 1000L;
      int total = 0;

      for (long t : buffer) {
         if (t >= cutoff) {
            total++;
         }
      }

      return total;
   }

   public static int leftCps() {
      return cps(LEFT_TIMES);
   }

   public static int rightCps() {
      return cps(RIGHT_TIMES);
   }

   @Override
   public void onTick() {
      long now = System.currentTimeMillis();
      if (now - lastSample >= 1000L) {
         if (lastSample > 0L) {
            HISTORY[historyIndex % HISTORY.length] = leftCps();
            historyIndex++;
         }

         lastSample = now;
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("88 | 88 CPS") + 12 + 2;
   }

   @Override
   public int getHeight() {
      return this.showGraph.get() ? 32 : 21;
   }

   private String text() {
      int left = leftCps();
      return this.showRight.get() ? left + " | " + rightCps() + " CPS" : left + " CPS";
   }

   @Override
   public void render(DrawContext context) {
      String text = this.text();
      int panelW = RenderUtil.textWidth(text) + 12 + 2;
      if (!this.showGraph.get()) {
         this.drawTextPanel(context, text);
      } else {
         RenderUtil.drawRoundedPanel(context, this.x, this.y, panelW, 32);
         RenderUtil.drawText(context, text, this.x + 6 + 2, this.y + 6, BlueColors.TEXT_PRIMARY);
         // Sparkline: last 20 seconds of click history, newest on the right
         int peak = 4;
         for (int h : HISTORY) {
            peak = Math.max(peak, h);
         }

         int barX = this.x + 7;
         int barY = this.y + 21;
         int barH = 8;
         for (int i = 0; i < HISTORY.length; i++) {
            int value = HISTORY[(historyIndex + i) % HISTORY.length];
            int slotW = Math.max(1, (panelW - 14) / HISTORY.length);
            int barW = Math.max(1, slotW - 1);
            int h = value <= 0 ? 1 : Math.max(1, value * barH / peak);
            int alpha = value <= 0 ? 0x33 : 0xCC;
            int color = alpha << 24 | BlueColors.ACCENT & 0xFFFFFF;
            context.fill(barX, barY + barH - h, barX + barW, barY + barH, color);
            barX += slotW;
         }
      }
   }
}
