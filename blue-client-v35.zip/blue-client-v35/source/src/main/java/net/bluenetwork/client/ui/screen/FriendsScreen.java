package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.social.BlueBackend;
import net.bluenetwork.client.social.FriendsManager;
import net.bluenetwork.client.social.Limits;
import net.bluenetwork.client.social.NameColor;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.ui.Anim;
import net.bluenetwork.client.ui.NamePainter;
import net.bluenetwork.client.ui.XKit;
import net.bluenetwork.client.ui.BluePlusIcon;
import net.bluenetwork.client.ui.VerifiedBadge;
import net.bluenetwork.client.social.SocialValidation;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * The Friends screen.
 *
 * <h2>Layout</h2>
 * Deliberately compact - a single centred panel with a tab strip, sized like
 * the rest of the Blue Client UI rather than a full-window dashboard. It uses
 * the same fit-scaled virtual space as {@code ClientSettingsScreen}, so the
 * panel can never be cut off on a small window or at a large GUI scale.
 *
 * <h2>How it stays responsive</h2>
 * This screen NEVER waits for the network. It draws whatever
 * {@link FriendsManager} currently has cached, and any action fires a request
 * that updates that cache later. If the backend is down the panel still opens
 * and simply shows "Friends services are currently unavailable."
 *
 * <h2>Text input</h2>
 * Fields are hand-drawn rather than vanilla {@code TextFieldWidget}s so they
 * match the theme. {@code focus} names which field has the caret.
 */
public class FriendsScreen extends Screen {

   /**
    * Design canvas. Widened from 700x430 for the X-style three-column
    * layout - the old box could not fit a nav rail, a feed and a sidebar, so
    * ten tabs wrapped onto three cramped lines instead.
    */
   private static final int DESIGN_W = 880;
   private static final int DESIGN_H = 470;

   /** Left navigation rail width, like X's icon+label sidebar. */
   private static final float NAV_W = 132.0F;
   /** Right sidebar width (trends / who to follow). */
   private static final float SIDE_W = 186.0F;

   // Colours now live in XKit so the launcher, the mod and every pane agree
   // on one palette. The old local GREEN/RED/GREY/PLUS_GOLD constants were
   // near-misses of the X values and made panes look subtly inconsistent.

   /** How many lines the tab strip wrapped onto this frame. */
   private int tabRows = 1;

   /**
    * v21 tab strip. "SEARCH" replaces the old "ADD" (same job, clearer name),
    * and POSTS / TOP / BLUE+ are new. The strip wraps onto a second line when
    * it does not fit, so adding tabs can never push any of them off-panel.
    */
   private static final String[] TABS = {
      "FRIENDS", "POSTS", "ACTIVITY", "TOP", "CHATS", "REQUESTS", "SEARCH",
      "BLUE+", "BLOCKED", "PRIVACY"};

   private final Screen parent;
   private String tab = "POSTS";

   /* text fields */
   private String fieldUser = "";
   private String fieldPass = "";
   private String fieldSearch = "";
   private String draftPost = "";
   private String draftCode = "";

   /**
    * Tooltip queued by the current frame's hover, drawn last.
    *
    * <p>It must be drawn after every pane or a later panel would paint over
    * it - which is why it is collected during layout rather than drawn in
    * place.</p>
    */
   private String pendingTooltip;
   private float tooltipX;
   private float tooltipY;

   /* ---- Blue+ colour studios ---- */
   /** Name colour: supports bold / italic. */
   private final net.bluenetwork.client.ui.ColorStudio nameStudio =
      new net.bluenetwork.client.ui.ColorStudio(true);
   /** Profile background colour: bold / italic would be meaningless. */
   private final net.bluenetwork.client.ui.ColorStudio bgStudio =
      new net.bluenetwork.client.ui.ColorStudio(false);
   private String plusNotice;
   private boolean plusOk;

   /* ---- chat PAGE state (replaces the ChatScreen popup) ---- */
   /** Conversation open as a page, or null. */
   private String chatId;
   private java.util.List<FriendsManager.Message> chatMessages = java.util.List.of();
   private String draftChat = "";
   private long chatLoadedAt;

   /* ---- profile PAGE state (replaces the old popup screen) ---- */
   /** Profile currently open as a page, or null. */
   private FriendsManager.Profile viewProfile;
   /** Id being loaded, so a slow fetch cannot land on the wrong page. */
   private String viewProfileId;
   private boolean viewProfileLoading;
   /** That player's posts, and how they are sorted. */
   private java.util.List<FriendsManager.Post> viewPosts = java.util.List.of();
   /** Every badge the viewed player owns. */
   private java.util.List<FriendsManager.Badge> viewBadges = java.util.List.of();
   private String viewSort = "new";
   /** The tab the user was on before opening a profile, to go Back to. */
   private String profileReturnTab;

   /** Non-null when the Posts tab is showing one post's reply thread. */
   private String threadId;
   private String draftReply = "";
   private String replyNotice;
   private volatile String postNotice;
   private volatile String redeemNotice;
   private volatile boolean redeemOk;
   private String focus = null;

   /* login screen mode: true = create account, false = log in */
   private boolean registerMode = false;

   /* search debounce + results */
   private long lastTypedMs;
   private boolean searchPending;
   private volatile List<FriendsManager.Blocked> results = List.of();

   private float scroll;
   private float drawScale = 1.0F;
   private final List<Hit> hits = new ArrayList<>();
   private String confirmRemoveId;

   public FriendsScreen(Screen parent) {
      super(Text.literal("Social"));
      this.parent = parent;
   }

   private static FriendsManager social() {
      return BlueClient.getInstance().friends();
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   /** Shown once for a brand-new account. */
   private static boolean tutorialSeen;

   @Override
   protected void init() {
      social().setScreenOpen(true);
      // Always land on Home. Reopening on whatever tab you last used means a
      // player who wandered into Blocked sees Blocked next launch.
      if (this.tab == null || this.tab.isBlank()) {
         this.tab = "POSTS";
      }
      // Replay the entrance every time the screen opens, not just the first.
      Anim.reset("screen:open");
   }

   @Override
   public void removed() {
      social().setScreenOpen(false);
      super.removed();
   }

   /* ====================================================================== */
   /*  Render                                                                */
   /* ====================================================================== */

   /** Set when rendering threw, so we show a message instead of dying again. */
   private String renderFault;

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      try {
         renderInner(context, mouseX, mouseY, delta);
      } catch (Throwable t) {
         /*
          * A throw inside render() crashes the game outright, which is what
          * the owner hit when opening Social. No single bad field is worth
          * that: catch it, show it, and keep the client alive. The stack trace
          * still reaches the log for diagnosis.
          */
         if (this.renderFault == null) {
            this.renderFault = t.getClass().getSimpleName()
               + (t.getMessage() == null ? "" : ": " + t.getMessage());
            net.bluenetwork.client.BlueClient.LOGGER
               .error("[Social] render failed", t);
         }
         try {
            context.getMatrices().popMatrix();
         } catch (Throwable ignored) {
            // The matrix stack may not have been pushed yet.
         }
         int w = context.getScaledWindowWidth();
         int h = context.getScaledWindowHeight();
         context.fill(0, 0, w, h, 0xD9000000);
         centered(context, "Social hit an error and stopped drawing.",
            w / 2.0F, h / 2.0F - 16, XKit.TEXT, 10.0F);
         centered(context, this.renderFault, w / 2.0F, h / 2.0F, XKit.MUTED, 8.0F);
         centered(context, "Press Escape to close. Details are in the log.",
            w / 2.0F, h / 2.0F + 16, XKit.MUTED, 8.0F);
      }
   }

   private void renderInner(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0xD9000000);

      float base = 0.75F;
      float fit = Math.min(1.0F,
         Math.min(w / (base * DESIGN_W + 12.0F), h / (base * DESIGN_H + 12.0F)));
      float scale = base * Math.max(0.35F, fit);

      float open = Anim.easeOut(Anim.once("screen:open", 180.0F));
      scale *= 0.985F + 0.015F * open;
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int mx = (int) (mouseX / scale);
      int my = (int) (mouseY / scale);

      float panelW = Math.min(vw - 20, DESIGN_W);
      float panelH = Math.min(vh - 20, DESIGN_H);
      float px = (vw - panelW) / 2.0F;
      float py = (vh - panelH) / 2.0F;

      this.hits.clear();
      this.pendingTooltip = null;

      // The shell: near-black canvas with a hairline edge, like X's dim theme.
      PremiumRender.drawShadow(context, (int) px - 2, (int) py - 2,
         (int) panelW + 4, (int) panelH + 4,
         Anim.mixColor(0x00000000, 0x99000000, open), 16);
      SmoothRect.fill(context, px, py, panelW, panelH, 12.0F,
         Anim.mixColor(0x00000000, XKit.BG, open));
      SmoothRect.outline(context, px, py, panelW, panelH, 12.0F, 1.0F,
         Anim.mixColor(0x00000000, XKit.DIVIDER, open));

      FriendsManager s = social();

      // Close button, top-right of the whole shell.
      boolean overX = hit(mx, my, px + panelW - 26, py + 8, 18, 18);
      if (overX) {
         SmoothRect.fill(context, px + panelW - 26, py + 8, 18, 18, 9.0F, XKit.HOVER);
      }
      RenderUtil.drawIcon(context, "x", (int) (px + panelW - 22), (int) (py + 12),
         10, overX ? XKit.TEXT : XKit.MUTED);
      this.hits.add(new Hit(px + panelW - 26, py + 8, 18, 18, "close"));

      if (!s.available()) {
         centered(context, "Social is disabled in this build.",
            px + panelW / 2.0F, py + panelH / 2.0F - 4.0F, XKit.MUTED, 9.0F);
         context.getMatrices().popMatrix();
         return;
      }
      if (!s.loggedIn()) {
         drawAuth(context, px, py + 30, panelW, panelH - 40, mx, my);
         context.getMatrices().popMatrix();
         runSearchIfDue();
         return;
      }

      /* ---- three columns, exactly as X lays them out ---- */
      boolean wide = panelW >= 700.0F;
      float navW = NAV_W;
      float sideW = wide ? SIDE_W : 0.0F;

      float navX = px;
      float feedX = navX + navW;
      float feedW = panelW - navW - sideW;
      float sideX = feedX + feedW;

      drawNavRail(context, navX, py, navW, panelH, mx, my);

      // Column dividers - hairlines, not panels.
      XKit.divider(context, feedX, py + 10, 1.0F);
      SmoothRect.fill(context, feedX, py + 8, 1.0F, panelH - 16, 0.0F, XKit.DIVIDER);
      if (wide) {
         SmoothRect.fill(context, sideX, py + 8, 1.0F, panelH - 16, 0.0F, XKit.DIVIDER);
      }

      /* ---- centre column: sticky header + the active pane ---- */
      float headH = drawFeedHeader(context, feedX, py, feedW, mx, my);
      float bodyY = py + headH;
      float bodyH = panelH - headH - 8.0F;

      switch (this.tab) {
         case "CHATS" -> {
            if (this.chatId != null) {
               drawChatPage(context, feedX, bodyY, feedW, bodyH, mx, my);
            } else {
               drawChats(context, feedX, bodyY, feedW, bodyH, mx, my);
            }
         }
         case "REQUESTS" -> drawRequests(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "SEARCH" -> drawAdd(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "POSTS" -> drawPosts(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "ACTIVITY" -> drawActivity(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "TOP" -> drawTop(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "PROFILE" -> drawProfilePage(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "ADMIN" -> drawAdmin(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "EDIT" -> drawEditProfile(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "RULES" -> drawRules(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "BLUE+" -> drawPlus(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "BLOCKED" -> drawBlocked(context, feedX, bodyY, feedW, bodyH, mx, my);
         case "PRIVACY" -> drawPrivacy(context, feedX, bodyY, feedW, bodyH, mx, my);
         default -> drawFriends(context, feedX, bodyY, feedW, bodyH, mx, my);
      }

      if (wide) {
         drawSidebar(context, sideX, py, sideW, panelH, mx, my);
      }

      // The single most valuable message this screen can show: the client is
      // fine, the DATABASE is missing functions. Without this, an un-applied
      // schema looks like a dozen unrelated broken features.
      if (s.schemaOutdated()) {
         float wy = py + panelH - 40;
         SmoothRect.fill(context, feedX + 8, wy, feedW - 16, 32, 6.0F,
            XKit.alpha(XKit.GOLD, 0.16F));
         SmoothRect.outline(context, feedX + 8, wy, feedW - 16, 32, 6.0F, 1.0F,
            XKit.alpha(XKit.GOLD, 0.6F));
         RenderUtil.drawIcon(context, "shield", (int) (feedX + 16), (int) (wy + 9),
            13, XKit.GOLD);
         TextPainter.drawPoppins(context, "Database is out of date", feedX + 34,
            wy + 7, XKit.GOLD, 8.5F);
         TextPainter.drawPoppins(context,
            "Run backend/schema_v3.sql in Supabase, then select setup_staff();",
            feedX + 34, wy + 19, XKit.MUTED, 7.0F);
      }

      String err = s.lastError();
      if (err != null) {
         SmoothRect.fill(context, feedX + 8, py + panelH - 24, feedW - 16, 17,
            8.5F, XKit.alpha(XKit.RED, 0.20F));
         centered(context, err, feedX + feedW / 2.0F, py + panelH - 19.5F,
            XKit.RED, 8.0F);
      }

      // First-run tutorial. Drawn over everything, dismissed by any click.
      FriendsManager tut = social();
      if (tut.loggedIn() && tut.profileReady() && !tutorialSeen
         && tut.feed().isEmpty() && tut.followers() == 0L
         && tut.friends().isEmpty()) {
         drawTutorial(context, px, py, panelW, panelH, mx, my);
      }

      drawTooltip(context);

      context.getMatrices().popMatrix();
      runSearchIfDue();
   }

   /**
    * A one-time welcome for a brand-new account.
    *
    * <p>Shown only when the account genuinely looks new - no posts, no
    * followers, no friends - so an existing player never sees it.</p>
    */
   private void drawTutorial(DrawContext ctx, float px, float py, float pw,
                             float ph, int mx, int my) {
      ctx.fill((int) px, (int) py, (int) (px + pw), (int) (py + ph), 0xE6000000);

      float cx = px + pw / 2.0F;
      float cy = py + 34;

      RenderUtil.drawLogo(ctx, (int) (cx - 14), (int) cy, 28);
      cy += 36;
      centered(ctx, "Welcome to Blue Social", cx, cy, XKit.TEXT, 14.0F);
      cy += 22;
      centered(ctx, "Here is what you can do.", cx, cy, XKit.MUTED, 8.5F);
      cy += 24;

      String[][] steps = {
         {"home", "Home", "Posts from people you follow, plus a For You feed."},
         {"search", "Explore", "Find players by username and add them."},
         {"users", "Friends", "See who is online and join their server."},
         {"bell", "Notifications", "Likes, replies, follows and requests."},
         {"sparkles", "Blue+", "Coloured names, profile colours, bigger limits."}};

      float lx = cx - 140;
      for (String[] step : steps) {
         RenderUtil.drawIcon(ctx, step[0], (int) lx, (int) cy, 12, XKit.BLUE);
         TextPainter.drawPoppins(ctx, step[1], lx + 18, cy + 1, XKit.TEXT, 8.5F);
         TextPainter.drawPoppins(ctx, XKit.fit(step[2], 190.0F, 7.5F),
            lx + 80, cy + 1.5F, XKit.MUTED, 7.5F);
         cy += 18;
      }

      cy += 8;
      centered(ctx, "You already follow Blue and Cyan.", cx, cy, XKit.MUTED, 7.5F);
      cy += 20;

      boolean over = hit(mx, my, cx - 50, cy, 100, 24);
      XKit.pill(ctx, "Get started", cx - 50, cy, 100, 24, over, true,
         XKit.BLUE, "tut:go");
      this.hits.add(new Hit(cx - 50, cy, 100, 24, "tutdone"));
   }

   /**
    * Draws the queued tooltip, clamped inside the panel.
    *
    * <p>Supports two lines: everything before a {@code \n} is the title, the
    * rest is muted detail. Badges use that for "Name" + description.</p>
    */
   private void drawTooltip(DrawContext ctx) {
      if (this.pendingTooltip == null) {
         return;
      }
      String[] lines = this.pendingTooltip.split("\n", 2);
      float titleSize = 7.5F;
      float subSize = 7.0F;

      float wTitle = TextPainter.poppinsWidth(lines[0], titleSize);
      float wSub = lines.length > 1
         ? TextPainter.poppinsWidth(lines[1], subSize) : 0.0F;

      float bw = Math.max(wTitle, wSub) + 12;
      float bh = lines.length > 1 ? 26.0F : 15.0F;
      float bx = this.tooltipX - bw / 2.0F;
      float by = this.tooltipY - bh;

      // Keep it inside the screen rather than hanging off an edge.
      bx = Math.max(2.0F, bx);
      float maxX = ctx.getScaledWindowWidth() / Math.max(0.01F, this.drawScale) - bw - 2;
      bx = Math.min(bx, Math.max(2.0F, maxX));
      by = Math.max(2.0F, by);

      PremiumRender.drawShadow(ctx, (int) bx - 1, (int) by - 1,
         (int) bw + 2, (int) bh + 2, 0x88000000, 6);
      SmoothRect.fill(ctx, bx, by, bw, bh, 4.0F, 0xFF2A2E33);
      SmoothRect.outline(ctx, bx, by, bw, bh, 4.0F, 1.0F, XKit.DIVIDER);

      if (lines.length > 1) {
         TextPainter.drawPoppins(ctx, lines[0], bx + 6, by + 5, XKit.TEXT, titleSize);
         TextPainter.drawPoppins(ctx, lines[1], bx + 6, by + 15, XKit.MUTED, subSize);
      } else {
         TextPainter.drawPoppins(ctx, lines[0], bx + 6,
            by + (bh - titleSize) / 2.0F + 0.5F, XKit.TEXT, titleSize);
      }
   }

   /**
    * The left navigation rail - X's primary navigation.
    *
    * <p>This replaces the old wrapping strip of ten tab pills, which was the
    * single biggest reason the screen looked like a debug menu: ten equal-
    * weight chips on three lines with no hierarchy. A vertical rail gives each
    * destination an icon, room to breathe, and an obvious active state.</p>
    */
   private void drawNavRail(DrawContext ctx, float x, float y, float w, float h,
                            int mx, int my) {
      FriendsManager s = social();

      // Brand mark at the top of the rail, where X puts its logo.
      RenderUtil.drawLogo(ctx, (int) (x + 12), (int) (y + 10), 20);

      record Nav(String tab, String icon, String label, int badge) {
      }
      java.util.List<Nav> items = new java.util.ArrayList<>();
      items.add(new Nav("POSTS", "home", "Home", 0));
      items.add(new Nav("ACTIVITY", "bell", "Notifications",
         net.bluenetwork.client.notification.NotificationInbox.unread()));
      items.add(new Nav("CHATS", "message-square", "Messages",
         (int) Math.min(99L, s.unreadTotal())));
      items.add(new Nav("FRIENDS", "users", "Friends", 0));
      items.add(new Nav("REQUESTS", "user-round", "Requests", s.incoming().size()));
      items.add(new Nav("SEARCH", "search", "Explore", 0));
      items.add(new Nav("TOP", "trending-up", "Top", 0));
      items.add(new Nav("BLUE+", "sparkles", "Blue+", 0));
      // Admin is added ONLY for staff. The server re-checks every admin RPC,
      // so hiding the button is convenience, not the security boundary.
      if (s.staff()) {
         items.add(new Nav("ADMIN", "shield", "Admin", 0));
      }

      float iy = y + 38;
      for (Nav n : items) {
         boolean active = n.tab().equals(this.tab);
         boolean over = hit(mx, my, x + 6, iy, w - 12, 22);
         XKit.navItem(ctx, n.icon(), n.label(), x + 6, iy, w - 12, 22,
            active, over || active, n.badge(), "nav:" + n.tab());
         this.hits.add(new Hit(x + 6, iy, w - 12, 22, "tab:" + n.tab()));
         iy += 25;
      }

      // Secondary destinations, visually demoted the way X demotes Settings.
      iy += 4;
      for (String[] extra : new String[][] {
            {"RULES", "book", "Rules"},
            {"BLOCKED", "lock", "Blocked"}, {"PRIVACY", "settings", "Settings"}}) {
         boolean active = extra[0].equals(this.tab);
         boolean over = hit(mx, my, x + 6, iy, w - 12, 20);
         XKit.navItem(ctx, extra[1], extra[2], x + 6, iy, w - 12, 20,
            active, over || active, 0, "nav:" + extra[0]);
         this.hits.add(new Hit(x + 6, iy, w - 12, 20, "tab:" + extra[0]));
         iy += 22;
      }

      // The big Post button, X's most prominent control.
      float pbY = iy + 8;
      boolean overPost = hit(mx, my, x + 10, pbY, w - 20, 24);
      XKit.pill(ctx, "Post", x + 10, pbY, w - 20, 24, overPost, true,
         XKit.BLUE, "nav:post");
      this.hits.add(new Hit(x + 10, pbY, w - 20, 24, "gopost"));

      /* ---- account card, pinned to the bottom like X ---- */
      float accY = y + h - 40;
      boolean overAcc = hit(mx, my, x + 6, accY, w - 12, 32);
      if (overAcc) {
         SmoothRect.fill(ctx, x + 6, accY, w - 12, 32, 16.0F, XKit.HOVER);
      }
      XKit.avatar(ctx, s.skinName() != null ? s.skinName() : s.username(),
         x + 11, accY + 6, 20.0F);

      float nameX = x + 36;
      float nameMax = w - 42;

      /*
       * The account card showed the avatar but no name.
       *
       * Two causes, both fixed here:
       *  - username() can be "" for a moment after a resumed session (the
       *    profile row lands a round trip after loggedIn() turns true), and
       *    drawing an empty string looks exactly like a broken renderer;
       *  - the name colour came from NameColor.primary(), so a Blue+ user
       *    whose stored colour failed to parse could render at an unreadable
       *    value. The card now falls back to XKit.TEXT whenever the parsed
       *    colour has no alpha.
       */
      String shownName = s.profileReady() ? s.username() : "Signing in...";
      int nameCol = XKit.TEXT;
      if (s.plus() && s.nameColor() != null && !s.nameColor().isBlank()) {
         int parsed = NameColor.primary(s.nameColor(), XKit.TEXT);
         if ((parsed >>> 24) != 0) {
            nameCol = parsed;
         }
      }

      String fitName = XKit.fit(shownName, nameMax - 16, 8.5F);
      TextPainter.drawPoppins(ctx, fitName, nameX, accY + 6, nameCol, 8.5F);

      float vx = nameX + TextPainter.poppinsWidth(fitName, 8.5F) + 2;
      if (s.verified()) {
         vx += VerifiedBadge.draw(ctx, vx, accY + 5, 8.0F) + 2;
      }
      if (s.plus()) {
         BluePlusIcon.draw(ctx, vx, accY + 5, 8.0F);
      }
      if (s.profileReady()) {
         TextPainter.drawPoppins(ctx, XKit.fit("@" + s.username().toLowerCase(
            java.util.Locale.ROOT), nameMax, 7.5F), nameX, accY + 18,
            XKit.MUTED, 7.5F);
      }
      // Clicking your own name opens your profile page, which is what every
      // social app does - Settings has its own rail entry.
      this.hits.add(new Hit(x + 6, accY, w - 12, 32, "myprofile"));
   }

   /**
    * The sticky header above the centre column: the page title, plus the
    * For You / Following switcher when we are on the timeline.
    *
    * @return the height it consumed
    */
   private float drawFeedHeader(DrawContext ctx, float x, float y, float w,
                                int mx, int my) {
      /*
       * One title, one back arrow, decided ONCE.
       *
       * The old code drew the tab title and then drew "Post" on top of it for
       * a thread, so two strings overlapped at nearly the same x - the
       * intersecting text the owner reported. Now the sub-page owns the
       * header outright when one is open.
       */
      boolean thread = "POSTS".equals(this.tab) && this.threadId != null;
      boolean profile = "PROFILE".equals(this.tab);
      boolean chat = "CHATS".equals(this.tab) && this.chatId != null;
      boolean sub = thread || profile || chat;

      String title;
      String subtitle = null;
      if (thread) {
         title = "Post";
      } else if (profile) {
         title = this.viewProfile != null ? this.viewProfile.username() : "Profile";
         subtitle = this.viewProfile != null
            ? XKit.compact(this.viewProfile.postCount()) + " posts" : null;
      } else if (chat) {
         title = "Messages";
      } else {
         title = switch (this.tab) {
            case "POSTS" -> "Home";
            case "ACTIVITY" -> "Notifications";
            case "CHATS" -> "Messages";
            case "REQUESTS" -> "Requests";
            case "SEARCH" -> "Explore";
            case "TOP" -> "Top";
            case "BLUE+" -> "Blue+";
            case "BLOCKED" -> "Blocked";
            case "PRIVACY" -> "Settings";
            case "ADMIN" -> "Admin";
            case "EDIT" -> "Edit profile";
            case "RULES" -> "Rules";
            default -> "Friends";
         };
      }

      float titleX = x + 14;
      if (sub) {
         boolean overB = hit(mx, my, x + 8, y + 8, 18, 18);
         if (overB) {
            SmoothRect.fill(ctx, x + 8, y + 8, 18, 18, 9.0F, XKit.HOVER);
         }
         RenderUtil.drawIcon(ctx, "chevron-down", (int) (x + 12), (int) (y + 12),
            10, XKit.TEXT);
         this.hits.add(new Hit(x + 8, y + 8, 18, 18,
            thread ? "threadback" : (profile ? "profileback" : "chatback")));
         titleX = x + 30;
      }

      TextPainter.drawPoppins(ctx, XKit.fit(title, w - (titleX - x) - 14, 11.0F),
         titleX, subtitle == null ? y + 12 : y + 7, XKit.TEXT, 11.0F);
      if (subtitle != null) {
         TextPainter.drawPoppins(ctx, subtitle, titleX, y + 20, XKit.MUTED, 7.0F);
      }

      float hh = 30.0F;

      if ("POSTS".equals(this.tab) && this.threadId == null) {
         boolean forYou = social().feedMode() == FriendsManager.FeedMode.FOR_YOU;
         float half = w / 2.0F;
         segTab(ctx, "For you", x, y + hh, half, mx, my, "feed:foryou", forYou);
         segTab(ctx, "Following", x + half, y + hh, half, mx, my,
            "feed:following", !forYou);
         hh += 24.0F;
      }

      XKit.divider(ctx, x + 1, y + hh, w - 2);
      return hh + 1.0F;
   }

   /**
    * One half of the For You / Following switcher.
    *
    * <p>X underlines the active one with a short accent bar centred under the
    * label, rather than filling a pill - that underline is a big part of the
    * look.</p>
    */
   private void segTab(DrawContext ctx, String label, float x, float y, float w,
                       int mx, int my, String tag, boolean active) {
      boolean over = hit(mx, my, x, y, w, 24);
      float hov = Anim.to("seg:" + tag, over);
      float sel = Anim.to("segsel:" + tag, active);

      if (hov > 0.01F) {
         SmoothRect.fill(ctx, x, y, w, 24, 0.0F,
            Anim.mixColor(0x00000000, XKit.HOVER, hov));
      }

      float size = 8.5F;
      float tw = TextPainter.poppinsWidth(label, size);
      TextPainter.drawPoppins(ctx, label, x + (w - tw) / 2.0F, y + 7,
         Anim.mixColor(XKit.MUTED, XKit.TEXT, sel), size);

      if (sel > 0.01F) {
         // The bar grows out from the centre as it activates.
         float barW = (tw + 8) * sel;
         SmoothRect.fill(ctx, x + (w - barW) / 2.0F, y + 21, barW, 2.5F, 1.25F,
            XKit.BLUE);
      }
      this.hits.add(new Hit(x, y, w, 24, tag));
   }

   /**
    * The right sidebar: live counters and who to follow, X's third column.
    *
    * <p>Hidden automatically when the panel is too narrow, so a small window
    * degrades to two columns instead of crushing all three.</p>
    */
   private void drawSidebar(DrawContext ctx, float x, float y, float w, float h,
                            int mx, int my) {
      FriendsManager s = social();
      float cx = x + 10;
      float cw = w - 20;
      float cy = y + 12;

      /* ---- your stats ---- */
      SmoothRect.fill(ctx, cx, cy, cw, 54, 8.0F, XKit.SURFACE);
      TextPainter.drawPoppins(ctx, "Your profile", cx + 10, cy + 8,
         XKit.TEXT, 9.0F);

      String[][] stats = {
         {XKit.compact(s.followers()), "Followers"},
         {XKit.compact(s.following()), "Following"},
         {String.valueOf(s.friends().size()), "Friends"}};
      float col = cw / 3.0F;
      for (int i = 0; i < stats.length; i++) {
         float sx = cx + col * i;
         float nw = TextPainter.poppinsWidth(stats[i][0], 9.5F);
         TextPainter.drawPoppins(ctx, stats[i][0], sx + (col - nw) / 2.0F,
            cy + 24, XKit.TEXT, 9.5F);
         float lw = TextPainter.poppinsWidth(stats[i][1], 6.5F);
         TextPainter.drawPoppins(ctx, stats[i][1], sx + (col - lw) / 2.0F,
            cy + 37, XKit.MUTED, 6.5F);
      }
      cy += 62;

      /* ---- verified progress, if not yet verified ---- */
      if (!s.verified()) {
         SmoothRect.fill(ctx, cx, cy, cw, 44, 8.0F, XKit.SURFACE);
         TextPainter.drawPoppins(ctx, "Get verified", cx + 10, cy + 8,
            XKit.TEXT, 9.0F);
         long have = s.followers();
         float pct = Math.min(1.0F, have / 100.0F);
         SmoothRect.fill(ctx, cx + 10, cy + 23, cw - 20, 4, 2.0F, XKit.DIVIDER);
         SmoothRect.fill(ctx, cx + 10, cy + 23, (cw - 20) * pct, 4, 2.0F, XKit.BLUE);
         TextPainter.drawPoppins(ctx, have + " / 100 followers", cx + 10, cy + 32,
            XKit.MUTED, 7.0F);
         cy += 52;
      }

      /* ---- who to follow: the leaderboard, reframed ---- */
      java.util.List<FriendsManager.LeaderRow> top = s.leaders();
      if (!top.isEmpty()) {
         float cardH = Math.min(h - (cy - y) - 12, 26 + top.size() * 28.0F);
         SmoothRect.fill(ctx, cx, cy, cw, cardH, 8.0F, XKit.SURFACE);
         TextPainter.drawPoppins(ctx, "Who to follow", cx + 10, cy + 8,
            XKit.TEXT, 9.0F);

         float ry = cy + 24;
         for (FriendsManager.LeaderRow r : top) {
            if (ry + 26 > cy + cardH) {
               break;
            }
            boolean over = hit(mx, my, cx, ry, cw, 26);
            if (over) {
               SmoothRect.fill(ctx, cx, ry, cw, 26, 0.0F, XKit.HOVER);
            }
            XKit.avatar(ctx, r.avatarName(), cx + 8, ry + 4, 18.0F);

            float nx = cx + 30;
            int ncol = NameColor.primary(r.color(), XKit.TEXT);
            String nm = XKit.fit(r.username(), cw - 44, 8.0F);
            TextPainter.drawPoppins(ctx, nm, nx, ry + 5, ncol, 8.0F);
            float bx = nx + TextPainter.poppinsWidth(nm, 8.0F) + 2;
            if (r.verified()) {
               bx += VerifiedBadge.draw(ctx, bx, ry + 4, 8.0F) + 2;
            }
            if (r.plus()) {
               BluePlusIcon.draw(ctx, bx, ry + 4, 8.0F);
            }
            TextPainter.drawPoppins(ctx,
               XKit.compact(r.followers()) + " followers", nx, ry + 15,
               XKit.MUTED, 6.5F);

            this.hits.add(new Hit(cx, ry, cw, 26,
               r.id() != null ? "profile:" + r.id() : "profilename:" + r.username()));
            ry += 28;
         }
      }
   }

   /* ---------------------------------------------------------------- AUTH */

   private void drawAuth(DrawContext ctx, float px, float y, float pw, float ph, int mx, int my) {
      float cx = px + pw / 2.0F;
      float fw = 220.0F;
      float fx = cx - fw / 2.0F;
      float fy = y + 28.0F;

      centered(ctx, this.registerMode ? "Create a Blue Client account" : "Log in to Blue Client",
         cx, fy - 18.0F, XKit.TEXT, 10.0F);
      centered(ctx,
         "No Minecraft or Microsoft account needed.",
         cx, fy - 5.0F, XKit.MUTED, 7.5F);

      field(ctx, "user", "Username", this.fieldUser, fx, fy + 10, fw, mx, my, false);
      field(ctx, "pass", "Password", this.fieldPass, fx, fy + 38, fw, mx, my, true);

      FriendsManager s = social();
      String btn = s.busy() ? "PLEASE WAIT..." : (this.registerMode ? "CREATE ACCOUNT" : "LOG IN");
      button(ctx, btn, fx, fy + 70, fw, 20, mx, my, "submit", !s.busy());

      String alt = this.registerMode
         ? "Already have an account? Log in"
         : "New here? Create an account";
      float aw = TextPainter.poppinsWidth(alt, 8.0F);
      TextPainter.drawPoppins(ctx, alt, cx - aw / 2.0F, fy + 97, XKit.BLUE, 8.0F);
      this.hits.add(new Hit(cx - aw / 2.0F, fy + 95, aw, 12, "togglemode"));

      if (this.registerMode) {
         centered(ctx, "Pick any username - it is separate from your Minecraft name.",
            cx, fy + 114, XKit.MUTED, 7.0F);
      }
   }

   /* ------------------------------------------------------------- FRIENDS */

   private void drawFriends(DrawContext ctx, float px, float y, float pw, float ph,
                            int mx, int my) {
      List<FriendsManager.Friend> list = social().friends();
      if (list.isEmpty()) {
         emptyState(ctx, px, y, pw, ph, "users", "No friends yet",
            "Find players by username in Explore, then send them a request.");
         return;
      }

      float rowH = 44.0F;
      float ry = y - this.scroll;
      for (FriendsManager.Friend f : list) {
         if (ry + rowH > y && ry < y + ph) {
            drawFriendRow(ctx, f, px, ry, pw, rowH, mx, my);
         }
         ry += rowH;
      }
      clampScroll(ry + this.scroll - (y + ph));
   }

   /**
    * One friend, laid out like an X "who to follow" row.
    *
    * <p>Full-bleed with a hairline underneath - no card, no border. Actions
    * are icon buttons that appear on hover instead of five permanent text
    * buttons, which is what made the old row look like a toolbar.</p>
    */
   private void drawFriendRow(DrawContext ctx, FriendsManager.Friend f,
                              float x, float y, float w, float h, int mx, int my) {
      boolean over = hit(mx, my, x, y, w, h);
      float hov = Anim.to("friend:" + f.id(), over);
      if (hov > 0.01F) {
         SmoothRect.fill(ctx, x, y, w, h, 0.0F,
            Anim.mixColor(0x00000000, XKit.HOVER, hov));
      }

      float av = 30.0F;
      XKit.avatar(ctx, f.avatarName(), x + 11, y + 7, av);

      // Presence dot on the avatar corner, ringed in the page colour so it
      // reads as a separate object rather than a smudge on the skin.
      float dot = 8.0F;
      float dx = x + 11 + av - dot;
      float dy = y + 7 + av - dot;
      SmoothRect.fill(ctx, dx - 1, dy - 1, dot + 2, dot + 2, (dot + 2) / 2.0F, XKit.BG);
      SmoothRect.fill(ctx, dx, dy, dot, dot, dot / 2.0F,
         f.online() ? XKit.GREEN : XKit.MUTED);

      float nameX = x + 11 + av + 9;
      // Reserve room for the action cluster so long names never collide.
      float nameMax = w - (nameX - x) - 112;

      int nameCol = NameColor.primary(f.nameColor(), XKit.TEXT);
      String nm = XKit.fit(f.username(), nameMax, 9.0F);
      TextPainter.drawPoppins(ctx, nm, nameX, y + 10, nameCol, 9.0F);
      float bx = nameX + TextPainter.poppinsWidth(nm, 9.0F) + 3;

      if (f.verified()) {
         bx += VerifiedBadge.draw(ctx, bx, y + 9, 9.0F) + 2;
      }
      if (f.plus()) {
         bx += BluePlusIcon.draw(ctx, bx, y + 9, 9.0F) + 2;
      }
      if (f.badge() != null) {
         badgeWithTooltip(ctx, f.badge(), bx, y + 9, 10.0F, mx, my);
      }

      String sub;
      if (f.online()) {
         sub = f.server() == null ? "Online" : "Playing on " + f.server();
      } else {
         sub = f.lastSeen() == null
            ? "Offline" : "Last seen " + FriendsManager.relativeTime(f.lastSeen());
      }
      TextPainter.drawPoppins(ctx, XKit.fit(sub, nameMax, 7.5F), nameX, y + 23,
         XKit.MUTED, 7.5F);

      /* ---- actions, right aligned, icon-only ---- */
      float ax = x + w - 14;
      boolean confirming = f.id().equals(this.confirmRemoveId);

      ax -= 22;
      iconAction(ctx, "x", ax, y + 12, mx, my,
         (confirming ? "doremove:" : "askremove:") + f.id(),
         confirming ? XKit.RED : XKit.MUTED, true,
         confirming ? "Click again to remove" : "Remove friend");

      ax -= 22;
      iconAction(ctx, "lock", ax, y + 12, mx, my, "block:" + f.id(),
         XKit.MUTED, true, "Block");

      ax -= 22;
      iconAction(ctx, "message-square", ax, y + 12, mx, my, "dm:" + f.id(),
         XKit.BLUE, true, "Message");

      // JOIN only when they are actually on a joinable server.
      boolean canJoin = f.online() && f.server() != null
         && !"Singleplayer".equals(f.server());
      ax -= 22;
      iconAction(ctx, "send", ax, y + 12, mx, my, "join:" + f.id(),
         XKit.GREEN, canJoin, canJoin ? "Join their server" : "Not joinable");

      ax -= 22;
      iconAction(ctx, "plus", ax, y + 12, mx, my, "invite:" + f.id(),
         XKit.GREEN, f.online(), "Invite to your world");

      // Name area opens the profile; the row itself does nothing, so the
      // action icons are never swallowed by a full-row hit box.
      this.hits.add(new Hit(nameX, y + 6, nameMax, 26, "profile:" + f.id()));

      XKit.divider(ctx, x + 1, y + h - 1, w - 2);
   }

   /**
    * Draws a badge image and queues its name + description on hover.
    *
    * @return the width drawn
    */
   private float badgeWithTooltip(DrawContext ctx, String badgeId, float x,
                                  float y, float size, int mx, int my) {
      net.bluenetwork.client.ui.BadgeArt.drawImage(ctx, badgeId, x, y, size);
      if (hit(mx, my, x, y, size, size)) {
         String label = social().badgeLabel(badgeId);
         String desc = net.bluenetwork.client.ui.BadgeArt.describe(badgeId);
         this.pendingTooltip = desc == null ? label : label + "\n" + desc;
         this.tooltipX = x + size / 2.0F;
         this.tooltipY = y - 3;
      }
      return size;
   }

   /**
    * A circular icon button with a hover disc and a tooltip.
    *
    * @param enabled when false it is dimmed and does not register a hit
    */
   private void iconAction(DrawContext ctx, String icon, float x, float y,
                           int mx, int my, String tag, int accent,
                           boolean enabled, String tooltip) {
      float d = 18.0F;
      boolean over = enabled && hit(mx, my, x, y, d, d);
      float hov = Anim.to("ia:" + tag, over);

      if (hov > 0.01F) {
         SmoothRect.fill(ctx, x, y, d, d, d / 2.0F,
            Anim.mixColor(0x00000000, XKit.alpha(accent, 0.15F), hov));
      }
      int col = enabled
         ? Anim.mixColor(XKit.MUTED, accent, hov)
         : XKit.alpha(XKit.MUTED, 0.35F);
      RenderUtil.drawIcon(ctx, icon, Math.round(x + 4), Math.round(y + 4), 10, col);

      if (enabled) {
         this.hits.add(new Hit(x, y, d, d, tag));
         if (over && tooltip != null) {
            this.pendingTooltip = tooltip;
            this.tooltipX = x + d / 2.0F;
            this.tooltipY = y - 4;
         }
      }
   }

   /* --------------------------------------------------------------- POSTS */

   /**
    * The public timeline.
    *
    * <p>Everyone sees everyone's posts, X-style. The composer at the top
    * enforces the tier limit <i>locally</i> so the counter turns red before a
    * doomed request is sent - the server truncates and rate-limits anyway.</p>
    */
   private void drawPosts(DrawContext ctx, float px, float y, float pw, float ph,
                          int mx, int my) {
      FriendsManager s = social();
      int cap = s.limitOf("post");

      // A post's reply thread takes over the column when open. The For You /
      // Following switcher lives in the sticky header now, not here.
      if (this.threadId != null) {
         drawThread(ctx, px, y, pw, ph, mx, my);
         return;
      }

      /* ---- composer: avatar + inline field, exactly like X's "What's happening?" ---- */
      float compH = 40.0F;
      XKit.avatar(ctx, s.skinName() != null ? s.skinName() : s.username(),
         px + 11, y + 8, 26.0F);

      float fx = px + 45;
      float fw = pw - (fx - px) - 60;
      boolean focused = "post".equals(this.focus);
      String shown = this.draftPost.isEmpty() && !focused
         ? "What's happening?" : this.draftPost;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, fw, 9.5F), fx, y + 14,
         this.draftPost.isEmpty() && !focused ? XKit.MUTED : XKit.TEXT, 9.5F);
      if (focused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         float cw2 = TextPainter.poppinsWidth(XKit.fit(shown, fw, 9.5F), 9.5F);
         SmoothRect.fill(ctx, fx + cw2 + 1, y + 13, 1.0F, 11.0F, 0.0F, XKit.BLUE);
      }
      this.hits.add(new Hit(fx, y + 6, fw, 24, "focus:post"));

      int used = this.draftPost.length();
      boolean canPost = used > 0 && used <= cap && !s.busy();

      // Character budget as a ring-style counter, shown only once you type -
      // X hides it until it matters.
      if (used > 0) {
         String counter = String.valueOf(cap - used);
         float cwid = TextPainter.poppinsWidth(counter, 7.0F);
         TextPainter.drawPoppins(ctx, counter, px + pw - 62 - cwid, y + 16,
            used > cap ? XKit.RED : XKit.MUTED, 7.0F);
      }

      boolean overPost = hit(mx, my, px + pw - 58, y + 9, 46, 20);
      float pillA = canPost ? 1.0F : 0.45F;
      XKit.pill(ctx, "Post", px + pw - 58, y + 9, 46, 20, overPost && canPost,
         true, XKit.alpha(XKit.BLUE, pillA), "composer:post");
      if (canPost) {
         this.hits.add(new Hit(px + pw - 58, y + 9, 46, 20, "dopost"));
      }

      if (this.postNotice != null) {
         TextPainter.drawPoppins(ctx, this.postNotice, fx, y + 30, XKit.RED, 7.0F);
         compH += 10;
      }

      XKit.divider(ctx, px + 1, y + compH, pw - 2);

      /* ---- timeline ---- */
      float listY = y + compH + 1;
      float listH = ph - (listY - y);
      List<FriendsManager.Post> posts = s.feed();

      if (posts.isEmpty()) {
         boolean forYou = s.feedMode() == FriendsManager.FeedMode.FOR_YOU;
         emptyState(ctx, px, listY, pw, listH, "home",
            forYou ? "Nothing here yet" : "Your timeline is quiet",
            forYou
               ? "Posts from across Blue Client will appear here as people start posting."
               : "Follow people and their posts will show up in this tab.");
         return;
      }

      float ry = listY - this.scroll;

      // The pinned post sits above everything, on both feeds, with a label -
      // Blue and Cyan can pin exactly one and it is meant to be seen.
      FriendsManager.Post pin = s.pinnedPost();
      if (pin != null) {
         float ph2 = postHeight(pin, pw) + 12;
         if (ry + ph2 > listY && ry < listY + listH) {
            SmoothRect.fill(ctx, px, ry, pw, ph2, 0.0F,
               XKit.alpha(XKit.GOLD, 0.06F));
            RenderUtil.drawIcon(ctx, "sparkles", (int) (px + 30), (int) (ry + 4),
               8, XKit.GOLD);
            TextPainter.drawPoppins(ctx, "Pinned by Blue Client", px + 41, ry + 4.5F,
               XKit.GOLD, 7.0F);
            drawPostRow(ctx, pin, px, ry + 12, pw, postHeight(pin, pw), mx, my);
         }
         ry += ph2;
      }

      for (FriendsManager.Post post : posts) {
         float rowH = postHeight(post, pw);
         if (ry + rowH > listY && ry < listY + listH) {
            drawPostRow(ctx, post, px, ry, pw, rowH, mx, my);
         }
         ry += rowH;
      }
      clampScroll(ry + this.scroll - (listY + listH));
   }

   /** One pill in the For You / Following switcher. */
   private void feedTab(DrawContext ctx, String label, float x, float y, float w,
                        int mx, int my, String tag, boolean active) {
      boolean over = hit(mx, my, x, y, w, 16);
      float sel = Anim.to("feedsel:" + tag, active);
      float hov = Anim.to("feedhov:" + tag, over && !active);
      if (hov > 0.01F) {
         SmoothRect.fill(ctx, x, y, w, 16, 8.0F,
            Anim.mixColor(0x00000000, 0x22FFFFFF, hov));
      }
      if (sel > 0.01F) {
         SmoothRect.fill(ctx, x, y, w, 16, 8.0F,
            Anim.mixColor(0x00000000, XKit.BLUE, sel));
      }
      float tw = TextPainter.poppinsWidth(label, 7.5F);
      TextPainter.drawPoppins(ctx, label, x + (w - tw) / 2.0F, y + 4,
         Anim.mixColor(XKit.MUTED, 0xFFFFFFFF, sel), 7.5F);
      this.hits.add(new Hit(x, y, w, 16, tag));
   }

   /**
    * The reply thread for one post: the parent, then its replies, then a
    * reply box pinned to the bottom.
    */
   private void drawThread(DrawContext ctx, float px, float y, float pw, float ph,
                           int mx, int my) {
      FriendsManager s = social();

      // The back arrow lives in the sticky header now.
      // The parent post, if it is still in the loaded feed.
      FriendsManager.Post parent = null;
      for (FriendsManager.Post p : s.feed()) {
         if (p.id().equals(this.threadId)) {
            parent = p;
            break;
         }
      }

      float ry = y;
      if (parent != null) {
         float h = postHeight(parent, pw);
         drawPostRow(ctx, parent, px, ry, pw, h, mx, my);
         ry += h;
      }

      /* ---- replies ---- */
      float listY = ry;
      float boxH = 26.0F;
      float listH = Math.max(20.0F, (y + ph) - listY - boxH - 6);

      java.util.List<FriendsManager.Post> list = s.replies();
      if (list.isEmpty()) {
         centered(ctx, "No replies yet - be the first.", px + pw / 2.0F,
            listY + 10, XKit.MUTED, 8.0F);
      } else {
         float cy = listY - this.scroll;
         for (FriendsManager.Post r : list) {
            float rh = postHeight(r, pw - 16);
            if (cy + rh > listY && cy < listY + listH) {
               // Replies are indented, as a thread should be.
               drawPostRow(ctx, r, px + 16, cy, pw - 16, rh, mx, my);
            }
            cy += rh;
         }
         clampScroll(cy + this.scroll - (listY + listH));
      }

      /* ---- reply box ---- */
      float by = y + ph - boxH;
      int cap = s.limitOf("post");
      field(ctx, "reply", "Write a reply...", this.draftReply,
         px + 10, by, pw - 82, mx, my, false);
      button(ctx, "REPLY", px + pw - 66, by, 56, 20, mx, my, "sendreply",
         !this.draftReply.isBlank() && this.draftReply.length() <= cap && !s.busy());

      if (this.replyNotice != null) {
         TextPainter.drawPoppins(ctx, this.replyNotice, px + 10, by - 9, XKit.RED, 7.0F);
      }
   }

   /** Height a post card needs, given its wrapped body. */
   private float postHeight(FriendsManager.Post post, float w) {
      float textW = w - 22 - AV - 8;
      int lines = Math.max(1, XKit.wrap(post.body(), textW, 8.5F, 6).size());
      float h = 10 + 12 + lines * 11.0F + 6 + 18;
      return post.boostedBy() != null ? h + 12 : h;
   }

   /** Avatar size in a post card. */
   private static final float AV = 28.0F;

   /**
    * One post, laid out exactly like an X timeline item.
    *
    * <p>The structure is what matters: a fixed avatar gutter on the left, then
    * a single content column holding the author line, the wrapped body, and
    * the action row. Because everything shares one left edge, a column of
    * posts reads as a feed rather than as a list of boxes. The card itself has
    * no border or fill - X separates items with a hairline only.</p>
    */
   private void drawPostRow(DrawContext ctx, FriendsManager.Post post,
                            float x, float y, float w, float h, int mx, int my) {
      boolean over = hit(mx, my, x, y, w, h);
      float hov = Anim.to("post:" + post.id(), over);
      if (hov > 0.01F) {
         SmoothRect.fill(ctx, x, y, w, h, 0.0F,
            Anim.mixColor(0x00000000, XKit.HOVER, hov));
      }

      float top = y + 8;

      // "X reposted" context line, above everything, in muted small caps.
      if (post.boostedBy() != null) {
         RenderUtil.drawIcon(ctx, "share-2", (int) (x + 30), (int) (top), 8,
            XKit.MUTED);
         TextPainter.drawPoppins(ctx, post.boostedBy() + " reposted",
            x + 41, top + 0.5F, XKit.MUTED, 7.0F);
         top += 12;
      }

      XKit.avatar(ctx, post.avatarName(), x + 11, top, AV);

      float colX = x + 11 + AV + 8;
      float colW = w - (colX - x) - 11;

      /* ---- author line: name, badges, @handle, dot, age ---- */
      float nx = colX;
      int nameCol = NameColor.primary(post.color(), XKit.TEXT);
      String name = XKit.fit(post.author(), colW * 0.45F, 8.5F);
      TextPainter.drawPoppins(ctx, name, nx, top, nameCol, 8.5F);
      nx += TextPainter.poppinsWidth(name, 8.5F) + 3;

      if (post.verified()) {
         nx += VerifiedBadge.draw(ctx, nx, top - 0.5F, 9.0F) + 1;
      }
      if (post.plus()) {
         nx += BluePlusIcon.draw(ctx, nx, top - 0.5F, 9.0F) + 1;
      }
      if (post.badge() != null) {
         // Snug against the name: a wide gap made the badge look like it
         // belonged to the timestamp rather than the author.
         nx += badgeWithTooltip(ctx, post.badge(), nx, top - 0.5F, 10.0F,
            mx, my) + 1;
      }

      String handle = "@" + post.author().toLowerCase(java.util.Locale.ROOT);
      String age = XKit.shortAge(post.at());
      String meta = XKit.fit(handle, colW - (nx - colX) - 34, 7.5F)
         + "  \u00b7  " + age;
      TextPainter.drawPoppins(ctx, meta, nx, top + 1, XKit.MUTED, 7.5F);

      /* ---- body, wrapped ---- */
      float by = top + 12;
      for (String line : XKit.wrap(post.body(), colW, 8.5F, 6)) {
         TextPainter.drawPoppins(ctx, line, colX, by, XKit.TEXT, 8.5F);
         by += 11.0F;
      }

      /* ---- action row: reply, repost, like. No share - owner removed it. ---- */
      float ay = by + 4;
      float ax = colX - 4;
      boolean oRep = hit(mx, my, ax, ay, 30, 17);
      ax += XKit.action(ctx, "message-square", post.replies(), ax, ay, oRep,
         false, XKit.BLUE, "act:r:" + post.id());
      this.hits.add(new Hit(ax - 44, ay, 44, 17, "reply:" + post.id()));

      boolean oBoost = hit(mx, my, ax, ay, 30, 17);
      ax += XKit.action(ctx, "share-2", post.reposts(), ax, ay, oBoost,
         post.reposted(), XKit.GREEN, "act:b:" + post.id());
      this.hits.add(new Hit(ax - 44, ay, 44, 17, "repost:" + post.id()));

      boolean oLike = hit(mx, my, ax, ay, 30, 17);
      ax += XKit.action(ctx, "flame", post.likes(), ax, ay, oLike,
         post.liked(), XKit.PINK, "act:l:" + post.id());
      this.hits.add(new Hit(ax - 44, ay, 44, 17, "like:" + post.id()));

      // Report, on other people's posts only.
      if (!post.author().equalsIgnoreCase(social().username())) {
         iconAction(ctx, "flag", x + w - 76, ay - 1, mx, my,
            "report:" + post.id(), XKit.MUTED, true, "Report this post");
      }

      // Pin / unpin, Blue and Cyan only. The server re-checks is_staff(), so
      // a modified client gains nothing by drawing this button.
      if (social().staff()) {
         boolean isPinned = social().pinnedPost() != null
            && social().pinnedPost().id().equals(post.id());
         iconAction(ctx, "sparkles", x + w - 52, ay - 1, mx, my,
            (isPinned ? "unpinpost" : "pinpost:") + (isPinned ? "" : post.id()),
            XKit.GOLD, true, isPinned ? "Unpin this post" : "Pin for everyone");
      }

      // Only your own posts can be deleted, and it sits far right so it is
      // never next to the actions you press constantly.
      if (post.author().equalsIgnoreCase(social().username())) {
         boolean oDel = hit(mx, my, x + w - 30, ay - 1, 18, 18);
         if (oDel) {
            SmoothRect.fill(ctx, x + w - 30, ay - 1, 18, 18, 9.0F,
               XKit.alpha(XKit.RED, 0.15F));
         }
         RenderUtil.drawIcon(ctx, "x", (int) (x + w - 26), (int) (ay + 3), 10,
            oDel ? XKit.RED : XKit.MUTED);
         this.hits.add(new Hit(x + w - 30, ay - 1, 18, 18, "delpost:" + post.id()));
      }

      // Clicking anywhere else on the card opens the thread, like X.
      this.hits.add(new Hit(x, y, w, h, "reply:" + post.id()));
      this.hits.add(new Hit(colX, top - 2, TextPainter.poppinsWidth(name, 8.5F),
         11, "profilename:" + post.author()));

      XKit.divider(ctx, x + 1, y + h - 1, w - 2);
   }

   /** Opens a conversation as a page and loads its messages. */
   private void openChat(String convId) {
      if (convId == null) {
         return;
      }
      this.tab = "CHATS";
      this.chatId = convId;
      this.draftChat = "";
      this.scroll = 0.0F;
      reloadChat(convId);
   }

   /** Reloads one conversation's messages, ignoring stale responses. */
   private void reloadChat(String convId) {
      social().loadMessages(convId, list -> {
         if (convId.equals(this.chatId)) {
            this.chatMessages = list;
            this.chatLoadedAt = System.currentTimeMillis();
         }
      });
      social().markRead(convId);
   }

   /**
    * A conversation as a PAGE, replacing the old ChatScreen popup.
    *
    * <p>Messages are bubbles: yours right-aligned in the accent colour, theirs
    * left-aligned on a surface, which is what every chat app does and what
    * makes a thread readable at a glance.</p>
    */
   private void drawChatPage(DrawContext ctx, float px, float y, float pw,
                             float ph, int mx, int my) {
      FriendsManager s = social();

      /* ---- header row: back, title ---- */
      boolean overBack = hit(mx, my, px + 8, y + 4, 18, 18);
      if (overBack) {
         SmoothRect.fill(ctx, px + 8, y + 4, 18, 18, 9.0F, XKit.HOVER);
      }
      RenderUtil.drawIcon(ctx, "chevron-down", (int) (px + 12), (int) (y + 8),
         10, XKit.TEXT);
      this.hits.add(new Hit(px + 8, y + 4, 18, 18, "chatback"));

      String title = "Conversation";
      for (FriendsManager.Conversation c : s.conversations()) {
         if (c.id().equals(this.chatId)) {
            title = c.title();
            break;
         }
      }
      XKit.avatar(ctx, title, px + 30, y + 3, 20.0F);
      TextPainter.drawPoppins(ctx, XKit.fit(title, pw - 70, 9.0F), px + 56, y + 8,
         XKit.TEXT, 9.0F);
      XKit.divider(ctx, px + 1, y + 26, pw - 2);

      /* ---- messages ---- */
      float boxH = 26.0F;
      float listY = y + 27;
      float listH = ph - (listY - y) - boxH - 4;

      java.util.List<FriendsManager.Message> msgs = this.chatMessages;
      if (msgs.isEmpty()) {
         centered(ctx, "No messages yet - say hello.", px + pw / 2.0F,
            listY + listH / 2.0F, XKit.MUTED, 8.0F);
      } else {
         String me = s.ownId();
         // Lay the thread out bottom-up so the newest message is always
         // visible without having to scroll to the end first.
         float cy = listY + listH - this.scroll;
         for (int i = msgs.size() - 1; i >= 0; i--) {
            FriendsManager.Message m = msgs.get(i);
            boolean mine = me != null && me.equals(m.senderId());
            float maxW = pw * 0.62F;
            java.util.List<String> lines = XKit.wrap(m.body(), maxW - 16, 8.0F, 8);
            float bh = Math.max(18.0F, lines.size() * 10.0F + 8.0F);
            cy -= bh + 4;
            if (cy + bh < listY || cy > listY + listH) {
               continue;
            }

            float bw = 0.0F;
            for (String ln : lines) {
               bw = Math.max(bw, TextPainter.poppinsWidth(ln, 8.0F));
            }
            bw = Math.min(maxW, bw + 16);
            float bxp = mine ? px + pw - bw - 10 : px + 10;

            SmoothRect.fill(ctx, bxp, cy, bw, bh, 7.0F,
               mine ? XKit.BLUE : XKit.SURFACE);
            float ty = cy + 5;
            for (String ln : lines) {
               TextPainter.drawPoppins(ctx, ln, bxp + 8, ty,
                  mine ? 0xFFFFFFFF : XKit.TEXT, 8.0F);
               ty += 10;
            }
         }
         clampScroll((listY + listH - cy) - listH);
      }

      /* ---- composer ---- */
      float by = y + ph - boxH;
      boolean fc = "chat".equals(this.focus);
      XKit.inputBox(ctx, px + 10, by, pw - 76, 22, fc);
      String shown = this.draftChat.isEmpty() && !fc
         ? "Message..." : this.draftChat;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, pw - 96, 8.5F), px + 20, by + 7,
         this.draftChat.isEmpty() && !fc ? XKit.MUTED : XKit.TEXT, 8.5F);
      if (fc && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         float cw = TextPainter.poppinsWidth(XKit.fit(shown, pw - 96, 8.5F), 8.5F);
         SmoothRect.fill(ctx, px + 21 + cw, by + 6, 1.0F, 10.0F, 0.0F, XKit.BLUE);
      }
      this.hits.add(new Hit(px + 10, by, pw - 76, 22, "focus:chat"));

      boolean can = !this.draftChat.isBlank() && !s.busy();
      boolean overSend = hit(mx, my, px + pw - 60, by, 50, 22);
      XKit.pill(ctx, "Send", px + pw - 60, by, 50, 22, overSend && can, true,
         XKit.alpha(XKit.BLUE, can ? 1.0F : 0.4F), "chat:send");
      if (can) {
         this.hits.add(new Hit(px + pw - 60, by, 50, 22, "sendchat"));
      }

      // Poll while the page is open so incoming messages appear live.
      if (System.currentTimeMillis() - this.chatLoadedAt > 3000L) {
         this.chatLoadedAt = System.currentTimeMillis();
         String cid = this.chatId;
         if (cid != null) {
            s.loadMessages(cid, list -> {
               if (cid.equals(this.chatId)) {
                  this.chatMessages = list;
               }
            });
         }
      }
   }

   /**
    * The profile PAGE - a pane, not a popup.
    *
    * <p>Layout borrows from both references the owner sent: Discord's coloured
    * banner with the avatar overlapping its lower edge, and X's identity block
    * (name, handle, bio, join date, follower counts) above a sortable list of
    * that player's posts.</p>
    */
   private void drawProfilePage(DrawContext ctx, float px, float y, float pw,
                                float ph, int mx, int my) {
      FriendsManager.Profile p = this.viewProfile;
      if (p == null) {
         centered(ctx, this.viewProfileLoading ? "Loading..." : "Profile unavailable",
            px + pw / 2.0F, y + ph / 2.0F, XKit.MUTED, 9.0F);
         return;
      }

      float top = y - this.scroll;
      boolean isSelf = p.id().equals(social().ownId());

      /* ================= BANNER ================= */
      // Discord's layout: a coloured banner with the avatar straddling its
      // lower edge. Blue+ members choose the colour; everyone else gets a
      // subtle accent wash rather than flat grey, so the page never looks
      // unfinished.
      float bannerH = 62.0F;
      if (p.profileColor() != null && !p.profileColor().isBlank()) {
         net.bluenetwork.client.ui.ColorStudio.fillSpec(ctx,
            NameColor.parse(p.profileColor(), XKit.SURFACE),
            px, top, pw, bannerH, 0.0F);
      } else {
         net.bluenetwork.client.ui.ColorStudio.fillSpec(ctx,
            NameColor.parse("{\"a\":\"#16181C\",\"b\":\"#1D9BF0\",\"g\":1}",
               XKit.SURFACE),
            px, top, pw, bannerH, 0.0F);
      }
      // Scrim along the bottom so the avatar ring always has contrast.
      SmoothRect.fill(ctx, px, top + bannerH - 14, pw, 14, 0.0F, 0x33000000);

      /* ---- avatar straddling the banner edge ---- */
      float av = 56.0F;
      float avX = px + 18;
      float avY = top + bannerH - av / 2.0F;
      SmoothRect.fill(ctx, avX - 3, avY - 3, av + 6, av + 6, (av + 6) / 2.0F, XKit.BG);
      XKit.avatar(ctx, p.avatarName(), avX, avY, av);

      float dot = 14.0F;
      SmoothRect.fill(ctx, avX + av - dot, avY + av - dot, dot, dot, dot / 2.0F, XKit.BG);
      SmoothRect.fill(ctx, avX + av - dot + 2.5F, avY + av - dot + 2.5F,
         dot - 5, dot - 5, (dot - 5) / 2.0F,
         p.online() ? XKit.GREEN : XKit.MUTED);

      /* ================= ACTION BUTTONS ================= */
      float bx = px + pw - 14;
      float by = top + bannerH + 8;
      if (isSelf) {
         bx -= 82;
         boolean oe = hit(mx, my, bx, by, 82, 24);
         XKit.pill(ctx, "Edit profile", bx, by, 82, 24, oe, false, XKit.BLUE, "pf:edit");
         this.hits.add(new Hit(bx, by, 82, 24, "tab:EDIT"));
      } else {
         bx -= 78;
         boolean of = hit(mx, my, bx, by, 78, 24);
         XKit.pill(ctx, p.isFollowing() ? "Following" : "Follow", bx, by, 78, 24,
            of, !p.isFollowing(), XKit.BLUE, "pf:follow");
         this.hits.add(new Hit(bx, by, 78, 24,
            (p.isFollowing() ? "unfollow:" : "follow:") + p.id()));

         bx -= 32;
         iconAction(ctx, "message-square", bx, by + 3, mx, my, "dm:" + p.id(),
            XKit.BLUE, true, "Message");
         if (!p.isFriend()) {
            bx -= 32;
            iconAction(ctx, "plus", bx, by + 3, mx, my, "request:" + p.id(),
               XKit.GREEN, true, "Add friend");
         }
         bx -= 32;
         iconAction(ctx, "lock", bx, by + 3, mx, my, "block:" + p.id(),
            XKit.MUTED, true, "Block");
      }

      /* ================= IDENTITY ================= */
      float ty = top + bannerH + av / 2.0F + 12;
      float nx = px + 18;

      NameColor.Spec pspec = p.plus()
         ? NameColor.parse(p.nameColor(), XKit.TEXT)
         : NameColor.parse(null, XKit.TEXT);
      float nameW = NamePainter.draw(ctx, p.username(), nx, ty, 15.0F, pspec);
      nx += nameW + 5;

      if (p.verified()) {
         float w = VerifiedBadge.draw(ctx, nx, ty, 12.0F);
         if (hit(mx, my, nx, ty, w, 12.0F)) {
            this.pendingTooltip = "Verified\n100 or more followers";
            this.tooltipX = nx + w / 2.0F;
            this.tooltipY = ty - 2;
         }
         nx += w + 4;
      }
      if (p.plus()) {
         BluePlusIcon.draw(ctx, nx, ty, 12.0F);
         if (hit(mx, my, nx, ty, 12.0F, 12.0F)) {
            this.pendingTooltip = "Blue+\nSince: "
               + FriendsManager.sinceDuration(p.plusSince());
            this.tooltipX = nx + 6;
            this.tooltipY = ty - 2;
         }
         nx += 16;
      }
      if (p.staff()) {
         RenderUtil.drawIcon(ctx, "shield", (int) nx, (int) (ty + 1), 12, XKit.GOLD);
         if (hit(mx, my, nx, ty, 12.0F, 12.0F)) {
            this.pendingTooltip = "Blue Client staff";
            this.tooltipX = nx + 6;
            this.tooltipY = ty - 2;
         }
      }

      TextPainter.drawPoppins(ctx, "@" + p.username().toLowerCase(java.util.Locale.ROOT),
         px + 18, ty + 17, XKit.MUTED, 8.0F);

      float iy = ty + 32;

      /* ================= BADGE ROW ================= */
      /*
       * Badges sit directly under the @handle, not in a separate card further
       * down the page. The old layout put them in their own panel below the
       * identity block, which read as unrelated to the name - the owner's
       * "shown so far away from your name".
       *
       * No background panel either: Discord shows badges as a bare row right
       * beneath the handle, and that is what makes them feel attached to the
       * person rather than to a widget.
       */
      List<FriendsManager.Badge> badges = this.viewBadges;
      if (!badges.isEmpty()) {
         float gx = px + 18;
         for (FriendsManager.Badge b : badges) {
            if (gx + 18 > px + pw - 18) {
               break;                       // one tidy row; overflow is rare
            }
            net.bluenetwork.client.ui.BadgeArt.drawImage(ctx, b.id(), gx, iy, 15.0F);
            if (hit(mx, my, gx, iy, 15.0F, 15.0F)) {
               String desc = b.description() != null && !b.description().isBlank()
                  ? b.description()
                  : net.bluenetwork.client.ui.BadgeArt.describe(b.id());
               this.pendingTooltip = desc == null ? b.label()
                  : b.label() + "\n" + desc;
               this.tooltipX = gx + 7.5F;
               this.tooltipY = iy - 3;
            }
            if (b.id().equals(p.badgeId())) {
               SmoothRect.outline(ctx, gx - 2, iy - 2, 19, 19, 9.5F, 1.0F,
                  XKit.alpha(XKit.BLUE, 0.8F));
            }
            gx += 19;
         }
         iy += 22;
      }

      /* ================= ABOUT ================= */
      if (p.about() != null && !p.about().isBlank()) {
         for (String ln : XKit.wrap(p.about(), pw - 36, 8.5F, 4)) {
            TextPainter.drawPoppins(ctx, ln, px + 18, iy, XKit.TEXT, 8.5F);
            iy += 12;
         }
         iy += 4;
      }
      if (p.status() != null && !p.status().isBlank()) {
         TextPainter.drawPoppins(ctx, "\u201c" + XKit.fit(p.status(), pw - 40, 8.0F)
            + "\u201d", px + 18, iy, XKit.MUTED, 8.0F);
         iy += 16;
      }

      /* ================= META ================= */
      float mxx = px + 18;
      if (p.online() && p.server() != null) {
         RenderUtil.drawIcon(ctx, "server", (int) mxx, (int) iy, 9, XKit.GREEN);
         String sv = XKit.fit(p.server(), 130.0F, 7.5F);
         TextPainter.drawPoppins(ctx, sv, mxx + 12, iy + 0.5F, XKit.GREEN, 7.5F);
         mxx += 12 + TextPainter.poppinsWidth(sv, 7.5F) + 14;
      }
      if (p.joined() > 0L) {
         RenderUtil.drawIcon(ctx, "clock", (int) mxx, (int) iy, 9, XKit.MUTED);
         TextPainter.drawPoppins(ctx,
            "Joined " + FriendsManager.sinceDuration(p.joined()) + " ago",
            mxx + 12, iy + 0.5F, XKit.MUTED, 7.5F);
      }
      iy += 16;

      /* ================= COUNTS ================= */
      iy = countsRow(ctx, p, px, iy, mx, my);
      iy += 4;

      XKit.divider(ctx, px + 1, iy, pw - 2);
      iy += 1;

      /* ================= SORT BAR ================= */
      float sx = px + 12;
      sx += sortChip(ctx, "Newest", "new", sx, iy + 6, mx, my);
      sx += sortChip(ctx, "Oldest", "old", sx, iy + 6, mx, my);
      sortChip(ctx, "Most liked", "top", sx, iy + 6, mx, my);
      iy += 32;
      XKit.divider(ctx, px + 1, iy, pw - 2);
      iy += 1;

      /* ================= THEIR POSTS ================= */
      if (this.viewPosts.isEmpty()) {
         centered(ctx, isSelf ? "You have not posted yet."
            : p.username() + " has not posted yet.",
            px + pw / 2.0F, iy + 24, XKit.MUTED, 8.5F);
         iy += 46;
      } else {
         for (FriendsManager.Post post : this.viewPosts) {
            float rowH = postHeight(post, pw);
            if (iy + rowH > y && iy < y + ph) {
               drawPostRow(ctx, post, px, iy, pw, rowH, mx, my);
            }
            iy += rowH;
         }
      }
      clampScroll(iy + this.scroll - (y + ph));
   }

   /** Following / Followers / Posts, X-style with bold values. */
   private float countsRow(DrawContext ctx, FriendsManager.Profile p,
                           float px, float y, int mx, int my) {
      float cx = px + 18;
      String[][] pairs = {
         {XKit.compact(p.following()), "Following"},
         {XKit.compact(p.followers()), "Followers"},
         {XKit.compact(p.postCount()), "Posts"}};
      for (String[] pair : pairs) {
         TextPainter.drawPoppins(ctx, pair[0], cx, y, XKit.TEXT, 9.0F);
         float vw = TextPainter.poppinsWidth(pair[0], 9.0F);
         TextPainter.drawPoppins(ctx, pair[1], cx + vw + 3, y + 0.5F,
            XKit.MUTED, 8.0F);
         cx += vw + 3 + TextPainter.poppinsWidth(pair[1], 8.0F) + 14;
      }
      return y + 16;
   }

   /** One sort option on the profile's post list. */
   private float sortChip(DrawContext ctx, String label, String key,
                          float x, float y, int mx, int my) {
      float w = TextPainter.poppinsWidth(label, 7.5F) + 18;
      boolean active = key.equals(this.viewSort);
      boolean over = hit(mx, my, x, y, w, 18);
      float sel = Anim.to("sort:" + key, active);
      float hov = Anim.to("sorth:" + key, over && !active);

      SmoothRect.fill(ctx, x, y, w, 18, 9.0F,
         Anim.mixColor(Anim.mixColor(0x00000000, XKit.HOVER, hov),
            XKit.alpha(XKit.BLUE, 0.22F), sel));
      SmoothRect.outline(ctx, x, y, w, 18, 9.0F, 1.0F,
         Anim.mixColor(XKit.DIVIDER, XKit.BLUE, sel));
      float tw = TextPainter.poppinsWidth(label, 7.5F);
      TextPainter.drawPoppins(ctx, label, x + (w - tw) / 2.0F, y + 5.5F,
         Anim.mixColor(XKit.MUTED, XKit.TEXT, sel), 7.5F);
      this.hits.add(new Hit(x, y, w, 18, "sortposts:" + key));
      return w + 6;
   }

   /** Opens a profile as a page and loads it. */
   private void openProfile(String userId) {
      if (userId == null) {
         return;
      }
      if (!"PROFILE".equals(this.tab)) {
         this.profileReturnTab = this.tab;
      }
      this.tab = "PROFILE";
      this.scroll = 0.0F;
      this.viewProfileId = userId;
      this.viewProfile = null;
      this.viewPosts = java.util.List.of();
      this.viewBadges = java.util.List.of();
      this.viewProfileLoading = true;

      social().loadProfile(userId, prof -> {
         // A slower earlier request must not overwrite a newer page.
         if (userId.equals(this.viewProfileId)) {
            this.viewProfile = prof;
            this.viewProfileLoading = false;
         }
      });
      social().loadUserPosts(userId, this.viewSort, list -> {
         if (userId.equals(this.viewProfileId)) {
            this.viewPosts = list;
         }
      });
      social().loadProfileBadges(userId, list -> {
         if (userId.equals(this.viewProfileId)) {
            this.viewBadges = list;
         }
      });
   }

   /* ---- edit-profile state ---- */
   private String editAbout = "";
   private String editStatus = "";
   private String editSkin = "";
   private boolean editLoaded;
   private String editNotice;
   private boolean editOk;

   /**
    * The Edit Profile page.
    *
    * <p>Everything about how you appear, in one place: avatar skin, about,
    * status and the badge picker. Previously "Edit profile" dropped you into
    * the privacy settings, where the skin field was buried and the badge
    * picker lived on a different screen entirely.</p>
    *
    * <p>Each field saves on its own button rather than on every keystroke -
    * each save is a network write, and a live-saving text field would fire one
    * per character typed.</p>
    */
   private void drawEditProfile(DrawContext ctx, float px, float y, float pw,
                                float ph, int mx, int my) {
      FriendsManager s = social();

      // Seed the drafts once from what is saved.
      if (!this.editLoaded && s.profileReady()) {
         this.editLoaded = true;
         this.editAbout = s.about() == null ? "" : s.about();
         this.editStatus = s.status() == null ? "" : s.status();
         this.editSkin = s.skinName() == null ? "" : s.skinName();
      }

      float ly = y + 8 - this.scroll;

      /* ---- live preview, so changes are visible before saving ---- */
      SmoothRect.fill(ctx, px + 12, ly, pw - 24, 52, 8.0F, XKit.SURFACE);
      String previewSkin = this.editSkin.isBlank() ? s.username() : this.editSkin;
      XKit.avatar(ctx, previewSkin, px + 22, ly + 11, 30.0F);

      float nx = px + 60;
      NamePainter.draw(ctx, s.username(), nx, ly + 12, 11.0F,
         s.nameColor(), XKit.TEXT);
      float nw = NamePainter.width(s.username(), 11.0F);
      float bx2 = nx + nw + 4;
      if (s.verified()) {
         bx2 += VerifiedBadge.draw(ctx, bx2, ly + 12, 10.0F) + 3;
      }
      if (s.plus()) {
         bx2 += BluePlusIcon.draw(ctx, bx2, ly + 12, 10.0F) + 3;
      }
      if (s.equippedBadge() != null) {
         badgeWithTooltip(ctx, s.equippedBadge(), bx2, ly + 12, 11.0F, mx, my);
      }
      TextPainter.drawPoppins(ctx,
         this.editStatus.isBlank() ? "No status set" : this.editStatus,
         nx, ly + 30, XKit.MUTED, 7.5F);
      ly += 62;

      /* ---- avatar skin ---- */
      ly = editField(ctx, "Avatar skin", "Any Minecraft username",
         this.editSkin, "editskin", px, ly, pw, mx, my, "saveskin", 16);
      TextPainter.drawPoppins(ctx,
         "Your social avatar is rendered from this name, so it works whether "
            + "or not you own the account.",
         px + 14, ly, XKit.MUTED, 7.0F);
      ly += 18;

      /* ---- status ---- */
      ly = editField(ctx, "Status", "What are you up to?",
         this.editStatus, "editstatus", px, ly, pw, mx, my, "savestatus",
         s.limitOf("status"));

      /* ---- about ---- */
      ly = editField(ctx, "About me", "Tell people about yourself",
         this.editAbout, "editabout", px, ly, pw, mx, my, "saveabout",
         s.limitOf("about"));

      if (this.editNotice != null) {
         TextPainter.drawPoppins(ctx, this.editNotice, px + 14, ly,
            this.editOk ? XKit.GREEN : XKit.RED, 8.0F);
         ly += 16;
      }

      /* ---- badge picker ---- */
      XKit.divider(ctx, px + 12, ly, pw - 24);
      ly += 14;
      TextPainter.drawPoppins(ctx, "Equipped badge", px + 14, ly, XKit.TEXT, 10.0F);
      ly += 15;
      TextPainter.drawPoppins(ctx,
         "One at a time. Hover a badge to see what it means.",
         px + 14, ly, XKit.MUTED, 7.5F);
      ly += 18;

      List<FriendsManager.Badge> owned = s.myBadges();
      if (owned.isEmpty()) {
         TextPainter.drawPoppins(ctx, "You have not earned any badges yet.",
            px + 14, ly, XKit.MUTED, 8.0F);
         ly += 20;
      } else {
         float bxp = px + 14;
         float rowTop = ly;
         float cell = 46.0F;

         // "None" clears the badge.
         boolean noneSel = s.equippedBadge() == null;
         drawBadgeChoice(ctx, null, "None", noneSel, bxp, ly, mx, my);
         bxp += cell;

         for (FriendsManager.Badge b : owned) {
            if (bxp + cell > px + pw - 14) {
               bxp = px + 14;
               ly += cell + 6;
            }
            drawBadgeChoice(ctx, b.id(), b.label(),
               b.id().equals(s.equippedBadge()), bxp, ly, mx, my);
            bxp += cell;
         }
         ly += cell + 10;
         if (ly < rowTop) {
            ly = rowTop + cell + 10;
         }
      }

      clampScroll(ly + this.scroll - (y + ph));
   }

   /** One badge tile in the picker: art, name, selected ring. */
   private void drawBadgeChoice(DrawContext ctx, String badgeId, String label,
                                boolean selected, float x, float y,
                                int mx, int my) {
      boolean over = hit(mx, my, x, y, 40, 40);
      float sel = Anim.to("bc:" + label, selected);
      float hov = Anim.to("bch:" + label, over && !selected);

      SmoothRect.fill(ctx, x, y, 40, 40, 8.0F,
         Anim.mixColor(Anim.mixColor(XKit.SURFACE, XKit.HOVER, hov),
            XKit.alpha(XKit.BLUE, 0.25F), sel));
      SmoothRect.outline(ctx, x, y, 40, 40, 8.0F, 1.0F,
         Anim.mixColor(XKit.DIVIDER, XKit.BLUE, sel));

      if (badgeId == null) {
         RenderUtil.drawIcon(ctx, "x", (int) (x + 13), (int) (y + 8), 14,
            XKit.MUTED);
      } else {
         net.bluenetwork.client.ui.BadgeArt.drawImage(ctx, badgeId,
            x + 10, y + 5, 20.0F);
         if (over) {
            String desc = net.bluenetwork.client.ui.BadgeArt.describe(badgeId);
            this.pendingTooltip = desc == null ? label : label + "\n" + desc;
            this.tooltipX = x + 20;
            this.tooltipY = y - 2;
         }
      }
      String shown = XKit.fit(label, 38.0F, 6.5F);
      float lw = TextPainter.poppinsWidth(shown, 6.5F);
      TextPainter.drawPoppins(ctx, shown, x + (40 - lw) / 2.0F, y + 29,
         selected ? XKit.TEXT : XKit.MUTED, 6.5F);
      this.hits.add(new Hit(x, y, 40, 40, "pickbadge:" + (badgeId == null ? "none" : badgeId)));
   }

   /**
    * A labelled text field with a Save button and a character counter.
    *
    * @return the y below the row
    */
   private float editField(DrawContext ctx, String label, String placeholder,
                           String value, String focusKey, float px, float y,
                           float pw, int mx, int my, String saveTag, int cap) {
      TextPainter.drawPoppins(ctx, label, px + 14, y, XKit.TEXT, 9.0F);

      String counter = value.length() + "/" + cap;
      float cw = TextPainter.poppinsWidth(counter, 7.0F);
      TextPainter.drawPoppins(ctx, counter, px + pw - cw - 14, y + 1,
         value.length() > cap ? XKit.RED : XKit.MUTED, 7.0F);
      y += 14;

      boolean fc = focusKey.equals(this.focus);
      float fw = pw - 90;
      XKit.inputBox(ctx, px + 14, y, fw, 22, fc);
      String shown = value.isEmpty() && !fc ? placeholder : value;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, fw - 18, 8.5F), px + 24, y + 7,
         value.isEmpty() && !fc ? XKit.MUTED : XKit.TEXT, 8.5F);
      if (fc && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         float tw = TextPainter.poppinsWidth(XKit.fit(shown, fw - 18, 8.5F), 8.5F);
         SmoothRect.fill(ctx, px + 25 + tw, y + 6, 1.0F, 10.0F, 0.0F, XKit.BLUE);
      }
      this.hits.add(new Hit(px + 14, y, fw, 22, "focus:" + focusKey));

      boolean can = value.length() <= cap && !social().busy();
      boolean over = hit(mx, my, px + pw - 68, y, 54, 22);
      XKit.pill(ctx, "Save", px + pw - 68, y, 54, 22, over && can, true,
         XKit.alpha(XKit.BLUE, can ? 1.0F : 0.4F), "ef:" + saveTag);
      if (can) {
         this.hits.add(new Hit(px + pw - 68, y, 54, 22, saveTag));
      }
      return y + 30;
   }

   /* ---- admin state ---- */
   private com.google.gson.JsonObject adminData;
   /* ---- redeem-code creator ---- */
   private String codeDraft = "";
   /* ---- announcement composer ---- */
   private String announceDraft = "";
   private String announceAccent = "blue";
   private String codeKind = "plus";
   private String codeValue = "";
   private String codeDays = "30";
   private com.google.gson.JsonObject codeList;
   private long codeLoadedAt;
   private long adminLoadedAt;
   private String adminNotice;

   /**
    * The announcement composer.
    *
    * <p>Sends a banner to every Blue Client user at once - in any server, in
    * singleplayer, and on the main menu. Because it reaches everyone
    * simultaneously it runs through the same content filter as a post; staff
    * are not exempt, since this is the worst possible place for a slur to slip
    * through.</p>
    */
   private float drawAnnounceComposer(DrawContext ctx, float px, float y,
                                      float pw, int mx, int my) {
      FriendsManager s = social();
      float ly = y;

      XKit.divider(ctx, px + 12, ly, pw - 24);
      ly += 12;
      TextPainter.drawPoppins(ctx, "BROADCAST ANNOUNCEMENT", px + 14, ly,
         XKit.MUTED, 7.5F);
      ly += 16;

      boolean fc = "announce".equals(this.focus);
      float fw = pw - 120;
      XKit.inputBox(ctx, px + 14, ly, fw, 22, fc);
      String shown = this.announceDraft.isEmpty() && !fc
         ? "Message shown to everyone" : this.announceDraft;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, fw - 18, 8.5F), px + 24,
         ly + 7, this.announceDraft.isEmpty() && !fc ? XKit.MUTED : XKit.TEXT,
         8.5F);
      this.hits.add(new Hit(px + 14, ly, fw, 22, "focus:announce"));

      String counter = this.announceDraft.length() + "/200";
      float cw = TextPainter.poppinsWidth(counter, 7.0F);
      TextPainter.drawPoppins(ctx, counter, px + 8 + fw - cw, ly - 10,
         this.announceDraft.length() > 200 ? XKit.RED : XKit.MUTED, 7.0F);

      boolean can = !this.announceDraft.isBlank()
         && this.announceDraft.length() <= 200 && !s.busy();
      boolean ob = hit(mx, my, px + pw - 96, ly, 82, 22);
      XKit.pill(ctx, "Broadcast", px + pw - 96, ly, 82, 22, ob && can, true,
         XKit.alpha(XKit.RED, can ? 1.0F : 0.4F), "ad:announce");
      if (can) {
         this.hits.add(new Hit(px + pw - 96, ly, 82, 22, "adannounce"));
      }
      ly += 28;

      // Accent chips: colour the banner to match the message.
      float ax = px + 14;
      for (String colour : new String[]{"blue", "green", "gold", "red"}) {
         boolean sel = colour.equals(this.announceAccent);
         float w = TextPainter.poppinsWidth(colour, 7.5F) + 18;
         boolean ov = hit(mx, my, ax, ly, w, 18);
         int tint = switch (colour) {
            case "green" -> XKit.GREEN;
            case "gold" -> XKit.GOLD;
            case "red" -> XKit.RED;
            default -> XKit.BLUE;
         };
         float a = Anim.to("anc:" + colour, sel);
         SmoothRect.fill(ctx, ax, ly, w, 18, 9.0F,
            Anim.mixColor(ov ? XKit.HOVER : XKit.SURFACE,
               XKit.alpha(tint, 0.3F), a));
         SmoothRect.outline(ctx, ax, ly, w, 18, 9.0F, 1.0F,
            Anim.mixColor(XKit.DIVIDER, tint, a));
         float tw = TextPainter.poppinsWidth(colour, 7.5F);
         TextPainter.drawPoppins(ctx, colour, ax + (w - tw) / 2.0F, ly + 5.5F,
            Anim.mixColor(XKit.MUTED, XKit.TEXT, a), 7.5F);
         this.hits.add(new Hit(ax, ly, w, 18, "anaccent:" + colour));
         ax += w + 5;
      }
      ly += 26;
      return ly;
   }

   /**
    * Redeem-code creation, inside the admin panel.
    *
    * <p>Kind decides what the code grants: Blue+ for a number of days (0 means
    * permanent), a badge, or a cosmetic. The server validates the code shape
    * and rejects a badge id that does not exist, because a code naming a
    * missing badge would "redeem" successfully and give the player nothing.</p>
    */
   private float drawCodeCreator(DrawContext ctx, float px, float y, float pw,
                                 int mx, int my) {
      FriendsManager s = social();
      float ly = y;

      XKit.divider(ctx, px + 12, ly, pw - 24);
      ly += 12;
      TextPainter.drawPoppins(ctx, "CREATE REDEEM CODE", px + 14, ly,
         XKit.MUTED, 7.5F);
      ly += 16;

      // Code text.
      boolean fc = "adcode".equals(this.focus);
      XKit.inputBox(ctx, px + 14, ly, 150, 22, fc);
      String shown = this.codeDraft.isEmpty() && !fc ? "CODE-NAME" : this.codeDraft;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, 134.0F, 8.5F), px + 24, ly + 7,
         this.codeDraft.isEmpty() && !fc ? XKit.MUTED : XKit.TEXT, 8.5F);
      this.hits.add(new Hit(px + 14, ly, 150, 22, "focus:adcode"));

      // Kind chips.
      float kx = px + 172;
      for (String k : new String[]{"plus", "badge", "cosmetic"}) {
         boolean sel = k.equals(this.codeKind);
         float kw = TextPainter.poppinsWidth(k, 7.5F) + 18;
         boolean ov = hit(mx, my, kx, ly, kw, 22);
         float a = Anim.to("ck:" + k, sel);
         SmoothRect.fill(ctx, kx, ly, kw, 22, 11.0F,
            Anim.mixColor(ov ? XKit.HOVER : XKit.SURFACE,
               XKit.alpha(XKit.BLUE, 0.3F), a));
         SmoothRect.outline(ctx, kx, ly, kw, 22, 11.0F, 1.0F,
            Anim.mixColor(XKit.DIVIDER, XKit.BLUE, a));
         float tw = TextPainter.poppinsWidth(k, 7.5F);
         TextPainter.drawPoppins(ctx, k, kx + (kw - tw) / 2.0F, ly + 7,
            Anim.mixColor(XKit.MUTED, XKit.TEXT, a), 7.5F);
         this.hits.add(new Hit(kx, ly, kw, 22, "adkind:" + k));
         kx += kw + 5;
      }
      ly += 28;

      // Days for plus, value for badge / cosmetic.
      if ("plus".equals(this.codeKind)) {
         TextPainter.drawPoppins(ctx, "Days (0 = permanent)", px + 14, ly + 6,
            XKit.MUTED, 7.5F);
         boolean fd = "addays".equals(this.focus);
         XKit.inputBox(ctx, px + 130, ly, 70, 22, fd);
         TextPainter.drawPoppins(ctx, this.codeDays.isEmpty() ? "0" : this.codeDays,
            px + 140, ly + 7, XKit.TEXT, 8.5F);
         this.hits.add(new Hit(px + 130, ly, 70, 22, "focus:addays"));
      } else {
         TextPainter.drawPoppins(ctx,
            "badge".equals(this.codeKind) ? "Badge id" : "Cosmetic id",
            px + 14, ly + 6, XKit.MUTED, 7.5F);
         boolean fv = "advalue".equals(this.focus);
         XKit.inputBox(ctx, px + 130, ly, 150, 22, fv);
         TextPainter.drawPoppins(ctx,
            this.codeValue.isEmpty() && !fv ? "e.g. supporter" : this.codeValue,
            px + 140, ly + 7,
            this.codeValue.isEmpty() && !fv ? XKit.MUTED : XKit.TEXT, 8.5F);
         this.hits.add(new Hit(px + 130, ly, 150, 22, "focus:advalue"));
      }

      boolean can = this.codeDraft.trim().length() >= 4 && !s.busy();
      boolean oc = hit(mx, my, px + pw - 90, ly, 76, 22);
      XKit.pill(ctx, "Create", px + pw - 90, ly, 76, 22, oc && can, true,
         XKit.alpha(XKit.GREEN, can ? 1.0F : 0.4F), "ad:mkcode");
      if (can) {
         this.hits.add(new Hit(px + pw - 90, ly, 76, 22, "admkcode"));
      }
      ly += 30;

      /* ---- existing codes ---- */
      if (System.currentTimeMillis() - this.codeLoadedAt > 15_000L) {
         this.codeLoadedAt = System.currentTimeMillis();
         s.adminAction2("admin_list_codes", null, o -> this.codeList = o);
      }
      if (this.codeList != null && this.codeList.has("codes")) {
         var arr = this.codeList.getAsJsonArray("codes");
         TextPainter.drawPoppins(ctx, "EXISTING CODES (" + arr.size() + ")",
            px + 14, ly, XKit.MUTED, 7.0F);
         ly += 14;
         int shownCount = 0;
         for (var el : arr) {
            if (shownCount++ >= 6) {
               break;
            }
            var c = el.getAsJsonObject();
            String code = c.get("c").getAsString();
            boolean used = c.has("by");
            TextPainter.drawPoppins(ctx, code, px + 20, ly,
               used ? XKit.MUTED : XKit.TEXT, 8.0F);
            String what = c.get("k").getAsString()
               + (c.has("d") ? " " + (c.get("d").getAsInt() == 0
                  ? "permanent" : c.get("d").getAsInt() + "d") : "")
               + (c.has("v") ? " " + c.get("v").getAsString() : "");
            TextPainter.drawPoppins(ctx, what, px + 130, ly, XKit.MUTED, 7.0F);
            if (used) {
               TextPainter.drawPoppins(ctx, "used by " + c.get("by").getAsString(),
                  px + 240, ly, XKit.GREEN, 7.0F);
            } else {
               iconAction(ctx, "x", px + pw - 34, ly - 5, mx, my,
                  "adrmcode:" + code, XKit.RED, true, "Delete code");
            }
            ly += 14;
         }
         ly += 6;
      }
      return ly;
   }

   /**
    * The admin panel. Blue and Cyan only.
    *
    * <h2>On "make it encrypted so no one can access it"</h2>
    * Encrypting the panel client-side would be security theatre: whatever key
    * the client holds to decrypt it, an attacker holds too. The real boundary
    * is the SERVER. Every admin RPC begins with {@code is_staff(auth.uid())}
    * and returns "Not authorised" otherwise, enforced by Postgres under row
    * level security. A modified client that draws this screen sees an empty
    * panel and every button fails.
    *
    * <p>That is strictly stronger than encryption here, because it does not
    * depend on the client keeping a secret.</p>
    */
   private void drawAdmin(DrawContext ctx, float px, float y, float pw, float ph,
                          int mx, int my) {
      FriendsManager s = social();
      if (!s.staff()) {
         emptyState(ctx, px, y, pw, ph, "lock", "Not authorised",
            "This panel is for Blue and Cyan only.");
         return;
      }

      // Refresh every 10s while open; admin data is small and rarely changes.
      if (System.currentTimeMillis() - this.adminLoadedAt > 10_000L) {
         this.adminLoadedAt = System.currentTimeMillis();
         s.adminOverview(o -> this.adminData = o);
      }
      com.google.gson.JsonObject d = this.adminData;
      if (d == null) {
         centered(ctx, "Loading...", px + pw / 2.0F, y + 30, XKit.MUTED, 9.0F);
         return;
      }

      float ly = y + 8 - this.scroll;

      /* ---- stats ---- */
      com.google.gson.JsonObject st = d.getAsJsonObject("stats");
      String[][] cells = {
         {"Users", st.get("users").getAsString()},
         {"Posts", st.get("posts").getAsString()},
         {"Online", st.get("online").getAsString()},
         {"Blue+", st.get("plus").getAsString()},
         {"New 24h", st.get("new24").getAsString()}};
      float cw = (pw - 24) / cells.length;
      SmoothRect.fill(ctx, px + 12, ly, pw - 24, 44, 8.0F, XKit.SURFACE);
      for (int i = 0; i < cells.length; i++) {
         float cxp = px + 12 + cw * i;
         float vw = TextPainter.poppinsWidth(cells[i][1], 12.0F);
         TextPainter.drawPoppins(ctx, cells[i][1], cxp + (cw - vw) / 2.0F,
            ly + 10, XKit.TEXT, 12.0F);
         float lw = TextPainter.poppinsWidth(cells[i][0], 7.0F);
         TextPainter.drawPoppins(ctx, cells[i][0], cxp + (cw - lw) / 2.0F,
            ly + 28, XKit.MUTED, 7.0F);
      }
      ly += 54;

      if (this.adminNotice != null) {
         TextPainter.drawPoppins(ctx, this.adminNotice, px + 14, ly,
            XKit.GREEN, 8.0F);
         ly += 14;
      }

      ly = drawAnnounceComposer(ctx, px, ly, pw, mx, my);
      ly = drawCodeCreator(ctx, px, ly, pw, mx, my);

      /* ---- open reports ---- */
      com.google.gson.JsonArray reports = d.getAsJsonArray("reports");
      TextPainter.drawPoppins(ctx, "OPEN REPORTS (" + reports.size() + ")",
         px + 14, ly, XKit.MUTED, 7.5F);
      ly += 16;
      if (reports.isEmpty()) {
         TextPainter.drawPoppins(ctx, "Nothing reported.", px + 14, ly,
            XKit.MUTED, 8.0F);
         ly += 18;
      }
      for (var el : reports) {
         com.google.gson.JsonObject r = el.getAsJsonObject();
         SmoothRect.fill(ctx, px + 12, ly, pw - 24, 40, 6.0F, XKit.SURFACE);
         String who = r.has("t") ? r.get("t").getAsString() : "?";
         TextPainter.drawPoppins(ctx, who, px + 20, ly + 6, XKit.TEXT, 8.5F);
         TextPainter.drawPoppins(ctx,
            XKit.fit(r.has("b") ? r.get("b").getAsString() : "", pw - 150, 7.5F),
            px + 20, ly + 18, XKit.MUTED, 7.5F);
         TextPainter.drawPoppins(ctx,
            "reported by " + (r.has("u") ? r.get("u").getAsString() : "?"),
            px + 20, ly + 29, XKit.MUTED, 6.5F);

         String pid = r.has("p") && !r.get("p").isJsonNull()
            ? r.get("p").getAsString() : null;
         if (pid != null) {
            boolean od = hit(mx, my, px + pw - 118, ly + 10, 50, 20);
            XKit.pill(ctx, "Delete", px + pw - 118, ly + 10, 50, 20, od, true,
               XKit.RED, "ad:del:" + pid);
            this.hits.add(new Hit(px + pw - 118, ly + 10, 50, 20, "admdel:" + pid));
         }
         boolean ok2 = hit(mx, my, px + pw - 64, ly + 10, 52, 20);
         XKit.pill(ctx, "Dismiss", px + pw - 64, ly + 10, 52, 20, ok2, false,
            XKit.BLUE, "ad:dis:" + r.get("i").getAsString());
         this.hits.add(new Hit(px + pw - 64, ly + 10, 52, 20,
            "admdismiss:" + r.get("i").getAsString()));
         ly += 44;
      }

      /* ---- recent posts, with pin + delete ---- */
      ly += 6;
      TextPainter.drawPoppins(ctx, "RECENT POSTS", px + 14, ly, XKit.MUTED, 7.5F);
      ly += 16;
      for (var el : d.getAsJsonArray("recent")) {
         com.google.gson.JsonObject r = el.getAsJsonObject();
         String pid = r.get("i").getAsString();
         if (ly > y + ph) {
            break;
         }
         boolean over = hit(mx, my, px + 12, ly, pw - 24, 30);
         if (over) {
            SmoothRect.fill(ctx, px + 12, ly, pw - 24, 30, 6.0F, XKit.HOVER);
         }
         TextPainter.drawPoppins(ctx, r.get("u").getAsString(), px + 20, ly + 5,
            XKit.TEXT, 8.0F);
         TextPainter.drawPoppins(ctx,
            XKit.fit(r.get("b").getAsString(), pw - 150, 7.5F),
            px + 20, ly + 16, XKit.MUTED, 7.5F);

         boolean isPinned = s.pinnedPost() != null
            && s.pinnedPost().id().equals(pid);
         iconAction(ctx, "sparkles", px + pw - 60, ly + 6, mx, my,
            isPinned ? "unpinpost" : "pinpost:" + pid,
            XKit.GOLD, true, isPinned ? "Unpin" : "Pin for everyone");
         iconAction(ctx, "x", px + pw - 34, ly + 6, mx, my, "admdel:" + pid,
            XKit.RED, true, "Delete post");
         ly += 34;
      }
      clampScroll(ly + this.scroll - (y + ph));
   }

   /* ---- account deletion state ---- */
   private boolean deleteArmed;
   private String deleteConfirm = "";
   private String deleteNotice;

   /**
    * The danger zone at the bottom of Settings.
    *
    * <p>Two-step on purpose: an accidental click must not be able to destroy
    * an account, so the button only arms the form, and the form requires the
    * username typed exactly. The server re-checks that string too.</p>
    */
   private float drawDangerZone(DrawContext ctx, float px, float y, float pw,
                                int mx, int my) {
      FriendsManager s = social();
      float ly = y;

      XKit.divider(ctx, px + 12, ly, pw - 24);
      ly += 14;
      TextPainter.drawPoppins(ctx, "DANGER ZONE", px + 14, ly, XKit.RED, 7.5F);
      ly += 16;

      if (!this.deleteArmed) {
         TextPainter.drawPoppins(ctx,
            "Deleting your account removes your posts, friends and Blue+.",
            px + 14, ly, XKit.MUTED, 7.5F);
         ly += 14;
         boolean over = hit(mx, my, px + 14, ly, 116, 22);
         XKit.pill(ctx, "Delete account", px + 14, ly, 116, 22, over, false,
            XKit.RED, "del:arm");
         this.hits.add(new Hit(px + 14, ly, 116, 22, "delarm"));
         ly += 30;
         return ly;
      }

      SmoothRect.fill(ctx, px + 12, ly, pw - 24, 76, 8.0F,
         XKit.alpha(XKit.RED, 0.10F));
      SmoothRect.outline(ctx, px + 12, ly, pw - 24, 76, 8.0F, 1.0F,
         XKit.alpha(XKit.RED, 0.5F));

      TextPainter.drawPoppins(ctx,
         "This cannot be undone. Type " + s.username() + " to confirm.",
         px + 20, ly + 8, XKit.TEXT, 8.0F);

      boolean fc = "delconfirm".equals(this.focus);
      XKit.inputBox(ctx, px + 20, ly + 24, pw - 130, 22, fc);
      String shown = this.deleteConfirm.isEmpty() && !fc
         ? "Your username" : this.deleteConfirm;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, pw - 150, 8.5F),
         px + 30, ly + 31,
         this.deleteConfirm.isEmpty() && !fc ? XKit.MUTED : XKit.TEXT, 8.5F);
      this.hits.add(new Hit(px + 20, ly + 24, pw - 130, 22, "focus:delconfirm"));

      boolean matches = this.deleteConfirm.equalsIgnoreCase(s.username())
         && s.profileReady();
      boolean od = hit(mx, my, px + pw - 102, ly + 24, 82, 22);
      XKit.pill(ctx, "Delete", px + pw - 102, ly + 24, 82, 22, od && matches,
         true, XKit.alpha(XKit.RED, matches ? 1.0F : 0.35F), "del:go");
      if (matches) {
         this.hits.add(new Hit(px + pw - 102, ly + 24, 82, 22, "delgo"));
      }

      boolean oc = hit(mx, my, px + 20, ly + 50, 60, 18);
      XKit.pill(ctx, "Cancel", px + 20, ly + 50, 60, 18, oc, false,
         XKit.BLUE, "del:cancel");
      this.hits.add(new Hit(px + 20, ly + 50, 60, 18, "delcancel"));

      if (this.deleteNotice != null) {
         TextPainter.drawPoppins(ctx, this.deleteNotice, px + 90, ly + 54,
            XKit.RED, 7.5F);
      }
      return ly + 86;
   }

   /** The community rules. */
   private void drawRules(DrawContext ctx, float px, float y, float pw, float ph,
                          int mx, int my) {
      float ly = y + 8 - this.scroll;

      RenderUtil.drawIcon(ctx, "book", (int) (px + 14), (int) ly, 14, XKit.BLUE);
      TextPainter.drawPoppins(ctx, "Community rules", px + 34, ly + 2,
         XKit.TEXT, 11.0F);
      ly += 24;
      TextPainter.drawPoppins(ctx,
         "These are enforced by the server, not just asked for.",
         px + 14, ly, XKit.MUTED, 7.5F);
      ly += 20;

      String[][] rules = {
         {"1", "Keep it clean",
          "Profanity and slurs are blocked automatically. Repeated attempts "
             + "to get around the filter will cost you your account."},
         {"2", "No politics",
          "Blue Client is a game client. Political arguments belong somewhere "
             + "else - posts about them are rejected."},
         {"3", "No spam",
          "No all-caps, no repeated characters, no posting the same thing "
             + "twice, and no link dumps. Free accounts get 2 posts an hour, "
             + "Blue+ gets 4."},
         {"4", "No harassment",
          "Do not target anyone. Block and report instead of arguing - the "
             + "report button is on every post."},
         {"5", "One account per person",
          "Up to three accounts per connection. Alt accounts made to get "
             + "around a block or a limit will be removed."},
         {"6", "Your name is public",
          "Your username, posts and profile are visible to everyone. Do not "
             + "put anything private in them."}};

      for (String[] rule : rules) {
         SmoothRect.fill(ctx, px + 12, ly, 18, 18, 9.0F, XKit.alpha(XKit.BLUE, 0.2F));
         float nw = TextPainter.poppinsWidth(rule[0], 8.0F);
         TextPainter.drawPoppins(ctx, rule[0], px + 21 - nw / 2.0F, ly + 5,
            XKit.BLUE, 8.0F);
         TextPainter.drawPoppins(ctx, rule[1], px + 38, ly + 2, XKit.TEXT, 9.0F);
         float ty = ly + 15;
         for (String line : XKit.wrap(rule[2], pw - 56, 7.5F, 4)) {
            TextPainter.drawPoppins(ctx, line, px + 38, ty, XKit.MUTED, 7.5F);
            ty += 10;
         }
         ly = ty + 10;
      }
      clampScroll(ly + this.scroll - (y + ph));
   }

   /**
    * Notifications - X's activity list.
    *
    * <p>Full-bleed rows separated by hairlines, with the event icon in the
    * left gutter where X puts it and the actor's avatar beside the text.</p>
    */
   private void drawActivity(DrawContext ctx, float px, float y, float pw, float ph,
                             int mx, int my) {
      net.bluenetwork.client.notification.NotificationInbox.markAllRead();
      social().markNotificationsRead();

      java.util.List<net.bluenetwork.client.notification.NotificationInbox.Entry> all =
         net.bluenetwork.client.notification.NotificationInbox.all();

      if (all.isEmpty()) {
         emptyState(ctx, px, y, pw, ph, "bell", "Nothing to see here - yet",
            "Likes, replies, reposts, follows and friend requests will show up here.");
         return;
      }

      float ry = y - this.scroll;
      for (var e : all) {
         float rowH = 34.0F;
         if (ry + rowH > y && ry < y + ph) {
            boolean over = hit(mx, my, px, ry, pw, rowH);
            float hov = Anim.to("act:" + e.at(), over);
            if (hov > 0.01F) {
               SmoothRect.fill(ctx, px, ry, pw, rowH, 0.0F,
                  Anim.mixColor(0x00000000, XKit.HOVER, hov));
            }

            // Event icon in the gutter, tinted by kind - X's visual grammar.
            RenderUtil.drawIcon(ctx, e.kind().icon(), (int) (px + 12),
               (int) (ry + 10), 13, e.kind().colour());

            XKit.avatar(ctx, e.who(), px + 34, ry + 7, 18.0F);

            float tx = px + 57;
            float tw = pw - (tx - px) - 30;
            String line = e.who() + " " + e.body();
            TextPainter.drawPoppins(ctx, XKit.fit(line, tw, 8.0F), tx, ry + 12,
               XKit.TEXT, 8.0F);

            String age = XKit.shortAge(e.at() / 1000L);
            float aw = TextPainter.poppinsWidth(age, 7.0F);
            TextPainter.drawPoppins(ctx, age, px + pw - aw - 12, ry + 12,
               XKit.MUTED, 7.0F);

            this.hits.add(new Hit(px, ry, pw, rowH, "profilename:" + e.who()));
            XKit.divider(ctx, px + 1, ry + rowH - 1, pw - 2);
         }
         ry += 34;
      }
      clampScroll(ry + this.scroll - (y + ph));
   }

   /**
    * The Top / most-followed list, styled as X styles a ranked list.
    */
   private void drawTop(DrawContext ctx, float px, float y, float pw, float ph,
                        int mx, int my) {
      java.util.List<FriendsManager.LeaderRow> rows = social().leaders();
      if (rows.isEmpty()) {
         emptyState(ctx, px, y, pw, ph, "trending-up", "No rankings yet",
            "Once people start following each other, the top accounts appear here.");
         return;
      }

      float ry = y - this.scroll;
      int rank = 1;
      for (FriendsManager.LeaderRow row : rows) {
         float rowH = 38.0F;
         if (ry + rowH > y && ry < y + ph) {
            boolean over = hit(mx, my, px, ry, pw, rowH);
            float hov = Anim.to("top:" + row.username(), over);
            if (hov > 0.01F) {
               SmoothRect.fill(ctx, px, ry, pw, rowH, 0.0F,
                  Anim.mixColor(0x00000000, XKit.HOVER, hov));
            }

            int medal = switch (rank) {
               case 1 -> 0xFFFFD700;
               case 2 -> 0xFFC0C0C0;
               case 3 -> 0xFFCD7F32;
               default -> XKit.MUTED;
            };
            String r = String.valueOf(rank);
            float rw = TextPainter.poppinsWidth(r, 9.0F);
            TextPainter.drawPoppins(ctx, r, px + 18 - rw / 2.0F, ry + 14,
               medal, 9.0F);

            XKit.avatar(ctx, row.avatarName(), px + 30, ry + 8, 22.0F);

            float nx = px + 58;
            int ncol = NameColor.primary(row.color(), XKit.TEXT);
            String nm = XKit.fit(row.username(), pw - 150, 9.0F);
            TextPainter.drawPoppins(ctx, nm, nx, ry + 9, ncol, 9.0F);
            float bx = nx + TextPainter.poppinsWidth(nm, 9.0F) + 3;
            if (row.verified()) {
               bx += VerifiedBadge.draw(ctx, bx, ry + 8, 9.0F) + 2;
            }
            if (row.plus()) {
               BluePlusIcon.draw(ctx, bx, ry + 8, 9.0F);
            }
            TextPainter.drawPoppins(ctx,
               "@" + row.username().toLowerCase(java.util.Locale.ROOT),
               nx, ry + 21, XKit.MUTED, 7.0F);

            String fol = XKit.compact(row.followers()) + " followers";
            float fw = TextPainter.poppinsWidth(fol, 7.5F);
            TextPainter.drawPoppins(ctx, fol, px + pw - fw - 14, ry + 15,
               XKit.MUTED, 7.5F);

            this.hits.add(new Hit(px, ry, pw, rowH,
               row.id() != null ? "profile:" + row.id()
                                : "profilename:" + row.username()));
            XKit.divider(ctx, px + 1, ry + rowH - 1, pw - 2);
         }
         ry += 38;
         rank++;
      }
      clampScroll(ry + this.scroll - (y + ph));
   }

   /**
    * A centred empty state: icon, headline, explanation.
    *
    * <p>X never shows a bare "nothing here" line - it explains what will
    * appear and why. Cheap to do and it makes a new account feel designed
    * rather than broken.</p>
    */
   private void emptyState(DrawContext ctx, float px, float y, float pw, float ph,
                           String icon, String title, String body) {
      float cx = px + pw / 2.0F;
      float cy = y + ph / 2.0F - 26;
      RenderUtil.drawIcon(ctx, icon, (int) (cx - 11), (int) cy, 22, XKit.MUTED);
      centered(ctx, title, cx, cy + 30, XKit.TEXT, 10.5F);
      for (String line : XKit.wrap(body, Math.min(pw - 60, 240.0F), 8.0F, 3)) {
         centered(ctx, line, cx, cy + 45, XKit.MUTED, 8.0F);
         cy += 11;
      }
   }

   /* --------------------------------------------------------------- BLUE+ */

   /**
    * The Blue+ tab: what it is, what you get, and how to redeem a code.
    *
    * <p>Subscribers see their evolving "Blue Plus user for ..." badge instead
    * of the sales pitch.</p>
    */
   /**
    * The Blue+ tab.
    *
    * <p>For SUBSCRIBERS this is the settings panel the owner asked for - the
    * coloured-name editor in particular. That was the missing piece: the
    * server RPC ({@code set_name_color}) and the renderer
    * ({@link NameColor}) both already existed, but nothing in the UI ever
    * called them, so coloured names could not be turned on at all.</p>
    *
    * <p>For non-subscribers it is the pitch plus the redeem box.</p>
    */
   private void drawPlus(DrawContext ctx, float px, float y, float pw, float ph,
                         int mx, int my) {
      FriendsManager s = social();
      if (s.plus()) {
         drawPlusSettings(ctx, px, y, pw, ph, mx, my);
         return;
      }

      float cx = px + pw / 2.0F;
      float ly = y + 6 - this.scroll;

      BluePlusIcon.drawCentred(ctx, cx, ly + 16, 30.0F);
      centered(ctx, "Blue+", cx, ly + 36, XKit.GOLD, 15.0F);
      centered(ctx, Limits.PLUS_PRICE, cx, ly + 55, XKit.TEXT, 10.0F);
      centered(ctx, Limits.PLUS_TERMS, cx, ly + 68, XKit.MUTED, 7.5F);
      ly += 86;

      String[] perks = {
         "A Blue+ mark next to your name, everywhere",
         "Coloured names - solid, gradient, bold, italic",
         "Posts up to " + Limits.POST_PLUS + " characters, "
            + Limits.POSTS_HOUR_PLUS + " per hour",
         "About me up to " + Limits.ABOUT_PLUS + " characters",
         "Up to " + Limits.FRIENDS_PLUS + " friends and "
            + Limits.FOLLOWING_PLUS + " following",
         "The Blue+ logo replaces the Blue logo for you",
         "An evolving \"Blue Plus user since\" badge"};

      float listX = px + Math.max(20.0F, (pw - 260.0F) / 2.0F);
      for (String perk : perks) {
         RenderUtil.drawIcon(ctx, "check", (int) listX, (int) ly, 9, XKit.GOLD);
         TextPainter.drawPoppins(ctx, perk, listX + 14, ly + 0.5F, XKit.TEXT, 8.0F);
         ly += 14;
      }

      ly += 8;
      centered(ctx, "Donate on Discord to receive a code.", cx, ly, XKit.MUTED, 7.5F);
      ly += 16;

      float fw = Math.min(200.0F, pw - 100.0F);
      float fx = cx - (fw + 60) / 2.0F;
      boolean fc = "code".equals(this.focus);
      XKit.inputBox(ctx, fx, ly, fw, 22, fc);
      String shown = this.draftCode.isEmpty() && !fc ? "Redeem code" : this.draftCode;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, fw - 16, 8.5F), fx + 10, ly + 7,
         this.draftCode.isEmpty() && !fc ? XKit.MUTED : XKit.TEXT, 8.5F);
      this.hits.add(new Hit(fx, ly, fw, 22, "focus:code"));

      boolean can = !this.draftCode.isBlank() && !s.busy();
      boolean overR = hit(mx, my, fx + fw + 6, ly, 54, 22);
      XKit.pill(ctx, "Redeem", fx + fw + 6, ly, 54, 22, overR && can, true,
         XKit.alpha(XKit.GOLD, can ? 1.0F : 0.4F), "plus:redeem");
      if (can) {
         this.hits.add(new Hit(fx + fw + 6, ly, 54, 22, "doredeem"));
      }

      if (this.redeemNotice != null) {
         centered(ctx, this.redeemNotice, cx, ly + 30,
            this.redeemOk ? XKit.GREEN : XKit.RED, 8.0F);
      }
      clampScroll(ly + 46 + this.scroll - (y + ph));
   }

   /**
    * The Blue+ subscriber settings: status, then the name-colour studio.
    *
    * <p>Colours are applied with an explicit APPLY rather than on every click.
    * Each change is a network round trip and a database write, and a live
    * colour picker would fire dozens of them while you drag through shades.</p>
    */
   private void drawPlusSettings(DrawContext ctx, float px, float y, float pw,
                                 float ph, int mx, int my) {
      FriendsManager s = social();

      // Seed both drafts from what is saved, once each, so the studios open
      // showing your current colours rather than the defaults.
      this.nameStudio.loadFrom(s.nameColor());
      this.bgStudio.loadFrom(s.profileColor());

      float ly = y + 8 - this.scroll;
      float cx = px + pw / 2.0F;
      java.util.List<net.bluenetwork.client.ui.ColorStudio.Hit> studioHits =
         new java.util.ArrayList<>();

      /* ---- status card ---- */
      SmoothRect.fill(ctx, px + 12, ly, pw - 24, 40, 8.0F, XKit.SURFACE);
      BluePlusIcon.draw(ctx, px + 22, ly + 11, 18.0F);
      TextPainter.drawPoppins(ctx, "Blue+ active", px + 46, ly + 9,
         XKit.GOLD, 10.0F);
      String sub = s.plusPermanent()
         ? "Permanent - thank you for supporting Blue Client."
         : (s.plusUntil() > 0L
            ? "Active until " + relativeEpoch(s.plusUntil()) + " - no auto-renewal"
            : Limits.plusSinceText(s.plusSince()));
      TextPainter.drawPoppins(ctx, XKit.fit(sub, pw - 70, 7.5F), px + 46,
         ly + 23, XKit.MUTED, 7.5F);
      ly += 50;

      /* ================= NAME COLOUR ================= */
      TextPainter.drawPoppins(ctx, "Name colour", px + 14, ly, XKit.TEXT, 10.0F);
      ly += 15;
      TextPainter.drawPoppins(ctx,
         "Shown on your posts, in Social and on your nametag.",
         px + 14, ly, XKit.MUTED, 7.5F);
      ly += 15;

      // Live preview, rendered with the same blend the game uses.
      SmoothRect.fill(ctx, px + 12, ly, pw - 24, 30, 8.0F, XKit.SURFACE);
      NameColor.Spec nspec = this.nameStudio.spec();
      String me = s.username();
      float tw = NamePainter.width(me, 13.0F);
      NamePainter.draw(ctx, me, cx - tw / 2.0F, ly + 8, 13.0F, nspec);
      ly += 36;

      ly = this.nameStudio.draw(ctx, px + 14, ly, pw - 28, mx, my, "nm",
         "nmhex".equals(this.focus), studioHits);

      boolean overNA = hit(mx, my, px + 14, ly, 66, 22);
      XKit.pill(ctx, "Apply", px + 14, ly, 66, 22, overNA, true, XKit.BLUE,
         "nm:apply");
      this.hits.add(new Hit(px + 14, ly, 66, 22, "nmapply"));
      boolean overNC = hit(mx, my, px + 88, ly, 66, 22);
      XKit.pill(ctx, "Clear", px + 88, ly, 66, 22, overNC, false, XKit.BLUE,
         "nm:clear");
      this.hits.add(new Hit(px + 88, ly, 66, 22, "nmclear"));
      ly += 32;

      XKit.divider(ctx, px + 12, ly, pw - 24);
      ly += 14;

      /* ================= PROFILE BACKGROUND ================= */
      TextPainter.drawPoppins(ctx, "Profile background", px + 14, ly,
         XKit.TEXT, 10.0F);
      ly += 15;
      TextPainter.drawPoppins(ctx,
         "The banner behind your name on your profile page.",
         px + 14, ly, XKit.MUTED, 7.5F);
      ly += 15;

      // Preview the actual banner, using the same painter the page uses.
      net.bluenetwork.client.ui.ColorStudio.fillSpec(ctx, this.bgStudio.spec(),
         px + 12, ly, pw - 24, 40, 8.0F);
      XKit.avatar(ctx, s.skinName() != null ? s.skinName() : me,
         px + 22, ly + 12, 26.0F);
      ly += 48;

      ly = this.bgStudio.draw(ctx, px + 14, ly, pw - 28, mx, my, "bg",
         "bghex".equals(this.focus), studioHits);

      boolean overBA = hit(mx, my, px + 14, ly, 66, 22);
      XKit.pill(ctx, "Apply", px + 14, ly, 66, 22, overBA, true, XKit.BLUE,
         "bg:apply");
      this.hits.add(new Hit(px + 14, ly, 66, 22, "bgapply"));
      boolean overBC = hit(mx, my, px + 88, ly, 66, 22);
      XKit.pill(ctx, "Clear", px + 88, ly, 66, 22, overBC, false, XKit.BLUE,
         "bg:clear");
      this.hits.add(new Hit(px + 88, ly, 66, 22, "bgclear"));

      if (this.plusNotice != null) {
         TextPainter.drawPoppins(ctx, this.plusNotice, px + 162, ly + 7,
            this.plusOk ? XKit.GREEN : XKit.RED, 8.0F);
      }
      ly += 32;

      XKit.divider(ctx, px + 12, ly, pw - 24);
      ly += 14;

      /* ---- redeem another code ---- */
      TextPainter.drawPoppins(ctx, "Redeem another code", px + 14, ly,
         XKit.MUTED, 7.5F);
      ly += 14;
      float fw = Math.min(180.0F, pw - 110.0F);
      boolean fc = "code".equals(this.focus);
      XKit.inputBox(ctx, px + 14, ly, fw, 22, fc);
      String shown = this.draftCode.isEmpty() && !fc ? "Code" : this.draftCode;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, fw - 16, 8.5F), px + 24, ly + 7,
         this.draftCode.isEmpty() && !fc ? XKit.MUTED : XKit.TEXT, 8.5F);
      this.hits.add(new Hit(px + 14, ly, fw, 22, "focus:code"));

      boolean can = !this.draftCode.isBlank() && !s.busy();
      boolean overR = hit(mx, my, px + 20 + fw, ly, 54, 22);
      XKit.pill(ctx, "Redeem", px + 20 + fw, ly, 54, 22, overR && can, false,
         XKit.GOLD, "plus:redeem2");
      if (can) {
         this.hits.add(new Hit(px + 20 + fw, ly, 54, 22, "doredeem"));
      }
      if (this.redeemNotice != null) {
         TextPainter.drawPoppins(ctx, this.redeemNotice, px + 14, ly + 26,
            this.redeemOk ? XKit.GREEN : XKit.RED, 7.5F);
      }
      ly += 40;

      // Studio hit boxes are collected during drawing and forwarded here so
      // the studios stay independent of this screen's Hit type.
      for (var sh : studioHits) {
         this.hits.add(new Hit(sh.x(), sh.y(), sh.w(), sh.h(), sh.tag()));
      }
      clampScroll(ly + this.scroll - (y + ph));
   }

   /** Formats an epoch-seconds timestamp as "3m ago" / "in 2d". */
   private static String relativeEpoch(long epochSeconds) {
      if (epochSeconds <= 0L) {
         return "";
      }
      long diff = epochSeconds - System.currentTimeMillis() / 1000L;
      boolean future = diff > 0;
      long abs = Math.abs(diff);
      String unit;
      if (abs < 60L) {
         unit = abs + "s";
      } else if (abs < 3600L) {
         unit = (abs / 60L) + "m";
      } else if (abs < 86_400L) {
         unit = (abs / 3600L) + "h";
      } else {
         unit = (abs / 86_400L) + "d";
      }
      return future ? "in " + unit : unit + " ago";
   }

   /* --------------------------------------------------------------- CHATS */

   private void drawChats(DrawContext ctx, float px, float y, float pw, float ph,
                          int mx, int my) {
      List<FriendsManager.Conversation> list = social().conversations();

      boolean overNew = hit(mx, my, px + pw - 84, y + 6, 72, 20);
      XKit.pill(ctx, "New group", px + pw - 84, y + 6, 72, 20, overNew, false,
         XKit.BLUE, "chats:new");
      this.hits.add(new Hit(px + pw - 84, y + 6, 72, 20, "newgroup"));

      if (list.isEmpty()) {
         emptyState(ctx, px, y + 26, pw, ph - 26, "message-square",
            "No messages yet",
            "Open a friend and press the message icon to start a conversation.");
         return;
      }

      float ry = y + 32 - this.scroll;
      for (FriendsManager.Conversation c : list) {
         float rowH = 40.0F;
         if (ry + rowH > y && ry < y + ph) {
            boolean over = hit(mx, my, px, ry, pw, rowH);
            float hov = Anim.to("chat:" + c.id(), over);
            if (hov > 0.01F) {
               SmoothRect.fill(ctx, px, ry, pw, rowH, 0.0F,
                  Anim.mixColor(0x00000000, XKit.HOVER, hov));
            }

            // Groups get an icon disc; DMs get the other person's face.
            if (c.group()) {
               SmoothRect.fill(ctx, px + 11, ry + 6, 28, 28, 14.0F, XKit.SURFACE);
               RenderUtil.drawIcon(ctx, "users", (int) (px + 19), (int) (ry + 14),
                  12, XKit.MUTED);
            } else {
               XKit.avatar(ctx, c.title(), px + 11, ry + 6, 28.0F);
            }

            float tx = px + 47;
            float tw = pw - (tx - px) - 60;
            TextPainter.drawPoppins(ctx, XKit.fit(c.title(), tw, 8.5F), tx,
               ry + 9, XKit.TEXT, 8.5F);

            String preview = c.lastBody() == null ? "No messages yet" : c.lastBody();
            TextPainter.drawPoppins(ctx, XKit.fit(preview, tw, 7.5F), tx, ry + 22,
               XKit.MUTED, 7.5F);

            if (c.unread() > 0L) {
               String n = XKit.compact(c.unread());
               float nw = TextPainter.poppinsWidth(n, 7.0F);
               SmoothRect.fill(ctx, px + pw - nw - 24, ry + 13, nw + 11, 13, 6.5F,
                  XKit.BLUE);
               TextPainter.drawPoppins(ctx, n, px + pw - nw - 18.5F, ry + 16,
                  0xFFFFFFFF, 7.0F);
            }

            this.hits.add(new Hit(px, ry, pw, rowH, "openchat:" + c.id()));
            XKit.divider(ctx, px + 1, ry + rowH - 1, pw - 2);
         }
         ry += 40;
      }
      clampScroll(ry + this.scroll - (y + ph));
   }

   /* ------------------------------------------------------------ REQUESTS */

   private void drawRequests(DrawContext ctx, float px, float y, float pw, float ph,
                             int mx, int my) {
      List<FriendsManager.Request> in = social().incoming();
      List<FriendsManager.Request> out = social().outgoing();

      if (in.isEmpty() && out.isEmpty()) {
         emptyState(ctx, px, y, pw, ph, "user-round", "No pending requests",
            "Friend requests you send or receive will appear here.");
         return;
      }

      float ry = y - this.scroll;

      if (!in.isEmpty()) {
         ry = sectionLabel(ctx, "Incoming", px, ry, pw);
         for (FriendsManager.Request r : in) {
            float rowH = 40.0F;
            if (ry + rowH > y && ry < y + ph) {
               requestRow(ctx, r, px, ry, pw, rowH, mx, my, true);
            }
            ry += rowH;
         }
      }

      if (!out.isEmpty()) {
         ry = sectionLabel(ctx, "Sent", px, ry, pw);
         for (FriendsManager.Request r : out) {
            float rowH = 40.0F;
            if (ry + rowH > y && ry < y + ph) {
               requestRow(ctx, r, px, ry, pw, rowH, mx, my, false);
            }
            ry += rowH;
         }
      }
      clampScroll(ry + this.scroll - (y + ph));
   }

   /** A small uppercase section heading. Returns the new y. */
   private float sectionLabel(DrawContext ctx, String text, float px, float y,
                              float pw) {
      TextPainter.drawPoppins(ctx, text.toUpperCase(java.util.Locale.ROOT),
         px + 14, y + 8, XKit.MUTED, 7.0F);
      return y + 22;
   }

   /** One friend request, incoming (accept/decline) or outgoing (cancel). */
   private void requestRow(DrawContext ctx, FriendsManager.Request r,
                           float x, float y, float w, float h,
                           int mx, int my, boolean incoming) {
      boolean over = hit(mx, my, x, y, w, h);
      float hov = Anim.to("req:" + r.id(), over);
      if (hov > 0.01F) {
         SmoothRect.fill(ctx, x, y, w, h, 0.0F,
            Anim.mixColor(0x00000000, XKit.HOVER, hov));
      }

      XKit.avatar(ctx, r.username(), x + 11, y + 6, 28.0F);

      float tx = x + 47;
      float tw = w - (tx - x) - (incoming ? 116 : 76);
      TextPainter.drawPoppins(ctx, XKit.fit(r.username(), tw, 8.5F), tx, y + 9,
         XKit.TEXT, 8.5F);
      TextPainter.drawPoppins(ctx,
         incoming ? "wants to be your friend" : "Pending",
         tx, y + 22, XKit.MUTED, 7.5F);

      if (incoming) {
         boolean overA = hit(mx, my, x + w - 108, y + 10, 50, 20);
         XKit.pill(ctx, "Accept", x + w - 108, y + 10, 50, 20, overA, true,
            XKit.BLUE, "req:a:" + r.id());
         this.hits.add(new Hit(x + w - 108, y + 10, 50, 20, "accept:" + r.id()));

         boolean overD = hit(mx, my, x + w - 54, y + 10, 42, 20);
         XKit.pill(ctx, "Decline", x + w - 54, y + 10, 42, 20, overD, false,
            XKit.BLUE, "req:d:" + r.id());
         this.hits.add(new Hit(x + w - 54, y + 10, 42, 20, "decline:" + r.id()));
      } else {
         boolean overC = hit(mx, my, x + w - 66, y + 10, 54, 20);
         XKit.pill(ctx, "Cancel", x + w - 66, y + 10, 54, 20, overC, false,
            XKit.BLUE, "req:c:" + r.id());
         this.hits.add(new Hit(x + w - 66, y + 10, 54, 20, "cancel:" + r.id()));
      }

      XKit.divider(ctx, x + 1, y + h - 1, w - 2);
   }

   /* ----------------------------------------------------------------- ADD */

   private void drawAdd(DrawContext ctx, float px, float y, float pw, float ph,
                        int mx, int my) {
      // X's rounded search field, with the magnifier inside it.
      boolean focused = "search".equals(this.focus);
      float fw = pw - 24;
      XKit.inputBox(ctx, px + 12, y + 8, fw, 24, focused);
      RenderUtil.drawIcon(ctx, "search", (int) (px + 22), (int) (y + 15), 10,
         focused ? XKit.BLUE : XKit.MUTED);

      String shown = this.fieldSearch.isEmpty() && !focused
         ? "Search Blue Client" : this.fieldSearch;
      TextPainter.drawPoppins(ctx, XKit.fit(shown, fw - 40, 8.5F), px + 38, y + 16,
         this.fieldSearch.isEmpty() && !focused ? XKit.MUTED : XKit.TEXT, 8.5F);
      if (focused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         float cw = TextPainter.poppinsWidth(XKit.fit(shown, fw - 40, 8.5F), 8.5F);
         SmoothRect.fill(ctx, px + 39 + cw, y + 15, 1.0F, 10.0F, 0.0F, XKit.BLUE);
      }
      this.hits.add(new Hit(px + 12, y + 8, fw, 24, "focus:search"));

      float listY = y + 38;
      List<FriendsManager.Blocked> res = this.results;

      if (this.fieldSearch.trim().length() < 2) {
         emptyState(ctx, px, listY, pw, ph - 38, "search", "Find people",
            "Type at least two characters of a username to search.");
         return;
      }
      if (this.searchPending) {
         centered(ctx, "Searching...", px + pw / 2.0F, listY + 20, XKit.MUTED, 8.0F);
         return;
      }
      if (res.isEmpty()) {
         emptyState(ctx, px, listY, pw, ph - 38, "search", "No results",
            "Nobody matches \"" + XKit.fit(this.fieldSearch, 120.0F, 8.0F) + "\".");
         return;
      }

      float ry = listY - this.scroll;
      for (FriendsManager.Blocked u : res) {
         float rowH = 38.0F;
         if (ry + rowH > listY && ry < y + ph) {
            boolean over = hit(mx, my, px, ry, pw, rowH);
            float hov = Anim.to("sr:" + u.id(), over);
            if (hov > 0.01F) {
               SmoothRect.fill(ctx, px, ry, pw, rowH, 0.0F,
                  Anim.mixColor(0x00000000, XKit.HOVER, hov));
            }

            XKit.avatar(ctx, u.avatarName(), px + 11, ry + 6, 26.0F);
            TextPainter.drawPoppins(ctx, XKit.fit(u.username(), pw - 140, 8.5F),
               px + 45, ry + 9, XKit.TEXT, 8.5F);
            TextPainter.drawPoppins(ctx,
               "@" + u.username().toLowerCase(java.util.Locale.ROOT),
               px + 45, ry + 21, XKit.MUTED, 7.0F);

            if (isFriend(u.id())) {
               String t = "Friends";
               float tw = TextPainter.poppinsWidth(t, 7.5F);
               TextPainter.drawPoppins(ctx, t, px + pw - tw - 14, ry + 15,
                  XKit.MUTED, 7.5F);
            } else if (isPendingOut(u.id())) {
               String t = "Requested";
               float tw = TextPainter.poppinsWidth(t, 7.5F);
               TextPainter.drawPoppins(ctx, t, px + pw - tw - 14, ry + 15,
                  XKit.MUTED, 7.5F);
            } else {
               boolean overAdd = hit(mx, my, px + pw - 62, ry + 9, 50, 20);
               XKit.pill(ctx, "Add", px + pw - 62, ry + 9, 50, 20, overAdd, true,
                  XKit.BLUE, "sradd:" + u.id());
               this.hits.add(new Hit(px + pw - 62, ry + 9, 50, 20,
                  "request:" + u.id()));
            }
            // Clicking the row (but not the Add pill) opens their profile.
            this.hits.add(new Hit(px, ry, pw - 70, rowH, "profile:" + u.id()));
            XKit.divider(ctx, px + 1, ry + rowH - 1, pw - 2);
         }
         ry += 38;
      }
      clampScroll(ry + this.scroll - (y + ph));
   }

   /* ------------------------------------------------------------- BLOCKED */

   private void drawBlocked(DrawContext ctx, float px, float y, float pw, float ph, int mx, int my) {
      List<FriendsManager.Blocked> list = social().blocked();
      if (list.isEmpty()) {
         centered(ctx, "You have not blocked anyone.",
            px + pw / 2.0F, y + ph / 2.0F - 4, XKit.MUTED, 9.0F);
         return;
      }
      float ry = y + 6 - this.scroll;
      for (FriendsManager.Blocked b : list) {
         if (ry + 26 > y && ry < y + ph) {
            SmoothRect.fill(ctx, px + 10, ry, pw - 20, 26, 4.0F, 0x22FFFFFF);
            TextPainter.drawPoppins(ctx, b.username(), px + 18, ry + 8,
               XKit.TEXT, 9.0F);
            button(ctx, "UNBLOCK", px + pw - 68, ry + 5, 56, 16, mx, my,
               "unblock:" + b.id(), true);
         }
         ry += 30;
      }
      clampScroll(ry + this.scroll - (y + ph));
   }

   /* ------------------------------------------------------------- PRIVACY */

   private void drawPrivacy(DrawContext ctx, float px, float y, float pw, float ph, int mx, int my) {
      FriendsManager.Privacy p = social().privacy();
      float ry = y + 6 - this.scroll;

      ry = cycleRow(ctx, "Who can send me requests", p.requestsFrom(),
         new String[] {"everyone", "friends_of_friends", "nobody"},
         "cyc:req", px, ry, pw, mx, my);
      ry = cycleRow(ctx, "Who can see I am online", p.onlineStatus(),
         new String[] {"everyone", "friends", "nobody"}, "cyc:online", px, ry, pw, mx, my);
      ry = cycleRow(ctx, "Who can see my server", p.currentServer(),
         new String[] {"everyone", "friends", "nobody"}, "cyc:server", px, ry, pw, mx, my);
      ry = cycleRow(ctx, "Who can see my last seen", p.lastSeen(),
         new String[] {"everyone", "friends", "nobody"}, "cyc:seen", px, ry, pw, mx, my);
      ry = toggleRow(ctx, "Notify me when friends come online",
         p.presenceNotifications(), "cyc:notify", px, ry, pw, mx, my);

      ry += 10;
      TextPainter.drawPoppins(ctx, "MINECRAFT ACCOUNT", px + 12, ry,
         XKit.MUTED, 8.0F);
      ry += 16;

      // Link the account you are currently logged in with. Premium names are
      // proved by the Edge Function, so you can only claim a paid name if that
      // account really is in your account manager.
      FriendsManager s = social();
      String mc = s.minecraftName();
      if (mc == null || mc.isBlank()) {
         TextPainter.drawPoppins(ctx, "Not linked. Links the account you are logged in as.",
            px + 12, ry + 5, XKit.MUTED, 7.5F);
         button(ctx, "LINK", px + pw - 92, ry, 80, 18, mx, my, "linkmc", !s.busy());
      } else {
         String line = mc + (s.minecraftVerified() ? "  (verified)" : "  (cracked)");
         TextPainter.drawPoppins(ctx, line, px + 12, ry + 5,
            s.minecraftVerified() ? XKit.GREEN : XKit.TEXT, 8.5F);
         button(ctx, "UNLINK", px + pw - 92, ry, 80, 18, mx, my, "unlinkmc", !s.busy());
      }
      ry += 26;

      TextPainter.drawPoppins(ctx, "ACCOUNT", px + 12, ry, XKit.MUTED, 8.0F);
      ry += 16;

      button(ctx, "MY PROFILE", px + 12, ry, 90, 18, mx, my, "myprofile", s.loggedIn());
      button(ctx, "LOG OUT", px + 108, ry, 80, 18, mx, my, "logout", true);
      ry = drawDangerZone(ctx, px, ry + 10, pw, mx, my);
      clampScroll(ry + 24 + this.scroll - (y + ph));
   }

   private float cycleRow(DrawContext ctx, String label, String value, String[] options,
                          String tag, float px, float y, float pw, int mx, int my) {
      TextPainter.drawPoppins(ctx, label, px + 12, y + 5, XKit.TEXT, 8.5F);
      String shown = pretty(value);
      float bw = 110.0F;
      float bx = px + pw - bw - 12;
      boolean over = hit(mx, my, bx, y, bw, 18);
      SmoothRect.fill(ctx, bx, y, bw, 18, 3.0F,
         over ? XKit.HOVER : 0x33FFFFFF);
      float sw = TextPainter.poppinsWidth(shown, 8.0F);
      TextPainter.drawPoppins(ctx, shown, bx + bw / 2.0F - sw / 2.0F, y + 5,
         XKit.TEXT, 8.0F);
      this.hits.add(new Hit(bx, y, bw, 18, tag));
      return y + 24;
   }

   private float toggleRow(DrawContext ctx, String label, boolean on,
                           String tag, float px, float y, float pw, int mx, int my) {
      TextPainter.drawPoppins(ctx, label, px + 12, y + 5, XKit.TEXT, 8.5F);
      float bw = 110.0F;
      float bx = px + pw - bw - 12;
      SmoothRect.fill(ctx, bx, y, bw, 18, 3.0F, on ? 0x3343D17A : 0x33FFFFFF);
      String shown = on ? "ON" : "OFF";
      float sw = TextPainter.poppinsWidth(shown, 8.0F);
      TextPainter.drawPoppins(ctx, shown, bx + bw / 2.0F - sw / 2.0F, y + 5,
         on ? XKit.GREEN : XKit.MUTED, 8.0F);
      this.hits.add(new Hit(bx, y, bw, 18, tag));
      return y + 24;
   }

   private static String pretty(String v) {
      return switch (v) {
         case "everyone" -> "Everyone";
         case "friends" -> "Friends";
         case "friends_of_friends" -> "Friends of friends";
         case "nobody" -> "Nobody";
         default -> v;
      };
   }

   /* ====================================================================== */
   /*  Small drawing helpers                                                 */
   /* ====================================================================== */

   private void centered(DrawContext ctx, String text, float cx, float y, int color, float size) {
      float w = TextPainter.poppinsWidth(text, size);
      TextPainter.drawPoppins(ctx, text, Math.round(cx - w / 2.0F), y, color, size);
   }

   private void field(DrawContext ctx, String id, String placeholder, String value,
                      float x, float y, float w, int mx, int my, boolean secret) {
      boolean focused = id.equals(this.focus);
      SmoothRect.fill(ctx, x, y, w, 20, 4.0F, 0x33000000);
      SmoothRect.outline(ctx, x, y, w, 20, 4.0F, 1.0F,
         focused ? XKit.BLUE : XKit.DIVIDER);

      String shown = secret ? "*".repeat(value.length()) : value;
      boolean empty = shown.isEmpty();
      if (empty) {
         shown = placeholder;
      }
      // Trim from the left so the caret end stays visible while typing.
      while (TextPainter.poppinsWidth(shown, 8.5F) > w - 14 && shown.length() > 1) {
         shown = shown.substring(1);
      }
      TextPainter.drawPoppins(ctx, shown, x + 7, y + 6,
         empty ? XKit.MUTED : XKit.TEXT, 8.5F);

      if (focused && (System.currentTimeMillis() / 500L) % 2L == 0L && !empty) {
         float cw = TextPainter.poppinsWidth(shown, 8.5F);
         ctx.fill((int) (x + 8 + cw), (int) y + 5, (int) (x + 9 + cw), (int) y + 15,
            XKit.TEXT);
      }
      this.hits.add(new Hit(x, y, w, 20, "focus:" + id));
   }

   private void button(DrawContext ctx, String label, float x, float y, float w, float h,
                       int mx, int my, String tag, boolean enabled) {
      boolean over = enabled && hit(mx, my, x, y, w, h);
      SmoothRect.fill(ctx, x, y, w, h, 3.0F,
         !enabled ? 0x22FFFFFF : over ? XKit.BLUE : 0x44FFFFFF);
      float tw = TextPainter.poppinsWidth(label, 7.5F);
      TextPainter.drawPoppins(ctx, label, Math.round(x + w / 2.0F - tw / 2.0F), y + h / 2.0F - 4.0F,
         enabled ? XKit.TEXT : XKit.MUTED, 7.5F);
      if (enabled) {
         this.hits.add(new Hit(x, y, w, h, tag));
      }
   }

   private static boolean hit(int mx, int my, float x, float y, float w, float h) {
      return mx >= x && mx <= x + w && my >= y && my <= y + h;
   }

   private void clampScroll(float overflow) {
      if (overflow <= 0.0F) {
         this.scroll = 0.0F;
      } else if (this.scroll > overflow) {
         this.scroll = overflow;
      }
      if (this.scroll < 0.0F) {
         this.scroll = 0.0F;
      }
   }

   private boolean isFriend(String id) {
      for (FriendsManager.Friend f : social().friends()) {
         if (f.id().equals(id)) {
            return true;
         }
      }
      return false;
   }

   private boolean isPendingOut(String id) {
      for (FriendsManager.Request r : social().outgoing()) {
         if (r.userId().equals(id)) {
            return true;
         }
      }
      return false;
   }

   /* ====================================================================== */
   /*  Input                                                                 */
   /* ====================================================================== */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) (click.x() / this.drawScale);
      int my = (int) (click.y() / this.drawScale);

      // Later hits are drawn on top, so test in reverse.
      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit hit = this.hits.get(i);
         if (mx >= hit.x && mx <= hit.x + hit.w && my >= hit.y && my <= hit.y + hit.h) {
            act(hit.tag);
            return true;
         }
      }
      this.focus = null;
      return super.mouseClicked(click, doubled);
   }

   private void act(String tag) {
      try {
         actInner(tag);
      } catch (Throwable t) {
         net.bluenetwork.client.BlueClient.LOGGER
            .error("[Social] action '{}' failed", tag, t);
         social().notifyUser("That action failed.", XKit.RED);
      }
   }

   private void actInner(String tag) {
      FriendsManager s = social();
      s.clearError();

      // ---- Blue+ colour studios ----
      if (tag.startsWith("nm:") || tag.startsWith("bg:")) {
         var studio = tag.startsWith("nm:") ? this.nameStudio : this.bgStudio;
         String rest = tag.substring(3);
         if (rest.startsWith("hue:")) {
            studio.setActive((int) Long.parseLong(rest.substring(4)));
            return;
         }
         if (rest.startsWith("grad:")) {
            studio.gradType = Integer.parseInt(rest.substring(5));
            if (studio.gradType == NameColor.GRAD_NONE) {
               studio.editingSecondary = false;
            }
            return;
         }
         if (rest.startsWith("end:")) {
            studio.editingSecondary = "1".equals(rest.substring(4));
            studio.hexDraft = "";
            return;
         }
         if (rest.equals("bold")) {
            studio.bold = !studio.bold;
            return;
         }
         if (rest.equals("italic")) {
            studio.italic = !studio.italic;
            return;
         }
         if (rest.equals("hexfocus")) {
            this.focus = tag.startsWith("nm:") ? "nmhex" : "bghex";
            return;
         }
         if (rest.equals("usehex")) {
            int c = net.bluenetwork.client.ui.ColorStudio.parseHex(studio.hexDraft);
            if (c != 0) {
               studio.setActive(c);
            }
            return;
         }
      }
      if (tag.equals("nmapply") || tag.equals("bgapply")) {
         boolean isName = tag.equals("nmapply");
         var studio = isName ? this.nameStudio : this.bgStudio;
         this.plusNotice = null;
         java.util.function.Consumer<String> done = err -> {
            this.plusOk = err == null;
            this.plusNotice = err == null ? "Saved" : err;
            if (err == null) {
               // Re-seed from the server's copy on the next frame so the draft
               // can never drift from what was actually stored.
               studio.invalidate();
            }
         };
         if (isName) {
            s.setNameColor(studio.toJson(), done);
         } else {
            s.setProfileColor(studio.toJson(), done);
         }
         return;
      }
      if (tag.equals("nmclear") || tag.equals("bgclear")) {
         boolean isName = tag.equals("nmclear");
         var studio = isName ? this.nameStudio : this.bgStudio;
         this.plusNotice = null;
         java.util.function.Consumer<String> done = err -> {
            this.plusOk = err == null;
            this.plusNotice = err == null ? "Cleared" : err;
            if (err == null) {
               studio.primary = 0xFF1D9BF0;
               studio.gradType = NameColor.GRAD_NONE;
               studio.bold = false;
               studio.italic = false;
               studio.hexDraft = "";
               studio.invalidate();
            }
         };
         if (isName) {
            s.setNameColor("", done);
         } else {
            s.setProfileColor("", done);
         }
         return;
      }
      if (tag.equals("close")) {
         close();
         return;
      }
      if (tag.startsWith("tab:")) {
         this.tab = tag.substring(4);
         this.scroll = 0.0F;
         this.confirmRemoveId = null;
         this.postNotice = null;
         this.redeemNotice = null;
         // Load a tab's data when it is opened, not on a timer: nobody is
         // looking at the timeline while they sit on the friends list.
         if (this.tab.equals("POSTS")) {
            s.refreshFeed();
         } else if (this.tab.equals("TOP")) {
            s.refreshLeaderboard();
         }
         return;
      }

      /* ---- v21 actions ---- */
      if (tag.equals("presence")) {
         String next = switch (s.presence() == null ? "online" : s.presence()) {
            case "online" -> "dnd";
            case "dnd" -> "offline";
            default -> "online";
         };
         // Going quiet should also clear anything already on screen, or a
         // DND player keeps staring at toasts they just asked not to get.
         if (!"online".equals(next)) {
            net.bluenetwork.client.notification.SocialToasts.clear();
         }
         s.setPresence(next, null);
         return;
      }
      if (tag.equals("dopost")) {
         String body = this.draftPost.trim();
         if (body.isEmpty()) {
            return;
         }
         this.postNotice = null;
         s.createPost(body, err -> {
            if (err == null) {
               this.draftPost = "";
            } else {
               this.postNotice = err;
            }
         });
         return;
      }
      if (tag.startsWith("invite:")) {
         this.postNotice = null;
         s.inviteHere(tag.substring(7), err ->
            s.notifyUser(err == null ? "Invite sent" : err,
               err == null ? XKit.GREEN : XKit.RED));
         return;
      }
      if (tag.startsWith("delpost:")) {
         s.deletePost(tag.substring(8), null);
         return;
      }
      if (tag.equals("close")) {
         this.client.setScreen(this.parent);
         return;
      }
      if (tag.equals("gopost")) {
         // The rail's Post button jumps to the timeline and focuses the box.
         this.tab = "POSTS";
         this.threadId = null;
         this.focus = "post";
         this.scroll = 0.0F;
         return;
      }
      if (tag.startsWith("like:")) {
         s.toggleLike(tag.substring(5), null);
         return;
      }
      if (tag.startsWith("repost:")) {
         s.toggleRepost(tag.substring(7), err -> {
            if (err != null) {
               s.notifyUser(err, XKit.RED);
            }
         });
         return;
      }
      if (tag.startsWith("reply:")) {
         // Opens the thread view, where the reply box lives.
         this.threadId = tag.substring(6);
         this.draftReply = "";
         this.scroll = 0.0F;
         s.loadReplies(this.threadId);
         return;
      }
      if (tag.equals("threadback")) {
         this.threadId = null;
         this.scroll = 0.0F;
         return;
      }
      if (tag.equals("sendreply")) {
         if (this.threadId != null && !this.draftReply.isBlank()) {
            String body = this.draftReply;
            s.replyToPost(this.threadId, body, err -> {
               this.replyNotice = err;
               if (err == null) {
                  this.draftReply = "";
               }
            });
         }
         return;
      }
      if (tag.equals("feed:foryou")) {
         s.feedMode(FriendsManager.FeedMode.FOR_YOU);
         this.scroll = 0.0F;
         return;
      }
      if (tag.equals("feed:following")) {
         s.feedMode(FriendsManager.FeedMode.FOLLOWING);
         this.scroll = 0.0F;
         return;
      }
      if (tag.equals("doredeem")) {
         String code = this.draftCode.trim();
         if (code.isEmpty()) {
            return;
         }
         s.redeem(code, msg -> {
            this.redeemNotice = msg;
            // A successful redeem is reported by the server flipping our
            // Blue+ state, which sync() picks up; clear the box either way.
            this.redeemOk = msg != null && msg.toLowerCase(java.util.Locale.ROOT)
               .matches(".*(activated|unlocked|redeemed).*");
            if (this.redeemOk) {
               this.draftCode = "";
            }
         });
         return;
      }
      if (tag.startsWith("profilename:")) {
         // Posts and the leaderboard carry only a username. profile_id_by_name
         // is one indexed lookup; the old path ran a full search and then
         // scanned the results, which could miss on a common prefix.
         String name = tag.substring(12);
         s.profileIdByName(name, id -> {
            if (id != null) {
               MinecraftClient.getInstance().execute(() -> openProfile(id));
            }
         });
         return;
      }
      if (tag.startsWith("openchat:")) {
         openChat(tag.substring(9));
         return;
      }
      if (tag.equals("chatback")) {
         this.chatId = null;
         this.scroll = 0.0F;
         return;
      }
      if (tag.equals("sendchat")) {
         String body = this.draftChat.trim();
         if (this.chatId != null && !body.isEmpty()) {
            String cid = this.chatId;
            this.draftChat = "";
            s.sendMessage(cid, body, () -> reloadChat(cid));
         }
         return;
      }
      if (tag.startsWith("pinpost:")) {
         s.pinPost(tag.substring(8), err -> {
            if (err != null) {
               s.notifyUser(err, XKit.RED);
            }
         });
         return;
      }
      if (tag.equals("unpinpost")) {
         s.unpinPost(err -> {
            if (err != null) {
               s.notifyUser(err, XKit.RED);
            }
         });
         return;
      }
      if (tag.startsWith("anaccent:")) {
         this.announceAccent = tag.substring(9);
         return;
      }
      if (tag.equals("adannounce")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_body", this.announceDraft.trim());
         a.addProperty("p_accent", this.announceAccent);
         a.addProperty("p_hours", 48);
         s.adminAction("admin_announce", a, err -> {
            this.adminNotice = err == null
               ? "Broadcast sent to everyone." : err;
            if (err == null) {
               this.announceDraft = "";
            }
         });
         return;
      }
      if (tag.startsWith("adkind:")) {
         this.codeKind = tag.substring(7);
         return;
      }
      if (tag.equals("admkcode")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_code", this.codeDraft.trim());
         a.addProperty("p_kind", this.codeKind);
         if (!"plus".equals(this.codeKind)) {
            a.addProperty("p_value", this.codeValue.trim());
         } else {
            int d = 0;
            try {
               d = this.codeDays.isBlank() ? 0 : Integer.parseInt(this.codeDays.trim());
            } catch (NumberFormatException ignored) {
               d = 0;
            }
            a.addProperty("p_days", d);
         }
         s.adminAction("admin_create_code", a, err -> {
            this.adminNotice = err == null
               ? "Created " + this.codeDraft.trim().toUpperCase(java.util.Locale.ROOT)
               : err;
            if (err == null) {
               this.codeDraft = "";
               this.codeValue = "";
               this.codeLoadedAt = 0L;
            }
         });
         return;
      }
      if (tag.startsWith("adrmcode:")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_code", tag.substring(9));
         s.adminAction("admin_delete_code", a, err -> {
            this.adminNotice = err == null ? "Code deleted." : err;
            this.codeLoadedAt = 0L;
         });
         return;
      }
      if (tag.startsWith("admdel:")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_post", tag.substring(7));
         s.adminAction("admin_delete_post", a, err -> {
            this.adminNotice = err == null ? "Post deleted." : err;
            this.adminLoadedAt = 0L;
         });
         return;
      }
      if (tag.startsWith("admdismiss:")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_report", Long.parseLong(tag.substring(11)));
         s.adminAction("admin_dismiss_report", a, err -> {
            this.adminNotice = err == null ? "Report dismissed." : err;
            this.adminLoadedAt = 0L;
         });
         return;
      }
      if (tag.startsWith("report:")) {
         s.reportPost(tag.substring(7), "Reported from the client", err ->
            s.notifyUser(err == null ? "Reported. Staff will review it."
               : err, err == null ? XKit.GREEN : XKit.RED));
         return;
      }
      if (tag.equals("saveskin")) {
         String want = this.editSkin.trim();
         s.setSkinName(want, err -> {
            this.editOk = err == null;
            this.editNotice = err == null
               ? (want.isEmpty() ? "Avatar reset." : "Avatar set to " + want) : err;
            if (err == null) {
               net.bluenetwork.client.account.PlayerHeads.forget(want);
            }
         });
         return;
      }
      if (tag.equals("savestatus")) {
         s.setStatus(this.editStatus, () -> {
            this.editOk = s.lastError() == null;
            this.editNotice = this.editOk ? "Status saved." : s.lastError();
         });
         return;
      }
      if (tag.equals("saveabout")) {
         s.setAbout(this.editAbout, () -> {
            this.editOk = s.lastError() == null;
            this.editNotice = this.editOk ? "About saved." : s.lastError();
         });
         return;
      }
      if (tag.startsWith("pickbadge:")) {
         String id = tag.substring(10);
         s.equipBadge("none".equals(id) ? null : id, () -> {
            this.editOk = true;
            this.editNotice = "none".equals(id) ? "Badge cleared." : "Badge equipped.";
         });
         return;
      }
      if (tag.equals("delarm")) {
         this.deleteArmed = true;
         this.deleteConfirm = "";
         this.deleteNotice = null;
         return;
      }
      if (tag.equals("delcancel")) {
         this.deleteArmed = false;
         this.deleteConfirm = "";
         this.deleteNotice = null;
         return;
      }
      if (tag.equals("delgo")) {
         s.deleteAccount(this.deleteConfirm, err -> {
            this.deleteNotice = err;
            if (err == null) {
               this.deleteArmed = false;
               this.deleteConfirm = "";
               this.tab = "POSTS";
            }
         });
         return;
      }
      if (tag.equals("tutdone")) {
         tutorialSeen = true;
         return;
      }
      if (tag.equals("myprofile")) {
         String mine = s.ownId();
         if (mine != null) {
            openProfile(mine);
         }
         return;
      }
      if (tag.startsWith("profile:")) {
         openProfile(tag.substring(8));
         return;
      }
      if (tag.equals("profileback")) {
         this.tab = this.profileReturnTab == null ? "POSTS" : this.profileReturnTab;
         this.viewProfile = null;
         this.viewProfileId = null;
         this.scroll = 0.0F;
         return;
      }
      if (tag.startsWith("sortposts:")) {
         this.viewSort = tag.substring(10);
         this.scroll = 0.0F;
         String id = this.viewProfileId;
         if (id != null) {
            s.loadUserPosts(id, this.viewSort, list -> {
               if (id.equals(this.viewProfileId)) {
                  this.viewPosts = list;
               }
            });
         }
         return;
      }
      if (tag.startsWith("follow:") || tag.startsWith("unfollow:")) {
         boolean following = tag.startsWith("unfollow:");
         String id = tag.substring(following ? 9 : 7);
         Runnable reload = () -> {
            if (id.equals(this.viewProfileId)) {
               s.loadProfile(id, prof -> this.viewProfile = prof);
            }
         };
         if (following) {
            s.unfollow(id, reload);
         } else {
            s.follow(id, reload);
         }
         return;
      }
      if (tag.startsWith("focus:")) {
         this.focus = tag.substring(6);
         return;
      }
      if (tag.equals("togglemode")) {
         this.registerMode = !this.registerMode;
         return;
      }
      if (tag.equals("submit")) {
         submitAuth();
         return;
      }
      if (tag.equals("logout")) {
         s.logOut(null);
         return;
      }
      if (tag.startsWith("request:")) {
         s.sendRequest(tag.substring(8), null);
         return;
      }
      if (tag.startsWith("accept:")) {
         s.acceptRequest(tag.substring(7), null);
         return;
      }
      if (tag.startsWith("decline:")) {
         s.declineRequest(tag.substring(8), null);
         return;
      }
      if (tag.startsWith("cancel:")) {
         s.cancelRequest(tag.substring(7), null);
         return;
      }
      if (tag.startsWith("askremove:")) {
         // Two-step so a misclick cannot silently delete a friend.
         this.confirmRemoveId = tag.substring(10);
         return;
      }
      if (tag.startsWith("doremove:")) {
         this.confirmRemoveId = null;
         s.removeFriend(tag.substring(9), null);
         return;
      }
      if (tag.equals("chatback")) {
         this.chatId = null;
         this.scroll = 0.0F;
         return;
      }
      if (tag.equals("sendchat")) {
         String body = this.draftChat.trim();
         if (this.chatId != null && !body.isEmpty()) {
            String cid = this.chatId;
            this.draftChat = "";
            s.sendMessage(cid, body, () -> reloadChat(cid));
         }
         return;
      }
      if (tag.startsWith("pinpost:")) {
         s.pinPost(tag.substring(8), err -> {
            if (err != null) {
               s.notifyUser(err, XKit.RED);
            }
         });
         return;
      }
      if (tag.equals("unpinpost")) {
         s.unpinPost(err -> {
            if (err != null) {
               s.notifyUser(err, XKit.RED);
            }
         });
         return;
      }
      if (tag.startsWith("dm:")) {
         // Opens the chat as a PAGE in this screen, not a separate popup.
         s.openDm(tag.substring(3), convId -> this.client.execute(() ->
            openChat(convId)));
         return;
      }
      if (tag.startsWith("join:")) {
         s.joinFriend(tag.substring(5));
         return;
      }
      if (tag.startsWith("open:")) {
         this.client.setScreen(new ChatScreen(this, tag.substring(5)));
         return;
      }
      if (tag.equals("newgroup")) {
         this.client.setScreen(new NewGroupScreen(this));
         return;
      }
      if (tag.startsWith("anaccent:")) {
         this.announceAccent = tag.substring(9);
         return;
      }
      if (tag.equals("adannounce")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_body", this.announceDraft.trim());
         a.addProperty("p_accent", this.announceAccent);
         a.addProperty("p_hours", 48);
         s.adminAction("admin_announce", a, err -> {
            this.adminNotice = err == null
               ? "Broadcast sent to everyone." : err;
            if (err == null) {
               this.announceDraft = "";
            }
         });
         return;
      }
      if (tag.startsWith("adkind:")) {
         this.codeKind = tag.substring(7);
         return;
      }
      if (tag.equals("admkcode")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_code", this.codeDraft.trim());
         a.addProperty("p_kind", this.codeKind);
         if (!"plus".equals(this.codeKind)) {
            a.addProperty("p_value", this.codeValue.trim());
         } else {
            int d = 0;
            try {
               d = this.codeDays.isBlank() ? 0 : Integer.parseInt(this.codeDays.trim());
            } catch (NumberFormatException ignored) {
               d = 0;
            }
            a.addProperty("p_days", d);
         }
         s.adminAction("admin_create_code", a, err -> {
            this.adminNotice = err == null
               ? "Created " + this.codeDraft.trim().toUpperCase(java.util.Locale.ROOT)
               : err;
            if (err == null) {
               this.codeDraft = "";
               this.codeValue = "";
               this.codeLoadedAt = 0L;
            }
         });
         return;
      }
      if (tag.startsWith("adrmcode:")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_code", tag.substring(9));
         s.adminAction("admin_delete_code", a, err -> {
            this.adminNotice = err == null ? "Code deleted." : err;
            this.codeLoadedAt = 0L;
         });
         return;
      }
      if (tag.startsWith("admdel:")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_post", tag.substring(7));
         s.adminAction("admin_delete_post", a, err -> {
            this.adminNotice = err == null ? "Post deleted." : err;
            this.adminLoadedAt = 0L;
         });
         return;
      }
      if (tag.startsWith("admdismiss:")) {
         com.google.gson.JsonObject a = new com.google.gson.JsonObject();
         a.addProperty("p_report", Long.parseLong(tag.substring(11)));
         s.adminAction("admin_dismiss_report", a, err -> {
            this.adminNotice = err == null ? "Report dismissed." : err;
            this.adminLoadedAt = 0L;
         });
         return;
      }
      if (tag.startsWith("report:")) {
         s.reportPost(tag.substring(7), "Reported from the client", err ->
            s.notifyUser(err == null ? "Reported. Staff will review it."
               : err, err == null ? XKit.GREEN : XKit.RED));
         return;
      }
      if (tag.equals("saveskin")) {
         String want = this.editSkin.trim();
         s.setSkinName(want, err -> {
            this.editOk = err == null;
            this.editNotice = err == null
               ? (want.isEmpty() ? "Avatar reset." : "Avatar set to " + want) : err;
            if (err == null) {
               net.bluenetwork.client.account.PlayerHeads.forget(want);
            }
         });
         return;
      }
      if (tag.equals("savestatus")) {
         s.setStatus(this.editStatus, () -> {
            this.editOk = s.lastError() == null;
            this.editNotice = this.editOk ? "Status saved." : s.lastError();
         });
         return;
      }
      if (tag.equals("saveabout")) {
         s.setAbout(this.editAbout, () -> {
            this.editOk = s.lastError() == null;
            this.editNotice = this.editOk ? "About saved." : s.lastError();
         });
         return;
      }
      if (tag.startsWith("pickbadge:")) {
         String id = tag.substring(10);
         s.equipBadge("none".equals(id) ? null : id, () -> {
            this.editOk = true;
            this.editNotice = "none".equals(id) ? "Badge cleared." : "Badge equipped.";
         });
         return;
      }
      if (tag.equals("delarm")) {
         this.deleteArmed = true;
         this.deleteConfirm = "";
         this.deleteNotice = null;
         return;
      }
      if (tag.equals("delcancel")) {
         this.deleteArmed = false;
         this.deleteConfirm = "";
         this.deleteNotice = null;
         return;
      }
      if (tag.equals("delgo")) {
         s.deleteAccount(this.deleteConfirm, err -> {
            this.deleteNotice = err;
            if (err == null) {
               this.deleteArmed = false;
               this.deleteConfirm = "";
               this.tab = "POSTS";
            }
         });
         return;
      }
      if (tag.equals("tutdone")) {
         tutorialSeen = true;
         return;
      }
      if (tag.equals("myprofile")) {
         String id = s.ownId();
         if (id != null) {
            this.client.setScreen(new ProfileScreen(this, id, true));
         }
         return;
      }
      if (tag.equals("linkmc")) {
         s.linkMinecraft(null);
         return;
      }
      if (tag.equals("unlinkmc")) {
         s.unlinkMinecraft(null);
         return;
      }
      if (tag.startsWith("block:")) {
         s.blockUser(tag.substring(6), null);
         return;
      }
      if (tag.startsWith("unblock:")) {
         s.unblockUser(tag.substring(8), null);
         return;
      }
      if (tag.startsWith("cyc:")) {
         cyclePrivacy(tag.substring(4));
      }
   }

   private void cyclePrivacy(String which) {
      FriendsManager s = social();
      FriendsManager.Privacy p = s.privacy();
      String[] three = {"everyone", "friends", "nobody"};
      String[] req = {"everyone", "friends_of_friends", "nobody"};

      FriendsManager.Privacy next = switch (which) {
         case "req" -> new FriendsManager.Privacy(cycle(req, p.requestsFrom()),
            p.onlineStatus(), p.currentServer(), p.lastSeen(), p.presenceNotifications());
         case "online" -> new FriendsManager.Privacy(p.requestsFrom(),
            cycle(three, p.onlineStatus()), p.currentServer(), p.lastSeen(), p.presenceNotifications());
         case "server" -> new FriendsManager.Privacy(p.requestsFrom(), p.onlineStatus(),
            cycle(three, p.currentServer()), p.lastSeen(), p.presenceNotifications());
         case "seen" -> new FriendsManager.Privacy(p.requestsFrom(), p.onlineStatus(),
            p.currentServer(), cycle(three, p.lastSeen()), p.presenceNotifications());
         case "notify" -> new FriendsManager.Privacy(p.requestsFrom(), p.onlineStatus(),
            p.currentServer(), p.lastSeen(), !p.presenceNotifications());
         default -> p;
      };
      s.savePrivacy(next, null);
   }

   private static String cycle(String[] options, String current) {
      for (int i = 0; i < options.length; i++) {
         if (options[i].equals(current)) {
            return options[(i + 1) % options.length];
         }
      }
      return options[0];
   }

   private void submitAuth() {
      FriendsManager s = social();
      String u = this.fieldUser.trim();
      String p = this.fieldPass;
      if (this.registerMode) {
         String err = SocialValidation.usernameError(u);
         if (err != null) {
            return;
         }
         s.signUp(u, p, () -> this.fieldPass = "");
      } else {
         s.logIn(u, p, () -> this.fieldPass = "");
      }
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.focus == null) {
         return super.charTyped(input);
      }
      String c = input.asString();
      if (c == null || c.isEmpty()) {
         return true;
      }
      switch (this.focus) {
         case "user" -> {
            if (this.fieldUser.length() < SocialValidation.MAX_LENGTH) {
               this.fieldUser += c;
            }
         }
         case "pass" -> this.fieldPass += c;
         case "search" -> {
            this.fieldSearch += c;
            onSearchTyped();
         }
         case "post" -> {
            // Allow a few characters past the cap so the counter can turn red
            // and explain itself, rather than the key silently doing nothing.
            if (this.draftPost.length() < social().limitOf("post") + 20) {
               this.draftPost += c;
            }
         }
         case "announce" -> {
            if (this.announceDraft.length() < 210) {
               this.announceDraft += c;
            }
         }
         case "adcode" -> {
            char ch = c.charAt(0);
            // Codes are A-Z 0-9 _ - only, so filter on input rather than
            // letting the server reject it afterwards.
            if ((Character.isLetterOrDigit(ch) || ch == '_' || ch == '-')
               && this.codeDraft.length() < 32) {
               this.codeDraft += c.toUpperCase(java.util.Locale.ROOT);
            }
         }
         case "advalue" -> {
            if (this.codeValue.length() < 40) {
               this.codeValue += c;
            }
         }
         case "addays" -> {
            if (Character.isDigit(c.charAt(0)) && this.codeDays.length() < 5) {
               this.codeDays += c;
            }
         }
         case "editskin" -> {
            if (this.editSkin.length() < 16) {
               this.editSkin += c;
            }
         }
         case "editstatus" -> {
            if (this.editStatus.length() < social().limitOf("status") + 10) {
               this.editStatus += c;
            }
         }
         case "editabout" -> {
            if (this.editAbout.length() < social().limitOf("about") + 20) {
               this.editAbout += c;
            }
         }
         case "delconfirm" -> {
            if (this.deleteConfirm.length() < 20) {
               this.deleteConfirm += c;
            }
         }
         case "chat" -> {
            if (this.draftChat.length() < 500) {
               this.draftChat += c;
            }
         }
         case "nmhex", "bghex" -> {
            // Hex only: '#' plus 6 digits. Filtering on input means the field
            // can never hold something the server will reject.
            var st = "nmhex".equals(this.focus) ? this.nameStudio : this.bgStudio;
            char ch = c.charAt(0);
            boolean okChar = ch == '#' || Character.digit(ch, 16) >= 0;
            if (okChar && st.hexDraft.length() < 7) {
               st.hexDraft += c.toUpperCase(java.util.Locale.ROOT);
            }
         }
         case "reply" -> {
            if (this.draftReply.length() < social().limitOf("post") + 20) {
               this.draftReply += c;
            }
         }
         case "code" -> {
            if (this.draftCode.length() < 32) {
               // Codes are stored uppercase; typing lowercase is fine.
               this.draftCode += c.toUpperCase(java.util.Locale.ROOT);
            }
         }
         default -> {
         }
      }
      return true;
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.focus != null) {
         if (key == GLFW.GLFW_KEY_BACKSPACE) {
            switch (this.focus) {
               case "user" -> this.fieldUser = drop(this.fieldUser);
               case "pass" -> this.fieldPass = drop(this.fieldPass);
               case "search" -> {
                  this.fieldSearch = drop(this.fieldSearch);
                  onSearchTyped();
               }
               case "post" -> this.draftPost = drop(this.draftPost);
               case "reply" -> this.draftReply = drop(this.draftReply);
               case "chat" -> this.draftChat = drop(this.draftChat);
               case "delconfirm" -> this.deleteConfirm = drop(this.deleteConfirm);
               case "announce" -> this.announceDraft = drop(this.announceDraft);
               case "adcode" -> this.codeDraft = drop(this.codeDraft);
               case "advalue" -> this.codeValue = drop(this.codeValue);
               case "addays" -> this.codeDays = drop(this.codeDays);
               case "editskin" -> this.editSkin = drop(this.editSkin);
               case "editstatus" -> this.editStatus = drop(this.editStatus);
               case "editabout" -> this.editAbout = drop(this.editAbout);
               case "nmhex" -> this.nameStudio.hexDraft = drop(this.nameStudio.hexDraft);
               case "bghex" -> this.bgStudio.hexDraft = drop(this.bgStudio.hexDraft);
               case "code" -> this.draftCode = drop(this.draftCode);
               default -> {
               }
            }
            return true;
         }
         if (key == GLFW.GLFW_KEY_TAB) {
            this.focus = "user".equals(this.focus) ? "pass" : "user";
            return true;
         }
         if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            if ("user".equals(this.focus) || "pass".equals(this.focus)) {
               submitAuth();
            } else if ("post".equals(this.focus)) {
               act("dopost");
            } else if ("chat".equals(this.focus)) {
               act("sendchat");
            } else if ("nmhex".equals(this.focus)) {
               act("nm:usehex");
            } else if ("bghex".equals(this.focus)) {
               act("bg:usehex");
            } else if ("reply".equals(this.focus)) {
               act("sendreply");
            } else if ("code".equals(this.focus)) {
               act("doredeem");
            }
            return true;
         }
         if (key == GLFW.GLFW_KEY_ESCAPE) {
            this.focus = null;
            return true;
         }
      }
      return super.keyPressed(input);
   }

   /** ARGB with a proportional alpha. */
   private static int withAlpha(int argb, float a) {
      int al = Math.max(0, Math.min(255, Math.round(a * 255.0F)));
      return (al << 24) | (argb & 0xFFFFFF);
   }

   private static String drop(String s) {
      return s.isEmpty() ? s : s.substring(0, s.length() - 1);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
      this.scroll -= (float) vAmount * 14.0F;
      if (this.scroll < 0.0F) {
         this.scroll = 0.0F;
      }
      return true;
   }

   /* ---- debounced search ------------------------------------------------ */

   private void onSearchTyped() {
      this.lastTypedMs = System.currentTimeMillis();
      this.searchPending = this.fieldSearch.trim().length() >= 2;
      if (!this.searchPending) {
         this.results = List.of();
      }
   }

   /**
    * Fires the search only once typing has paused.
    *
    * <p>Without this, "Notch" would send five requests. Called from render,
    * which is exactly where a time-based check belongs - it costs one
    * comparison per frame and starts no work until it is due.</p>
    */
   private void runSearchIfDue() {
      if (!this.searchPending) {
         return;
      }
      if (System.currentTimeMillis() - this.lastTypedMs < FriendsManager.SEARCH_DEBOUNCE_MS) {
         return;
      }
      this.searchPending = false;
      String q = this.fieldSearch.trim();
      social().search(q, list -> {
         // Ignore a late reply for a query the player has already changed.
         if (q.equals(this.fieldSearch.trim())) {
            this.results = list;
         }
      });
   }

   @Override
   public void close() {
      if (this.parent != null) {
         this.client.setScreen(this.parent);
      } else {
         super.close();
      }
   }

   /** A clickable rectangle registered during render. */
   private record Hit(float x, float y, float w, float h, String tag) {
   }
}
