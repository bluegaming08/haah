package net.bluenetwork.client.net;

import net.bluenetwork.client.BlueClient;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * The {@code blueclient:hello} handshake.
 *
 * <p>Implements §2 of {@code README-PLUGIN.md}, which was previously specified
 * but not built on the client side.</p>
 *
 * <h2>What it does</h2>
 * <ol>
 *   <li>About a second after joining a world, the client announces itself:
 *       {@code protocol:VarInt=1}, {@code version:String}, {@code mc:String}.
 *       The delay matters — the server needs time to register its own channel
 *       listener, otherwise the packet lands before anyone is listening.</li>
 *   <li>If the server replies ({@code accepted:Boolean},
 *       {@code multiplier:Float}) the client shows a toast. If it never
 *       replies, nothing happens and nothing breaks — a vanilla or
 *       non-Blue-Network server simply ignores an unknown channel.</li>
 * </ol>
 *
 * <h2>Trust</h2>
 * Per the plugin README: <b>this is a convenience signal, not a security
 * boundary.</b> Any modded client can forge it, so the server must never tie a
 * permission, rank or purchase to it.
 *
 * <h2>1.21.11 API notes</h2>
 * Raw {@code PacketByteBuf} channels are long gone; this is the modern
 * {@link CustomPayload} flow. Both directions must be registered with
 * {@link PayloadTypeRegistry} — C2S for what we send, S2C for what we receive
 * — or sending throws. Registration happens once at client init.
 */
public final class BlueHelloPacket {

   /** Channel id, shared with the server plugin. */
   public static final Identifier CHANNEL = Identifier.of("blueclient", "hello");

   /** Wire protocol version. Bump only with a matching plugin change. */
   private static final int PROTOCOL = 1;

   /** Ticks to wait after join before announcing (20 ticks = 1 second). */
   private static final int SEND_DELAY_TICKS = 20;

   /** Countdown to the announce, or -1 when idle. */
   private static int countdown = -1;

   private BlueHelloPacket() {
   }

   /* ===================================================================== */
   /* Payloads                                                              */
   /* ===================================================================== */

   /** Client → server announcement. */
   public record Hello(int protocol, String version, String mc) implements CustomPayload {

      public static final CustomPayload.Id<Hello> ID = new CustomPayload.Id<>(CHANNEL);

      public static final PacketCodec<RegistryByteBuf, Hello> CODEC =
         CustomPayload.codecOf(Hello::write, Hello::read);

      private static void write(Hello payload, RegistryByteBuf buf) {
         buf.writeVarInt(payload.protocol());
         buf.writeString(payload.version());
         buf.writeString(payload.mc());
      }

      private static Hello read(RegistryByteBuf buf) {
         // Bounded reads: a hostile server must not be able to make the client
         // allocate a huge string.
         return new Hello(buf.readVarInt(), buf.readString(64), buf.readString(64));
      }

      @Override
      public CustomPayload.Id<? extends CustomPayload> getId() {
         return ID;
      }
   }

   /** Server → client reply. */
   public record HelloReply(boolean accepted, float multiplier) implements CustomPayload {

      public static final CustomPayload.Id<HelloReply> ID = new CustomPayload.Id<>(CHANNEL);

      public static final PacketCodec<RegistryByteBuf, HelloReply> CODEC =
         CustomPayload.codecOf(HelloReply::write, HelloReply::read);

      private static void write(HelloReply payload, RegistryByteBuf buf) {
         buf.writeBoolean(payload.accepted());
         buf.writeFloat(payload.multiplier());
      }

      private static HelloReply read(RegistryByteBuf buf) {
         return new HelloReply(buf.readBoolean(), buf.readFloat());
      }

      @Override
      public CustomPayload.Id<? extends CustomPayload> getId() {
         return ID;
      }
   }

   /* ===================================================================== */
   /* Wiring                                                                */
   /* ===================================================================== */

   /**
    * Registers the payload types, the reply handler and the join hook.
    *
    * <p>Call once from {@code onInitializeClient}. Everything is wrapped so a
    * networking failure can never abort the entrypoint.</p>
    */
   public static void register() {
      try {
         PayloadTypeRegistry.playC2S().register(Hello.ID, Hello.CODEC);
         PayloadTypeRegistry.playS2C().register(HelloReply.ID, HelloReply.CODEC);

         ClientPlayNetworking.registerGlobalReceiver(HelloReply.ID, (payload, context) -> {
            // Handlers run on the network thread; touching the UI must be
            // deferred to the client thread.
            context.client().execute(() -> onReply(payload));
         });

         ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> countdown = SEND_DELAY_TICKS);
         ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            countdown = -1;
            // Totem pop counts are per-session; carrying them to the next
            // server would show stale numbers.
            net.bluenetwork.client.util.TotemTracker.reset();
         });

         BlueClient.LOGGER.info("Registered the {} channel", CHANNEL);
      } catch (Throwable t) {
         BlueClient.LOGGER.error("Could not register the blueclient:hello channel", t);
      }
   }

   /**
    * Drives the send delay. Call once per client tick.
    */
   public static void tick() {
      if (countdown < 0) {
         return;
      }
      if (--countdown > 0) {
         return;
      }
      countdown = -1;
      send();
   }

   /** Sends the announcement, if the server has advertised the channel. */
   private static void send() {
      try {
         // canSend is false unless the server registered the channel, so this
         // is also how we avoid spamming vanilla servers.
         if (!ClientPlayNetworking.canSend(Hello.ID)) {
            BlueClient.LOGGER.debug("Server does not support {}, skipping hello", CHANNEL);
            return;
         }
         String mc = net.fabricmc.loader.api.FabricLoader.getInstance()
            .getModContainer("minecraft")
            .map(c -> c.getMetadata().getVersion().getFriendlyString())
            .orElse("unknown");
         ClientPlayNetworking.send(new Hello(PROTOCOL, BlueClient.MOD_VERSION, mc));
         BlueClient.LOGGER.info("Sent {} (protocol {})", CHANNEL, PROTOCOL);
      } catch (Throwable t) {
         BlueClient.LOGGER.debug("Failed to send the hello packet", t);
      }
   }

   /** Shows the shard-multiplier toast when the server acknowledges us. */
   private static void onReply(HelloReply reply) {
      try {
         if (!reply.accepted()) {
            return;
         }
         if (reply.multiplier() > 1.0F) {
            // Trim a trailing ".0" so 2.0 reads as "2x", but 1.5 stays "1.5x".
            String m = reply.multiplier() == Math.rint(reply.multiplier())
               ? String.valueOf((int) reply.multiplier())
               : String.valueOf(reply.multiplier());
            BlueClient.getInstance().notificationManager()
               .add(m + "x shards active", 0xFF2FA5FF);
         } else {
            BlueClient.getInstance().notificationManager()
               .add("Blue Network connected", 0xFF2FA5FF);
         }
      } catch (Throwable t) {
         BlueClient.LOGGER.debug("Failed to handle the hello reply", t);
      }
   }
}
