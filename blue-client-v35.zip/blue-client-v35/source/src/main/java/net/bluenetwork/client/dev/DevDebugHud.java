package net.bluenetwork.client.dev;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.optimization.PerformanceOptimizer;
import net.bluenetwork.client.render.BlueFont;
import net.bluenetwork.client.ui.material.GlassPanel;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextPainter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Dev-only HUD overlay (Phase 0 → Phase 1): live FPS / memory / module-count /
 * screen / appearance readout in the top-right corner, drawn through the v2
 * toolkit (Poppins + glass panel + the global text effect) so it doubles as
 * the on-screen harness for the new render path. Only active when launched
 * with {@code -Dblueclient.dev=true}.
 */
public final class DevDebugHud {
   private static final float SIZE = 9.0F;
   private static final int PAD = 6;

   private DevDebugHud() {
   }

   public static void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null) {
         return;
      }
      BlueClient blue = BlueClient.getInstance();
      if (blue == null) {
         return;
      }

      List<String> lines = new ArrayList<>();
      lines.add("Blue Client DEV " + BlueClient.MOD_VERSION);
      lines.add("fps " + Math.round(PerformanceOptimizer.getCurrentFPS())
         + "  mem " + PerformanceOptimizer.getMemoryUsage() + " MB");
      lines.add("modules " + blue.moduleManager().getModules().size()
         + "  hud " + blue.moduleManager().getHudModules().size());
      lines.add("screen "
         + (mc.currentScreen == null ? "world" : mc.currentScreen.getClass().getSimpleName()));
      lines.add("fx " + blue.settings().textEffect().name().toLowerCase().replace("_", "-")
         + "  glass " + blue.settings().glassLevel().name().toLowerCase()
         + "  theme " + blue.settings().themeName());

      float width = 0.0F;
      for (String line : lines) {
         width = Math.max(width, TextPainter.poppinsWidth(line, SIZE));
      }
      float padF = PAD;
      float x = mc.getWindow().getScaledWidth() - width - padF * 2 - 4.0F - 8.0F;
      float y = 4.0F;
      float lineH = Math.max(SIZE + 2.0F, BlueFont.get("poppins").lineHeight(SIZE) + 1.0F);
      float h = lines.size() * lineH + padF * 2;

      GlassSurface level = blue.settings().glassLevel();
      GlassPanel.panel(context, x, y, width + padF * 2 + 4.0F, h, 10.0F, level, false, 0);

      float ty = y + padF + 1.0F;
      for (String line : lines) {
         TextPainter.drawPoppins(context, line, x + padF + 2.0F, ty, 0xFFFFFFFF, SIZE);
         ty += lineH;
      }
   }
}
