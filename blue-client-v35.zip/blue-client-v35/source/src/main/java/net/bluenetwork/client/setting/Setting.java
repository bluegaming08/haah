package net.bluenetwork.client.setting;

import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

/**
 * v3 settings-engine extension: every setting now supports (1) conditional
 * visibility ({@link #visibleWhen}) so a setting only shows when its parent
 * setting is relevant, and (2) value-change callbacks ({@link #onChange}) for
 * live updates. Both are additive — existing settings with no conditions stay
 * always-visible and fire nothing.
 */
public abstract class Setting<T> {
   private final String name;
   private final String description;
   private T value;
   private BooleanSupplier visibility = () -> true;
   private final List<Runnable> changeListeners = new ArrayList<>(2);

   protected Setting(String name, String description, T defaultValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
   }

   /** Marks this setting as shown only while {@code condition} returns true. */
   public Setting<T> visibleWhen(BooleanSupplier condition) {
      if (condition != null) {
         this.visibility = condition;
      }
      return this;
   }

   /** Runs {@code listener} after the value changes (called once per set). */
   public Setting<T> onChange(Runnable listener) {
      if (listener != null) {
         this.changeListeners.add(listener);
      }
      return this;
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public boolean isVisible() {
      try {
         return this.visibility.getAsBoolean();
      } catch (Throwable t) {
         return true;
      }
   }

   public T get() {
      return this.value;
   }

   public void set(T value) {
      boolean changed = this.value == null ? value != null : !this.value.equals(value);
      this.value = value;
      if (changed) {
         for (Runnable listener : this.changeListeners) {
            try {
               listener.run();
            } catch (Throwable ignored) {
            }
         }
      }
   }

   public abstract JsonElement toJson();

   public abstract void fromJson(JsonElement var1);
}
