package net.bluenetwork.client.cosmetics;

/**
 * Cosmetics v0.20.0 — Cape rarity tiers. Prices are in Blue Stars (this
 * mod's cosmetics currency, 1 per minute online on Blue Network, AFK
 * counts). EXCLUSIVE is never purchasable — those capes only exist because
 * the owner explicitly granted them to a UUID/username.
 */
public enum CapeRarity {
   COMMON("Common", 300, 0xFFB0B0B0),
   UNCOMMON("Uncommon", 600, 0xFF55D65E),
   RARE("Rare", 1200, 0xFF4A9CFF),
   EPIC("Epic", 2400, 0xFFB25CFF),
   LEGENDARY("Legendary", 4800, 0xFFFFC94A),
   // Rainbow — rendered as a shimmering gradient in the locker, not a flat
   // color; EXCLUSIVE_RGB below is only the fallback/base tint.
   EXCLUSIVE("Exclusive", -1, 0xFFFF4AC8);

   private final String displayName;
   private final int price;
   private final int color;

   CapeRarity(String displayName, int price, int color) {
      this.displayName = displayName;
      this.price = price;
      this.color = color;
   }

   public String displayName() {
      return this.displayName;
   }

   /** Price in Blue Stars, or -1 if not purchasable (EXCLUSIVE). */
   public int price() {
      return this.price;
   }

   public boolean purchasable() {
      return this.price >= 0;
   }

   /** Base UI tint (EXCLUSIVE gets an animated rainbow shimmer on top of this in the renderer). */
   public int color() {
      return this.color;
   }
}
