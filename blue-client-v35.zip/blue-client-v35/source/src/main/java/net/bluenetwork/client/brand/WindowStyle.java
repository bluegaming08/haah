package net.bluenetwork.client.brand;

import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import net.minecraft.util.Util;
import net.minecraft.util.Util.OperatingSystem;
import org.lwjgl.glfw.GLFWNativeWin32;

/**
 * Optional dark Windows title bar via DWM. JNA is NOT bundled with the mod —
 * we only use it when some other mod (or the launcher) already provides it on
 * the classpath. Bundling a second JNA would repeat the v1.0.0 OSHI classpath
 * conflict and break hardware reporting instance-wide.
 */
public final class WindowStyle {
   private WindowStyle() {
   }

   public static void apply() {
      try {
         if (Util.getOperatingSystem() != OperatingSystem.WINDOWS) {
            return;
         }
         Window window = MinecraftClient.getInstance().getWindow();
         long glfwHandle = window.getHandle();
         if (glfwHandle == 0L) {
            return;
         }
         long hwnd = GLFWNativeWin32.glfwGetWin32Window(glfwHandle);
         if (hwnd == 0L) {
            return;
         }
         // Only touch JNA if it is already on the classpath.
         if (!isJnaAvailable()) {
            BlueClient.LOGGER.debug("Dark title bar skipped - no JNA on the classpath");
            return;
         }
         WindowStyleJna.setDarkTitleBar(hwnd);
         BlueClient.LOGGER.info("Dark title bar applied");
      } catch (Throwable t) {
         BlueClient.LOGGER.debug("Dark title bar not applied", t);
      }
   }

   private static boolean isJnaAvailable() {
      try {
         Class.forName("com.sun.jna.Native", false, WindowStyle.class.getClassLoader());
         return true;
      } catch (Throwable t) {
         return false;
      }
   }
}
