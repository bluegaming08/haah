package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.util.Identifier;

/**
 * Motion Blur — smooth camera blur.
 *
 * <h2>Owner spec</h2>
 * <pre>
 *   add a smooth motion blur setting
 * </pre>
 *
 * <h2>Technique</h2>
 * Accumulation blur: each frame is blended with the previous finished frame.
 * Moving geometry smears into a short trail, static geometry is untouched
 * because both frames agree there. This is what the
 * "Motion Blur (Fabric)" mod all do — true per-object velocity blur needs a
 * motion-vector G-buffer that vanilla does not produce.
 *
 * <p>The actual blend happens in
 * {@code assets/blueclient/shaders/post/motion_blur.fsh}; see that file for
 * the maths. The pipeline that wires it up lives in
 * {@code assets/blueclient/post_effect/motion_blur_&lt;1-9&gt;.json}.</p>
 *
 * <h2>Why nine JSON files instead of one uniform?</h2>
 * A post-effect's uniform values are baked in when the pipeline is parsed, and
 * 1.21.11 gives no public API to push a new value per frame without rebuilding
 * the whole {@code PostEffectProcessor} (which recompiles shaders — a stutter
 * every time you move the slider). Nine pre-baked strengths cost a few hundred
 * bytes of JSON, are swapped instantly, and each one is compiled once and then
 * cached by {@code ShaderLoader}. Simple beats clever here.
 *
 * <h2>Performance / compatibility</h2>
 * One full-screen blend per frame — negligible. The "history" target is
 * {@code persistent}, which is what makes the previous frame survive. Known
 * caveats, same as every accumulation blur: with Sodium, set "CPU Render-Ahead
 * Limit" to 5 or higher, and it cannot coexist with OptiFine's own shaders.
 */
public class MotionBlur extends Module {

   /** Lowest / highest pre-baked pipeline index. */
   private static final int MIN_LEVEL = 1;
   private static final int MAX_LEVEL = 9;

   private final NumberSetting strength = new NumberSetting("Strength",
      "How long the trail lingers. 10 = a hint of smoothing, 90 = heavy smear",
      40.0, 10.0, 90.0, 10.0);

   public MotionBlur() {
      super("Motion Blur", "Smooth camera motion blur", Category.RENDER);
      this.addSettings(new Setting[]{this.strength});
   }

   /**
    * The post-effect to run this frame, or {@code null} when the module is off.
    * Called by {@code GameRendererMotionBlurMixin} once per frame — it must stay
    * allocation-free apart from the cached Identifier lookup below.
    */
   public static Identifier activeEffect() {
      Module module = BlueClient.getInstance().moduleManager().byName("Motion Blur");
      if (!(module instanceof MotionBlur blur) || !blur.isEnabled()) {
         return null;
      }
      return blur.effectId();
   }

   private Identifier cachedId;
   private int cachedLevel = -1;

   private Identifier effectId() {
      int level = Math.max(MIN_LEVEL, Math.min(MAX_LEVEL, (int) Math.round(this.strength.get() / 10.0)));
      if (level != this.cachedLevel) {
         this.cachedLevel = level;
         this.cachedId = Identifier.of("blueclient", "motion_blur_" + level);
      }
      return this.cachedId;
   }
}
