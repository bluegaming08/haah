package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;

public class PingDisplay extends HudModule {
   public PingDisplay() {
      super("Ping", "Shows your connection latency.", Category.HUD, 4, 70);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         ClientPlayNetworkHandler net = mc.getNetworkHandler();
         if (net != null) {
            PlayerListEntry entry = net.getPlayerListEntry(mc.player.getUuid());
            String text = entry != null ? "Ping: " + entry.getLatency() + "ms" : "Ping: ?";
            this.drawTextPanel(context, text);
         }
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Ping: 999ms") + 12 + 2;
   }
}
