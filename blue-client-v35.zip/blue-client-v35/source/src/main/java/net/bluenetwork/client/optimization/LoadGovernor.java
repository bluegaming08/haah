package net.bluenetwork.client.optimization;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextEffect;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.particle.ParticlesMode;

/**
 * LoadGovernor (Performance Charter §0.2, engine piece 2) — a quality ladder
 * that steps the client down when frames are slow and back up once they
 * recover. Ladder (quality 0 = richest):
 * <pre>
 *   0  GLASS + Shadow&amp;Glow + particles ALL   (what the user chose)
 *   1  MATTE + Shadow     + particles ALL
 *   2  FLAT  + no text fx + particles MINIMAL
 * </pre>
 * Steps require a sustained FPS reading (bad &ge; 20 checks below target / good
 * &ge; 60 checks above target+margin) to avoid flapping on one-frame dips.
 * Enabling snapshots the current glass/text/particle state; disabling restores
 * it exactly.
 */
public final class LoadGovernor {
   public static final int TOP = 0;
   public static final int MID = 1;
   public static final int BOTTOM = 2;

   private static boolean running = false;
   private static GlassSurface savedGlass;
   private static TextEffect savedText;
   private static ParticlesMode savedParticles;
   private static int level = TOP;
   private static int badStreak = 0;
   private static int goodStreak = 0;

   private LoadGovernor() {
   }

   public static void enable() {
      if (running) {
         return;
      }
      running = true;
      BlueClient blue = BlueClient.getInstance();
      if (blue != null && blue.settings() != null) {
         savedGlass = blue.settings().glassLevel();
         savedText = blue.settings().textEffect();
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         try {
            savedParticles = mc.options.getParticles().getValue();
         } catch (Throwable ignored) {
         }
      }
      level = TOP;
      badStreak = 0;
      goodStreak = 0;
   }

   public static void disable() {
      if (!running) {
         return;
      }
      running = false;
      restore(savedGlass, savedText, savedParticles);
      level = TOP;
      badStreak = 0;
      goodStreak = 0;
   }

   public static boolean running() {
      return running;
   }

   public static int level() {
      return level;
   }

   /**
    * Called ~5x/sec while the governing module is enabled.
    * @param fps the current FPS
    * @param targetFps FPS you want to hold
    * @param hysteresis margin before a step up is allowed
    */
   public static void tick(double fps, double targetFps, double hysteresis) {
      if (!running) {
         return;
      }
      if (fps <= 0.0) {
         return;
      }
      if (fps < targetFps - 5.0) {
         badStreak++;
         goodStreak = 0;
         if (badStreak >= 20 && level < BOTTOM) {
            badStreak = 0;
            setLevel(level + 1);
         }
      } else if (fps > targetFps + hysteresis && level > TOP) {
         goodStreak++;
         if (goodStreak >= 60) {
            goodStreak = 0;
            setLevel(level - 1);
         }
      } else {
         badStreak = Math.max(0, badStreak - 2);
         goodStreak = Math.max(0, goodStreak - 2);
      }
   }

   private static void setLevel(int next) {
      level = Math.max(TOP, Math.min(BOTTOM, next));
      BlueClient blue = BlueClient.getInstance();
      if (blue != null && blue.settings() != null) {
         switch (level) {
            case MID -> {
               blue.settings().glassLevel(GlassSurface.MATTE);
               blue.settings().textEffect(TextEffect.SHADOW);
            }
            case BOTTOM -> {
               blue.settings().glassLevel(GlassSurface.FLAT);
               blue.settings().textEffect(TextEffect.NONE);
               setParticles(ParticlesMode.MINIMAL);
            }
            default -> {
               blue.settings().glassLevel(GlassSurface.GLASS);
               blue.settings().textEffect(TextEffect.GLOW_SHADOW);
               setParticles(ParticlesMode.ALL);
            }
         }
      }
   }

   private static void setParticles(ParticlesMode mode) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         try {
            SimpleOption<ParticlesMode> option = mc.options.getParticles();
            option.setValue(mode);
         } catch (Throwable ignored) {
         }
      }
   }

   private static void restore(GlassSurface glass, TextEffect text, ParticlesMode particles) {
      BlueClient blue = BlueClient.getInstance();
      if (blue != null && blue.settings() != null) {
         blue.settings().glassLevel(glass);
         blue.settings().textEffect(text);
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null && particles != null) {
         try {
            mc.options.getParticles().setValue(particles);
         } catch (Throwable ignored) {
         }
      }
   }
}
