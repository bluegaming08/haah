package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.optimization.PerformanceOptimizer;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;

/**
 * Adaptive Render Distance (v3 catalogue G1) — watch the real FPS and step the
 * render distance down when it dips below the target, restoring it once the
 * frame rate recovers. Conservative: only drops to the configured minimum and
 * only ever goes back up to the distance you started with.
 *
 * <p>v0.16.1: the view-distance option is held through {@link OptionGuard}, so
 * other FOV/option modules can't capture our override as their "original".
 */
public class AdaptiveRenderDistance extends Module {
   private final NumberSetting targetFps = new NumberSetting("Target FPS", "Frames below this start the drop", 60.0, 30.0, 240.0, 5.0);
   private final NumberSetting minDistance = new NumberSetting("Min distance", "Lowest render distance allowed", 6.0, 2.0, 16.0, 1.0);
   private final NumberSetting checkInterval = new NumberSetting("Check every", "Seconds between FPS checks", 2.0, 1.0, 30.0, 1.0);
   private final BooleanSetting notify = new BooleanSetting("Notify", "Toast when the distance changes", true);

   private int baseDistance = -1;
   private int current = -1;
   private long lastCheck = 0L;

   public AdaptiveRenderDistance() {
      super("Adaptive Render Distance", "Lower render distance on FPS dips, restore after", Category.MISC);
      this.addSettings(new Setting[]{this.targetFps, this.minDistance, this.checkInterval, this.notify});
   }

   @Override
   protected void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         this.baseDistance = mc.options.getViewDistance().getValue();
         this.current = this.baseDistance;
         OptionGuard.hold(mc.options.getViewDistance(), this.current, this);
      }
      this.lastCheck = 0L;
   }

   @Override
   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         OptionGuard.release(mc.options.getViewDistance(), this);
      }
      this.baseDistance = -1;
      this.current = -1;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || mc.world == null) {
         return;
      }
      long now = System.currentTimeMillis();
      long intervalMs = (long) (this.checkInterval.get() * 1000.0);
      if (now - this.lastCheck < intervalMs) {
         return;
      }
      this.lastCheck = now;

      SimpleOption<Integer> view = mc.options.getViewDistance();
      if (this.baseDistance < 0) {
         this.baseDistance = view.getValue();
         this.current = this.baseDistance;
      }

      double fps = PerformanceOptimizer.getCurrentFPS();
      int min = (int) Math.round(this.minDistance.get());
      int floor = Math.max(2, Math.min(32, min));
      int target = (int) Math.round(this.targetFps.get());

      if (this.current > floor && fps > 0.0 && fps < target - 8.0) {
         this.apply(mc, this.current - 1, view);
      } else if (this.current < this.baseDistance && fps > target + 12.0) {
         this.apply(mc, Math.min(this.baseDistance, this.current + 1), view);
      }
   }

   private void apply(MinecraftClient mc, int next, SimpleOption<Integer> view) {
      if (next != this.current) {
         this.current = next;
         OptionGuard.hold(view, this.current, this);
         if (this.notify.get()) {
            try {
               net.bluenetwork.client.BlueClient.getInstance().notificationManager().add(
                  "Render distance " + this.current, 0xFF4D8DFF);
            } catch (Throwable ignored) {
            }
         }
      }
   }
}
