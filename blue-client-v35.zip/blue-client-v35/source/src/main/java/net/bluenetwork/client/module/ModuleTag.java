package net.bluenetwork.client.module;

/**
 * v3 module tags (BLUE_CLIENT_V3_MASTER_PLAN.md §2.1). Drive the Module Library
 * filters, the smoke test, and the server-safety badge. Intentionally distinct
 * from {@link Family}: a module has exactly one family but may carry many tags.
 */
public enum ModuleTag {
   HUD("hud", "Screen overlay"),
   INFO("info", "Shows information"),
   COSMETIC("cosmetic", "Look & feel"),
   CLARITY("clarity", "Makes things clearer"),
   COMFORT("comfort", "Quality of life"),
   ALERTS("alerts", "Notifications & warnings"),
   SOCIAL("social", "People & chat"),
   ITEMS("items", "Items & inventory"),
   UTILITY("utility", "Tools"),
   SERVER_SAFE("server-safe", "Safe on servers"),
   DISABLE_BY_DEFAULT("disable-by-default", "Off unless you turn it on");

   private final String id;
   private final String description;

   ModuleTag(String id, String description) {
      this.id = id;
      this.description = description;
   }

   public String id() {
      return this.id;
   }

   public String description() {
      return this.description;
   }
}
