package net.bluenetwork.client.module;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.bluenetwork.client.BlueClient;

/**
 * v3 module index (BLUE_CLIENT_V3_MASTER_PLAN.md §3.1). Builds one
 * {@link ModuleInfo} per registered module — from {@link ModuleInfoProvider}
 * when a module declares it, otherwise synthesised from the legacy fields so
 * the existing 29 modules appear in the Library without any edits.
 *
 * <p>Designed to be purely read-side for now (no writes to the legacy registry);
 * the live enable/keybind state stays owned by {@link ModuleManager}.</p>
 */
public final class ModuleCatalogue {
   private final Map<String, ModuleInfo> byId = new LinkedHashMap<>();

   public ModuleCatalogue() {
      refresh();
   }

   /** Rebuilds the index from the current registry. Cheap enough to call on screen open. */
   public void refresh() {
      BlueClient blue = BlueClient.getInstance();
      if (blue == null) {
         return;
      }
      byId.clear();
      Collection<Module> modules = blue.moduleManager().getModules();
      for (Module module : modules) {
         ModuleInfo info;
         if (module instanceof ModuleInfoProvider provider && provider.moduleInfo() != null) {
            info = provider.moduleInfo();
         } else {
            info = synthesise(module);
         }
         byId.put(info.id() != null ? info.id() : info.name(), info);
      }
   }

   private static ModuleInfo synthesise(Module module) {
      ModuleInfo.Builder b = ModuleInfo.builder()
         .name(module.getName())
         .description(module.getDescription());
      Family family = Family.ofLegacy(module.getCategory());
      b.family(family);
      String id = module.getName().toLowerCase().replace(' ', '-');
      b.id(id);
      if (module.getKeybind() != 0) {
         b.defaultKey(module.getKeybind());
      }
      b.requiresWorld(true);
      b.since("0.15.0");
      if (module.isRequired()) {
         b.tags(ModuleTag.SERVER_SAFE);
      }
      return b.build();
   }

   public Collection<ModuleInfo> all() {
      return Collections.unmodifiableCollection(byId.values());
   }

   public List<ModuleInfo> byFamily(Family family) {
      List<ModuleInfo> result = new ArrayList<>();
      for (ModuleInfo info : byId.values()) {
         if (info.family() == family) {
            result.add(info);
         }
      }
      return result;
   }

   public ModuleInfo byId(String id) {
      return byId.get(id);
   }

   public int size() {
      return byId.size();
   }
}
