package net.bluenetwork.client.music;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * On-disk cache of resolved lyrics, so a song is only ever looked up once.
 *
 * <h2>Why this exists instead of just the .lrc sidecar</h2>
 * The music player already wrote a {@code .lrc} next to the audio file, but
 * that has three problems the owner ran into:
 * <ul>
 *   <li><b>Poisoned cache.</b> Every build before {@code 0.24.7} picked lyrics
 *       without a working duration match, so it frequently saved the timings of
 *       a <i>different master</i> of the song. Those sidecars look perfectly
 *       valid and would be trusted forever - the sync bug would appear "fixed
 *       for new songs only". This cache carries a {@link #CACHE_VERSION} stamp,
 *       so everything written by the buggy versions is ignored automatically.</li>
 *   <li><b>User files got overwritten / confused.</b> A hand-made {@code .lrc}
 *       is indistinguishable from one we generated. We now only ever write into
 *       our own cache directory and leave the user's files completely alone.</li>
 *   <li><b>Read-only or shared folders.</b> Music on a network share or a
 *       read-only drive could not be cached at all.</li>
 * </ul>
 *
 * <p>Entries live in {@code .minecraft/config/blueclient/lyrics/} and are keyed
 * by title + artist + duration, so two masters of the same song cache
 * separately and never collide.</p>
 *
 * <p>Every method fails soft: a broken cache must never stop playback or the
 * online lookup.</p>
 */
public final class LyricsCache {

   /**
    * Bump this whenever a bug could have written WRONG lyrics to disk.
    *
    * <p>Entries stamped with an older version are ignored and re-fetched.
    * v2 = the 0.24.7 duration-matching fix. v3 = 0.25.0 display/position fixes.</p>
    */
   private static final int CACHE_VERSION = 3;

   /** Header written as the first line of every cache file. */
   private static final String STAMP = "#blueclient-lyrics-v" + CACHE_VERSION;

   /** Cache entries older than this are refreshed (lyrics do get corrected upstream). */
   private static final long MAX_AGE_MS = 90L * 24L * 60L * 60L * 1000L;

   private LyricsCache() {
   }

   private static Path cacheDir() {
      return net.fabricmc.loader.api.FabricLoader.getInstance()
         .getConfigDir().resolve("blueclient").resolve("lyrics");
   }

   /**
    * Builds a stable, filesystem-safe filename for a track.
    *
    * <p>Duration is part of the key on purpose: LRCLIB carries both a 177 s and
    * a 303 s "catch me" by JVKE, and they need different timings.</p>
    */
   private static String keyFor(String title, String artist, int durationSec) {
      String raw = (title == null ? "" : title).trim().toLowerCase(Locale.ROOT)
         + "|" + (artist == null ? "" : artist).trim().toLowerCase(Locale.ROOT)
         + "|" + (durationSec > 0 ? durationSec : 0);
      StringBuilder safe = new StringBuilder();
      for (char c : raw.toCharArray()) {
         safe.append(Character.isLetterOrDigit(c) ? c : '_');
      }
      // Append a hash so different songs can never collide after sanitising.
      return (safe.length() > 60 ? safe.substring(0, 60) : safe.toString())
         + "_" + Integer.toHexString(raw.hashCode()) + ".lrc";
   }

   /**
    * @return cached lyrics for this track, or {@code null} for a miss.
    */
   public static LyricsProvider.Lyrics load(String title, String artist, int durationSec) {
      try {
         Path file = cacheDir().resolve(keyFor(title, artist, durationSec));
         if (!Files.isRegularFile(file)) {
            return null;
         }
         List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
         if (lines.isEmpty() || !STAMP.equals(lines.get(0).trim())) {
            // Written by a version whose matching was broken - drop it.
            Files.deleteIfExists(file);
            return null;
         }
         if (System.currentTimeMillis() - Files.getLastModifiedTime(file).toMillis() > MAX_AGE_MS) {
            return null;
         }
         StringBuilder body = new StringBuilder();
         for (int i = 1; i < lines.size(); i++) {
            body.append(lines.get(i)).append('\n');
         }
         if (body.toString().isBlank()) {
            return null;
         }
         LyricsProvider.Lyrics synced = LyricsProvider.parseSyncedPublic(body.toString());
         if (synced != null && !synced.lines().isEmpty()) {
            return synced;
         }
         LyricsProvider.Lyrics plain = LyricsProvider.parsePlainPublic(body.toString());
         return plain != null && !plain.lines().isEmpty() ? plain : null;
      } catch (Throwable t) {
         return null;
      }
   }

   /** Stores resolved lyrics. Silently does nothing on any failure. */
   public static void save(String title, String artist, int durationSec,
                           LyricsProvider.Lyrics lyrics) {
      try {
         if (lyrics == null || lyrics.lines().isEmpty()) {
            return;
         }
         Path dir = cacheDir();
         Files.createDirectories(dir);
         StringBuilder sb = new StringBuilder(STAMP).append('\n');
         for (LyricsProvider.Line line : lyrics.lines()) {
            if (lyrics.synced()) {
               long m = line.ms() / 60000L;
               double sec = (line.ms() % 60000L) / 1000.0D;
               sb.append(String.format(Locale.ROOT, "[%02d:%05.2f]", m, sec));
            }
            sb.append(line.text()).append('\n');
         }
         Files.writeString(dir.resolve(keyFor(title, artist, durationSec)), sb.toString(),
            StandardCharsets.UTF_8);
      } catch (Throwable ignored) {
      }
   }

   /**
    * Deletes every cached entry.
    *
    * @return how many files were removed.
    */
   public static int clear() {
      int removed = 0;
      try {
         Path dir = cacheDir();
         if (!Files.isDirectory(dir)) {
            return 0;
         }
         List<Path> doomed = new ArrayList<>();
         try (var stream = Files.list(dir)) {
            stream.filter(p -> p.getFileName().toString().endsWith(".lrc")).forEach(doomed::add);
         }
         for (Path p : doomed) {
            if (Files.deleteIfExists(p)) {
               removed++;
            }
         }
      } catch (Throwable ignored) {
      }
      return removed;
   }
}
