package net.bluenetwork.client.module;

/**
 * v3 module families (BLUE_CLIENT_V3_MASTER_PLAN.md §2.1). Families are the
 * user-facing organisation for the Module Library and are richer than the
 * legacy {@link Category}. Each family maps to a legacy {@link Category} so
 * every existing code path (click-GUI tabs, HUD editor grouping) keeps working
 * for modules of any vintage.
 */
public enum Family {
   HUD("HUD", Category.HUD),
   VISUALS("Visuals", Category.RENDER),
   CHAT("Chat", Category.MISC),
   AUDIO("Audio", Category.MISC),
   ITEMS("Items", Category.MISC),
   MOVEMENT("Movement", Category.MOVEMENT),
   PERFORMANCE("Performance", Category.MISC),
   UTILITY("Utility", Category.MISC);

   private final String displayName;
   private final Category legacyCategory;

   Family(String displayName, Category legacyCategory) {
      this.displayName = displayName;
      this.legacyCategory = legacyCategory;
   }

   public String displayName() {
      return this.displayName;
   }

   /** Legacy category used for anything that still switches on Category. */
   public Category legacyCategory() {
      return this.legacyCategory;
   }

   public static Family ofLegacy(Category category) {
      if (category == null) {
         return UTILITY;
      }
      return switch (category) {
         case HUD -> HUD;
         case COMBAT -> HUD; // combat-category HUDs (CPS/Combo/Reach) are still HUD family
         case MOVEMENT -> MOVEMENT;
         case RENDER -> VISUALS;
         default -> UTILITY;
      };
   }
}
