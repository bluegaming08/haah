package net.bluenetwork.client.ui.widget;

import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.ui.material.GlassPanel;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.DrawContext;

/**
 * Pill-style glass button (BLUE_CLIENT_V3_MASTER_PLAN.md §4.2). Hover lifts
 * the accent hairline; clicks play the standard UI click. Text is drawn through
 * {@link TextPainter} so the global text-effect setting applies.
 */
public class Button extends Widget {
   private final String label;
   private final String icon;
   private final Runnable action;
   private final boolean accent;

   public Button(String label, String icon, boolean accent, Runnable action) {
      this.label = label == null ? "" : label;
      this.icon = icon;
      this.accent = accent;
      this.action = action;
   }

   public Button(String label, Runnable action) {
      this(label, null, false, action);
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, long nowMs) {
      boolean hovered = hovered(mouseX, mouseY);
      int radius = Math.max(4, h / 2);
      GlassSurface level = GlassSurface.defaultSurface();
      boolean active = accent || hovered;
      int border = active ? DesignTokens.accent() : 0;
      GlassPanel.panel(context, x, y, w, h, radius, level, active, border);

      int contentX = x;
      if (icon != null && !icon.isEmpty()) {
         int iconSize = Math.max(8, h - 12);
         RenderUtil.drawIcon(context, icon, x + 8, y + (h - iconSize) / 2, iconSize,
            accent || hovered ? DesignTokens.accent() : DesignTokens.textMid());
         contentX = x + 8 + iconSize + 6;
      }

      int textColor = accent ? DesignTokens.textHi() : (hovered ? DesignTokens.textHi() : DesignTokens.textMid());
      float size = 9.0F;
      float textWidth = TextPainter.poppinsWidth(label, size);
      float cx = contentX + (w - (contentX - x) - textWidth) / 2.0F;
      TextPainter.drawPoppins(context, label, cx, y + (h - 9.0F) / 2.0F, textColor, size);
   }

   @Override
   public boolean mouseClicked(int mouseX, int mouseY, int button) {
      if (button == 0 && contains(mouseX, mouseY)) {
         RenderUtil.clickSound();
         if (action != null) {
            action.run();
         }
         return true;
      }
      return false;
   }
}
