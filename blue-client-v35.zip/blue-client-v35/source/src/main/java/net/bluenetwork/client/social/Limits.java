package net.bluenetwork.client.social;

/**
 * The free / Blue+ limits, mirrored from the database.
 *
 * <h2>Why these numbers exist twice</h2>
 * The <b>database</b> is the authority - {@code limit_of()} in schema_v3.sql
 * enforces every one of these server-side, so a modified client gains nothing
 * by lying. These copies exist purely so the UI can show "12/25" and grey out
 * a button <i>before</i> a request is sent, instead of letting the player type
 * a long post and only then being told no.
 *
 * <p>If you change a number here, change it in {@code limit_of()} too, or the
 * client will promise something the server refuses.</p>
 */
public final class Limits {

   private Limits() {
   }

   /** Characters allowed in an "about me". */
   public static final int ABOUT_FREE = 50;
   public static final int ABOUT_PLUS = 100;

   /** Characters allowed in a status. */
   public static final int STATUS_FREE = 25;
   public static final int STATUS_PLUS = 40;

   /** Characters allowed in a post. */
   public static final int POST_FREE = 25;
   public static final int POST_PLUS = 100;

   /** Friends you may have. */
   public static final int FRIENDS_FREE = 15;
   public static final int FRIENDS_PLUS = 40;

   /** People you may follow. Blue and Cyan do not count toward this. */
   public static final int FOLLOWING_FREE = 15;
   public static final int FOLLOWING_PLUS = 50;

   /** Posts allowed per hour. */
   public static final int POSTS_HOUR_FREE = 2;
   public static final int POSTS_HOUR_PLUS = 4;

   /**
    * Looks up a limit by the same key the SQL function uses.
    *
    * @param key  one of about, status, post, friends, following, posts_hour
    * @param plus whether the account has Blue+
    */
   public static int of(String key, boolean plus) {
      return switch (key) {
         case "about" -> plus ? ABOUT_PLUS : ABOUT_FREE;
         case "status" -> plus ? STATUS_PLUS : STATUS_FREE;
         case "post" -> plus ? POST_PLUS : POST_FREE;
         case "friends" -> plus ? FRIENDS_PLUS : FRIENDS_FREE;
         case "following" -> plus ? FOLLOWING_PLUS : FOLLOWING_FREE;
         case "posts_hour" -> plus ? POSTS_HOUR_PLUS : POSTS_HOUR_FREE;
         default -> 0;
      };
   }

   /** Price shown in the Blue+ tab. */
   /**
    * Blue+ price. Owner set this to $4.99/month with NO auto-renewal, so the
    * UI must never use the word "renews" - a lapsed subscription simply ends
    * and the player redeems again when they choose to.
    */
   public static final String PLUS_PRICE = "$4.99/month";

   /** Shown under the price so the no-auto-renew promise is explicit. */
   public static final String PLUS_TERMS = "One-time payment - no auto-renewal";

   /**
    * Turns a Blue+ start date into "Blue Plus user since 3 months ago".
    *
    * @param sinceEpochSeconds epoch seconds, or 0 if unknown
    */
   public static String plusSinceText(long sinceEpochSeconds) {
      if (sinceEpochSeconds <= 0L) {
         return "Blue Plus user";
      }
      long days = (System.currentTimeMillis() / 1000L - sinceEpochSeconds) / 86_400L;
      if (days < 1L) {
         return "Blue Plus user since today";
      }
      if (days == 1L) {
         return "Blue Plus user since yesterday";
      }
      if (days < 30L) {
         return "Blue Plus user for " + days + " days";
      }
      long months = days / 30L;
      if (months < 12L) {
         return "Blue Plus user for " + months + (months == 1L ? " month" : " months");
      }
      long years = days / 365L;
      long rem = (days % 365L) / 30L;
      if (rem == 0L) {
         return "Blue Plus user for " + years + (years == 1L ? " year" : " years");
      }
      return "Blue Plus user for " + years + "y " + rem + "m";
   }
}
