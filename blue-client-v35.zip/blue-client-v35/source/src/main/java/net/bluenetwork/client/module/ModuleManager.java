package net.bluenetwork.client.module;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.bluenetwork.client.hud.impl.ArmorHud;
import net.bluenetwork.client.hud.impl.ArmorDurability;
import net.bluenetwork.client.hud.impl.AttackIndicator;
import net.bluenetwork.client.hud.impl.BiomeHud;
import net.bluenetwork.client.hud.impl.ClockHud;
import net.bluenetwork.client.hud.impl.CoordinatesDisplay;
import net.bluenetwork.client.hud.impl.DayCounter;
import net.bluenetwork.client.hud.impl.DirectionHud;
import net.bluenetwork.client.hud.impl.ElytraAssist;
import net.bluenetwork.client.hud.impl.FpsDisplay;
import net.bluenetwork.client.hud.impl.FpsGraph;
import net.bluenetwork.client.hud.impl.HealthNumbers;
import net.bluenetwork.client.hud.impl.DimensionDisplay;
import net.bluenetwork.client.hud.impl.ItemCountdown;
import net.bluenetwork.client.hud.impl.Keystrokes;
import net.bluenetwork.client.hud.impl.PingDisplay;
import net.bluenetwork.client.hud.impl.FrameTimes;
import net.bluenetwork.client.hud.impl.PlaytimeHud;
import net.bluenetwork.client.hud.impl.ServerInfoHud;
import net.bluenetwork.client.hud.impl.ServerTicks;
import net.bluenetwork.client.hud.impl.SessionStats;
import net.bluenetwork.client.hud.impl.Speedometer;
import net.bluenetwork.client.hud.impl.SunPosition;
import net.bluenetwork.client.hud.impl.PotionTimers;
import net.bluenetwork.client.hud.impl.NetherCoords;
import net.bluenetwork.client.hud.impl.HungerNumbers;
import net.bluenetwork.client.hud.impl.TotemCounter;
import net.bluenetwork.client.module.impl.AlarmTimer;
import net.bluenetwork.client.module.impl.ChatHeight;
import net.bluenetwork.client.module.impl.DurabilityWarning;
import net.bluenetwork.client.module.impl.ChatTimestamps;
import net.bluenetwork.client.module.impl.ComboHud;
import net.bluenetwork.client.module.impl.CpsHud;
import net.bluenetwork.client.module.impl.CustomCrosshair;
import net.bluenetwork.client.module.impl.BluePlusPerks;
import net.bluenetwork.client.module.impl.Fullbright;
/*
 * v0.24.0 FIX - "the cosmetics menu doesnt work".
 * Root cause: CosmeticsModule existed but was never listed in the registration
 * block below, so it had no entry in the modules menu and no keybind. The
 * cosmetics MANAGER was wired into BlueClient, which is why capes still loaded
 * and made the bug look like a rendering problem instead of a missing row.
 */
import net.bluenetwork.client.cosmetics.CosmeticsModule;
import net.bluenetwork.client.module.impl.MotionBlur;
import net.bluenetwork.client.module.impl.ScreenRecorder;
import net.bluenetwork.client.module.impl.TimeChanger;
import net.bluenetwork.client.module.impl.WeatherChanger;
import net.bluenetwork.client.module.impl.LowHealthAlert;
import net.bluenetwork.client.module.impl.MentionHighlight;
import net.bluenetwork.client.module.impl.MemoryWatchdog;
import net.bluenetwork.client.module.impl.MusicPlayer;
import net.bluenetwork.client.module.impl.NoHurtCam;
import net.bluenetwork.client.module.impl.ReachHud;
import net.bluenetwork.client.module.impl.ToggleSneak;
import net.bluenetwork.client.module.impl.ToggleSprint;
import net.bluenetwork.client.module.impl.Zoom;
import net.bluenetwork.client.module.impl.SprintModes;
import net.bluenetwork.client.module.impl.AdaptiveRenderDistance;
import net.bluenetwork.client.module.impl.AlwaysParticles;
import net.bluenetwork.client.module.impl.HitColor;
import net.bluenetwork.client.module.impl.HitMarker;
import net.bluenetwork.client.module.impl.HitSound;
import net.bluenetwork.client.module.impl.AttackChime;
import net.bluenetwork.client.module.impl.ChunkLoadIndicator;
import net.bluenetwork.client.module.impl.FrameSmooth;
import net.bluenetwork.client.module.impl.UISoundPack;
import net.bluenetwork.client.hud.impl.KeybindViewer;
import net.bluenetwork.client.hud.impl.SessionNotes;
import net.bluenetwork.client.module.impl.VolumeMixer;
import net.bluenetwork.client.module.impl.PickupTracker;
import net.bluenetwork.client.module.impl.FriendPresence;
import net.bluenetwork.client.module.impl.ChatLogger;
import net.bluenetwork.client.module.impl.ChatCleaner;
import net.bluenetwork.client.hud.impl.WaypointArrow;
import net.bluenetwork.client.hud.impl.TargetInfo;
import net.bluenetwork.client.module.impl.AutoQuality;
import net.bluenetwork.client.module.impl.HighlightManager;
import net.bluenetwork.client.module.impl.NameFormatter;
import net.bluenetwork.client.module.impl.DropWarning;
import net.bluenetwork.client.module.impl.LowFoodAlert;
import net.bluenetwork.client.module.impl.CustomFov;
import net.bluenetwork.client.module.impl.CoordsConverter;
import net.bluenetwork.client.module.impl.ModuleSearch;
import net.bluenetwork.client.hud.impl.HotbarInfo;
import net.bluenetwork.client.hud.impl.LightLevel;
import net.bluenetwork.client.hud.impl.ServerIp;
import net.bluenetwork.client.hud.impl.PlayerCount;
import net.bluenetwork.client.hud.impl.AirMeter;
import net.bluenetwork.client.hud.impl.PerfMonitor;
import net.bluenetwork.client.hud.impl.XpProgress;
import net.bluenetwork.client.hud.impl.MountHealth;
import net.bluenetwork.client.hud.impl.MoonPhase;
import net.bluenetwork.client.hud.impl.ChunkPosition;
import net.bluenetwork.client.hud.impl.LookedBlock;
import net.bluenetwork.client.hud.impl.SpawnDistance;
import net.bluenetwork.client.module.impl.DeathCoords;
import net.bluenetwork.client.module.impl.SleepReminder;

public class ModuleManager {
   private final Map<String, Module> modules = new LinkedHashMap<>();
   private List<HudModule> hudCache = null;

   /**
    * Registers modules.
    *
    * <h3>Why each module is wrapped in its own try/catch</h3>
    * Registration happens inside the Fabric client entrypoint. Anything thrown
    * here aborts the entrypoint and the game dies on the loading screen with
    * "Could not execute entrypoint stage 'client'" — the user loses the ENTIRE
    * client, not just the broken feature.
    *
    * <p>That is exactly what happened in 0.24.0: {@code ScreenRecorder}'s field
    * initialiser linked JCodec, JCodec's nested jar was not declared in
    * {@code fabric.mod.json}, and a {@link NoClassDefFoundError} took the whole
    * game down. Note it is an {@link Error}, not an {@link Exception} — hence
    * {@code catch (Throwable)}.</p>
    *
    * <p>A module that fails to construct is skipped and logged loudly. Everything
    * else still loads. Never "tidy" this back into an unguarded loop.</p>
    */
   public void register(Module... toRegister) {
      for (Module module : toRegister) {
         // null = a module that failed to construct (see safely()).
         if (module == null) {
            continue;
         }
         try {
            this.modules.put(module.getName().toLowerCase(), module);
            // HUD modules get the shared appearance settings BEFORE config load.
            if (module instanceof HudModule hud) {
               hud.ensureAppearanceSettings();
            }
         } catch (Throwable t) {
            net.bluenetwork.client.BlueClient.LOGGER.error(
               "Skipping module '{}' - it failed to register. The rest of the client is unaffected.",
               module == null ? "?" : module.getName(), t);
         }
      }
      this.hudCache = null;
   }

   /**
    * Constructs a module defensively.
    *
    * <p>{@code register(new Foo(), new Bar())} evaluates every constructor
    * BEFORE {@code register} is entered, so a throwing constructor escapes the
    * guard above. Wrapping each one in a supplier moves construction inside the
    * try/catch. Used for modules that touch optional bundled libraries.</p>
    */
   private static Module safely(String name, java.util.function.Supplier<Module> factory) {
      try {
         return factory.get();
      } catch (Throwable t) {
         net.bluenetwork.client.BlueClient.LOGGER.error(
            "Module '{}' could not be created and will be unavailable this session.", name, t);
         return null;
      }
   }

   public void registerDefaults() {
      this.register(
         new FpsDisplay(),
         new CoordinatesDisplay(),
         new Keystrokes(),
         new PingDisplay(),
         new ArmorHud(),
         new DirectionHud(),
         new Speedometer(),
         new ClockHud(),
         new ServerInfoHud(),
         new BiomeHud(),
         new ToggleSprint(),
         new Zoom(),
         new BluePlusPerks(),
         new Fullbright(),
         new CosmeticsModule(),
         new MotionBlur(),
         safely("Screen Recorder", ScreenRecorder::new),
         new TimeChanger(),
         new WeatherChanger(),
         new CpsHud(),
         new ComboHud(),
         new HitColor(),
         new AlwaysParticles(),
         new HitMarker(),
         new HitSound(),
         new ReachHud(),
         new AttackIndicator(),
         new PlaytimeHud(),
         new FrameTimes(),
         new SunPosition(),
         new ItemCountdown(),
         new ToggleSneak(),
         new ChatHeight(),
         new CustomCrosshair(),
         new NoHurtCam(),
         new ChatTimestamps(),
         new MentionHighlight(),
         new MusicPlayer(),
         new DayCounter(),
         new ArmorDurability(),
         new LowHealthAlert(),
         new MemoryWatchdog(),
         new AlarmTimer(),
         new TotemCounter(),
         new HungerNumbers(),
         new DurabilityWarning(),
         new HealthNumbers(),
         new FpsGraph(),
         new ServerTicks(),
         new PotionTimers(),
         new ElytraAssist(),
         new SessionStats(),
         new NetherCoords(),
         new DimensionDisplay(),
         new SprintModes(),
         new AdaptiveRenderDistance(),
         new ChunkLoadIndicator(),
         new FrameSmooth(),
         new UISoundPack(),
         new AttackChime(),
         new KeybindViewer(),
         new SessionNotes(),
         new TargetInfo(),
         new WaypointArrow(),
         new ChatCleaner(),
         new ChatLogger(),
         new FriendPresence(),
         new VolumeMixer(),
         new PickupTracker(),
         new net.bluenetwork.client.module.impl.AutoQuality(),
         new net.bluenetwork.client.hud.impl.PerfMonitor(),
         new net.bluenetwork.client.hud.impl.HotbarInfo(),
         new net.bluenetwork.client.hud.impl.LightLevel(),
         new net.bluenetwork.client.hud.impl.ServerIp(),
         new net.bluenetwork.client.hud.impl.PlayerCount(),
         new net.bluenetwork.client.hud.impl.AirMeter(),
         new net.bluenetwork.client.module.impl.HighlightManager(),
         new net.bluenetwork.client.module.impl.NameFormatter(),
         new net.bluenetwork.client.module.impl.DropWarning(),
         new net.bluenetwork.client.module.impl.LowFoodAlert(),
         new net.bluenetwork.client.module.impl.CustomFov(),
         new net.bluenetwork.client.module.impl.CoordsConverter(),
         new net.bluenetwork.client.module.impl.ModuleSearch(),
         new net.bluenetwork.client.hud.impl.XpProgress(),
         new net.bluenetwork.client.hud.impl.MountHealth(),
         new net.bluenetwork.client.hud.impl.MoonPhase(),
         new net.bluenetwork.client.hud.impl.ChunkPosition(),
         new net.bluenetwork.client.hud.impl.LookedBlock(),
         new net.bluenetwork.client.hud.impl.SpawnDistance(),
         new net.bluenetwork.client.module.impl.DeathCoords(),
         new net.bluenetwork.client.module.impl.SleepReminder(),
         /*
          * v0.24.1 - these eight existed as classes but were never listed here,
          * so they had no row in the modules menu, no keybind and no config
          * entry: dead code that looked like "broken modules". Same bug class
          * as the Cosmetics menu in 0.24.0. If you add a module file, you MUST
          * add it to this list.
          */
         new net.bluenetwork.client.module.impl.Nametags(),
         safely("Hitboxes", net.bluenetwork.client.module.impl.Hitboxes::new),
         safely("Item Physics", net.bluenetwork.client.module.impl.ItemPhysics::new),
         safely("Item Hold Display", net.bluenetwork.client.hud.impl.ItemHoldDisplay::new),
         new net.bluenetwork.client.module.impl.PotionEffects(),
         new net.bluenetwork.client.module.impl.BossBar(),
         new net.bluenetwork.client.module.impl.Animations(),
         new net.bluenetwork.client.module.impl.Horses(),
         new net.bluenetwork.client.module.impl.CustomF3(),
         new net.bluenetwork.client.module.impl.Screenshots(),
         new net.bluenetwork.client.module.impl.DiscordPresence(),
         new net.bluenetwork.client.module.impl.MenuCustomizer(),
         new net.bluenetwork.client.module.impl.BlueLogo(),
         new net.bluenetwork.client.module.impl.ThirdPersonNametag(),
         new net.bluenetwork.client.module.impl.ChatLocation(),
         new net.bluenetwork.client.module.impl.BlockOverlay(),
         new net.bluenetwork.client.module.impl.ChunkPreload(),
         new net.bluenetwork.client.module.impl.Waypoints(),
         // These four existed as complete, working classes but were never
         // registered, so they never appeared in the modules menu at all.
         new net.bluenetwork.client.module.impl.Hitboxes(),
         new net.bluenetwork.client.module.impl.ItemPhysics(),
         new net.bluenetwork.client.module.impl.ScreenRecorder(),
         new net.bluenetwork.client.hud.impl.ItemHoldDisplay(),
         new net.bluenetwork.client.module.impl.ShieldTotemTransform(),
         new net.bluenetwork.client.module.impl.FireHeight(),
         new net.bluenetwork.client.hud.impl.MouseStrokes()
      );
   }

   public Collection<Module> getModules() {
      return this.modules.values();
   }

   public List<Module> getByCategory(Category category) {
      List<Module> result = new ArrayList<>();

      for (Module module : this.modules.values()) {
         if (module.getCategory() == category) {
            result.add(module);
         }
      }

      return result;
   }

   public List<HudModule> getHudModules() {
      // Called every rendered frame by HudManager — build once, reuse.
      if (this.hudCache == null) {
         List<HudModule> result = new ArrayList<>();
         for (Module module : this.modules.values()) {
            if (module instanceof HudModule hud) {
               result.add(hud);
            }
         }
         this.hudCache = result;
      }
      return this.hudCache;
   }

   public Module byName(String name) {
      return this.modules.get(name.toLowerCase());
   }

   public <T extends Module> T byClass(Class<T> clazz) {
      for (Module module : this.modules.values()) {
         if (clazz.isInstance(module)) {
            return (T)module;
         }
      }

      return null;
   }

   /**
    * Called once per client tick for every enabled module that implements
    * {@link Module#onTick()}. v0.15 never invoked onTick anywhere — this is the
    * missing dispatch that makes tick-driven modules (ToggleSprint,
    * PlaytimeHud, Low Health Alert, Alarm Timer, ...) actually run.
    */
   public void tickModules() {
      boolean metered = net.bluenetwork.client.optimization.PerfMeter.active();
      for (Module module : this.modules.values()) {
         if (module.isEnabled()) {
            long start = metered ? System.nanoTime() : 0L;
            try {
               module.onTick();
            } catch (Throwable var4) {
               net.bluenetwork.client.BlueClient.LOGGER.error(
                  "Module '{}' failed while ticking", module.getName(), var4);
            } finally {
               if (metered) {
                  net.bluenetwork.client.optimization.PerfMeter.record(module.getName(), System.nanoTime() - start);
               }
            }
         }
      }
   }
}
