package net.bluenetwork.client.mixin;

import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Dev-harness switch, not a user feature. The vanilla GUI background blur
 * (GameRenderer#renderBlur) runs a full-resolution gaussian post-effect every
 * frame; on software renderers (llvmpipe in the CI/dev sandbox) that pass can
 * take minutes per frame and the menu appears frozen. Setting the system
 * property {@code blueclient.dev.noblur=true} at launch skips the pass.
 * The property is never set in production or by the mod itself, so this
 * injector is a no-op for real players on real GPUs.
 */
@Mixin(GameRenderer.class)
public abstract class DevNoBlurMixin {
   @Inject(
      method = {"renderBlur"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$skipGuiBlurInDev(CallbackInfo ci) {
      if (Boolean.getBoolean("blueclient.dev.noblur")) {
         ci.cancel();
      }
   }
}
