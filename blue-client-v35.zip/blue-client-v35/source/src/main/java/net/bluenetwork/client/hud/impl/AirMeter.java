package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Air Meter (bonus HUD) — remaining air in whole seconds while underwater, so
 * you always know how long until you surface. Hidden when you're not under
 * water.
 */
public class AirMeter extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Readout colour", 0xFFFFFFFF);
   private final BooleanSetting warnBlink = new BooleanSetting("Warn blink", "Blink red in the last 3 seconds", true);

   public AirMeter() {
      super("Air Meter", "Seconds of air left while underwater", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.warnBlink});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 100);
   }

   private boolean underwater(PlayerEntity p) {
      return p != null && p.isSubmergedInWater() && p.getAir() < p.getMaxAir();
   }

   private String text(PlayerEntity p) {
      int air = Math.max(0, p.getAir());
      int seconds = air / 20;
      if (air % 20 != 0) {
         seconds++;
      }
      return "Air " + seconds + "s";
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || !this.underwater(mc.player)) {
         return;
      }
      int air = Math.max(0, mc.player.getAir());
      int seconds = air / 20;
      if (air % 20 != 0) {
         seconds++;
      }
      boolean warn = this.warnBlink.get() && seconds <= 3 && ((System.currentTimeMillis() / 400L) & 1L) == 0L;
      this.drawPanel(context);
      int color = warn ? 0xFFFF5C5C : this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(mc.player), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      MinecraftClient mc = MinecraftClient.getInstance();
      String t = mc.player != null ? this.text(mc.player) : "Air 0s";
      return RenderUtil.textWidth(t) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
