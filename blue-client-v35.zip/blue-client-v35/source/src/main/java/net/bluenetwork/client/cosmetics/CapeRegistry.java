package net.bluenetwork.client.cosmetics;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The cape catalog. Owner-only by design (v0.20.0 plan changed from
 * "anyone can drop in custom capes" to "the owner supplies the art, the
 * agent converts it into a proper cape texture and hardcodes it here") — no
 * player-facing custom cape import exists.
 *
 * To add a new cape: convert the source art to a 64x32-multiple cape
 * texture (see cosmetics/CAPE_AUTHORING.md), drop it under
 * assets/blueclient/textures/capes/, and add one line below.
 */
public final class CapeRegistry {
   private static final Map<String, Cape> CAPES = new LinkedHashMap<>();

   static {
      register(Cape.of("blues_pfp", "Blue's PFP", CapeRarity.LEGENDARY, "textures/capes/blues_pfp.png"));
      register(Cape.of("blue_client_user", "Blue Client User", CapeRarity.UNCOMMON, "textures/capes/blue_client_user.png"));
      register(Cape.of("blue_cape", "Blue Cape", CapeRarity.EPIC, "textures/capes/blue_cape.png"));

      /* ---- v0.24.0: the three capes supplied by the owner ----
         Source art lives in assets_in/capes/ and is converted to a proper
         64x32-layout cape sheet by make_capes.py at the repo root. Re-run that
         script if the art changes; do not hand-edit the PNGs under
         textures/capes/. */
      register(Cape.of("blue_b", "Blue B", CapeRarity.LEGENDARY, "textures/capes/blue_wave.png"));
      register(Cape.of("blue_crest", "Blue Crest", CapeRarity.EPIC, "textures/capes/blue_crest.png"));
      register(Cape.of("cat_cute", "Windswept Cat", CapeRarity.RARE, "textures/capes/cat_cute.png"));
   }

   private CapeRegistry() {
   }

   private static void register(Cape cape) {
      CAPES.put(cape.id(), cape);
   }

   public static Cape byId(String id) {
      return id == null ? null : CAPES.get(id);
   }

   public static List<Cape> all() {
      return List.copyOf(CAPES.values());
   }
}
