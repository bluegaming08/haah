package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Item Physics — dropped items lie flat on the ground instead of hovering.
 *
 * <p>Vanilla renders every dropped item as an upright billboard bobbing and
 * spinning in mid-air. This tips them over so they rest on the surface they
 * landed on, like the well-known Item Physics mods.</p>
 *
 * <h2>Client-side only — and why that matters</h2>
 * This changes <b>rendering only</b>. The item entity's real position, hitbox
 * and pickup behaviour are untouched, and nothing is sent to the server, so
 * items still pick up exactly where vanilla says they are. That also means it
 * works on any server and cannot be flagged by an anticheat.
 *
 * <h2>Settings</h2>
 * Everything is configurable: whether items lie flat, how fast they settle,
 * whether they keep spinning while airborne, whether the vanilla bob is kept,
 * how large they render, and whether stacks are still shown as multiple
 * overlapping copies.
 */
public class ItemPhysics extends Module {

   private final BooleanSetting lieFlat = new BooleanSetting("Lie flat",
      "Tip items over so they rest on the ground", true);
   private final NumberSetting settleSpeed = new NumberSetting("Settle speed",
      "How quickly an item falls flat after landing", 8.0, 1.0, 30.0, 1.0);
   private final BooleanSetting spinInAir = new BooleanSetting("Spin in air",
      "Keep items spinning while they are still falling", true);
   private final BooleanSetting keepBobbing = new BooleanSetting("Keep bobbing",
      "Keep the vanilla up-and-down float while airborne", false);
   private final BooleanSetting randomRotation = new BooleanSetting("Random rotation",
      "Give each item its own resting angle instead of all facing the same way", true);
   private final NumberSetting scale = new NumberSetting("Item scale",
      "Size of dropped items (%)", 100.0, 50.0, 200.0, 5.0);
   private final NumberSetting groundOffset = new NumberSetting("Ground offset",
      "How far above the ground a flat item sits, to avoid z-fighting (1/100 block)",
      2.0, 0.0, 10.0, 0.5);
   private final BooleanSetting stackDepth = new BooleanSetting("Stack layers",
      "Keep vanilla's multiple copies for large stacks", true);

   public ItemPhysics() {
      super("Item Physics", "Dropped items lie flat on the ground instead of floating",
         Category.RENDER);
      Setting<?>[] all = {
         this.lieFlat, this.settleSpeed, this.spinInAir, this.keepBobbing,
         this.randomRotation, this.scale, this.groundOffset, this.stackDepth
      };
      this.addSettings(new Setting[]{
         this.lieFlat, this.settleSpeed, this.spinInAir, this.keepBobbing,
         this.randomRotation, this.scale, this.groundOffset, this.stackDepth
      });
      this.settleSpeed.visibleWhen(this.lieFlat::get);
      this.groundOffset.visibleWhen(this.lieFlat::get);

      // Any settings change drops the cached snapshot, so the very next frame
      // picks up the new value. Without this the cache would go stale and the
      // settings screen would appear to do nothing.
      for (Setting<?> setting : all) {
         setting.onChange(ItemPhysics::invalidate);
      }
   }

   @Override
   protected void onEnable() {
      invalidate();
   }

   @Override
   protected void onDisable() {
      invalidate();
   }

   /**
    * Every setting the render hooks need, read once and frozen.
    *
    * <p>The hooks run <i>per dropped item, per frame</i>, and the first version
    * called a separate static getter for each setting — up to ten
    * {@code byName()} lookups (each allocating a lowercased string) for every
    * item on screen. On a floor covered in drops that is thousands of pointless
    * lookups a second, on hardware that cannot spare them.</p>
    *
    * <p>Values are pre-converted (percentages already divided) so the render
    * path does no arithmetic it does not have to.</p>
    */
   public record Snapshot(
      boolean lieFlat,
      float settleSpeed,
      boolean spinInAir,
      boolean keepBobbing,
      boolean randomRotation,
      float scale,
      float groundOffset,
      boolean stackLayers) {
   }

   /**
    * The cached snapshot, or {@code null} when it needs rebuilding.
    *
    * <p>Invalidated by {@link #invalidate()} whenever a setting changes or the
    * module is toggled, which is the only time the values can differ. That is
    * more precise than rebuilding every frame and avoids a per-frame
    * allocation entirely.</p>
    *
    * <p>{@code volatile} because settings can be changed from the client
    * thread while the render thread reads it.</p>
    */
   private static volatile Snapshot cached = null;

   private static ItemPhysics active() {
      Module m = BlueClient.getInstance().moduleManager().byName("Item Physics");
      return m instanceof ItemPhysics p && p.isEnabled() ? p : null;
   }

   /**
    * @return the current settings, or {@code null} when the module is off —
    *         which tells every hook to leave vanilla rendering alone.
    */
   public static Snapshot snapshot() {
      Snapshot local = cached;
      if (local != null) {
         return local;
      }
      ItemPhysics p = active();
      if (p == null) {
         return null;                       // off: do not cache, stays cheap
      }
      local = new Snapshot(
         p.lieFlat.get(),
         p.settleSpeed.getFloat(),
         p.spinInAir.get(),
         p.keepBobbing.get(),
         p.randomRotation.get(),
         p.scale.getFloat() / 100.0F,
         p.groundOffset.getFloat() / 100.0F,
         p.stackDepth.get());
      cached = local;
      return local;
   }

   /** Drops the cached snapshot so the next read re-reads every setting. */
   public static void invalidate() {
      cached = null;
   }
}
