package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.UiSoundController;

/**
 * UI Sound Pack (v3 catalogue D3) — choose how every UI click sounds:
 * Default (original pitch), Soft (gentler, lower pitch) or Off (muted). The
 * live mode is pushed into {@link UiSoundController} which every click sound in
 * the client already routes through.
 */
public class UISoundPack extends Module {
   private static final String[] PACKS = {"Default", "Soft", "Off"};
   private final ModeSetting pack = new ModeSetting("Pack", "UI click sound style", List.of(PACKS), "Default");

   private String lastMode = "";

   public UISoundPack() {
      super("UI Sound Pack", "Change how UI clicks sound", Category.MISC);
      this.addSettings(new Setting[]{this.pack});
   }

   @Override
   protected void onEnable() {
      this.lastMode = "";
   }

   @Override
   protected void onDisable() {
      UiSoundController.apply("Default");
   }

   @Override
   public void onTick() {
      String mode = this.pack.get();
      if (!mode.equals(this.lastMode)) {
         this.lastMode = mode;
         UiSoundController.apply(mode);
      }
   }
}
