package net.bluenetwork.client.module;

/**
 * Module categories, in the order they appear in the menu's filter rail.
 *
 * <p><b>Append new constants at the END.</b> {@code ModuleMenuScreen} maps a
 * filter chip back to a category by {@code ordinal()}, so inserting one in the
 * middle would silently re-point every chip.</p>
 */
public enum Category {
   HUD("HUD"),
   COMBAT("Combat"),
   MOVEMENT("Movement"),
   RENDER("Render"),
   MISC("Misc"),

   /**
    * Blue+ subscriber settings.
    *
    * <p>Hidden entirely for free users - {@link #visible()} is what the menu
    * checks. It is not merely greyed out: an empty locked category is clutter,
    * and the Blue+ tab in Social is where the upsell belongs.</p>
    */
   BLUE_PLUS("Blue+");

   private final String displayName;

   private Category(String displayName) {
      this.displayName = displayName;
   }

   public String displayName() {
      return this.displayName;
   }

   /** Whether this category should be listed for the current user. */
   public boolean visible() {
      if (this != BLUE_PLUS) {
         return true;
      }
      try {
         return net.bluenetwork.client.BlueClient.getInstance().friends().plus();
      } catch (Throwable t) {
         // If the social system is not up, do not advertise a locked category.
         return false;
      }
   }
}
