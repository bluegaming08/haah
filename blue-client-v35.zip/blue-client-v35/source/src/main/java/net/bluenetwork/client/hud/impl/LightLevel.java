package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.LightType;

/**
 * Light Level (bonus HUD) — block and sky light at your feet as numbers, so
 * you always know if mobs can spawn where you're standing.
 */
public class LightLevel extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Readout colour", 0xFFFFFFFF);

   public LightLevel() {
      super("Light Level", "Block/sky light where you stand", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_LEFT, 6, 160);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) {
         return "Light --";
      }
      BlockPos pos = mc.player.getBlockPos();
      int block = mc.world.getLightLevel(LightType.BLOCK, pos);
      int sky = mc.world.getLightLevel(LightType.SKY, pos);
      return "Light " + block + "/" + sky;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
