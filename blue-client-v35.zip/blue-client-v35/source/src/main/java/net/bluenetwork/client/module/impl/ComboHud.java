package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

public class ComboHud extends HudModule {
   private int combo = 0;
   private long lastHit = 0L;
   private boolean wasHurt = false;
   /** From the premium pack's ComboCounter: estimated cumulative damage. */
   private final BooleanSetting damageEstimate = new BooleanSetting("Damage estimate", "Append estimated total damage (1.5 hearts per hit)", false);

   public ComboHud() {
      super("Combo", "Shows your current hit streak", Category.COMBAT, 4, 328);
      this.addSettings(new Setting[]{this.damageEstimate});
   }

   public void onAttack() {
      this.combo++;
      this.lastHit = System.currentTimeMillis();
   }

   @Override
   public void onTick() {
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player == null) {
         this.combo = 0;
      } else {
         // v0.16.9: detect ANY hurt transition (0 -> >0), not just hurtTime==9.
         // Fire ticks and some damage sources start hurtTime at different
         // values, which let fire damage slip through and keep the combo alive.
         boolean hurtNow = player.hurtTime > 0;
         if (hurtNow && !this.wasHurt) {
            this.combo = 0;
         }
         this.wasHurt = hurtNow;

         if (this.combo > 0 && System.currentTimeMillis() - this.lastHit > 3000L) {
            this.combo = 0;
         }
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }

   private String text() {
      String base = this.combo > 0 ? this.combo + "x Combo" : "0x Combo";
      return this.damageEstimate.get() ? base + String.format(" (~%.1f dmg)", (float)this.combo * 1.5F) : base;
   }

   @Override
   public void render(DrawContext context) {
      this.drawTextPanel(context, this.text());
   }
}
