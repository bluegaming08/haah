package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.Animations;
import net.bluenetwork.client.module.impl.ShieldTotemTransform;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Animations module (v0.19.0): cancels the individual first-person hand
 * transformations the module is told to hide. Cancelling these matrix
 * offsets leaves the held item rendered in its neutral pose.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

   /*
    * Shield & Totem transform.
    *
    * Injected at HEAD of renderItem so the offset and scale are pushed onto
    * the matrix before the model is drawn. The matrix is pushed here and
    * popped in the RETURN injection below - leaving it unbalanced would
    * corrupt every subsequent draw call in the frame.
    *
    * require = 0 so a mapping change degrades to "the feature does nothing"
    * rather than crashing the game on startup.
    */
   @org.spongepowered.asm.mixin.Unique
   private boolean blueclient$stackPushed;

   @Inject(method = {"renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"},
      at = {@At("HEAD")}, require = 0)
   private void blueclient$transformPush(LivingEntity entity, ItemStack stack,
         ItemDisplayContext context, MatrixStack matrices,
         OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
      this.blueclient$stackPushed = false;
      if (!ShieldTotemTransform.handles(stack)) {
         return;
      }
      float[] off = ShieldTotemTransform.offsetFor(stack);
      float scale = ShieldTotemTransform.scaleFor(stack);
      matrices.push();
      this.blueclient$stackPushed = true;
      matrices.translate(off[0], off[1], off[2]);
      if (scale != 1.0F) {
         matrices.scale(scale, scale, scale);
      }
   }

   @Inject(method = {"renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"},
      at = {@At("RETURN")}, require = 0)
   private void blueclient$transformPop(LivingEntity entity, ItemStack stack,
         ItemDisplayContext context, MatrixStack matrices,
         OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
      if (this.blueclient$stackPushed) {
         matrices.pop();
         this.blueclient$stackPushed = false;
      }
   }

   @Inject(method = {"applySwingOffset"}, at = {@At("HEAD")}, cancellable = true, require = 0)
   private void blueclient$noSwing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
      if (Animations.noSwing()) {
         ci.cancel();
      }
   }

   @Inject(method = {"applyEquipOffset"}, at = {@At("HEAD")}, cancellable = true, require = 0)
   private void blueclient$noEquip(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
      if (Animations.noEquip()) {
         ci.cancel();
      }
   }

   @Inject(method = {"applyEatOrDrinkTransformation"}, at = {@At("HEAD")}, cancellable = true, require = 0)
   private void blueclient$noEatDrink(MatrixStack matrices, float tickDelta, Arm arm, ItemStack stack,
                                      PlayerEntity player, CallbackInfo ci) {
      if (Animations.noEatDrink()) {
         ci.cancel();
      }
   }
}
