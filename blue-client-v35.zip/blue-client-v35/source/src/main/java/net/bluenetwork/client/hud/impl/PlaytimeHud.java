package net.bluenetwork.client.hud.impl;

import java.nio.file.Files;
import java.nio.file.Path;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class PlaytimeHud extends HudModule {
   private long sessionTicks = 0L;
   private long lifetimeMinutes = -1L;

   public PlaytimeHud() {
      super("Playtime", "Time played (session + lifetime)", Category.HUD, 4, 418);
   }

   private Path file() {
      return FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("playtime.txt");
   }

   private long lifetime() {
      if (this.lifetimeMinutes < 0L) {
         try {
            this.lifetimeMinutes = Long.parseLong(Files.readString(this.file()).trim());
         } catch (Throwable var2) {
            this.lifetimeMinutes = 0L;
         }
      }

      return this.lifetimeMinutes;
   }

   @Override
   public void onTick() {
      if (MinecraftClient.getInstance().player != null) {
         this.sessionTicks++;
         if (this.sessionTicks % 1200L == 0L) {
            this.lifetimeMinutes = this.lifetime() + 1L;

            try {
               Files.writeString(this.file(), String.valueOf(this.lifetimeMinutes));
            } catch (Throwable var2) {
            }
         }
      }
   }

   @Override
   public void render(DrawContext context) {
      long sessionSeconds = this.sessionTicks / 20L;
      long sessionMinutes = sessionSeconds / 60L;
      String text = "Playtime: "
         + String.format("%dh %02dm", sessionMinutes / 60L, sessionMinutes % 60L)
         + " | Life: "
         + String.format("%dh", this.lifetime() / 60L);
      this.drawTextPanel(context, text);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Playtime: 99h 99m | Life: 9999h") + 12 + 2;
   }
}
