package net.bluenetwork.client.module.impl;

import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.setting.StringSetting;
import net.bluenetwork.client.util.Sounds;

/**
 * NOT the Blue Client Friends system. This is an older, unrelated module that
 * watches SERVER CHAT for join/leave lines from names you typed into a list.
 * It needs no account and no backend. The real friends system (accounts,
 * requests, presence, blocking) lives in {@code net.bluenetwork.client.social}
 * and is opened from the FRIENDS button. Both can be used at once.
 *
 * <p>Friend Presence (v3 catalogue C6) — toast when a listed friend name appears
 * in a "... joined the game" / "... left the game" server message. Friend list
 * is a persisted comma-separated string. Cooldown per friend prevents repeats.
 */
public class FriendPresence extends Module {
   private final StringSetting friends = new StringSetting("Friends", "Comma-separated player names", "");
   private final BooleanSetting joins = new BooleanSetting("Joins", "Alert when a friend joins", true);
   private final BooleanSetting leaves = new BooleanSetting("Leaves", "Alert when a friend leaves", true);
   private final BooleanSetting sound = new BooleanSetting("Sound", "Play a soft tone", true);

   private long lastFriendAlert = 0L;

   public FriendPresence() {
      super("Friend Presence", "Alert when friends join or leave", Category.MISC);
      this.addSettings(new Setting[]{this.friends, this.joins, this.leaves, this.sound});
   }

   /** Called from the chat mixin for every incoming message. */
   public static void scan(String content) {
      try {
         Module module = BlueClient.getInstance().moduleManager().byName("Friend Presence");
         if (!(module instanceof FriendPresence fp) || !fp.isEnabled() || content == null) {
            return;
         }
         fp.check(content);
      } catch (Throwable ignored) {
      }
   }

   private void check(String content) {
      boolean join = content.contains("joined the game");
      boolean leave = content.contains("left the game");
      if ((!join || !this.joins.get()) && (!leave || !this.leaves.get())) {
         return;
      }
      String list = this.friends.get();
      if (list == null || list.isBlank()) {
         return;
      }
      long now = System.currentTimeMillis();
      if (now - this.lastFriendAlert < 2000L) {
         return;
      }
      String lower = content.toLowerCase(Locale.ROOT);
      for (String name : list.split(",")) {
         String friend = name.trim();
         if (friend.isEmpty()) {
            continue;
         }
         if (lower.contains(friend.toLowerCase(Locale.ROOT))) {
            this.lastFriendAlert = now;
            if (this.sound.get()) {
               Sounds.pickup();
            }
            String kind = join ? "joined" : "left";
            try {
               BlueClient.getInstance().notificationManager().add(friend + " " + kind, 0xFF7CFF9B);
            } catch (Throwable ignored) {
            }
            break;
         }
      }
   }
}
