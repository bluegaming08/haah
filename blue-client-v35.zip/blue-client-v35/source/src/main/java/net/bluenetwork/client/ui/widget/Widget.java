package net.bluenetwork.client.ui.widget;

import net.bluenetwork.client.ui.core.Rect;
import net.minecraft.client.gui.DrawContext;

/**
 * Base v2 widget (BLUE_CLIENT_V3_MASTER_PLAN.md §4.2). Minimal contract:
 * bounds + hit test, render with the current design tokens/text effect, and
 * optional mouse handling. Screens will compose these into the Module Library
 * and settings sheets.
 */
public abstract class Widget {
   protected int x;
   protected int y;
   protected int w;
   protected int h;

   public void setBounds(int x, int y, int w, int h) {
      this.x = x;
      this.y = y;
      this.w = Math.max(1, w);
      this.h = Math.max(1, h);
   }

   public Rect bounds() {
      return new Rect(x, y, w, h);
   }

   public boolean contains(int mx, int my) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   public boolean hovered(int mx, int my) {
      return contains(mx, my);
   }

   public abstract void render(DrawContext context, int mouseX, int mouseY, long nowMs);

   /** Return true if the click was consumed. */
   public boolean mouseClicked(int mouseX, int mouseY, int button) {
      return false;
   }

   public void mouseDragged(int mouseX, int mouseY) {
   }

   public void mouseReleased(int mouseX, int mouseY) {
   }
}
