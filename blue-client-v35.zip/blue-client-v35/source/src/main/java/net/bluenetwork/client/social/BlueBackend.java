package net.bluenetwork.client.social;

/**
 * Where the Friends system connects to, and the one place to change it.
 *
 * <h2>Is it safe that these are inside the jar?</h2>
 * Yes. The project URL and the <i>publishable</i> key are designed to be
 * public - they are the same values a website would ship in its JavaScript.
 * They grant nothing on their own: every table is protected by Row Level
 * Security policies that run on Supabase's servers and cannot be bypassed by
 * a modified client.
 *
 * <p><b>What must NEVER appear in this file (or anywhere in the jar):</b></p>
 * <ul>
 *   <li>the database password</li>
 *   <li>the {@code service_role} key (it ignores RLS entirely)</li>
 *   <li>any personal access token</li>
 * </ul>
 *
 * <h2>The fake email domain</h2>
 * Blue Client accounts are username + password. Supabase Auth, however, has
 * no username login - it requires an email address. So we build a synthetic
 * one: the username {@code BlueDev} becomes {@code bluedev@blueclient.app}.
 *
 * <p>The player never sees or types this. It exists only to satisfy Supabase.
 * Because of it, <b>email confirmation must be turned OFF</b> in the Supabase
 * dashboard - otherwise Supabase tries to send a confirmation mail to an
 * address that does not exist. See README-BACKEND.md, Step 4.</p>
 *
 * <p>A player may later attach their <i>real</i> email for password recovery;
 * that replaces the synthetic address on their auth record but never changes
 * their username or their id.</p>
 */
public final class BlueBackend {

   /** Supabase project URL. No trailing slash. */
   public static final String URL = "https://mzomulrpfffrvoennzlb.supabase.co";

   /**
    * Publishable ("anon") key. Safe to embed - see the class note above.
    * Replace this if you move to your own Supabase project.
    */
   public static final String ANON_KEY =
      "sb_publishable_fIks_Dkb5RGspp0mpLyWKg__Eu87EvR";

   /**
    * Domain used to build the synthetic login email.
    *
    * <p>Supabase validates this domain and rejects obviously fake TLDs such
    * as {@code .invalid} or {@code .local}, so it must look like a real
    * domain. Ideally you own it; see README-BACKEND.md, Step 3.</p>
    */
   public static final String ACCOUNT_EMAIL_DOMAIN = "blueclient.app";

   /** Set to false to compile a build with Friends completely disabled. */
   public static final boolean ENABLED = true;

   private BlueBackend() {
   }

   /** Turns a username into the synthetic email Supabase logs in with. */
   public static String loginEmail(String username) {
      return username.toLowerCase(java.util.Locale.ROOT) + "@" + ACCOUNT_EMAIL_DOMAIN;
   }

   /** True when the backend looks configured (someone may blank it out). */
   public static boolean configured() {
      return ENABLED
         && URL != null && !URL.isBlank()
         && ANON_KEY != null && !ANON_KEY.isBlank();
   }
}
