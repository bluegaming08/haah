package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.config.ProfileCode;
import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.gui.AccountsScreen;
import net.bluenetwork.client.gui.ClientSettingsScreen;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.impl.MenuCustomizer;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.ui.motion.Easing;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.bluenetwork.client.ui.theme.ThemePalette;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * ModuleMenuScreen v5 - "Blue Console" (feedback 2026-09-11).
 *
 * <p>The v4 panel sized itself from the raw window and could end up wider or
 * taller than the space left around it, which is exactly why users saw the
 * background border box "cut off" with cards spilling past the right edge.
 * v5 fixes that for good:</p>
 * <ul>
 *   <li>The whole menu renders in a virtual resolution and an extra
 *       <i>fit factor</i> shrinks the menu whenever the window is smaller
 *       than the design size - the panel (and its border) ALWAYS fits fully
 *       inside the window with a margin on every side.</li>
 *   <li>The scrollable module area is scissored to its own rectangle only,
 *       so nothing can ever paint over the panel border or the chrome.</li>
 * </ul>
 *
 * <p>Visual language follows the attached reference
 * shots): top bar with logo, centre tabs and a close button; left sidebar;
 * a filter-chip row with a grid/list view toggle and search; then either
 * <b>cards</b> (big centred icon, name, OPTIONS bar, ENABLED/DISABLED bar)
 * or the compact <b>list</b> grid (bordered rows, green = on, red = off,
 * gear button on the right).</p>
 */
public class ModuleMenuScreen extends Screen {
   /* virtual-space design constants */
   private static final int DESIGN_W = 700;
   private static final int DESIGN_H = 430;
   private static final int TOP_BAR_H = 34;
   private static final int SIDEBAR_W = 128;
   private static final int TOOLBAR_H = 30;
   private static final int PAD = 10;
   private static final int GAP = 8;
   private static final int CARD_MIN_W = 176;
   private static final int CARD_H = 112;
   private static final int LIST_MIN_W = 196;
   private static final int LIST_H = 24;
   private static final int SEARCH_W = 150;
   private static final int SEARCH_H = 20;

   private static final int GREEN = 0xFF3CB860;
   private static final int GREEN_DIM = 0x9943B581;
   private static final int CRIMSON = 0xFFC9405E;
   private static final int CRIMSON_DIM = 0x99B03060;

   private final BlueClient blue;
   private final Screen parent;

   private String query = "";
   private boolean searchFocused = false;
   private Category category; // null = All
   /** Session override from the grid/list buttons; null = follow the style setting. */
   private Boolean viewOverride = null;

   private float targetScroll;
   private float smoothScroll;

   private final Map<String, Long> toggleAnim = new HashMap<>();
   private long revealStartMs = System.currentTimeMillis();

   private final List<RectHit> chipHits = new ArrayList<>();
   private final List<RectHit> tabHits = new ArrayList<>();
   private final List<RectHit> sideHits = new ArrayList<>();
   private final List<ModuleHit> optionHits = new ArrayList<>();
   private final List<ModuleHit> toggleHits = new ArrayList<>();
   private final List<ModuleHit> gearHits = new ArrayList<>();
   private final List<ModuleHit> bodyHits = new ArrayList<>();
   private Rect searchBox;
   private Rect gridBtn;
   private Rect listBtn;
   private Rect sortBtn;
   private Rect closeBtn;
   private Rect saveBtn;
   private Rect hudBtn;

   /*
    * v0.24.1 - "remove save button and only save button and load button,
    * save button copies the share code to your clipboard and load button has
    * an input where you can paste the save code".
    *
    * There used to be THREE buttons (SAVE / SHARE CODE / LOAD CODE) which was
    * confusing: plain SAVE just wrote config.json, which the client already
    * does automatically on every change and on exit. Now there are exactly two:
    *   SAVE -> copies a BLUE1- share code to the clipboard
    *   LOAD -> opens an inline paste box
    */

   /** True while the LOAD paste box is open. */
   private boolean loadBoxOpen;

   /** Text typed / pasted into the LOAD box. */
   private String loadBoxText = "";

   /** Hit box of the inline paste field. */
   private Rect loadBoxRect;

   /** Hit box of the paste box's confirm button. */
   private Rect loadBoxGo;

   /** The popup's X (close) button. */
   private Rect loadBoxClose;

   /** The popup's dimmed backdrop, used to close on outside-click. */
   private Rect loadBoxBackdrop;
   /** "SAVE": copies a {@link ProfileCode} share string to the clipboard. */
   /** "LOAD CODE": reads a code from the clipboard and applies it. */
   private Rect loadBtn;
   private float listTop;
   private float listBottom;
   private float drawScale = 1.0F;
   private boolean draggingThumb;
   private float thumbGrabOff;
   private float thumbX = Float.MIN_VALUE;
   private float trackTop;
   private float trackH;
   private float thumbHf = 24.0F;
   private float scrollMaxF;

   public ModuleMenuScreen(BlueClient blue) {
      this(blue, null);
   }

   public ModuleMenuScreen(BlueClient blue, Screen parent) {
      super(Text.literal("Modules"));
      this.blue = blue;
      this.parent = parent;
   }

   /**
    * Cards or list layout, read LIVE every frame: the toolbar toggle's
    * session override wins, otherwise the Menu Customizer's Menu Style
    * setting decides (cards when the customizer is missing), so changing
    * the setting or the toggle always applies immediately.
    */
   private boolean cardsView() {
      if (this.viewOverride != null) {
         return this.viewOverride;
      }
      MenuCustomizer mc = this.customizer();
      return mc == null ? true : "CARDS".equals(mc.style());
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   protected void init() {
      this.revealStartMs = System.currentTimeMillis();
   }

   /* ================================================================ DATA */

   private List<Module> all() {
      return new ArrayList<>(this.blue.moduleManager().getModules());
   }

   private List<Module> visible() {
      List<Module> out = new ArrayList<>();
      String q = this.query.toLowerCase(Locale.ROOT);
      for (Module m : this.all()) {
         if (this.category != null && m.getCategory() != this.category) {
            continue;
         }
         if (!q.isEmpty() && !m.getName().toLowerCase(Locale.ROOT).contains(q)
            && !m.getDescription().toLowerCase(Locale.ROOT).contains(q)) {
            continue;
         }
         out.add(m);
      }
      // v0.16.9: enabled modules sort to the top of every category
      // (v0.16.11: toggleable from the toolbar pill + Client Settings)
      java.util.Comparator<Module> byName =
         java.util.Comparator.comparing(m -> m.getName().toLowerCase(Locale.ROOT));
      if (this.blue.settings().modulesEnabledFirst()) {
         out.sort(java.util.Comparator.comparing(Module::isEnabled).reversed().thenComparing(byName));
      } else {
         out.sort(byName);
      }
      return out;
   }

   private int enabledCount(Category cat) {
      int n = 0;
      for (Module m : this.all()) {
         if ((cat == null || m.getCategory() == cat) && m.isEnabled()) {
            n++;
         }
      }
      return n;
   }

   private boolean animated() {
      try {
         return this.blue.settings().animations();
      } catch (Throwable t) {
         return true;
      }
   }

   /* ---- menu style: driven by the optional "Menu Customizer" module ---- */

   private MenuCustomizer customizer() {
      for (Module m : this.all()) {
         if (m instanceof MenuCustomizer mc) {
            return mc;
         }
      }
      return null;
   }

   private MenuCustomizer activeCustomizer() {
      MenuCustomizer mc = this.customizer();
      return mc != null && mc.isEnabled() ? mc : null;
   }

   /**
    * UI scale of the whole modules menu. The setting is displayed as
    * 90% - 100% (default 90%, feedback 2026-09-11); 100% is the size users
    * know (0.75 of the raw screen resolution), so the real factor is
    * percent * 0.0075.
    */
   private float uiScale() {
      MenuCustomizer mc = this.activeCustomizer();
      int pct = mc != null ? Math.max(90, Math.min(100, mc.scalePercent())) : MenuCustomizer.DEFAULT_SCALE;
      return pct * 0.0075F;
   }

   private float roundness() {
      MenuCustomizer mc = this.activeCustomizer();
      int r = mc != null ? Math.max(0, Math.min(24, mc.roundnessValue())) : MenuCustomizer.DEFAULT_ROUNDNESS;
      return r;
   }

   private int bodyOpacity() {
      MenuCustomizer mc = this.activeCustomizer();
      int o = mc != null ? Math.max(0, Math.min(100, mc.opacityPercent())) : MenuCustomizer.DEFAULT_OPACITY;
      return o;
   }

   private int dimStrength() {
      MenuCustomizer mc = this.activeCustomizer();
      int d = mc != null ? Math.max(0, Math.min(100, mc.dimPercent())) : MenuCustomizer.DEFAULT_DIM;
      return d;
   }

   private boolean menuShadow() {
      MenuCustomizer mc = this.activeCustomizer();
      return mc == null || mc.shadowEnabled();
   }

   /*
    * v0.24.2: "the light mode doesnt change the text color to black in
    * modules menu".
    *
    * These used to fall back to MenuCustomizer.DEFAULT_*_COLOR, which is a
    * hardcoded WHITE - so under the WHITE theme the module names were white on
    * a white card and effectively invisible. The fallback is now the THEME's
    * own text colour (dark under WHITE, light under BLACK/GLASS).
    *
    * An explicit colour set in Menu Customizer still wins: if the owner picked
    * a colour by hand we must not silently override it.
    */
   private int menuIconColor() {
      MenuCustomizer mc = this.activeCustomizer();
      if (mc != null && mc.iconColorCustomised()) {
         return mc.iconArgb(System.currentTimeMillis());
      }
      return DesignTokens.textHi();
   }

   private int menuTextColor() {
      MenuCustomizer mc = this.activeCustomizer();
      if (mc != null && mc.textColorCustomised()) {
         return mc.textArgb(System.currentTimeMillis());
      }
      return DesignTokens.textHi();
   }

   /**
    * Tint for a card / panel surface inside the modules menu.
    *
    * <h3>v0.24.1: themes must win over the hardcoded tints</h3>
    * Every call site passes a hardcoded ARGB like {@code 0x11FFFFFF} - a WHITE
    * wash. Under GLASS that washed the whole UI out to near-white over a bright
    * sky, and under BLACK / WHITE it left the cards translucent so the world
    * showed through. Both were reported by the owner.
    *
    * <p>Now the theme decides:</p>
    * <ul>
    *   <li><b>BLACK / WHITE</b> - return the palette's own 100 % opaque panel
    *       colour, ignoring the caller's tint entirely. Nothing behind is
    *       visible, which is the whole point of a solid theme.</li>
    *   <li><b>GLASS</b> - keep the caller's relative brightness but apply it as
    *       a DARK tint over {@code #0B0E14}, never white.</li>
    * </ul>
    * The Menu Customizer opacity slider still applies, but only within GLASS;
    * on a solid theme "opacity" would contradict the theme.
    */
   private int cardFill(int baseArgb) {
      ThemePalette palette = ThemeManager.palette();
      if (ThemeManager.opaque()) {
         // Brighter requested tints map to the hover surface, so cards still
         // have visible depth instead of becoming one flat slab.
         int requested = (baseArgb >>> 24) & 0xFF;
         return requested >= 0x80 ? palette.panelBgHover() : palette.panelBg();
      }
      float pct = this.bodyOpacity() / 100.0F;
      float alpha = 0.15F + 0.85F * pct;
      // Same alpha ramp as before, but tinting DARK instead of white.
      int tinted = (baseArgb & 0x00FFFFFF) == 0x00FFFFFF ? 0x0B0E14 : (baseArgb & 0x00FFFFFF);
      return withAlpha(tinted, alpha);
   }

   /* ====================================================== ICON MAPPING */

   private static String categoryIcon(Category cat) {
      if (cat == null) {
         return "layout-grid";
      }
      return switch (cat) {
         case HUD -> "layout-dashboard";
         case COMBAT -> "swords";
         case MOVEMENT -> "footprints";
         case RENDER -> "eye";
         case MISC -> "sliders-horizontal";
         case BLUE_PLUS -> "sparkles";
      };
   }

   /**
    * Module display name -> icon sprite, drawn as {@code blueclient:icon/<name>}.
    *
    * <p>Owner spec: <i>"different icons for each module in the modules menu,
    * dont repeat the icons"</i>. Every value in this table is UNIQUE, and the
    * static initializer below fails loudly in dev if a duplicate ever sneaks
    * in — a silent duplicate is exactly how the menu regressed before.</p>
    *
    * <p>Adding a module? Add a row here with an unused sprite from
    * {@code assets/blueclient/textures/gui/sprites/icon/}. If you forget, the
    * module still renders — it just falls back to its category icon.</p>
    */
   private static final Map<String, String> MODULE_ICONS = Map.ofEntries(
      Map.entry("Blue Plus", "sparkles"),
      Map.entry("Shield & Totem", "shield"),
      Map.entry("Fire Height", "flame"),
      Map.entry("Mouse Strokes", "mouse-pointer-click"),
      Map.entry("FPS Display", "gauge"),
      Map.entry("Coordinates", "compass"),
      Map.entry("Keystrokes", "keyboard"),
      Map.entry("Ping", "wifi"),
      Map.entry("ArmorHUD", "shield"),
      Map.entry("Direction", "navigation"),
      Map.entry("Speedometer", "gauge"),
      Map.entry("Clock", "clock"),
      Map.entry("Server", "server"),
      Map.entry("Biome", "trees"),
      Map.entry("ToggleSprint", "footprints"),
      Map.entry("Zoom", "zoom-in"),
      Map.entry("Fullbright", "sun"),
      Map.entry("Time Changer", "hourglass"),
      Map.entry("Weather Changer", "cloud"),
      Map.entry("CPS", "mouse-pointer-click"),
      Map.entry("Combo", "flame"),
      Map.entry("Hit Color", "paintbrush"),
      Map.entry("Always Particles", "sparkles"),
      Map.entry("Hit Marker", "target"),
      Map.entry("Hit Sound", "volume-2"),
      Map.entry("Reach Display", "ruler"),
      Map.entry("Attack Indicator", "sword"),
      Map.entry("Playtime", "timer"),
      Map.entry("Frame Times", "activity"),
      Map.entry("Sun Position", "sun"),
      Map.entry("Item Countdown", "package"),
      Map.entry("Toggle Sneak", "chevron-down"),
      Map.entry("Chat Height", "panel-top"),
      Map.entry("Crosshair", "crosshair"),
      Map.entry("No Hurt Cam", "camera"),
      Map.entry("Chat Timestamps", "hash"),
      Map.entry("Mention Highlight", "at-sign"),
      Map.entry("Music Player", "music"),
      Map.entry("Day Counter", "book"),
      Map.entry("Armor Durability", "shirt"),
      Map.entry("Low Health Alert", "bell"),
      Map.entry("Memory Watchdog", "cpu"),
      Map.entry("Alarm Timer", "alarm-clock"),
      Map.entry("Totem Counter", "gem"),
      Map.entry("Hunger Numbers", "apple"),
      Map.entry("Durability Warning", "pickaxe"),
      Map.entry("Health Numbers", "activity"),
      Map.entry("FPS Graph", "trending-up"),
      Map.entry("Server Ticks", "database"),
      Map.entry("Potion Timers", "thermometer"),
      Map.entry("Elytra HUD Assist", "wind"),
      Map.entry("Session Stats", "percent"),
      Map.entry("Nether Coords", "flag"),
      Map.entry("Dimension Display", "globe"),
      Map.entry("Sprint Modes", "route"),
      Map.entry("Adaptive Render Distance", "mountain"),
      Map.entry("Chunk Load Indicator", "box"),
      Map.entry("Frame Smooth", "waves"),
      Map.entry("UI Sound Pack", "headphones"),
      Map.entry("Attack Chime", "bell"),
      Map.entry("Keybind Viewer", "list-checks"),
      Map.entry("Session Notes", "book"),
      Map.entry("Target Info", "user-round"),
      Map.entry("Waypoint Arrow", "map-pin"),
      Map.entry("Chat Cleaner", "brush"),
      Map.entry("Chat Logger", "list"),
      Map.entry("Friend Presence", "users"),
      Map.entry("Volume Mixer", "sliders-horizontal"),
      Map.entry("Pickup Tracker", "hand"),
      Map.entry("Cosmetics", "wand"),
      Map.entry("Motion Blur", "spline"),
      Map.entry("Screen Recorder", "film"),
      Map.entry("Screenshots", "camera"),
      Map.entry("Nametags", "user-round"),
      Map.entry("Hitboxes", "square"),
      Map.entry("Item Hold Display", "package"),
      Map.entry("Air Meter", "wind"),
      Map.entry("Animations", "move"),
      Map.entry("Auto Quality", "gauge"),
      Map.entry("Player Tags", "award"),
      Map.entry("Boss Bar", "shield"),
      Map.entry("Chat Location", "message-square"),
      Map.entry("Chunk Position", "grid-2x2"),
      Map.entry("Chunk Pre-Render", "layout-grid"),
      Map.entry("Coords Converter", "compass"),
      Map.entry("Custom F3", "list"),
      Map.entry("Death Coords", "milestone"),
      Map.entry("Drop Warning", "alarm-clock"),
      Map.entry("Highlight Manager", "paintbrush"),
      Map.entry("Horses", "horse"),
      Map.entry("Hotbar Info", "layout-dashboard"),
      Map.entry("Light Level", "sun"),
      Map.entry("Looked Block", "box"),
      Map.entry("Low Food Alert", "bell"),
      Map.entry("Menu Customizer", "layout-dashboard"),
      Map.entry("Module Search", "search"),
      Map.entry("Moon Phase", "moon"),
      Map.entry("Mount Health", "horse"),
      Map.entry("Name Formatter", "type"),
      Map.entry("Performance Monitor", "activity"),
      Map.entry("Player Count", "users"),
      Map.entry("Potion Effects", "thermometer"),
      Map.entry("Server IP", "server"),
      Map.entry("Sleep Reminder", "moon"),
      Map.entry("Spawn Distance", "home"),
      Map.entry("Third Person Nametag", "user-round"),
      Map.entry("Waypoints", "map-pin"),
      Map.entry("XP Progress", "trending-up"),
      Map.entry("Item Physics", "box"),
      Map.entry("FOV Changer", "eye"),
      Map.entry("Block Overlay", "square"),
      Map.entry("Discord Presence", "message-square")
   );

   /** The icon for a module: explicit mapping first, category icon as fallback. */
   private static String iconFor(Module m) {
      String icon = MODULE_ICONS.get(m.getName());
      return icon != null ? icon : categoryIcon(m.getCategory());
   }

   private static String keyName(int key) {
      return switch (key) {
         case 32 -> "SPACE";
         case 340 -> "LSHIFT";
         case 341 -> "RSHIFT";
         case 342 -> "ALT";
         default -> {
            String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(key, 0);
            yield name != null ? name.toUpperCase(Locale.ROOT) : ("KEY " + key);
         }
      };
   }

   /* ========================================================== RENDERING */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();

      int dimA = (int) (0.70F * 255.0F * this.dimStrength() / 100.0F);
      context.fill(0, 0, w, h, dimA << 24 | 0x0B0E14);

      // Base menu scale from settings, then an extra fit factor so the panel
      // + margins ALWAYS fit the window (the v4 "cut off border" bug).
      float base = this.uiScale();
      float fit = Math.min(1.0F, Math.min(w / (base * DESIGN_W + 12.0F), h / (base * DESIGN_H + 12.0F)));
      float scale = base * Math.max(0.35F, fit);
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int vmx = (int) (mouseX / scale);
      int vmy = (int) (mouseY / scale);

      float panelW = Math.min(vw - 24, 980);
      float panelH = Math.min(vh - 24, 640);
      float panelX = (vw - panelW) / 2.0F;
      float panelY = (vh - panelH) / 2.0F;
      float radius = this.roundness();

      this.chipHits.clear();
      this.tabHits.clear();
      this.sideHits.clear();
      this.optionHits.clear();
      this.toggleHits.clear();
      this.gearHits.clear();
      this.bodyHits.clear();

      if (this.menuShadow()) {
         PremiumRender.drawShadow(context, (int) panelX - 2, (int) panelY - 2, (int) panelW + 4, (int) panelH + 4, 0x77000000, 14);
      }

      float bodyAlpha = Math.min(1.0F, 0.35F + 0.65F * (this.bodyOpacity() / 100.0F));
      SmoothRect.fill(context, panelX, panelY, panelW, panelH, radius, withAlpha(DesignTokens.panelBg() & 0x00FFFFFF, bodyAlpha));

      this.drawTopBar(context, panelX, panelY, panelW, vmx, vmy);
      this.drawSidebar(context, panelX, panelY, panelH, vmx, vmy);

      float contentX = panelX + SIDEBAR_W;
      float contentW = panelW - SIDEBAR_W;
      this.drawToolbar(context, contentX, contentW, panelY + TOP_BAR_H, vmx, vmy);

      float listX = contentX + PAD;
      float listW = contentW - PAD * 2 - 6;
      float top = panelY + TOP_BAR_H + TOOLBAR_H + 6;
      float bottom = panelY + panelH - PAD;
      this.drawModules(context, listX, listW, top, bottom, scale, vmx, vmy);

      // Border LAST and never scissored: the box outline is always complete.
      int borderBase = DesignTokens.panelBorder();
      float borderAlpha = Math.max(0.55F, ((borderBase >>> 24) & 0xFF) / 255.0F);
      SmoothRect.outline(context, panelX, panelY, panelW, panelH, radius, 1.5F, withAlpha(borderBase & 0xFFFFFF, borderAlpha));

      context.getMatrices().popMatrix();

      if (this.animated()) {
         this.smoothScroll += (this.targetScroll - this.smoothScroll) * Math.min(1.0F, delta * 14.0F);
         if (Math.abs(this.targetScroll - this.smoothScroll) < 0.25F) {
            this.smoothScroll = this.targetScroll;
         }
      } else {
         this.smoothScroll = this.targetScroll;
      }
      /*
       * LOAD popup - drawn LAST so it floats above the panel and its border.
       * Uses raw (unscaled) mouse coords because it is drawn outside the
       * panel's matrix transform.
       */
      if (this.loadBoxOpen) {
         this.drawLoadModal(context, mouseX, mouseY);
      } else {
         this.loadBoxRect = null;
         this.loadBoxGo = null;
         this.loadBoxClose = null;
      }

      // Custom immediate-mode screen: super.render() is never called, so draw
      // toasts here (the ScreenMixin hook only fires for vanilla render paths).
      if (this.client != null && this.client.player == null) {
         BlueClient.getInstance().notificationManager().render(context);
      }
   }

   /* ---------------------------------------------------------- top bar */

   private void drawTopBar(DrawContext context, float px, float py, float pw, int mx, int my) {
      SmoothRect.fill(context, px + 1, py + 1, pw - 2, TOP_BAR_H - 1, Math.max(0.0F, this.roundness() - 1.0F), this.cardFill(0x80141A26));
      SmoothRect.fill(context, px + 1, py + TOP_BAR_H - 1, pw - 2, 1, 0.5F, 0x22FFFFFF);

      RenderUtil.drawLogo(context, (int) (px + 10), (int) (py + 8), 18);
      TextPainter.drawPoppins(context, "BLUE CLIENT", px + 10 + RenderUtil.logoWidth(18) + 8, py + 11, DesignTokens.textHi(), 11.0F);

      // centre tabs
      String[] tabs = new String[]{"MODS", "SETTINGS", "HUD", "ACCOUNTS"};
      float tabW = 62;
      float total = tabs.length * tabW + (tabs.length - 1) * 6;
      float tx = px + pw / 2 - total / 2;
      for (int i = 0; i < tabs.length; i++) {
         float x = tx + i * (tabW + 6);
         boolean active = i == 0;
         boolean hovered = mx >= x && mx < x + tabW && my >= py + 7 && my < py + 7 + 20;
         SmoothRect.fill(context, x, py + 7, tabW, 20, 5.0F,
            active ? withAlpha(DesignTokens.accent(), 0.22F) : hovered ? 0x1FFFFFFF : 0x0DFFFFFF);
         if (active) {
            SmoothRect.outline(context, x, py + 7, tabW, 20, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.6F));
         }
         TextPainter.drawPoppins(context, tabs[i], x + tabW / 2 - TextPainter.poppinsWidth(tabs[i], 8.5F) / 2.0F,
            py + 12, active ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);
         if (!active) {
            this.tabHits.add(new RectHit(x, py + 7, tabW, 20, i));
         }
      }

      // close button
      float cx = px + pw - 30;
      this.closeBtn = new Rect(cx, py + 7, 22, 20);
      boolean closeHover = this.closeBtn.contains(mx, my);
      SmoothRect.fill(context, cx, py + 7, 22, 20, 5.0F, closeHover ? 0x33FF5C5C : 0x14FFFFFF);
      RenderUtil.drawIcon(context, "x", (int) (cx + 6), (int) (py + 11), 10, closeHover ? 0xFFFF8A8A : DesignTokens.textMid());
   }

   /* ---------------------------------------------------------- sidebar */

   private void drawSidebar(DrawContext context, float px, float py, float ph, int mx, int my) {
      float x = px + 1;
      float y = py + TOP_BAR_H;
      float w = SIDEBAR_W - 1;
      float h = ph - TOP_BAR_H - 1;
      SmoothRect.fill(context, x, y, w, h, Math.max(0.0F, this.roundness() - 1.0F), this.cardFill(0x66141A26));
      SmoothRect.fill(context, x + w - 1, y + 6, 1, h - 12, 0.5F, 0x22FFFFFF);

      float ey = y + 10;
      TextPainter.drawPoppins(context, "FILTER", x + 10, ey, DesignTokens.textMid(), 7.5F);
      ey += 13;

      List<Category> order = new ArrayList<>();
      order.add(null);
      for (Category c : Category.values()) {
         // Blue+ only appears once you actually have Blue+.
         if (c.visible()) {
            order.add(c);
         }
      }
      for (Category c : order) {
         boolean active = this.category == c;
         boolean hovered = mx >= x + 6 && mx < x + w - 6 && my >= ey && my < ey + 22;
         if (active) {
            SmoothRect.fill(context, x + 6, ey, w - 12, 22, 5.0F, DesignTokens.accentSoft());
            SmoothRect.outline(context, x + 6, ey, w - 12, 22, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.55F));
         } else if (hovered) {
            SmoothRect.fill(context, x + 6, ey, w - 12, 22, 5.0F, 0x14FFFFFF);
         }
         String icon = categoryIcon(c);
         RenderUtil.drawIcon(context, icon, (int) (x + 12), (int) (ey + 5), 12,
            active ? DesignTokens.accent() : DesignTokens.textMid());
         String label = c == null ? "All Modules" : c.displayName();
         TextPainter.drawPoppins(context, label, x + 30, ey + 7,
            active ? DesignTokens.textHi() : DesignTokens.textMid(), 9.0F);
         int on = this.enabledCount(c);
         if (on > 0) {
            String badge = String.valueOf(on);
            float bw = TextPainter.poppinsWidth(badge, 7.5F) + 8;
            SmoothRect.fill(context, x + w - 12 - bw, ey + 6, bw, 11, 5.5F,
               active ? withAlpha(DesignTokens.accent(), 0.85F) : 0x26FFFFFF);
            TextPainter.drawPoppins(context, badge, x + w - 12 - bw + 4, ey + 7.5F,
               active ? 0xFFFFFFFF : DesignTokens.textHi(), 7.5F);
         }
         this.chipHits.add(new RectHit(x + 6, ey, w - 12, 22, c == null ? -1 : c.ordinal()));
         ey += 26;
      }

      float bottomY = py + ph - 78;
      this.hudBtn = new Rect(x + 8, bottomY, w - 16, 24);
      boolean hudHover = this.hudBtn.contains(mx, my);
      SmoothRect.fill(context, this.hudBtn.x, this.hudBtn.y, this.hudBtn.w, this.hudBtn.h, 5.0F,
         hudHover ? 0x22FFFFFF : this.cardFill(0x11FFFFFF));
      RenderUtil.drawIcon(context, "move", (int) (this.hudBtn.x + 8), (int) (this.hudBtn.y + 6), 12,
         hudHover ? DesignTokens.textHi() : DesignTokens.textMid());
      TextPainter.drawPoppins(context, "EDIT HUD", this.hudBtn.x + 26, this.hudBtn.y + 8,
         hudHover ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);

      /* --- SAVE: copy a share code to the clipboard --------------------- */
      this.saveBtn = new Rect(x + 8, bottomY + 28, w - 16, 24);
      boolean saveHover = this.saveBtn.contains(mx, my);
      SmoothRect.fill(context, this.saveBtn.x, this.saveBtn.y, this.saveBtn.w, this.saveBtn.h, 5.0F,
         saveHover ? 0x22FFFFFF : this.cardFill(0x11FFFFFF));
      RenderUtil.drawIcon(context, "share-2", (int) (this.saveBtn.x + 8), (int) (this.saveBtn.y + 6), 12,
         saveHover ? DesignTokens.textHi() : DesignTokens.textMid());
      TextPainter.drawPoppins(context, "SAVE", this.saveBtn.x + 26, this.saveBtn.y + 8,
         saveHover ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);

      /* --- LOAD: opens an inline paste field ---------------------------- */
      this.loadBtn = new Rect(x + 8, bottomY + 56, w - 16, 24);
      boolean loadHover = this.loadBtn.contains(mx, my);
      SmoothRect.fill(context, this.loadBtn.x, this.loadBtn.y, this.loadBtn.w, this.loadBtn.h, 5.0F,
         this.loadBoxOpen ? withAlpha(DesignTokens.accent(), 0.30F)
            : loadHover ? 0x22FFFFFF : this.cardFill(0x11FFFFFF));
      RenderUtil.drawIcon(context, "clipboard-paste", (int) (this.loadBtn.x + 8), (int) (this.loadBtn.y + 6), 12,
         loadHover || this.loadBoxOpen ? DesignTokens.textHi() : DesignTokens.textMid());
      TextPainter.drawPoppins(context, "LOAD", this.loadBtn.x + 26, this.loadBtn.y + 8,
         loadHover || this.loadBoxOpen ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);

      // NOTE: the LOAD popup is NOT drawn here any more. It used to be an
      // inline strip at bottomY + 84, which fell off the bottom of the screen
      // on smaller displays (owner: "it opens below it which is off my
      // screen"). It is now a centred modal drawn at the very end of render().

      TextPainter.drawPoppins(context, BlueClient.displayVersion(), x + 10, py + ph - 18, 0x66FFFFFF, 7.0F);
   }

   /* ---------------------------------------------------------- toolbar */

   private void drawToolbar(DrawContext context, float cx, float cw, float ty, int mx, int my) {
      float x = cx + PAD;
      float w = cw - PAD * 2;

      // stat chip
      int total = this.all().size();
      int on = this.enabledCount(null);
      String stat = on + " / " + total + " ON";
      float statW = TextPainter.poppinsWidth(stat, 8.5F) + 14;
      SmoothRect.fill(context, x, ty + 5, statW, 18, 5.0F, this.cardFill(0x14FFFFFF));
      SmoothRect.outline(context, x, ty + 5, statW, 18, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.35F));
      TextPainter.drawPoppins(context, stat, x + 7, ty + 10, DesignTokens.textHi(), 8.5F);

      // view toggle: grid / list
      float toggleX = x + w - SEARCH_W - 8 - 52;
      // v0.16.11: enabled-first sorting pill
      this.sortBtn = new Rect(toggleX - 32, ty + 4, 24, 20);
      boolean enabledFirst = this.blue.settings().modulesEnabledFirst();
      boolean sortHover = this.sortBtn.contains(mx, my);
      SmoothRect.fill(context, this.sortBtn.x, this.sortBtn.y, 24, 20, 5.0F,
         enabledFirst ? withAlpha(DesignTokens.accent(), 0.25F) : sortHover ? 0x1FFFFFFF : 0x0DFFFFFF);
      if (enabledFirst) {
         SmoothRect.outline(context, this.sortBtn.x, this.sortBtn.y, 24, 20, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.55F));
      }
      RenderUtil.drawIcon(context, "zap", (int) (this.sortBtn.x + 6), (int) (ty + 9), 11,
         enabledFirst ? DesignTokens.accent() : DesignTokens.textMid());
      boolean cards = this.cardsView();
      this.gridBtn = new Rect(toggleX, ty + 4, 24, 20);
      this.listBtn = new Rect(toggleX + 28, ty + 4, 24, 20);
      boolean gridHover = this.gridBtn.contains(mx, my);
      boolean listHover = this.listBtn.contains(mx, my);
      SmoothRect.fill(context, this.gridBtn.x, this.gridBtn.y, 24, 20, 5.0F,
         cards ? withAlpha(DesignTokens.accent(), 0.25F) : gridHover ? 0x1FFFFFFF : 0x0DFFFFFF);
      SmoothRect.fill(context, this.listBtn.x, this.listBtn.y, 24, 20, 5.0F,
         !cards ? withAlpha(DesignTokens.accent(), 0.25F) : listHover ? 0x1FFFFFFF : 0x0DFFFFFF);
      RenderUtil.drawIcon(context, "layout-grid", (int) (this.gridBtn.x + 6), (int) (ty + 9), 11,
         cards ? DesignTokens.accent() : DesignTokens.textMid());
      RenderUtil.drawIcon(context, "list-music", (int) (this.listBtn.x + 6), (int) (ty + 9), 11,
         !cards ? DesignTokens.accent() : DesignTokens.textMid());

      // search
      float sx = x + w - SEARCH_W;
      this.searchBox = new Rect(sx, ty + 4, SEARCH_W, SEARCH_H);
      boolean hovered = this.searchBox.contains(mx, my);
      boolean focused = this.searchFocused;
      SmoothRect.fill(context, sx, ty + 4, SEARCH_W, SEARCH_H, 6.0F, this.cardFill(0x99101520));
      SmoothRect.outline(context, sx, ty + 4, SEARCH_W, SEARCH_H, 6.0F, 1.0F,
         focused ? withAlpha(DesignTokens.accent(), 0.9F) : hovered ? 0x3DFFFFFF : 0x22FFFFFF);
      RenderUtil.drawIcon(context, "search", (int) sx + 7, (int) (ty + 9), 10,
         focused || !this.query.isEmpty() ? DesignTokens.accent() : DesignTokens.textMid());
      if (this.query.isEmpty()) {
         TextPainter.drawPoppins(context, "Search...", sx + 22, ty + 9.5F, DesignTokens.textMid(), 9.0F);
      } else {
         String shown = fitTextPoppins(this.query, (int) (SEARCH_W - 28), 9.0F);
         TextPainter.drawPoppins(context, shown, sx + 22, ty + 9.5F, DesignTokens.textHi(), 9.0F);
      }
      if (focused && (System.currentTimeMillis() / 500) % 2 == 0) {
         float textW = this.query.isEmpty() ? 0 : TextPainter.poppinsWidth(this.query, 9.0F);
         SmoothRect.fill(context, sx + 23 + Math.min(textW, SEARCH_W - 30), ty + 8, 1, 12, 0.5F, DesignTokens.accent());
      }
   }

   /* ---------------------------------------------------------- modules */

   private void drawModules(DrawContext context, float x, float w, float top, float bottom, float sc, int mx, int my) {
      this.listTop = top;
      this.listBottom = bottom;
      List<Module> modules = this.visible();

      int cols;
      float itemW;
      int itemH;
      if (this.cardsView()) {
         cols = Math.max(1, Math.min(4, (int) Math.floor((w + GAP) / (float) CARD_MIN_W)));
         itemW = (w - (cols - 1) * GAP) / cols;
         itemH = CARD_H;
      } else {
         cols = Math.max(1, Math.min(4, (int) Math.floor((w + GAP) / (float) LIST_MIN_W)));
         itemW = (w - (cols - 1) * GAP) / cols;
         itemH = LIST_H;
      }
      int rows = (modules.size() + cols - 1) / cols;
      int step = itemH + GAP;
      float viewH = bottom - top;
      // Only whole rows are ever shown: snap the scroll to the row grid and
      // clip at a row boundary, so no card/row is ever drawn half-cut.
      int visibleRows = Math.max(1, (int) Math.floor((viewH + GAP) / (float) step));

      /*
       * SMOOTH vs SNAP (owner request, v0.24.1).
       *
       * Smooth (the default): scrolling is free-floating and can stop halfway
       * through a row, so the list follows the wheel exactly. The content is
       * clipped at the panel edge and rows may be partially visible - that is
       * what makes it feel smooth.
       *
       * Snap (opt-in via Settings > Interface > "Snap scrolling"): the scroll
       * offset is rounded to the row grid and the clip stops at a row boundary,
       * so a card is never drawn half-cut. This was the old behaviour.
       */
      boolean snap = BlueClient.getInstance().settings().snapScrolling();
      float maxScroll;
      float clipBottom;
      if (snap) {
         maxScroll = Math.max(0, (rows - visibleRows) * step);
         this.targetScroll = Math.max(0, Math.min(this.targetScroll, maxScroll));
         float snapped = Math.round(this.targetScroll / (float) step) * step;
         this.targetScroll = Math.max(0, Math.min(snapped, maxScroll));
         clipBottom = Math.min(bottom, top + visibleRows * step - GAP);
      } else {
         // Free scrolling: allow travelling until the last row's bottom edge
         // touches the bottom of the viewport.
         maxScroll = Math.max(0, rows * step - GAP - viewH);
         this.targetScroll = Math.max(0, Math.min(this.targetScroll, maxScroll));
         clipBottom = bottom;
      }
      float contentHeight = rows * step;

      if (modules.isEmpty()) {
         this.drawEmptyState(context, x, w, top, bottom);
         return;
      }

      // Scissor EXACTLY the scrollable area (whole rows only) - nothing
      // paints over chrome and nothing is ever clipped mid-card.
      // NOTE: enableScissor transforms by the current matrix itself, so the
      // virtual coordinates go in untouched (pre-scaling them double-scales
      // the clip and cuts the right side off - the old "cut off" bug).
      context.enableScissor((int) Math.floor(x - 2), (int) Math.floor(top),
         (int) Math.ceil(x + w + 8), (int) Math.ceil(clipBottom + 2));

      long now = System.currentTimeMillis();
      for (int i = 0; i < modules.size(); i++) {
         Module m = modules.get(i);
         int col = i % cols;
         int rowIdx = i / cols;
         float itemX = x + col * (itemW + GAP);
         float baseY = top - this.smoothScroll + rowIdx * (itemH + GAP);
         if (baseY + itemH < top || baseY > bottom) {
            continue;
         }

         float reveal = 1.0F;
         float revealOffY = 0;
         if (this.animated()) {
            long sinceOpen = now - this.revealStartMs;
            long itemDelay = 40 + (long) (i * 10.0F);
            if (sinceOpen < itemDelay) {
               reveal = 0;
            } else {
               float t = Math.min(1.0F, (sinceOpen - itemDelay) / 200.0F);
               reveal = Easing.EASE_OUT_CUBIC.apply(t);
               revealOffY = (1.0F - reveal) * 6.0F;
            }
         }
         if (reveal <= 0) {
            continue;
         }

         if (this.cardsView()) {
            this.drawCard(context, m, itemX, baseY + revealOffY, itemW, mx, my);
         } else {
            this.drawRow(context, m, itemX, baseY + revealOffY, itemW, mx, my);
         }
      }

      context.disableScissor();

      if (contentHeight > viewH) {
         float thumbH = Math.max(24, viewH * (viewH / contentHeight));
         float thumbY = top + (this.smoothScroll / maxScroll) * (viewH - thumbH);
         SmoothRect.fill(context, x + w + 3, top, 3, viewH, 1.5F, draggingThumb ? 0x33FFFFFF : 0x14FFFFFF);
         SmoothRect.fill(context, x + w + 3, thumbY, 3, thumbH, 1.5F, withAlpha(DesignTokens.accent(), draggingThumb ? 1.0F : 0.75F));
         // remember the thumb geometry so the mouse handlers can drag it
         this.thumbX = x + w + 3;
         this.trackTop = top;
         this.trackH = viewH;
         this.thumbHf = thumbH;
         this.scrollMaxF = maxScroll;
      } else {
         this.thumbX = Float.MIN_VALUE;
      }
   }

   /** Module card: centred icon + name, OPTIONS bar, ENABLED bar. */
   private void drawCard(DrawContext context, Module m, float x, float y, float w, int mx, int my) {
      boolean enabled = m.isEnabled();
      boolean hovered = mx >= x && mx < x + w && my >= y && my < y + CARD_H;

      SmoothRect.fill(context, x, y, w, CARD_H, 6.0F, this.cardFill(hovered ? 0xE6151B29 : 0xB3121724));
      SmoothRect.outline(context, x, y, w, CARD_H, 6.0F, 1.0F,
         enabled ? withAlpha(DesignTokens.accent(), 0.35F) : hovered ? 0x26FFFFFF : 0x14FFFFFF);

      RenderUtil.drawIcon(context, iconFor(m), (int) (x + w / 2 - 13), (int) (y + 12), 26,
         enabled ? this.menuIconColor() : withAlpha(this.menuIconColor() & 0xFFFFFF, 0.55F));

      String name = fitTextPoppins(m.getName(), (int) (w - 14), 10.5F);
      TextPainter.drawPoppins(context, name, x + w / 2 - TextPainter.poppinsWidth(name, 10.5F) / 2.0F, y + 46,
         enabled ? this.menuTextColor() : withAlpha(this.menuTextColor() & 0xFFFFFF, 0.6F), 10.5F);

      boolean hasSettings = !visibleSettings(m).isEmpty();

      // OPTIONS bar
      float optY = y + 64;
      SmoothRect.fill(context, x + 8, optY, w - 16, 17, 4.0F, this.cardFill(0xCC1B2230));
      SmoothRect.outline(context, x + 8, optY, w - 16, 17, 4.0F, 1.0F, DesignTokens.panelBorder());
      String optLabel = "OPTIONS";
      /*
       * Centre OPTIONS in the space it can ACTUALLY use, not the whole bar.
       *
       * The gear icon sits at the right end of the bar, so centring on the bar
       * made the label visually collide with it. The old code "fixed" that with
       * a hard-coded "- 5" nudge, which is why the text looked off-centre
       * (reported by the owner). Now we centre inside the gap between the left
       * edge of the bar and the left edge of the gear, so it is genuinely
       * centred in its own space at any card width.
       */
      float optBarLeft = x + 8;
      float optGearLeft = x + w - 8 - 15;
      float optTextCenter = (optBarLeft + optGearLeft) / 2.0F;
      TextPainter.drawPoppins(context, optLabel,
         optTextCenter - TextPainter.poppinsWidth(optLabel, 7.5F) / 2.0F,
         optY + 5, hasSettings ? DesignTokens.textHi() : DesignTokens.textMid(), 7.5F);
      RenderUtil.drawIcon(context, "settings", (int) (x + w - 8 - 15), (int) (optY + 3), 11,
         hasSettings ? DesignTokens.textMid() : withAlpha(DesignTokens.textMid() & 0xFFFFFF, 0.33F));
      if (hasSettings) {
         this.optionHits.add(new ModuleHit(m, x + 8, optY, w - 16, 17));
      }

      // ENABLED / DISABLED bar
      float togY = y + 86;
      boolean togHover = mx >= x + 8 && mx < x + w - 8 && my >= togY && my < togY + 17;
      int fillColor = enabled ? GREEN : CRIMSON;
      if (togHover) {
         fillColor = enabled ? 0xFF46CE6C : 0xFFDF5573;
      }
      SmoothRect.fill(context, x + 8, togY, w - 16, 17, 4.0F, fillColor);
      String state = enabled ? "ENABLED" : "DISABLED";
      TextPainter.drawPoppins(context, state, x + w / 2 - TextPainter.poppinsWidth(state, 7.5F) / 2.0F,
         togY + 5, 0xFFFFFFFF, 7.5F);
      this.toggleHits.add(new ModuleHit(m, x + 8, togY, w - 16, 17));

      int bind = m.getKeybind();
      if (bind > 0) {
         String label = keyName(bind);
         float kw = TextPainter.poppinsWidth(label, 6.5F) + 8;
         SmoothRect.fill(context, x + w - 8 - kw, y + 8, kw, 11, 3.5F, 0x26FFFFFF);
         TextPainter.drawPoppins(context, label, x + w - 8 - kw + 4, y + 9.5F, DesignTokens.textMid(), 6.5F);
      }

      this.bodyHits.add(new ModuleHit(m, x, y, w, CARD_H));
   }

   /** Compact bordered row grid (green = on, crimson = off) + gear box. */
   private void drawRow(DrawContext context, Module m, float x, float y, float w, int mx, int my) {
      boolean enabled = m.isEnabled();
      boolean hasSettings = !visibleSettings(m).isEmpty();
      float gearW = hasSettings ? 24 : 0;
      float rowW = w - gearW - (hasSettings ? 4 : 0);

      boolean hovered = mx >= x && mx < x + w && my >= y && my < y + LIST_H;
      int border = enabled ? GREEN_DIM : CRIMSON_DIM;
      if (hovered) {
         border = enabled ? GREEN : CRIMSON;
      }
      SmoothRect.fill(context, x, y, rowW, LIST_H, 5.0F, this.cardFill(hovered ? 0xE6151B29 : 0xB3121724));
      SmoothRect.outline(context, x, y, rowW, LIST_H, 5.0F, 1.0F, border);

      RenderUtil.drawIcon(context, iconFor(m), (int) (x + 6), (int) (y + 6), 12,
         enabled ? this.menuIconColor() : withAlpha(this.menuIconColor() & 0xFFFFFF, 0.55F));
      String name = fitTextPoppins(m.getName(), (int) (rowW - 26), 8.5F);
      TextPainter.drawPoppins(context, name, x + 22, y + 7.5F,
         enabled ? this.menuTextColor() : withAlpha(this.menuTextColor() & 0xFFFFFF, 0.6F), 8.5F);
      this.toggleHits.add(new ModuleHit(m, x, y, rowW, LIST_H));

      if (hasSettings) {
         float gx = x + rowW + 4;
         boolean gearHover = mx >= gx && mx < gx + gearW && my >= y && my < y + LIST_H;
         SmoothRect.fill(context, gx, y, gearW, LIST_H, 5.0F, this.cardFill(gearHover ? 0xE61B2230 : 0xB3161C29));
         SmoothRect.outline(context, gx, y, gearW, LIST_H, 5.0F, 1.0F, gearHover ? withAlpha(DesignTokens.accent(), 0.7F) : border);
         RenderUtil.drawIcon(context, "settings", (int) (gx + gearW / 2 - 6), (int) (y + 6), 12,
            gearHover ? DesignTokens.accent() : DesignTokens.textMid());
         this.gearHits.add(new ModuleHit(m, gx, y, gearW, LIST_H));
      }
   }

   private void drawEmptyState(DrawContext context, float x, float w, float top, float bottom) {
      float cx = x + w / 2;
      float cy = (top + bottom) / 2 - 20;
      RenderUtil.drawIcon(context, "search", (int) cx - 14, (int) cy, 28, withAlpha(DesignTokens.textMid(), 0.45F));
      String msg = this.query.isEmpty() ? "Nothing here yet" : "No modules match";
      TextPainter.drawPoppins(context, msg, cx - TextPainter.poppinsWidth(msg, 12.0F) / 2, cy + 40, DesignTokens.textHi(), 12.0F);
      String sub = this.query.isEmpty() ? "Check another category" : "Try a different search";
      // Round, do not truncate: textWidth() is an int, so "/ 2" was integer
      // division and odd-width strings landed half a pixel to the left.
      RenderUtil.drawText(context, sub,
         Math.round(cx - RenderUtil.textWidth(sub) / 2.0F), (int) cy + 54, DesignTokens.textMid());
   }

   /* ============================================================= HELPERS */

   private static List<Setting<?>> visibleSettings(Module m) {
      List<Setting<?>> out = new ArrayList<>();
      for (Setting<?> s : m.getSettings()) {
         try {
            if (s.isVisible()) {
               out.add(s);
            }
         } catch (Throwable t) {
            out.add(s);
         }
      }
      return out;
   }

   private static String fitTextPoppins(String text, int maxWidth, float size) {
      String full = text == null ? "" : text;
      if (TextPainter.poppinsWidth(full, size) <= maxWidth) {
         return full;
      }
      /*
       * The ellipsis must be measured TOO.
       *
       * The old loop trimmed until the bare text fit, then appended "..." -
       * so the returned string was up to ~8px WIDER than maxWidth. Centred
       * labels are drawn at (x + w/2 - width/2), so an over-wide string spills
       * past both edges and reads as off-centre. It only showed up on long
       * labels, which is why the owner saw it "sometimes".
       */
      float ellipsis = TextPainter.poppinsWidth("...", size);
      String t = full;
      while (!t.isEmpty() && TextPainter.poppinsWidth(t, size) + ellipsis > maxWidth) {
         t = t.substring(0, t.length() - 1);
      }
      return t.isEmpty() ? full.substring(0, 1) : t + "...";
   }

   private static String fitText(String text, int maxWidth) {
      if (text == null || text.isEmpty()) {
         return "";
      }
      if (RenderUtil.textWidth(text) <= maxWidth) {
         return text;
      }
      // Measure the ellipsis as well - see fitTextPoppins.
      int ellipsis = RenderUtil.textWidth("...");
      String t = text;
      while (!t.isEmpty() && RenderUtil.textWidth(t) + ellipsis > maxWidth) {
         t = t.substring(0, t.length() - 1);
      }
      return t.isEmpty() ? text.substring(0, 1) : t + "...";
   }

   private static int withAlpha(int color, float alpha) {
      int a = (int) (alpha * 255.0F) & 0xFF;
      return (a << 24) | (color & 0x00FFFFFF);
   }

   /* ============================================================== INPUT */

   /**
    * Draws the inline "paste your code here" field that appears under LOAD.
    *
    * <p>It is deliberately not a vanilla {@code TextFieldWidget}: share codes
    * run to thousands of characters, and we only ever need to show the tail of
    * what was pasted plus a confirm button.</p>
    */
   /**
    * Centred "Load share code" modal.
    *
    * <h3>v0.24.5</h3>
    * Owner: "the load button in modules should open a popup in center of
    * screen with an x button and an input button too, currently it opens below
    * it which is off my screen."
    *
    * <p>The old version drew an inline strip directly beneath the LOAD button
    * at a hardcoded {@code bottomY + 84}. On a short window (or at a large GUI
    * scale) that was below the bottom edge and simply invisible.</p>
    *
    * <p>This is a real modal: a dimmed full-screen backdrop, a panel centred on
    * the window, an X in the corner, the paste field, and a LOAD button. It is
    * drawn at the end of {@code render()} so nothing can cover it, and it uses
    * <b>raw window coordinates</b> because it lives outside the module panel's
    * scale transform.</p>
    */
   private void drawLoadModal(DrawContext context, int mx, int my) {
      int sw = context.getScaledWindowWidth();
      int sh = context.getScaledWindowHeight();

      // Dimmed backdrop; clicking it closes the popup.
      context.fill(0, 0, sw, sh, 0xAA000000);
      this.loadBoxBackdrop = new Rect(0, 0, sw, sh);

      int pw = Math.min(320, sw - 40);
      int ph = 132;
      int px = (sw - pw) / 2;
      int py = (sh - ph) / 2;

      SmoothRect.fill(context, px, py, pw, ph, 8.0F, DesignTokens.panelBg());
      SmoothRect.outline(context, px, py, pw, ph, 8.0F, 1.5F, withAlpha(DesignTokens.accent(), 0.75F));

      // Title
      TextPainter.drawPoppins(context, "LOAD SHARE CODE",
         px + pw / 2.0F - TextPainter.poppinsWidth("LOAD SHARE CODE", 11.0F) / 2.0F,
         py + 14, DesignTokens.textHi(), 11.0F);
      String hint = "Paste a BLUE1- code to apply a saved config";
      TextPainter.drawPoppins(context, hint,
         px + pw / 2.0F - TextPainter.poppinsWidth(hint, 7.5F) / 2.0F,
         py + 30, DesignTokens.textMid(), 7.5F);

      /* ---- close (X) ---- */
      int cx = px + pw - 24;
      int cy = py + 8;
      this.loadBoxClose = new Rect(cx, cy, 16, 16);
      boolean closeHover = this.loadBoxClose.contains(mx, my);
      SmoothRect.fill(context, cx, cy, 16, 16, 4.0F, closeHover ? 0xFFC9405E : 0x22FFFFFF);
      RenderUtil.drawIcon(context, "x", cx + 2, cy + 2, 12,
         closeHover ? 0xFFFFFFFF : DesignTokens.textMid());

      /* ---- paste field ---- */
      int fx = px + 16;
      int fy = py + 48;
      int fw = pw - 32;
      this.loadBoxRect = new Rect(fx, fy, fw, 26);
      boolean fieldHover = this.loadBoxRect.contains(mx, my);
      SmoothRect.fill(context, fx, fy, fw, 26, 5.0F, 0x33000000);
      SmoothRect.outline(context, fx, fy, fw, 26, 5.0F, 1.0F,
         withAlpha(DesignTokens.accent(), fieldHover ? 0.85F : 0.55F));

      // Show the END of the code (that is where the caret is) rather than the
      // start, which is always the same "BLUE1-H4sI..." prefix.
      String shown = this.loadBoxText.isEmpty() ? "paste code..." : this.loadBoxText;
      while (TextPainter.poppinsWidth(shown, 8.0F) > fw - 16 && shown.length() > 1) {
         shown = shown.substring(1);
      }
      boolean blink = (System.currentTimeMillis() / 500L) % 2L == 0L;
      TextPainter.drawPoppins(context, this.loadBoxText.isEmpty() ? shown : shown + (blink ? "_" : ""),
         fx + 8, fy + 9.5F,
         this.loadBoxText.isEmpty() ? DesignTokens.textMid() : DesignTokens.textHi(), 8.0F);

      /* ---- paste hint ---- */
      String paste = "Ctrl+V or right-click to paste";
      TextPainter.drawPoppins(context, paste, fx, fy + 31, DesignTokens.textMid(), 7.0F);

      /* ---- LOAD button ---- */
      int bw = fw;
      int bx = fx;
      int by = py + ph - 34;
      this.loadBoxGo = new Rect(bx, by, bw, 24);
      boolean goHover = this.loadBoxGo.contains(mx, my);
      SmoothRect.fill(context, bx, by, bw, 24, 5.0F,
         goHover ? withAlpha(DesignTokens.accent(), 0.95F) : withAlpha(DesignTokens.accent(), 0.65F));
      TextPainter.drawPoppins(context, "LOAD",
         bx + bw / 2.0F - TextPainter.poppinsWidth("LOAD", 9.0F) / 2.0F,
         by + 8, 0xFFFFFFFF, 9.0F);
   }

   /**
    * Feeds whatever is in the paste box to {@link ProfileCode#load(String)} and
    * reports the outcome as a notification. {@code ProfileCode.load} never
    * throws, so a bad paste is a message, not a crash.
    */
   private void applyLoadCode() {
      String code = this.loadBoxText.trim();
      if (code.isEmpty()) {
         this.blue.notificationManager().add("Paste a code first", 0xFFFFAA33);
         return;
      }
      ProfileCode.Result result = ProfileCode.load(code);
      this.blue.notificationManager()
         .add(result.message(), result.ok() ? DesignTokens.accent() : 0xFFFF5C5C);
      if (result.ok()) {
         this.loadBoxOpen = false;
         this.loadBoxText = "";
         this.blue.configManager().save();
      }
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      float s = this.drawScale;
      int mx = (int) (click.x() / s);
      int my = (int) (click.y() / s);

      /*
       * LOAD popup first, and in RAW window coordinates.
       *
       * The modal is drawn outside the module panel's scale transform, so its
       * rects are in real window pixels - dividing by drawScale here would put
       * the hitboxes in the wrong place. While it is open it is modal: it
       * swallows every click so nothing behind it can be activated.
       */
      if (this.loadBoxOpen) {
         int rx = (int) click.x();
         int ry = (int) click.y();

         if (this.loadBoxClose != null && this.loadBoxClose.contains(rx, ry)) {
            RenderUtil.clickSound();
            this.loadBoxOpen = false;
            return true;
         }
         if (this.loadBoxGo != null && this.loadBoxGo.contains(rx, ry)) {
            RenderUtil.clickSound();
            this.applyLoadCode();
            return true;
         }
         if (this.loadBoxRect != null && this.loadBoxRect.contains(rx, ry)) {
            // Right-click inside the field pastes, matching the search box.
            if (click.button() == 1) {
               try {
                  this.loadBoxText = this.client.keyboard.getClipboard().trim();
               } catch (Throwable ignored) {
               }
            }
            return true;
         }
         // Anywhere else = outside the panel = dismiss.
         this.loadBoxOpen = false;
         return true;
      }

      // v0.16.12: the scrollbar is draggable - grab the thumb, or jump to a
      // position when the track itself is clicked.
      if (this.thumbX != Float.MIN_VALUE && this.scrollMaxF > 0
         && mx >= this.thumbX - 4 && mx <= this.thumbX + 7
         && my >= this.trackTop && my <= this.trackTop + this.trackH) {
         float thumbY = this.trackTop + (this.smoothScroll / this.scrollMaxF) * (this.trackH - this.thumbHf);
         if (my >= thumbY && my <= thumbY + this.thumbHf) {
            this.thumbGrabOff = my - thumbY;
         } else {
            this.thumbGrabOff = this.thumbHf / 2.0F;
            this.targetScroll = Math.max(0, Math.min(
               (my - this.trackTop - this.thumbGrabOff) / Math.max(1, this.trackH - this.thumbHf) * this.scrollMaxF, this.scrollMaxF));
         }
         this.draggingThumb = true;
         RenderUtil.clickSound();
         return true;
      }

      if (this.closeBtn != null && this.closeBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.close();
         return true;
      }
      for (RectHit tab : this.tabHits) {
         if (tab.contains(mx, my)) {
            RenderUtil.clickSound();
            switch (tab.index()) {
               case 1 -> this.client.setScreen(new ClientSettingsScreen(this));
               case 2 -> this.client.setScreen(new HudEditScreen(this.blue, this));
               case 3 -> this.client.setScreen(new AccountsScreen(this));
               default -> {
               }
            }
            return true;
         }
      }
      if (this.hudBtn != null && this.hudBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.client.setScreen(new HudEditScreen(this.blue, this));
         return true;
      }
      // SAVE -> clipboard. The owner wants one button that hands them a code.
      if (this.saveBtn != null && this.saveBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         try {
            String code = ProfileCode.save();
            this.client.keyboard.setClipboard(code);
            this.blue.configManager().save();
            this.blue.notificationManager()
               .add("Share code copied (" + code.length() + " chars)", DesignTokens.accent());
         } catch (Throwable t) {
            this.blue.notificationManager().add("Couldn't copy the code", 0xFFFF5C5C);
         }
         return true;
      }

      // LOAD -> open the paste box, pre-filled from the clipboard so the
      // common case ("I just copied a code") is a single extra click.
      if (this.loadBtn != null && this.loadBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.loadBoxOpen = !this.loadBoxOpen;
         if (this.loadBoxOpen) {
            try {
               String clip = this.client.keyboard.getClipboard();
               this.loadBoxText = clip != null && clip.startsWith("BLUE1-") ? clip.trim() : "";
            } catch (Throwable ignored) {
               this.loadBoxText = "";
            }
         }
         return true;
      }


      for (RectHit chip : this.chipHits) {
         if (chip.contains(mx, my)) {
            this.category = chip.index() < 0 ? null : Category.values()[chip.index()];
            this.revealStartMs = System.currentTimeMillis();
            this.targetScroll = 0;
            this.smoothScroll = 0;
            RenderUtil.clickSound();
            return true;
         }
      }
      if (this.sortBtn != null && this.sortBtn.contains(mx, my)) {
         boolean now = !this.blue.settings().modulesEnabledFirst();
         this.blue.settings().modulesEnabledFirst(now);
         RenderUtil.clickSound();
         return true;
      }
      if (this.gridBtn != null && this.gridBtn.contains(mx, my) && !this.cardsView()) {
         this.setView(true);
         return true;
      }
      if (this.listBtn != null && this.listBtn.contains(mx, my) && this.cardsView()) {
         this.setView(false);
         return true;
      }
      if (this.searchBox != null && this.searchBox.contains(mx, my)) {
         this.searchFocused = true;
         return true;
      }
      this.searchFocused = false;

      for (ModuleHit hit : this.optionHits) {
         if (hit.contains(mx, my)) {
            RenderUtil.clickSound();
            this.client.setScreen(new ModuleSettingsScreen(this.blue, this, hit.module()));
            return true;
         }
      }
      for (ModuleHit hit : this.gearHits) {
         if (hit.contains(mx, my)) {
            RenderUtil.clickSound();
            this.client.setScreen(new ModuleSettingsScreen(this.blue, this, hit.module()));
            return true;
         }
      }
      for (ModuleHit hit : this.toggleHits) {
         if (hit.contains(mx, my)) {
            this.toggleAnim.put(hit.module().getName(), System.currentTimeMillis());
            hit.module().toggle();
            RenderUtil.clickSound();
            return true;
         }
      }
      for (ModuleHit hit : this.bodyHits) {
         if (hit.contains(mx, my)) {
            Module m = hit.module();
            if (!visibleSettings(m).isEmpty()) {
               RenderUtil.clickSound();
               this.client.setScreen(new ModuleSettingsScreen(this.blue, this, m));
            } else {
               this.toggleAnim.put(m.getName(), System.currentTimeMillis());
               m.toggle();
               RenderUtil.clickSound();
            }
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   private void setView(boolean cards) {
      this.viewOverride = cards;
      this.targetScroll = 0;
      this.smoothScroll = 0;
      RenderUtil.clickSound();
      MenuCustomizer mc = this.customizer();
      if (mc != null) {
         for (Setting<?> setting : mc.getSettings()) {
            if (setting.getName().equals("Menu Style") && setting instanceof net.bluenetwork.client.setting.ModeSetting mode) {
               mode.set(cards ? "CARDS" : "LIST");
            }
         }
      }
   }

   @Override
   public boolean mouseDragged(Click click, double dx, double dy) {
      if (this.draggingThumb && this.scrollMaxF > 0) {
         float s = this.drawScale;
         float my = (float) (click.y() / s);
         this.targetScroll = Math.max(0, Math.min(
            (my - this.trackTop - this.thumbGrabOff) / Math.max(1, this.trackH - this.thumbHf) * this.scrollMaxF, this.scrollMaxF));
         return true;
      }
      return super.mouseDragged(click, dx, dy);
   }

   @Override
   public boolean mouseReleased(Click click) {
      this.draggingThumb = false;
      return super.mouseReleased(click);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
      float s = this.drawScale;
      if (my / s >= this.listTop && my / s <= this.listBottom) {
         // Smooth scrolling: the wheel only moves the TARGET, and render()
         // eases smoothScroll toward it, so a flick glides instead of jumping.
         this.targetScroll -= (float) vAmount * 40.0F;
         return true;
      }
      return super.mouseScrolled(mx, my, hAmount, vAmount);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();

      /*
       * While the LOAD paste box is open it owns the keyboard, otherwise typing
       * a code would filter the module list instead. Handled BEFORE the search
       * box so the two can never fight over the same keystroke.
       */
      if (this.loadBoxOpen) {
         if (key == 256) {                       // ESC - close, discard
            this.loadBoxOpen = false;
            this.loadBoxText = "";
            return true;
         }
         if (key == 257 || key == 335) {         // ENTER / numpad ENTER - apply
            this.applyLoadCode();
            return true;
         }
         if (key == 259) {                       // BACKSPACE
            if (!this.loadBoxText.isEmpty()) {
               this.loadBoxText = this.loadBoxText.substring(0, this.loadBoxText.length() - 1);
            }
            return true;
         }
         if (key == 86 && input.hasCtrl()) {     // CTRL+V
            try {
               this.loadBoxText = this.client.keyboard.getClipboard().trim();
            } catch (Throwable ignored) {
            }
            return true;
         }
         return true;
      }

      if (key == 259) {
         if (!this.query.isEmpty()) {
            this.query = this.query.substring(0, this.query.length() - 1);
            this.targetScroll = 0;
         }
         return true;
      }
      if (key == 256) {
         if (!this.query.isEmpty()) {
            this.query = "";
            this.targetScroll = 0;
            this.searchFocused = false;
            return true;
         }
         this.close();
         return true;
      }
      if (key == 264 || key == 265) {
         this.targetScroll += key == 264 ? 40 : -40;
         return true;
      }
      if (key == 266 || key == 267) {
         this.targetScroll += key == 266 ? 160 : -160;
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.loadBoxOpen) {
         if (input.isValidChar()) {
            char ch = (char) input.codepoint();
            // Share codes are URL-safe Base64, so plain ASCII is all we accept.
            if (ch >= 32 && ch < 127 && this.loadBoxText.length() < 20000) {
               this.loadBoxText += ch;
            }
         }
         return true;
      }

      if (input.isValidChar()) {
         char ch = (char) input.codepoint();
         if (ch >= 32 && ch < 127) {
            this.query += ch;
            this.targetScroll = 0;
            this.revealStartMs = System.currentTimeMillis();
            return true;
         }
      }
      return super.charTyped(input);
   }

   @Override
   public void removed() {
      try {
         this.blue.configManager().save();
      } catch (Throwable ignored) {
      }
      super.removed();
   }

   @Override
   public void close() {
      if (this.parent != null) {
         this.client.setScreen(this.parent);
      } else {
         super.close();
      }
   }

   /* ========================================================= HIT RECORDS */

   private static final class Rect {
      final float x, y, w, h;

      Rect(float x, float y, float w, float h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }

   private record RectHit(float x, float y, float w, float h, int index) {
      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }

   private record ModuleHit(Module module, float x, float y, float w, float h) {
      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
