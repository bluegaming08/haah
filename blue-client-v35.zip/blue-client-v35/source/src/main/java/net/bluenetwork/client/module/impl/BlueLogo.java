package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Player Tags - everything that decorates a player's name.
 *
 * <p>Renamed from "Blue Logo" in v20, because it no longer controls just the
 * logo: it now also owns the profile <b>badges</b> (Founder, Helper, Tester,
 * …) drawn on in-world nametags.</p>
 *
 * <h2>Renaming a module is dangerous - this is handled</h2>
 * Saved configs and {@code BLUE1-} share codes are keyed by <b>display name</b>,
 * so a rename silently wipes user settings. {@code ConfigManager.renamedModule()}
 * maps {@code "Blue Logo" -> "Player Tags"} so existing configs keep working.
 * The Java class keeps its old name to avoid churning every call site.
 *
 * <h2>Badges: nametags only</h2>
 * Per the spec, badges appear on <b>in-world nametags only, never in the tab
 * list</b>. The tab list keeps the plain Blue Client logo. There are two
 * independent switches, because they answer different questions:
 * <ul>
 *   <li>{@link #showOwnBadge()} - "do I broadcast MY badge to other people?"
 *       This one is also mirrored to the backend ({@code settings.show_badge}),
 *       because hiding it must be enforced server-side - otherwise someone
 *       running a modified client could still read it.</li>
 *   <li>{@link #seeOtherBadges()} - "do I want to SEE other people's badges?"
 *       Purely local: it only decides whether we draw what we fetched.</li>
 * </ul>
 */
public class BlueLogo extends Module {

   private final BooleanSetting nametags = new BooleanSetting(
      "Nametags", "Show the Blue Client logo next to names in the world", true);

   private final BooleanSetting tabList = new BooleanSetting(
      "Tab list", "Show the Blue Client logo in the player list (Tab)", true);

   /*
    * v0.24.2 - owner: "in tab to the left side of your name, show the blue
    * client logo". The side lives HERE, on the module that owns the badge, so
    * both surfaces read the same value. Default = left.
    */
   private final BooleanSetting logoLeft = new BooleanSetting("Logo on left",
      "Put the badge BEFORE the name (tab list and nametags) instead of after it", true);

   /* ---- v20: profile badges (nametags only) ---------------------------- */

   private final BooleanSetting showBadges = new BooleanSetting("Show badges",
      "Draw profile badges (Founder, Helper, ...) on in-world nametags", true);

   private final BooleanSetting myBadgeToOthers = new BooleanSetting("Share my badge",
      "Let other players see YOUR equipped badge on your nametag", true);

   private final BooleanSetting otherBadges = new BooleanSetting("See others' badges",
      "Show other players' badges on their nametags", true);

   public BlueLogo() {
      super("Player Tags", "Logo and profile badges on nametags and the tab list", Category.MISC);
      this.addSettings(new Setting[] {
         this.nametags, this.tabList, this.logoLeft,
         this.showBadges, this.myBadgeToOthers, this.otherBadges
      });
      this.setEnabled(true);

      // Hiding your badge has to reach the SERVER to be real, so push the
      // change whenever it is toggled.
      this.myBadgeToOthers.onChange(() -> {
         try {
            net.bluenetwork.client.BlueClient.getInstance().friends()
               .pushBadgeVisibility(this.myBadgeToOthers.get(), this.otherBadges.get());
         } catch (Throwable ignored) {
            // Never let a settings toggle throw into the UI.
         }
      });
   }

   /**
    * True when the badge goes BEFORE the name.
    *
    * <p>Falls back to {@code true} (left) when the module cannot be found, so
    * the owner's requested default survives a config wipe.</p>
    */
   public static boolean logoOnLeft() {
      try {
         for (Module m : net.bluenetwork.client.BlueClient.getInstance().moduleManager().getModules()) {
            if (m instanceof BlueLogo logo) {
               return logo.logoLeft.get();
            }
         }
      } catch (Throwable ignored) {
      }
      return true;
   }

   /** True when the logo badge should be drawn on in-world nametags. */
   public static boolean showOnNametags() {
      return show(0);
   }

   /** True when the logo badge should be drawn in the tab list. */
   public static boolean showInTab() {
      return show(1);
   }

   /** True when profile badges should be drawn on nametags at all. */
   public static boolean showBadgesOnNametags() {
      return flag(0);
   }

   /** True when we broadcast our own badge to other players. */
   public static boolean showOwnBadge() {
      return flag(1);
   }

   /** True when we want to see other people's badges. */
   public static boolean seeOtherBadges() {
      return flag(2);
   }

   private static boolean flag(int which) {
      try {
         for (Module m : net.bluenetwork.client.BlueClient.getInstance().moduleManager().getModules()) {
            if (m instanceof BlueLogo tags && tags.isEnabled()) {
               return switch (which) {
                  case 0 -> tags.showBadges.get();
                  case 1 -> tags.myBadgeToOthers.get();
                  default -> tags.otherBadges.get();
               };
            }
         }
      } catch (Throwable ignored) {
      }
      return false;
   }

   private static boolean show(int surface) {
      try {
         for (Module m : net.bluenetwork.client.BlueClient.getInstance().moduleManager().getModules()) {
            if (m instanceof BlueLogo logo && logo.isEnabled()) {
               return surface == 0 ? logo.nametags.get() : logo.tabList.get();
            }
         }
      } catch (Throwable ignored) {
      }
      return false;
   }
}
