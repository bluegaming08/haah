package net.bluenetwork.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.render.state.GuiRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes DrawContext internals for Blue Client's custom GUI render elements.
 *
 * <p>Pure accessor interface (every method annotated): sponge-mixin demotes an
 * interface mixin with any un-annotated default method to a plain interface mixin,
 * which is only valid against interface targets. Lives in our own package - a
 * mixin config that claims a vanilla package (net.minecraft.client.gui.*) makes
 * the mixin transformer refuse to load ANY class in that package, including
 * vanilla classes themselves (IllegalClassLoadError "cannot be referenced directly").
 *
 * <p>For the active scissor rectangle use {@link net.bluenetwork.client.render.BlueScissors#current()}.
 */
@Mixin(DrawContext.class)
public interface BlueDrawContextAccessor {
    @Accessor("state")
    GuiRenderState blueclient$guiState();
}
