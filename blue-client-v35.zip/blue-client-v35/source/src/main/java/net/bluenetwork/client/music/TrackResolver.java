package net.bluenetwork.client.music;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Link resolver for the v3 Music Player (feedback 2026-09-11: "make it support
 * youtube, Spotify and other website links").
 *
 * <p>Supported inputs:</p>
 * <ul>
 *   <li><b>YouTube</b> (watch / youtu.be / shorts / music / embed): resolved
 *       through YouTube's own innertube API (iOS client - the same route
 *       yt-dlp uses), which returns a direct AAC (audio/mp4) stream URL plus
 *       title / author / length. Public Piped & Invidious instances are kept
 *       as fallbacks.</li>
 *   <li><b>Spotify</b> (track / album / playlist): track name, artist and
 *       duration from Spotify's public embed endpoints; audio from the best
 *       matching YouTube upload (Spotify's full audio is DRM-locked, so no
 *       client can stream it directly). When only a 30 s preview is
 *       reachable, that preview is played instead of nothing.</li>
 *   <li><b>Any other website link</b>: played directly when it points at an
 *       audio file (mp3 / ogg / wav / m4a / aac, by extension or HTTP
 *       Content-Type).</li>
 * </ul>
 *
 * <p>All network work happens on the caller's background thread; every
 * resolver failure throws {@link IOException} with a human-readable reason
 * that the module surfaces as a notification.</p>
 */
public final class TrackResolver {
   private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BlueClient/1.1";
   public static final String LYRICS_USER_AGENT = "blueclient-1.1 (https://play.sennahosting.com)";
   private static final int TIMEOUT_MS = 12000;

   /* innertube (iOS client) - returns cipher-free AAC stream URLs */
   private static final String INNERTUBE_PLAYER = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false";
   private static final String INNERTUBE_SEARCH = "https://www.youtube.com/youtubei/v1/search?prettyPrint=false";
   private static final String IOS_UA = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X)";
   private static final String IOS_BODY =
      "{\"context\":{\"client\":{\"clientName\":\"IOS\",\"clientVersion\":\"20.10.4\",\"deviceModel\":\"iPhone16,2\",\"hl\":\"en\"}},\"videoId\":\"%s\"}";
   private static final String VR_UA = "com.google.android.youtube/1.57.24 (Linux; U; Android 11; VR) gzip";
   private static final String VR_BODY =
      "{\"context\":{\"client\":{\"clientName\":\"ANDROID_VR\",\"clientVersion\":\"1.57.24\",\"deviceModel\":\"VR\",\"hl\":\"en\"}},\"videoId\":\"%s\"}";
   private static final String TV_UA = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version";
   private static final String TV_BODY =
      "{\"context\":{\"client\":{\"clientName\":\"TVHTML5_SIMPLY_EMBEDDED_PLAYER\",\"clientVersion\":\"2.0\",\"hl\":\"en\"},\"thirdParty\":{\"embedUrl\":\"https://www.youtube.com/watch?v=%s\"}},\"videoId\":\"%s\"}";
   private static final String IOS_SEARCH_BODY =
      "{\"context\":{\"client\":{\"clientName\":\"IOS\",\"clientVersion\":\"20.10.4\",\"deviceModel\":\"iPhone16,2\",\"hl\":\"en\"}},\"query\":\"%s\"}";

   private static final List<String> PIPED = List.of(
      "https://pipedapi.adminforge.de",
      "https://pipedapi.kavin.rocks",
      "https://pipedapi.reallyaweso.me",
      "https://api.piped.private.coffee");

   private static final List<String> INVIDIOUS = List.of(
      "https://yewtu.be",
      "https://inv.nadeko.net",
      "https://invidious.nerdvpn.de");

   /** A resolved, playable track. */
   public record Resolved(String title, String artist, int durationSec, String streamUrl, String format) {
      public String displayTitle() {
         if (this.artist == null || this.artist.isBlank()) {
            return this.title;
         }
         return this.title + " - " + this.artist;
      }
   }

   private TrackResolver() {
   }

   /* ------------------------------------------------------------ public */

   public static Resolved resolve(String input) throws IOException {
      String url = input.trim();
      if (url.isEmpty()) {
         throw new IOException("Set the Link setting first");
      }
      if (!url.contains("://")) {
         url = "https://" + url;
      }
      String lower = url.toLowerCase(Locale.ROOT);

      if (lower.contains("youtube.com") || lower.contains("youtu.be")) {
         String id = youtubeId(url);
         if (id == null) {
            throw new IOException("That YouTube link has no video id - paste the full link (the part after ?v=)");
         }
         return resolveYouTube(id, null, null);
      }
      if (lower.contains("spotify.com") || lower.contains("open.spotify")) {
         return resolveSpotify(url);
      }
      // Anything else: direct audio file (extension or content-type sniffed
      // by the caller's openAudio path).
      return new Resolved(fileName(url), "", 0, url, "direct");
   }

   /* ---------------------------------------------------------- youtube */

   public static String youtubeId(String url) {
      String u = url;
      int idx = u.indexOf("v=");
      if (idx >= 0 && u.contains("/watch")) {
         String id = u.substring(idx + 2);
         int amp = id.indexOf('&');
         return amp >= 0 ? id.substring(0, amp) : id;
      }
      for (String prefix : new String[]{"youtu.be/", "/shorts/", "/embed/", "/live/"}) {
         int p = u.indexOf(prefix);
         if (p >= 0) {
            String rest = u.substring(p + prefix.length());
            int slash = rest.indexOf('/');
            int query = rest.indexOf('?');
            int cut = slash >= 0 ? slash : rest.length();
            if (query >= 0) {
               cut = Math.min(cut, query);
            }
            String id = rest.substring(0, cut);
            if (!id.isEmpty()) {
               return id;
            }
         }
      }
      return null;
   }

   private static Resolved resolveYouTube(String id, String preferredTitle, String preferredArtist) throws IOException {
      IOException last = null;
      try {
         Resolved innertube = resolveYouTubeInnertube(id);
         if (preferredTitle != null && !preferredTitle.isBlank()) {
            return new Resolved(preferredTitle, preferredArtist == null ? innertube.artist() : preferredArtist,
               innertube.durationSec(), innertube.streamUrl(), innertube.format());
         }
         return innertube;
      } catch (IOException e) {
         last = e;
      }
      for (String base : PIPED) {
         try {
            JsonObject json = JsonParser.parseString(httpGet(base + "/streams/" + id)).getAsJsonObject();
            String title = str(json, "title");
            String artist = str(json, "uploader");
            int duration = json.has("duration") ? json.getAsJsonPrimitive("duration").getAsInt() : 0;
            String stream = pickPipedAudio(json);
            if (stream == null) {
               throw new IOException("Resolver returned no playable AAC audio stream");
            }
            return titled(preferredTitle, preferredArtist, title, artist, duration, stream);
         } catch (IOException e) {
            last = e;
         }
      }
      for (String base : INVIDIOUS) {
         try {
            JsonObject json = JsonParser.parseString(httpGet(base + "/api/v1/videos/" + id)).getAsJsonObject();
            String title = str(json, "title");
            String artist = str(json, "author");
            int duration = json.has("lengthSeconds") ? json.getAsJsonPrimitive("lengthSeconds").getAsInt() : 0;
            String stream = pickInvidiousAudio(json, base);
            if (stream == null) {
               throw new IOException("Resolver returned no playable AAC audio stream");
            }
            return titled(preferredTitle, preferredArtist, title, artist, duration, stream);
         } catch (IOException e) {
            last = e;
         }
      }
      if (last != null) {
         throw new IOException(last.getMessage() + " - YouTube may be bot-checking your network right now, try again in a minute or use a direct audio link");
      }
      throw new IOException("No resolver answered");
   }

   private static Resolved titled(String preferredTitle, String preferredArtist,
                                  String title, String artist, int duration, String stream) {
      return new Resolved(
         preferredTitle != null && !preferredTitle.isBlank() ? preferredTitle : title,
         preferredArtist != null && !preferredArtist.isBlank() ? preferredArtist : artist,
         duration, stream, "m4a");
   }

   /** YouTube's own innertube API (several client identities): cipher-free AAC URLs. */
   private static Resolved resolveYouTubeInnertube(String id) throws IOException {
      String[][] clients = new String[][]{
         {IOS_BODY.formatted(id), IOS_UA},
         {VR_BODY.formatted(id), VR_UA},
         {TV_BODY.formatted(id, id), TV_UA},
      };
      JsonObject json = null;
      String lastReason = "";
      for (String[] client : clients) {
         try {
            JsonObject candidate = JsonParser.parseString(httpPost(INNERTUBE_PLAYER, client[0], client[1])).getAsJsonObject();
            JsonObject st = candidate.has("playabilityStatus") ? candidate.getAsJsonObject("playabilityStatus") : null;
            String state = st != null ? str(st, "status") : "";
            if ("OK".equals(state)) {
               json = candidate;
               break;
            }
            lastReason = st != null ? str(st, "reason") : "";
         } catch (IOException e) {
            lastReason = e.getMessage();
         }
      }
      if (json == null) {
         throw new IOException(lastReason.isEmpty() ? "YouTube refused playback for this video" : lastReason);
      }
      JsonObject details = json.has("videoDetails") ? json.getAsJsonObject("videoDetails") : new JsonObject();
      String title = str(details, "title");
      String artist = str(details, "author");
      int duration = details.has("lengthSeconds") ? details.getAsJsonPrimitive("lengthSeconds").getAsInt() : 0;

      String stream = null;
      long bestRate = -1;
      if (json.has("streamingData")) {
         JsonObject streaming = json.getAsJsonObject("streamingData");
         for (String key : new String[]{"adaptiveFormats", "formats"}) {
            if (!streaming.has(key) || !streaming.get(key).isJsonArray()) {
               continue;
            }
            for (JsonElement element : streaming.getAsJsonArray(key)) {
               if (!element.isJsonObject()) {
                  continue;
               }
               JsonObject f = element.getAsJsonObject();
               String mime = str(f, "mimeType").toLowerCase(Locale.ROOT);
               if (!mime.startsWith("audio/mp4") && !mime.startsWith("audio/aac")) {
                  continue;
               }
               String url = str(f, "url");
               if (url.isEmpty()) {
                  continue; // signature-ciphered format: unusable without JS solving
               }
               long rate = f.has("bitrate") ? f.getAsJsonPrimitive("bitrate").getAsLong() : 0;
               if (rate > bestRate) {
                  bestRate = rate;
                  stream = url;
               }
            }
         }
      }
      if (stream == null) {
         throw new IOException("YouTube returned no cipher-free AAC stream (try a Piped-friendly video)");
      }
      return new Resolved(title, artist, duration, stream, "m4a");
   }

   /** YouTube search (innertube) -> first video id, used for Spotify matches. */
   public static String youtubeSearchFirstId(String query) {
      try {
         JsonObject json = JsonParser.parseString(
            httpPost(INNERTUBE_SEARCH, IOS_SEARCH_BODY.formatted(jsonEscape(query)), IOS_UA)).getAsJsonObject();
         List<String> ids = new java.util.ArrayList<>();
         collectVideoIds(json, ids);
         return ids.isEmpty() ? null : ids.get(0);
      } catch (Throwable t) {
         return null;
      }
   }

   private static void collectVideoIds(JsonElement node, List<String> out) {
      if (node == null || out.size() > 5) {
         return;
      }
      if (node.isJsonObject()) {
         JsonObject object = node.getAsJsonObject();
         if (object.has("videoId") && object.get("videoId").isJsonPrimitive()) {
            out.add(object.getAsJsonPrimitive("videoId").getAsString());
         }
         for (String key : object.keySet()) {
            collectVideoIds(object.get(key), out);
         }
      } else if (node.isJsonArray()) {
         for (JsonElement element : node.getAsJsonArray()) {
            collectVideoIds(element, out);
         }
      }
   }

   private static String pickPipedAudio(JsonObject json) {
      if (!json.has("audioStreams") || !json.get("audioStreams").isJsonArray()) {
         return null;
      }
      JsonArray streams = json.getAsJsonArray("audioStreams");
      String best = null;
      long bestRate = -1;
      for (JsonElement element : streams) {
         if (!element.isJsonObject()) {
            continue;
         }
         JsonObject s = element.getAsJsonObject();
         String mime = str(s, "mimeType").toLowerCase(Locale.ROOT);
         if (!mime.contains("audio/mp4") && !mime.contains("audio/aac") && !mime.contains("audio/m4a")) {
            continue;
         }
         long rate = s.has("bitrate") ? s.getAsJsonPrimitive("bitrate").getAsLong() : 0;
         String url = str(s, "url");
         if (!url.isEmpty() && rate > bestRate) {
            best = url;
            bestRate = rate;
         }
      }
      return best;
   }

   private static String pickInvidiousAudio(JsonObject json, String base) {
      if (!json.has("adaptiveFormats") || !json.get("adaptiveFormats").isJsonArray()) {
         return null;
      }
      JsonArray formats = json.getAsJsonArray("adaptiveFormats");
      String best = null;
      long bestRate = -1;
      for (JsonElement element : formats) {
         if (!element.isJsonObject()) {
            continue;
         }
         JsonObject f = element.getAsJsonObject();
         String type = str(f, "type").toLowerCase(Locale.ROOT);
         if (!type.startsWith("audio/mp4") && !type.startsWith("audio/aac")) {
            continue;
         }
         String url = str(f, "url");
         if (url.isEmpty()) {
            continue; // instance doesn't proxy streams
         }
         if (url.startsWith("/")) {
            url = base + url;
         }
         long rate = f.has("bitrate") ? f.getAsJsonPrimitive("bitrate").getAsLong() : 0;
         if (rate > bestRate) {
            best = url;
            bestRate = rate;
         }
      }
      return best;
   }

   /* ---------------------------------------------------------- spotify */

   private static Resolved resolveSpotify(String url) throws IOException {
      String type = "track";
      String id = null;
      String[] parts = URI.create(url).getPath().split("/");
      for (int i = 0; i + 1 < parts.length; i++) {
         if (parts[i].equals("track") || parts[i].equals("album") || parts[i].equals("playlist")) {
            type = parts[i];
            id = parts[i + 1].split("\\?")[0];
         }
      }
      if (id == null) {
         throw new IOException("Couldn't read a Spotify track id from that link");
      }

      String title = "";
      String artist = "";
      int durationSec = 0;
      String preview = "";

      // 1) oEmbed (when Spotify serves it)
      try {
         JsonObject meta = JsonParser.parseString(httpGet("https://open.spotify.com/oembed?url=" + urlEncode(url))).getAsJsonObject();
         String combined = str(meta, "title");
         int dash = combined.lastIndexOf(" - ");
         if (dash > 0) {
            title = combined.substring(0, dash).trim();
            artist = combined.substring(dash + 3).trim();
         } else {
            title = combined;
         }
      } catch (IOException ignored) {
         // try next source
      }
      // 2) embed page JSON / meta tags
      if (title.isEmpty()) {
         try {
            String html = httpGet("https://open.spotify.com/embed/" + type + "/" + id);
            int start = html.indexOf("<script id=\"embedded-state\" type=\"application/json\">");
            if (start >= 0) {
               int from = start + "<script id=\"embedded-state\" type=\"application/json\">".length();
               int end = html.indexOf("</script>", from);
               JsonObject state = JsonParser.parseString(html.substring(from, end)).getAsJsonObject();
               title = str(state, "name");
               if (state.has("artists") && state.get("artists").isJsonArray() && !state.getAsJsonArray("artists").isEmpty()) {
                  artist = str(state.getAsJsonArray("artists").get(0).getAsJsonObject(), "name");
               }
               if (state.has("duration") && state.get("duration").isJsonPrimitive()) {
                  durationSec = state.getAsJsonPrimitive("duration").getAsInt() / 1000;
               }
            } else {
               int og = html.indexOf("og:title\" content=\"");
               if (og >= 0) {
                  int from = og + "og:title\" content=\"".length();
                  int end = html.indexOf('"', from);
                  String combined = html.substring(from, end);
                  int dash = combined.lastIndexOf(" - ");
                  if (dash > 0) {
                     title = combined.substring(0, dash).trim();
                     artist = combined.substring(dash + 3).trim();
                  } else {
                     title = combined;
                  }
               }
            }
         } catch (IOException ignored) {
            // try next source
         }
      }
      // 3) embed player token + public web API (also yields a 30s preview)
      if (durationSec <= 0) {
         try {
            JsonObject token = JsonParser.parseString(httpGet(
               "https://open.spotify.com/get_access_token?reason=transport&productType=embedded_player")).getAsJsonObject();
            String accessToken = str(token, "accessToken");
            if (!accessToken.isEmpty()) {
               JsonObject track = jsonGetAuthed("https://api.spotify.com/v1/" + type + "s/" + id, accessToken);
               if (track != null) {
                  title = str(track, "name");
                  if (track.has("artists") && track.get("artists").isJsonArray() && !track.getAsJsonArray("artists").isEmpty()) {
                     artist = str(track.getAsJsonArray("artists").get(0).getAsJsonObject(), "name");
                  }
                  if (track.has("duration_ms")) {
                     durationSec = track.getAsJsonPrimitive("duration_ms").getAsInt() / 1000;
                  }
                  if (track.has("preview_url") && !track.get("preview_url").isJsonNull()) {
                     preview = str(track, "preview_url");
                  }
               }
            }
         } catch (IOException ignored) {
            // metadata stays empty -> error below
         }
      }
      if (title.isEmpty()) {
         throw new IOException("Spotify didn't share metadata for that link from your network - try a YouTube or direct link");
      }

      // Full audio: best matching upload on YouTube.
      String matchId = youtubeSearchFirstId(title + " " + artist);
      if (matchId != null) {
         try {
            return resolveYouTube(matchId, title, artist);
         } catch (IOException ignored) {
            // fall through to the preview
         }
      }
      if (!preview.isEmpty()) {
         return new Resolved(title, artist, durationSec, preview, "m4a");
      }
      throw new IOException("Found the Spotify track but no playable audio match");
   }

   private static JsonObject jsonGetAuthed(String url, String bearer) {
      try {
         HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
         connection.setRequestProperty("User-Agent", USER_AGENT);
         connection.setRequestProperty("Authorization", "Bearer " + bearer);
         connection.setConnectTimeout(TIMEOUT_MS);
         connection.setReadTimeout(TIMEOUT_MS);
         try {
            if (connection.getResponseCode() / 100 != 2) {
               return null;
            }
            try (InputStream in = connection.getInputStream()) {
               return JsonParser.parseString(new String(in.readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();
            }
         } finally {
            connection.disconnect();
         }
      } catch (Throwable t) {
         return null;
      }
   }

   /* ------------------------------------------------------------ http */

   public static String httpGet(String url) throws IOException {
      return httpGetWithAgent(url, USER_AGENT);
   }

   public static String httpGetWithAgent(String url, String agent) throws IOException {
      HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
      connection.setRequestProperty("User-Agent", agent);
      connection.setRequestProperty("Accept", "application/json,*/*");
      connection.setInstanceFollowRedirects(true);
      connection.setConnectTimeout(TIMEOUT_MS);
      connection.setReadTimeout(TIMEOUT_MS);
      try {
         int code = connection.getResponseCode();
         if (code / 100 != 2) {
            throw new IOException("HTTP " + code + " from " + connection.getURL().getHost());
         }
         try (InputStream in = connection.getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
         }
      } finally {
         connection.disconnect();
      }
   }

   private static String httpPost(String url, String body, String agent) throws IOException {
      HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
      connection.setRequestMethod("POST");
      connection.setRequestProperty("User-Agent", agent);
      connection.setRequestProperty("Content-Type", "application/json");
      connection.setInstanceFollowRedirects(true);
      connection.setConnectTimeout(TIMEOUT_MS);
      connection.setReadTimeout(TIMEOUT_MS);
      connection.setDoOutput(true);
      try {
         try (OutputStream out = connection.getOutputStream()) {
            out.write(body.getBytes(StandardCharsets.UTF_8));
         }
         int code = connection.getResponseCode();
         if (code / 100 != 2) {
            throw new IOException("HTTP " + code + " from " + connection.getURL().getHost());
         }
         try (InputStream in = connection.getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
         }
      } finally {
         connection.disconnect();
      }
   }

   private static String str(JsonObject object, String member) {
      if (object != null && object.has(member) && object.get(member).isJsonPrimitive()) {
         return object.getAsJsonPrimitive(member).getAsString();
      }
      return "";
   }

   private static String jsonEscape(String value) {
      return value.replace("\\", "\\\\").replace("\"", "\\\"");
   }

   private static String urlEncode(String value) {
      return java.net.URLEncoder.encode(value, StandardCharsets.UTF_8);
   }

   private static String fileName(String url) {
      String path = URI.create(url).getPath();
      if (path == null || path.isEmpty()) {
         path = url;
      }
      int slash = path.lastIndexOf('/');
      String name = slash >= 0 ? path.substring(slash + 1) : path;
      int dot = name.lastIndexOf('.');
      if (dot > 0) {
         name = name.substring(0, dot);
      }
      try {
         name = URLDecoder.decode(name, StandardCharsets.UTF_8);
      } catch (Throwable ignored) {
      }
      return name.isBlank() ? "Track" : name;
   }
}
