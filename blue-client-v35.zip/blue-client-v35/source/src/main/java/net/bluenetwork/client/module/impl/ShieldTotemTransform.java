package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Repositions the first-person shield and totem.
 *
 * <h2>What it does</h2>
 * Offsets and scales the held shield and the held totem independently, on all
 * three axes. This is a cosmetic first-person transform of the player's OWN
 * view: it changes where the model is drawn on your screen and nothing else.
 *
 * <h2>Why it is not anticheat-flaggable</h2>
 * The transform is applied inside the client's own rendering of your held
 * item. It sends no packets, changes no hitbox, alters no reach, and is not
 * visible to the server or to other players. It is the same class of change as
 * moving a HUD element.
 *
 * <h2>Defaults</h2>
 * All offsets default to 0 and scale to 1, so installing the module changes
 * nothing until the player deliberately moves something. A module that
 * silently alters your view on first launch is a bug, not a feature.
 */
public class ShieldTotemTransform extends Module {

   /* ---- shield ---- */
   private final BooleanSetting shieldEnabled = new BooleanSetting("Shield",
      "Apply the transform to held shields", true);
   private final NumberSetting shieldX = new NumberSetting("Shield X",
      "Left / right offset", 0.0, -1.0, 1.0, 0.01);
   private final NumberSetting shieldY = new NumberSetting("Shield Y",
      "Up / down offset", 0.0, -1.0, 1.0, 0.01);
   private final NumberSetting shieldZ = new NumberSetting("Shield Z",
      "Forward / back offset", 0.0, -1.0, 1.0, 0.01);
   private final NumberSetting shieldScale = new NumberSetting("Shield Scale",
      "Size multiplier", 1.0, 0.25, 3.0, 0.01);

   /* ---- totem ---- */
   private final BooleanSetting totemEnabled = new BooleanSetting("Totem",
      "Apply the transform to held totems", true);
   private final NumberSetting totemX = new NumberSetting("Totem X",
      "Left / right offset", 0.0, -1.0, 1.0, 0.01);
   private final NumberSetting totemY = new NumberSetting("Totem Y",
      "Up / down offset", 0.0, -1.0, 1.0, 0.01);
   private final NumberSetting totemZ = new NumberSetting("Totem Z",
      "Forward / back offset", 0.0, -1.0, 1.0, 0.01);
   private final NumberSetting totemScale = new NumberSetting("Totem Scale",
      "Size multiplier", 1.0, 0.25, 3.0, 0.01);

   private static ShieldTotemTransform instance;

   public ShieldTotemTransform() {
      super("Shield & Totem", "Reposition and resize the held shield and totem",
         Category.RENDER);
      this.addSettings(new Setting[]{
         this.shieldEnabled, this.shieldX, this.shieldY, this.shieldZ,
         this.shieldScale,
         this.totemEnabled, this.totemX, this.totemY, this.totemZ,
         this.totemScale});

      // Hide the axis sliders when that half is switched off, so the settings
      // list stays readable instead of showing ten always-on numbers.
      this.shieldX.visibleWhen(this.shieldEnabled::get);
      this.shieldY.visibleWhen(this.shieldEnabled::get);
      this.shieldZ.visibleWhen(this.shieldEnabled::get);
      this.shieldScale.visibleWhen(this.shieldEnabled::get);
      this.totemX.visibleWhen(this.totemEnabled::get);
      this.totemY.visibleWhen(this.totemEnabled::get);
      this.totemZ.visibleWhen(this.totemEnabled::get);
      this.totemScale.visibleWhen(this.totemEnabled::get);

      instance = this;
   }

   /** The live instance, or null before registration. */
   public static ShieldTotemTransform get() {
      return instance;
   }

   /** True when this module should transform the given stack. */
   public static boolean handles(net.minecraft.item.ItemStack stack) {
      ShieldTotemTransform m = instance;
      if (m == null || !m.isEnabled() || stack == null || stack.isEmpty()) {
         return false;
      }
      return (m.shieldEnabled.get() && isShield(stack))
         || (m.totemEnabled.get() && isTotem(stack));
   }

   private static boolean isShield(net.minecraft.item.ItemStack stack) {
      return stack.getItem() == net.minecraft.item.Items.SHIELD;
   }

   private static boolean isTotem(net.minecraft.item.ItemStack stack) {
      return stack.getItem() == net.minecraft.item.Items.TOTEM_OF_UNDYING;
   }

   /** Offsets for a stack: {x, y, z}. Zeroes when it does not apply. */
   public static float[] offsetFor(net.minecraft.item.ItemStack stack) {
      ShieldTotemTransform m = instance;
      if (m == null || !m.isEnabled() || stack == null) {
         return ZERO;
      }
      if (m.shieldEnabled.get() && isShield(stack)) {
         return new float[]{m.shieldX.getFloat(), m.shieldY.getFloat(),
            m.shieldZ.getFloat()};
      }
      if (m.totemEnabled.get() && isTotem(stack)) {
         return new float[]{m.totemX.getFloat(), m.totemY.getFloat(),
            m.totemZ.getFloat()};
      }
      return ZERO;
   }

   /** Scale multiplier for a stack, or 1 when it does not apply. */
   public static float scaleFor(net.minecraft.item.ItemStack stack) {
      ShieldTotemTransform m = instance;
      if (m == null || !m.isEnabled() || stack == null) {
         return 1.0F;
      }
      if (m.shieldEnabled.get() && isShield(stack)) {
         return m.shieldScale.getFloat();
      }
      if (m.totemEnabled.get() && isTotem(stack)) {
         return m.totemScale.getFloat();
      }
      return 1.0F;
   }

   private static final float[] ZERO = {0.0F, 0.0F, 0.0F};
}
