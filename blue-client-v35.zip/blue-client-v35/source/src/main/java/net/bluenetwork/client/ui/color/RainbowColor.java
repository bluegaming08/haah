package net.bluenetwork.client.ui.color;

/**
 * Shared rainbow colour math for the v2 colour system (plan §3.2 / §4.2).
 * Pure functions — no state, no allocations, callable from the render thread.
 *
 * <p>Every colour setting owns its own {@code speed} (cycles per second) and
 * {@code offset} (0..1 phase), so e.g. Keystrokes can cycle fast while the CPS
 * counter stays slow (owner decision #6). The heavy per-frame work stays in
 * each caller — typically one call per colour target per frame, which is far
 * below any measurable cost.</p>
 */
public final class RainbowColor {
   private RainbowColor() {
   }

   /** Wraps a moving hue phase into 0..1. */
   public static float hue01(long timeMs, float cyclesPerSecond, float offset) {
      double t = (double) timeMs / 1000.0D * cyclesPerSecond + offset;
      double wrapped = t - Math.floor(t);
      return (float) wrapped;
   }

   /** Full-brightness colour for a 0..1 hue, packed as 0xRRGGBB. */
   public static int rgb(float hue01) {
      return hsvToRgb(hue01, 1.0F, 1.0F) & 0xFFFFFF;
   }

   /** Convenience: current full-brightness colour at the given phase settings. */
   public static int rgb(long timeMs, float cyclesPerSecond, float offset) {
      return rgb(hue01(timeMs, cyclesPerSecond, offset));
   }

   /** Rainbow colour with an explicit alpha 0..255, packed as 0xAARRGGBB. */
   public static int argb(long timeMs, float cyclesPerSecond, float offset, int alpha) {
      int a = Math.max(0, Math.min(255, alpha));
      return a << 24 | rgb(timeMs, cyclesPerSecond, offset) & 0xFFFFFF;
   }

   /** Standard HSV → RGB. h in 0..1, s/v in 0..1. Result is 0xRRGGBB. */
   public static int hsvToRgb(float h, float s, float v) {
      float hh = h - (float) Math.floor(h);
      int i = (int) (hh * 6.0F);
      float f = hh * 6.0F - i;
      float p = v * (1.0F - s);
      float q = v * (1.0F - f * s);
      float t = v * (1.0F - (1.0F - f) * s);
      float r;
      float g;
      float b;
      switch (i % 6) {
         case 0 -> {
            r = v;
            g = t;
            b = p;
         }
         case 1 -> {
            r = q;
            g = v;
            b = p;
         }
         case 2 -> {
            r = p;
            g = v;
            b = t;
         }
         case 3 -> {
            r = p;
            g = q;
            b = v;
         }
         case 4 -> {
            r = t;
            g = p;
            b = v;
         }
         default -> {
            r = v;
            g = p;
            b = q;
         }
      }
      int ri = (int) (r * 255.0F + 0.5F);
      int gi = (int) (g * 255.0F + 0.5F);
      int bi = (int) (b * 255.0F + 0.5F);
      return ri << 16 | gi << 8 | bi;
   }

   /** Overlays an alpha on an existing 0xRRGGBB / 0xAARRGGBB colour. */
   public static int withAlpha(int argbOrRgb, int alpha) {
      int a = Math.max(0, Math.min(255, alpha));
      return a << 24 | argbOrRgb & 0xFFFFFF;
   }
}
