package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Moon Phase (bonus HUD) — the current moon phase as a short label, handy for
 * slime-farming and general world-time awareness.
 */
public class MoonPhase extends HudModule {
   private static final String[] PHASES = {
      "Full Moon", "Waning Gibbous", "Third Quarter", "Waning Crescent",
      "New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous"
   };
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);

   public MoonPhase() {
      super("Moon Phase", "Current moon phase (slime farming)", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_RIGHT, 6, 132);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null) {
         return "Moon --";
      }
      int phase = (int) ((mc.world.getTimeOfDay() / 24000L) % 8L);
      return PHASES[phase];
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Waning Crescent") + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
