package net.bluenetwork.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.bluenetwork.client.BlueClient;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Shows enchantment levels as numbers: "Unbreaking 3", not "Unbreaking III".
 *
 * <h2>Where the hook goes</h2>
 * {@code Enchantment.getName(entry, level)} is the single place the game turns
 * a level into a label, for tooltips, the enchanting table and anvil alike.
 * Hooking it once covers every surface instead of chasing each screen.
 *
 * <p>Vanilla builds the level text by looking up the translation key
 * {@code enchantment.level.<n>}, which resolves to a Roman numeral for 1-10.
 * This replaces the result of that lookup with the plain number.</p>
 *
 * <h2>Why levels above 10 already worked</h2>
 * Vanilla only ships {@code enchantment.level.1} through {@code .10}; anything
 * higher already falls back to the raw digits. So this only changes the range
 * that actually had Roman numerals, and a level-30 book looked the same
 * before and after.
 *
 * <p>{@code require = 0}: if the mapping moves, the setting silently stops
 * working rather than crashing the game.</p>
 */
@Mixin(Enchantment.class)
public abstract class EnchantmentLevelMixin {

   @ModifyExpressionValue(
      method = "getName",
      at = @At(value = "INVOKE",
         target = "Lnet/minecraft/text/Text;translatable(Ljava/lang/String;)Lnet/minecraft/text/MutableText;"),
      require = 0)
   private static MutableText blueclient$arabicLevel(MutableText original) {
      try {
         BlueClient client = BlueClient.getInstance();
         if (client == null || client.settings() == null
            || !client.settings().arabicEnchantLevels()) {
            return original;
         }
         String key = translationKey(original);
         if (key == null || !key.startsWith("enchantment.level.")) {
            // getName also translates the enchantment's own name; only the
            // level component should change.
            return original;
         }
         String digits = key.substring("enchantment.level.".length());
         return Text.literal(digits);   // literal() also returns MutableText
      } catch (Throwable t) {
         // A tooltip is never worth a crash.
         return original;
      }
   }

   /** The translation key behind a Text, or null when it is not translatable. */
   private static String translationKey(MutableText text) {
      if (text == null) {
         return null;
      }
      return text.getContent() instanceof net.minecraft.text.TranslatableTextContent tc
         ? tc.getKey() : null;
   }
}
