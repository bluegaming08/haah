package net.bluenetwork.client.ui;

import java.util.HashMap;
import java.util.Map;

/**
 * Tiny frame-rate-independent animation helper.
 *
 * <h2>Why this exists</h2>
 * Owner: "the GUI doesn't feel premium - the account manager does." The
 * difference is motion. The account manager eases its hovers; the Social
 * screen snapped instantly between states, which reads as cheap no matter how
 * good the colours are.
 *
 * <h2>How to use it</h2>
 * Call {@link #to(String, boolean)} every frame with a stable key and the
 * target state; it returns a 0..1 value that glides toward it:
 *
 * <pre>{@code
 * float t = Anim.to("row:" + id, hovered);
 * SmoothRect.fill(ctx, x, y, w, h, 4, lerpColor(base, hot, t));
 * }</pre>
 *
 * <h2>Frame-rate independence</h2>
 * The step is derived from elapsed milliseconds, not from a fixed per-frame
 * increment, so an animation takes the same wall-clock time at 30 fps and at
 * 240 fps. A fixed increment would make the whole UI run at double speed on a
 * fast machine - a classic and very visible bug.
 */
public final class Anim {

   /** Milliseconds for a value to travel the full 0..1 range. */
   private static final float DEFAULT_MS = 160.0F;

   private record State(float value, long at) {
   }

   private static final Map<String, State> STATES = new HashMap<>();

   private Anim() {
   }

   /** Eases toward 1 when {@code on}, toward 0 otherwise. */
   public static float to(String key, boolean on) {
      return to(key, on ? 1.0F : 0.0F, DEFAULT_MS);
   }

   /** Eases toward an arbitrary target over {@code durationMs}. */
   public static float to(String key, float target, float durationMs) {
      long now = System.currentTimeMillis();
      State s = STATES.get(key);
      if (s == null) {
         // First sight of this key: start AT the target rather than at zero,
         // or every row would animate in whenever the list is rebuilt.
         STATES.put(key, new State(target, now));
         return target;
      }

      float dt = Math.min(100.0F, now - s.at());
      float step = dt / Math.max(1.0F, durationMs);
      float v = s.value();

      if (v < target) {
         v = Math.min(target, v + step);
      } else if (v > target) {
         v = Math.max(target, v - step);
      }

      STATES.put(key, new State(v, now));
      return v;
   }

   /**
    * A 0..1 progress that starts when {@code key} is first seen and runs once.
    * Used for screen-open and row-stagger entrances.
    */
   public static float once(String key, float durationMs) {
      long now = System.currentTimeMillis();
      State s = STATES.get(key);
      if (s == null) {
         STATES.put(key, new State(0.0F, now));
         return 0.0F;
      }
      float t = Math.min(1.0F, (now - s.at()) / Math.max(1.0F, durationMs));
      return t;
   }

   /** Forgets a one-shot so it plays again - call when a screen opens. */
   public static void reset(String key) {
      STATES.remove(key);
   }

   /** Forgets every key that starts with {@code prefix}. */
   public static void resetPrefix(String prefix) {
      STATES.keySet().removeIf(k -> k.startsWith(prefix));
   }

   /** Decelerating ease - fast out of the gate, gentle at the end. */
   public static float easeOut(float t) {
      float c = clamp(t);
      return 1.0F - (1.0F - c) * (1.0F - c) * (1.0F - c);
   }

   /** Symmetric ease, for things that move and stop. */
   public static float easeInOut(float t) {
      float c = clamp(t);
      return c < 0.5F
         ? 4.0F * c * c * c
         : 1.0F - (float) Math.pow(-2.0F * c + 2.0F, 3) / 2.0F;
   }

   /** Slight overshoot, for a control that should feel springy. */
   public static float easeBack(float t) {
      float c = clamp(t);
      float s = 1.70158F;
      float p = c - 1.0F;
      return p * p * ((s + 1.0F) * p + s) + 1.0F;
   }

   /** Linear blend between two floats. */
   public static float mix(float a, float b, float t) {
      return a + (b - a) * clamp(t);
   }

   /** Blends two ARGB colours, channel by channel including alpha. */
   public static int mixColor(int a, int b, float t) {
      float c = clamp(t);
      int aa = (a >>> 24) & 0xFF;
      int ar = (a >>> 16) & 0xFF;
      int ag = (a >>> 8) & 0xFF;
      int ab = a & 0xFF;
      int ba = (b >>> 24) & 0xFF;
      int br = (b >>> 16) & 0xFF;
      int bg = (b >>> 8) & 0xFF;
      int bb = b & 0xFF;
      int ra = Math.round(aa + (ba - aa) * c);
      int rr = Math.round(ar + (br - ar) * c);
      int rg = Math.round(ag + (bg - ag) * c);
      int rb = Math.round(ab + (bb - ab) * c);
      return (ra << 24) | (rr << 16) | (rg << 8) | rb;
   }

   private static float clamp(float t) {
      return t < 0.0F ? 0.0F : (t > 1.0F ? 1.0F : t);
   }
}
