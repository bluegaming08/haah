package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class DirectionHud extends HudModule {
   private static final String[] DIRECTIONS = new String[]{"South", "South West", "West", "North West", "North", "North East", "East", "South East"};

   public DirectionHud() {
      super("Direction", "Shows which way you are facing.", Category.HUD, 4, 240);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         double yaw = (mc.player.getYaw() % 360.0F + 360.0F) % 360.0F;
         int sector = (int)(Math.round(yaw / 45.0) % 8L);
         String text = "Dir: " + DIRECTIONS[sector] + " (" + (int)yaw + "°)";
         this.drawTextPanel(context, text);
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Dir: South East (360°)") + 12 + 2;
   }
}
