package net.bluenetwork.client.brand;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.StyleSpriteSource.Font;
import net.minecraft.util.Identifier;

public final class BlueBrand {
   public static final String BLUE_NETWORK_NAME = "Blue Network";
   public static final String BLUE_NETWORK_ADDRESS = "play.sennahosting.com";
   public static final Identifier LOGO_TEXTURE = Identifier.of("blueclient", "logo.png");
   public static final Identifier ICON_FONT = Identifier.of("blueclient", "blueicons");
   public static final String ICON_GLYPH = "\ue001";

   private BlueBrand() {
   }

   public static boolean isBlueNetwork(String address) {
      if (address != null && !address.isBlank()) {
         String host = address;
         int colon = address.lastIndexOf(58);
         if (colon > 0 && address.indexOf(93) < colon) {
            host = address.substring(0, colon);
         }

         return "play.sennahosting.com".equalsIgnoreCase(host) || "play.sennahosting.com".equalsIgnoreCase(address);
      } else {
         return false;
      }
   }

   public static MutableText withIcon(Text name) {
      // v0.16.13: badge sits BEHIND (after) the name. The glyph
      // is registered in the DEFAULT font (assets/minecraft/font/default.json
      // override), so no per-text font styling is needed anymore - that also
      // fixes tab/nametag badges not rendering when the custom font file
      // failed to load.
      return name.copy().append(Text.literal(" ")).append(Text.literal("\ue001"));
   }

   /** v0.19.0: badge IN FRONT of the name (Nametags "logo on the left side"). */
   public static MutableText withIconLeft(Text name) {
      return Text.literal("\ue001").append(Text.literal(" ")).append(name.copy());
   }

   public static boolean modMenuInstalled() {
      return FabricLoader.getInstance().isModLoaded("modmenu");
   }

   public static Screen openModMenu(Screen parent) {
      return openScreenReflectively("com.terraformersmc.modmenu.gui.ModsScreen", parent);
   }

   public static boolean flashbackInstalled() {
      return FabricLoader.getInstance().isModLoaded("flashback");
   }

   public static Screen openFlashback(Screen parent) {
      return openScreenReflectively(
         "com.moulberry.flashback.screen.select_replay.SelectReplayScreen", parent, "com.moulberry.flashback.screen.RecoverRecordingsScreen", parent
      );
   }

   private static Screen openScreenReflectively(Object... classAndParent) {
      for (int i = 0; i + 1 < classAndParent.length; i += 2) {
         String className = (String)classAndParent[i];
         Screen parent = (Screen)classAndParent[i + 1];

         try {
            Class<?> clazz = Class.forName(className);

            try {
               return (Screen)clazz.getConstructor(Screen.class).newInstance(parent);
            } catch (NoSuchMethodException var6) {
               return (Screen)clazz.getConstructor().newInstance();
            }
         } catch (Throwable var7) {
         }
      }

      return null;
   }
}
