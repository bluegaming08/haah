package net.bluenetwork.client.ui;

import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.social.NameColor;
import net.bluenetwork.client.ui.text.TextPainter;
import net.minecraft.client.gui.DrawContext;

/**
 * Editable state for one colour setting, shared by the name colour and the
 * profile background colour.
 *
 * <h2>Why this is a separate class</h2>
 * The owner asked for hex entry and two gradient directions on <i>both</i>
 * settings. Duplicating a picker twice guarantees the two drift apart - one
 * grows a feature, the other quietly does not. This holds the state and the
 * drawing for a single picker; the screen owns two instances.
 *
 * <h2>Validation</h2>
 * Hex is validated here for instant feedback, and <b>again on the server</b>
 * by {@code set_name_color} / {@code set_profile_color}, which accept nothing
 * but {@code ^#[0-9A-Fa-f]{6}$}. The client check is a courtesy; the server
 * check is the one that matters, because this data is rendered on other
 * players' machines.
 */
public final class ColorStudio {

   /** Preset swatches. Deliberately small - a wall of colours is worse UX. */
   public static final int[] PALETTE = {
      0xFF1D9BF0, 0xFF00BA7C, 0xFFF91880, 0xFFFFD400, 0xFFFF7A00,
      0xFF7856FF, 0xFF00D1C1, 0xFFFF4545, 0xFFE7E9EA, 0xFF8A94A6};

   /** Primary / gradient-start colour. */
   public int primary = 0xFF1D9BF0;
   /** Gradient end colour. */
   public int secondary = 0xFFF91880;
   /** {@link NameColor#GRAD_NONE}, {@code GRAD_HORIZONTAL}, {@code GRAD_VERTICAL}. */
   public int gradType = NameColor.GRAD_NONE;
   public boolean bold;
   public boolean italic;

   /** Which endpoint the swatches and the hex box currently edit. */
   public boolean editingSecondary;

   /** Live text in the hex field. Not necessarily valid yet. */
   public String hexDraft = "";
   /** Set once the saved value has been loaded into this draft. */
   public boolean loaded;

   private final boolean supportsTextStyle;

   /**
    * @param supportsTextStyle true for the name colour (bold / italic apply to
    *                          text); false for a background, where they are
    *                          meaningless
    */
   public ColorStudio(boolean supportsTextStyle) {
      this.supportsTextStyle = supportsTextStyle;
   }

   /** Loads a saved JSON value into this draft, once. */
   public void loadFrom(String json) {
      if (this.loaded) {
         return;
      }
      this.loaded = true;
      if (json == null || json.isBlank()) {
         return;
      }
      NameColor.Spec cur = NameColor.parse(json, 0xFF1D9BF0);
      this.primary = cur.primary();
      this.secondary = cur.secondary();
      this.gradType = cur.gradType();
      this.bold = cur.bold();
      this.italic = cur.italic();
   }

   /** Forces the next {@link #loadFrom} to re-read - call after a save. */
   public void invalidate() {
      this.loaded = false;
   }

   /** The JSON to send to the server. */
   public String toJson() {
      return NameColor.toJson(this.primary,
         this.gradType == NameColor.GRAD_NONE ? null : this.secondary,
         this.gradType, this.bold, this.italic);
   }

   /** A Spec for previewing, without a server round trip. */
   public NameColor.Spec spec() {
      return NameColor.parse(toJson(), 0xFF1D9BF0);
   }

   /** The colour currently being edited. */
   public int active() {
      return this.editingSecondary ? this.secondary : this.primary;
   }

   /** Sets the colour currently being edited. */
   public void setActive(int argb) {
      if (this.editingSecondary) {
         this.secondary = argb;
      } else {
         this.primary = argb;
      }
      this.hexDraft = hexOf(argb);
   }

   /** "#RRGGBB" for an ARGB int. */
   public static String hexOf(int argb) {
      return String.format("#%06X", argb & 0xFFFFFF);
   }

   /**
    * Parses a typed hex value.
    *
    * <p>Accepts with or without the leading {@code #}, and accepts 3-digit
    * shorthand ({@code #0af}) because people type it. Returns 0 when the text
    * is not yet a complete colour.</p>
    */
   public static int parseHex(String text) {
      if (text == null) {
         return 0;
      }
      String t = text.trim();
      if (t.startsWith("#")) {
         t = t.substring(1);
      }
      if (t.length() == 3) {
         // #abc -> #aabbcc
         StringBuilder sb = new StringBuilder();
         for (char c : t.toCharArray()) {
            sb.append(c).append(c);
         }
         t = sb.toString();
      }
      if (t.length() != 6 || !t.matches("[0-9A-Fa-f]{6}")) {
         return 0;
      }
      try {
         return 0xFF000000 | Integer.parseInt(t, 16);
      } catch (NumberFormatException bad) {
         return 0;
      }
   }

   /* ====================================================================== */
   /*  Drawing                                                               */
   /* ====================================================================== */

   /** A hit box emitted by {@link #draw}. */
   public record Hit(float x, float y, float w, float h, String tag) {
   }

   /**
    * Draws the picker and appends its hit boxes to {@code out}.
    *
    * @param prefix tag prefix so two studios on one screen never collide
    * @return the y coordinate just below the picker
    */
   public float draw(DrawContext ctx, float x, float y, float w,
                     int mx, int my, String prefix, boolean hexFocused,
                     java.util.List<Hit> out) {

      /* ---- which endpoint ---- */
      if (this.gradType != NameColor.GRAD_NONE) {
         float bw = (w - 6) / 2.0F;
         endpointTab(ctx, "Start", x, y, bw, mx, my,
            prefix + ":end:0", !this.editingSecondary, this.primary, out);
         endpointTab(ctx, "End", x + bw + 6, y, bw, mx, my,
            prefix + ":end:1", this.editingSecondary, this.secondary, out);
         y += 24;
      }

      /* ---- swatches ---- */
      float sw = 17.0F;
      float gap = 6.0F;
      float sx = x;
      int target = active();
      for (int colour : PALETTE) {
         boolean sel = colour == target;
         boolean over = mx >= sx && mx < sx + sw && my >= y && my < y + sw;
         float grow = Anim.to(prefix + ":sw:" + colour + this.editingSecondary,
            over || sel);
         float pad = 1.5F * grow;
         SmoothRect.fill(ctx, sx - pad, y - pad, sw + pad * 2, sw + pad * 2,
            (sw + pad * 2) / 2.0F, colour);
         if (sel) {
            SmoothRect.outline(ctx, sx - 3, y - 3, sw + 6, sw + 6,
               (sw + 6) / 2.0F, 1.5F, XKit.TEXT);
         }
         out.add(new Hit(sx, y, sw, sw, prefix + ":hue:" + colour));
         sx += sw + gap;
      }
      y += sw + 10;

      /* ---- hex field ---- */
      float fieldW = 92.0F;
      XKit.inputBox(ctx, x, y, fieldW, 20, hexFocused);

      // A live chip of whatever the typed text currently means, so you can see
      // the colour before committing it.
      int typed = parseHex(this.hexDraft);
      int chip = typed != 0 ? typed : active();
      SmoothRect.fill(ctx, x + 5, y + 5, 10, 10, 2.0F, chip);

      String shown = this.hexDraft.isEmpty() && !hexFocused
         ? hexOf(active()) : this.hexDraft;
      boolean bad = !this.hexDraft.isEmpty() && typed == 0;
      TextPainter.drawPoppins(ctx, shown, x + 20, y + 6,
         bad ? XKit.RED : (this.hexDraft.isEmpty() && !hexFocused
            ? XKit.MUTED : XKit.TEXT), 8.0F);
      if (hexFocused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         float cw = TextPainter.poppinsWidth(shown, 8.0F);
         SmoothRect.fill(ctx, x + 21 + cw, y + 5, 1.0F, 10.0F, 0.0F, XKit.BLUE);
      }
      out.add(new Hit(x, y, fieldW, 20, prefix + ":hexfocus"));

      boolean canUse = typed != 0;
      boolean overUse = mx >= x + fieldW + 6 && mx < x + fieldW + 52
         && my >= y && my < y + 20;
      XKit.pill(ctx, "Use", x + fieldW + 6, y, 46, 20, overUse && canUse, true,
         XKit.alpha(XKit.BLUE, canUse ? 1.0F : 0.4F), prefix + ":usehex");
      if (canUse) {
         out.add(new Hit(x + fieldW + 6, y, 46, 20, prefix + ":usehex"));
      }
      y += 28;

      /* ---- gradient type ---- */
      TextPainter.drawPoppins(ctx, "GRADIENT", x, y, XKit.MUTED, 7.0F);
      y += 12;
      float bx = x;
      bx += gradButton(ctx, "square", "Solid", NameColor.GRAD_NONE, bx, y,
         mx, my, prefix, out);
      bx += gradButton(ctx, "move", "Left to right", NameColor.GRAD_HORIZONTAL,
         bx, y, mx, my, prefix, out);
      gradButton(ctx, "chevron-down", "Top to bottom", NameColor.GRAD_VERTICAL,
         bx, y, mx, my, prefix, out);
      y += 26;

      /* ---- bold / italic, text only ---- */
      if (this.supportsTextStyle) {
         float tx = x;
         tx += styleToggle(ctx, "Bold", this.bold, tx, y, mx, my,
            prefix + ":bold", out);
         styleToggle(ctx, "Italic", this.italic, tx, y, mx, my,
            prefix + ":italic", out);
         y += 26;
      }
      return y;
   }

   private void endpointTab(DrawContext ctx, String label, float x, float y,
                            float w, int mx, int my, String tag, boolean active,
                            int swatch, java.util.List<Hit> out) {
      boolean over = mx >= x && mx < x + w && my >= y && my < y + 20;
      float sel = Anim.to(tag + ":s", active);
      float hov = Anim.to(tag + ":h", over && !active);

      SmoothRect.fill(ctx, x, y, w, 20, 10.0F,
         Anim.mixColor(Anim.mixColor(XKit.SURFACE, XKit.HOVER, hov),
            XKit.alpha(XKit.BLUE, 0.22F), sel));
      SmoothRect.outline(ctx, x, y, w, 20, 10.0F, 1.0F,
         Anim.mixColor(XKit.DIVIDER, XKit.BLUE, sel));

      SmoothRect.fill(ctx, x + 7, y + 6, 8, 8, 4.0F, swatch);
      TextPainter.drawPoppins(ctx, label, x + 19, y + 6.5F,
         Anim.mixColor(XKit.MUTED, XKit.TEXT, sel), 7.5F);
      out.add(new Hit(x, y, w, 20, tag));
   }

   private float gradButton(DrawContext ctx, String icon, String label,
                            int type, float x, float y, int mx, int my,
                            String prefix, java.util.List<Hit> out) {
      float w = TextPainter.poppinsWidth(label, 7.5F) + 24;
      boolean active = this.gradType == type;
      boolean over = mx >= x && mx < x + w && my >= y && my < y + 20;
      String tag = prefix + ":grad:" + type;
      float sel = Anim.to(tag + ":s", active);
      float hov = Anim.to(tag + ":h", over && !active);

      SmoothRect.fill(ctx, x, y, w, 20, 10.0F,
         Anim.mixColor(Anim.mixColor(XKit.SURFACE, XKit.HOVER, hov),
            XKit.alpha(XKit.BLUE, 0.25F), sel));
      SmoothRect.outline(ctx, x, y, w, 20, 10.0F, 1.0F,
         Anim.mixColor(XKit.DIVIDER, XKit.BLUE, sel));

      RenderUtil.drawIcon(ctx, icon, Math.round(x + 7), Math.round(y + 6), 8,
         Anim.mixColor(XKit.MUTED, XKit.BLUE, sel));
      TextPainter.drawPoppins(ctx, label, x + 18, y + 6.5F,
         Anim.mixColor(XKit.MUTED, XKit.TEXT, sel), 7.5F);
      out.add(new Hit(x, y, w, 20, tag));
      return w + 6;
   }

   private float styleToggle(DrawContext ctx, String label, boolean on,
                             float x, float y, int mx, int my, String tag,
                             java.util.List<Hit> out) {
      float w = TextPainter.poppinsWidth(label, 7.5F) + 24;
      boolean over = mx >= x && mx < x + w && my >= y && my < y + 20;
      float sel = Anim.to(tag + ":s", on);
      float hov = Anim.to(tag + ":h", over);

      SmoothRect.fill(ctx, x, y, w, 20, 10.0F,
         Anim.mixColor(Anim.mixColor(XKit.SURFACE, XKit.HOVER, hov),
            XKit.alpha(XKit.BLUE, 0.25F), sel));
      SmoothRect.outline(ctx, x, y, w, 20, 10.0F, 1.0F,
         Anim.mixColor(XKit.DIVIDER, XKit.BLUE, sel));
      RenderUtil.drawIcon(ctx, on ? "check" : "square", Math.round(x + 7),
         Math.round(y + 6), 8, Anim.mixColor(XKit.MUTED, XKit.BLUE, sel));
      TextPainter.drawPoppins(ctx, label, x + 18, y + 6.5F,
         Anim.mixColor(XKit.MUTED, XKit.TEXT, sel), 7.5F);
      out.add(new Hit(x, y, w, 20, tag));
      return w + 6;
   }

   /**
    * Paints a rectangle with this spec: solid, left-to-right, or top-to-bottom.
    *
    * <p>Gradients are drawn as strips. A strip per pixel row/column is exact
    * and still cheap at these sizes, and it avoids needing a custom shader.</p>
    */
   public static void fillSpec(DrawContext ctx, NameColor.Spec spec,
                               float x, float y, float w, float h, float radius) {
      if (spec.gradType() == NameColor.GRAD_NONE) {
         SmoothRect.fill(ctx, x, y, w, h, radius, spec.primary());
         return;
      }
      if (spec.vertical()) {
         int rows = Math.max(1, Math.round(h));
         for (int i = 0; i < rows; i++) {
            float t = rows == 1 ? 0.0F : i / (float) (rows - 1);
            // Only the first and last strips get the corner radius, so the
            // rounded ends survive without rounding every strip.
            float r = (i == 0 || i == rows - 1) ? radius : 0.0F;
            SmoothRect.fill(ctx, x, y + i, w, 1.0F, r, NameColor.blend(spec, t));
         }
      } else {
         int cols = Math.max(1, Math.round(w));
         for (int i = 0; i < cols; i++) {
            float t = cols == 1 ? 0.0F : i / (float) (cols - 1);
            float r = (i == 0 || i == cols - 1) ? radius : 0.0F;
            SmoothRect.fill(ctx, x + i, y, 1.0F, h, r, NameColor.blend(spec, t));
         }
      }
   }
}
