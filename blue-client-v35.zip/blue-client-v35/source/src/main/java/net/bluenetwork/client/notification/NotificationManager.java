package net.bluenetwork.client.notification;

import java.util.concurrent.CopyOnWriteArrayList;
import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.gui.DrawContext;

public class NotificationManager {
   private static final int MAX_SHOWN = 5;
   private static final int PADDING = 6;
   private static final int WIDTH = 110;
   private final CopyOnWriteArrayList<Notification> notifications = new CopyOnWriteArrayList<>();

   public synchronized void add(String title, int accent) {
      this.notifications.add(new Notification(title, accent));

      while (this.notifications.size() > 5) {
         this.notifications.remove(0);
      }
   }

   public void addModuleToggle(String moduleName, boolean enabled) {
      this.add(moduleName + (enabled ? " » on" : " » off"), enabled ? -13673473 : BlueColors.TOGGLE_OFF);
   }

   public synchronized void render(DrawContext context) {
      int y = 8;
      int slideDistance = 126;

      if (!this.notifications.isEmpty()) {
         this.notifications.removeIf(Notification::isExpired);
      }

      for (Notification n : this.notifications) {
            int offsetX = (int)((1.0 - n.getSlideIn()) * slideDistance);
            float fade = n.getFadeOut();
            int x = context.getScaledWindowWidth() - 110 - 8 + offsetX;
            this.drawToast(context, n, x, y, fade);
            int panelHeight = 21;
            y += panelHeight + 4;
      }
   }

   private void drawToast(DrawContext context, Notification n, int x, int y, float fade) {
      int panelHeight = 21;
      int width = 122;
      int body = fadeColor(BlueColors.PANEL_BG, fade);
      int border = fadeColor(BlueColors.PANEL_BORDER, fade);
      context.fill(x + 1, y, x + width - 1, y + panelHeight, body);
      context.fill(x, y + 1, x + width, y + panelHeight - 1, body);
      context.fill(x + 1, y, x + width - 1, y + 1, border);
      context.fill(x + 1, y + panelHeight - 1, x + width - 1, y + panelHeight, border);
      context.fill(x, y + 1, x + 1, y + panelHeight - 1, border);
      context.fill(x + width - 1, y + 1, x + width, y + panelHeight - 1, border);
      context.fill(x + 1, y + 2, x + 3, y + panelHeight - 2, fadeColor(n.getAccent(), fade));
      RenderUtil.drawText(context, n.getTitle(), x + 6 + 2, y + 6, fadeColor(BlueColors.TEXT_PRIMARY, fade));
   }

   private static int fadeColor(int argb, float fade) {
      int a = (int)((argb >>> 24 & 0xFF) * fade);
      return a << 24 | argb & 16777215;
   }
}
