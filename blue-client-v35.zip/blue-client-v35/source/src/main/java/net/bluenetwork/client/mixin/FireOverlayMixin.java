package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.FireHeight;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Scales the fire drawn across the screen while the player is burning.
 *
 * <h2>Why this method</h2>
 * {@code renderFireOverlay} is the dedicated draw call for the burning
 * overlay, and it receives the <b>real</b> {@link MatrixStack} the flames are
 * drawn into. Transforming that stack therefore transforms the actual output.
 *
 * <p>An earlier attempt hooked {@code renderOverlays} instead and built its
 * own {@code MatrixStack} - which would have compiled, run, and done
 * absolutely nothing, because the object was never the one being drawn with.
 * Verified against {@code javap} before writing this.</p>
 *
 * <h2>Matrix balance</h2>
 * Push at HEAD, pop at RETURN, guarded by a flag. An unbalanced stack corrupts
 * every subsequent draw in the frame, which is far worse than the feature
 * simply not working.
 *
 * <p>{@code require = 0}: if the mapping changes, the feature quietly stops
 * instead of crashing the game at launch.</p>
 */
@Mixin(InGameOverlayRenderer.class)
public abstract class FireOverlayMixin {

   /**
    * Static, because {@code renderFireOverlay} is a static method and a mixin
    * injecting into it cannot touch instance state.
    */
   @org.spongepowered.asm.mixin.Unique
   private static boolean blueclient$firePushed;

   @Inject(method = {"renderFireOverlay"}, at = {@At("HEAD")}, require = 0)
   private static void blueclient$firePush(MatrixStack matrices,
         VertexConsumerProvider vertices, Sprite sprite, CallbackInfo ci) {
      blueclient$firePushed = false;
      if (!FireHeight.overlayActive()) {
         return;
      }
      matrices.push();
      blueclient$firePushed = true;
      matrices.translate(0.0F, FireHeight.overlayOffset(), 0.0F);
      // Scale Y only: squashing X or Z would distort the flames sideways
      // rather than shortening them.
      matrices.scale(1.0F, FireHeight.overlayScale(), 1.0F);
   }

   @Inject(method = {"renderFireOverlay"}, at = {@At("RETURN")}, require = 0)
   private static void blueclient$firePop(MatrixStack matrices,
         VertexConsumerProvider vertices, Sprite sprite, CallbackInfo ci) {
      if (blueclient$firePushed) {
         matrices.pop();
         blueclient$firePushed = false;
      }
   }
}
