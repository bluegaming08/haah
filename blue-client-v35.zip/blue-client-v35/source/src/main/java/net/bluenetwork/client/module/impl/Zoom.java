package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.event.ClientTickEvent;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.SelfKeyedModule;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;

import java.util.List;

/**
 * Zoom v2 — Zoomify-inspired (feedback 2026-09-11: "the zoom module isn't
 * working, it just changes FOV for some reason").
 *
 * <p>What changed over v1:</p>
 * <ul>
 *   <li><b>Key mode</b>: HOLD (default, press-and-hold like v1) or TOGGLE
 *       (press once to zoom in, press again to zoom out) — the keybind is
 *       handled here ({@link SelfKeyedModule}), never by the generic
 *       keybind manager, so TOGGLE mode can't fight the module toggle.</li>
 *   <li><b>Animation</b>: SMOOTH (eased over {@link #zoomTime} seconds,
 *       Zoomify-style ease-out curve) or INSTANT (snap, zero delay).</li>
 *   <li><b>Zoom time</b>: how many seconds the zoom-in AND zoom-out
 *       animation takes (0.05 s - 3 s).</li>
 *   <li><b>Zoom FOV</b>: the target FOV while zoomed (lower = closer).</li>
 *   <li><b>Smooth camera</b>: optional cinematic camera while zoomed.</li>
 * </ul>
 *
 * <p>The FOV write still goes through {@link OptionGuard}, so zoom stacks
 * correctly on top of Custom FOV and releasing always restores exactly the
 * value that was on screen before the zoom started.</p>
 */
public class Zoom extends Module implements SelfKeyedModule {
   private final ModeSetting keyMode = new ModeSetting("Key Mode", "HOLD = press and hold, TOGGLE = press once to zoom in/out",
      List.of("HOLD", "TOGGLE"), "HOLD");
   private final ModeSetting animation = new ModeSetting("Animation", "SMOOTH eases the FOV over Zoom Time, INSTANT snaps",
      List.of("SMOOTH", "INSTANT"), "SMOOTH");
   private final NumberSetting zoomTime = new NumberSetting("Zoom Time", "Seconds the zoom animation takes (in and out)", 0.40D, 0.05D, 3.0D, 0.05D);
   private final NumberSetting fov = new NumberSetting("Zoom FOV", "Target FOV while zoomed - lower = stronger zoom", 30.0D, 4.0D, 60.0D, 1.0D);
   private final BooleanSetting smoothCamera = new BooleanSetting("Smooth Camera", "Cinematic (smooth) camera while zoomed", false);

   private boolean keyDownLastTick = false;
   private boolean zoomActive = false;
   /** True between "zoom started" and "restore finished" (guard is held). */
   private boolean guarding = false;
   private int restoreTarget = -1;
   private long animStartMs = 0L;
   private float animFromFov = 30.0F;
   private boolean cinematicHeld = false;
   private boolean lastWantZoom = false;

   public Zoom() {
      super("Zoom", "Zoom in with a keybind - hold or toggle, smooth or instant", Category.RENDER);
      this.setKeybind(67);
      this.zoomTime.visibleWhen(() -> "SMOOTH".equals(this.animation.get()));
      this.addSettings(new Setting[]{this.keyMode, this.animation, this.zoomTime, this.fov, this.smoothCamera});
      net.bluenetwork.client.BlueClient.getInstance().eventBus().subscribe(ClientTickEvent.class, this::onClientTick);
   }

   @Override
   protected void onDisable() {
      // Module turned off mid-zoom: release everything on the next tick.
      this.zoomActive = false;
      this.keyDownLastTick = false;
   }

   private boolean zoomKeyHeld() {
      try {
         int code = this.getKeybind();
         if (code <= 0) {
            return false;
         }
         Window window = MinecraftClient.getInstance().getWindow();
         return InputUtil.isKeyPressed(window, code);
      } catch (Throwable t) {
         return false;
      }
   }

   private void onClientTick(ClientTickEvent event) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }

      boolean keyDown = this.zoomKeyHeld();
      boolean pressedEdge = keyDown && !this.keyDownLastTick;
      this.keyDownLastTick = keyDown;

      if (!this.isEnabled()) {
         if (this.guarding) {
            this.finish(mc, true);
         }
         this.zoomActive = false;
         return;
      }

      boolean wantZoom;
      if ("TOGGLE".equals(this.keyMode.get())) {
         if (pressedEdge) {
            this.zoomActive = !this.zoomActive;
         }
         wantZoom = this.zoomActive;
      } else {
         wantZoom = keyDown;
         this.zoomActive = keyDown;
      }

      if (wantZoom && !this.guarding) {
         // Start: remember exactly what was on screen (Custom FOV included).
         this.restoreTarget = mc.options.getFov().getValue();
         this.animFromFov = this.restoreTarget;
         this.animStartMs = System.currentTimeMillis();
         this.guarding = true;
         this.lastWantZoom = true;
         OptionGuard.hold(mc.options.getFov(), this.restoreTarget, this);
         if (this.smoothCamera.get()) {
            mc.options.smoothCameraEnabled = true;
            this.cinematicHeld = true;
         }
      }

      if (!this.guarding) {
         return;
      }

      // Direction flip (in -> out or out -> in): retime the easing from the
      // FOV that is on screen right now so both directions animate smoothly.
      if (wantZoom != this.lastWantZoom) {
         this.animFromFov = mc.options.getFov().getValue();
         this.animStartMs = System.currentTimeMillis();
         this.lastWantZoom = wantZoom;
      }

      int target = wantZoom ? (int) Math.round(this.fov.get()) : this.restoreTarget;
      int next;
      if ("INSTANT".equals(this.animation.get())) {
         next = target;
      } else {
         long durationMs = Math.max(10L, (long) (this.zoomTime.get() * 1000.0D));
         float t = Math.min(1.0F, (System.currentTimeMillis() - this.animStartMs) / (float) durationMs);
         // Zoomify-like ease-out: fast at first, settles gently.
         float eased = 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
         next = Math.round(this.animFromFov + (target - this.animFromFov) * eased);
      }

      OptionGuard.setValue(mc.options.getFov(), next, this);

      if (!wantZoom && next == target) {
         this.finish(mc, false);
      }
   }

   private void finish(MinecraftClient mc, boolean forced) {
      this.guarding = false;
      this.zoomActive = false;
      this.lastWantZoom = false;
      OptionGuard.release(mc.options.getFov(), this);
      if (this.cinematicHeld) {
         mc.options.smoothCameraEnabled = false;
         this.cinematicHeld = false;
      }
      if (forced) {
         this.keyDownLastTick = false;
      }
   }
}
