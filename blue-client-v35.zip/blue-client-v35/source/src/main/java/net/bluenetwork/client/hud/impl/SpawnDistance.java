package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;

/**
 * Spawn Distance (bonus HUD) — your straight-line distance to the world spawn
 * point, in blocks. Useful when you get lost and want to know how far "home"
 * is.
 */
public class SpawnDistance extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);

   public SpawnDistance() {
      super("Spawn Distance", "Distance to the world spawn", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 212);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) {
         return "Spawn --";
      }
      BlockPos spawn = mc.world.getSpawnPoint().getPos();
      double dx = mc.player.getX() - (spawn.getX() + 0.5);
      double dz = mc.player.getZ() - (spawn.getZ() + 0.5);
      int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
      return "Spawn " + dist + "m";
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Spawn 99999m") + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
