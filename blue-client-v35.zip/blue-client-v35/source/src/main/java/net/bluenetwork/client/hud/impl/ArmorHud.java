package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud extends HudModule {
   private static final int SLOT = 18;
   /** v0.16.9: optionally draw each piece's remaining durability next to it. */
   private final BooleanSetting showDurability = new BooleanSetting("Show durability", "Draw remaining durability next to each piece", true);

   public ArmorHud() {
      super("ArmorHUD", "Shows your worn armor.", Category.HUD, 4, 160);
      this.addSettings(new Setting[]{this.showDurability});
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         int panelWidth = 22;
         context.fill(this.x + 1, this.y, this.x + panelWidth - 1, this.y + this.getHeight(), BlueColors.PANEL_BG);
         context.fill(this.x, this.y + 1, this.x + panelWidth, this.y + this.getHeight() - 1, BlueColors.PANEL_BG);
         EquipmentSlot[] slots = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

         for (int i = 0; i < slots.length; i++) {
            ItemStack stack = mc.player.getEquippedStack(slots[i]);
            int itemY = this.y + 2 + i * 18;
            context.drawItem(stack, this.x + 3, itemY);
            if (this.showDurability.get() && stack != null && stack.isDamageable()) {
               int left = stack.getMaxDamage() - stack.getDamage();
               String num = String.valueOf(left);
               float pct = (float) left / (float) stack.getMaxDamage();
               int color = pct > 0.4F ? 0xFF34C759 : (pct > 0.15F ? 0xFFFFD60A : 0xFFE05252);
               RenderUtil.drawText(context, num, this.x + 24, itemY + 5, color);
            }
         }
      }
   }

   @Override
   public int getWidth() {
      // room for the durability column when enabled
      return this.showDurability.get() ? 40 : 22;
   }

   @Override
   public int getHeight() {
      return 76;
   }
}
