package net.bluenetwork.client.hud.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * Elytra HUD Assist (v3 catalogue F6) — information-only flight readout shown
 * while gliding: horizontal speed, height (Y), and rocket count from your
 * inventory. No auto inputs. Hides when not flying.
 */
public class ElytraAssist extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Readout colour", 0xFFFFFFFF);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Rocket-low colour", 0xFFFF5C5C);
   private final NumberSetting warnRockets = new NumberSetting("Warn rockets", "At or below this count rockets turn red", 3.0, 0.0, 20.0, 1.0);
   private final BooleanSetting showRockets = new BooleanSetting("Show rockets", "Count fireworks in your inventory", true);
   private final BooleanSetting showSpeed = new BooleanSetting("Show speed", "Horizontal blocks/second", true);
   private final BooleanSetting showHeight = new BooleanSetting("Show height", "Current Y level", true);

   public ElytraAssist() {
      super("Elytra HUD Assist", "Speed / height / rocket info while gliding", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.warnColor, this.warnRockets, this.showRockets, this.showSpeed, this.showHeight});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 178);
   }

   private List<Line> lines() {
      MinecraftClient mc = MinecraftClient.getInstance();
      List<Line> out = new ArrayList<>();
      if (mc.player == null) {
         return out;
      }
      if (this.showSpeed.get()) {
         double vx = mc.player.getVelocity().x;
         double vz = mc.player.getVelocity().z;
         double speed = Math.sqrt(vx * vx + vz * vz) * 20.0;
         out.add(new Line(String.format("Speed %.1f", speed), false));
      }
      if (this.showHeight.get()) {
         out.add(new Line("Y " + (int) Math.floor(mc.player.getY()), false));
      }
      if (this.showRockets.get()) {
         int rockets = this.rockets();
         boolean warn = rockets <= this.warnRockets.getInt();
         out.add(new Line("Rockets " + rockets, warn));
      }
      return out;
   }

   private int rockets() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return 0;
      }
      int n = 0;
      for (ItemStack stack : mc.player.getInventory().getMainStacks()) {
         if (!stack.isEmpty() && stack.isOf(Items.FIREWORK_ROCKET)) {
            n += stack.getCount();
         }
      }
      return n;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || !mc.player.isGliding()) {
         return;
      }
      List<Line> lines = this.lines();
      if (lines.isEmpty()) {
         return;
      }
      this.drawPanel(context);
      int ty = this.y + 6;
      int normal = this.textColor.currentRgb(System.currentTimeMillis());
      int warn = this.warnColor.currentRgb(System.currentTimeMillis());
      for (Line line : lines) {
         RenderUtil.drawText(context, line.text, this.x + 6 + 2, ty, line.warn ? warn : normal);
         ty += 9;
      }
   }

   @Override
   public int getWidth() {
      int max = 0;
      for (Line line : this.lines()) {
         max = Math.max(max, RenderUtil.textWidth(line.text));
      }
      return Math.max(20, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = this.lines().size();
      return Math.max(21, rows * 9 + 12);
   }

   private record Line(String text, boolean warn) {
   }
}
