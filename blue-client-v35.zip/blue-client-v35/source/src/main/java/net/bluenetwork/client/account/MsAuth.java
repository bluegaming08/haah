package net.bluenetwork.client.account;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import net.bluenetwork.client.BlueClient;

/**
 * Microsoft device-code login.
 *
 * <h2>v0.24.2 — why "Microsoft login doesn't work"</h2>
 *
 * The flow itself (device code → Xbox Live → XSTS → Minecraft services) was
 * implemented correctly, but it could never succeed, for one reason:
 *
 * <p><b>The bundled client id was a placeholder.</b> Microsoft will only issue
 * Minecraft tokens to an Azure application that has been <i>explicitly
 * approved</i> for the Minecraft API. An unapproved app gets HTTP 403 with
 * {@code "Invalid app registration, see https://aka.ms/AppRegInfo"} from
 * {@code login_with_xbox}, and an id that was never registered at all fails
 * even earlier with {@code unauthorized_client} from the devicecode endpoint.
 * See README-MICROSOFT-LOGIN.md for how to register your own.</p>
 *
 * <p>Two things are fixed here regardless of the id:</p>
 * <ol>
 *   <li><b>Errors are now readable.</b> The old code called
 *       {@code code.get("user_code").getAsString()} straight away — when the
 *       devicecode endpoint returned an error JSON instead, that threw a bare
 *       {@code NullPointerException} and the screen showed an empty notice.
 *       Every response is now checked and turned into a plain-English message.</li>
 *   <li><b>HTTP status codes are kept</b>, so a 403 can be reported as the app
 *       registration problem it actually is instead of a parse failure.</li>
 * </ol>
 */
public class MsAuth {
   /**
    * Fallback app id. This is NOT approved for the Minecraft API — override it
    * with your own approved id in config (`msClientId`) or the login will fail
    * with "Invalid app registration". See README-MICROSOFT-LOGIN.md.
    */
   private static final String CLIENT_ID = "c36a9fb6-4f15-4b4f-8817-4a4f7f0a4f8c";
   private static final String DEVICE_CODE_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
   private static final String TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
   private static final String XBL_URL = "https://user.auth.xboxlive.com/user/authenticate";
   private static final String XSTS_URL = "https://xsts.auth.xboxlive.com/xsts/authorize";
   private static final String MC_LOGIN_URL = "https://api.minecraftservices.com/authentication/login_with_xbox";
   private static final String MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile";

   public static MsAuth.State start() {
      String clientId = BlueClient.getInstance().settings().msClientId();
      if (clientId == null || clientId.isBlank() || clientId.equals("00000000-0000-0000-0000-000000000000")) {
         clientId = "c36a9fb6-4f15-4b4f-8817-4a4f7f0a4f8c";
      }

      MsAuth.State state = new MsAuth.State();
      String id = clientId;
      Thread thread = new Thread(() -> {
         try {
            run(state, id);
         } catch (Throwable var3x) {
            state.error = var3x.getMessage() == null ? var3x.toString() : var3x.getMessage();
            state.done = true;
         }
      }, "Blue Client MS Login");
      thread.setDaemon(true);
      thread.start();
      return state;
   }

   private static void run(MsAuth.State state, String clientId) throws Exception {
      HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).followRedirects(Redirect.NORMAL).build();
      Http devicecode = postForm(
         http,
         "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode",
         "client_id=" + clientId + "&scope=" + enc("XboxLive.signin offline_access")
      );
      JsonObject code = parseObject(devicecode, "device code request");

      /*
       * Fail LOUDLY and specifically here. This is where a bad/unregistered
       * client id shows up, and the old code just NPE'd on the missing
       * "user_code" field, which told the owner nothing.
       */
      if (!code.has("user_code") || !code.has("device_code")) {
         String err = code.has("error") ? code.get("error").getAsString() : "";
         String desc = code.has("error_description")
            ? code.get("error_description").getAsString() : devicecode.body;
         if ("unauthorized_client".equals(err) || "invalid_client".equals(err)) {
            // AADSTS700016. Verified against three client ids including the
            // built-in fallback: Microsoft no longer publishes a public app id
            // a third-party client may use. The two real options are the
            // user's own Azure registration, or letting a launcher that HAS
            // one hand us a finished session - so point at both.
            boolean launcher = net.bluenetwork.client.social.LauncherBridge
               .readMcSession() != null;
            throw new IllegalStateException(launcher
               ? "Microsoft login is not needed - the launcher already signed "
                  + "you in. Restart the game if this keeps appearing."
               : "This build has no valid Microsoft app id. Use the Blue "
                  + "Client launcher, or set 'msClientId' in config - see "
                  + "README-MICROSOFT-LOGIN.md");
         }
         throw new IllegalStateException("Microsoft rejected the login request: "
            + (desc == null || desc.isBlank() ? err : firstLine(desc)));
      }

      state.userCode = code.get("user_code").getAsString();
      state.verificationUri = code.has("verification_uri") ? code.get("verification_uri").getAsString() : "https://www.microsoft.com/link";
      long interval = code.has("interval") ? code.get("interval").getAsLong() : 5L;
      long deadline = System.currentTimeMillis() + 900000L;
      String msAccess = null;
      String msRefresh = null;

      while (System.currentTimeMillis() < deadline) {
         Thread.sleep(interval * 1000L);
         Http tokenHttp = postForm(
            http,
            "https://login.microsoftonline.com/consumers/oauth2/v2.0/token",
            "client_id="
               + clientId
               + "&grant_type="
               + enc("urn:ietf:params:oauth:grant-type:device_code")
               + "&device_code="
               + enc(code.get("device_code").getAsString())
         );
         JsonObject token = parseObject(tokenHttp, "token request");
         if (token.has("access_token")) {
            msAccess = token.get("access_token").getAsString();
            msRefresh = token.has("refresh_token") ? token.get("refresh_token").getAsString() : "";
            break;
         }

         String error = token.has("error") ? token.get("error").getAsString() : "";
         if (!"authorization_pending".equals(error) && !"slow_down".equals(error)) {
            if ("authorization_declined".equals(error)) {
               throw new IllegalStateException("Login was cancelled");
            }

            if ("expired_token".equals(error)) {
               throw new IllegalStateException("The code expired - try again");
            }

            throw new IllegalStateException("Microsoft login failed: " + error);
         }
      }

      if (msAccess == null) {
         throw new IllegalStateException("The code expired - try again");
      } else {
         JsonObject xblBody = new JsonObject();
         JsonObject props = new JsonObject();
         props.addProperty("AuthMethod", "RPS");
         props.addProperty("SiteName", "user.auth.xboxlive.com");
         props.addProperty("RpsTicket", "d=" + msAccess);
         xblBody.add("Properties", props);
         Http xblHttp = postJson(http, "https://user.auth.xboxlive.com/user/authenticate", xblBody.toString());
         JsonObject xbl = parseObject(xblHttp, "Xbox Live sign-in");
         if (!xbl.has("Token")) {
            throw new IllegalStateException("Xbox Live rejected the sign-in (HTTP "
               + xblHttp.status + ") - does this account have an Xbox profile?");
         }
         String xblToken = xbl.get("Token").getAsString();
         JsonObject xstsBody = new JsonObject();
         JsonObject xstsProps = new JsonObject();
         xstsProps.addProperty("SandboxId", "RETAIL");
         JsonArray tokens = new JsonArray();
         tokens.add(xblToken);
         xstsProps.add("UserTokens", tokens);
         xstsBody.add("Properties", xstsProps);
         Http xstsHttp = postJson(http, "https://xsts.auth.xboxlive.com/xsts/authorize", xstsBody.toString());
         JsonObject xsts = parseObject(xstsHttp, "Xbox authorization");
         if (!xsts.has("Token")) {
            long xerr = xsts.has("XErr") ? xsts.get("XErr").getAsLong() : 0L;
            if (xerr == 2148916233L) {
               throw new IllegalStateException("This Microsoft account has no Xbox profile");
            } else if (xerr == 2148916238L) {
               throw new IllegalStateException("Child accounts need adult sign-in");
            } else {
               throw new IllegalStateException("Xbox authorization failed (XErr " + xerr + ")");
            }
         } else {
            String xstsToken = xsts.get("Token").getAsString();
            String uhs = xsts.getAsJsonArray("DisplayClaims").get(0).getAsJsonObject().get("uhs").getAsString();
            JsonObject mcBody = new JsonObject();
            mcBody.addProperty("identityToken", "XBL3.0 x=" + uhs + ";" + xstsToken);
            Http mcHttp = postJson(http,
               "https://api.minecraftservices.com/authentication/login_with_xbox", mcBody.toString());

            /*
             * THE app-registration wall. Mojang returns 403 + "Invalid app
             * registration" for any Azure app that has not been approved for
             * the Minecraft API. Nothing client-side can work around it - the
             * owner must register an app and get it approved.
             */
            if (mcHttp.status == 403 || mcHttp.body.contains("Invalid app registration")) {
               throw new IllegalStateException(
                  "Microsoft app is not approved for Minecraft. Register your own app id "
                     + "and apply at aka.ms/mce-reviewappid - see README-MICROSOFT-LOGIN.md");
            }
            JsonObject mc = parseObject(mcHttp, "Minecraft sign-in");
            if (!mc.has("access_token")) {
               throw new IllegalStateException("Minecraft did not return a token (HTTP "
                  + mcHttp.status + ")");
            }
            String mcAccess = mc.get("access_token").getAsString();
            HttpRequest profileRequest = HttpRequest.newBuilder(URI.create("https://api.minecraftservices.com/minecraft/profile"))
               .header("Authorization", "Bearer " + mcAccess)
               .timeout(Duration.ofSeconds(10L))
               .GET()
               .build();
            HttpResponse<String> profileResponse = http.send(profileRequest, BodyHandlers.ofString());
            if (profileResponse.statusCode() == 404) {
               throw new IllegalStateException("This account does not own Minecraft");
            } else {
               JsonObject profile = JsonParser.parseString(profileResponse.body()).getAsJsonObject();
               String compactUuid = profile.get("id").getAsString();
               String name = profile.get("name").getAsString();
               String dashed = compactUuid.length() == 32
                  ? compactUuid.substring(0, 8)
                     + "-"
                     + compactUuid.substring(8, 12)
                     + "-"
                     + compactUuid.substring(12, 16)
                     + "-"
                     + compactUuid.substring(16, 20)
                     + "-"
                     + compactUuid.substring(20, 32)
                  : compactUuid;
               state.account = new Account("msa", name, dashed, mcAccess, msRefresh, uhs);
               state.success = true;
               state.done = true;
               BlueClient.LOGGER.info("Microsoft account '{}' logged in", name);
            }
         }
      }
   }

   /** An HTTP status + body pair; the status is what makes 403 diagnosable. */
   private record Http(int status, String body) {
   }

   private static Http postForm(HttpClient http, String url, String body) throws Exception {
      HttpRequest request = HttpRequest.newBuilder(URI.create(url))
         .header("Content-Type", "application/x-www-form-urlencoded")
         .timeout(Duration.ofSeconds(15L))
         .POST(BodyPublishers.ofString(body, StandardCharsets.UTF_8))
         .build();
      HttpResponse<String> response = http.send(request, BodyHandlers.ofString());
      return new Http(response.statusCode(), response.body());
   }

   private static Http postJson(HttpClient http, String url, String body) throws Exception {
      HttpRequest request = HttpRequest.newBuilder(URI.create(url))
         .header("Content-Type", "application/json")
         .header("Accept", "application/json")
         .timeout(Duration.ofSeconds(15L))
         .POST(BodyPublishers.ofString(body, StandardCharsets.UTF_8))
         .build();
      HttpResponse<String> response = http.send(request, BodyHandlers.ofString());
      return new Http(response.statusCode(), response.body());
   }

   /**
    * Parses a response body as a JSON object, or throws a message naming the
    * step that failed. Servers sometimes answer with an HTML error page, which
    * would otherwise surface as an unreadable parser exception.
    */
   private static JsonObject parseObject(Http response, String step) {
      try {
         return JsonParser.parseString(response.body()).getAsJsonObject();
      } catch (Throwable t) {
         throw new IllegalStateException(step + " failed (HTTP " + response.status()
            + "): " + firstLine(response.body()));
      }
   }

   private static String firstLine(String text) {
      if (text == null || text.isBlank()) {
         return "no details";
      }
      String line = text.strip().split("\\R", 2)[0];
      return line.length() > 160 ? line.substring(0, 160) + "..." : line;
   }

   private static String enc(String value) {
      return URLEncoder.encode(value, StandardCharsets.UTF_8);
   }

   public static class State {
      public volatile String userCode = "";
      public volatile String verificationUri = "";
      public volatile boolean done = false;
      public volatile boolean success = false;
      public volatile String error = "";
      public volatile Account account = null;
   }
}
