package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.event.KeyEvent;
import net.minecraft.client.Keyboard;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Keyboard.class})
public abstract class KeyboardMixin {
   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")}
   )
   private void blueclient$postKeyEvent(long window, int action, KeyInput input, CallbackInfo ci) {
      BlueClient blue = BlueClient.getInstance();
      if (blue != null) {
         blue.eventBus().post(new KeyEvent(input.key(), action));
      }
   }
}
