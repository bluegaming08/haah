package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.Nametags;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Nametags module (v0.19.0): vanilla {@code hasLabel} hard-codes
 * {@code entity == cameraEntity → false}, which is why you never see your own
 * name above your head - even in F5. This forces the label back on for the
 * local player while the Nametags module wants it (third person only).
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity> {

   @Inject(
      method = {"hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void blueclient$showOwnNametag(T entity, double distanceSq, CallbackInfoReturnable<Boolean> cir) {
      if (!cir.getReturnValueZ() && Nametags.ownNametag()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player != null && entity == mc.player && !mc.player.isInvisible()) {
            cir.setReturnValue(true);
         }
      }
   }
}
