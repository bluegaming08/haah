package net.bluenetwork.client.hud.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Hunger Numbers (v3 catalogue A5) — numeric hunger and saturation as a text
 * panel. Mode selects hunger only / +saturation. Saturation shown with one
 * decimal, matching the vanilla half-shank precision.
 */
public class HungerNumbers extends HudModule {
   private static final String[] MODES = {"Hunger & Saturation", "Hunger only", "Saturation only"};
   private final ModeSetting mode = new ModeSetting("Mode", "Which values the panel shows", List.of(MODES), "Hunger & Saturation");
   private final ColorSetting textColor = new ColorSetting("Text color", "Normal value colour", 0xFFFFFFFF);
   private final BooleanSetting decimals = new BooleanSetting("Saturation decimals", "Show saturation with a decimal (else rounded)", true);

   public HungerNumbers() {
      super("Hunger Numbers", "Numeric hunger + saturation", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.mode, this.textColor, this.decimals});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 78);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return "Hunger --";
      }
      int food = mc.player.getHungerManager().getFoodLevel();
      float sat = mc.player.getHungerManager().getSaturationLevel();
      String satText = this.decimals.get()
         ? String.format("%.1f", sat)
         : String.valueOf(Math.round(sat));
      return switch (this.mode.get()) {
         case "Hunger only" -> "Hunger " + food;
         case "Saturation only" -> "Sat " + satText;
         default -> "Hunger " + food + "  Sat " + satText;
      };
   }

   @Override
   public void render(DrawContext context) {
      if (MinecraftClient.getInstance().player == null) {
         return;
      }
      String text = this.text();
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, text, this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
