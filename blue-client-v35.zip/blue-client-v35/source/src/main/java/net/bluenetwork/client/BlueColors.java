package net.bluenetwork.client;

public final class BlueColors {
   public static int ACCENT = -13673473;
   public static int ACCENT_SOFT = -2144379905;
   public static int PANEL_BG = -1877994986;
   public static int PANEL_BG_HOVER = -1340597728;
   public static int PANEL_BORDER = 1358954495;
   public static int TEXT_PRIMARY = -1;
   public static int TEXT_MUTED = -5196608;
   public static int TOGGLE_OFF = 0xFFE05252;
   public static int GLASS_TINT = 405293184;

   public static void applyTheme(boolean light) {
      if (light) {
         // Light palette, v0.16.1: darker text greys (the old muted grey was
         // unreadable on translucent panels) and a DARK translucent border —
         // the old white border was invisible against a light background.
         PANEL_BG = 0xB4F5F7FB;      // translucent near-white
         PANEL_BG_HOVER = 0xCCE9EEF7;
         PANEL_BORDER = 0x66131A2A;   // dark translucent outline
         TEXT_PRIMARY = 0xFF141A26;   // near-black
         TEXT_MUTED = 0xFF4E586D;     // readable secondary
         TOGGLE_OFF = 0xFFE05252;
      } else {
         PANEL_BG = -1877994986;
         PANEL_BG_HOVER = -1340597728;
         PANEL_BORDER = 1358954495;
         TEXT_PRIMARY = -1;
         TEXT_MUTED = -5196608;
         TOGGLE_OFF = 0xFFE05252;
      }
   }

   private BlueColors() {
   }

   static {
      applyTheme(false);
   }
}
