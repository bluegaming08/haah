package net.bluenetwork.client.module;

import net.minecraft.client.gui.screen.Screen;

/**
 * Module whose keybind opens a screen instead of toggling it (v0.19.1,
 * Waypoints menu). {@code KeybindManager} checks this before its normal
 * toggle path, so one key can never both open the screen and flip the
 * module on/off.
 */
public interface KeyScreenOpener {
   /** The screen this module's keybind should open. */
   Screen openKeyScreen();
}
