package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.cosmetics.Cape;
import net.bluenetwork.client.cosmetics.CosmeticsManager;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * CosmeticsScreen (v0.20.2) — the cosmetics hub, per the owner's spec:
 * <ul>
 *   <li><b>Left:</b> vertical category list under the COSMETICS heading —
 *       Capes (active, shows owned count), Accessories / Pets / Emotes /
 *       Auras grayed out with a SOON tag.</li>
 *   <li><b>Center:</b> sort button (Owned / Unowned / Favorites / A-Z / Z-A)
 *       to the LEFT of the search bar, cape grid below with OWNED/UNOWNED
 *       tags, prices, rarity strips and a favorite heart per tile.</li>
 *   <li><b>Right:</b> 3D player showcase wearing the SELECTED Blue Client
 *       cape (never the vanilla/Mojang cape). Auto-rotates; drag it to spin
 *       it faster, and a small button inside the showcase stops the
 *       auto-rotation for pure manual spinning. A HELP button above the
 *       showcase opens the info popup (closable, dims the background).</li>
 * </ul>
 * Purchase still needs a deliberate CONFIRM click. Favorites are saved in
 * cosmetics.json. Cape art renders via drawTexture (TextureManager), NOT
 * drawGuiTexture (GUI atlas) — that v0.20.0/1 bug is why capes never
 * rendered in the locker.
 */
public class CosmeticsScreen extends Screen {
   private enum Sort {
      OWNED, UNOWNED, FAVORITES, A_Z, Z_A;

      String label() {
         return switch (this) {
            case OWNED -> "OWNED";
            case UNOWNED -> "UNOWNED";
            case FAVORITES -> "FAVORITES";
            case A_Z -> "A-Z";
            case Z_A -> "Z-A";
         };
      }
   }

   private final Screen parent;
   private final List<Cape> capes = net.bluenetwork.client.cosmetics.CapeRegistry.all();
   private Cape selected;
   private int confirmTicks;

   // search + sort
   private String searchDraft = "";
   private boolean searchFocus;
   private Sort sort = Sort.OWNED;

   // showcase
   private float mannequinYaw;
   private float yawVel;
   private boolean autoRotate = true;
   private boolean rotating;

   // help popup
   private boolean helpOpen;

   // hit rects (recomputed each frame)
   private final List<Rect> tiles = new ArrayList<>();
   private final List<Rect> hearts = new ArrayList<>();
   private Rect searchRect;
   private Rect sortRect;
   private Rect helpRect;
   private Rect rotateRect;
   private Rect showcaseRect;
   private Rect actionButton;
   private Rect unequipButton;
   private Rect helpCloseRect;

   public CosmeticsScreen(Screen parent) {
      super(Text.literal("Cosmetics"));
      this.parent = parent;
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   protected void init() {
      this.selected = this.selected != null ? this.selected
         : net.bluenetwork.client.cosmetics.CapeRegistry.byId(CosmeticsManager.profileStatic().equipped());
      if (this.selected == null && !this.capes.isEmpty()) {
         this.selected = this.capes.get(0);
      }
   }

   /* ---------------- filtering + sorting ---------------- */

   private List<Cape> visibleCapes() {
      var profile = CosmeticsManager.profileStatic();
      String q = this.searchDraft.strip().toLowerCase(Locale.ROOT);
      List<Cape> out = new ArrayList<>();
      for (Cape cape : this.capes) {
         if (q.isEmpty() || cape.displayName().toLowerCase(Locale.ROOT).contains(q)) {
            out.add(cape);
         }
      }
      Comparator<Cape> cmp = switch (this.sort) {
         case OWNED -> Comparator.comparing((Cape c) -> profile.owns(c.id()) ? 0 : 1)
            .thenComparing(c -> profile.isFavorite(c.id()) ? 0 : 1)
            .thenComparing(Cape::displayName);
         case UNOWNED -> Comparator.comparing((Cape c) -> profile.owns(c.id()) ? 1 : 0)
            .thenComparing(Cape::displayName);
         case FAVORITES -> Comparator.comparing((Cape c) -> profile.isFavorite(c.id()) ? 0 : 1)
            .thenComparing(c -> profile.owns(c.id()) ? 0 : 1)
            .thenComparing(Cape::displayName);
         case A_Z -> Comparator.comparing(Cape::displayName);
         case Z_A -> Comparator.comparing(Cape::displayName).reversed();
      };
      out.sort(cmp);
      return out;
   }

   /* ---------------- render ---------------- */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      MinecraftClient mc = MinecraftClient.getInstance();
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, DesignTokens.scrim());

      var profile = CosmeticsManager.profileStatic();
      List<Cape> shown = this.visibleCapes();

      int panelW = Math.max(430, Math.min(580, w - 16));
      int panelH = Math.max(230, Math.min(300, h - 16));
      int px = (w - panelW) / 2;
      int py = (h - panelH) / 2;

      SmoothRect.fill(context, px, py, panelW, panelH, 14, DesignTokens.panelBg());
      SmoothRect.outline(context, px, py, panelW, panelH, 14, 1.0F, DesignTokens.panelBorder());

      // ---------- header ----------
      TextPainter.drawPoppins(context, "COSMETICS", px + 14, py + 10, DesignTokens.textHi(), 14.0F);
      String stars = "\u2605 " + profile.stars();
      TextPainter.drawPoppins(context, stars, px + panelW - 14 - TextPainter.poppinsWidth(stars, 12.0F), py + 11, 0xFFFFC94A, 12.0F);

      // ---------- left: categories ----------
      int catX = px + 10;
      int catY = py + 34;
      int catW = 88;
      int ownedCount = (int) this.capes.stream().filter(c -> profile.owns(c.id())).count();
      this.category(context, catX, catY, catW, "Capes", true, "OWNED " + ownedCount + "/" + this.capes.size(), mouseX, mouseY);
      String[] soon = {"Accessories", "Pets", "Emotes", "Auras"};
      int sy = catY + 24;
      for (String name : soon) {
         this.category(context, catX, sy, catW, name, false, "SOON", mouseX, mouseY);
         sy += 22;
      }

      // divider
      int centerX0 = catX + catW + 10;
      context.fill(centerX0, py + 34, centerX0 + 1, py + panelH - 10, 0x22FFFFFF);

      // ---------- right: 3D showcase ----------
      int showW = Math.min(150, Math.max(110, (panelW - catW - 60) / 4));
      int showX = px + panelW - showW - 12;
      int showY = py + 46;
      int showH = panelH - 46 - 12;
      this.showcaseRect = new Rect(showX, showY, showW, showH);

      // HELP button above the showcase
      int helpW = 13;
      this.helpRect = new Rect(showX + showW - helpW, showY - 18, helpW, 13);
      RenderUtil.drawIcon(context, "help-circle", this.helpRect.x, this.helpRect.y, helpW,
         this.helpRect.contains(mouseX, mouseY) ? 0xFFFFFFFF : 0xFF9DB2FF);

      SmoothRect.fill(context, showX, showY, showW, showH, 10, 0x14000000);
      SmoothRect.outline(context, showX, showY, showW, showH, 10, 1.0F, 0x22FFFFFF);

      // rotation update
      if (this.autoRotate && !this.rotating) {
         this.yawVel = this.yawVel * 0.90F + 2.4F * 0.10F;
      }
      this.yawVel *= 0.94F;
      this.mannequinYaw += this.autoRotate && !this.rotating ? 2.4F + this.yawVel : this.yawVel;

      if (mc.player != null) {
         try {
            var st = mc.getEntityRenderDispatcher().getRenderer(mc.player)
               .getAndUpdateRenderState(mc.player, 1.0F);
            st.light = 0xF000F0;
            st.shadowPieces.clear();
            st.outlineColor = 0;
            if (st instanceof net.minecraft.client.render.entity.state.LivingEntityRenderState ls) {
               ls.bodyYaw = this.mannequinYaw % 360.0F;
               ls.relativeHeadYaw = 0.0F;
               ls.pitch = 0.0F;
               ls.width = ls.width / ls.baseScale;
               ls.height = ls.height / ls.baseScale;
               ls.baseScale = 1.0F;
            }
            org.joml.Vector3f pos = new org.joml.Vector3f(0.0F, st.height / 2.0F, 0.0F);
            org.joml.Quaternionf q1 = new org.joml.Quaternionf().rotateZ((float) Math.PI);
            org.joml.Quaternionf q2 = new org.joml.Quaternionf().rotateX(0.0F);
            q1.mul(q2);
            int size = Math.min(showH, showW) * 2 / 3;
            context.addEntity(st, size, pos, q1, q2,
               showX + 4, showY + 4, showX + showW - 4, showY + showH - 4);
         } catch (Throwable ignored) {
            // showcase must never crash the screen
         }
      }

      // auto-rotate on/off button inside the showcase (bottom-right)
      int rotW = 14;
      this.rotateRect = new Rect(showX + showW - rotW - 5, showY + showH - rotW - 5, rotW, rotW);
      boolean rotHover = this.rotateRect.contains(mouseX, mouseY);
      SmoothRect.fill(context, this.rotateRect.x - 2, this.rotateRect.y - 2, rotW + 4, rotW + 4, 5,
         rotHover ? 0x33FFFFFF : 0x14FFFFFF);
      RenderUtil.drawIcon(context, this.autoRotate ? "pause" : "play",
         this.rotateRect.x, this.rotateRect.y, rotW, rotHover ? 0xFFFFFFFF : 0xFF9DB2FF);

      // selected cape caption
      if (this.selected != null) {
         TextPainter.drawPoppins(context, this.selected.displayName(), showX + 6, showY + showH - 22, DesignTokens.textHi(), 9.5F);
         TextPainter.drawPoppins(context, this.selected.rarity().displayName().toUpperCase(Locale.ROOT), showX + 6, showY + showH - 11, this.selected.rarity().color(), 8.0F);
      }

      // ---------- center: sort + search + grid ----------
      int gridX = centerX0 + 10;
      int gridW = showX - 10 - gridX;
      int topY = py + 34;

      // sort button LEFT of the search bar
      int sortW = 62;
      this.sortRect = new Rect(gridX, topY, sortW, 16);
      boolean sortHover = this.sortRect.contains(mouseX, mouseY);
      SmoothRect.fill(context, this.sortRect.x, this.sortRect.y, sortW, 16, 5, sortHover ? 0x2E101520 : 0x99101520);
      SmoothRect.outline(context, this.sortRect.x, this.sortRect.y, sortW, 16, 5, 1.0F, 0x33FFFFFF);
      String sortLabel = this.sort.label();
      TextPainter.drawPoppins(context, sortLabel, this.sortRect.x + (sortW - TextPainter.poppinsWidth(sortLabel, 8.0F)) / 2,
         this.sortRect.y + 4, 0xFF9DB2FF, 8.0F);

      // search bar
      int searchX = gridX + sortW + 6;
      this.searchRect = new Rect(searchX, topY, gridX + gridW - searchX, 16);
      SmoothRect.fill(context, this.searchRect.x, this.searchRect.y, this.searchRect.w, 16, 5,
         this.searchFocus ? 0x2E101520 : 0x99101520);
      SmoothRect.outline(context, this.searchRect.x, this.searchRect.y, this.searchRect.w, 16, 5, 1.0F,
         this.searchFocus ? 0xFF4A9CFF : 0x33FFFFFF);
      RenderUtil.drawIcon(context, "search", this.searchRect.x + 4, this.searchRect.y + 3, 10, 0xFF9DB2FF);
      String typed = this.searchDraft.isEmpty() ? "Search capes..." : this.searchDraft + (this.searchFocus ? "_" : "");
      TextPainter.drawPoppins(context, typed, this.searchRect.x + 18, this.searchRect.y + 4,
         this.searchDraft.isEmpty() ? DesignTokens.textMid() : DesignTokens.textHi(), 8.0F);

      // grid
      this.tiles.clear();
      this.hearts.clear();
      int gridY = topY + 22;
      int gridH = panelH - (gridY - py) - 34;
      int cols = gridW >= 120 ? 2 : 1;
      int rows = (shown.size() + cols - 1) / cols;
      int cellW = (gridW - 6 * (cols - 1)) / cols;
      int cellH = rows <= 0 ? 0 : Math.min(100, (gridH - 6 * (rows - 1)) / rows);
      int artH = (int) ((cellH - 30) * 0.62F);
      int artW = artH * 100 / 160;

      for (int i = 0; i < shown.size(); i++) {
         Cape cape = shown.get(i);
         int col = i % cols;
         int row = i / cols;
         int tileX = gridX + col * (cellW + 6);
         int tileY = gridY + row * (cellH + 6);
         this.tiles.add(new Rect(tileX, tileY, cellW, cellH));

         boolean hovered = mouseX >= tileX && mouseX < tileX + cellW && mouseY >= tileY && mouseY < tileY + cellH;
         boolean owned = profile.owns(cape.id());
         boolean equipped = cape.id().equals(profile.equipped());
         boolean fav = profile.isFavorite(cape.id());
         boolean sel = this.selected != null && cape.id().equals(this.selected.id());

         if (hovered && mc.player != null) {
            CosmeticsManager.preview(cape); // live try-on
         }

         int body = sel ? 0x2A000000 : 0x17000000;
         SmoothRect.fill(context, tileX, tileY, cellW, cellH, 8, body);
         int border = hovered ? 0xFFFFFFFF : (sel ? 0xAAFFFFFF : 0x33FFFFFF);
         if (equipped) {
            border = 0xAA4A9CFF;
         }
         SmoothRect.outline(context, tileX, tileY, cellW, cellH, 8, 1.0F, border);

         // cape art — drawTexture (TextureManager path), NOT the GUI atlas
         if (artW > 4 && artH > 4) {
            int artX = tileX + (cellW - artW) / 2;
            int artY = tileY + 6;
            context.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,
               net.minecraft.util.Identifier.of("blueclient", "textures/capes/thumbs/" + cape.id() + ".png"),
               artX, artY, 0.0F, 0.0F, artW, artH, artW, artH, 100, 160);
         }

         // favorite heart (top-right of the tile)
         int heartW = 11;
         Rect heart = new Rect(tileX + cellW - heartW - 4, tileY + 4, heartW, heartW);
         this.hearts.add(heart);
         RenderUtil.drawIcon(context, "heart", heart.x, heart.y, heartW,
            fav ? 0xFFFF5A8A : (heart.contains(mouseX, mouseY) ? 0xFFB9C4E8 : 0x66FFFFFF));

         // name
         /*
          * Trim to fit, measuring the ellipsis as part of the budget.
          *
          * The old loop appended "…" on every iteration, so a long name could
          * end up as "Somethi………" and still overflow the cell. Build the
          * truncation once instead.
          */
         String name = cape.displayName();
         if (TextPainter.poppinsWidth(name, 8.5F) > cellW - 8) {
            float ellipsis = TextPainter.poppinsWidth("…", 8.5F);
            while (!name.isEmpty()
                  && TextPainter.poppinsWidth(name, 8.5F) + ellipsis > cellW - 8) {
               name = name.substring(0, name.length() - 1);
            }
            name = name + "…";
         }
         TextPainter.drawPoppins(context, name, tileX + 4, tileY + cellH - 30, DesignTokens.textHi(), 8.5F);

         // owned/unowned tag + price
         String tag;
         int tagColor;
         if (equipped) {
            tag = "EQUIPPED";
            tagColor = 0xFF4A9CFF;
         } else if (owned) {
            tag = "OWNED";
            tagColor = 0xFF55D65E;
         } else {
            tag = "UNOWNED";
            tagColor = 0xFFB9C4E8;
         }
         TextPainter.drawPoppins(context, tag, tileX + 4, tileY + cellH - 19, tagColor, 8.0F);
         if (!owned) {
            String price = cape.rarity().purchasable() ? "\u2605 " + cape.rarity().price() : "EXCLUSIVE";
            TextPainter.drawPoppins(context, price, tileX + cellW - 4 - TextPainter.poppinsWidth(price, 8.0F),
               tileY + cellH - 19, cape.rarity().purchasable() ? 0xFFFFC94A : cape.rarity().color(), 8.0F);
         }

         // rarity strip
         SmoothRect.fill(context, tileX, tileY + cellH - 4, cellW, 2, 2, cape.rarity().color());
      }
      if (mc.player != null && this.selected != null) {
         boolean hoveringTile = false;
         for (Rect r : this.tiles) {
            if (r.contains(mouseX, mouseY)) {
               hoveringTile = true;
               break;
            }
         }
         if (!hoveringTile) {
            CosmeticsManager.preview(this.selected);
         }
      }

      // ---------- action bar ----------
      int barY = gridY + rows * (cellH + 6) + 2;
      this.actionButton = null;
      this.unequipButton = null;
      if (this.selected != null && rows > 0 && cellH > 0) {
         Cape cape = this.selected;
         boolean owned = profile.owns(cape.id());
         boolean equipped = cape.id().equals(profile.equipped());
         int btnW = gridW;
         int btnH = 18;
         if (owned) {
            if (!equipped) {
               this.actionButton = new Rect(gridX, barY, btnW, btnH);
               this.drawButton(context, this.actionButton, mouseX, mouseY, "EQUIP", 0xFF4A9CFF, DesignTokens.textHi());
            } else {
               this.unequipButton = new Rect(gridX, barY, btnW, btnH);
               this.drawButton(context, this.unequipButton, mouseX, mouseY, "UNEQUIP", 0x66000000, DesignTokens.textMid());
            }
         } else if (cape.rarity().purchasable()) {
            boolean afford = profile.stars() >= cape.rarity().price();
            this.actionButton = new Rect(gridX, barY, btnW, btnH);
            if (this.confirmTicks > 0) {
               this.drawButton(context, this.actionButton, mouseX, mouseY,
                  "CONFIRM  \u2605 " + cape.rarity().price() + " ?", 0xFFFF5A5A, 0xFFFFFFFF);
            } else {
               this.drawButton(context, this.actionButton, mouseX, mouseY,
                  "BUY  \u2605 " + cape.rarity().price(), afford ? 0xFF4A9CFF : 0x44FFFFFF,
                  afford ? DesignTokens.textHi() : DesignTokens.textMid());
            }
         } else {
            this.drawButton(context, new Rect(gridX, barY, btnW, btnH), mouseX, mouseY,
               "GRANTED ONLY", 0x33FFFFFF, DesignTokens.textMid());
         }
      }

      // ---------- help popup ----------
      if (this.helpOpen) {
         context.fill(0, 0, w, h, 0x66000000);
         int popW = Math.min(320, w - 20);
         String[] lines = {
            "Blue Stars: +1 per minute online on Blue",
            "Network - AFK counts.",
            "",
            "Cape prices: Common \u2605300, Uncommon \u2605600,",
            "Rare \u26051200, Epic \u26052400, Legendary \u26054800.",
            "EXCLUSIVE capes are granted by the owner and",
            "can never be bought.",
            "",
            "Click a cape to try it on - hover for a live",
            "preview on the mannequin. Heart = favorite.",
            "BUY needs a second CONFIRM click.",
            "",
            "Sorting: Owned, Unowned, Favorites, A-Z, Z-A.",
            "",
            "Phase 1: your cape is visible to you; other",
            "players see it once the backend ships."
         };
         float lineH = 12.0F;
         int popH = (int) (16 + lines.length * lineH + 12);
         int popX = (w - popW) / 2;
         int popY = (h - popH) / 2;
         SmoothRect.fill(context, popX, popY, popW, popH, 12, 0xF40E121A);
         SmoothRect.outline(context, popX, popY, popW, popH, 12, 1.0F, 0x55FFFFFF);
         TextPainter.drawPoppins(context, "HOW COSMETICS WORK", popX + 12, popY + 10, DesignTokens.textHi(), 11.0F);
         this.helpCloseRect = new Rect(popX + popW - 18, popY + 8, 12, 12);
         RenderUtil.drawIcon(context, "x", this.helpCloseRect.x, this.helpCloseRect.y, 12,
            this.helpCloseRect.contains(mouseX, mouseY) ? 0xFFFFFFFF : 0xFF9DB2FF);
         float ly = popY + 26;
         for (String line : lines) {
            if (!line.isEmpty()) {
               TextPainter.drawPoppins(context, line, popX + 12, ly, DesignTokens.textMid(), 9.0F);
            }
            ly += lineH;
         }
      } else {
         this.helpCloseRect = null;
      }

      if (this.confirmTicks > 0) {
         this.confirmTicks--;
      }
   }

   private void category(DrawContext context, int x, int y, int w, String name, boolean active, String tag, int mx, int my) {
      int rowH = active ? 22 : 20;
      if (active) {
         SmoothRect.fill(context, x, y, w, rowH, 5, 0x2E4A9CFF);
         context.fill(x, y, x + 2, y + rowH, 0xFF4A9CFF);
      }
      int textColor = active ? DesignTokens.textHi() : 0x669DB2FF;
      TextPainter.drawPoppins(context, name, x + (active ? 8 : 6), y + (active ? 5 : 4), textColor, active ? 10.0F : 9.0F);
      // tag right-aligned
      String tagText = tag;
      float tagW = TextPainter.poppinsWidth(tagText, 7.0F);
      TextPainter.drawPoppins(context, tagText, x + w - tagW - 4, y + (active ? 7 : 6),
         active ? 0xFF9DB2FF : 0x449DB2FF, 7.0F);
   }

   private void drawButton(DrawContext context, Rect r, int mx, int my, String label, int body, int textColor) {
      boolean hovered = r.contains(mx, my);
      SmoothRect.fill(context, r.x, r.y, r.w, r.h, 6, hovered ? brighter(body) : body);
      SmoothRect.outline(context, r.x, r.y, r.w, r.h, 6, 1.0F, 0x33FFFFFF);
      float tw = TextPainter.poppinsWidth(label, 9.5F);
      TextPainter.drawPoppins(context, label, r.x + (r.w - tw) / 2, r.y + (r.h - 10) / 2, textColor, 9.5F);
   }

   private static int brighter(int argb) {
      int a = (argb >>> 24) & 0xFF;
      int r = Math.min(255, (int) (((argb >>> 16) & 0xFF) * 1.25F));
      int g = Math.min(255, (int) (((argb >>> 8) & 0xFF) * 1.25F));
      int b = Math.min(255, (int) ((argb & 0xFF) * 1.25F));
      return (a << 24) | (r << 16) | (g << 8) | b;
   }

   /* ---------------- input ---------------- */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) click.x();
      int my = (int) click.y();
      var profile = CosmeticsManager.profileStatic();

      // help popup swallows all clicks while open
      if (this.helpOpen) {
         if (this.helpCloseRect != null && this.helpCloseRect.contains(mx, my)) {
            this.helpOpen = false;
            RenderUtil.clickSound();
            return true;
         }
         return true;
      }
      if (this.helpRect != null && this.helpRect.contains(mx, my)) {
         this.helpOpen = true;
         RenderUtil.clickSound();
         return true;
      }
      if (this.rotateRect != null && this.rotateRect.contains(mx, my)) {
         this.autoRotate = !this.autoRotate;
         this.yawVel = 0.0F;
         RenderUtil.clickSound();
         return true;
      }
      if (this.searchRect != null && this.searchRect.contains(mx, my)) {
         this.searchFocus = true;
         RenderUtil.clickSound();
         return true;
      }
      if (this.searchRect != null && !this.searchRect.contains(mx, my)) {
         this.searchFocus = false;
      }
      if (this.sortRect != null && this.sortRect.contains(mx, my)) {
         Sort[] values = Sort.values();
         this.sort = values[(this.sort.ordinal() + 1) % values.length];
         RenderUtil.clickSound();
         return true;
      }

      List<Cape> shown = this.visibleCapes();

      // hearts (favorite toggle) - checked before tiles so they win
      for (int i = 0; i < this.hearts.size() && i < shown.size(); i++) {
         if (this.hearts.get(i).contains(mx, my)) {
            profile.toggleFavorite(shown.get(i).id());
            RenderUtil.clickSound();
            return true;
         }
      }

      for (int i = 0; i < this.tiles.size() && i < shown.size(); i++) {
         if (this.tiles.get(i).contains(mx, my)) {
            this.selected = shown.get(i);
            this.confirmTicks = 0;
            RenderUtil.clickSound();
            CosmeticsManager.preview(this.selected);
            return true;
         }
      }

      if (this.showcaseRect != null && this.showcaseRect.contains(mx, my) && click.button() == 0) {
         this.rotating = true; // drag the mannequin to spin it
         return true;
      }

      if (this.selected != null && this.actionButton != null && this.actionButton.contains(mx, my)) {
         Cape cape = this.selected;
         if (profile.owns(cape.id())) {
            profile.equip(cape.id());
            RenderUtil.clickSound();
            BlueClient.getInstance().notificationManager().add("Cape equipped: " + cape.displayName(), 0xFF4A9CFF);
         } else if (cape.rarity().purchasable()) {
            if (this.confirmTicks > 0) {
               if (profile.purchase(cape)) {
                  profile.equip(cape.id());
                  RenderUtil.clickSound();
                  BlueClient.getInstance().notificationManager().add("Cape unlocked: " + cape.displayName(), 0xFF55D65E);
               } else {
                  BlueClient.getInstance().notificationManager().add("Not enough stars", 0xFFFFC94A);
               }
               this.confirmTicks = 0;
            } else if (profile.stars() >= cape.rarity().price()) {
               this.confirmTicks = 120; // arm CONFIRM for 6s
               RenderUtil.clickSound();
            } else {
               BlueClient.getInstance().notificationManager().add("Not enough stars", 0xFFFFC94A);
            }
         }
         return true;
      }
      if (this.unequipButton != null && this.unequipButton.contains(mx, my)) {
         profile.unequip();
         RenderUtil.clickSound();
         return true;
      }
      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseDragged(Click click, double dx, double dy) {
      if (this.rotating) {
         // spin faster while dragged (auto or manual mode)
         this.yawVel = (float) Math.max(-16.0D, Math.min(16.0D, dx * 0.9D));
         return true;
      }
      return super.mouseDragged(click, dx, dy);
   }

   @Override
   public boolean mouseReleased(Click click) {
      if (this.rotating) {
         this.rotating = false;
         return true;
      }
      return super.mouseReleased(click);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.searchFocus && key == 259) { // Backspace
         if (!this.searchDraft.isEmpty()) {
            this.searchDraft = this.searchDraft.substring(0, this.searchDraft.length() - 1);
         }
         return true;
      }
      if (key == 256) { // ESC
         RenderUtil.clickSound();
         if (this.helpOpen) {
            this.helpOpen = false;
         } else if (this.searchFocus) {
            this.searchFocus = false;
         } else {
            this.back();
         }
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.searchFocus && input.isValidChar()) {
         String ch = input.asString();
         if (ch.length() == 1 && this.searchDraft.length() < 24) {
            this.searchDraft += ch;
         }
         return true;
      }
      return super.charTyped(input);
   }

   private void back() {
      CosmeticsManager.preview(null);
      this.client.setScreen(this.parent);
   }

   private static final class Rect {
      final int x;
      final int y;
      final int w;
      final int h;

      Rect(int x, int y, int w, int h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
