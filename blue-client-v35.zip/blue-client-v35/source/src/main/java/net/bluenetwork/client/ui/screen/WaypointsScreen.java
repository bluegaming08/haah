package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.material.GlassPanel;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.bluenetwork.client.util.WaypointStore;
import net.bluenetwork.client.util.WaypointStore.Waypoint;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * WaypointsScreen (v0.19.1) — waypoint manager. Opens with the
 * Waypoints module keybind (or the OPEN MENU action in its settings), and
 * replaces the old /waypoint commands: add a waypoint at your current
 * position with a custom name, or delete it — all in-game, all clickable
 * (v0.19.2: no teleport - waypoints never move the player). The HUD panel stays as the passive display.
 */
public class WaypointsScreen extends Screen {
   private static final int ROW_H = 22;
   private static final int VISIBLE_ROWS = 8;

   private final Screen parent;
   private int scroll;
   private String nameDraft = "";
   private boolean adding;
   private final List<Rect> rows = new ArrayList<>();
   private final List<Rect> delButtons = new ArrayList<>();
   private Rect addButton;
   private Rect saveButton;
   private Rect cancelButton;
   private Rect nameField;

   public WaypointsScreen(Screen parent) {
      super(Text.literal("Waypoints"));
      this.parent = parent;
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   private List<Waypoint> here() {
      MinecraftClient mc = MinecraftClient.getInstance();
      List<Waypoint> out = new ArrayList<>();
      if (mc.world == null) {
         return out;
      }
      String dim = mc.world.getRegistryKey().getValue().toString();
      for (Waypoint w : WaypointStore.all()) {
         if (w.dimension().equals(dim)) {
            out.add(w);
         }
      }
      return out;
   }

   private void back() {
      MinecraftClient mc = MinecraftClient.getInstance();
      mc.setScreen(this.parent);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.adding) {
         if (key == 257) { // Enter - save
            this.commitAdd();
            return true;
         }
         if (key == 256) { // ESC - cancel
            this.adding = false;
            this.nameDraft = "";
            RenderUtil.clickSound();
            return true;
         }
         if (key == 259 && !this.nameDraft.isEmpty()) { // Backspace
            this.nameDraft = this.nameDraft.substring(0, this.nameDraft.length() - 1);
            return true;
         }
         return true;
      }
      if (key == 256) {
         RenderUtil.clickSound();
         this.back();
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.adding && input.isValidChar()) {
         String ch = input.asString();
         if (ch.length() == 1 && ch.charAt(0) != '§' && this.nameDraft.length() < 24) {
            this.nameDraft += ch;
         }
         return true;
      }
      return super.charTyped(input);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
      int maxScroll = Math.max(0, this.here().size() - VISIBLE_ROWS);
      this.scroll = Math.max(0, Math.min(maxScroll, this.scroll - (int) Math.signum(vAmount)));
      return true;
   }

   private void commitAdd() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) {
         return;
      }
      String name = this.nameDraft.strip();
      if (name.isEmpty()) {
         name = "Waypoint " + (this.here().size() + 1);
      }
      var pos = mc.player.getBlockPos();
      String dim = mc.world.getRegistryKey().getValue().toString();
      WaypointStore.add(new Waypoint(name, pos.getX(), pos.getY(), pos.getZ(), dim));
      RenderUtil.clickSound();
      this.adding = false;
      this.nameDraft = "";
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) click.x();
      int my = (int) click.y();
      List<Waypoint> list = this.here();
      if (this.adding) {
         if (this.saveButton != null && this.saveButton.contains(mx, my)) {
            this.commitAdd();
            return true;
         }
         if (this.cancelButton != null && this.cancelButton.contains(mx, my)) {
            this.adding = false;
            this.nameDraft = "";
            RenderUtil.clickSound();
            return true;
         }
         return super.mouseClicked(click, doubled);
      }
      for (int i = 0; i < this.rows.size(); i++) {
         if (!this.rows.get(i).contains(mx, my)) {
            continue;
         }
         int idx = this.scroll + i;
         if (idx >= list.size()) {
            return true;
         }
         Waypoint w = list.get(idx);
         if (this.delButtons.get(i).contains(mx, my)) {
            RenderUtil.clickSound();
            WaypointStore.remove(w.name());
            return true;
         }
         return true;
      }
      if (this.addButton != null && this.addButton.contains(mx, my)) {
         RenderUtil.clickSound();
         this.adding = true;
         this.nameDraft = "";
         return true;
      }
      return super.mouseClicked(click, doubled);
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      MinecraftClient mc = MinecraftClient.getInstance();
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, DesignTokens.scrim());

      List<Waypoint> list = this.here();
      String dim = mc.world == null ? ""
         : mc.world.getRegistryKey().getValue().toString().replace("minecraft:", "");
      int cw = Math.max(280, Math.min(400, w - 40));
      int listH = ROW_H * Math.min(VISIBLE_ROWS, Math.max(1, list.size()));
      int bottomBar = this.adding ? 64 : 30;
      int ch = 42 + listH + bottomBar;
      int cx = (w - cw) / 2;
      int cy = (h - ch) / 2;

      GlassPanel.panel(context, cx, cy, cw, ch, 14.0F, GlassSurface.defaultSurface(), true, DesignTokens.accent());
      TextPainter.drawPoppins(context, "WAYPOINTS", cx + 16, cy + 12, DesignTokens.textHi(), 13.0F);
      String sub = list.size() + " HERE • " + dim.toUpperCase(java.util.Locale.ROOT);
      TextPainter.drawPoppins(context, sub, cx + cw - 16 - TextPainter.poppinsWidth(sub, 8.0F),
         cy + 15, DesignTokens.textMid(), 8.0F);

      this.rows.clear();
      this.delButtons.clear();
      this.addButton = null;
      this.saveButton = null;
      this.cancelButton = null;
      this.nameField = null;

      int ly = cy + 36;
      if (list.isEmpty()) {
         TextPainter.drawPoppins(context, "No waypoints in this dimension yet.",
            cx + 16, ly + 4, DesignTokens.textMid(), 8.5F);
         ly += 22;
      }
      for (int i = 0; i < VISIBLE_ROWS; i++) {
         int idx = this.scroll + i;
         if (idx >= list.size()) {
            break;
         }
         Waypoint wp = list.get(idx);
         Rect r = new Rect(cx + 10, ly, cw - 20, ROW_H - 2);
         boolean hover = r.contains(mouseX, mouseY);
         if (hover) {
            SmoothRect.fill(context, r.x, r.y, r.w, r.h, 6.0F, 0x14FFFFFF);
         }
         TextPainter.drawPoppins(context, fit(wp.name(), 120), r.x + 8, r.y + 7, DesignTokens.textHi(), 8.5F);
         String coords = wp.x() + " " + wp.y() + " " + wp.z();
         String dist = distText(wp, mc);
         Rect del = new Rect(r.x + r.w - 42, r.y + 2, 30, 16);
         boolean delHover = del.contains(mouseX, mouseY);
         TextPainter.drawPoppins(context, coords, r.x + 136, r.y + 7, DesignTokens.textMid(), 8.0F);
         if (!dist.isEmpty()) {
            TextPainter.drawPoppins(context, dist, r.x + r.w - 78, r.y + 7, DesignTokens.textMid(), 8.0F);
         }
         SmoothRect.fill(context, del.x, del.y, del.w, del.h, 5.0F, delHover ? 0x40FF5C5C : 0x1AFF5C5C);
         // Rect.w is an int, so "del.w / 2" was integer division and the label
         // sat a pixel left of centre. Halve in float on both sides.
         TextPainter.drawPoppins(context, "DEL",
            del.x + del.w / 2.0F - TextPainter.poppinsWidth("DEL", 7.5F) / 2.0F,
            del.y + 5, 0xFFFFB3B3, 7.5F);
         this.rows.add(r);
         this.delButtons.add(del);
         ly += ROW_H;
      }

      int by = cy + 42 + listH + 2;
      if (this.adding) {
         // name field + save/cancel
         this.nameField = new Rect(cx + 10, by, cw - 96, 20);
         SmoothRect.fill(context, this.nameField.x, this.nameField.y, this.nameField.w, this.nameField.h, 6.0F, 0x14FFFFFF);
         String shown = this.nameDraft.isEmpty() ? "Waypoint name (default: Waypoint " + (list.size() + 1) + ")"
            : this.nameDraft + "_";
         TextPainter.drawPoppins(context, shown, this.nameField.x + 8, this.nameField.y + 6,
            this.nameDraft.isEmpty() ? DesignTokens.textMid() : DesignTokens.textHi(), 8.0F);
         this.saveButton = new Rect(cx + cw - 82, by, 36, 20);
         this.cancelButton = new Rect(cx + cw - 42, by, 32, 20);
         SmoothRect.fill(context, this.saveButton.x, this.saveButton.y, this.saveButton.w, this.saveButton.h, 6.0F,
            this.saveButton.contains(mouseX, mouseY) ? 0xFF3D6BFF : 0xCC3D6BFF);
         TextPainter.drawPoppins(context, "SAVE", this.saveButton.x + 5, this.saveButton.y + 6, 0xFFFFFFFF, 8.0F);
         SmoothRect.fill(context, this.cancelButton.x, this.cancelButton.y, this.cancelButton.w, this.cancelButton.h, 6.0F, 0x22FFFFFF);
         TextPainter.drawPoppins(context, "X", this.cancelButton.x + 13, this.cancelButton.y + 6, DesignTokens.textMid(), 8.0F);
         TextPainter.drawPoppins(context, "Added at your current position, in this dimension",
            cx + 12, by + 24, DesignTokens.textMid(), 7.0F);
      } else {
         this.addButton = new Rect(cx + 10, by, 110, 20);
         boolean addHover = this.addButton.contains(mouseX, mouseY);
         SmoothRect.fill(context, this.addButton.x, this.addButton.y, this.addButton.w, this.addButton.h, 6.0F,
            addHover ? 0xFF3D6BFF : 0xCC3D6BFF);
         TextPainter.drawPoppins(context, "+ ADD WAYPOINT", this.addButton.x + 8, this.addButton.y + 6, 0xFFFFFFFF, 8.0F);
         String hint = list.size() > VISIBLE_ROWS
            ? (this.scroll + 1) + "-" + Math.min(list.size(), this.scroll + VISIBLE_ROWS) + " / " + list.size()
            : "ESC to close";
         TextPainter.drawPoppins(context, hint, cx + cw - 12 - TextPainter.poppinsWidth(hint, 8.0F),
            by + 6, DesignTokens.textMid(), 8.0F);
      }
   }

   private static String distText(Waypoint w, MinecraftClient mc) {
      if (mc.player == null) {
         return "";
      }
      int dx = w.x() - mc.player.getBlockPos().getX();
      int dz = w.z() - mc.player.getBlockPos().getZ();
      return (int) Math.round(Math.sqrt(dx * dx + dz * dz)) + "m";
   }

   private static String fit(String text, int maxWidth) {
      if (TextPainter.poppinsWidth(text, 8.5F) <= maxWidth) {
         return text;
      }
      String t = text;
      while (t.length() > 3 && TextPainter.poppinsWidth(t + "...", 8.5F) > maxWidth) {
         t = t.substring(0, t.length() - 1);
      }
      return t + "...";
   }

   private static final class Rect {
      final int x;
      final int y;
      final int w;
      final int h;

      Rect(int x, int y, int w, int h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
