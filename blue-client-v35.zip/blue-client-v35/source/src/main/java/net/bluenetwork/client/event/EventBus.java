package net.bluenetwork.client.event;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import net.bluenetwork.client.BlueClient;

public class EventBus {
   private final Map<Class<?>, List<Consumer<?>>> listeners = new ConcurrentHashMap<>();

   public <T> void subscribe(Class<T> eventClass, Consumer<T> listener) {
      this.listeners.computeIfAbsent(eventClass, c -> new CopyOnWriteArrayList<>()).add(listener);
   }

   public <T> void post(T event) {
      List<Consumer<?>> list = this.listeners.get(event.getClass());
      if (list != null) {
         for (Consumer<?> consumer : list) {
            try {
               ((Consumer<T>)consumer).accept(event);
            } catch (Throwable var6) {
               BlueClient.LOGGER.error("Event listener failed for {}", event.getClass().getSimpleName(), var6);
            }
         }
      }
   }
}
