package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.optimization.RenderCache;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Keystrokes — 100% customizable via the shared appearance settings:
 * Background color, Background opacity (0 = transparent), Corner radius,
 * Border, Text color, plus its own "Pressed color".
 */
public class Keystrokes extends HudModule {
   private static final int KEY_SIZE = 20;
   private static final int GAP = 2;
   private final BooleanSetting showSpace = new BooleanSetting("Space bar", "Show the jump key row.", true);
   private final ColorSetting pressedColor = new ColorSetting("Pressed color", "Key color while pressed", 0x2FA5FF);

   public Keystrokes() {
      super("Keystrokes", "Shows which keys you are pressing.", Category.HUD, 4, 92);
      this.addSettings(new Setting[]{this.showSpace, this.pressedColor});
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         this.drawKey(context, "W", this.x + KEY_SIZE + GAP, this.y, mc.options.forwardKey.isPressed());
         int row2Y = this.y + KEY_SIZE + GAP;
         this.drawKey(context, "A", this.x, row2Y, mc.options.leftKey.isPressed());
         this.drawKey(context, "S", this.x + KEY_SIZE + GAP, row2Y, mc.options.backKey.isPressed());
         this.drawKey(context, "D", this.x + 2 * (KEY_SIZE + GAP), row2Y, mc.options.rightKey.isPressed());
         if (this.showSpace.get()) {
            int row3Y = row2Y + KEY_SIZE + GAP;
            this.drawSpaceBar(context, row3Y, mc.options.jumpKey.isPressed());
         }
      }
   }

   private void drawKey(DrawContext context, String label, int keyX, int keyY, boolean pressed) {
      this.drawKeyPanel(context, keyX, keyY, KEY_SIZE, pressed);
      int textX = keyX + (KEY_SIZE - RenderCache.textWidth(label)) / 2;
      int textY = keyY + 5 + 1;
      RenderUtil.drawText(context, label, textX, textY, this.textColor());
   }

   private void drawSpaceBar(DrawContext context, int keyY, boolean pressed) {
      int width = 64;
      this.drawKeyPanel(context, this.x, keyY, width, pressed);
      String label = "SPACE";
      int textX = this.x + (width - RenderCache.textWidth(label)) / 2;
      int textY = keyY + 5 + 1;
      RenderUtil.drawText(context, label, textX, textY, this.textColor());
   }

   private void drawKeyPanel(DrawContext context, int keyX, int keyY, int width, boolean pressed) {
      long now = System.currentTimeMillis();
      float radius = this.panelRadius();
      if (pressed) {
         int accent = 0xFF000000 | this.pressedColor.currentRgb(now) & 0xFFFFFF;
         SmoothRect.fill(context, keyX, keyY, width, KEY_SIZE, radius, accent);
         SmoothRect.outline(context, keyX, keyY, width, KEY_SIZE, radius, 1.0F, 0x80FFFFFF);
      } else {
         if (this.panelBackground()) {
            SmoothRect.fill(context, keyX, keyY, width, KEY_SIZE, radius, this.panelBodyArgb());
         }
         if (this.panelBorderEnabled()) {
            SmoothRect.outline(context, keyX, keyY, width, KEY_SIZE, radius, 1.0F, this.panelBorderArgb());
         }
      }
   }

   @Override
   public int getWidth() {
      return 64;
   }

   @Override
   public int getHeight() {
      int rows = this.showSpace.get() ? 3 : 2;
      return KEY_SIZE * rows + GAP * (rows - 1);
   }
}
