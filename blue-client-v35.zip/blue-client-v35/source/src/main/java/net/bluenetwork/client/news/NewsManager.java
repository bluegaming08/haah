package net.bluenetwork.client.news;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;

public class NewsManager {
   private static final String NEWS_URL = "https://raw.githubusercontent.com/BlueNetwork/blueclient-news/main/news.json";
   private static final long REFRESH_MS = TimeUnit.HOURS.toMillis(6L);
   private final Path cacheFile;
   private volatile List<NewsManager.NewsEntry> entries = offlineDefaults();
   private volatile long lastFetch = 0L;
   private final AtomicBoolean fetching = new AtomicBoolean(false);

   public NewsManager() {
      this.cacheFile = FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("news-cache.json");
      this.loadFromCache();
   }

   public List<NewsManager.NewsEntry> getEntries() {
      return this.entries;
   }

   public void refreshIfStaleAsync() {
      if (!this.fetching.get() && System.currentTimeMillis() - this.lastFetch >= REFRESH_MS) {
         this.lastFetch = System.currentTimeMillis();
         if (this.fetching.compareAndSet(false, true)) {
            Thread thread = new Thread(this::fetch, "BlueClient-News");
            thread.setDaemon(true);
            thread.start();
         }
      }
   }

   private void fetch() {
      try {
         HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
         HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://raw.githubusercontent.com/BlueNetwork/blueclient-news/main/news.json"))
            .timeout(Duration.ofSeconds(5L))
            .GET()
            .build();
         HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
         if (response.statusCode() / 100 != 2) {
            throw new IllegalStateException("HTTP " + response.statusCode());
         }

         List<NewsManager.NewsEntry> parsed = this.parse(response.body());
         if (!parsed.isEmpty()) {
            this.entries = List.copyOf(parsed);
            this.saveToCache(response.body());
            BlueClient.LOGGER.info("News feed updated ({} entries)", parsed.size());
         }
      } catch (Throwable var8) {
         BlueClient.LOGGER.debug("News fetch failed, using cached entries", var8);
      } finally {
         this.fetching.set(false);
      }
   }

   private List<NewsManager.NewsEntry> parse(String json) {
      JsonArray array = JsonParser.parseString(json).getAsJsonArray();
      List<NewsManager.NewsEntry> result = new ArrayList<>();

      for (JsonElement element : array) {
         if (element.isJsonPrimitive()) {
            result.add(new NewsManager.NewsEntry(element.getAsString()));
         } else {
            JsonElement text = element.getAsJsonObject().get("text");
            if (text != null && text.isJsonPrimitive()) {
               result.add(new NewsManager.NewsEntry(text.getAsString()));
            }
         }
      }

      return result;
   }

   private void saveToCache(String rawJson) {
      try {
         Files.createDirectories(this.cacheFile.getParent());
         Files.writeString(this.cacheFile, rawJson, StandardCharsets.UTF_8);
      } catch (Throwable var3) {
         BlueClient.LOGGER.debug("News cache write failed", var3);
      }
   }

   private void loadFromCache() {
      try {
         if (Files.exists(this.cacheFile)) {
            List<NewsManager.NewsEntry> cached = this.parse(Files.readString(this.cacheFile, StandardCharsets.UTF_8));
            if (!cached.isEmpty()) {
               this.entries = List.copyOf(cached);
            }
         }
      } catch (Throwable var2) {
         BlueClient.LOGGER.debug("News cache read failed", var2);
      }
   }

   private static List<NewsManager.NewsEntry> offlineDefaults() {
      return List.of(
         new NewsManager.NewsEntry("Blue Client is installed!"),
         new NewsManager.NewsEntry("Press Right Shift in game"),
         new NewsManager.NewsEntry("to open the click-GUI."),
         new NewsManager.NewsEntry("Launcher coming soon.")
      );
   }

   public record NewsEntry(String text) {
   }
}
