package net.bluenetwork.client.hud.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.StringSetting;
import net.minecraft.client.gui.DrawContext;

/**
 * Session Notes (v3 catalogue H4) — a small always-on notepad overlay. The
 * note text is a persisted string setting, so whatever you type in the module
 * settings stays between sessions. Empty notes render nothing.
 */
public class SessionNotes extends HudModule {
   private final StringSetting note = new StringSetting("Note", "Your note (\\n = new line)", "");
   private final ColorSetting textColor = new ColorSetting("Text color", "Note colour", 0xFFFFFFFF);
   private final BooleanSetting showTimestamp = new BooleanSetting("Show time", "Stamp the note with the current time", false);

   public SessionNotes() {
      super("Session Notes", "Quick persistent notepad overlay", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.note, this.textColor, this.showTimestamp});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_LEFT, 6, 6);
   }

   private List<String> lines() {
      String text = this.note.get() == null ? "" : this.note.get();
      List<String> out = new java.util.ArrayList<>();
      if (this.showTimestamp.get()) {
         out.add(java.time.LocalTime.now().withSecond(0).withNano(0).toString());
      }
      if (!text.isEmpty()) {
         String[] raw = text.split("\\\\n", -1);
         if (raw.length == 1) {
            raw = text.split("\n", -1);
         }
         for (String part : raw) {
            if (!part.isEmpty() || raw.length > 1) {
               out.add(part);
            }
         }
      }
      return out;
   }

   @Override
   public void render(DrawContext context) {
      List<String> lines = this.lines();
      if (lines.isEmpty()) {
         return;
      }
      this.drawPanel(context);
      int ty = this.y + 6;
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      for (String line : lines) {
         RenderUtil.drawText(context, line.isEmpty() ? " " : line, this.x + 6 + 2, ty, color);
         ty += 9;
      }
   }

   @Override
   public int getWidth() {
      int max = 0;
      for (String line : this.lines()) {
         max = Math.max(max, RenderUtil.textWidth(line));
      }
      return Math.max(20, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = this.lines().size();
      return Math.max(21, rows * 9 + 12);
   }
}
