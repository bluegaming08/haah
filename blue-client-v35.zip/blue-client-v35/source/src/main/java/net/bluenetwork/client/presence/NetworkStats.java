package net.bluenetwork.client.presence;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;

public final class NetworkStats {
   private static final String COUNT_URL = "https://solene-2ebf28bd.base44.app/functions/bluePresenceCount";
   private static final long REFRESH_MS = 60000L;
   private static final AtomicInteger onlineCount = new AtomicInteger(-1);
   private static volatile long lastFetch;
   private static volatile boolean fetching;
   private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4L)).build();

   private NetworkStats() {
   }

   public static int onlineCount() {
      long now = System.currentTimeMillis();
      if (!fetching && now - lastFetch > 60000L) {
         fetching = true;
         lastFetch = now;
         Thread thread = new Thread(
            () -> {
               try {
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create("https://solene-2ebf28bd.base44.app/functions/bluePresenceCount"))
                     .timeout(Duration.ofSeconds(5L))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString("{}"))
                     .build();
                  HttpResponse<String> response = HTTP.send(request, BodyHandlers.ofString());
                  if (response.statusCode() == 200) {
                     JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                     if (json.has("count")) {
                        onlineCount.set(json.get("count").getAsInt());
                     }
                  }
               } catch (Throwable var6) {
               } finally {
                  fetching = false;
               }
            },
            "Blue Network Stats"
         );
         thread.setDaemon(true);
         thread.start();
      }

      return onlineCount.get();
   }
}
