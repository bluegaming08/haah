package net.bluenetwork.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class StringSetting extends Setting<String> {
   private String value;

   public StringSetting(String name, String description, String defaultValue) {
      super(name, description, defaultValue);
      this.value = defaultValue == null ? "" : defaultValue;
   }

   public String get() {
      return this.value;
   }

   public void set(String value) {
      this.value = value == null ? "" : value;
      super.set(this.value);
   }

   public void type(String character) {
      if (this.value.length() + character.length() <= 512) {
         this.set(this.value + character);
      }
   }

   public void backspace() {
      if (!this.value.isEmpty()) {
         this.set(this.value.substring(0, this.value.length() - 1));
      }
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.value);
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
         this.value = element.getAsString();
      }
   }
}
