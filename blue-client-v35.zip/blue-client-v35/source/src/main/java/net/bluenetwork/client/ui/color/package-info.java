/**
 * Blue Client v2 UI — {@code color} layer. Scaffolded in Phase 0, populated in
 * Phase 1+ per BLUE_CLIENT_V2_REDESIGN_PLAN.md.
 */
package net.bluenetwork.client.ui.color;
