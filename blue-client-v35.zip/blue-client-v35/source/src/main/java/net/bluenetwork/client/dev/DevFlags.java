package net.bluenetwork.client.dev;

/**
 * Dev-mode switches. Everything here is inert unless the client is launched
 * with {@code -Dblueclient.dev=true} (see Phase 0 README). Nothing in this
 * package ever runs for normal users.
 */
public final class DevFlags {
   private static final String PROP = "blueclient.dev";

   private DevFlags() {
   }

   /** True when the client was started with -Dblueclient.dev=true. */
   public static boolean enabled() {
      return Boolean.getBoolean(PROP);
   }
}
