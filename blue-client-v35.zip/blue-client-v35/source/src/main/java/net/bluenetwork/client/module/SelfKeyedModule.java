package net.bluenetwork.client.module;

/**
 * Marker for modules that handle their own keybind presses (hold AND toggle
 * semantics) instead of letting {@code KeybindManager} toggle/enable them.
 *
 * <p>Added for the v0.16.1 Zoom rework: zoom can be a HOLD key (Zoomify
 * "hold" mode) or a TOGGLE key (press once to zoom, press again to release),
 * and neither maps onto the manager's "toggle on press / hold-enable on
 * press + disable on release" behaviour, so the manager skips self-keyed
 * modules entirely and the module reads the key itself.</p>
 */
public interface SelfKeyedModule {
}
