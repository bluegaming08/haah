package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.brand.BlueBrand;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Puts the Blue Client badge next to names in the tab list.
 *
 * <h2>v0.24.3 — "it doesnt have the logo in tab tho"</h2>
 *
 * The injection point was always correct ({@code getPlayerName} feeds
 * {@code ScoreDisplayEntry.name}, which the tab list draws). The badge was
 * missing because of the GATE, not the hook:
 *
 * <p>{@code PresenceManager.isBlueClientUser} only returns true for yourself
 * when {@code mc.player} is non-null, but it also only ever populates the
 * remote-user set while {@code getCurrentServerEntry() != null}. In singleplayer
 * — and on any server while the presence backend is unreachable, which is the
 * normal case since no backend is deployed — the set stays empty. Worse, the
 * comparison used {@code entry.getProfile().id()}, and a tab entry's profile id
 * can differ from {@code mc.player.getUuid()} on servers that rewrite profiles
 * (most proxies/NPC plugins), so even the self-check failed.</p>
 *
 * <p>Fix: resolve "is this me?" locally and by NAME as well as UUID, and let
 * the presence backend only ADD to that. The owner's requirement — "for now
 * make it only for the user himself if no backend is linked" — is now
 * guaranteed rather than dependent on a network call.</p>
 */
@Mixin({PlayerListHud.class})
public abstract class PlayerListHudMixin {
   @Inject(
      method = {"getPlayerName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void blueclient$tabIcon(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
      Text name = cir.getReturnValue();
      if (name == null || entry == null) {
         return;
      }
      if (!net.bluenetwork.client.module.impl.BlueLogo.showInTab()) {
         return;
      }
      // Never double-badge (see PlayerEntityRendererMixin's bridge-method note).
      if (name.getString().contains(BlueBrand.ICON_GLYPH)) {
         return;
      }
      if (!blueclient$isBlueUser(entry)) {
         return;
      }
      cir.setReturnValue(net.bluenetwork.client.module.impl.BlueLogo.logoOnLeft()
         ? BlueBrand.withIconLeft(name)
         : BlueBrand.withIcon(name));
   }

   /**
    * True when this tab entry should carry the badge.
    *
    * <p>Self-detection is done by UUID <i>or</i> name because proxies commonly
    * hand out a different profile id in the player list than the one the client
    * knows itself by.</p>
    */
   @org.spongepowered.asm.mixin.Unique
   private static boolean blueclient$isBlueUser(PlayerListEntry entry) {
      try {
         com.mojang.authlib.GameProfile profile = entry.getProfile();
         if (profile == null) {
            return false;
         }
         net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
         if (mc != null && mc.player != null) {
            if (profile.id() != null && profile.id().equals(mc.player.getUuid())) {
               return true;
            }
            String self = mc.player.getGameProfile().name();
            if (self != null && self.equalsIgnoreCase(profile.name())) {
               return true;
            }
         }
         // Anyone the presence backend has confirmed (no-op with no backend).
         return profile.id() != null
            && BlueClient.getInstance().presence().isBlueClientUser(profile.id());
      } catch (Throwable ignored) {
         return false;
      }
   }
}
