package net.bluenetwork.client.hud.impl;

import java.util.ArrayDeque;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * FPS Graph (v3 catalogue A11) — rolling frame-time graph + current FPS.
 * Samples real time between HUD renders (this render pass runs once per
 * frame), so the history is a genuine frame-time trace.
 */
public class FpsGraph extends HudModule {
   private final ColorSetting lineColor = new ColorSetting("Line color", "Bar colour", 0xFF9BE7FF);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "Colour of frames slower than the target", 0xFFFF5C5C);
   private final NumberSetting history = new NumberSetting("History", "How many frames to keep", 60.0, 20.0, 240.0, 10.0);
   private final BooleanSetting showFps = new BooleanSetting("Show FPS", "Draw the current FPS + ms above the graph", true);
   private final NumberSetting frameBudget = new NumberSetting("Target ms", "Frames slower than this (ms) are drawn in warn colour", 16.7, 4.0, 100.0, 0.1);

   private final ArrayDeque<Float> samples = new ArrayDeque<>();
   private long lastSampleNanos = 0L;
   private int lastFps = 0;

   public FpsGraph() {
      super("FPS Graph", "Rolling frame-time graph", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.lineColor, this.warnColor, this.history, this.showFps, this.frameBudget});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 126);
   }

   private void sampleFrame() {
      long now = System.nanoTime();
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null) {
         this.lastFps = (int) Math.round(mc.getCurrentFps());
      }
      if (this.lastSampleNanos > 0L) {
         float ms = (float) ((now - this.lastSampleNanos) / 1_000_000.0);
         int cap = (int) Math.round(this.history.get());
         if (this.samples.size() >= cap) {
            this.samples.pollFirst();
         }
         this.samples.addLast(Math.min(ms, 1000.0F));
      }
      this.lastSampleNanos = now;
   }

   private float maxSample() {
      float max = 1.0F;
      for (Float f : this.samples) {
         if (f != null && f > max) {
            max = f;
         }
      }
      return max;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.sampleFrame();
      int panelW = this.getWidth();
      int panelH = this.getHeight();
      this.drawPanel(context, panelW, panelH);

      int top = this.y + 4;
      int graphTop = top + (this.showFps.get() ? 12 : 0);
      int graphW = panelW - 12;
      int graphH = this.getHeight() - (this.showFps.get() ? 16 : 8);
      if (graphH > 0 && graphW > 0 && !this.samples.isEmpty()) {
         float maxMs = Math.max(1.0F, this.maxSample());
         int n = this.samples.size();
         float barW = Math.max(1.0F, (float) graphW / n);
         int i = 0;
         for (Float f : this.samples) {
            if (f == null) {
               i++;
               continue;
            }
            float ratio = Math.min(1.0F, f / maxMs);
            int h = Math.max(1, (int) Math.floor(ratio * graphH));
            int x0 = this.x + 6 + (int) Math.floor(i * barW);
            boolean slow = f > this.frameBudget.get();
            int color = slow ? this.warnColor.currentRgb(System.currentTimeMillis()) : this.lineColor.currentRgb(System.currentTimeMillis());
            context.fill(x0, graphTop + graphH - h, x0 + Math.max(1, (int) Math.ceil(barW - 1.0F)), graphTop + graphH, color);
            i++;
         }
      }

      if (this.showFps.get()) {
         String head = this.lastFps + " FPS";
         RenderUtil.drawText(context, head, this.x + 6 + 2, top, 0xFFFFFFFF);
      }
   }

   @Override
   public int getWidth() {
      int plot = Math.max(60, Math.min(140, (int) Math.round(this.history.get())));
      return plot + 12 + 2;
   }

   @Override
   public int getHeight() {
      return (this.showFps.get() ? 34 : 26);
   }
}
