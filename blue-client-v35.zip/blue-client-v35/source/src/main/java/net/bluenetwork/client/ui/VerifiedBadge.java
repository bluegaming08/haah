package net.bluenetwork.client.ui;

import net.bluenetwork.client.render.SmoothRect;
import net.minecraft.client.gui.DrawContext;

/**
 * The verified badge: a blue seal with a white tick, drawn as geometry.
 *
 * <h2>Why this is not just a text character</h2>
 * v21 drew the tick as the Unicode character U+2713 through the Poppins
 * renderer. <b>None of the three bundled fonts contain that glyph</b>
 * (checked with fontTools against poppins-semibold, poppins-medium and
 * minecraft-five-bold) - so it silently rendered as nothing at all. That is
 * the owner's "the blue check mark isn't working".
 *
 * <p>Drawing it from primitives removes the dependency on font coverage
 * entirely: it cannot regress if the font is swapped, it scales to any size
 * without a bigger atlas, and it looks identical on every machine.</p>
 *
 * <h2>Where it appears</h2>
 * Everywhere a name appears: the Social lists, posts, replies, the
 * leaderboard, profiles, and in-world nametags. The nametag path cannot use
 * this class (it builds a {@code Text}, not a draw call), so it uses
 * {@link #NAMETAG_GLYPH} instead - a character that IS in the vanilla font.
 */
public final class VerifiedBadge {

   /** Twitter-style verification blue. */
   public static final int BLUE = 0xFF2FA5FF;

   /**
    * Fallback for contexts that can only take text, such as in-world
    * nametags built from {@code Text} components.
    *
    * <p>U+2714 (heavy check) is covered by Minecraft's own Unicode font, so
    * unlike U+2713 in Poppins it actually renders. Verified with the font
    * audit described above.</p>
    */
   public static final String NAMETAG_GLYPH = "\u2714";

   private VerifiedBadge() {
   }

   /** Width this badge occupies at {@code size} - it is square. */
   public static float widthFor(float size) {
      return size;
   }

   /**
    * Draws the badge with its top-left at {@code x, y}.
    *
    * @param size box size in pixels; 9-10 suits body text
    * @return the width drawn, so callers can advance a cursor
    */
   public static float draw(DrawContext ctx, float x, float y, float size) {
      return draw(ctx, x, y, size, BLUE);
   }

   /**
    * Optical baseline nudge, as a fraction of the badge size.
    *
    * <p>The badge is a square drawn from its TOP edge, but the text beside it
    * sits on a baseline with most of its mass lower down. Aligning the two
    * tops makes the badge look like it is floating above the name, which is
    * what the owner saw. Pushing it down by a fraction of its own size keeps
    * the correction proportional at every call site instead of needing a
    * hand-tuned offset in each of the seven places it is drawn.</p>
    */
   private static final float BASELINE_NUDGE = 0.22F;

   /** As {@link #draw}, with a custom seal colour. */
   public static float draw(DrawContext ctx, float x, float y, float size, int colour) {
      // Apply the optical nudge once, here, so every caller benefits.
      y += size * BASELINE_NUDGE;
      // The seal. A high corner radius on a square reads as a circle at the
      // sizes this is used at, and costs one quad instead of a triangle fan.
      SmoothRect.fill(ctx, x, y, size, size, size / 2.0F, colour);

      // The tick, as two strokes of a thickness that scales with the badge.
      // Rounded to whole pixels so it stays crisp rather than blurring across
      // two rows at small sizes.
      int thick = Math.max(1, Math.round(size / 7.0F));
      float cx = x + size / 2.0F;
      float cy = y + size / 2.0F;

      // Short down-right stroke, then the long up-right stroke. Both are drawn
      // as stacked 1px squares stepping diagonally - at these sizes that is
      // indistinguishable from a real line and needs no rotation support.
      int shortLen = Math.max(2, Math.round(size * 0.22F));
      int longLen = Math.max(3, Math.round(size * 0.34F));

      float sx = cx - size * 0.17F;
      float sy = cy + size * 0.10F;

      for (int i = 0; i < shortLen; i++) {
         ctx.fill(Math.round(sx - shortLen + i), Math.round(sy - shortLen + i),
            Math.round(sx - shortLen + i) + thick,
            Math.round(sy - shortLen + i) + thick, 0xFFFFFFFF);
      }
      for (int i = 0; i < longLen; i++) {
         ctx.fill(Math.round(sx + i), Math.round(sy - i),
            Math.round(sx + i) + thick,
            Math.round(sy - i) + thick, 0xFFFFFFFF);
      }
      return size;
   }

   /** Draws the badge centred on a point. */
   public static void drawCentred(DrawContext ctx, float centreX, float centreY,
                                  float size) {
      draw(ctx, centreX - size / 2.0F, centreY - size / 2.0F, size);
   }
}
