package net.bluenetwork.client.mixin;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.thread.NameableExecutor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Chunk-build worker thread boost (Settings &gt; Performance &gt; Chunk Builder
 * Threads). Vanilla mesh-builds chunk sections on the shared main worker pool;
 * giving the ChunkBuilder a larger dedicated pool keeps chunk generation and
 * rebuilds from starving the render thread, so flying / fast turning stays
 * smooth. Skipped entirely when Sodium is installed - Sodium replaces the
 * chunk builder with its own, and we must not fight it over threads.
 */
@Mixin({WorldRenderer.class})
public abstract class WorldRendererMixin {
   private static ExecutorService previousPool;

   /**
    * Block Overlay — replaces the vanilla crosshair-block outline with a
    * configurable colour / opacity / thickness box.
    *
    * <h3>v0.24.0 FIX: "block overlay is broken"</h3>
    * Three separate bugs, all found by reading vanilla's own
    * {@code drawBlockOutline} bytecode with {@code javap -c}:
    * <ol>
    *   <li><b>The outline was invisible.</b> The old code called
    *       {@code VertexRendering.drawOutline(..., argb & 0xFFFFFF, alpha)}.
    *       That signature is {@code (..., int color, float lineWidth)} — the
    *       last float is LINE WIDTH, not alpha. So we passed a colour whose
    *       alpha byte was masked to 0 (fully transparent) and a line width of
    *       about 0.2–1.0. Vanilla passes {@code ColorHelper.fromFloats(1,1,1,1)}
    *       and a real width. We now pass the full ARGB and a genuine width.</li>
    *   <li><b>The third parameter is not "is a block targeted".</b> It is
    *       {@code isTranslucent}: vanilla calls this method once per render
    *       pass and returns early unless it matches
    *       {@code outlineRenderState.isTranslucent()}. Reading it as a
    *       "has block" flag made the overlay draw in the wrong pass, or twice.</li>
    *   <li><b>It used {@code mc.crosshairTarget} instead of the render state.</b>
    *       The render state is the snapshot vanilla is drawing right now;
    *       crosshairTarget is updated on the tick thread, so on a fast turn the
    *       outline lagged a frame behind the block.</li>
    * </ol>
    * The fix mirrors vanilla's control flow exactly and changes only the colour
    * and the line width.
    */
   @Inject(
      method = {"renderTargetBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void blueclient$customBlockOutline(net.minecraft.client.render.VertexConsumerProvider.Immediate immediate,
                                              net.minecraft.client.util.math.MatrixStack matrices,
                                              boolean translucentPass,
                                              net.minecraft.client.render.state.WorldRenderState state,
                                              CallbackInfo ci) {
      if (!net.bluenetwork.client.module.impl.BlockOverlay.active()) {
         return;                                  // module off: vanilla draws
      }
      net.minecraft.client.render.state.OutlineRenderState outline = state.outlineRenderState;
      if (outline == null) {
         return;                                  // nothing targeted
      }
      // The same pass guard vanilla uses; without it we draw in both passes.
      if (outline.isTranslucent() != translucentPass) {
         ci.cancel();
         return;
      }

      ci.cancel();                                // we are taking over the draw
      try {
         var cameraPos = state.cameraRenderState.pos;
         var pos = outline.pos();
         int argb = net.bluenetwork.client.module.impl.BlockOverlay.outlineArgb();
         float lineWidth = net.bluenetwork.client.module.impl.BlockOverlay.lineWidth();

         net.minecraft.client.render.VertexRendering.drawOutline(
            matrices,
            immediate.getBuffer(net.minecraft.client.render.RenderLayers.lines()),
            outline.shape(),
            pos.getX() - cameraPos.x,
            pos.getY() - cameraPos.y,
            pos.getZ() - cameraPos.z,
            argb,                                 // full ARGB, alpha included
            lineWidth);                           // this parameter is WIDTH
      } catch (Throwable t) {
         // A cosmetic outline must never break world rendering.
      }
   }

   /**
    * Hitboxes module — draws entity hitbox outlines.
    *
    * <p>Injected at the TAIL of {@code renderTargetBlockOutline} rather than at
    * a dedicated entity hook because this is the one place in world rendering
    * that already hands us everything needed: a {@link MatrixStack} in
    * camera-relative space, an {@code Immediate} vertex provider, and the
    * camera position via the world render state. Vanilla's own hitbox drawing
    * lives in the debug renderer (F3+B) and shows every entity with extra
    * clutter, so we do not reuse it.</p>
    *
    * <p>Guarded to the opaque pass so the boxes are only emitted once per
    * frame — this method is called once per pass.</p>
    */
   @Inject(
      method = {"renderTargetBlockOutline"},
      at = {@At("TAIL")},
      require = 0
   )
   private void blueclient$renderHitboxes(net.minecraft.client.render.VertexConsumerProvider.Immediate immediate,
                                          net.minecraft.client.util.math.MatrixStack matrices,
                                          boolean translucentPass,
                                          net.minecraft.client.render.state.WorldRenderState state,
                                          CallbackInfo ci) {
      if (translucentPass) {
         return;                                  // opaque pass only: draw once
      }
      try {
         net.bluenetwork.client.render.HitboxRenderer.render(immediate, matrices, state);
      } catch (Throwable t) {
         // Cosmetic only - never break world rendering.
      }
   }

   @ModifyExpressionValue(
      method = {"reload()V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/thread/Util;getMainWorkerExecutor()Lnet/minecraft/util/thread/NameableExecutor;"
      ),
      require = 0
   )
   private NameableExecutor blueclient$chunkThreadBoost(NameableExecutor original) {
      try {
         if (FabricLoader.getInstance().isModLoaded("sodium")) {
            return original;
         }
         int boost = BlueClient.getInstance().settings().chunkThreads();
         boolean preloadBoost = net.bluenetwork.client.optimization.ChunkPreloader.boostThreads();
         if (boost <= 0 && !preloadBoost) {
            return original;
         }
         int extra = boost <= 1 ? 2 : (boost == 2 ? 4 : 8);
         if (preloadBoost) {
            extra += 4;
         }
         int threads = Math.max(2, Runtime.getRuntime().availableProcessors() + extra);
         ExecutorService pool = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "Blue Client Chunk Builder");
            t.setPriority(Thread.NORM_PRIORITY - 1);
            t.setDaemon(true);
            return t;
         });
         ExecutorService old = previousPool;
         previousPool = pool;
         if (old != null) {
            old.shutdown();
         }
         return new NameableExecutor(pool);
      } catch (Throwable t) {
         return original;
      }
   }
}
