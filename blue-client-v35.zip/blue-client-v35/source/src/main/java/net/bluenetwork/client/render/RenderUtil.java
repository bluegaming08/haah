package net.bluenetwork.client.render;

import net.bluenetwork.client.BlueColors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class RenderUtil {
   public static final int FONT_HEIGHT = 9;
   public static final int LOGO_VISIBLE_W = 340;
   public static final int LOGO_BOX = 512;

   private RenderUtil() {
   }

   public static void drawIcon(DrawContext context, String icon, int x, int y, int size, int color) {
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, Identifier.of("blueclient", "icon/" + icon), x, y, size, size, color);
   }

   /**
    * The brand logo sprite for the CURRENT user.
    *
    * <p>Blue+ subscribers get the gold Blue+ mark instead, everywhere the logo
    * appears - main menu, pause menu, HUD, loading screens. Owner: "everywhere
    * that the blue logo is, it should be the plus logo" for Blue+ users.</p>
    *
    * <p>Routing this through one method is deliberate: the alternative was
    * editing a dozen call sites and missing some.</p>
    */
   private static Identifier brandSprite() {
      return net.bluenetwork.client.module.impl.BluePlusPerks.useplusLogo()
         ? Identifier.of("blueclient", "brand/blueplus")
         : Identifier.of("blueclient", "brand/logo");
   }

   public static void drawLogo(DrawContext context, int x, int y, int height) {
      int visibleW = height * 340 / 512;
      int boxX = x - (height - visibleW) / 2;
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, brandSprite(), boxX, y, height, height, -1);
   }

   /** Logo with a tint (argb) — used by the Client Logo HUD at 30% opacity. */
   public static void drawLogoTinted(DrawContext context, int x, int y, int height, int tint) {
      int visibleW = height * 340 / 512;
      int boxX = x - (height - visibleW) / 2;
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, brandSprite(), boxX, y, height, height, tint);
   }

   public static int logoWidth(int height) {
      return height * 340 / 512;
   }

   /** v0.16.8: pure-black shadow at the glyph's alpha (MiniMessage look) -
    * vanilla's drawTextWithShadow tints the shadow toward the text colour. */
   /**
    * Draws classic-font text. When the Menu Customizer's "Five Bold Font"
    * toggle is on (and we are on a menu screen), the text is drawn in
    * Minecraft Five Bold instead of the vanilla Minecraft font.
    */
   public static void drawText(DrawContext context, String text, int x, int y, int color) {
      if (fiveFontActive()) {
         BlueFont.get("minecraft-five").draw(context, text, x, y + 0.5F, color, false, 8.0F);
         return;
      }
      context.drawText(MinecraftClient.getInstance().textRenderer, Text.literal(text), x + 1, y + 1, color & 0xFF000000, false);
      context.drawText(MinecraftClient.getInstance().textRenderer, Text.literal(text), x, y, color, false);
   }

   private static boolean fiveFontActive() {
      if (!net.bluenetwork.client.module.impl.MenuCustomizer.fiveFontEnabled()) {
         return false;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc != null && mc.currentScreen != null;
   }

   public static int textWidth(String text) {
      if (fiveFontActive()) {
         return (int) Math.ceil(BlueFont.get("minecraft-five").width(text, 8.0F));
      }
      return net.bluenetwork.client.optimization.RenderCache.textWidth(text);
   }

   public static void clickSound() {
      net.bluenetwork.client.util.UiSoundController.playClick();
   }

   /** Anti-aliased rounded rect through the SDF pipeline; same signature as the old helper. */
   public static void drawRoundedRect(DrawContext context, int x, int y, int w, int h, int c, int r) {
      SmoothRect.fill(context, x, y, w, h, r, c);
   }

   public static void drawRoundedRectF(DrawContext context, float x, float y, float w, float h, int c, float r) {
      SmoothRect.fill(context, x, y, w, h, r, c);
   }

   public static void drawRoundedOutline(DrawContext context, int x, int y, int w, int h, int c, int r) {
      SmoothRect.outline(context, x, y, w, h, r, 1.0F, c);
   }

   public static void drawRoundedPanel(DrawContext context, int x, int y, int w, int h) {
      SmoothRect.panel(context, x, y, w, h, 8.0F, BlueColors.PANEL_BORDER, BlueColors.PANEL_BG);
      context.fill(x + 6, y, x + w - 6, y + 1, 822083583);
   }

   public static void drawInterText(DrawContext context, String text, int x, int y, int color) {
      drawPoppins(context, text, x, y, color, 9.0F);
   }

   public static void drawInterText(DrawContext context, String text, int x, int y, int color, float size) {
      drawPoppins(context, text, x, y, color, size);
   }

   public static int interTextWidth(String text) {
      return (int) Math.ceil(popinsWidth(text, 9.0F));
   }

   public static int interTextWidth(String text, float size) {
      return (int) Math.ceil(popinsWidth(text, size));
   }

   public static void drawPoppins(DrawContext context, String text, float x, float y, int color, float size) {
      BlueFont.get("poppins").draw(context, text, x, y, color, false, size);
   }

   public static void drawPoppinsShadow(DrawContext context, String text, float x, float y, int color, float size) {
      BlueFont.get("poppins").draw(context, text, x, y, color, true, size);
   }

   public static float popinsWidth(String text, float size) {
      return BlueFont.get("poppins").width(text, size);
   }

   /** Poppins Medium - the lighter companion weight (wordmark "CLIENT", etc.). */
   public static void drawPoppinsMediumShadow(DrawContext context, String text, float x, float y, int color, float size) {
      BlueFont.get("poppins-medium").draw(context, text, x, y, color, true, size);
   }

   public static int poppinsMediumWidth(String text, float size) {
      return (int) Math.ceil(BlueFont.get("poppins-medium").width(text, size));
   }

   public static void drawPoppinsCentered(DrawContext context, String text, float centerX, float y, int color, float size) {
      BlueFont.get("poppins").drawCentered(context, text, centerX, y, color, false, size);
   }

   public static void drawPoppinsRight(DrawContext context, String text, float rightX, float y, int color, float size) {
      BlueFont.get("poppins").drawRightAligned(context, text, rightX, y, color, false, size);
   }
}
