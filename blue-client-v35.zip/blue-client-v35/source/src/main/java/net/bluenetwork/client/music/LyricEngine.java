package net.bluenetwork.client.music;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Resolves lyrics for a track and answers "what is being sung right now".
 *
 * <h2>Provider ladder</h2>
 * Tried in order, stopping at the first usable result:
 * <ol>
 *   <li><b>NetEase yrc</b> - real per-word timestamps. The only public source
 *       that actually provides them.</li>
 *   <li><b>LRCLIB</b> - line-synced, the best line-level coverage.</li>
 *   <li><b>NetEase lrc</b> - line-synced fallback.</li>
 *   <li><b>Plain text</b> - no timing.</li>
 * </ol>
 *
 * <p>Musixmatch rich-sync sits above all of these in principle and is
 * deliberately absent: its anonymous token is all zeroes, {@code richsync.get}
 * returns 404, and the macro endpoint confidently matches the wrong song.
 * See {@link NetEaseLyrics} for the evidence. Add it here if a paid key
 * appears - the ladder will prefer it automatically.</p>
 *
 * <h2>Threading</h2>
 * {@link #resolve} performs network I/O and must run on a worker thread.
 * {@link #state} is a pure lookup against the parsed document and is safe to
 * call every frame. The parsed result is published through a single
 * {@link AtomicReference}, so the render thread always sees either the old
 * document or the new one - never a half-built one.
 */
public final class LyricEngine {

   /** What the renderer needs to draw, computed fresh each frame. */
   public record State(LyricData data, int lineIndex, LyricData.Line line,
                       int wordIndex, List<LyricData.Word> segments,
                       int segmentIndex, long positionMs) {

      public boolean hasLine() {
         return this.line != null;
      }

      /** The active segment's text, or the whole line when unsegmented. */
      public String activeText() {
         if (this.segmentIndex >= 0 && this.segmentIndex < this.segments.size()) {
            return this.segments.get(this.segmentIndex).text();
         }
         return this.line == null ? "" : this.line.text();
      }
   }

   private final AtomicReference<LyricData> current =
      new AtomicReference<>(LyricData.empty());

   /** Per-track offset in ms, applied at comparison time only. */
   private volatile long offsetMs;

   public LyricData data() {
      return this.current.get();
   }

   public void clear() {
      this.current.set(LyricData.empty());
   }

   public long offsetMs() {
      return this.offsetMs;
   }

   public void offsetMs(long ms) {
      this.offsetMs = Math.max(-5000L, Math.min(5000L, ms));
   }

   /**
    * Fetches lyrics for a track. <b>Blocking - call from a worker thread.</b>
    *
    * @param durationSec the playing track's length, for version matching
    */
   public LyricData resolve(String title, String artist, int durationSec) {
      // 1. Real word timing.
      LyricData word = NetEaseLyrics.fetch(title, artist, durationSec);
      if (word != null && word.syncType() == LyricData.SyncType.WORD) {
         this.current.set(word);
         return word;
      }

      // 2. LRCLIB, which has the best line-level coverage.
      LyricsProvider.Lyrics legacy = LyricsProvider.fetch(title, artist, durationSec);
      if (legacy != null && !legacy.lines().isEmpty() && legacy.synced()) {
         LyricData converted = fromLegacy(legacy, "LRCLIB");
         this.current.set(converted);
         return converted;
      }

      // 3. NetEase line-level, if its search matched but only had lrc.
      if (word != null && !word.isEmpty()) {
         this.current.set(word);
         return word;
      }

      // 4. Plain text, better than nothing.
      if (legacy != null && !legacy.lines().isEmpty()) {
         LyricData plain = fromLegacy(legacy, "LRCLIB (plain)");
         this.current.set(plain);
         return plain;
      }

      this.current.set(LyricData.empty());
      return LyricData.empty();
   }

   /** Adopts an already-parsed document, e.g. from the cache or a sidecar. */
   public void adopt(LyricData data) {
      this.current.set(data == null ? LyricData.empty() : data);
   }

   /** Bridges the old line-only structure into the new model. */
   private static LyricData fromLegacy(LyricsProvider.Lyrics legacy, String provider) {
      java.util.List<LyricData.Line> lines = new java.util.ArrayList<>();
      List<LyricsProvider.Line> src = legacy.lines();
      for (int i = 0; i < src.size(); i++) {
         long start = src.get(i).ms();
         long end = i + 1 < src.size() ? src.get(i + 1).ms() : -1L;
         lines.add(new LyricData.Line(start, end, src.get(i).text(), List.of()));
      }
      return new LyricData(lines,
         legacy.synced() ? LyricData.SyncType.LINE : LyricData.SyncType.PLAIN,
         provider);
   }

   /**
    * Computes what to display at an audio position.
    *
    * <p><b>Always driven by the real playback clock.</b> There is no
    * independent lyric timer, so a few laggy ticks cannot desynchronise the
    * display - the next frame simply looks up the correct position again.</p>
    *
    * @param audioPositionMs the ACTUAL audible position from the engine
    * @param wordsPerSegment 1 = one word per segment
    * @param allowEstimated  when true, lines without real word timing get
    *                        derived timings; when false they stay line-level.
    *                        Estimated words are always flagged as such.
    */
   public State state(long audioPositionMs, int wordsPerSegment,
                      boolean allowEstimated) {
      LyricData data = this.current.get();
      long pos = audioPositionMs + this.offsetMs;

      if (data.isEmpty()) {
         return new State(data, -1, null, -1, List.of(), -1, pos);
      }

      int lineIndex = data.lineIndexAt(pos);
      if (lineIndex < 0) {
         return new State(data, -1, null, -1, List.of(), -1, pos);
      }
      LyricData.Line line = data.lines().get(lineIndex);

      List<LyricData.Word> words = line.words();
      if (words.isEmpty() && allowEstimated) {
         // Explicit opt-in only. The words produced carry estimated = true.
         LyricData.Line next = data.lineAfter(lineIndex);
         long dur = line.endMs() > 0 ? line.endMs() - line.startMs()
            : (next != null ? next.startMs() - line.startMs() : 4000L);
         words = LyricData.estimateWords(line, dur);
      }

      if (words.isEmpty()) {
         // LINE sync: the whole line is the unit. Do NOT invent word positions.
         return new State(data, lineIndex, line, -1, List.of(), -1, pos);
      }

      int wordIndex = LyricData.wordIndexAt(
         new LyricData.Line(line.startMs(), line.endMs(), line.text(), words), pos);

      List<LyricData.Word> segments = LyricData.segment(
         new LyricData.Line(line.startMs(), line.endMs(), line.text(), words),
         wordsPerSegment);
      int segmentIndex = LyricData.wordIndexAt(
         new LyricData.Line(line.startMs(), line.endMs(), line.text(), segments), pos);

      return new State(data, lineIndex, line, wordIndex, segments, segmentIndex, pos);
   }
}
