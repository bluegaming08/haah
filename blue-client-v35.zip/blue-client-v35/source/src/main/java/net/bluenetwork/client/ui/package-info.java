/**
 * Blue Client v2 user-interface layer (see BLUE_CLIENT_V2_REDESIGN_PLAN.md §4.1).
 *
 * <p>Phase 0 scaffolding only: these sub-packages are declared now so the new
 * architecture is visible and stable before Phase 1 starts filling them in.
 */
package net.bluenetwork.client.ui;
