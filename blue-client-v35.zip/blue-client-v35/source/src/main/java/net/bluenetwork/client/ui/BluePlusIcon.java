package net.bluenetwork.client.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * The Blue+ mark, drawn from the owner-supplied artwork.
 *
 * <h2>Why this exists</h2>
 * The spec says the Blue+ logo is "used everywhere". Rather than repeating the
 * texture id, the 532x800 aspect ratio and the alpha handling at a dozen call
 * sites, every one of them goes through here. Change the art once and the
 * whole client follows.
 *
 * <h2>About the artwork</h2>
 * The PNG the owner linked was unusable as delivered - it had no plus mark and
 * no alpha channel, so it would have drawn as an opaque rectangle over
 * whatever was behind it. The version shipped in the jar was rebuilt locally as
 * a proper RGBA (colortype 6) image at 532x800, matching the main logo so the
 * two line up visually when shown together.
 */
public final class BluePlusIcon {

   /** The rebuilt RGBA artwork. */
   public static final Identifier TEXTURE =
      Identifier.of("blueclient", "textures/blueplus.png");

   /**
    * Source dimensions, used to keep the aspect ratio honest.
    *
    * <p>462x717 after processing. The owner's PNG arrived as 532x800 RGB with
    * NO alpha - a gold "B" sitting on solid black, which would have drawn as
    * an opaque black rectangle over the UI. It was keyed to transparency on a
    * luminance threshold (with a feathered edge so it stays smooth when scaled
    * down) and then cropped to the glyph, which is where these numbers come
    * from. Re-crop and update both if the art is ever replaced.</p>
    */
   private static final float SRC_W = 462.0F;
   private static final float SRC_H = 717.0F;

   /** The gold used for text accents that sit next to the mark. */
   public static final int GOLD = 0xFFFFD600;

   private BluePlusIcon() {
   }

   /** Width the mark will occupy when drawn at {@code height}. */
   public static float widthFor(float height) {
      return height * (SRC_W / SRC_H);
   }

   /**
    * Draws the mark with its top-left at {@code x, y}, scaled to {@code height}.
    *
    * @return the width drawn, so callers can advance a cursor past it
    */
   public static float draw(DrawContext ctx, float x, float y, float height) {
      float w = widthFor(height);
      // drawTexturedQuad takes integer corners, so round once here rather
      // than letting each call site truncate differently.
      int x0 = Math.round(x);
      int y0 = Math.round(y);
      ctx.drawTexturedQuad(TEXTURE, x0, y0,
         x0 + Math.max(1, Math.round(w)), y0 + Math.max(1, Math.round(height)),
         0.0F, 1.0F, 0.0F, 1.0F);
      return w;
   }

   /** Draws the mark centred on a point - handy inside buttons and rows. */
   public static void drawCentred(DrawContext ctx, float centreX, float centreY,
                                  float height) {
      float w = widthFor(height);
      ctx.drawTexturedQuad(TEXTURE,
         Math.round(centreX - w / 2.0F), Math.round(centreY - height / 2.0F),
         Math.round(centreX + w / 2.0F), Math.round(centreY + height / 2.0F),
         0.0F, 1.0F, 0.0F, 1.0F);
   }
}
