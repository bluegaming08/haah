package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;

public class BiomeHud extends HudModule {
   public BiomeHud() {
      super("Biome", "Shows the biome you are in.", Category.HUD, 60, 26);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.world != null) {
         BlockPos pos = mc.player.getBlockPos();
         String id = mc.world.getBiome(pos).getIdAsString();
         String name = id.startsWith("minecraft:") ? id.substring("minecraft:".length()) : id;
         this.drawTextPanel(context, "Biome: " + name);
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Biome: old_growth_pine_taiga") + 12 + 2;
   }
}
