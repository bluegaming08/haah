package net.bluenetwork.client.config;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.Module;

/**
 * Shareable configuration codes — the Save / Load buttons in the modules menu.
 *
 * <h2>Owner spec, verbatim</h2>
 * <pre>
 *   add a save and load button in the modules menu. save gives u a code (a big
 *   text) which u can share to ur friends, and if u paste the code and click
 *   load, all the modules that were enabled in the code should be enabled with
 *   the correct positions
 * </pre>
 *
 * <h2>Code format</h2>
 * <pre>
 *   BLUE1-H4sIAAAAAAAA...==
 * </pre>
 * <ul>
 *   <li><b>{@code BLUE1-}</b> — magic + format version. If the format ever
 *       changes, bump to {@code BLUE2} and keep a reader for {@code BLUE1};
 *       {@link #load} dispatches on this prefix.</li>
 *   <li>The rest is <b>URL-safe Base64(GZIP(payload))</b>. URL-safe matters:
 *       the code must survive being pasted into Discord, a URL or chat without
 *       a character being mangled.</li>
 * </ul>
 *
 * <h2>Payload</h2>
 * Plain text, one record per line, fields separated by {@code |}:
 * <pre>
 *   v|1                                           format marker
 *   t|BLACK                                       theme
 *   m|ModuleName|enabled                          a non-HUD module
 *   h|ModuleName|enabled|ANCHOR|offX|offY|scale   a HUD module
 * </pre>
 * Deliberately human-readable once un-gzipped, so a future agent debugging a
 * bad code can just decode and read it. Unknown line types and unknown module
 * names are <b>skipped, not errors</b> — a code from a newer build still loads
 * whatever an older build understands.
 *
 * <h2>Safety</h2>
 * Loading never throws. Anything malformed returns a {@link Result} with
 * {@code ok=false} and a human-readable message for the notification toast.
 */
public final class ProfileCode {

   /** Magic prefix + format version. */
   private static final String MAGIC = "BLUE1-";

   private ProfileCode() {
   }

   /** Outcome of a {@link #load} attempt. */
   public record Result(boolean ok, String message, int applied) {
   }

   /* ===================================================================== */
   /* Save                                                                  */
   /* ===================================================================== */

   /** Builds a shareable code from the CURRENT client state. Never null. */
   public static String save() {
      StringBuilder sb = new StringBuilder();
      sb.append("v|1\n");
      sb.append("t|").append(ThemeManager.currentTheme()).append('\n');

      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         String name = sanitize(module.getName());
         if (module instanceof HudModule hud) {
            sb.append("h|").append(name)
              .append('|').append(hud.isEnabled())
              .append('|').append(hud.getAnchor().name())
              .append('|').append(hud.getOffsetX())
              .append('|').append(hud.getOffsetY())
              .append('|').append(String.format(Locale.ROOT, "%.2f", hud.getScale()))
              .append('\n');
         } else {
            sb.append("m|").append(name)
              .append('|').append(module.isEnabled())
              .append('\n');
         }
      }
      return MAGIC + compress(sb.toString());
   }

   /* ===================================================================== */
   /* Load                                                                  */
   /* ===================================================================== */

   /**
    * Applies a pasted code.
    *
    * <p>Whitespace is stripped first: copying a long code out of Discord very
    * often introduces line breaks.</p>
    */
   public static Result load(String code) {
      if (code == null || code.isBlank()) {
         return new Result(false, "Clipboard is empty", 0);
      }
      String cleaned = code.replaceAll("\\s+", "");
      if (!cleaned.startsWith(MAGIC)) {
         return new Result(false, "Not a Blue Client code (must start with " + MAGIC + ")", 0);
      }

      String payload;
      try {
         payload = decompress(cleaned.substring(MAGIC.length()));
      } catch (Exception e) {
         return new Result(false, "Code is corrupted or incomplete", 0);
      }

      int applied = 0;
      for (String line : payload.split("\n")) {
         if (line.isBlank()) {
            continue;
         }
         String[] f = line.split("\\|", -1);
         try {
            switch (f[0]) {
               case "t" -> {
                  if (f.length >= 2) {
                     BlueClient.getInstance().settings().theme(f[1]);
                  }
               }
               case "m" -> {
                  if (f.length >= 3 && applyEnabled(f[1], Boolean.parseBoolean(f[2]))) {
                     applied++;
                  }
               }
               case "h" -> {
                  if (f.length >= 6 && applyHud(f)) {
                     applied++;
                  }
               }
               default -> {
                  // "v" and anything from a future format: ignored on purpose.
               }
            }
         } catch (Exception ignored) {
            // One bad line must never abort the whole load.
         }
      }

      BlueClient.getInstance().configManager().save();
      return new Result(true, "Loaded " + applied + " modules", applied);
   }

   private static boolean applyEnabled(String name, boolean enabled) {
      Module module = BlueClient.getInstance().moduleManager().byName(name);
      if (module == null) {
         return false;
      }
      if (module.isEnabled() != enabled) {
         module.setEnabled(enabled);
      }
      return true;
   }

   private static boolean applyHud(String[] f) {
      Module module = BlueClient.getInstance().moduleManager().byName(f[1]);
      if (!(module instanceof HudModule hud)) {
         return false;
      }
      boolean enabled = Boolean.parseBoolean(f[2]);
      if (hud.isEnabled() != enabled) {
         hud.setEnabled(enabled);
      }
      HudModule.Anchor anchor;
      try {
         anchor = HudModule.Anchor.valueOf(f[3]);
      } catch (IllegalArgumentException e) {
         anchor = HudModule.Anchor.TOP_LEFT;
      }
      hud.setAnchorAndOffsets(anchor, Integer.parseInt(f[4]), Integer.parseInt(f[5]));
      if (f.length >= 7) {
         hud.setScale(Float.parseFloat(f[6]));
      }
      return true;
   }

   /* ===================================================================== */
   /* Compression                                                           */
   /* ===================================================================== */

   private static String compress(String text) {
      try {
         ByteArrayOutputStream out = new ByteArrayOutputStream();
         try (GZIPOutputStream gz = new GZIPOutputStream(out)) {
            gz.write(text.getBytes(StandardCharsets.UTF_8));
         }
         return Base64.getUrlEncoder().encodeToString(out.toByteArray());
      } catch (Exception e) {
         // GZIP on an in-memory stream cannot realistically fail, but if it
         // somehow does we still hand back a usable (just longer) code.
         return Base64.getUrlEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
      }
   }

   private static String decompress(String base64) throws Exception {
      byte[] raw = Base64.getUrlDecoder().decode(base64);
      // Detect the GZIP magic so uncompressed fallback codes still load.
      if (raw.length >= 2 && (raw[0] & 0xFF) == 0x1F && (raw[1] & 0xFF) == 0x8B) {
         try (GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(raw))) {
            return new String(gz.readAllBytes(), StandardCharsets.UTF_8);
         }
      }
      return new String(raw, StandardCharsets.UTF_8);
   }

   /** Module names must not contain the field separator. */
   private static String sanitize(String name) {
      return name == null ? "" : name.replace('|', '/');
   }
}
