package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;

public class MentionHighlight extends Module {
   public MentionHighlight() {
      super("Mention Highlight", "Ping + color when your name is said", Category.MISC);
   }
}
