package net.bluenetwork.client.cosmetics;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import net.bluenetwork.client.BlueClient;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Local cosmetics save file (Phase 1 — no backend yet, see
 * README-BACKEND-COSMETICS.md). Lives at
 * {@code <config>/blueclient/cosmetics.json}. Becomes a display cache once
 * the backend exists; until then it IS the source of truth, which is why
 * one-time seeded grants (see {@link #SEEDED_GRANTS}) are tracked so they
 * can never be reapplied even if the balance is edited by hand.
 */
public final class CosmeticsProfile {
   /** username(lowercase) -> stars granted once, on first load for that username. */
   private static final java.util.Map<String, Integer> SEEDED_GRANTS = java.util.Map.of(
      "blue_kzz", 15000
   );

   /**
    * v0.21.1: the "Blue Client User" starter cape is granted ONCE to every
    * profile and auto-equipped on first grant - a fresh profile previously
    * owned NOTHING and equipped nothing, so the vanilla Mojang cape kept
    * showing in-game and in the locker showcase ("my minecraft cape is
    * still override over my blue client cape"). A later deliberate UNEQUIP
    * stays: the auto-equip only happens together with the first grant.
    */
   private static final String STARTER_CAPE = "blue_client_user";
   private static final String STARTER_GRANT_KEY = "starter:" + STARTER_CAPE;

   private final Path file;
   private int stars;
   private int lifetimeStars;
   private final Set<String> owned = new LinkedHashSet<>();
   private final Set<String> favorites = new LinkedHashSet<>();
   private String equipped;
   private final Set<String> grantsApplied = new LinkedHashSet<>();

   public CosmeticsProfile() {
      this(FabricLoader.getInstance().getConfigDir().resolve("blueclient").resolve("cosmetics.json"));
   }

   /** Test/isolated profile at an explicit path. */
   CosmeticsProfile(Path file) {
      this.file = file;
   }

   /** Dev gametest: an isolated profile that never touches the real save. */
   public static CosmeticsProfile testProfile(java.nio.file.Path file) {
      return new CosmeticsProfile(file);
   }

   public void load() {
      if (Files.exists(this.file)) {
         try {
            JsonObject root = JsonParser.parseString(Files.readString(this.file)).getAsJsonObject();
            this.stars = root.has("stars") ? root.get("stars").getAsInt() : 0;
            this.lifetimeStars = root.has("lifetimeStars") ? root.get("lifetimeStars").getAsInt() : this.stars;
            if (root.has("owned")) {
               for (var el : root.getAsJsonArray("owned")) {
                  this.owned.add(el.getAsString());
               }
            }
            if (root.has("favorites")) {
               for (var el : root.getAsJsonArray("favorites")) {
                  this.favorites.add(el.getAsString());
               }
            }
            this.equipped = root.has("equipped") && !root.get("equipped").isJsonNull() ? root.get("equipped").getAsString() : null;
            if (root.has("grantsApplied")) {
               for (var el : root.getAsJsonArray("grantsApplied")) {
                  this.grantsApplied.add(el.getAsString());
               }
            }
         } catch (Exception e) {
            BlueClient.LOGGER.error("Failed to load cosmetics.json - starting fresh", e);
         }
      }
      this.applySeededGrantIfAny();
   }

   /**
    * One-time star grants keyed by username (cracked-account safe - no
    * reliable UUID to key on). v0.20.2: public + called from the manager tick
    * as well as load() — on launcher/offline setups the session username may
    * not be readable at client-init time, which silently skipped the grant
    * forever. Re-running it every tick is idempotent (grantsApplied guard)
    * and dirt cheap (one map lookup).
    */
   public void applySeededGrantIfAny() {
      String username = currentUsername();
      if (username == null) {
         return;
      }
      String key = username.trim().toLowerCase(Locale.ROOT);
      Integer amount = SEEDED_GRANTS.get(key);
      if (amount != null && !this.grantsApplied.contains(key)) {
         this.stars += amount;
         this.lifetimeStars += amount;
         this.grantsApplied.add(key);
         BlueClient.LOGGER.info("Cosmetics: granted {} Blue Stars to {} (seeded grant)", amount, username);
         this.save();
      }
      // v0.21.1: starter cape for every Blue Client user - one-time, idempotent.
      if (!this.grantsApplied.contains(STARTER_GRANT_KEY)) {
         this.owned.add(STARTER_CAPE);
         this.grantsApplied.add(STARTER_GRANT_KEY);
         if (this.equipped == null) {
            this.equipped = STARTER_CAPE;
            BlueClient.LOGGER.info("Cosmetics: starter cape '{}' granted + auto-equipped", STARTER_CAPE);
         } else {
            BlueClient.LOGGER.info("Cosmetics: starter cape '{}' granted (kept equipped cape)", STARTER_CAPE);
         }
         this.save();
      }
   }

   /* ---- favorites (v0.20.2 cosmetics revamp) ---- */

   public boolean isFavorite(String capeId) {
      return capeId != null && this.favorites.contains(capeId);
   }

   public void toggleFavorite(String capeId) {
      if (capeId == null) {
         return;
      }
      if (!this.favorites.remove(capeId)) {
         this.favorites.add(capeId);
      }
      this.save();
   }

   private static String currentUsername() {
      try {
         var session = net.minecraft.client.MinecraftClient.getInstance().getSession();
         return session == null ? null : session.getUsername();
      } catch (Throwable t) {
         return null;
      }
   }

   public void save() {
      try {
         Files.createDirectories(this.file.getParent());
         JsonObject root = new JsonObject();
         root.addProperty("stars", this.stars);
         root.addProperty("lifetimeStars", this.lifetimeStars);
         JsonArray ownedArr = new JsonArray();
         this.owned.forEach(ownedArr::add);
         root.add("owned", ownedArr);
         JsonArray favArr = new JsonArray();
         this.favorites.forEach(favArr::add);
         root.add("favorites", favArr);
         root.addProperty("equipped", this.equipped);
         JsonArray grantsArr = new JsonArray();
         this.grantsApplied.forEach(grantsArr::add);
         root.add("grantsApplied", grantsArr);
         Files.writeString(this.file, root.toString());
      } catch (IOException e) {
         BlueClient.LOGGER.error("Failed to save cosmetics.json", e);
      }
   }

   public int stars() {
      return this.stars;
   }

   public int lifetimeStars() {
      return this.lifetimeStars;
   }

   public boolean owns(String capeId) {
      return this.owned.contains(capeId);
   }

   public String equipped() {
      return this.equipped;
   }

   /** Grants a star (accrual tick). Saves immediately - accrual is only once/minute so this is cheap. */
   public void addStar() {
      this.stars++;
      this.lifetimeStars++;
      this.save();
   }

   /** Owner-only: grants a cape directly (EXCLUSIVE grants), no charge. */
   public void grant(String capeId) {
      this.owned.add(capeId);
      this.save();
   }

   /** Returns true and deducts stars if affordable and not already owned; false otherwise. */
   public boolean purchase(Cape cape) {
      if (cape == null || !cape.rarity().purchasable() || this.owns(cape.id())) {
         return false;
      }
      if (this.stars < cape.rarity().price()) {
         return false;
      }
      this.stars -= cape.rarity().price();
      this.owned.add(cape.id());
      this.save();
      return true;
   }

   public void equip(String capeId) {
      if (capeId == null || this.owns(capeId)) {
         this.equipped = capeId;
         this.save();
      }
   }

   public void unequip() {
      this.equipped = null;
      this.save();
   }
}
