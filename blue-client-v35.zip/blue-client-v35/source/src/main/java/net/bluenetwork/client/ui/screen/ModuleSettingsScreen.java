package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.ModuleActions;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.setting.StringSetting;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import java.nio.file.Path;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * Module Settings v2 - module page (feedback 2026-09-11, reference
 * shot 2): round back button + module name header with the description
 * underneath, gear (keybind) and search top-right, small-caps section
 * headers, ON/OFF chip toggles, value + blue-knob sliders, cycle boxes with
 * chevrons, colour swatches with an inline RGB editor, action buttons and a
 * live preview strip for HUD modules.
 *
 * <p>Rendered in the same fit-scaled virtual space as the other screens, so
 * it can never be cut off by the window.</p>
 */
public class ModuleSettingsScreen extends Screen {
   /*
    * v0.24.1 READABILITY PASS
    * ------------------------
    * Owner: "make the module settings have bigger things even tho it requires
    *         more scrolling, it is currently not readable"
    *
    * The old layout squeezed 10 px setting names and 8.5 px values into 24 px
    * rows on a 640 px virtual canvas. On a 1080p screen at GUI scale 2 that is
    * genuinely tiny, and on the owner's laptop it was unreadable.
    *
    * Everything below is now driven by these constants, so the whole screen
    * scales together instead of drifting:
    *   ROW_H       24 -> 34   (taller rows, more breathing room)
    *   NAME_SIZE   10 -> 13   (setting names)
    *   VALUE_SIZE  8.5 -> 11  (values / dropdown text)
    *   LABEL_SIZE  7.5 -> 9.5 (section headers)
    * The canvas is narrower (640 -> 560) so the SAME pixels cover less virtual
    * space, i.e. everything is drawn physically larger. More scrolling is the
    * accepted trade - the owner asked for it explicitly.
    */

   private static final int DESIGN_W = 560;
   private static final int DESIGN_H = 400;
   private static final int HEADER_H = 52;
   private static final int PAD = 16;
   private static final int ROW_H = 34;

   /** Setting name text size. */
   private static final float NAME_SIZE = 13.0F;
   /** Value / dropdown / hex text size. */
   private static final float VALUE_SIZE = 11.0F;
   /** Small section-header text size ("CONTROLS", "APPEARANCE"). */
   private static final float LABEL_SIZE = 9.5F;

   /** Height of an inline control (dropdown / text box) inside a row. */
   private static final float CTRL_H = 24.0F;
   /** Y offset that vertically centres a CTRL_H control in a ROW_H row. */
   private static final float CTRL_Y = (ROW_H - CTRL_H) / 2.0F;
   /** Y offset that centres the setting-name baseline in a ROW_H row. */
   private static final float TEXT_Y = 11.0F;
   private static final int SEARCH_W = 140;

   private static final int GREEN = 0xFF3CB860;
   private static final int CRIMSON = 0xFFC9405E;
   private static final Set<String> APPEARANCE_NAMES = Set.of(
      "Background", "Background color", "Background opacity", "Corner radius",
      "Show border", "Border color", "Text color");

   private final BlueClient blue;
   private final Screen parent;
   private final Module module;

   private String query = "";

   /**
    * The number setting whose value is being typed, or null.
    *
    * <p>Dragging a slider cannot reach every value: Lyric Offset spans
    * -5000..5000 across roughly 180 pixels, so one pixel is about 55 units and
    * landing exactly on 0 is impossible. Clicking the value opens this editor
    * so any number can be entered exactly.</p>
    */
   private NumberSetting editingNumber;
   private String numberDraft = "";
   private boolean searchFocused = false;
   // v0.16.11 songs dropdown (Music Player): expandable /songs list, cached.
   private boolean songsOpen = true;
   private List<java.nio.file.Path> songsCache = null;
   private long songsCacheAt = 0L;
   private float targetScroll;
   private float smoothScroll;
   private float drawScale = 1.0F;

   private final List<Hit> hits = new ArrayList<>();
   private Rect backBtn;
   private Rect gearBtn;
   private Rect searchBox;
   private float listTop;
   private float listBottom;

   private boolean bindListening = false;
   private StringSetting editingString = null;
   private ColorSetting expandedColor = null;
   private NumberSetting draggingNumber = null;
   private ColorSetting draggingColor = null;
   private int draggingChannel = -1;
   private float dragX0;
   private float dragX1;

   public ModuleSettingsScreen(BlueClient blue, ModuleMenuScreen parent, Module module) {
      this(blue, (Screen) parent, module);
   }

   /** v0.16.12: overloads accept any parent screen (HUD editor opens module
    * settings directly - the back button returns to where we came from). */
   public ModuleSettingsScreen(BlueClient blue, Screen parent, Module module) {
      super(Text.literal(module.getName() + " Settings"));
      this.blue = blue;
      this.parent = parent;
      this.module = module;
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   private boolean isHud() {
      return this.module instanceof HudModule;
   }

   /**
    * Whether this module gets the live preview panel.
    *
    * <p>HUD modules render themselves into it; Crosshair+ draws through the
    * same {@code CrosshairRenderer} the game uses, so what you tune here is
    * exactly what you get in game.</p>
    */
   private boolean hasPreview() {
      return this.isHud()
         || this.module instanceof net.bluenetwork.client.module.impl.CustomCrosshair;
   }

   private boolean animated() {
      try {
         return this.blue.settings().animations();
      } catch (Throwable t) {
         return true;
      }
   }

   private boolean matches(Setting<?> s) {
      return this.query.isEmpty()
         || s.getName().toLowerCase(Locale.ROOT).contains(this.query.toLowerCase(Locale.ROOT));
   }

   private List<Setting<?>> generalSettings() {
      List<Setting<?>> out = new ArrayList<>();
      for (Setting<?> s : this.module.getSettings()) {
         if (APPEARANCE_NAMES.contains(s.getName())) {
            continue;
         }
         if (safeVisible(s) && this.matches(s)) {
            out.add(s);
         }
      }
      return out;
   }

   private List<Setting<?>> appearanceSettings() {
      List<Setting<?>> out = new ArrayList<>();
      for (Setting<?> s : this.module.getSettings()) {
         if (!APPEARANCE_NAMES.contains(s.getName())) {
            continue;
         }
         if (safeVisible(s) && this.matches(s)) {
            out.add(s);
         }
      }
      return out;
   }

   private static boolean safeVisible(Setting<?> s) {
      try {
         return s.isVisible();
      } catch (Throwable t) {
         return true;
      }
   }

   /* ========================================================== RENDERING */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0xB20B0E14);

      float base = 0.75F;
      float fit = Math.min(1.0F, Math.min(w / (base * DESIGN_W + 12.0F), h / (base * DESIGN_H + 12.0F)));
      float scale = base * Math.max(0.35F, fit);

      // v0.16.4: fit-to-content. The panel is sized to exactly what the module
      // needs and, if that would not fit, the whole sheet scales down (never
      // below a readable 0.55) so typical modules show every setting at once
      // with no scrollbar and no dead space.
      float content = this.contentHeightEstimate();
      for (int pass = 0; pass < 3 && scale > 0.55F; pass++) {
         int vhPass = (int) Math.floor(h / scale);
         float avail = vhPass - 24 - HEADER_H - 6 - (this.isHud() ? 74 : PAD) - PAD;
         if (content <= avail || avail < 60) {
            break;
         }
         scale = Math.max(0.55F, scale * (avail / content));
      }
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int mx = (int) (mouseX / scale);
      int my = (int) (mouseY / scale);

      float panelW = Math.min(vw - 24, 760);
      float needed = content + HEADER_H + 6 + (this.isHud() ? 74 : PAD);
      float panelH = Math.max(220, Math.min(vh - 24, needed));
      float panelX = (vw - panelW) / 2.0F;
      float panelY = (vh - panelH) / 2.0F;
      float radius = 12.0F;

      this.hits.clear();
      PremiumRender.drawShadow(context, (int) panelX - 2, (int) panelY - 2, (int) panelW + 4, (int) panelH + 4, 0x77000000, 14);
      SmoothRect.fill(context, panelX, panelY, panelW, panelH, radius,
         withAlpha(DesignTokens.panelBg() & 0x00FFFFFF, this.bodyAlpha()));

      this.drawHeader(context, panelX, panelY, panelW, mx, my);

      float listX = panelX + PAD;
      float listW = panelW - PAD * 2 - 6;
      float top = panelY + HEADER_H + 6;
      float bottom = panelY + panelH - (this.hasPreview() ? 74 : PAD);
      this.drawSettings(context, listX, listW, top, bottom, scale, mx, my);

      if (this.hasPreview()) {
         this.drawPreview(context, panelX + PAD, panelY + panelH - 66, panelW - PAD * 2, 54);
      }

      int borderBase = DesignTokens.panelBorder();
      float borderAlpha = Math.max(0.55F, ((borderBase >>> 24) & 0xFF) / 255.0F);
      SmoothRect.outline(context, panelX, panelY, panelW, panelH, radius, 1.5F,
         withAlpha(borderBase & 0xFFFFFF, borderAlpha));
      context.getMatrices().popMatrix();

      if (this.animated()) {
         this.smoothScroll += (this.targetScroll - this.smoothScroll) * Math.min(1.0F, delta * 14.0F);
         if (Math.abs(this.targetScroll - this.smoothScroll) < 0.25F) {
            this.smoothScroll = this.targetScroll;
         }
      } else {
         this.smoothScroll = this.targetScroll;
      }
      // Custom immediate-mode screens never call super.render(), so the ScreenMixin
      // toast hook does not fire - draw toasts here so "Playing X" / error feedback
      // is visible while sitting on this screen (in-game HudManager handles it).
      if (this.client != null && this.client.player == null) {
         BlueClient.getInstance().notificationManager().render(context);
      }
   }

   private void drawHeader(DrawContext context, float px, float py, float pw, int mx, int my) {
      // round back button
      this.backBtn = new Rect(px + 12, py + 12, 22, 22);
      boolean backHover = this.backBtn.contains(mx, my);
      SmoothRect.fill(context, px + 12, py + 12, 22, 22, 11.0F, backHover ? 0x26FFFFFF : 0x14FFFFFF);
      RenderUtil.drawIcon(context, "chevron-down", (int) (px + 18), (int) (py + 16), 10,
         backHover ? DesignTokens.textHi() : DesignTokens.textMid());

      String name = this.module.getName().toUpperCase(Locale.ROOT);
      // v0.16.9: long module names scale down instead of colliding with the chip
      float nameSize = 13.0F;
      float nameW = TextPainter.poppinsWidth(name, nameSize);
      float maxNameW = (float) Math.max(60, pw - 220);
      if (nameW > maxNameW) {
         nameSize = Math.max(7.5F, nameSize * maxNameW / nameW);
         nameW = TextPainter.poppinsWidth(name, nameSize);
      }
      // v0.16.12: no ENABLED/DISABLED chip - the module NAME is green (on) or red (off).
      boolean enabled = this.module.isEnabled();
      TextPainter.drawPoppins(context, name, px + 42, py + 12, enabled ? GREEN : CRIMSON, nameSize);
      String desc = this.module.getDescription();
      RenderUtil.drawText(context, fit(desc, (int) (pw - 220)), (int) (px + 42), (int) (py + 28), DesignTokens.textMid());
      // clicking the name still toggles the module
      this.hits.add(new Hit(new Rect(px + 42, py + 11, Math.max(nameW, 60), 20), "toggleModule"));

      // search (right)
      float sx = px + pw - PAD - SEARCH_W;
      this.searchBox = new Rect(sx, py + 13, SEARCH_W, 20);
      boolean searchHover = this.searchBox.contains(mx, my);
      SmoothRect.fill(context, sx, py + 13, SEARCH_W, 20, 6.0F, 0x99101520);
      SmoothRect.outline(context, sx, py + 13, SEARCH_W, 20, 6.0F, 1.0F,
         this.searchFocused ? withAlpha(DesignTokens.accent(), 0.9F) : searchHover ? 0x3DFFFFFF : 0x22FFFFFF);
      RenderUtil.drawIcon(context, "search", (int) sx + 7, (int) (py + 18), 10,
         this.searchFocused || !this.query.isEmpty() ? DesignTokens.accent() : DesignTokens.textMid());
      if (this.query.isEmpty()) {
         TextPainter.drawPoppins(context, "Search...", sx + 22, py + 18.5F, DesignTokens.textMid(), 9.0F);
      } else {
         TextPainter.drawPoppins(context, this.query, sx + 22, py + 18.5F, DesignTokens.textHi(), 9.0F);
      }

      // gear = keybind editor
      float gx = sx - 30;
      this.gearBtn = new Rect(gx, py + 13, 22, 20);
      boolean gearHover = this.gearBtn.contains(mx, my);
      SmoothRect.fill(context, gx, py + 13, 22, 20, 5.0F,
         this.bindListening ? withAlpha(DesignTokens.accent(), 0.3F) : gearHover ? 0x26FFFFFF : 0x14FFFFFF);
      RenderUtil.drawIcon(context, "settings", (int) (gx + 5), (int) (py + 17), 12,
         this.bindListening ? DesignTokens.accent() : gearHover ? DesignTokens.textHi() : DesignTokens.textMid());

      SmoothRect.fill(context, px + 1, py + HEADER_H - 1, pw - 2, 1, 0.5F, 0x22FFFFFF);
   }

   /* --------------------------------------------------------- settings */

   private void drawSettings(DrawContext context, float x, float w, float top, float bottom, float sc, int mx, int my) {
      this.listTop = top;
      this.listBottom = bottom;

      List<Setting<?>> general = this.generalSettings();
      List<Setting<?>> appearance = this.appearanceSettings();
      boolean hasActions = this.module instanceof ModuleActions actions && !actions.actionLabels().isEmpty();

      float contentHeight = 0;
      if (!general.isEmpty()) {
         contentHeight += 16 + this.rowHeightFor(general) + 8;
      }
      if (this.isHud() && !appearance.isEmpty()) {
         contentHeight += 16 + this.rowHeightFor(appearance) + 8;
      }
      if (hasActions) {
         int labels = ((ModuleActions) this.module).actionLabels().size();
         contentHeight += 16 + ((labels + 2) / 3) * 24 + 8;
      }
      if (this.module instanceof net.bluenetwork.client.module.impl.MusicPlayer) {
         List<Path> songs = this.songs();
         contentHeight += 16 + 22 + 6;
         if (this.songsOpen) {
            contentHeight += songs.size() * 20 + 6;
         }
      }
      contentHeight += 16 + ROW_H; // controls section (keybind)

      float viewH = bottom - top;
      float maxScroll = Math.max(0, contentHeight - viewH);
      this.targetScroll = Math.max(0, Math.min(this.targetScroll, maxScroll));

      // enableScissor applies the current matrix itself - pass virtual coords.
      context.enableScissor((int) Math.floor(x - 2), (int) Math.floor(top),
         (int) Math.ceil(x + w + 8), (int) Math.ceil(bottom + 2));

      float y = top - this.smoothScroll + 4;

      y = this.drawSection(context, "GENERAL", general, x, w, y, top, bottom, mx, my);
      if (this.isHud() && !appearance.isEmpty()) {
         y = this.drawSection(context, "APPEARANCE", appearance, x, w, y, top, bottom, mx, my);
      }
      if (hasActions) {
         y = this.drawActions(context, x, w, y, top, bottom, mx, my);
      }
      if (this.module instanceof net.bluenetwork.client.module.impl.MusicPlayer) {
         y = this.drawSongs(context, x, w, y, top, bottom, mx, my);
      }
      if (y + 16 > top && y < bottom) {
         TextPainter.drawPoppins(context, "CONTROLS", x + 2, y + 3, DesignTokens.textMid(), LABEL_SIZE);
      }
      y += 16;
      if (y + ROW_H > top - 24 && y < bottom + 24) {
         this.drawBindRow(context, x, y, w, mx, my);
      }
      y += ROW_H;

      context.disableScissor();

      if (contentHeight > viewH) {
         float thumbH = Math.max(24, viewH * (viewH / contentHeight));
         float thumbY = top + (this.smoothScroll / maxScroll) * (viewH - thumbH);
         SmoothRect.fill(context, x + w + 3, top, 3, viewH, 1.5F, 0x14FFFFFF);
         SmoothRect.fill(context, x + w + 3, thumbY, 3, thumbH, 1.5F, withAlpha(DesignTokens.accent(), 0.75F));
      }
   }

   /** Mirrors drawSettings' vertical budget so the panel can be pre-sized. */
   private float contentHeightEstimate() {
      List<Setting<?>> general = this.generalSettings();
      List<Setting<?>> appearance = this.appearanceSettings();
      boolean hasActions = this.module instanceof ModuleActions actions && !actions.actionLabels().isEmpty();
      float height = 0;
      if (!general.isEmpty()) {
         height += 16 + this.rowHeightFor(general) + 8;
      }
      if (this.isHud() && !appearance.isEmpty()) {
         height += 16 + this.rowHeightFor(appearance) + 8;
      }
      if (hasActions) {
         int labels = ((ModuleActions) this.module).actionLabels().size();
         height += 16 + ((labels + 2) / 3) * 24 + 8;
      }
      height += 16 + ROW_H;
      return height + 8;
   }

   private int rowHeightFor(List<Setting<?>> list) {
      int h = 0;
      for (Setting<?> s : list) {
         h += this.settingHeight(s);
      }
      return h;
   }

   private int settingHeight(Setting<?> s) {
      if (s instanceof ColorSetting c && c == this.expandedColor) {
         return ROW_H + 3 * 16 + 18;
      }
      return ROW_H;
   }

   private float drawSection(DrawContext context, String title, List<Setting<?>> settings,
                             float x, float w, float y, float top, float bottom, int mx, int my) {
      if (settings.isEmpty()) {
         return y;
      }
      if (y + 16 > top && y < bottom) {
         TextPainter.drawPoppins(context, title, x + 2, y + 3, DesignTokens.textMid(), LABEL_SIZE);
      }
      y += 16;
      for (Setting<?> s : settings) {
         int rh = this.settingHeight(s);
         if (y + rh > top - 30 && y < bottom + 30) {
            this.drawSetting(context, s, x, w, y, mx, my);
         }
         y += rh;
      }
      return y + 8;
   }

   private void drawSetting(DrawContext context, Setting<?> s, float x, float w, float y, int mx, int my) {
      String name = s.getName();
      if (s instanceof BooleanSetting bool) {
         boolean on = bool.get();
         boolean hovered = mx >= x && mx < x + w && my >= y && my < y + ROW_H;
         if (hovered) {
            SmoothRect.fill(context, x - 4, y, w + 8, ROW_H, 5.0F, 0x0FFFFFFF);
         }
         this.drawChipToggle(context, x, y + CTRL_Y, on);
         TextPainter.drawPoppins(context, name, x + 42, y + 10, on ? DesignTokens.textHi() : DesignTokens.textMid(), NAME_SIZE);
         String desc = fit(s.getDescription(), (int) (w - 42 - TextPainter.poppinsWidth(name, NAME_SIZE) - 12));
         if (!desc.isEmpty() && TextPainter.poppinsWidth(name, NAME_SIZE) + 42 + TextPainter.poppinsWidth(desc, 8.0F) < w - 8) {
            TextPainter.drawPoppins(context, desc, x + 42 + TextPainter.poppinsWidth(name, NAME_SIZE) + 10, y + 11.0F,
               0x88AAAAAA, 8.0F);
         }
         this.hits.add(new Hit(new Rect(x - 4, y, w + 8, ROW_H), "bool:" + name));
      } else if (s instanceof NumberSetting num) {
         TextPainter.drawPoppins(context, name, x, y + 10, DesignTokens.textHi(), NAME_SIZE);
         boolean editingThis = this.editingNumber == num;
         String value = editingThis ? this.numberDraft : trim(num.get());
         float trackW = Math.min(180, w * 0.4F);
         float trackX = x + w - trackW;

         // The value doubles as a text field. A caret and a box make that
         // discoverable instead of hidden.
         float boxW = Math.max(46.0F, TextPainter.poppinsWidth(value, VALUE_SIZE) + 14);
         float boxX = trackX - boxW - 8;
         boolean overBox = mx >= boxX && mx < boxX + boxW
            && my >= y + CTRL_Y && my < y + CTRL_Y + CTRL_H;
         if (editingThis || overBox) {
            SmoothRect.fill(context, boxX, y + CTRL_Y, boxW, CTRL_H, 4.0F, 0x1AFFFFFF);
            SmoothRect.outline(context, boxX, y + CTRL_Y, boxW, CTRL_H, 4.0F, 1.0F,
               editingThis ? DesignTokens.accent() : 0x33FFFFFF);
         }
         float valueW = TextPainter.poppinsWidth(value, VALUE_SIZE);
         TextPainter.drawPoppins(context, value, boxX + (boxW - valueW) / 2.0F,
            y + 11.0F, editingThis ? DesignTokens.textHi() : DesignTokens.textMid(),
            VALUE_SIZE);
         if (editingThis && (System.currentTimeMillis() / 500L) % 2L == 0L) {
            SmoothRect.fill(context, boxX + (boxW + valueW) / 2.0F + 1, y + CTRL_Y + 3,
               1.0F, CTRL_H - 6, 0.0F, DesignTokens.accent());
         }
         this.hits.add(new Hit(new Rect(boxX, y + CTRL_Y, boxW, CTRL_H),
            "numedit:" + name));
         this.drawSlider(context, trackX, y + ROW_H / 2.0F, trackW,
            (num.get() - num.getMin()) / (num.getMax() - num.getMin()), "number:" + name);
         this.hits.add(new Hit(new Rect(trackX - 4, y + CTRL_Y, trackW + 8, CTRL_H), "number:" + name));
      } else if (s instanceof ModeSetting mode) {
         TextPainter.drawPoppins(context, name, x, y + 10, DesignTokens.textHi(), NAME_SIZE);
         String value = mode.get();
         float bw = Math.max(96, TextPainter.poppinsWidth(value, VALUE_SIZE) + 26);
         float bx = x + w - bw;
         boolean hovered = mx >= bx && mx < bx + bw && my >= y + CTRL_Y && my < y + CTRL_Y + CTRL_H;
         SmoothRect.fill(context, bx, y + CTRL_Y, bw, CTRL_H, 4.0F, hovered ? 0x26FFFFFF : 0x14FFFFFF);
         SmoothRect.outline(context, bx, y + CTRL_Y, bw, CTRL_H, 4.0F, 1.0F, hovered ? withAlpha(DesignTokens.accent(), 0.7F) : 0x22FFFFFF);
         TextPainter.drawPoppins(context, value, bx + 8, y + 11.0F, DesignTokens.textHi(), VALUE_SIZE);
         RenderUtil.drawIcon(context, "chevron-down", (int) (bx + bw - 14), (int) (y + 8), 8, DesignTokens.textMid());
         this.hits.add(new Hit(new Rect(bx, y + 3, bw, 18), "mode:" + name));
      } else if (s instanceof ColorSetting color) {
         TextPainter.drawPoppins(context, name, x, y + 10, DesignTokens.textHi(), NAME_SIZE);
         int rgb = color.currentRgb(System.currentTimeMillis());
         float bx = x + w - 84;
         boolean hovered = mx >= bx && mx < bx + 84 && my >= y + 2 && my < y + 20;
         SmoothRect.fill(context, bx, y + 3, 26, 16, 4.0F, 0xFF000000 | rgb);
         SmoothRect.outline(context, bx, y + 3, 26, 16, 4.0F, 1.0F, hovered ? 0x66FFFFFF : 0x33FFFFFF);
         TextPainter.drawPoppins(context, color.hex().toUpperCase(Locale.ROOT), bx + 32, y + 11.0F, DesignTokens.textMid(), VALUE_SIZE);
         this.hits.add(new Hit(new Rect(bx, y + 3, 84, 16), "color:" + name));
         if (color == this.expandedColor) {
            float ey = y + ROW_H;
            for (int channel = 0; channel < 3; channel++) {
               int channelValue = channel == 0 ? color.red() : channel == 1 ? color.green() : color.blue();
               String label = channel == 0 ? "R" : channel == 1 ? "G" : "B";
               int labelColor = channel == 0 ? 0xFFFF6B6B : channel == 1 ? 0xFF6BFF8A : 0xFF6B9FFF;
               TextPainter.drawPoppins(context, label, x + 8, ey + 4, labelColor, VALUE_SIZE);
               this.drawSlider(context, x + 24, ey + 5, w - 90, channelValue / 255.0F, "rgb:" + channel + ":" + name);
               this.hits.add(new Hit(new Rect(x + 20, ey, w - 82, 16), "rgb:" + channel + ":" + name));
               ey += 16;
            }
            boolean rb = color.rainbowEnabled();
            float rw = 64;
            SmoothRect.fill(context, x + 8, ey + 1, rw, 14, 6.5F, rb ? DesignTokens.accent() : 0x22FFFFFF);
            TextPainter.drawPoppins(context, rb ? "RAINBOW" : "SOLID", x + 15, ey + 4, DesignTokens.textHi(), 7.0F);
            this.hits.add(new Hit(new Rect(x + 4, ey - 2, rw + 8, 18), "rainbow:" + name));
         }
      } else if (s instanceof StringSetting string) {
         TextPainter.drawPoppins(context, name, x, y + 10, DesignTokens.textHi(), NAME_SIZE);
         boolean editing = this.editingString == string;
         String shown = string.get().isEmpty() ? (editing ? "_" : "click to type") : string.get() + (editing ? "_" : "");
         float bw = Math.max(120, w * 0.5F);
         float bx = x + w - bw;
         shown = fitPoppins(shown, (int) (bw - 16), VALUE_SIZE);
         boolean hovered = mx >= bx && mx < bx + bw && my >= y + 2 && my < y + 20;
         SmoothRect.fill(context, bx, y + 3, bw, 18, 4.0F, editing || hovered ? 0x26FFFFFF : 0x14FFFFFF);
         SmoothRect.outline(context, bx, y + 3, bw, 18, 4.0F, 1.0F,
            editing ? withAlpha(DesignTokens.accent(), 0.9F) : 0x22FFFFFF);
         TextPainter.drawPoppins(context, shown, bx + 8, y + 11.0F,
            string.get().isEmpty() && !editing ? DesignTokens.textMid() : DesignTokens.textHi(), VALUE_SIZE);
         this.hits.add(new Hit(new Rect(bx, y + 3, bw, 18), "string:" + name));
      }
   }

   /* v0.16.11: the /songs dropdown. Every playable file in .minecraft/songs
    * shows as a click-to-play row inside the Music Player settings - no
    * separate screen, nothing that can take the game down. */

   private List<Path> songs() {
      long now = System.currentTimeMillis();
      if (this.songsCache == null || now - this.songsCacheAt > 2000L) {
         try {
            this.songsCache = net.bluenetwork.client.module.impl.MusicPlayer.listSongs();
         } catch (Throwable t) {
            this.songsCache = java.util.List.of();
         }
         this.songsCacheAt = now;
      }
      return this.songsCache;
   }

   private float drawSongs(DrawContext context, float x, float w, float y, float top, float bottom, int mx, int my) {
      List<Path> songs = this.songs();
      if (y + 16 > top && y < bottom) {
         TextPainter.drawPoppins(context, "SONGS (" + songs.size() + ")", x + 2, y + 3, DesignTokens.textMid(), LABEL_SIZE);
         // expand/collapse pill on the right
         float pw = 52;
         float px = x + w - pw;
         boolean pillHover = mx >= px && mx < px + pw && my >= y && my < y + 16;
         SmoothRect.fill(context, px, y + 1, pw, 14, 4.0F, pillHover ? 0x26FFFFFF : 0x14FFFFFF);
         String pill = this.songsOpen ? "HIDE ▾" : "SHOW ▸";
         TextPainter.drawPoppins(context, pill, px + pw / 2 - TextPainter.poppinsWidth(pill, 7.0F) / 2.0F,
            y + 4, DesignTokens.textMid(), 7.0F);
         this.hits.add(new Hit(new Rect(px, y + 1, pw, 14), "songs:toggle"));
         // OPEN FOLDER pill - opens .minecraft/songs in the OS file explorer
         float fw = 74;
         float fx = px - 4 - fw;
         boolean folderHover = mx >= fx && mx < fx + fw && my >= y && my < y + 16;
         SmoothRect.fill(context, fx, y + 1, fw, 14, 4.0F, folderHover ? 0x26FFFFFF : 0x14FFFFFF);
         String fpill = "OPEN FOLDER";
         TextPainter.drawPoppins(context, fpill, fx + fw / 2 - TextPainter.poppinsWidth(fpill, 7.0F) / 2.0F,
            y + 4, DesignTokens.textMid(), 7.0F);
         this.hits.add(new Hit(new Rect(fx, y + 1, fw, 14), "songs:folder"));
      }
      y += 22;
      if (!this.songsOpen) {
         return y;
      }
      String nowPlaying = "";
      try {
         if (net.bluenetwork.client.music.MusicEngine.INSTANCE.isPlaying()) {
            nowPlaying = net.bluenetwork.client.music.MusicEngine.INSTANCE.nowPlaying();
         }
      } catch (Throwable ignored) {
         // Music engine unavailable - fall back to no now-playing marker.
      }
      if (songs.isEmpty()) {
         if (y + 18 > top && y < bottom) {
            String hint = "Put mp3 / wav / m4a / ogg files in .minecraft/songs";
            TextPainter.drawPoppins(context, hint, x + 2, y + 3, DesignTokens.textMid(), 8.0F);
         }
         return y + 24;
      }
      int index = 0;
      for (Path song : songs) {
         if (y + 20 > top && y < bottom) {
            String name = song.getFileName().toString();
            int dot = name.lastIndexOf('.');
            String label = dot > 0 ? name.substring(0, dot) : name;
            boolean playing = !nowPlaying.isEmpty() && nowPlaying.equals(name);
            boolean hovered = mx >= x && mx < x + w && my >= y && my < y + 20;
            SmoothRect.fill(context, x, y, w, 20, 4.0F,
               playing ? withAlpha(DesignTokens.accent(), 0.22F) : hovered ? 0x1AFFFFFF : 0x0DFFFFFF);
            if (playing) {
               SmoothRect.outline(context, x, y, w, 20, 4.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.55F));
            }
            RenderUtil.drawIcon(context, playing ? "pause" : "play",
               (int) (x + 6), (int) (y + 5), 9, playing ? DesignTokens.accent() : DesignTokens.textMid());
            String shown = this.fitPoppins(label, (int) (w - 34), VALUE_SIZE);
            TextPainter.drawPoppins(context, shown, x + 22, y + 6,
               playing ? DesignTokens.textHi() : DesignTokens.textHi(), VALUE_SIZE);
            this.hits.add(new Hit(new Rect(x, y, w, 20), "songs:play:" + index));
         }
         y += 20;
         index++;
      }
      return y + 6;
   }

   private float drawActions(DrawContext context, float x, float w, float y, float top, float bottom, int mx, int my) {
      if (!(this.module instanceof ModuleActions actions) || actions.actionLabels().isEmpty()) {
         return y;
      }
      if (y + 16 > top && y < bottom) {
         TextPainter.drawPoppins(context, "ACTIONS", x + 2, y + 3, DesignTokens.textMid(), LABEL_SIZE);
      }
      y += 16;
      List<String> labels = actions.actionLabels();
      float colW = (w - 16) / 3.0F;
      for (int i = 0; i < labels.size(); i++) {
         int col = i % 3;
         int row = i / 3;
         float bx = x + col * (colW + 8);
         float by = y + row * 24;
         boolean hovered = mx >= bx && mx < bx + colW && my >= by && my < by + 20;
         SmoothRect.fill(context, bx, by, colW, 20, 4.0F, hovered ? withAlpha(DesignTokens.accent(), 0.3F) : 0xCC1B2230);
         SmoothRect.outline(context, bx, by, colW, 20, 4.0F, 1.0F, hovered ? withAlpha(DesignTokens.accent(), 0.7F) : 0x33FFFFFF);
         String label = fitPoppins(labels.get(i), (int) (colW - 12), 7.5F);
         TextPainter.drawPoppins(context, label, bx + colW / 2 - TextPainter.poppinsWidth(label, 7.5F) / 2.0F,
            by + 6, DesignTokens.textHi(), 7.5F);
         this.hits.add(new Hit(new Rect(bx, by, colW, 20), "action:" + i));
      }
      return y + ((labels.size() + 2) / 3) * 24 + 8;
   }

   private void drawBindRow(DrawContext context, float x, float y, float w, int mx, int my) {
      TextPainter.drawPoppins(context, "Keybind", x, y + 10, DesignTokens.textHi(), NAME_SIZE);
      String label = this.bindListening ? "PRESS A KEY" : keyName(this.module.getKeybind());
      float bw = Math.max(90, TextPainter.poppinsWidth(label, 8.5F) + 20);
      float bx = x + w - bw;
      boolean hovered = mx >= bx && mx < bx + bw && my >= y + 2 && my < y + 20;
      SmoothRect.fill(context, bx, y + 3, bw, 18, 4.0F,
         this.bindListening ? withAlpha(DesignTokens.accent(), 0.3F) : hovered ? 0x26FFFFFF : 0x14FFFFFF);
      SmoothRect.outline(context, bx, y + 3, bw, 18, 4.0F, 1.0F,
         this.bindListening ? DesignTokens.accent() : 0x22FFFFFF);
      TextPainter.drawPoppins(context, label, bx + 10, y + 11.0F,
         this.bindListening ? 0xFFFFFFFF : DesignTokens.textHi(), VALUE_SIZE);
      this.hits.add(new Hit(new Rect(bx, y + 3, bw, 18), "bind"));
   }

   private void drawPreview(DrawContext context, float x, float y, float w, float h) {
      SmoothRect.fill(context, x, y, w, h, 6.0F, 0x66101520);
      SmoothRect.outline(context, x, y, w, h, 6.0F, 1.0F, 0x22FFFFFF);
      TextPainter.drawPoppins(context, "PREVIEW", x + 8, y + 5, 0x66FFFFFF, 7.0F);
      try {
         if (this.module instanceof net.bluenetwork.client.module.impl.CustomCrosshair crosshair) {
            // Centre of the preview box. Dynamic spread is excluded so the
            // preview does not twitch just because the player is walking.
            crosshair.draw(context, (int) (x + w / 2.0F), (int) (y + h / 2.0F + 4), false);
            return;
         }
         HudModule hud = (HudModule) this.module;
         hud.renderPreview(context, (int) (x + w / 2 - hud.getWidthCached() / 2.0F), (int) (y + 18));
      } catch (Throwable ignored) {
      }
   }

   /* ------------------------------------------------------------ widgets */

   private void drawChipToggle(DrawContext context, float x, float y, boolean on) {
      float w = 34;
      float h = 14;
      SmoothRect.fill(context, x, y, w, h, 4.0F, 0x33FFFFFF);
      if (on) {
         SmoothRect.fill(context, x + w / 2.0F, y + 1, w / 2.0F - 1, h - 2, 3.0F, GREEN);
         TextPainter.drawPoppins(context, "ON", x + w * 0.75F - TextPainter.poppinsWidth("ON", 6.5F) / 2.0F, y + 3.5F, 0xFFFFFFFF, 6.5F);
      } else {
         SmoothRect.fill(context, x + 1, y + 1, w / 2.0F - 1, h - 2, 3.0F, CRIMSON);
         TextPainter.drawPoppins(context, "OFF", x + w * 0.25F - TextPainter.poppinsWidth("OFF", 6.5F) / 2.0F, y + 3.5F, 0xFFFFFFFF, 6.5F);
      }
   }

   private void drawSlider(DrawContext context, float x, float y, float w, double ratio, String tag) {
      float clamped = (float) Math.max(0.0, Math.min(1.0, ratio));
      // y is the slider's CENTRE line; the track is drawn around it.
      SmoothRect.fill(context, x, y - 2, w, 4, 2.0F, 0x33FFFFFF);
      SmoothRect.fill(context, x, y - 2, w * clamped, 4, 2.0F, withAlpha(DesignTokens.accent(), 0.8F));
      float knobX = x + w * clamped;
      SmoothRect.fill(context, knobX - 7, y - 7, 14, 14, 7.0F, DesignTokens.accent());
      SmoothRect.outline(context, knobX - 7, y - 7, 14, 14, 7.0F, 1.0F, 0x66FFFFFF);
   }

   /* ============================================================= INPUT */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      float s = this.drawScale;
      int mx = (int) (click.x() / s);
      int my = (int) (click.y() / s);

      if (this.backBtn != null && this.backBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.client.setScreen(this.parent);
         return true;
      }
      if (this.gearBtn != null && this.gearBtn.contains(mx, my)) {
         this.bindListening = true;
         this.editingString = null;
         RenderUtil.clickSound();
         return true;
      }
      if (this.searchBox != null && this.searchBox.contains(mx, my)) {
         this.searchFocused = true;
         return true;
      }
      this.searchFocused = false;

      for (Hit hit : this.hits) {
         if (!hit.rect.contains(mx, my)) {
            continue;
         }
         String tag = hit.tag;
         if (tag.equals("toggleModule")) {
            this.module.toggle();
            RenderUtil.clickSound();
            return true;
         }
         if (tag.equals("bind")) {
            this.bindListening = true;
            this.editingString = null;
            RenderUtil.clickSound();
            return true;
         }
         if (tag.startsWith("bool:")) {
            BooleanSetting b = this.findBoolean(tag.substring(5));
            if (b != null) {
               b.set(!b.get());
               RenderUtil.clickSound();
            }
            return true;
         }
         if (tag.startsWith("mode:")) {
            this.cycleMode(tag.substring(5));
            RenderUtil.clickSound();
            return true;
         }
         if (tag.startsWith("numedit:")) {
            NumberSetting number = this.findNumber(tag.substring(8));
            if (number != null) {
               this.editingNumber = number;
               this.numberDraft = trim(number.get());
               this.editingString = null;
               RenderUtil.clickSound();
            }
            return true;
         }
         if (tag.startsWith("number:")) {
            NumberSetting number = this.findNumber(tag.substring(7));
            if (number != null) {
               this.dragX0 = hit.rect.x + 4;
               this.dragX1 = hit.rect.x + hit.rect.w - 4;
               this.draggingNumber = number;
               this.applySlider(number, mx);
            }
            return true;
         }
         if (tag.startsWith("color:")) {
            ColorSetting color = this.findColor(tag.substring(6));
            if (color != null) {
               this.expandedColor = this.expandedColor == color ? null : color;
               this.editingString = null;
               RenderUtil.clickSound();
            }
            return true;
         }
         if (tag.startsWith("rainbow:")) {
            ColorSetting color = this.findColor(tag.substring(8));
            if (color != null) {
               color.setRainbow(!color.rainbowEnabled(), 1.0F, 0.0F);
               RenderUtil.clickSound();
            }
            return true;
         }
         if (tag.startsWith("rgb:")) {
            String[] parts = tag.substring(4).split(":", 2);
            if (parts.length == 2) {
               ColorSetting color = this.findColor(parts[1]);
               if (color != null) {
                  this.draggingColor = color;
                  this.draggingChannel = Integer.parseInt(parts[0]);
                  this.dragX0 = hit.rect.x + 4;
                  this.dragX1 = hit.rect.x + hit.rect.w - 4;
                  this.applyColorSlider(color, this.draggingChannel, mx);
               }
            }
            return true;
         }
         if (tag.startsWith("string:")) {
            StringSetting string = this.findString(tag.substring(7));
            if (string != null) {
               this.editingString = this.editingString == string ? null : string;
               this.expandedColor = null;
               RenderUtil.clickSound();
            }
            return true;
         }
         if (tag.equals("songs:toggle")) {
            this.songsOpen = !this.songsOpen;
            RenderUtil.clickSound();
            return true;
         }
         if (tag.equals("songs:folder")) {
            RenderUtil.clickSound();
            try {
               java.nio.file.Path dir = net.bluenetwork.client.module.impl.MusicPlayer.songsDir();
               net.minecraft.util.Util.getOperatingSystem().open(dir.toFile());
               BlueClient.getInstance().notificationManager().add("Songs folder opened — drop music in, then reopen SONGS", 0xFF3CB860);
            } catch (Throwable t) {
               BlueClient.LOGGER.error("Couldn't open songs folder", t);
               BlueClient.getInstance().notificationManager().add("Couldn't open songs folder", 0xFFFF5C5C);
            }
            this.songsCache = null;
            return true;
         }
         if (tag.startsWith("songs:play:")) {
            try {
               // NOTE: "songs:play:" is 11 chars - the old substring(10) kept the
               // trailing colon, parseInt threw NumberFormatException and the click
               // was silently swallowed (songs never played). Fixed 2026-09-15.
               int i = Integer.parseInt(tag.substring(11));
               List<Path> songs = this.songs();
               if (i >= 0 && i < songs.size()) {
                  RenderUtil.clickSound();
                  // Queue instead of replacing: picking a second song while one is
// playing should line it up, not play both at once.
net.bluenetwork.client.module.impl.MusicPlayer.enqueue(songs.get(i));
               }
            } catch (NumberFormatException ignored) {
            } catch (Throwable t) {
               BlueClient.LOGGER.error("Song dropdown playback failed", t);
            }
            return true;
         }
         if (tag.startsWith("action:")) {
            try {
               if (this.module instanceof ModuleActions actions) {
                  int index = Integer.parseInt(tag.substring(7));
                  actions.onAction(index);
                  // Convenience: committing a link plays it (Music Player).
                  RenderUtil.clickSound();
               }
            } catch (NumberFormatException ignored) {
            }
            return true;
         }
      }
      this.editingString = null;
      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseDragged(Click click, double dx, double dy) {
      float s = this.drawScale;
      int mx = (int) (click.x() / s);
      if (this.draggingNumber != null) {
         this.applySlider(this.draggingNumber, mx);
         return true;
      }
      if (this.draggingColor != null) {
         this.applyColorSlider(this.draggingColor, this.draggingChannel, mx);
         return true;
      }
      return super.mouseDragged(click, dx, dy);
   }

   @Override
   public boolean mouseReleased(Click click) {
      this.draggingNumber = null;
      this.draggingColor = null;
      this.draggingChannel = -1;
      return super.mouseReleased(click);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
      float s = this.drawScale;
      if (my / s >= this.listTop && my / s <= this.listBottom) {
         this.targetScroll -= (float) vAmount * 26.0F;
         return true;
      }
      return super.mouseScrolled(mx, my, hAmount, vAmount);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.editingNumber != null) {
         if (key == 259) {                          // backspace
            if (!this.numberDraft.isEmpty()) {
               this.numberDraft = this.numberDraft.substring(0,
                  this.numberDraft.length() - 1);
            }
            return true;
         }
         if (key == 257 || key == 335) {            // enter
            commitNumberDraft();
            return true;
         }
         if (key == 256) {                          // escape: discard
            this.editingNumber = null;
            this.numberDraft = "";
            return true;
         }
         return true;
      }
      if (this.bindListening) {
         this.module.setKeybind(key == 256 ? 0 : key);
         this.bindListening = false;
         RenderUtil.clickSound();
         return true;
      }
      if (this.editingString != null) {
         if (key == 257 || key == 256) {
            // Committing the Link field of a module with a PLAY action plays it.
            if (key == 257 && "Link".equals(this.editingString.getName())
               && this.module instanceof ModuleActions actions) {
               List<String> labels = actions.actionLabels();
               for (int i = 0; i < labels.size(); i++) {
                  if ("PLAY".equals(labels.get(i))) {
                     actions.onAction(i);
                     break;
                  }
               }
            }
            this.editingString = null;
            return true;
         }
         if (key == 86 && (input.modifiers() & 2) != 0) {
            try {
               String clip = this.client.keyboard.getClipboard();
               if (clip != null && !clip.isEmpty()) {
                  this.editingString.type(clip.replaceAll("[\\r\\n\\t]", ""));
               }
            } catch (Throwable ignored) {
            }
            return true;
         }
         if (key == 259) {
            this.editingString.backspace();
            return true;
         }
         return true;
      }
      if (key == 256) {
         if (!this.query.isEmpty()) {
            this.query = "";
            return true;
         }
         this.client.setScreen(this.parent);
         return true;
      }
      if (key == 264 || key == 266) {
         this.targetScroll += 40;
         return true;
      }
      if (key == 265 || key == 267) {
         this.targetScroll -= 40;
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.editingNumber != null && input.isValidChar()) {
         char ch = (char) input.codepoint();
         // Digits, one sign, one decimal point. Filtering here means the
         // field can never hold something unparseable.
         boolean digit = ch >= '0' && ch <= '9';
         boolean sign = (ch == '-' || ch == '+') && this.numberDraft.isEmpty();
         boolean dot = ch == '.' && !this.numberDraft.contains(".");
         if ((digit || sign || dot) && this.numberDraft.length() < 12) {
            this.numberDraft += ch;
         }
         return true;
      }
      if (this.editingString != null && input.isValidChar()) {
         String ch = input.asString();
         if (ch.length() == 1 && ch.charAt(0) != '§') {
            this.editingString.type(ch);
         }
         return true;
      }
      if (this.searchFocused && input.isValidChar()) {
         char ch = (char) input.codepoint();
         if (ch >= 32 && ch < 127) {
            this.query += ch;
            this.targetScroll = 0;
            return true;
         }
      }
      return super.charTyped(input);
   }

   /* =========================================================== helpers */

   /** Parses and applies the typed value, clamping to the setting's range. */
   private void commitNumberDraft() {
      if (this.editingNumber == null) {
         return;
      }
      try {
         String t = this.numberDraft.trim();
         if (!t.isEmpty() && !t.equals("-") && !t.equals("+") && !t.equals(".")) {
            this.editingNumber.setExact(Double.parseDouble(t));
         }
      } catch (NumberFormatException ignored) {
         // Impossible given the input filter, but never throw from a UI commit.
      }
      this.editingNumber = null;
      this.numberDraft = "";
      RenderUtil.clickSound();
   }

   private void applySlider(NumberSetting number, int mx) {
      double ratio = (mx - this.dragX0) / Math.max(1.0F, this.dragX1 - this.dragX0);
      ratio = Math.max(0.0, Math.min(1.0, ratio));
      double value = number.getMin() + ratio * (number.getMax() - number.getMin());

      // Snap to zero near the middle of a signed range. Lyric Offset spans
      // -5000..5000 in ~180px, so one pixel is ~55 units and hitting exactly 0
      // by dragging is impossible - the reported "you can only get 50 or -50".
      if (number.getMin() < 0.0 && number.getMax() > 0.0) {
         double span = number.getMax() - number.getMin();
         double perPixel = span / Math.max(1.0F, this.dragX1 - this.dragX0);
         if (Math.abs(value) < perPixel * 1.5) {
            value = 0.0;
         }
      }
      number.set(value);
   }

   private void applyColorSlider(ColorSetting color, int channel, int mx) {
      double ratio = (mx - this.dragX0) / Math.max(1.0F, this.dragX1 - this.dragX0);
      ratio = Math.max(0.0, Math.min(1.0, ratio));
      int value = (int) Math.round(ratio * 255.0);
      int r = channel == 0 ? value : color.red();
      int g = channel == 1 ? value : color.green();
      int b = channel == 2 ? value : color.blue();
      color.setRgb(r, g, b);
   }

   private void cycleMode(String name) {
      ModeSetting mode = this.findMode(name);
      if (mode == null) {
         return;
      }
      List<String> modes = mode.getModes();
      int index = modes.indexOf(mode.get());
      mode.set(modes.get((index + 1) % modes.size()));
   }

   private BooleanSetting findBoolean(String name) {
      for (Setting<?> s : this.module.getSettings()) {
         if (s.getName().equals(name) && s instanceof BooleanSetting b) {
            return b;
         }
      }
      return null;
   }

   private ModeSetting findMode(String name) {
      for (Setting<?> s : this.module.getSettings()) {
         if (s.getName().equals(name) && s instanceof ModeSetting mode) {
            return mode;
         }
      }
      return null;
   }

   private NumberSetting findNumber(String name) {
      for (Setting<?> s : this.module.getSettings()) {
         if (s.getName().equals(name) && s instanceof NumberSetting n) {
            return n;
         }
      }
      return null;
   }

   private ColorSetting findColor(String name) {
      for (Setting<?> s : this.module.getSettings()) {
         if (s.getName().equals(name) && s instanceof ColorSetting c) {
            return c;
         }
      }
      return null;
   }

   private StringSetting findString(String name) {
      for (Setting<?> s : this.module.getSettings()) {
         if (s.getName().equals(name) && s instanceof StringSetting str) {
            return str;
         }
      }
      return null;
   }

   private static String trim(double value) {
      return value == Math.rint(value) ? String.valueOf((long) value) : String.format(Locale.ROOT, "%.2f", value);
   }

   private static String fit(String text, int maxWidth) {
      if (text == null || text.isEmpty() || maxWidth <= 0) {
         return "";
      }
      if (RenderUtil.textWidth(text) <= maxWidth) {
         return text;
      }
      /*
       * The ellipsis must be measured TOO.
       *
       * The old loop trimmed until the bare text fit, then appended "..." -
       * so the returned string was up to ~8px WIDER than maxWidth. Centred
       * labels are drawn at (x + w/2 - width/2), so an over-wide string spills
       * past both edges and reads as off-centre. It only showed up on long
       * labels, which is why the owner saw it "sometimes".
       */
      int ellipsis = RenderUtil.textWidth("...");
      String t = text;
      while (!t.isEmpty() && RenderUtil.textWidth(t) + ellipsis > maxWidth) {
         t = t.substring(0, t.length() - 1);
      }
      return t.isEmpty() ? text.substring(0, 1) : t + "...";
   }

   private static String fitPoppins(String text, int maxWidth, float size) {
      if (text == null) {
         return "";
      }
      if (TextPainter.poppinsWidth(text, size) <= maxWidth) {
         return text;
      }
      // Measure the ellipsis as well - see fit().
      float ellipsis = TextPainter.poppinsWidth("...", size);
      String t = text;
      while (!t.isEmpty() && TextPainter.poppinsWidth(t, size) + ellipsis > maxWidth) {
         t = t.substring(0, t.length() - 1);
      }
      return t.isEmpty() ? text.substring(0, 1) : t + "...";
   }

   private static String keyName(int key) {
      if (key <= 0) {
         return "NONE";
      }
      return switch (key) {
         case 32 -> "SPACE";
         case 340 -> "LSHIFT";
         case 341 -> "RSHIFT";
         case 342 -> "ALT";
         default -> {
            String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(key, 0);
            yield name != null ? name.toUpperCase(Locale.ROOT) : ("KEY " + key);
         }
      };
   }


   /* ---- shared glass material (same recipe as the modules menu) ---- */

   private net.bluenetwork.client.module.impl.MenuCustomizer customizer() {
      for (net.bluenetwork.client.module.Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof net.bluenetwork.client.module.impl.MenuCustomizer mc) {
            return mc;
         }
      }
      return null;
   }

   private net.bluenetwork.client.module.impl.MenuCustomizer activeCustomizer() {
      net.bluenetwork.client.module.impl.MenuCustomizer mc = this.customizer();
      return mc != null && mc.isEnabled() ? mc : null;
   }

   private float bodyAlpha() {
      net.bluenetwork.client.module.impl.MenuCustomizer mc = this.activeCustomizer();
      int o = mc != null ? Math.max(0, Math.min(100, mc.opacityPercent()))
         : net.bluenetwork.client.module.impl.MenuCustomizer.DEFAULT_OPACITY;
      return Math.min(1.0F, 0.35F + 0.65F * (o / 100.0F));
   }

   private int cardFill(int baseArgb) {
      net.bluenetwork.client.module.impl.MenuCustomizer mc = this.activeCustomizer();
      int o = mc != null ? Math.max(0, Math.min(100, mc.opacityPercent()))
         : net.bluenetwork.client.module.impl.MenuCustomizer.DEFAULT_OPACITY;
      float alpha = 0.15F + 0.85F * (o / 100.0F);
      return withAlpha(baseArgb & 0x00FFFFFF, alpha);
   }
   private static int withAlpha(int color, float alpha) {
      int a = (int) (alpha * 255.0F) & 0xFF;
      return (a << 24) | (color & 0x00FFFFFF);
   }

   @Override
   public void removed() {
      try {
         this.blue.configManager().save();
      } catch (Throwable ignored) {
      }
      super.removed();
   }

   private record Hit(Rect rect, String tag) {
   }

   private static final class Rect {
      final float x, y, w, h;

      Rect(float x, float y, float w, float h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
