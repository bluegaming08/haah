package net.bluenetwork.client.ui.screen;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.social.FriendsManager;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * A DM or group conversation.
 *
 * <h2>Design</h2>
 * Chat bubbles: your own messages align right in the accent colour, theirs
 * align left in panel grey, with the sender's name shown only in groups (in a
 * 1:1 DM you already know who is talking). Long messages wrap.
 *
 * <h2>Refresh strategy</h2>
 * Polls every 3 seconds <b>only while this screen is open</b>, which is the
 * one place in the client where near-real-time actually matters. Closing the
 * screen stops it dead. There is no websocket: Supabase Realtime would be a
 * new dependency and a persistent connection for a feature most players use
 * for a few seconds at a time.
 *
 * <p>Messages are capped at 256 characters by the database, and the input
 * enforces the same limit so the player sees the ceiling rather than an
 * error.</p>
 */
public class ChatScreen extends Screen {

   private static final int DESIGN_W = 700;
   private static final int DESIGN_H = 430;
   private static final int GREY = 0xFF8A94A6;
   private static final long POLL_MS = 3_000L;
   private static final int MAX_LEN = 256;

   private final Screen parent;
   private final String convId;

   private volatile List<FriendsManager.Message> messages = List.of();
   private String draft = "";
   private boolean inputFocused = true;
   private long lastPoll;
   private boolean sending;

   private float scroll;
   private boolean stickToBottom = true;
   private float drawScale = 1.0F;
   private final List<Hit> hits = new ArrayList<>();

   public ChatScreen(Screen parent, String convId) {
      super(Text.literal("Chat"));
      this.parent = parent;
      this.convId = convId;
   }

   private static FriendsManager social() {
      return BlueClient.getInstance().friends();
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   protected void init() {
      reload();
      social().markRead(this.convId);
   }

   private void reload() {
      this.lastPoll = System.currentTimeMillis();
      social().loadMessages(this.convId, list -> this.messages = list);
   }

   private String title() {
      for (FriendsManager.Conversation c : social().conversations()) {
         if (c.id().equals(this.convId)) {
            return c.title();
         }
      }
      return "Chat";
   }

   /* ====================================================================== */
   /*  Render                                                                */
   /* ====================================================================== */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0xB20B0E14);

      float base = 0.75F;
      float fit = Math.min(1.0F,
         Math.min(w / (base * DESIGN_W + 12.0F), h / (base * DESIGN_H + 12.0F)));
      float scale = base * Math.max(0.35F, fit);
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int mx = (int) (mouseX / scale);
      int my = (int) (mouseY / scale);

      float pw = Math.min(vw - 24, 420);
      float ph = Math.min(vh - 24, 400);
      float px = (vw - pw) / 2.0F;
      float py = (vh - ph) / 2.0F;

      this.hits.clear();
      PremiumRender.drawShadow(context, (int) px - 2, (int) py - 2,
         (int) pw + 4, (int) ph + 4, 0x77000000, 14);
      SmoothRect.fill(context, px, py, pw, ph, 10.0F, DesignTokens.panelBg());
      SmoothRect.outline(context, px, py, pw, ph, 10.0F, 1.0F, DesignTokens.panelBorder());

      /* header */
      TextPainter.drawPoppins(context, title(), px + 14, py + 13, DesignTokens.textHi(), 11.0F);
      boolean hovX = hit(mx, my, px + pw - 24, py + 10, 14, 14);
      TextPainter.drawPoppins(context, "X", px + pw - 20, py + 13,
         hovX ? DesignTokens.textHi() : GREY, 10.0F);
      this.hits.add(new Hit(px + pw - 24, py + 10, 14, 14, "close"));
      context.fill((int) px + 10, (int) py + 32, (int) (px + pw - 10), (int) py + 33, 0x22FFFFFF);

      /* messages */
      float listTop = py + 38;
      float listBottom = py + ph - 38;
      context.enableScissor((int) px + 8, (int) listTop, (int) (px + pw - 8), (int) listBottom);
      drawMessages(context, px, listTop, pw, listBottom);
      context.disableScissor();

      /* composer */
      drawComposer(context, px, py + ph - 32, pw, mx, my);

      context.getMatrices().popMatrix();

      // Poll only while open.
      if (System.currentTimeMillis() - this.lastPoll >= POLL_MS) {
         reload();
      }
   }

   private void drawMessages(DrawContext ctx, float px, float top, float pw, float bottom) {
      List<FriendsManager.Message> list = this.messages;
      if (list.isEmpty()) {
         float cx = px + pw / 2.0F;
         String t = "No messages yet. Say hello.";
         float tw = TextPainter.poppinsWidth(t, 8.0F);
         TextPainter.drawPoppins(ctx, t, cx - tw / 2.0F, top + 20, GREY, 8.0F);
         return;
      }

      String me = null;
      try {
         me = social().username();
      } catch (Throwable ignored) {
      }

      boolean group = isGroup();
      float maxBubble = pw * 0.68F;

      // Measure everything first so we can anchor the newest message to the
      // bottom - the natural reading position for a chat.
      float totalH = 0;
      List<List<String>> wrapped = new ArrayList<>();
      for (FriendsManager.Message m : list) {
         List<String> lines = wrap(m.body(), maxBubble - 14, 8.0F);
         wrapped.add(lines);
         totalH += lines.size() * 10 + 10 + (group ? 8 : 0);
      }

      float viewH = bottom - top;
      float maxScroll = Math.max(0.0F, totalH - viewH);
      if (this.stickToBottom) {
         this.scroll = maxScroll;
      } else if (this.scroll > maxScroll) {
         this.scroll = maxScroll;
      }

      float y = top - this.scroll;
      for (int i = 0; i < list.size(); i++) {
         FriendsManager.Message m = list.get(i);
         List<String> lines = wrapped.get(i);
         boolean mine = me != null && me.equals(m.senderName());

         float bw = 0;
         for (String l : lines) {
            bw = Math.max(bw, TextPainter.poppinsWidth(l, 8.0F));
         }
         bw += 14;
         float bh = lines.size() * 10 + 8;
         float bx = mine ? px + pw - 12 - bw : px + 12;

         if (y + bh > top - 20 && y < bottom + 20) {
            if (group && !mine) {
               TextPainter.drawPoppins(ctx, m.senderName(), bx + 2, y,
                  DesignTokens.accent(), 6.5F);
            }
            float by = y + (group && !mine ? 8 : 0);
            SmoothRect.fill(ctx, bx, by, bw, bh, 6.0F,
               mine ? withAlpha(DesignTokens.accent(), 0.85F) : 0x33FFFFFF);
            float ty = by + 4;
            for (String l : lines) {
               TextPainter.drawPoppins(ctx, l, bx + 7, ty,
                  mine ? 0xFFFFFFFF : DesignTokens.textHi(), 8.0F);
               ty += 10;
            }
         }
         y += bh + 10 + (group && !mine ? 8 : 0);
      }
   }

   private boolean isGroup() {
      for (FriendsManager.Conversation c : social().conversations()) {
         if (c.id().equals(this.convId)) {
            return c.group();
         }
      }
      return false;
   }

   /** Greedy word wrap. Falls back to hard-splitting a single long word. */
   private static List<String> wrap(String text, float maxW, float size) {
      List<String> out = new ArrayList<>();
      if (text == null || text.isEmpty()) {
         out.add("");
         return out;
      }
      StringBuilder line = new StringBuilder();
      for (String word : text.split(" ")) {
         String candidate = line.isEmpty() ? word : line + " " + word;
         if (TextPainter.poppinsWidth(candidate, size) <= maxW) {
            line = new StringBuilder(candidate);
            continue;
         }
         if (!line.isEmpty()) {
            out.add(line.toString());
            line = new StringBuilder();
         }
         // A single word longer than the bubble: split it by character.
         String rest = word;
         while (TextPainter.poppinsWidth(rest, size) > maxW && rest.length() > 1) {
            int cut = rest.length();
            while (cut > 1 && TextPainter.poppinsWidth(rest.substring(0, cut), size) > maxW) {
               cut--;
            }
            out.add(rest.substring(0, cut));
            rest = rest.substring(cut);
         }
         line = new StringBuilder(rest);
      }
      if (!line.isEmpty()) {
         out.add(line.toString());
      }
      if (out.isEmpty()) {
         out.add("");
      }
      return out;
   }

   private void drawComposer(DrawContext ctx, float px, float y, float pw, int mx, int my) {
      float fieldW = pw - 24 - 54;
      SmoothRect.fill(ctx, px + 12, y, fieldW, 22, 5.0F, 0x33000000);
      SmoothRect.outline(ctx, px + 12, y, fieldW, 22, 5.0F, 1.0F,
         this.inputFocused ? DesignTokens.accent() : DesignTokens.panelBorder());

      String shown = this.draft.isEmpty() ? "Write a message..." : this.draft;
      while (TextPainter.poppinsWidth(shown, 8.5F) > fieldW - 14 && shown.length() > 1) {
         shown = shown.substring(1);
      }
      TextPainter.drawPoppins(ctx, shown, px + 19, y + 7,
         this.draft.isEmpty() ? GREY : DesignTokens.textHi(), 8.5F);

      if (this.inputFocused && !this.draft.isEmpty()
         && (System.currentTimeMillis() / 500L) % 2L == 0L) {
         float w = TextPainter.poppinsWidth(shown, 8.5F);
         ctx.fill((int) (px + 20 + w), (int) y + 6, (int) (px + 21 + w), (int) y + 16,
            DesignTokens.textHi());
      }
      this.hits.add(new Hit(px + 12, y, fieldW, 22, "focus"));

      boolean can = !this.draft.isBlank() && !this.sending;
      float bx = px + pw - 12 - 48;
      boolean over = can && hit(mx, my, bx, y, 48, 22);
      SmoothRect.fill(ctx, bx, y, 48, 22, 5.0F,
         !can ? 0x18FFFFFF : over ? DesignTokens.accent() : 0x44FFFFFF);
      float tw = TextPainter.poppinsWidth("SEND", 7.5F);
      TextPainter.drawPoppins(ctx, "SEND", bx + 24 - tw / 2.0F, y + 8,
         can ? DesignTokens.textHi() : 0x55FFFFFF, 7.5F);
      if (can) {
         this.hits.add(new Hit(bx, y, 48, 22, "send"));
      }

      if (this.draft.length() > MAX_LEN - 40) {
         String left = (MAX_LEN - this.draft.length()) + "";
         TextPainter.drawPoppins(ctx, left, px + 12 + fieldW - 22, y - 9, GREY, 6.5F);
      }
   }

   /* ====================================================================== */
   /*  Input                                                                 */
   /* ====================================================================== */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      int mx = (int) (click.x() / this.drawScale);
      int my = (int) (click.y() / this.drawScale);
      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit h = this.hits.get(i);
         if (mx >= h.x && mx <= h.x + h.w && my >= h.y && my <= h.y + h.h) {
            switch (h.tag) {
               case "close" -> close();
               case "focus" -> this.inputFocused = true;
               case "send" -> send();
               default -> {
               }
            }
            return true;
         }
      }
      return super.mouseClicked(click, doubled);
   }

   private void send() {
      String text = this.draft.trim();
      if (text.isEmpty() || this.sending) {
         return;
      }
      this.sending = true;
      this.draft = "";
      this.stickToBottom = true;
      social().sendMessage(this.convId, text, () -> {
         this.sending = false;
         reload();
      });
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (!this.inputFocused) {
         return super.charTyped(input);
      }
      String c = input.asString();
      if (c != null && !c.isEmpty() && this.draft.length() < MAX_LEN) {
         this.draft += c;
      }
      return true;
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.inputFocused) {
         if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (!this.draft.isEmpty()) {
               this.draft = this.draft.substring(0, this.draft.length() - 1);
            }
            return true;
         }
         if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            send();
            return true;
         }
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double h, double v) {
      this.scroll -= (float) v * 16.0F;
      if (this.scroll < 0.0F) {
         this.scroll = 0.0F;
      }
      // Scrolling up detaches from the bottom; scrolling back down re-attaches.
      this.stickToBottom = v < 0;
      return true;
   }

   @Override
   public void removed() {
      social().markRead(this.convId);
      super.removed();
   }

   private static int withAlpha(int argb, float a) {
      int alpha = Math.max(0, Math.min(255, (int) (a * 255.0F)));
      return (alpha << 24) | (argb & 0xFFFFFF);
   }

   private static boolean hit(int mx, int my, float x, float y, float w, float h) {
      return mx >= x && mx <= x + w && my >= y && my <= y + h;
   }

   @Override
   public void close() {
      if (this.parent != null) {
         this.client.setScreen(this.parent);
      } else {
         super.close();
      }
   }

   private record Hit(float x, float y, float w, float h, String tag) {
   }
}
