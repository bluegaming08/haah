package net.bluenetwork.client.module.impl;

import java.util.List;
import java.util.Random;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HitReactor;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

/**
 * Always Particles - spawns impact particles on every attack, client-side and
 * unconditionally (the vanilla particle video setting cannot hide them, they
 * are injected straight into the local particle manager). Cosmetic only.
 */
public class AlwaysParticles extends Module implements HitReactor {
   private final Random random = new Random();
   private final ModeSetting particle = new ModeSetting("Particle", "Which particle bursts on hit",
      List.of("CRIT", "DAMAGE", "ENCHANT", "POOF", "INK"), "CRIT");
   private final NumberSetting count = new NumberSetting("Count", "Particles per hit", 8.0, 1.0, 24.0, 1.0);

   public AlwaysParticles() {
      super("Always Particles", "Impact particles on every hit, ignoring particle settings", Category.COMBAT);
   }

   @Override
   public void onHit(PlayerEntity attacker, Entity target) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null) {
         return;
      }
      ParticleEffect type = switch (this.particle.get()) {
         case "DAMAGE" -> ParticleTypes.DAMAGE_INDICATOR;
         case "ENCHANT" -> ParticleTypes.ENCHANT;
         case "POOF" -> ParticleTypes.POOF;
         case "INK" -> ParticleTypes.SQUID_INK;
         default -> ParticleTypes.CRIT;
      };
      int n = this.count.get().intValue();
      for (int i = 0; i < n; i++) {
         double x = target.getX() + (this.random.nextDouble() - 0.5) * target.getWidth();
         double y = target.getY() + this.random.nextDouble() * target.getHeight();
         double z = target.getZ() + (this.random.nextDouble() - 0.5) * target.getWidth();
         double vx = (this.random.nextDouble() - 0.5) * 0.5;
         double vy = this.random.nextDouble() * 0.25 + 0.05;
         double vz = (this.random.nextDouble() - 0.5) * 0.5;
         mc.world.addParticleClient(type, x, y, z, vx, vy, vz);
      }
   }
}
