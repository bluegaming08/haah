package net.bluenetwork.client.account;

import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentHashMap.KeySetView;
import net.bluenetwork.client.BlueClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

/**
 * Player bust renders from <a href="https://mc-api.io">mc-api.io</a>.
 *
 * <h2>What this is for</h2>
 * The account manager and the main-menu player card used to draw a flat 8×8
 * slice of the skin texture. This fetches a proper 3D bust render instead:
 *
 * <pre>https://mc-api.io/render/BUST/&lt;username&gt;/JAVA?size=256</pre>
 *
 * <h2>Rules this class follows</h2>
 * <ol>
 *   <li><b>Never block the render thread.</b> {@link #bust(String)} returns
 *       immediately — {@code null} on a miss — and kicks off a background
 *       download. The caller simply draws a fallback until the next frame has
 *       it. Screens repaint constantly, so nothing needs a callback.</li>
 *   <li><b>One request per name, ever.</b> {@link #requested} latches before
 *       the thread starts. Without it a screen rendering at 60 fps would fire
 *       sixty identical HTTP requests a second and get rate-limited.</li>
 *   <li><b>Failures are remembered.</b> A miss is cached too, so an invalid or
 *       unrendered username does not retry forever.</li>
 *   <li><b>Textures are registered on the client thread.</b> Uploading a
 *       texture touches GL state, so registration is handed back via
 *       {@code MinecraftClient.execute}.</li>
 * </ol>
 *
 * <p>The API returns a 256×256 RGBA PNG with a transparent background, so the
 * bust composites cleanly over any panel.</p>
 */
public final class PlayerHeads {

   /** Bust render endpoint; {@code %s} is the username. */
   private static final String BUST_URL = "https://mc-api.io/render/BUST/%s/JAVA?size=256";

   /**
    * HEAD render endpoint - just the face, no shoulders.
    *
    * <p>Used by the quick menu, where a square head reads better in a small
    * circular frame than a bust does.</p>
    */
   private static final String HEAD_URL = "https://mc-api.io/render/HEAD/%s/JAVA?size=256";

   /** Profile lookup (uuid, skin url, …) — kept for future use. */
   private static final String PROFILE_URL = "https://mc-api.io/profile/%s/JAVA";

   private static final Duration TIMEOUT = Duration.ofSeconds(8L);

   /** Successfully loaded busts, by lowercase username. */
   private static final Map<String, Identifier> CACHE = new ConcurrentHashMap<>();

   /** Names already requested (whether or not they succeeded). */
   private static final KeySetView<String, Boolean> requested = ConcurrentHashMap.newKeySet();

   /** Names that failed; used to draw the fallback without retrying. */
   private static final KeySetView<String, Boolean> failed = ConcurrentHashMap.newKeySet();

   private static final HttpClient HTTP = HttpClient.newBuilder()
      .connectTimeout(TIMEOUT)
      .followRedirects(HttpClient.Redirect.NORMAL)
      .build();

   private PlayerHeads() {
   }

   /**
    * The bust texture for {@code username}, or {@code null} if it is not ready.
    *
    * <p>Safe to call every frame: the first call starts one download, later
    * calls are a map lookup.</p>
    */
   public static Identifier bust(String username) {
      return render(username, false);
   }

   /**
    * A HEAD render for {@code username}, or null while it loads.
    *
    * <p>Cached separately from the bust: the two are different images for the
    * same player, so they must not share a key.</p>
    */
   public static Identifier head(String username) {
      return render(username, true);
   }

   private static Identifier render(String username, boolean headOnly) {
      if (username == null || username.isBlank()) {
         return null;
      }
      String key = (headOnly ? "head:" : "")
         + username.toLowerCase(Locale.ROOT);
      Identifier cached = CACHE.get(key);
      if (cached != null) {
         return cached;
      }
      if (requested.add(key)) {
         download(username, key, headOnly);
      }
      return null;
   }

   /** True when this name was tried and did not produce a render. */
   public static boolean unavailable(String username) {
      return username != null && failed.contains(username.toLowerCase(Locale.ROOT));
   }

   /** Drops a cached bust so the next {@link #bust} call re-fetches it. */
   public static void forget(String username) {
      if (username == null) {
         return;
      }
      String key = username.toLowerCase(Locale.ROOT);
      CACHE.remove(key);
      requested.remove(key);
      failed.remove(key);
      // The head render is a separate cache entry for the same player.
      CACHE.remove("head:" + key);
      requested.remove("head:" + key);
      failed.remove("head:" + key);
   }

   private static void download(String username, String key, boolean headOnly) {
      Thread thread = new Thread(() -> {
         try {
            HttpRequest request = HttpRequest.newBuilder(
                  URI.create(String.format(headOnly ? HEAD_URL : BUST_URL,
                     encode(username))))
               .timeout(TIMEOUT)
               .header("User-Agent", "BlueClient")
               .GET()
               .build();

            HttpResponse<InputStream> response = HTTP.send(request, BodyHandlers.ofInputStream());
            if (response.statusCode() / 100 != 2) {
               failed.add(key);
               BlueClient.LOGGER.debug("Bust render for {} returned HTTP {}", username, response.statusCode());
               return;
            }

            // Decode off-thread; only the GL upload has to be on the client thread.
            NativeImage image;
            try (InputStream body = response.body()) {
               image = NativeImage.read(body);
            }

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null) {
               image.close();
               failed.add(key);
               return;
            }
            mc.execute(() -> {
               try {
                  NativeImageBackedTexture texture =
                     new NativeImageBackedTexture(() -> "blueclient/bust/" + key, image);
                  Identifier id = Identifier.of("blueclient", "dynamic/bust/" + sanitize(key));
                  mc.getTextureManager().registerTexture(id, texture);
                  CACHE.put(key, id);
               } catch (Throwable t) {
                  failed.add(key);
                  BlueClient.LOGGER.debug("Could not register bust texture for {}", username, t);
               }
            });
         } catch (Throwable t) {
            failed.add(key);
            BlueClient.LOGGER.debug("Bust render failed for {}: {}", username, t.toString());
         }
      }, "Blue Client Bust " + username);
      thread.setDaemon(true);
      thread.start();
   }

   /** Identifiers accept only [a-z0-9_.-/]; usernames allow more than that. */
   private static String sanitize(String key) {
      StringBuilder out = new StringBuilder(key.length());
      for (char c : key.toCharArray()) {
         out.append((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '.' || c == '-'
            ? c : '_');
      }
      return out.isEmpty() ? "unknown" : out.toString();
   }

   private static String encode(String value) {
      return java.net.URLEncoder.encode(value, java.nio.charset.StandardCharsets.UTF_8);
   }
}
