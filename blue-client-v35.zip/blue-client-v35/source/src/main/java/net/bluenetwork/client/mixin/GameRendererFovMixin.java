package net.bluenetwork.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.bluenetwork.client.module.impl.CustomFov;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Applies the FOV Changer's dynamic multiplier to the renderer's FOV.
 *
 * <h2>Why not just set the FOV option</h2>
 * The vanilla FOV option is an <b>integer</b>. Writing it every frame to
 * animate a transition produces visible 1-degree steps. {@code getFov} returns
 * a float that feeds the projection matrix directly, so scaling its return
 * value gives genuinely smooth motion.
 *
 * <p>Uses {@code @ModifyReturnValue} rather than {@code @Redirect} (forbidden
 * in this codebase — MixinExtras 0.5.4 throws a CCE) and pins the full
 * descriptor on one line, because {@code getFov} is private and overloaded-
 * prone; a bare name could bind a synthetic bridge.</p>
 *
 * <p>{@code require = 0} so a Minecraft update that renames this method
 * degrades to "no dynamic FOV" instead of refusing to launch.</p>
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererFovMixin {

   /** Timestamp of the previous call, for frame-rate independent easing. */
   @org.spongepowered.asm.mixin.Unique
   private long blueclient$lastFovNanos = 0L;

   @ModifyReturnValue(
      method = "getFov(Lnet/minecraft/client/render/Camera;FZ)F",
      at = @At("RETURN"),
      require = 0
   )
   private float blueclient$dynamicFov(float original) {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc == null || mc.player == null) {
            return original;
         }
         long now = System.nanoTime();
         float delta = this.blueclient$lastFovNanos == 0L
            ? 1.0F / 60.0F
            : (now - this.blueclient$lastFovNanos) / 1_000_000_000.0F;
         this.blueclient$lastFovNanos = now;
         // Clamp: a long pause (alt-tab, lag spike) must not teleport the FOV.
         delta = Math.max(0.0F, Math.min(0.25F, delta));

         float multiplier = CustomFov.dynamicMultiplier(delta);
         if (multiplier == 1.0F) {
            return original;
         }
         return original * multiplier;
      } catch (Throwable t) {
         return original;
      }
   }
}
