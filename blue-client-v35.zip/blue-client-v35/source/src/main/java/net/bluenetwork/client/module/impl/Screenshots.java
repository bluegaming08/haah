package net.bluenetwork.client.module.impl;

import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.image.BufferedImage;
import java.nio.file.Path;
import javax.imageio.ImageIO;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Screenshots (v0.19.0) — richer screenshot feedback. Every vanilla
 * screenshot (F2 / whatever you rebound it to) posts a chat line with two
 * clickable buttons:
 *
 * <pre>Took screenshot: 2026-09-15_22.05.33.png  [Copy] [Open]</pre>
 *
 * <p>Copy (green, bold) copies the absolute file path to the OS clipboard via
 * the vanilla COPY_TO_CLIPBOARD click event; Open (blue, bold) opens the file
 * with the OS image viewer via the vanilla OPEN_FILE click event. The
 * "Auto-copy image" setting additionally pushes the actual picture (not just
 * the path) onto the clipboard using AWT right after every screenshot.</p>
 */
public class Screenshots extends Module {
   private final BooleanSetting buttons = new BooleanSetting("Chat buttons", "Add clickable Copy / Open to the screenshot message", true);
   private final BooleanSetting autoCopyImage = new BooleanSetting("Auto-copy image", "Copy the picture itself to the clipboard after every shot", false);

   public Screenshots() {
      super("Screenshots", "Clickable Copy / Open buttons on every screenshot message", Category.MISC);
      this.addSettings(new Setting[]{this.buttons, this.autoCopyImage});
   }

   /** True when the chat buttons should replace the vanilla message. */
   public static boolean chatButtons() {
      Module m = BlueClient.getInstance().moduleManager().byName("Screenshots");
      return m instanceof Screenshots s && m.isEnabled() && s.buttons.get();
   }

   /** True when the image bytes should land on the OS clipboard automatically. */
   public static boolean autoCopy() {
      Module m = BlueClient.getInstance().moduleManager().byName("Screenshots");
      return m instanceof Screenshots s && m.isEnabled() && s.autoCopyImage.get();
   }

   /**
    * Pushes the screenshot file onto the OS clipboard as a real image (AWT).
    *
    * <h2>v21: this is now refused on macOS, and why</h2>
    * Since the move to LWJGL3, Minecraft runs with {@code java.awt.headless=true}
    * and GLFW owns the process's first thread. On macOS, AWT and GLFW both want
    * the AppKit run loop: touching {@code Toolkit.getDefaultToolkit()} from a
    * GLFW process started with {@code -XstartOnFirstThread} can <b>deadlock the
    * whole game</b> rather than throw. A try/catch cannot rescue a deadlock -
    * the only safe move is not to make the call.
    *
    * <p>This is the most likely source of the owner's unreproduced Linux/Mac
    * report. There was no crash log to work from, so this was found by
    * auditing for platform-specific hazards rather than by reading a stack
    * trace; the surrounding code is unchanged on Windows, where it works.</p>
    *
    * <p>On Linux the call is allowed but the headless flag is checked first,
    * because a headless JVM throws {@code HeadlessException} here and there is
    * no clipboard to write to under a bare X/Wayland session without AWT.</p>
    */
   public static void copyImageToClipboard(Path file) {
      if (!clipboardImageSupported()) {
         // Not an error: the screenshot is still saved, it just is not copied.
         BlueClient.LOGGER.info(
            "Screenshot saved; image-to-clipboard is unavailable on this platform");
         return;
      }
      try {
         BufferedImage image = ImageIO.read(file.toFile());
         if (image == null) {
            return;
         }
         final BufferedImage converted = image.getType() == BufferedImage.TYPE_INT_ARGB
            ? image : copyToRgb(image);
         Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new ImageSelection(converted), null);
      } catch (Throwable t) {
         BlueClient.LOGGER.warn("Couldn't copy screenshot image to clipboard", t);
      }
   }

   /**
    * Whether it is SAFE to touch AWT's clipboard on this machine.
    *
    * <p>Deliberately conservative: when in doubt, say no. Losing the
    * copy-to-clipboard convenience is a far smaller cost than hanging the
    * game, and the screenshot itself is written to disk either way.</p>
    */
   private static boolean clipboardImageSupported() {
      try {
         // macOS: never. See the note on copyImageToClipboard.
         if (net.minecraft.util.Util.getOperatingSystem()
            == net.minecraft.util.Util.OperatingSystem.OSX) {
            return false;
         }
         // A headless JVM has no clipboard at all.
         if (Boolean.getBoolean("java.awt.headless")) {
            return false;
         }
         if (java.awt.GraphicsEnvironment.isHeadless()) {
            return false;
         }
         return true;
      } catch (Throwable t) {
         return false;
      }
   }

   private static BufferedImage copyToRgb(BufferedImage src) {
      BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
      Graphics2D g = out.createGraphics();
      try {
         g.drawImage(src, 0, 0, null);
      } finally {
         g.dispose();
      }
      return out;
   }

   private static final class ImageSelection implements Transferable {
      private final BufferedImage image;

      ImageSelection(BufferedImage image) {
         this.image = image;
      }

      @Override
      public DataFlavor[] getTransferDataFlavors() {
         return new DataFlavor[]{DataFlavor.imageFlavor};
      }

      @Override
      public boolean isDataFlavorSupported(DataFlavor flavor) {
         return DataFlavor.imageFlavor.equals(flavor);
      }

      @Override
      public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException {
         if (DataFlavor.imageFlavor.equals(flavor)) {
            return this.image;
         }
         throw new UnsupportedFlavorException(flavor);
      }
   }
}
