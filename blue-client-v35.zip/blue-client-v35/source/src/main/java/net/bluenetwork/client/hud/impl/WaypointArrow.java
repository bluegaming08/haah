package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Waypoint Arrow (v3 catalogue A8) — a compact HUD that always points from you
 * toward the world spawn. The arrow is screen-relative (↑ ahead, → to your
 * right, ...), followed by straight-line distance and, optionally, the
 * altitude difference (+up / -down). Pure math on your position vs spawn.
 */
public class WaypointArrow extends HudModule {
   /** Clockwise octants starting at straight-ahead. */
   private static final String[] ARROWS = {"\u2191", "\u2196", "\u2190", "\u2199", "\u2193", "\u2198", "\u2192", "\u2197"};

   private final ColorSetting textColor = new ColorSetting("Text color", "Readout colour", 0xFFFFFFFF);
   private final BooleanSetting showAltitude = new BooleanSetting("Show altitude", "Append +up / -down to the distance", true);

   public WaypointArrow() {
      super("Waypoint Arrow", "Direction + distance to world spawn", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.showAltitude});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 230);
   }

   private BlockPos target() {
      MinecraftClient mc = MinecraftClient.getInstance();
      World world = mc.world;
      return world == null ? null : world.getSpawnPoint().getPos();
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      BlockPos target = this.target();
      if (mc.player == null || target == null) {
         return "Spawn --";
      }
      Vec3d from = mc.player.getEntityPos();
      double dx = target.getX() + 0.5 - from.x;
      double dz = target.getZ() + 0.5 - from.z;
      double dy = target.getY() - from.y;
      double flat = Math.sqrt(dx * dx + dz * dz);
      double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

      // Camera forward = (-sin(yaw), cos(yaw)); its bearing is -yaw.
      // Target bearing = atan2(dx, dz). Positive relative angle = target to the left.
      double targetBearing = Math.toDegrees(Math.atan2(dx, dz));
      double rel = targetBearing + mc.player.getYaw();
      while (rel < -180.0) {
         rel += 360.0;
      }
      while (rel > 180.0) {
         rel -= 360.0;
      }
      int k = (int) Math.round(rel / 45.0);
      if (k == 4 || k == -4) {
         k = 4;
      } else {
         k = (k + 8) % 8;
      }
      String arrow = ARROWS[k];

      StringBuilder sb = new StringBuilder(arrow);
      if (this.showAltitude.get() && flat > 1.0E-3) {
         if (dy > 0.5) {
            sb.append(" +").append((int) Math.round(dy)).append('m');
         } else if (dy < -0.5) {
            sb.append(' ').append((int) Math.round(dy)).append('m');
         }
      }
      sb.append(' ').append((int) Math.round(dist)).append('m');
      return sb.toString();
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || this.target() == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
