package net.bluenetwork.client.ui.motion;

/**
 * Standard easing functions for the v2 motion system (plan §3.5). Pure math —
 * no state, safe to call on any thread. Complements the handful of helpers in
 * {@link net.bluenetwork.client.render.AnimationEngine} with the exact curves
 * the design system calls for.
 */
public enum Easing {
   LINEAR {
      @Override
      public float apply(float t) {
         return t;
      }
   },
   EASE_OUT_QUAD {
      @Override
      public float apply(float t) {
         return t * (2.0F - t);
      }
   },
   EASE_IN_OUT_QUAD {
      @Override
      public float apply(float t) {
         return t < 0.5F ? 2.0F * t * t : 1.0F - (float) Math.pow(-2.0F * t + 2.0F, 2.0D) / 2.0F;
      }
   },
   EASE_OUT_CUBIC {
      @Override
      public float apply(float t) {
         return 1.0F - (float) Math.pow(1.0D - clamp01(t), 3.0D);
      }
   },
   EASE_IN_OUT_CUBIC {
      @Override
      public float apply(float t) {
         return t < 0.5F ? 4.0F * t * t * t : 1.0F - (float) Math.pow(-2.0F * t + 2.0F, 3.0D) / 2.0F;
      }
   },
   EASE_OUT_QUART {
      @Override
      public float apply(float t) {
         return 1.0F - (float) Math.pow(1.0D - clamp01(t), 4.0D);
      }
   },
   EASE_OUT_EXPO {
      @Override
      public float apply(float t) {
         if (t <= 0.0F) {
            return 0.0F;
         }
         if (t >= 1.0F) {
            return 1.0F;
         }
         return 1.0F - (float) Math.pow(2.0D, -10.0D * t);
      }
   },
   /** Small overshoot for "satisfying" module-card toggles. */
   EASE_OUT_BACK {
      @Override
      public float apply(float t) {
         float c1 = 1.70158F;
         float c3 = c1 + 1.0F;
         float x = clamp01(t) - 1.0F;
         return 1.0F + c3 * x * x * x + c1 * x * x;
      }
   };

   public abstract float apply(float t);

   private static float clamp01(float t) {
      return Math.max(0.0F, Math.min(1.0F, t));
   }
}
