package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HitReactor;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.ScreenOverlay;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Hit Marker - draws four fading diagonal ticks around the crosshair for a
 * moment after each successful attack (Quake/CS-style hit feedback).
 */
public class HitMarker extends Module implements HitReactor, ScreenOverlay {
   private final ColorSetting color = new ColorSetting("Color", "Marker colour", 0xFFFFFF);
   private final NumberSetting duration = new NumberSetting("Duration", "Marker time in milliseconds", 140.0, 60.0, 400.0, 10.0);

   private volatile long lastHit = Long.MIN_VALUE;

   public HitMarker() {
      super("Hit Marker", "Crosshair tick flash on successful hits", Category.COMBAT);
   }

   @Override
   public void onHit(PlayerEntity attacker, Entity target) {
      this.lastHit = System.currentTimeMillis();
   }

   @Override
   public void renderOverlay(DrawContext context) {
      long dt = System.currentTimeMillis() - this.lastHit;
      float max = this.duration.get().floatValue();
      if (dt < 0 || dt > max) {
         return;
      }
      float fade = 1.0F - dt / max;
      int c = ((int) (255 * fade) << 24) | (this.color.rgb() & 0xFFFFFF);
      int cx = context.getScaledWindowWidth() / 2;
      int cy = context.getScaledWindowHeight() / 2;
      for (int i = 0; i < 5; i++) {
         int o = 4 + i;
         context.fill(cx + o, cy - o, cx + o + 1, cy - o + 1, c);
         context.fill(cx - o - 1, cy - o, cx - o, cy - o + 1, c);
         context.fill(cx + o, cy + o, cx + o + 1, cy + o + 1, c);
         context.fill(cx - o - 1, cy + o, cx - o, cy + o + 1, c);
      }
   }
}
