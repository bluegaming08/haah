package net.bluenetwork.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public abstract class Module {
   private final String name;
   private final String description;
   private final Category category;
   private final List<Setting<?>> settings = new ArrayList<>();
   private boolean enabled = false;
   private int keybind = 0;

   protected Module(String name, String description, Category category) {
      this.name = name;
      this.description = description;
      this.category = category;
   }

   protected void addSettings(Setting<?>... toAdd) {
      Collections.addAll(this.settings, toAdd);
   }

   public final void toggle() {
      this.setEnabled(!this.enabled);
   }

   public final void setEnabled(boolean value) {
      if (this.enabled != value) {
         this.enabled = value;
         if (value) {
            this.onEnable();
         } else {
            this.onDisable();
         }

         if (!(this instanceof HoldModule) && MinecraftClient.getInstance().player != null) {
            BlueClient.getInstance().notificationManager().addModuleToggle(this.name, value);
         }
      }
   }

   protected void onEnable() {
   }

   protected void onDisable() {
   }

   public boolean isRequired() {
      return false;
   }

   public void onTick() {
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public Category getCategory() {
      return this.category;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public List<Setting<?>> getSettings() {
      return this.settings;
   }

   public int getKeybind() {
      return this.keybind;
   }

   public void setKeybind(int keybind) {
      this.keybind = keybind;
   }

   /** Finds the registered module instance of the given type, or null. */
   public static <T extends Module> T find(Class<T> type) {
      try {
         for (Module m : net.bluenetwork.client.BlueClient.getInstance().moduleManager().getModules()) {
            if (type.isInstance(m)) {
               return type.cast(m);
            }
         }
      } catch (Throwable ignored) {
      }
      return null;
   }
}
