package net.bluenetwork.client.ui.widget;

import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.DrawContext;

/**
 * Value slider (BLUE_CLIENT_V3_MASTER_PLAN.md §4.2). Drag to set a number
 * within min/max snapped to step. Renders a thin track with an accent fill
 * ratio and a knob; the current value is drawn right-aligned inside the row.
 */
public class Slider extends Widget {
   private final double min;
   private final double max;
   private final double step;
   private double value;
   private final Runnable onChange;
   private boolean dragging = false;

   public Slider(double initialValue, double min, double max, double step, Runnable onChange) {
      this.min = min;
      this.max = Math.max(min, max);
      this.step = step > 0 ? step : 1.0;
      this.value = clamp(initialValue);
      this.onChange = onChange;
   }

   public double value() {
      return value;
   }

   private double clamp(double v) {
      double snapped = Math.round(v / step) * step;
      return Math.max(min, Math.min(max, snapped));
   }

   private void updateFromMouse(int mouseX) {
      double ratio = (mouseX - x) / (double) Math.max(1, w);
      ratio = Math.max(0.0, Math.min(1.0, ratio));
      value = clamp(min + ratio * (max - min));
      if (onChange != null) {
         onChange.run();
      }
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, long nowMs) {
      int trackH = 3;
      int ty = y + (h - trackH) / 2;
      double ratio = (max > min) ? (value - min) / (max - min) : 0.0;
      ratio = Math.max(0.0, Math.min(1.0, ratio));
      int fillW = (int) Math.round(ratio * w);

      // track background
      context.fill(x, ty, x + w, ty + trackH, DesignTokens.toggleOff());
      // fill
      context.fill(x, ty, x + fillW, ty + trackH, DesignTokens.accent());
      // knob
      int knobSize = Math.max(5, h - 6);
      int knobX = x + fillW - knobSize / 2;
      knobX = Math.max(x, Math.min(x + w - knobSize, knobX));
      int knobY = y + (h - knobSize) / 2;
      context.fill(knobX, knobY, knobX + knobSize, knobY + knobSize,
         hovered(mouseX, mouseY) || dragging ? 0xFFFFFFFF : DesignTokens.textMid());
   }

   @Override
   public boolean mouseClicked(int mouseX, int mouseY, int button) {
      if (button == 0 && contains(mouseX, mouseY)) {
         dragging = true;
         updateFromMouse(mouseX);
         return true;
      }
      return false;
   }

   @Override
   public void mouseDragged(int mouseX, int mouseY) {
      if (dragging) {
         updateFromMouse(mouseX);
      }
   }

   @Override
   public void mouseReleased(int mouseX, int mouseY) {
      dragging = false;
   }
}
