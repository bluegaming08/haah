package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class SunPosition extends HudModule {
   public SunPosition() {
      super("Sun Position", "Tiny dial for the day/night cycle", Category.HUD, 4, 440);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null) {
         long time = mc.world.getTimeOfDay() % 24000L;
         // "Sunrise" rather than the older label, so the word the owner asked to
         // remove appears nowhere in the client. Same meaning, same time range.
         String phase = time < 12000L ? "Day" : (time < 13000L ? "Dusk" : (time < 23000L ? "Night" : "Sunrise"));
         int dayPercent = (int)(time * 100L / 24000L);
         String text = "Sun: " + phase + " (" + dayPercent + "%)";
         this.drawTextPanel(context, text);
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Sun: Dusk (54%)") + 12 + 2;
   }
}
