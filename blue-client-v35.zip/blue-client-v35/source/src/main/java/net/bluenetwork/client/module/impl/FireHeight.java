package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;

/**
 * Controls how tall fire is drawn.
 *
 * <h2>Two separate fires</h2>
 * They are rendered by completely different code paths, so they get separate
 * settings:
 * <ul>
 *   <li><b>Overlay fire</b> - the flames drawn across your screen while you
 *       are burning. Lowering this is the common request: at the default
 *       height it covers most of the view during a fight.</li>
 *   <li><b>Block fire</b> - a fire block placed in the world.</li>
 * </ul>
 *
 * <h2>Not anticheat-flaggable</h2>
 * Both are pure client-side draw heights. Nothing about the fire's damage,
 * duration or hitbox changes - only how many pixels of it appear on your own
 * screen. It is the same category of change as a resource pack that makes the
 * fire texture shorter, which is universally allowed.
 *
 * <h2>Defaults</h2>
 * Both scales default to 1.0 - identical to vanilla - so enabling the module
 * changes nothing until a slider is moved.
 */
public class FireHeight extends Module {

   private final BooleanSetting overlayEnabled = new BooleanSetting("Overlay Fire",
      "Scale the flames drawn on your screen while burning", true);
   private final NumberSetting overlayScale = new NumberSetting("Overlay Height",
      "1.0 = vanilla, lower = shorter flames", 1.0, 0.0, 2.0, 0.05);
   private final NumberSetting overlayOffset = new NumberSetting("Overlay Y",
      "Move the screen flames up or down", 0.0, -1.0, 1.0, 0.05);

   private final BooleanSetting blockEnabled = new BooleanSetting("Block Fire",
      "Scale fire blocks placed in the world", false);
   private final NumberSetting blockScale = new NumberSetting("Block Height",
      "1.0 = vanilla height for placed fire", 1.0, 0.1, 2.0, 0.05);

   private static FireHeight instance;

   public FireHeight() {
      super("Fire Height", "Change how tall screen and block fire are drawn",
         Category.RENDER);
      this.addSettings(new Setting[]{
         this.overlayEnabled, this.overlayScale, this.overlayOffset,
         this.blockEnabled, this.blockScale});

      this.overlayScale.visibleWhen(this.overlayEnabled::get);
      this.overlayOffset.visibleWhen(this.overlayEnabled::get);
      this.blockScale.visibleWhen(this.blockEnabled::get);

      instance = this;
   }

   private static FireHeight active() {
      FireHeight m = instance;
      return m != null && m.isEnabled() ? m : null;
   }

   /** Vertical scale for the burning-screen overlay. 1 = vanilla. */
   public static float overlayScale() {
      FireHeight m = active();
      return m != null && m.overlayEnabled.get() ? m.overlayScale.getFloat() : 1.0F;
   }

   /** Vertical offset for the burning-screen overlay, in blocks. */
   public static float overlayOffset() {
      FireHeight m = active();
      return m != null && m.overlayEnabled.get() ? m.overlayOffset.getFloat() : 0.0F;
   }

   /** True when the overlay should be transformed at all. */
   public static boolean overlayActive() {
      FireHeight m = active();
      return m != null && m.overlayEnabled.get()
         && (m.overlayScale.getFloat() != 1.0F || m.overlayOffset.getFloat() != 0.0F);
   }

   /** Vertical scale for fire blocks in the world. 1 = vanilla. */
   public static float blockScale() {
      FireHeight m = active();
      return m != null && m.blockEnabled.get() ? m.blockScale.getFloat() : 1.0F;
   }

   /** True when block fire should be transformed at all. */
   public static boolean blockActive() {
      FireHeight m = active();
      return m != null && m.blockEnabled.get() && m.blockScale.getFloat() != 1.0F;
   }
}
