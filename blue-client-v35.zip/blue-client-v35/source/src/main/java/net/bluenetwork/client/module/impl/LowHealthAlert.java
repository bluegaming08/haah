package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;

/**
 * Low Health Alert (v3 catalogue D2) — notifies + softly chimes when your
 * health drops below a threshold, with a per-alert cooldown. Pure client-side,
 * server-safe, driven by the (now live) per-tick module dispatch.
 */
public class LowHealthAlert extends Module {
   private final NumberSetting threshold = new NumberSetting("Health %", "Alert when health is at or below this percent", 30.0, 1.0, 100.0, 1.0);
   private final NumberSetting cooldown = new NumberSetting("Cooldown", "Seconds between alerts while still low", 5.0, 1.0, 60.0, 1.0);
   private final BooleanSetting sound = new BooleanSetting("Sound", "Play a soft alert tone", true);

   private boolean wasLow = false;
   private long lastAlert = 0L;

   public LowHealthAlert() {
      super("Low Health Alert", "Alert when your health drops below a threshold", Category.MISC);
      this.addSettings(new Setting[]{this.threshold, this.cooldown, this.sound});
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null) {
         this.wasLow = false;
         return;
      }
      float pct = mc.player.getMaxHealth() <= 0.0F
         ? 100.0F
         : mc.player.getHealth() / mc.player.getMaxHealth() * 100.0F;
      boolean low = pct <= this.threshold.getFloat();
      long now = System.currentTimeMillis();
      long cooldownMs = (long) (this.cooldown.get() * 1000.0);
      if (low) {
         if (!this.wasLow || now - this.lastAlert >= cooldownMs) {
            this.lastAlert = now;
            if (this.sound.get()) {
               Sounds.softAlert();
            }
            this.notify("Low health - " + Math.round(pct) + "%");
         }
         this.wasLow = true;
      } else {
         this.wasLow = false;
      }
   }

   private void notify(String message) {
      try {
         BlueClient.getInstance().notificationManager().add(message, 0xFFFF5C5C);
      } catch (Throwable ignored) {
      }
   }
}
