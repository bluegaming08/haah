package net.bluenetwork.client.module;

import java.util.List;

public interface ModuleActions {
   List<String> actionLabels();

   void onAction(int var1);
}
