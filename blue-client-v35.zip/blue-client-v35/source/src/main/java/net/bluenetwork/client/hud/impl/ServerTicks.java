package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;

/**
 * Server Ticks (v3 catalogue A12) — estimated server TPS + MSPT from the rate
 * the world clock advances vs. wall time. Clearly a heuristic estimate, as
 * labelled on the panel. Samples across client ticks (via the per-tick module
 * dispatch) and shows the last result when rendering.
 */
public class ServerTicks extends HudModule {
   private final NumberSetting windowTicks = new NumberSetting("Window", "Client ticks per sample", 40.0, 20.0, 200.0, 20.0);
   private final ColorSetting goodColor = new ColorSetting("Good color", "TPS at/above target", 0xFF7CFF9B);
   private final ColorSetting warnColor = new ColorSetting("Warn color", "TPS below target", 0xFFFF5C5C);
   private final NumberSetting targetTps = new NumberSetting("Target TPS", "Below this the text uses the warn colour", 18.0, 5.0, 20.0, 1.0);
   private final BooleanSetting showMspt = new BooleanSetting("Show MSPT", "Also show the estimated tick time", true);

   private long lastWorldTime = -1L;
   private long lastWallMs = 0L;
   private long accTicks = 0L;
   private long accWallMs = 0L;
   private long ticksSinceSample = 0L;
   private double lastTps = 20.0;

   public ServerTicks() {
      super("Server Ticks", "Estimated server TPS (heuristic)", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.windowTicks, this.goodColor, this.warnColor, this.targetTps, this.showMspt});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 152);
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientWorld world = mc.world;
      if (world == null) {
         this.lastWorldTime = -1L;
         return;
      }
      long now = System.currentTimeMillis();
      long worldTime = world.getTime();
      if (this.lastWorldTime >= 0L && worldTime > this.lastWorldTime && this.lastWallMs > 0L) {
         this.accTicks += worldTime - this.lastWorldTime;
         this.accWallMs += now - this.lastWallMs;
      }
      this.lastWorldTime = worldTime;
      this.lastWallMs = now;

      this.ticksSinceSample++;
      long window = (long) Math.round(this.windowTicks.get());
      if (this.ticksSinceSample >= window) {
         if (this.accTicks > 0L && this.accWallMs > 0L) {
            double tps = this.accTicks * 1000.0 / this.accWallMs;
            this.lastTps = Math.max(0.0, Math.min(20.0, tps));
         }
         this.accTicks = 0L;
         this.accWallMs = 0L;
         this.ticksSinceSample = 0L;
      }

      this.cachedText = this.text();
   }

   private String cachedText = "";

   private String currentText() {
      if (this.cachedText.isEmpty()) {
         this.cachedText = this.text();
      }
      return this.cachedText;
   }

   private String text() {
      String tps = String.format("%.1f", this.lastTps);
      if (!this.showMspt.get()) {
         return "TPS ~" + tps;
      }
      double mspt = this.lastTps <= 0.0 ? 50.0 : 1000.0 / this.lastTps;
      return "TPS ~" + tps + "  MSPT ~" + Math.round(mspt) + "ms";
   }

   private int resolveColor() {
      int base = this.lastTps >= this.targetTps.get()
         ? this.goodColor.currentRgb(System.currentTimeMillis())
         : this.warnColor.currentRgb(System.currentTimeMillis());
      return base;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      RenderUtil.drawText(context, this.currentText(), this.x + 6 + 2, this.y + 6, this.resolveColor());
   }

   @Override
   public int getWidth() {
      return net.bluenetwork.client.optimization.RenderCache.textWidth(this.currentText()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
