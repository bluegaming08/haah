package net.bluenetwork.client.ui.material;

import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.DrawContext;

/**
 * Liquid-glass panel renderer (plan §3.6). Composes the material layers in
 * order: drop shadow → base tint → rim (top edge light + accent hairline).
 *
 * <p>Phase 1 ships the translucency/rim/hairline layers that are already
 * supported by the SDF pipeline and helper set. The two remaining layers —
 * real background blur and the animated sheen sweep — are Phase 1b/3 work:
 * blur depends on the §7.1 framebuffer spike, sheen on the motion engine being
 * driven by real screens. Until then GLASS behaves like an improved MATTE, and
 * nothing about the API changes when the extra layers land.</p>
 */
public final class GlassPanel {
   private GlassPanel() {
   }

   /** Standard panel with default surface quality and no interactive accent. */
   public static void panel(DrawContext context, float x, float y, float w, float h, float radius) {
      panel(context, x, y, w, h, radius, GlassSurface.defaultSurface(), false, 0);
   }

   public static void panel(DrawContext context, float x, float y, float w, float h, float radius, GlassSurface level) {
      panel(context, x, y, w, h, radius, level, false, 0);
   }

   /**
    * Renders a glass panel.
    *
    * @param accentOverride 0 = use the theme accent for interactive hairline,
    *                       otherwise a concrete ARGB colour (custom/rainbow)
    */
   public static void panel(DrawContext context, float x, float y, float w, float h, float radius, GlassSurface level, boolean interactive, int accentOverride) {
      GlassSurface surface = level == null ? GlassSurface.defaultSurface() : level;
      switch (surface) {
         case FLAT -> drawFlat(context, x, y, w, h, radius, interactive, accentOverride);
         case MATTE -> drawMatte(context, x, y, w, h, radius, interactive, accentOverride);
         case GLASS -> drawGlass(context, x, y, w, h, radius, interactive, accentOverride);
      }
   }

   /**
    * Same as {@link #panel(DrawContext, float, float, float, float, float, GlassSurface, boolean, int)}
    * but never draws the soft drop shadow. Used by surfaces where shadows are
    * unwanted (e.g. the main menu per 2026-09-12 feedback).
    */
   public static void panelNoShadow(DrawContext context, float x, float y, float w, float h, float radius, boolean interactive, int accentOverride) {
      // Base translucent tint
      SmoothRect.fill(context, x, y, w, h, radius, DesignTokens.panelBg());
      // Inner top rim light (inset so it never pokes past rounded corners)
      context.fill((int) x + (int) Math.max(3.0F, radius * 0.5F), (int) y + 1,
         (int) (x + w) - (int) Math.max(3.0F, radius * 0.5F), (int) y + 2, 0x14FFFFFF);
      // Hairline
      border(context, x, y, w, h, radius, interactive, accentOverride);
   }

   private static void drawFlat(DrawContext context, float x, float y, float w, float h, float radius, boolean interactive, int accentOverride) {
      SmoothRect.fill(context, x, y, w, h, radius, opaque(DesignTokens.panelBg()));
      border(context, x, y, w, h, radius, interactive, accentOverride);
   }

   private static void drawMatte(DrawContext context, float x, float y, float w, float h, float radius, boolean interactive, int accentOverride) {
      SmoothRect.fill(context, x, y, w, h, radius, DesignTokens.panelBg());
      border(context, x, y, w, h, radius, interactive, accentOverride);
   }

   private static void drawGlass(DrawContext context, float x, float y, float w, float h, float radius, boolean interactive, int accentOverride) {
      // Soft drop shadow behind the panel (fast layered approximation)
      PremiumRender.drawShadow(context, (int) x, (int) y, (int) w, (int) h, 0x33000000, 4);
      // Base translucent tint
      SmoothRect.fill(context, x, y, w, h, radius, DesignTokens.panelBg());
      // Inner top rim light (inset so it never pokes past rounded corners)
      context.fill((int) x + (int) Math.max(3.0F, radius * 0.5F), (int) y + 1,
         (int) (x + w) - (int) Math.max(3.0F, radius * 0.5F), (int) y + 2, 0x14FFFFFF);
      // Hairline
      border(context, x, y, w, h, radius, interactive, accentOverride);
   }

   private static void border(DrawContext context, float x, float y, float w, float h, float radius, boolean interactive, int accentOverride) {
      if (interactive) {
         int accent = accentOverride != 0 ? accentOverride : DesignTokens.accent();
         SmoothRect.outline(context, x, y, w, h, radius, 1.0F, accent);
      } else {
         SmoothRect.outline(context, x, y, w, h, radius, 1.0F, DesignTokens.panelBorder());
      }
   }

   private static int opaque(int argb) {
      return 0xFF000000 | argb & 0xFFFFFF;
   }
}
