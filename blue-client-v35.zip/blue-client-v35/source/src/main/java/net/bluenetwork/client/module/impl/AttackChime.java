package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Attack Cooldown Chime (v3 catalogue D4) — a quiet chime the moment your
 * attack indicator fully recharges after an attack. The indicator only crosses
 * 0 → full after you swing, so this naturally rings once per recharged hit and
 * stays silent while you idle.
 */
public class AttackChime extends Module {
   private final BooleanSetting sound = new BooleanSetting("Sound", "Play the chime (off silences, module then only tracks)", true);
   private final BooleanSetting onlyWhenHeld = new BooleanSetting("Only with tool", "Only ring while holding a damageable tool/weapon", false);

   private float prev = 1.0F;
   private boolean attacking = false;
   private long lastChime = 0L;

   public AttackChime() {
      super("Attack Chime", "Chime when your attack recharges", Category.MISC);
      this.addSettings(new Setting[]{this.sound, this.onlyWhenHeld});
   }

   @Override
   protected void onDisable() {
      this.prev = 1.0F;
      this.attacking = false;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity p = mc.player;
      if (p == null) {
         this.prev = 1.0F;
         this.attacking = false;
         return;
      }
      float progress = p.getAttackCooldownProgress(0.0F);
      if (progress < 0.5F) {
         this.attacking = true;
      }
      if (progress >= 0.999F) {
         if (this.prev < 0.999F && this.attacking) {
            this.attacking = false;
            long now = System.currentTimeMillis();
            if (this.sound.get() && now - this.lastChime > 750L
                  && (!this.onlyWhenHeld.get() || this.holdsWeapon(p))) {
               this.lastChime = now;
               Sounds.chime();
            }
         }
      }
      this.prev = progress;
   }

   private boolean holdsWeapon(ClientPlayerEntity p) {
      if (p.getMainHandStack() == null || p.getMainHandStack().isEmpty()) {
         return false;
      }
      return p.getMainHandStack().isDamageable();
   }
}
