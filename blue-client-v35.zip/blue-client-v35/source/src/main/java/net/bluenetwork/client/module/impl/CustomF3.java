package net.bluenetwork.client.module.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.setting.StringSetting;

/**
 * Custom F3 (v0.19.0) — debug screen control. Hide entire sides,
 * or hide individual lines by keyword: any F3 line containing one of your
 * comma-separated words disappears. Keywords match case-insensitively on
 * the line's first few words (e.g. "Eye" hides the eye position line).
 */
public class CustomF3 extends Module {
   private final BooleanSetting hideLeft = new BooleanSetting("Hide left side", "Hide the whole left F3 column", false);
   private final BooleanSetting hideRight = new BooleanSetting("Hide right side", "Hide the whole right F3 column", false);
   private final StringSetting hideLines = new StringSetting("Hide lines", "Comma-separated words: lines containing them vanish", "Debug:,Paused");

   public CustomF3() {
      super("Custom F3", "Choose which F3 debug lines show", Category.RENDER);
      this.addSettings(new Setting[]{this.hideLeft, this.hideRight, this.hideLines});
   }

   /** True when the given side should not draw at all. */
   public static boolean sideHidden(boolean rightSide) {
      Module m = BlueClient.getInstance().moduleManager().byName("Custom F3");
      if (!(m instanceof CustomF3 f3) || !m.isEnabled()) {
         return false;
      }
      // Verified on hardware (2026-09-15): with the yarn 1.21.11 drawText flag,
      // hideLeft removes the RIGHT column and vice versa - the flag names the
      // column the caller is about to draw AFTER it, not the visual side.
      return rightSide ? f3.hideLeft.get() : f3.hideRight.get();
   }

   /** Filters a list of F3 lines by the configured keywords. */
   public static List<String> filter(List<String> lines) {
      Module m = BlueClient.getInstance().moduleManager().byName("Custom F3");
      if (!(m instanceof CustomF3 f3) || !m.isEnabled()) {
         return lines;
      }
      String raw = f3.hideLines.get();
      List<String> keywords = new ArrayList<>();
      if (raw != null && !raw.isBlank()) {
         for (String word : raw.split(",")) {
            String w = word.trim();
            if (!w.isEmpty()) {
               keywords.add(w.toLowerCase(Locale.ROOT));
            }
         }
      }
      if (keywords.isEmpty()) {
         return lines;
      }
      List<String> out = new ArrayList<>(lines.size());
      for (String line : lines) {
         if (line == null || line.isEmpty()) {
            out.add(line);
            continue;
         }
         String lower = line.toLowerCase(Locale.ROOT);
         boolean blocked = false;
         for (String keyword : keywords) {
            if (lower.contains(keyword)) {
               blocked = true;
               break;
            }
         }
         if (!blocked) {
            out.add(line);
         }
      }
      return out;
   }
}
