package net.bluenetwork.client.util;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.MinecraftClient;

/**
 * Central save/restore manager for vanilla options that modules override.
 *
 * <p>Problem this solves: FrameSmooth, Adaptive Render Distance, Custom FOV,
 * Zoom and the built-in optimizer each captured "the user's original value"
 * for the SAME vanilla option independently. Enable two of them and one
 * module's override is captured as the other's "original" — on disable the
 * player gets a stale module value back instead of their own setting.
 *
 * <p>Model: every option has a stack of holds. The first hold snapshots the
 * true original; the top hold's value is applied. Releasing a hold applies the
 * next hold down, and releasing the last hold restores the user's original.
 * All methods must be called on the client thread.
 */
public final class OptionGuard {
   private static final Map<SimpleOption<?>, Object> ORIGINALS = new IdentityHashMap<>();
   private static final Map<SimpleOption<?>, Deque<Hold>> HOLDS = new IdentityHashMap<>();
   /** Fallback while MinecraftClient.options is not ready during early startup. */
   private static boolean optionsReady;

   private OptionGuard() {
   }

   public record Hold(Object owner, Object value) {
   }

   /** Registers the module's claim on {@code option} at {@code value} and applies it. */
   public static <T> void hold(SimpleOption<T> option, T value, Object owner) {
      if (option == null) {
         return;
      }
      Deque<Hold> stack = HOLDS.computeIfAbsent(option, k -> new ArrayDeque<>(2));
      boolean already = stack.stream().anyMatch(h -> h.owner() == owner);
      if (already) {
         setValue(option, value, owner);
         return;
      }
      if (!ORIGINALS.containsKey(option)) {
         try {
            ORIGINALS.put(option, option.getValue());
         } catch (Throwable ignored) {
         }
      }
      stack.push(new Hold(owner, value));
      applyTop(option);
   }

   /** Updates this owner's held value (and re-applies it if it is on top). */
   public static <T> void setValue(SimpleOption<T> option, T value, Object owner) {
      if (option == null) {
         return;
      }
      Deque<Hold> stack = HOLDS.get(option);
      if (stack == null) {
         return;
      }
      for (Hold hold : stack) {
         if (hold.owner() == owner) {
            stack.remove(hold);
            stack.push(new Hold(owner, value));
            break;
         }
      }
      applyTop(option);
   }

   /** Drops this owner's hold; restores the next hold / the user's original value. */
   public static <T> void release(SimpleOption<T> option, Object owner) {
      if (option == null) {
         return;
      }
      Deque<Hold> stack = HOLDS.get(option);
      if (stack == null) {
         return;
      }
      stack.removeIf(h -> h.owner() == owner);
      if (stack.isEmpty()) {
         HOLDS.remove(option);
         Object original = ORIGINALS.remove(option);
         if (original != null) {
            setRaw(option, original);
         }
      } else {
         applyTop(option);
      }
   }

   /** The user's pre-hold value for an option (or null when not held). */
   public static <T> T original(SimpleOption<T> option) {
      Object original = ORIGINALS.get(option);
      if (original == null) {
         return null;
      }
      try {
         return (T) original;
      } catch (ClassCastException e) {
         return null;
      }
   }

   /**
    * The value {@code owner} is currently holding, or null if it holds none.
    *
    * <p>Lets a module compare what it last wrote against the live value, which
    * is how it can tell "the player changed this" from "nothing happened".
    * Without it the only option is to blindly re-apply, which is exactly what
    * made the FPS limit snap back whenever it was edited elsewhere.</p>
    */
   @SuppressWarnings("unchecked")
   public static <T> T heldValueOf(SimpleOption<T> option, Object owner) {
      if (option == null) {
         return null;
      }
      Deque<Hold> stack = HOLDS.get(option);
      if (stack == null) {
         return null;
      }
      for (Hold h : stack) {
         if (h.owner() == owner) {
            return (T) h.value();
         }
      }
      return null;
   }

   /**
    * Replaces the remembered "user's original" for an option.
    *
    * <p>Used when a module detects the player deliberately changed a held
    * option: the value they chose becomes what we restore on release, so
    * turning the module off gives them back THEIR setting rather than a
    * snapshot from before they touched it.</p>
    */
   public static <T> void adoptOriginal(SimpleOption<T> option, T value) {
      if (option != null && value != null) {
         ORIGINALS.put(option, value);
      }
   }

   public static boolean isHeldBy(SimpleOption<?> option, Object owner) {
      Deque<Hold> stack = HOLDS.get(option);
      return stack != null && stack.stream().anyMatch(h -> h.owner() == owner);
   }

   /** True once vanilla options exist (used by early-startup callers to retry later). */
   public static boolean areOptionsReady() {
      if (!optionsReady) {
         optionsReady = MinecraftClient.getInstance() != null
            && MinecraftClient.getInstance().options != null;
      }
      return optionsReady;
   }

   private static void applyTop(SimpleOption<?> option) {
      Deque<Hold> stack = HOLDS.get(option);
      if (stack == null || stack.isEmpty()) {
         return;
      }
      setRaw(option, stack.peek().value());
   }

   @SuppressWarnings({"unchecked", "rawtypes"})
   private static void setRaw(SimpleOption option, Object value) {
      try {
         option.setValue(value);
      } catch (Throwable ignored) {
         // Validated options may reject a value (e.g. while options are mid-init);
         // callers retry on their next tick.
      }
   }
}
