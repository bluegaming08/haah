package net.bluenetwork.client.render;

import net.bluenetwork.client.BlueColors;
import net.minecraft.client.gui.DrawContext;

/**
 * Premium-pack render helpers, combined with Blue Client's SDF pipeline:
 * rounded rects and outlines route through SmoothRect (anti-aliased),
 * gradients/progress bars/shadows are real fill-based effects.
 */
public final class PremiumRender {
   private PremiumRender() {
   }

   /** Translucent "glass" panel with accent outline. The blur parameter from the pack is honored via BlueScissors when supported. */
   public static void drawGlassPanel(DrawContext context, int x, int y, int width, int height, int color) {
      SmoothRect.fill(context, x, y, width, height, 12.0F, color);
      SmoothRect.outline(context, x, y, width, height, 12.0F, 1.0F, BlueColors.ACCENT);
   }

   /** Vertical gradient rect. */
   public static void drawGradientRect(DrawContext context, int x1, int y1, int x2, int y2, int colorTopLeft, int colorBottomRight) {
      int r1 = colorTopLeft >> 16 & 0xFF;
      int g1 = colorTopLeft >> 8 & 0xFF;
      int b1 = colorTopLeft & 0xFF;
      int a1 = colorTopLeft >> 24 & 0xFF;
      int r2 = colorBottomRight >> 16 & 0xFF;
      int g2 = colorBottomRight >> 8 & 0xFF;
      int b2 = colorBottomRight & 0xFF;
      int a2 = colorBottomRight >> 24 & 0xFF;
      int rows = Math.max(1, y2 - y1);
      for (int i = 0; i < rows; i++) {
         float p = (float)i / rows;
         int color = (int)(a1 + (a2 - a1) * p) << 24 | (int)(r1 + (r2 - r1) * p) << 16 | (int)(g1 + (g2 - g1) * p) << 8 | (int)(b1 + (b2 - b1) * p);
         context.fill(x1, y1 + i, x2, y1 + i + 1, color);
      }
   }

   public static void drawRoundedRect(DrawContext context, int x, int y, int width, int height, int color, int radius) {
      SmoothRect.fill(context, x, y, width, height, (float)radius, color);
   }

   public static void drawRoundedRect(DrawContext context, int x, int y, int width, int height, int color, int radius, float alpha) {
      int a = (int)((color >> 24 & 0xFF) * alpha);
      int finalColor = a << 24 | color & 0xFFFFFF;
      SmoothRect.fill(context, x, y, width, height, (float)radius, finalColor);
   }

   /** Layered soft shadow: alpha falls off with distance. */
   public static void drawShadow(DrawContext context, int x, int y, int width, int height, int shadowColor, int distance) {
      int base = shadowColor >> 24 & 0xFF;
      int rgb = shadowColor & 0xFFFFFF;
      for (int i = distance; i >= 1; i--) {
         int alpha = (int)((float)base * (1.0F - i / (float)distance));
         if (alpha > 0) {
            context.fill(x - i, y - i, x + width + i, y + i + 1, alpha << 24 | rgb);
         }
      }
   }

   public static void drawRoundedOutline(DrawContext context, int x, int y, int width, int height, int color, int radius, float thickness) {
      SmoothRect.outline(context, x, y, width, height, (float)radius, thickness, color);
   }

   /** Progress bar with vertical gradient fill. */
   public static void drawProgressBar(DrawContext context, int x, int y, int width, int height, float progress, int colorStart, int colorEnd) {
      SmoothRect.fill(context, x, y, width, height, (float)Math.min(4, height / 2), 0x4D000000);
      int filled = (int)(width * progress);
      if (filled > 0) {
         drawGradientRect(context, x, y, x + filled, y + height, colorStart, colorEnd);
      }
   }

   /** Pulsing accent glow behind an element. */
   public static void drawPulseGlow(DrawContext context, int x, int y, int width, int height, int color, float pulse) {
      int alpha = (int)((color >> 24 & 0xFF) * pulse);
      if (alpha <= 0) {
         return;
      }
      int glowColor = alpha << 24 | color & 0xFFFFFF;
      SmoothRect.fill(context, x - 2, y - 2, width + 4, height + 4, 12.0F, glowColor);
   }
}
