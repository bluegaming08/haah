package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Death Coords (bonus utility) — records where you died and shows a toast with
 * the coordinates after you respawn, so you always know where your stuff is.
 * Pure client-side observation; it never touches your items or the server.
 */
public class DeathCoords extends Module {
   private final BooleanSetting sound = new BooleanSetting("Sound", "Soft tone on respawn", true);
   private String pending = null;
   private boolean wasDead = false;

   public DeathCoords() {
      super("Death Coords", "Toast your death location on respawn", Category.MISC);
      this.addSettings(new Setting[]{this.sound});
   }

   @Override
   protected void onDisable() {
      this.pending = null;
      this.wasDead = false;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity p = mc.player;
      if (p == null || mc.world == null) {
         this.pending = null;
         this.wasDead = false;
         return;
      }
      boolean dead = p.getHealth() <= 0.0F && !p.getAbilities().creativeMode && !p.isSpectator();
      if (dead) {
         if (!this.wasDead) {
            int x = (int) Math.floor(p.getX());
            int y = (int) Math.floor(p.getY());
            int z = (int) Math.floor(p.getZ());
            this.pending = x + " " + y + " " + z;
         }
         this.wasDead = true;
      } else {
         if (this.wasDead && this.pending != null) {
            String where = this.pending;
            this.pending = null;
            if (this.sound.get()) {
               Sounds.softAlert();
            }
            try {
               BlueClient.getInstance().notificationManager().add("Died at " + where, 0xFFFF8A80);
            } catch (Throwable ignored) {
            }
         }
         this.wasDead = false;
      }
   }
}
