package net.bluenetwork.client.hud.impl;

import java.util.ArrayList;
import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Session Stats (v3 catalogue A7) — this-life stats since you joined (or since
 * the module was enabled): time, blocks walked, jumps, XP gained. All local
 * counters from client tick data; resets when the world changes.
 */
public class SessionStats extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Stats colour", 0xFFFFFFFF);
   private final BooleanSetting showTime = new BooleanSetting("Show time", "Time in this session", true);
   private final BooleanSetting showWalked = new BooleanSetting("Show walked", "Blocks walked (on foot)", true);
   private final BooleanSetting showJumps = new BooleanSetting("Show jumps", "Jump count", true);
   private final BooleanSetting showXp = new BooleanSetting("Show XP", "XP gained", true);

   private ClientWorld lastWorld = null;
   private long startMs = 0L;
   private double walked = 0.0;
   private long jumps = 0L;
   private int xpStart = -1;
   private double prevX = 0.0;
   private double prevZ = 0.0;
   private boolean prevOnGround = false;

   public SessionStats() {
      super("Session Stats", "Time, walked, jumps and XP this session", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.showTime, this.showWalked, this.showJumps, this.showXp});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 204);
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) {
         return;
      }
      if (mc.world != this.lastWorld) {
         this.lastWorld = mc.world;
         this.startMs = System.currentTimeMillis();
         this.walked = 0.0;
         this.jumps = 0L;
         this.xpStart = mc.player.totalExperience;
         this.prevX = mc.player.getX();
         this.prevZ = mc.player.getZ();
         this.prevOnGround = mc.player.isOnGround();
      }
      PlayerEntity p = mc.player;
      boolean onGround = p.isOnGround();
      double dx = p.getX() - this.prevX;
      double dz = p.getZ() - this.prevZ;
      if (onGround) {
         this.walked += Math.sqrt(dx * dx + dz * dz);
      }
      if (this.prevOnGround && !onGround && p.getVelocity().y > 0.0) {
         this.jumps++;
      }
      this.prevX = p.getX();
      this.prevZ = p.getZ();
      this.prevOnGround = onGround;

      // Per-tick text cache: render/getWidth/getHeight read currentLines()
      // and never rebuild strings on the frame path.
      this.cachedLines = this.lines();
   }

   private List<String> cachedLines = new ArrayList<>();

   private List<String> currentLines() {
      if (this.cachedLines.isEmpty()) {
         this.cachedLines = this.lines();
      }
      return this.cachedLines;
   }

   private List<String> lines() {
      MinecraftClient mc = MinecraftClient.getInstance();
      List<String> out = new ArrayList<>();
      if (mc.player == null) {
         return out;
      }
      if (this.showTime.get()) {
         long s = Math.max(0L, (System.currentTimeMillis() - this.startMs) / 1000L);
         out.add("Time " + fmt(s));
      }
      if (this.showWalked.get()) {
         out.add("Walked " + (int) Math.floor(this.walked) + " m");
      }
      if (this.showJumps.get()) {
         out.add("Jumps " + this.jumps);
      }
      if (this.showXp.get()) {
         int gained = this.xpStart < 0 ? 0 : Math.max(0, mc.player.totalExperience - this.xpStart);
         out.add("XP +" + gained);
      }
      return out;
   }

   private static String fmt(long totalSeconds) {
      long h = totalSeconds / 3600L;
      long m = (totalSeconds % 3600L) / 60L;
      long s = totalSeconds % 60L;
      if (h > 0L) {
         return h + "h " + m + "m";
      }
      return m + "m " + s + "s";
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      List<String> lines = this.currentLines();
      if (lines.isEmpty()) {
         return;
      }
      this.drawPanel(context);
      int ty = this.y + 6;
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      for (String line : lines) {
         RenderUtil.drawText(context, line, this.x + 6 + 2, ty, color);
         ty += 9;
      }
   }

   @Override
   public int getWidth() {
      int max = 0;
      for (String line : this.currentLines()) {
         max = Math.max(max, RenderUtil.textWidth(line));
      }
      return Math.max(20, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = this.lines().size();
      return Math.max(21, rows * 9 + 12);
   }
}
