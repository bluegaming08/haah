package net.bluenetwork.client.ui.theme;

/**
 * Every colour in the Blue Client UI, for one theme.
 *
 * <h2>The single source of truth</h2>
 * If a colour appears anywhere in a screen, it should come from here (usually
 * via {@link DesignTokens}). Hard-coded ARGB literals scattered through screens
 * are what made v11 impossible to re-theme — the same "panel grey" existed in
 * eleven files with four slightly different values.
 *
 * <h2>ARGB, always</h2>
 * Every int is {@code 0xAARRGGBB}. Minecraft's {@code DrawContext.fill} and our
 * {@code SmoothRect} both expect that order. A colour with alpha {@code 00} is
 * fully transparent, which is exactly how "no border" is expressed.
 *
 * <h2>The owner's button preset</h2>
 * These constants are mandated and must not be edited casually:
 * <pre>
 *   border opacity .... 0        (BUTTON_BORDER_ALPHA)
 *   background ........ enabled
 *   background colour . #0B0E14  (BUTTON_BASE)
 *   background opacity  100 %
 *   corner radius ..... 2 px     (BUTTON_RADIUS)
 *   text colour ....... #FFFFFF  (BUTTON_TEXT)
 * </pre>
 * The same numbers are mirrored by the HUD defaults in
 * {@code module/HudModule.java} so panels and buttons look like one system.
 */
public record ThemePalette(
   ThemeStyle style,
   int accent,
   int accentSoft,
   int textHi,
   int textMid,
   int textOnAccent,
   int panelBg,
   int panelBgHover,
   int panelBorder,
   int shadow,
   int buttonTop,
   int buttonBottom,
   int buttonTopHover,
   int buttonBottomHover,
   int toggleOff,
   int toggleOn
) {

   /* ===================================================================== */
   /* Owner-mandated button preset                                          */
   /* ===================================================================== */

   /** Corner radius for every button, in pixels. */
   public static final int BUTTON_RADIUS = 2;

   /** Button background, #0B0E14 at 100 % opacity. */
   public static final int BUTTON_BASE = 0xFF0B0E14;

   /** Button label colour, #FFFFFF. */
   public static final int BUTTON_TEXT = 0xFFFFFFFF;

   /** Button border alpha: 0 means no border is drawn at all. */
   public static final int BUTTON_BORDER_ALPHA = 0;

   /** The Blue Client brand accent, #2FA5FF. */
   public static final int BRAND_ACCENT = 0xFF2FA5FF;

   /* ===================================================================== */
   /* Factory                                                               */
   /* ===================================================================== */

   /**
    * The palette for a theme. Cheap enough to call per frame (it just returns
    * one of three constant records), but prefer {@code ThemeManager.palette()}
    * so the whole UI reads the same instance within a frame.
    */
   public static ThemePalette of(ThemeStyle style) {
      return switch (style) {
         case BLACK -> BLACK_PALETTE;
         case GLASS -> GLASS_PALETTE;
         case WHITE -> WHITE_PALETTE;
      };
   }

   /**
    * BLACK — 100 % opaque, near-black. Buttons are a black → dark-grey gradient.
    * Borders are fully transparent: on an opaque surface a hairline border
    * just looks like a rendering artefact.
    *
    * <p><b>Every alpha here is 0xFF on purpose</b> ("dark mode should make the
    * opacity 100% of the background and cards, nothing behind visible"). If you
    * add a colour to this palette, it must be fully opaque too — and see
    * {@code DesignTokens.scrim()}, which blacks out the game behind the menu
    * for opaque themes.</p>
    */
   private static final ThemePalette BLACK_PALETTE = new ThemePalette(
      ThemeStyle.BLACK,
      BRAND_ACCENT,
      0x662FA5FF,
      0xFFFFFFFF,          // textHi
      0xFF9AA4B2,          // textMid
      0xFF061018,          // textOnAccent
      0xFF0B0E14,          // panelBg      - 100 % opaque, owner's colour
      0xFF141922,          // panelBgHover
      0x00000000,          // panelBorder  - none
      0x80000000,          // shadow
      0xFF15191F,          // buttonTop    - black ...
      0xFF0A0C11,          // buttonBottom - ... to dark grey
      0xFF1E242D,          // buttonTopHover
      0xFF12161C,          // buttonBottomHover
      0xFFE05260,          // toggleOff
      0xFF3CB860           // toggleOn
   );

   /**
    * GLASS — a DARK translucent pane, ~10 % opacity.
    *
    * <h3>v0.24.1 fix: "glass shouldnt make everything white"</h3>
    * The old palette tinted every surface with WHITE at 10 % alpha
    * ({@code 0x1AFFFFFF}). Over a bright sky or snow that washes the entire UI
    * out to near-white and the dark text becomes unreadable — which is exactly
    * what the owner reported.
    *
    * <p>Glass now tints with the brand's near-black ({@code #0B0E14}) at 10 %
    * alpha, so it reads as smoked glass: you can see the game through it, but
    * it always darkens rather than lightens, and white text stays legible on
    * any background.</p>
    *
    * <p>The numbers below are ALPHA over {@code 0x0B0E14}:
    * {@code 0x1A} = 10 %, {@code 0x2E} = 18 % (hover), {@code 0x40} = 25 %
    * (buttons, which need to read as raised).</p>
    *
    * <p>Borders stay a light hairline: on a translucent dark pane a light edge
    * is the only thing that separates the panel from a dark game background.</p>
    */
   private static final ThemePalette GLASS_PALETTE = new ThemePalette(
      ThemeStyle.GLASS,
      BRAND_ACCENT,
      0x662FA5FF,
      0xFFFFFFFF,          // textHi  - white, always legible on a darkening pane
      0xFFB8C2CF,          // textMid
      0xFF061018,          // textOnAccent
      0x1A0B0E14,          // panelBg      - 10 % of #0B0E14 (DARK, not white)
      0x2E0B0E14,          // panelBgHover - 18 %
      0x33FFFFFF,          // panelBorder  - light hairline, keeps edges visible
      0x99000000,          // shadow
      0x400B0E14,          // buttonTop    - 25 %, reads as a raised surface
      0x59060910,          // buttonBottom - slightly darker + denser
      0x59141922,          // buttonTopHover
      0x73090D14,          // buttonBottomHover
      0xFFE05260,
      0xFF3CB860
   );

   /**
    * WHITE — 100 % opaque light surfaces, white → grey button gradient, black
    * text. Nothing of the game shows through ("same with white mode but
    * opacity 100% with white backgrounds and black text and stuff").
    *
    * <p>{@code textHi} is near-black here: reusing the dark theme's white text
    * was the single most common light-theme bug in v11. Every alpha is 0xFF.</p>
    */
   private static final ThemePalette WHITE_PALETTE = new ThemePalette(
      ThemeStyle.WHITE,
      0xFF0A84FF,          // slightly deeper blue: #2FA5FF is weak on white
      0x660A84FF,
      0xFF10141A,          // textHi  - near-black
      0xFF5A6472,          // textMid
      0xFFFFFFFF,          // textOnAccent
      0xFFF2F4F8,          // panelBg      - opaque off-white
      0xFFE6EAF1,          // panelBgHover
      0x1A000000,          // panelBorder  - soft dark hairline
      0x33000000,
      0xFFFFFFFF,          // buttonTop    - white ...
      0xFFD8DDE6,          // buttonBottom - ... to grey
      0xFFFFFFFF,
      0xFFC8CFDA,
      0xFFD1434F,
      0xFF2E9E52
   );

   /* ===================================================================== */
   /* Colour helpers                                                        */
   /* ===================================================================== */

   /** Replaces the alpha channel. {@code alpha} is 0..255. */
   public static int withAlpha(int argb, int alpha) {
      return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0x00FFFFFF);
   }

   /** Scales the existing alpha by {@code factor} (0..1). */
   public static int fade(int argb, float factor) {
      int alpha = (int) (((argb >>> 24) & 0xFF) * Math.max(0.0F, Math.min(1.0F, factor)));
      return withAlpha(argb, alpha);
   }

   /**
    * Linear blend between two ARGB colours. {@code t} of 0 returns {@code a},
    * 1 returns {@code b}. Used for hover animations and theme cross-fades.
    */
   public static int lerp(int a, int b, float t) {
      float f = Math.max(0.0F, Math.min(1.0F, t));
      int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
      int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
      return ((int) (aa + (ba - aa) * f) << 24)
         | ((int) (ar + (br - ar) * f) << 16)
         | ((int) (ag + (bg - ag) * f) << 8)
         | (int) (ab + (bb - ab) * f);
   }

   /** True when this palette's panels are see-through. */
   public boolean translucent() {
      return this.style.isTranslucent();
   }
}
