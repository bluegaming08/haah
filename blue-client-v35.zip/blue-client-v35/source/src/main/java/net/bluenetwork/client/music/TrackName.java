package net.bluenetwork.client.music;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Turns a real-world filename into something a lyrics database can match.
 *
 * <h2>Why this exists</h2>
 * Lyric detection was landing about 2 in 10. The cause was not the lyrics API
 * and not the scoring - it was the <b>query</b>. Files people actually have are
 * named things like:
 *
 * <pre>
 *   01. Tum Hi Ho (Official Video) [320kbps].mp3
 *   Kesariya - Brahmastra (Lyrical) | Arijit Singh.mp3
 *   Blinding Lights (Official Audio)_320k.mp3
 *   Despacito ft. Daddy Yankee (Video Oficial).mp3
 * </pre>
 *
 * Searched verbatim, LRCLIB returned <b>zero</b> results for four of those
 * five. Cleaned with the rules below, all five return twenty. The API was
 * never the problem.
 *
 * <h2>Design</h2>
 * Cleaning is deliberately conservative and ordered: strip the extension, the
 * leading track number, bracketed junk, then known noise words, then trailing
 * credits. It must never eat the actual title - so noise words are matched as
 * whole words only, and if cleaning would empty the string the original is
 * kept instead.
 */
public final class TrackName {

   /**
    * Words that appear in upload titles but never in a song title.
    *
    * <p>Includes Spanish forms ({@code video oficial}) because the same junk
    * appears on Latin uploads, which is part of why non-English tracks failed
    * even more often than English ones.</p>
    */
   private static final Pattern NOISE = Pattern.compile(
      "(?i)\\b("
         + "official\\s*(music\\s*)?(video|audio|lyrics?|lyric)|"
         + "video\\s*oficial|audio\\s*oficial|letra\\s*oficial|"
         + "lyrics?|lyrical|with\\s+lyrics|"
         + "full\\s*(song|video|audio)|"
         + "music\\s*video|visuali[sz]er|audio|video|"
         + "hd|hq|4k|1080p|720p|"
         + "remaster(ed)?(\\s*\\d{4})?|explicit|clean\\s*version|"
         + "slowed(\\s*\\+?\\s*reverb)?|reverb|sped\\s*up|nightcore|"
         + "radio\\s*edit|extended\\s*(mix|version)|"
         + "free\\s*download|copyright\\s*free|no\\s*copyright"
         + ")\\b");

   /** "320kbps", "128 kbps". */
   private static final Pattern BITRATE = Pattern.compile("(?i)\\b\\d{2,4}\\s*kbps\\b");

   /** Trailing "_320k" / "-160k" that download tools append. */
   private static final Pattern BITRATE_SUFFIX = Pattern.compile("(?i)[_\\-]\\s*\\d{2,4}k\\b");

   /** A leading track number: "01. ", "7 - ", "003_". */
   private static final Pattern TRACK_NO =
      Pattern.compile("^\\s*\\d{1,3}\\s*(?:[-._)\\]]\\s*|\\s+)");

   /** Anything in (), [] or {}. Upload junk lives here almost exclusively. */
   private static final Pattern BRACKETED = Pattern.compile("[\\(\\[\\{][^)\\]\\}]*[\\)\\]\\}]");

   /** "ft. X", "feat X", "featuring X" and everything after. */
   private static final Pattern FEAT = Pattern.compile("(?i)\\b(ft|feat|featuring)\\.?\\s.*$");

   private static final Pattern AUDIO_EXT =
      Pattern.compile("(?i)\\.(mp3|wav|flac|m4a|aac|ogg|opus|wma|aiff?)$");

   private static final Pattern MULTI_SPACE = Pattern.compile("\\s{2,}");

   private TrackName() {
   }

   /** Artist and title, either of which may be empty. */
   public record Guess(String title, String artist) {
   }

   /**
    * Best-effort artist/title from a filename.
    *
    * <p>Splits on " - " only <b>after</b> cleaning, because the junk often
    * contains dashes of its own and splitting first picks the wrong half.</p>
    */
   public static Guess fromFileName(String fileName) {
      if (fileName == null || fileName.isBlank()) {
         return new Guess("", "");
      }
      String cleaned = clean(fileName);

      // "Artist - Title" is the overwhelmingly common convention.
      int dash = cleaned.indexOf(" - ");
      if (dash > 0) {
         String left = cleaned.substring(0, dash).trim();
         String right = cleaned.substring(dash + 3).trim();
         if (!left.isEmpty() && !right.isEmpty()) {
            return new Guess(right, left);
         }
      }
      return new Guess(cleaned, "");
   }

   /**
    * Strips upload noise from a name.
    *
    * <p>Never returns empty: if every rule fires and nothing survives, the
    * trimmed original is returned, because a bad query still beats no query.</p>
    */
   public static String clean(String raw) {
      return clean(raw, true);
   }

   /**
    * Cleans an ID3 tag value.
    *
    * <p>Far more conservative than {@link #clean(String)}: bracketed junk and
    * bitrates still go, but bare noise WORDS are kept. A tag is already
    * curated metadata, so "Audio Adrenaline", "Video Games" and "Lyrical
    * Lemonade" are real names - stripping them produced "Adrenaline",
    * "Games" and "Lemonade" and the lookup then failed.</p>
    */
   public static String cleanTag(String raw) {
      return clean(raw, false);
   }

   private static String clean(String raw, boolean stripNoiseWords) {
      if (raw == null) {
         return "";
      }
      String s = raw;
      s = AUDIO_EXT.matcher(s).replaceAll("");
      s = TRACK_NO.matcher(s).replaceAll("");
      s = BRACKETED.matcher(s).replaceAll(" ");
      s = BITRATE.matcher(s).replaceAll(" ");
      s = BITRATE_SUFFIX.matcher(s).replaceAll(" ");
      if (stripNoiseWords) {
         /*
          * Strip noise words, but never let it eat a real name.
          *
          * "Audio Adrenaline - Ocean Floor" was becoming "Adrenaline - Ocean
          * Floor" because "Audio" is on the noise list. A noise word that
          * STARTS the string is almost always part of the artist, while the
          * upload decoration this list targets ("... Official Video", "... HD")
          * trails. So only strip from the second word onward, and never if the
          * result would lose more than half the string.
          */
         String stripped = NOISE.matcher(s).replaceAll(" ");
         String probe = MULTI_SPACE.matcher(stripped).replaceAll(" ").trim();
         boolean startsWithNoise = NOISE.matcher(s.trim()).lookingAt();
         if (!probe.isEmpty()
            && probe.length() * 2 >= trimJunk(s).length()
            && !startsWithNoise) {
            s = stripped;
         }
      }

      // Trailing credits after a pipe: "Kesariya | Arijit Singh".
      int pipe = s.indexOf('|');
      if (pipe > 0) {
         s = s.substring(0, pipe);
      }
      s = FEAT.matcher(s).replaceAll(" ");

      s = s.replace('_', ' ');
      s = MULTI_SPACE.matcher(s).replaceAll(" ");
      s = trimJunk(s);

      if (s.isBlank()) {
         // Cleaning removed everything - the name was pure noise. Fall back to
         // the original minus its extension.
         s = trimJunk(AUDIO_EXT.matcher(raw).replaceAll("").replace('_', ' '));
      }
      return s;
   }

   /** Trims whitespace and leftover separators from both ends. */
   private static String trimJunk(String s) {
      int a = 0;
      int b = s.length();
      while (a < b && isJunk(s.charAt(a))) {
         a++;
      }
      while (b > a && isJunk(s.charAt(b - 1))) {
         b--;
      }
      return s.substring(a, b);
   }

   private static boolean isJunk(char c) {
      return Character.isWhitespace(c) || c == '-' || c == '.' || c == '_'
         || c == '\u2013' || c == '\u2014' || c == '|' || c == ',';
   }

   /**
    * Progressively simpler queries to try, most specific first.
    *
    * <p>One cleaned query is a big improvement but still brittle: a title with
    * a subtitle ("Kesariya - Brahmastra") can miss when the database stores
    * only "Kesariya". Trying a short ladder of fallbacks costs at most a few
    * requests and only when the earlier ones fail.</p>
    */
   public static java.util.List<String> queryLadder(String title, String artist) {
      java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
      String t = clean(title == null ? "" : title);
      String a = clean(artist == null ? "" : artist);

      if (!t.isEmpty() && !a.isEmpty()) {
         out.add(t + " " + a);
      }
      if (!t.isEmpty()) {
         out.add(t);
      }
      // Drop a subtitle after a dash: "Kesariya - Brahmastra" -> "Kesariya".
      int dash = t.indexOf(" - ");
      if (dash > 0) {
         String head = t.substring(0, dash).trim();
         if (!head.isEmpty()) {
            out.add(head);
         }
      }
      if (!a.isEmpty()) {
         out.add(a + " " + t);
      }
      out.remove("");
      return new java.util.ArrayList<>(out);
   }

   /** True when the text contains characters Minecraft's font cannot draw. */
   public static boolean needsRomanization(String text) {
      if (text == null) {
         return false;
      }
      for (int i = 0; i < text.length(); i++) {
         if (isNonLatinScript(text.charAt(i))) {
            return true;
         }
      }
      return false;
   }

   /**
    * Scripts the vanilla font has no glyphs for, so they draw as blank boxes.
    *
    * <p>Latin, Latin-1 accents and punctuation are fine and must not trigger
    * romanization - a French or Spanish lyric should stay exactly as written.</p>
    */
   private static boolean isNonLatinScript(char c) {
      return (c >= '\u0900' && c <= '\u097F')      // Devanagari (Hindi)
         || (c >= '\u0600' && c <= '\u06FF')       // Arabic / Urdu
         || (c >= '\u0400' && c <= '\u04FF')       // Cyrillic
         || (c >= '\u0980' && c <= '\u09FF')       // Bengali
         || (c >= '\u0A00' && c <= '\u0A7F')       // Gurmukhi (Punjabi)
         || (c >= '\u0B80' && c <= '\u0BFF')       // Tamil
         || (c >= '\u0C00' && c <= '\u0C7F')       // Telugu
         || (c >= '\u0E00' && c <= '\u0E7F')       // Thai
         || (c >= '\u3040' && c <= '\u30FF')       // Japanese kana
         || (c >= '\u4E00' && c <= '\u9FFF')       // CJK
         || (c >= '\uAC00' && c <= '\uD7AF')       // Hangul
         || (c >= '\u0370' && c <= '\u03FF')       // Greek
         || (c >= '\u05D0' && c <= '\u05EA');      // Hebrew
   }

   /** Lowercase, for logging. */
   public static String lower(String s) {
      return s == null ? "" : s.toLowerCase(Locale.ROOT);
   }
}
