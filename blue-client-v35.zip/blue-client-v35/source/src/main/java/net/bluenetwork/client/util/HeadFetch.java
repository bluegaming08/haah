package net.bluenetwork.client.util;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.bluenetwork.client.BlueClient;

/**
 * HeadFetch (v0.16.9) - fetches a player's full 64x64 skin from a public
 * head API (mc-heads.net) so account rows / the main-menu player card can
 * show real heads even for cracked accounts that Minecraft's skin provider
 * has no profile for.
 *
 * <p>{@link #head(String)} is safe to call every frame: it returns the
 * registered texture id once the skin is downloaded, null before that (and
 * kicks off exactly one background download per username). Callers are
 * expected to draw their own fallback when null comes back.</p>
 */
public final class HeadFetch {
   private static final Map<String, Identifier> LOADED = new ConcurrentHashMap<>();
   private static final Set<String> PENDING = ConcurrentHashMap.newKeySet();

   private HeadFetch() {
   }

   /**
    * Returns the registered skin texture for this username, or null while
    * the download is still in flight / failed.
    */
   public static Identifier head(String username) {
      if (username == null || username.isBlank()) {
         return null;
      }
      String key = username.toLowerCase(java.util.Locale.ROOT);
      Identifier id = LOADED.get(key);
      if (id != null) {
         return id;
      }
      if (PENDING.add(key)) {
         Thread t = new Thread(() -> fetch(key), "Blue Client Head Fetch");
         t.setDaemon(true);
         t.start();
      }
      return null;
   }

   private static void fetch(String key) {
      try {
         java.net.URL url = new java.net.URL("https://mc-heads.net/skin/" + key);
         try (java.io.InputStream in = url.openStream()) {
            NativeImage img = NativeImage.read(in);
            String safe = key.replaceAll("[^a-z0-9_]", "_");
            Identifier id = Identifier.of("blueclient", "head_" + safe);
            MinecraftClient.getInstance().execute(() -> {
               try {
                  NativeImageBackedTexture tex = new NativeImageBackedTexture(() -> "blueclient:head_" + safe, img);
                  MinecraftClient.getInstance().getTextureManager().registerTexture(id, tex);
                  LOADED.put(key, id);
               } catch (Throwable t2) {
                  BlueClient.LOGGER.debug("Head texture register failed for {}", key, t2);
               }
            });
         }
      } catch (Throwable t) {
         BlueClient.LOGGER.debug("Head fetch failed for {}: {}", key, t.toString());
      }
   }
}
