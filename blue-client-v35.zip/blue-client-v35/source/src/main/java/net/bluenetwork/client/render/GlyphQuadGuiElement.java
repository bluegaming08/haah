package net.bluenetwork.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2fc;

/** One glyph quad from the BlueFont atlas, drawn through the GLYPH pipeline. */
final class GlyphQuadGuiElement implements SimpleGuiElementRenderState {
    private final GpuTextureView texture;
    private final GpuSampler sampler;
    private final Matrix3x2fc pose;
    private final float x0;
    private final float y0;
    private final float x1;
    private final float y1;
    private final float u0;
    private final float v0;
    private final float u1;
    private final float v1;
    private final int color;
    private final ScreenRect scissorArea;
    private final ScreenRect bounds;

    GlyphQuadGuiElement(GpuTextureView texture, GpuSampler sampler, Matrix3x2fc pose,
                        float x0, float y0, float x1, float y1,
                        float u0, float v0, float u1, float v1,
                        int color, ScreenRect scissor, ScreenRect bounds) {
        this.texture = texture;
        this.sampler = sampler;
        this.pose = pose;
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
        this.u0 = u0;
        this.v0 = v0;
        this.u1 = u1;
        this.v1 = v1;
        this.color = color;
        this.scissorArea = scissor;
        this.bounds = bounds;
    }

    @Override
    public void setupVertices(VertexConsumer consumer) {
        consumer.vertex(pose, x0, y0).texture(u0, v0).color(color);
        consumer.vertex(pose, x1, y0).texture(u1, v0).color(color);
        consumer.vertex(pose, x1, y1).texture(u1, v1).color(color);
        consumer.vertex(pose, x0, y1).texture(u0, v1).color(color);
    }

    @Override
    public RenderPipeline pipeline() {
        return BluePipelines.GLYPH;
    }

    @Override
    public TextureSetup textureSetup() {
        return TextureSetup.of(texture, sampler);
    }

    @Override
    public ScreenRect scissorArea() {
        return scissorArea;
    }

    @Override
    public ScreenRect bounds() {
        return bounds;
    }
}
