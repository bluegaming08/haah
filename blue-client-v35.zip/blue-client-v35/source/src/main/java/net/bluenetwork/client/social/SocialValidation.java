package net.bluenetwork.client.social;

import java.util.Locale;

/**
 * Username rules, kept in one place.
 *
 * <p>These checks are a <b>convenience</b>: they let the UI say "too short"
 * instantly instead of waiting for a round trip. They are NOT the security
 * boundary. The identical rules exist as constraints in the database
 * ({@code profiles_username_format} and the unique index on
 * {@code username_low}), which is what actually stops a modified client.</p>
 *
 * <p>If you change the rules here, change them in {@code backend/schema.sql}
 * too, or the client will accept names the database then rejects.</p>
 */
public final class SocialValidation {

   public static final int MIN_LENGTH = 3;
   public static final int MAX_LENGTH = 16;

   private SocialValidation() {
   }

   /**
    * @return null when the username is fine, otherwise the reason it is not.
    */
   public static String usernameError(String name) {
      if (name == null || name.isBlank()) {
         return "Enter a username.";
      }
      if (name.length() < MIN_LENGTH) {
         return "Username must be at least " + MIN_LENGTH + " characters.";
      }
      if (name.length() > MAX_LENGTH) {
         return "Username must be at most " + MAX_LENGTH + " characters.";
      }
      for (int i = 0; i < name.length(); i++) {
         char c = name.charAt(i);
         boolean ok = (c >= 'a' && c <= 'z')
            || (c >= 'A' && c <= 'Z')
            || (c >= '0' && c <= '9')
            || c == '_';
         if (!ok) {
            return "Only letters, numbers and _ are allowed.";
         }
      }
      return null;
   }

   /** The lowercase form used for uniqueness and searching. */
   public static String normalize(String name) {
      return name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
   }
}
