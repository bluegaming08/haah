package net.bluenetwork.client.music;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

/**
 * Minimal ID3 reader for local songs (v0.16.14 lyrics). Reads only what the
 * lyrics search needs - title (TIT2) and artist (TPE1) - from ID3v2 (2.2/2.3/2.4)
 * with an ID3v1 tail fallback. No third-party library, no mutation: the MP3
 * itself never has lyrics, these tags are how we know WHAT to search for.
 */
public final class Id3Tags {
   public record Tags(String title, String artist) {
   }

   private Id3Tags() {
   }

   /** Returns null when the file carries no usable tags. */
   public static Tags read(Path file) {
      try (RandomAccessFile raf = new RandomAccessFile(file.toFile(), "r")) {
         Tags v2 = readV2(raf);
         if (v2 != null && (v2.title() != null || v2.artist() != null)) {
            return v2;
         }
         return readV1(raf);
      } catch (Throwable t) {
         return null;
      }
   }

   private static Tags readV2(RandomAccessFile raf) throws IOException {
      byte[] head = new byte[10];
      if (raf.length() < 10 || raf.read(head) != 10) {
         return null;
      }
      if (head[0] != 'I' || head[1] != 'D' || head[2] != '3') {
         return null;
      }
      int major = head[3] & 0xFF;
      int size = synchsafe(head[6], head[7], head[8], head[9]);
      // Only the header start of the tag - lyrics search never needs more.
      int limit = Math.min(size, 1 << 18);
      byte[] tag = new byte[limit];
      int read = raf.read(tag);
      if (read <= 0) {
         return null;
      }
      String title = null;
      String artist = null;
      int pos = 0;
      while (pos + 10 <= read) {
         int idLen = major <= 2 ? 3 : 4;
         if (pos + idLen + (major <= 2 ? 3 : 6) > read) {
            break;
         }
         StringBuilder idb = new StringBuilder();
         for (int i = 0; i < idLen; i++) {
            char c = (char) (tag[pos + i] & 0xFF);
            /*
             * BUGFIX (v0.24.4): this used to accept only 'A'-'Z', but real ID3
             * frame ids contain DIGITS - the two we actually want are TIT2 and
             * TPE1. The very first frame therefore failed the check and the
             * parser returned empty tags for every file in existence.
             * Frame ids are [A-Z0-9], so digits must be allowed; anything else
             * still means we have run past the frame area into padding.
             */
            boolean valid = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
            if (!valid) {
               return new Tags(title, artist); // ran off the frame area
            }
            idb.append(c);
         }
         String id = idb.toString();
         int frameSize;
         int headerLen;
         if (major <= 2) {
            frameSize = ((tag[pos + 3] & 0xFF) << 16) | ((tag[pos + 4] & 0xFF) << 8) | (tag[pos + 5] & 0xFF);
            headerLen = 6;
         } else {
            if (major == 4) {
               frameSize = synchsafe(tag[pos + 4], tag[pos + 5], tag[pos + 6], tag[pos + 7]);
            } else {
               frameSize = ((tag[pos + 4] & 0xFF) << 24) | ((tag[pos + 5] & 0xFF) << 16)
                  | ((tag[pos + 6] & 0xFF) << 8) | (tag[pos + 7] & 0xFF);
            }
            headerLen = 10;
         }
         if (frameSize <= 0 || frameSize > read) {
            break;
         }
         int dataStart = pos + headerLen;
         if ((id.equals("TIT2") || id.equals("TT2")) && title == null) {
            title = decodeText(tag, dataStart, Math.min(frameSize, read - dataStart));
         } else if ((id.equals("TPE1") || id.equals("TPE2") || id.equals("TP1")) && artist == null) {
            artist = decodeText(tag, dataStart, Math.min(frameSize, read - dataStart));
         }
         pos = dataStart + frameSize;
      }
      return new Tags(title, artist);
   }

   private static String decodeText(byte[] data, int start, int len) {
      if (len <= 1) {
         return null;
      }
      int encoding = data[start] & 0xFF;
      int off = start + 1;
      int textLen = len - 1;
      try {
         return (switch (encoding) {
            case 0 -> new String(data, off, textLen, StandardCharsets.ISO_8859_1);
            case 1 -> new String(data, off, stripZero(textLen, data, off, true), "UTF-16");
            case 2 -> new String(data, off, stripZero(textLen, data, off, true), "UTF-16BE");
            default -> new String(data, off, textLen, StandardCharsets.UTF_8);
         }).trim();
      } catch (Throwable t) {
         return null;
      }
   }

   /** ID3 text frames are often zero-padded - trim the trailing padding. */
   private static int stripZero(int len, byte[] data, int off, boolean utf16) {
      int end = off + len;
      // Termination is one 0x00 for latin/utf-8 and 0x00 0x00 aligned for utf-16.
      while (end > off && data[end - 1] == 0) {
         end--;
      }
      if (utf16) {
         int usable = end - off;
         if (usable % 2 == 1) {
            end--;
         }
      }
      return Math.max(0, end - off);
   }

   private static Tags readV1(RandomAccessFile raf) throws IOException {
      if (raf.length() < 128) {
         return null;
      }
      raf.seek(raf.length() - 128);
      byte[] tail = new byte[128];
      if (raf.read(tail) != 128 || tail[0] != 'T' || tail[1] != 'A' || tail[2] != 'G') {
         return null;
      }
      String title = fixed(tail, 3, 30);
      String artist = fixed(tail, 33, 30);
      return new Tags(title, artist);
   }

   private static String fixed(byte[] data, int off, int len) {
      String s = new String(data, off, len, StandardCharsets.ISO_8859_1).trim();
      int zero = s.indexOf('\0');
      return zero >= 0 ? s.substring(0, zero).trim() : s;
   }

   private static int synchsafe(byte a, byte b, byte c, byte d) {
      return ((a & 0x7F) << 21) | ((b & 0x7F) << 14) | ((c & 0x7F) << 7) | (d & 0x7F);
   }
}
