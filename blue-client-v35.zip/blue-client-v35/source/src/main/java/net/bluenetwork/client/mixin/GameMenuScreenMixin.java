package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.gui.PauseMenuScreen;
import net.bluenetwork.client.gui.QuickMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Vanilla pause menu integration.
 *
 * <h2>Two modes</h2>
 * <ul>
 *   <li><b>Custom pause menu ON</b> — {@code init} is cancelled and replaced
 *       with {@link PauseMenuScreen}.</li>
 *   <li><b>Vanilla pause menu ON</b> — a real {@link ButtonWidget} labelled
 *       "Blue Client" is added below Advancements / Statistics.</li>
 * </ul>
 *
 * <h2>v0.24.0 FIX: "the button in pause menu (the blue client button) isn't working"</h2>
 * The old implementation faked a button: {@code PauseSquares} stored some
 * coordinates, {@code ScreenMixin} painted a square there, and a
 * {@code mouseClicked} hook compared raw mouse coordinates against them.
 * That could never work, for three reasons:
 * <ol>
 *   <li><b>The click hook had no valid target.</b> It injected into
 *       {@code Screen.mouseClicked}, but {@code Screen} does not declare that
 *       method — it inherits the default from the {@code Element} interface.
 *       Mixin therefore failed to apply the injection at launch. This is the
 *       actual root cause, found with {@code javap} + {@code verify_mixins.py}.</li>
 *   <li>The coordinates were computed in {@code init}, but the vanilla menu
 *       re-lays-out on resize without our hook re-running, so the painted
 *       square and the clickable region drifted apart.</li>
 *   <li>Nothing gave the fake button focus or narration, so it was invisible
 *       to keyboard navigation and accessibility.</li>
 * </ol>
 * The owner asked for this explicitly: <i>"it should open the right shift menu
 * upon clicking and should use the minecraft api not something blah blah"</i>.
 * So it is now a genuine {@code ButtonWidget} added through
 * {@code Screen.addDrawableChild}. Minecraft owns hit-testing, hover, focus
 * and narration — there is nothing left to drift.
 */
@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin {

   /**
    * Width of the full-width vanilla pause-menu buttons ("Back to Game").
    * The owner asked for "the same size as the back to game button".
    */
   private static final int BLUE_BUTTON_WIDTH = 204;
   private static final int BLUE_BUTTON_HEIGHT = 20;

   /** Width of the small square "switch to the custom menu" button. */
   private static final int SWITCH_BUTTON_SIZE = 20;

   @Inject(method = "init", at = @At("HEAD"), cancellable = true)
   private void blueclient$replacePauseMenu(CallbackInfo ci) {
      if (BlueClient.getInstance().settings().customPauseMenu()) {
         MinecraftClient.getInstance().setScreen(new PauseMenuScreen());
         ci.cancel();
      }
   }

   /**
    * Adds the real "Blue Client" button to the vanilla pause menu.
    *
    * <p>Placement: the owner asked for it "below advancements and statistics
    * button". Rather than hardcoding a y offset, we measure the widgets vanilla
    * already added and anchor below the lowest one. That keeps the layout right
    * when the menu gains or loses a row — "Open to LAN" only exists in
    * singleplayer, for example.</p>
    */
   @Inject(method = "init", at = @At("TAIL"))
   private void blueclient$addBlueClientButton(CallbackInfo ci) {
      if (BlueClient.getInstance().settings().customPauseMenu()) {
         return;
      }
      Screen self = (Screen) (Object) this;

      int lowest = Integer.MIN_VALUE;
      for (var element : self.children()) {
         if (element instanceof ClickableWidget widget && widget.visible) {
            lowest = Math.max(lowest, widget.getY() + widget.getHeight());
         }
      }
      int x = self.width / 2 - BLUE_BUTTON_WIDTH / 2;
      int y = lowest == Integer.MIN_VALUE ? self.height / 4 + 120 : lowest + 4;

      // Never push the button off the bottom of a short window.
      y = Math.min(y, self.height - BLUE_BUTTON_HEIGHT - 4);

      ButtonWidget button = ButtonWidget
         .builder(Text.literal("Blue Client"), b ->
            // Owner: "it should open the right shift menu upon clicking".
            // QuickMenuScreen is exactly what the right-shift keybind opens.
            MinecraftClient.getInstance().setScreen(new QuickMenuScreen()))
         .dimensions(x, y, BLUE_BUTTON_WIDTH, BLUE_BUTTON_HEIGHT)
         .tooltip(Tooltip.of(Text.literal("Open the Blue Client quick menu")))
         .build();

      ((ScreenInvoker) self).blueclient$invokeAddDrawableChild(button);

      /*
       * v0.24.1 - "the custom pause menu has a button to switch to vanilla one
       * but vanilla one doesnt have a button to switch to custom one".
       *
       * A small square button immediately right of the Blue Client button.
       * It flips the setting, saves it, and re-opens the pause menu - the HEAD
       * inject above then routes straight to PauseMenuScreen. Using the same
       * setting both directions means the choice is remembered.
       */
      ButtonWidget switchButton = ButtonWidget
         .builder(Text.literal("\u2750"), b -> {
            BlueClient.getInstance().settings().customPauseMenu(true);
            BlueClient.getInstance().configManager().save();
            MinecraftClient.getInstance().setScreen(new PauseMenuScreen());
         })
         .dimensions(x + BLUE_BUTTON_WIDTH + 4, y, SWITCH_BUTTON_SIZE, BLUE_BUTTON_HEIGHT)
         .tooltip(Tooltip.of(Text.literal("Switch to the Blue Client pause menu")))
         .build();

      ((ScreenInvoker) self).blueclient$invokeAddDrawableChild(switchButton);
   }
}
