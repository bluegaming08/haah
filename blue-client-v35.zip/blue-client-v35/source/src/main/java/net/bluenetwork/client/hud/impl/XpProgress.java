package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;

/**
 * XP Progress (bonus HUD) — your level and progress to the next level as a
 * compact "Lv 27 · 62%" panel, plus a thin progress bar.
 */
public class XpProgress extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);
   private final ColorSetting barColor = new ColorSetting("Bar color", "Progress bar colour", 0xFF7BE4A6);

   public XpProgress() {
      super("XP Progress", "Level and progress to the next level", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.barColor});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 90);
   }

   private int level() {
      PlayerEntity p = MinecraftClient.getInstance().player;
      return p != null ? p.experienceLevel : 0;
   }

   private int percent() {
      PlayerEntity p = MinecraftClient.getInstance().player;
      if (p == null) {
         return 0;
      }
      return Math.max(0, Math.min(100, (int) (p.experienceProgress * 100.0F)));
   }

   private String text() {
      return "Lv " + this.level() + " \u00b7 " + this.percent() + "%";
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, color);
      int barW = this.getWidth() - 12;
      int barH = 3;
      int bx = this.x + 6;
      int by = this.y + this.getHeight() - 8;
      context.fill(bx, by, bx + barW, by + barH, 0x66000000);
      context.fill(bx, by, bx + barW * this.percent() / 100, by + barH, this.barColor.currentRgb(System.currentTimeMillis()));
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Lv 000 \u00b7 100%") + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 26;
   }
}
