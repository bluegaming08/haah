package net.bluenetwork.client.social;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Parses and applies the Blue+ coloured-name setting.
 *
 * <h2>The stored format</h2>
 * A tiny JSON object, validated server-side by {@code set_name_color()}:
 *
 * <pre>
 *   {"a":"#2FA5FF","b":"#FFD600","g":1,"bo":1,"it":0}
 * </pre>
 *
 * <ul>
 *   <li>{@code a} - primary colour (or gradient start). Required, hex only.</li>
 *   <li>{@code b} - gradient end. Optional.</li>
 *   <li>{@code g} - 1 to draw a gradient between a and b.</li>
 *   <li>{@code bo} / {@code it} - bold / italic.</li>
 * </ul>
 *
 * <h2>Why parsing is defensive</h2>
 * The database already rejects anything that is not a {@code #RRGGBB} hex
 * string, so this should never see rubbish. But this code runs inside the
 * render loop for <b>other players'</b> data, and a throw there would take the
 * game down. Every method therefore falls back to a sane default rather than
 * propagating an exception - the same lesson as the Fullbright crash.
 */
public final class NameColor {

   private NameColor() {
   }

   /** Solid fill - {@code g:0} or absent. */
   public static final int GRAD_NONE = 0;
   /** Left-to-right gradient - {@code g:1}. */
   public static final int GRAD_HORIZONTAL = 1;
   /** Top-to-bottom gradient - {@code g:2}. */
   public static final int GRAD_VERTICAL = 2;

   /**
    * A parsed colour spec. All fields are safe to use directly.
    *
    * @param gradType one of {@link #GRAD_NONE}, {@link #GRAD_HORIZONTAL},
    *                 {@link #GRAD_VERTICAL}
    */
   public record Spec(int primary, int secondary, int gradType,
                      boolean bold, boolean italic) {

      /** The plain colour to use when gradients are not supported. */
      public int flat() {
         return this.primary;
      }

      /** True when this spec paints a gradient of any direction. */
      public boolean gradient() {
         return this.gradType != GRAD_NONE;
      }

      /** True for a top-to-bottom gradient. */
      public boolean vertical() {
         return this.gradType == GRAD_VERTICAL;
      }
   }

   private static final Spec NONE = new Spec(0, 0, GRAD_NONE, false, false);

   /**
    * Parses the stored JSON.
    *
    * @param json     the raw value, may be null
    * @param fallback colour to use when there is no valid spec
    */
   public static Spec parse(String json, int fallback) {
      if (json == null || json.isBlank()) {
         return new Spec(fallback, fallback, GRAD_NONE, false, false);
      }
      try {
         JsonObject o = JsonParser.parseString(json).getAsJsonObject();
         int a = hex(o.has("a") ? o.get("a").getAsString() : null, fallback);
         int b = hex(o.has("b") ? o.get("b").getAsString() : null, a);

         // "g" used to be a 0/1 flag and is now a gradient TYPE. Reading it as
         // a number keeps every value already stored working: an old g:1 means
         // horizontal, which is exactly what it used to draw.
         int g = GRAD_NONE;
         if (o.has("g") && o.get("g").isJsonPrimitive()) {
            try {
               g = o.get("g").getAsInt();
            } catch (Throwable notANumber) {
               g = flag(o, "g") ? GRAD_HORIZONTAL : GRAD_NONE;
            }
         }
         if (g < GRAD_NONE || g > GRAD_VERTICAL || !o.has("b")) {
            g = GRAD_NONE;
         }
         return new Spec(a, b, g, flag(o, "bo"), flag(o, "it"));
      } catch (Throwable t) {
         // Never let one player's malformed setting break another's render.
         return new Spec(fallback, fallback, GRAD_NONE, false, false);
      }
   }

   /** Convenience: just the primary colour, for single-colour draws. */
   public static int primary(String json, int fallback) {
      return parse(json, fallback).primary();
   }

   /**
    * Blends between the gradient endpoints.
    *
    * @param t 0.0 at the start of the name, 1.0 at the end
    */
   public static int blend(Spec spec, float t) {
      if (spec.gradType() == GRAD_NONE) {
         return spec.primary();
      }
      float clamped = Math.max(0.0F, Math.min(1.0F, t));
      int a = spec.primary();
      int b = spec.secondary();
      int ar = (a >> 16) & 0xFF;
      int ag = (a >> 8) & 0xFF;
      int ab = a & 0xFF;
      int br = (b >> 16) & 0xFF;
      int bg = (b >> 8) & 0xFF;
      int bb = b & 0xFF;
      int r = Math.round(ar + (br - ar) * clamped);
      int g = Math.round(ag + (bg - ag) * clamped);
      int bl = Math.round(ab + (bb - ab) * clamped);
      return 0xFF000000 | (r << 16) | (g << 8) | bl;
   }

   /**
    * Builds the JSON for {@code set_name_color()} / {@code set_profile_color()}.
    *
    * @param gradType {@link #GRAD_NONE}, {@link #GRAD_HORIZONTAL} or
    *                 {@link #GRAD_VERTICAL}
    */
   public static String toJson(int primary, Integer secondary, int gradType,
                               boolean bold, boolean italic) {
      StringBuilder sb = new StringBuilder("{\"a\":\"").append(toHex(primary)).append('"');
      if (secondary != null) {
         sb.append(",\"b\":\"").append(toHex(secondary)).append('"');
      }
      if (gradType != GRAD_NONE && secondary != null) {
         sb.append(",\"g\":").append(gradType);
      }
      if (bold) {
         sb.append(",\"bo\":1");
      }
      if (italic) {
         sb.append(",\"it\":1");
      }
      return sb.append('}').toString();
   }

   /** "#RRGGBB" -> 0xFFRRGGBB, or the fallback if it is not valid. */
   private static int hex(String value, int fallback) {
      if (value == null || !value.matches("^#[0-9A-Fa-f]{6}$")) {
         return fallback;
      }
      return 0xFF000000 | Integer.parseInt(value.substring(1), 16);
   }

   private static String toHex(int argb) {
      return String.format("#%06X", argb & 0xFFFFFF);
   }

   private static boolean flag(JsonObject o, String key) {
      try {
         return o.has(key) && !o.get(key).isJsonNull() && o.get(key).getAsInt() != 0;
      } catch (Throwable t) {
         return false;
      }
   }
}
