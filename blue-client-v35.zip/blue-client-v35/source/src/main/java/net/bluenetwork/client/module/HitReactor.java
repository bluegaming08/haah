package net.bluenetwork.client.module;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Implemented by modules that react to the local player attacking something. */
public interface HitReactor {
   void onHit(PlayerEntity attacker, Entity target);
}
