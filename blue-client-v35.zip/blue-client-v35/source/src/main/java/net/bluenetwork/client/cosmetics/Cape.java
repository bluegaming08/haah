package net.bluenetwork.client.cosmetics;

import net.minecraft.util.Identifier;

/**
 * A single cape entry in the catalog. {@code animated}/{@code frames}/
 * {@code fps} describe a vertically-stacked frame atlas texture — not used
 * by the 3 starter capes (all static) but wired end-to-end so a GIF-derived
 * animated cape only needs a texture + these 3 numbers, no new code.
 */
public record Cape(String id, String displayName, CapeRarity rarity, Identifier textureId,
                   boolean animated, int frames, int fps) {

   public static Cape of(String id, String displayName, CapeRarity rarity, String texturePath) {
      return new Cape(id, displayName, rarity, Identifier.of("blueclient", texturePath), false, 1, 0);
   }

   public static Cape animated(String id, String displayName, CapeRarity rarity, String texturePath, int frames, int fps) {
      return new Cape(id, displayName, rarity, Identifier.of("blueclient", texturePath), true, frames, fps);
   }
}
