package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

public class AttackIndicator extends HudModule {
   private static final int BAR_W = 40;
   private static final int BAR_H = 3;

   public AttackIndicator() {
      super("Attack Indicator", "Cooldown bar for your attacks", Category.COMBAT, 0, 0);
   }

   private static int centerX(MinecraftClient mc) {
      return mc.getWindow().getScaledWidth() / 2;
   }

   private static int centerY(MinecraftClient mc) {
      return mc.getWindow().getScaledHeight() / 2;
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity player = mc.player;
      if (player != null) {
         float progress = player.getAttackCooldownProgress(0.0F);
         if (!(progress >= 0.999F)) {
            int x = centerX(mc) - 20;
            int y = centerY(mc) + 12;
            context.fill(x - 1, y - 1, x + 40 + 1, y + 3 + 1, BlueColors.PANEL_BG);
            context.fill(x, y, x + (int)(40.0F * progress), y + 3, -13673473);
            context.fill(x + (int)(40.0F * progress), y, x + 40, y + 3, BlueColors.TOGGLE_OFF);
         }
      }
   }

   @Override
   public int getWidth() {
      return 42;
   }

   @Override
   public int getHeight() {
      return 5;
   }

   @Override
   public int getX() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return centerX(mc) - 20;
   }

   @Override
   public int getY() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return centerY(mc) + 12;
   }
}
