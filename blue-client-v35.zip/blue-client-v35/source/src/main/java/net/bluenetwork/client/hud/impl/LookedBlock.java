package net.bluenetwork.client.hud.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * Looked Block - the block under your crosshair, shown as its real item icon
 * and/or its name (v0.16.9: dropped the old "Look" text prefix, added icon +
 * display modes). Hardness is appended when the block is breakable.
 */
public class LookedBlock extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "Label colour", 0xFFFFFFFF);
   private final ModeSetting display = new ModeSetting("Display", "What to show for the target block",
      List.of("BOTH", "NAME", "ICON"), "BOTH");

   public LookedBlock() {
      super("Looked Block", "Block under the crosshair + hardness", Category.HUD, 4, 4);
      this.addSettings(new Setting[]{this.textColor, this.display});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 6, 128);
   }

   private BlockState target(MinecraftClient mc) {
      if (mc.player == null || mc.world == null || mc.crosshairTarget == null
            || mc.crosshairTarget.getType() != HitResult.Type.BLOCK
            || !(mc.crosshairTarget instanceof BlockHitResult hit)) {
         return null;
      }
      return mc.world.getBlockState(hit.getBlockPos());
   }

   private String name(BlockState state, MinecraftClient mc) {
      String name = state.getBlock().getName().getString();
      float hardness = state.getHardness(mc.world, ((BlockHitResult) mc.crosshairTarget).getBlockPos());
      if (hardness < 0.0F) {
         return name + " \u221e";
      }
      if (hardness < 0.6F) {
         return name + " (instant)";
      }
      return name;
   }

   private boolean wantsIcon() {
      return !"NAME".equals(this.display.get());
   }

   private boolean wantsName() {
      return !"ICON".equals(this.display.get());
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      BlockState state = this.target(mc);
      this.drawPanel(context);
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      if (state == null) {
         RenderUtil.drawText(context, "--", this.x + 6, this.y + 6, color);
         return;
      }
      int iconW = 0;
      if (this.wantsIcon()) {
         context.drawItem(new ItemStack(state.getBlock()), this.x + 4, this.y + 2);
         iconW = 18;
      }
      if (this.wantsName()) {
         RenderUtil.drawText(context, this.name(state, mc), this.x + 6 + iconW, this.y + 6, color);
      }
   }

   @Override
   public int getWidth() {
      int w = 12;
      MinecraftClient mc = MinecraftClient.getInstance();
      BlockState state = mc.world != null ? this.target(mc) : null;
      if (this.wantsIcon()) {
         w += 16;
      }
      if (this.wantsName() && state != null) {
         w += RenderUtil.textWidth(this.name(state, mc)) + 4;
      }
      if (this.wantsName() && state == null) {
         w += 40;
      }
      return w;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
