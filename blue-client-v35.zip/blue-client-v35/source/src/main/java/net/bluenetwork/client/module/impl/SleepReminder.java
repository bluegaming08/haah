package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.world.World;

/**
 * Sleep Reminder (bonus utility) — a gentle toast once per in-game night when
 * you are in the Overworld and it is dark enough to sleep. Never forces
 * anything; it only reminds.
 */
public class SleepReminder extends Module {
   private final BooleanSetting sound = new BooleanSetting("Sound", "Soft tone with the reminder", true);
   private long remindedDay = -1L;

   public SleepReminder() {
      super("Sleep Reminder", "Nudge to sleep when night falls", Category.MISC);
      this.addSettings(new Setting[]{this.sound});
   }

   @Override
   protected void onDisable() {
      this.remindedDay = -1L;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity p = mc.player;
      if (p == null || mc.world == null || mc.world.getRegistryKey() != World.OVERWORLD) {
         return;
      }
      if (p.getAbilities().creativeMode) {
         return;
      }
      long time = mc.world.getTimeOfDay();
      long day = time / 24000L;
      long tick = time % 24000L;
      if (this.remindedDay == day) {
         return;
      }
      if (tick < 13000L) {
         return;
      }
      this.remindedDay = day;
      if (this.sound.get()) {
         Sounds.softAlert();
      }
      try {
         BlueClient.getInstance().notificationManager().add("It's night - you can sleep", 0xFFA5C8FF);
      } catch (Throwable ignored) {
      }
   }
}
