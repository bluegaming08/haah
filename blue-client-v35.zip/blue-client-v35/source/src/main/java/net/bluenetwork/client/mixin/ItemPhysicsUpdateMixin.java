package net.bluenetwork.client.mixin;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.bluenetwork.client.render.ItemPhysicsState;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Copies the physics data an item needs from the entity onto its render state.
 *
 * <p>Runs in {@code updateRenderState}, the one place per frame where both the
 * live {@link ItemEntity} and its {@link ItemEntityRenderState} are in scope.
 * {@code ItemPhysicsMixin} then reads the values while drawing.</p>
 *
 * <h2>Why the landing time is tracked here</h2>
 * The entity knows <i>whether</i> it is on the ground but not <i>since when</i>,
 * and the settling animation needs the elapsed time. A small map keyed by
 * entity id records the moment each item first landed. It is bounded: entries
 * are dropped once an item leaves the ground, and the whole map is cleared if
 * it ever grows past {@link #MAX_TRACKED} (a safety valve for something like an
 * item-spam farm), so it cannot grow without limit.
 */
@Mixin(ItemEntityRenderer.class)
public abstract class ItemPhysicsUpdateMixin {

   /** Entity id to the client time (ms) it first touched the ground. */
   @Unique
   private static final Map<Integer, Long> BLUECLIENT$LANDED = new ConcurrentHashMap<>();

   /** Safety valve so a pathological world cannot grow the map forever. */
   @Unique
   private static final int MAX_TRACKED = 4096;

   @Inject(
      method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V",
      at = @At("TAIL"),
      require = 0
   )
   private void blueclient$capturePhysics(ItemEntity entity, ItemEntityRenderState state,
                                          float tickDelta, CallbackInfo ci) {
      try {
         if (!(state instanceof ItemPhysicsState physics)) {
            return;
         }
         boolean onGround = entity.isOnGround();
         physics.blueclient$setOnGround(onGround);
         physics.blueclient$setSeed(entity.getId() * 31);

         int id = entity.getId();
         if (!onGround) {
            BLUECLIENT$LANDED.remove(id);
            physics.blueclient$setAge(0.0F);
            return;
         }
         if (BLUECLIENT$LANDED.size() > MAX_TRACKED) {
            BLUECLIENT$LANDED.clear();
         }
         long since = BLUECLIENT$LANDED.computeIfAbsent(id, key -> System.currentTimeMillis());
         // Convert to ticks (20/s) so the settle maths reads naturally.
         float ticks = (System.currentTimeMillis() - since) / 50.0F;
         physics.blueclient$setAge(ticks);
      } catch (Throwable ignored) {
      }
   }
}
