package net.bluenetwork.client.render;

/**
 * Extra per-item data the Item Physics module needs at render time.
 *
 * <p>{@code ItemEntityRenderState} carries no reference back to its
 * {@code ItemEntity}, but physics has to know whether the item has landed and
 * which item it is (so each one settles differently rather than in lockstep).
 * Mixin "duck typing" solves this: {@code ItemEntityRenderStateMixin} makes the
 * vanilla render state implement this interface, and
 * {@code ItemPhysicsMixin} fills it in during {@code updateRenderState}.</p>
 *
 * <p>Reading it later is a plain interface call — no maps, no lookups by
 * position, and nothing to clean up when an item despawns.</p>
 */
public interface ItemPhysicsState {

   /** @return true once the item entity is resting on the ground. */
   boolean blueclient$isOnGround();

   void blueclient$setOnGround(boolean onGround);

   /** @return ticks the item has existed, used to drive the settling animation. */
   float blueclient$getAge();

   void blueclient$setAge(float age);

   /** @return a stable per-entity value, so items do not all land identically. */
   int blueclient$getSeed();

   void blueclient$setSeed(int seed);
}
