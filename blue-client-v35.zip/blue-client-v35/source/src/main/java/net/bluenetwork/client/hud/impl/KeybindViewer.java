package net.bluenetwork.client.hud.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

/**
 * Keybind Viewer (v3 catalogue H5) — overlay listing which enabled modules have
 * a keybind and what key that is. Sorted by key. Shows the module colour accent
 * when toggling is common.
 */
public class KeybindViewer extends HudModule {
   private final ColorSetting textColor = new ColorSetting("Text color", "List colour", 0xFFFFFFFF);
   private final BooleanSetting onlyEnabled = new BooleanSetting("Only enabled", "Hide disabled modules from the list", false);
   private final BooleanSetting groupByCategory = new BooleanSetting("Group by category", "Separate Combat / Movement / ... rows", true);

   public KeybindViewer() {
      super("Keybind Viewer", "Your module keybinds at a glance", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.textColor, this.onlyEnabled, this.groupByCategory});
      this.setAnchorAndOffsets(HudModule.Anchor.BOTTOM_LEFT, 6, 30);
   }

   private List<String> rows() {
      List<String> out = new ArrayList<>();
      List<Module> all = new ArrayList<>(BlueClient.getInstance().moduleManager().getModules());
      all.removeIf(m -> m.getKeybind() == 0 || (this.onlyEnabled.get() && !m.isEnabled()));
      all.sort(Comparator.comparingInt(Module::getKeybind).thenComparing(Module::getName));
      String lastGroup = null;
      for (Module m : all) {
         String group = this.groupByCategory.get() ? m.getCategory().displayName() : null;
         if (group != null && !group.equals(lastGroup)) {
            out.add(group);
            lastGroup = group;
         }
         out.add("  " + m.getName() + " \u2192 " + keyName(m.getKeybind()));
      }
      return out;
   }

   private static String keyName(int code) {
      String name = GLFW.glfwGetKeyName(code, 0);
      return name != null ? name.toUpperCase() : "KEY " + code;
   }

   @Override
   public void render(DrawContext context) {
      List<String> rows = this.rows();
      if (rows.isEmpty()) {
         return;
      }
      this.drawPanel(context);
      int ty = this.y + 6;
      int color = this.textColor.currentRgb(System.currentTimeMillis());
      for (String row : rows) {
         boolean heading = !row.startsWith("  ");
         RenderUtil.drawText(context, row.trim(), this.x + 6 + 2, ty, heading ? 0xFF9BE7FF : color);
         ty += 9;
      }
   }

   @Override
   public int getWidth() {
      int max = 0;
      for (String row : this.rows()) {
         max = Math.max(max, RenderUtil.textWidth(row.trim()));
      }
      return Math.max(20, max + 12 + 2);
   }

   @Override
   public int getHeight() {
      int rows = this.rows().size();
      return Math.max(21, rows * 9 + 12);
   }
}
