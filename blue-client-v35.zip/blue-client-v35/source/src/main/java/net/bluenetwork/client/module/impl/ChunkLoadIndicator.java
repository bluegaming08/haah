package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;

/**
 * Chunk Load Indicator (v3 catalogue G3) — "show loaded chunk info on demand":
 * each time you enable it (via its keybind) it pops a toast with the loaded
 * chunk count and the current render distance, then does nothing until the next
 * toggle. No scanning cost while on.
 */
public class ChunkLoadIndicator extends Module {
   public ChunkLoadIndicator() {
      super("Chunk Load Indicator", "Toast with loaded-chunk stats on demand", Category.MISC);
   }

   @Override
   protected void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientWorld world = mc.world;
      if (world == null) {
         this.toast("No world loaded");
         return;
      }
      int chunks = world.getChunkManager().getLoadedChunkCount();
      int distance = mc.options.getViewDistance().getValue();
      this.toast("Chunks loaded: " + chunks + "  (render distance " + distance + ")");
   }

   private void toast(String message) {
      try {
         BlueClient.getInstance().notificationManager().add(message, 0xFF4D8DFF);
      } catch (Throwable ignored) {
      }
   }
}
