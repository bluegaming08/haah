package net.bluenetwork.client.module.impl;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.module.ModuleActions;
import net.bluenetwork.client.recorder.AudioRecorder;
import net.bluenetwork.client.recorder.VideoRecorder;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.ScreenshotRecorder;

/**
 * In-Game Screen Recorder.
 *
 * <h2>Owner spec</h2>
 * <pre>
 *   add a in game screen recorder, make it lightweight. add a keybind for it,
 *   and when im recording, there should be a hud showing how long ive been
 *   recording for and the file size. settings: record sound, record mic,
 *   select which mic, resolution from 720p to 4k, and other useful recorder
 *   settings, and a toggle for whether the hud shows up in the recording
 * </pre>
 *
 * <h2>How it fits together</h2>
 * <pre>
 *   ScreenRecorder (this)      the module: settings, keybind, HUD, state
 *        |
 *        +-- RecorderHookMixin captures the frame at the right moment
 *        +-- VideoRecorder     background H.264 encode to .mp4
 *        +-- AudioRecorder     optional mic / loopback capture to .wav
 * </pre>
 *
 * <h2>"Show HUD in the recording"</h2>
 * Decided by <i>when</i> we grab the framebuffer, not by hiding anything:
 * <ul>
 *   <li><b>off</b> — capture at the end of {@code GameRenderer.renderWorld},
 *       where the world is drawn but the HUD is not yet composited;</li>
 *   <li><b>on</b> — capture at the end of {@code GameRenderer.render}, after
 *       everything.</li>
 * </ul>
 * No UI is toggled, so your own screen looks the same either way.
 *
 * <h2>Keeping it lightweight</h2>
 * <ul>
 *   <li>Frames are captured at the chosen <b>FPS</b>, not every rendered frame:
 *       at 30 fps on a 120 fps machine we skip three frames out of four.</li>
 *   <li>Encoding happens on a low-priority background thread; if it falls
 *       behind, frames are dropped rather than stalling the game.</li>
 *   <li>Nothing is allocated while idle.</li>
 * </ul>
 */
public class ScreenRecorder extends HudModule implements ModuleActions {

   /*
    * LAZY, FAULT-TOLERANT ENCODER HANDLE  (fix for the 0.24.0 startup crash)
    * =======================================================================
    * These used to be eagerly-initialised final fields:
    *
    *     private final VideoRecorder video = new VideoRecorder();
    *
    * That single line crashed the entire game on startup. VideoRecorder's
    * encodeLoop() declares a local of type org.jcodec...SeekableByteChannel,
    * so the JVM verifier resolves JCodec the moment VideoRecorder is linked.
    * With the nested jar missing from fabric.mod.json's "jars" array, that
    * throws NoClassDefFoundError inside this constructor, which runs inside
    * ModuleManager.registerDefaults(), which runs inside the client
    * entrypoint -> "Could not execute entrypoint stage 'client'".
    *
    * The declaration bug is fixed, but the fragility is not acceptable: ONE
    * optional feature's optional dependency must never be able to take the
    * whole client down. So the encoder is now created lazily, on the first
    * recording attempt, behind a Throwable guard. If JCodec is ever missing
    * again the user gets "Recorder unavailable" in a toast and everything
    * else in Blue Client keeps working.
    */

   /** Created on first use; null until then, and stays null if JCodec is absent. */
   private VideoRecorder video;

   /** Latched once the encoder is known to be unloadable, to avoid retry spam. */
   private boolean videoUnavailable;

   private final AudioRecorder audio = new AudioRecorder();

   /**
    * Returns the encoder, creating it on first use.
    *
    * @return the encoder, or {@code null} if JCodec is not on the classpath
    */
   private VideoRecorder video() {
      if (this.video == null && !this.videoUnavailable) {
         try {
            this.video = new VideoRecorder();
         } catch (Throwable t) {
            // NoClassDefFoundError included - it is an Error, not an Exception,
            // which is exactly why "catch (Exception)" would not have saved us.
            this.videoUnavailable = true;
            BlueClient.LOGGER.error(
               "Screen Recorder disabled: the JCodec encoder could not be loaded ({}). "
                  + "Check that META-INF/jars/jcodec-0.2.5.jar is both bundled AND listed "
                  + "in the \"jars\" array of fabric.mod.json.", t.toString());
         }
      }
      return this.video;
   }

   /** True when video recording is actually possible right now. */
   private boolean videoActive() {
      return this.video != null && this.video.isRecording();
   }

   /* ------------------------------------------------------------- settings */

   private final ModeSetting resolution = new ModeSetting("Resolution",
      "Output height. Lower = smaller files and much faster encoding",
      List.of("720p", "1080p", "1440p", "4K"), "1080p");

   private final NumberSetting fps = new NumberSetting("FPS",
      "Frames captured per second. 30 is the sweet spot; 60 doubles the CPU cost",
      30.0, 15.0, 60.0, 5.0);

   private final BooleanSetting recordSound = new BooleanSetting("Record sound",
      "Capture game audio. Needs a loopback input on your system (Stereo Mix / BlackHole / a Pulse monitor)", false);

   private final BooleanSetting recordMic = new BooleanSetting("Record mic",
      "Capture your microphone to a .wav next to the video", false);

   private final ModeSetting micDevice = new ModeSetting("Microphone",
      "Which input device to record from", AudioRecorder.inputDevices(), AudioRecorder.inputDevices().get(0));

   private final BooleanSetting hudInVideo = new BooleanSetting("HUD in recording",
      "Include the HUD, chat and hotbar in the video", true);

   private final BooleanSetting showHud = new BooleanSetting("Show REC panel",
      "Draw the elapsed time / file size panel while recording", true);

   private final BooleanSetting notify = new BooleanSetting("Notifications",
      "Toast when a recording starts and stops", true);

   private final NumberSetting maxMinutes = new NumberSetting("Auto-stop after",
      "Stop automatically after this many minutes. 0 = no limit",
      0.0, 0.0, 120.0, 5.0);

   public ScreenRecorder() {
      super("Screen Recorder", "Record your gameplay to an MP4", Category.MISC, 4, 90);
      this.micDevice.visibleWhen(() -> this.recordMic.get() || this.recordSound.get());
      this.addSettings(new Setting[]{
         this.resolution, this.fps, this.recordSound, this.recordMic, this.micDevice,
         this.hudInVideo, this.showHud, this.notify, this.maxMinutes
      });
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_RIGHT, 4, 4);

      /*
       * Default recording hotkey: F9.
       *
       * Owner: "the screen recorder doesnt have a recording key". The keybind
       * machinery already worked - toggling the module starts/stops a
       * recording - but NO key was ever bound by default, so there was nothing
       * to press unless you found the bind box in module settings. Only Zoom
       * (C) and the client GUI (right shift) ship defaults, so there was no
       * hint that recording could be bound at all.
       *
       * F9 is free in vanilla (F3/F5/F11 are taken, F9 is not) and does not
       * collide with either existing default. Rebindable as usual in the
       * module's settings page; saved configs override this.
       */
      this.setKeybind(GLFW_KEY_F9);
   }

   /** GLFW code for F9 - the default record/stop hotkey. */
   private static final int GLFW_KEY_F9 = 298;

   /* ===================================================================== */
   /* Start / stop                                                          */
   /* ===================================================================== */

   /**
    * Enabling the module starts a recording, disabling stops it.
    *
    * <p>That is what makes the keybind work for free: the keybind system
    * toggles modules, so one key press starts and the next stops.</p>
    */
   @Override
   protected void onEnable() {
      this.startRecording();
   }

   @Override
   protected void onDisable() {
      this.stopRecording();
   }

   private void startRecording() {
      VideoRecorder recorder = this.video();
      if (recorder == null) {
         this.toast("Recorder unavailable (encoder missing)", 0xFFFF5C5C);
         return;
      }
      if (recorder.isRecording()) {
         return;
      }
      int height = switch (this.resolution.get()) {
         case "720p" -> 720;
         case "1440p" -> 1440;
         case "4K" -> 2160;
         default -> 1080;
      };
      if (!recorder.start(height, (int) this.fps.get().doubleValue())) {
         this.toast("Couldn't start recording", 0xFFFF5C5C);
         return;
      }

      if (this.recordMic.get() || this.recordSound.get()) {
         // "Record sound" wants a loopback device; fall back to the chosen mic.
         String device = this.recordSound.get() ? AudioRecorder.findLoopbackDevice() : null;
         if (device == null) {
            device = this.micDevice.get();
         }
         Path wav = Path.of(recorder.outputFile().toString().replace(".mp4", ".wav"));
         if (!this.audio.start(wav, device) && this.notify.get()) {
            this.toast("Recording video only - no audio device", 0xFFFFB84D);
         }
      }
      this.toast("Recording started", 0xFF3CB860);
   }

   private void stopRecording() {
      if (!this.videoActive() && !this.audio.isRecording()) {
         return;
      }
      Path file = this.video != null ? this.video.outputFile() : null;
      long dropped = this.video != null ? this.video.droppedFrames() : 0L;
      this.audio.stop();
      if (this.video != null) {
         this.video.stop();
      }
      if (file != null) {
         String name = file.getFileName().toString();
         this.toast("Saved " + name + (dropped > 0 ? " (" + dropped + " frames dropped)" : ""), 0xFF3CB860);
      }
   }

   private void toast(String message, int color) {
      if (this.notify.get()) {
         BlueClient.getInstance().notificationManager().add(message, color);
      }
   }

   @Override
   public List<String> actionLabels() {
      List<String> labels = new ArrayList<>();
      labels.add("OPEN FOLDER");
      return labels;
   }

   @Override
   public void onAction(int index) {
      if (index == 0) {
         try {
            net.minecraft.util.Util.getOperatingSystem().open(
               net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir().resolve("recordings").toFile());
         } catch (Throwable t) {
            BlueClient.LOGGER.warn("Recorder: cannot open the recordings folder", t);
         }
      }
   }

   /* ===================================================================== */
   /* Per-tick housekeeping                                                 */
   /* ===================================================================== */

   @Override
   public void onTick() {
      // Auto-stop guard: a forgotten recording quietly filling the disk is the
      // most annoying way for a recorder to misbehave.
      double limit = this.maxMinutes.get();
      if (limit > 0.0 && this.videoActive()
         && this.video.elapsedMs() > (long) (limit * 60_000.0)) {
         this.setEnabled(false);
      }
   }

   /* ===================================================================== */
   /* Frame capture — called by RecorderHookMixin                           */
   /* ===================================================================== */

   /** Wall-clock time of the last captured frame, for FPS pacing. */
   private long lastCaptureMs;

   /**
    * True when the mixin should capture at this point in the frame.
    *
    * @param afterHud true if the caller is the post-HUD hook
    */
   public static boolean shouldCapture(boolean afterHud) {
      ScreenRecorder rec = active();
      return rec != null && rec.hudInVideo.get() == afterHud && rec.dueForFrame();
   }

   private boolean dueForFrame() {
      if (!this.videoActive()) {
         return false;
      }
      long intervalMs = (long) (1000.0 / Math.max(1.0, this.fps.get()));
      long now = System.currentTimeMillis();
      if (now - this.lastCaptureMs < intervalMs) {
         return false;
      }
      this.lastCaptureMs = now;
      return true;
   }

   /**
    * Reads the main framebuffer and hands the pixels to the encoder.
    *
    * <p>{@code ScreenshotRecorder.takeScreenshot} does the GPU readback for us
    * and passes a {@link NativeImage} that <b>we</b> must close. We copy the
    * pixels out immediately ({@code makePixelArray}) because the encoder runs
    * on another thread and must not touch native memory we are about to free.</p>
    */
   public static void captureFrame() {
      ScreenRecorder rec = active();
      if (rec == null || rec.video == null) {
         return;
      }
      try {
         MinecraftClient client = MinecraftClient.getInstance();
         ScreenshotRecorder.takeScreenshot(client.getFramebuffer(), image -> {
            try (NativeImage owned = image) {
               rec.video.submit(owned.makePixelArray(), owned.getWidth(), owned.getHeight());
            } catch (Throwable t) {
               BlueClient.LOGGER.warn("Recorder: frame capture failed", t);
            }
         });
      } catch (Throwable t) {
         BlueClient.LOGGER.warn("Recorder: framebuffer read failed", t);
      }
   }

   private static ScreenRecorder cached;

   private static ScreenRecorder active() {
      if (cached == null) {
         if (BlueClient.getInstance().moduleManager().byName("Screen Recorder") instanceof ScreenRecorder sr) {
            cached = sr;
         }
      }
      return cached != null && cached.isEnabled() ? cached : null;
   }

   /* ===================================================================== */
   /* HUD: elapsed time + file size                                         */
   /* ===================================================================== */

   @Override
   public void render(DrawContext context) {
      if (!this.showHud.get() || !this.videoActive()) {
         return;
      }
      this.drawTextPanel(context, this.hudText());
   }

   @Override
   public int getWidth() {
      if (!this.showHud.get() || !this.videoActive()) {
         return 0;
      }
      return RenderUtil.textWidth(this.hudText()) + 12 + 2;
   }

   private String hudText() {
      long seconds = this.video.elapsedMs() / 1000L;
      // A blinking dot is the universal "this is live" signal.
      String dot = (seconds % 2 == 0) ? "\u25CF" : "\u25CB";
      return String.format(Locale.ROOT, "%s REC  %02d:%02d  %s",
         dot, seconds / 60, seconds % 60, formatSize(this.video.fileSizeBytes()));
   }

   private static String formatSize(long bytes) {
      if (bytes < 1024L * 1024L) {
         return String.format(Locale.ROOT, "%.0f KB", bytes / 1024.0);
      }
      if (bytes < 1024L * 1024L * 1024L) {
         return String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0));
      }
      return String.format(Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
   }
}
