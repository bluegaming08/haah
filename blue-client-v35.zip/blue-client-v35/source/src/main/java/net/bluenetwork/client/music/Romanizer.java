package net.bluenetwork.client.music;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.Map;

/**
 * Converts non-Latin lyrics into Latin letters so they can actually be read.
 *
 * <h2>Why this is needed</h2>
 * LRCLIB stores Hindi lyrics in Devanagari, Russian in Cyrillic, and so on.
 * Minecraft's font has <b>no glyphs</b> for those scripts, so the lyric line
 * renders as a row of blank boxes. The lyrics were being found and displayed
 * correctly - they were simply invisible. Romanizing makes a Hindi song
 * singable for someone who cannot read the script, which is the point of
 * on-screen lyrics.
 *
 * <h2>Scope and honesty about quality</h2>
 * This is <b>transliteration, not translation</b>. "मुझको" becomes "mujhko",
 * not "to me".
 *
 * <p>Devanagari and Cyrillic are handled properly, including the parts that
 * make Devanagari hard: the inherent 'a' vowel, matras (dependent vowel signs)
 * that replace it, the virama that deletes it, and nukta consonants. Greek is
 * handled with a simple table. Other scripts fall through unchanged rather
 * than being mangled - showing the original is better than showing nonsense.</p>
 *
 * <p>The output is not a scholarly IAST romanization; it is the informal
 * spelling people actually use when they type Hindi in Latin letters, because
 * that is what is readable at a glance while a song plays.</p>
 */
public final class Romanizer {

   private Romanizer() {
   }

   /* ---- Devanagari ---------------------------------------------------- */

   /** Consonants, WITHOUT the inherent vowel - that is added by the walker. */
   private static final Map<Character, String> DEVA_CONSONANT = new HashMap<>();
   /** Independent vowels (word-initial forms). */
   private static final Map<Character, String> DEVA_VOWEL = new HashMap<>();
   /** Dependent vowel signs (matras) that replace the inherent 'a'. */
   private static final Map<Character, String> DEVA_MATRA = new HashMap<>();
   /** Consonant + nukta pairs that do not compose to a single character. */
   private static final Map<String, String> DEVA_NUKTA = new HashMap<>();

   static {
      String[][] cons = {
         {"क", "k"}, {"ख", "kh"}, {"ग", "g"}, {"घ", "gh"}, {"ङ", "ng"},
         {"च", "ch"}, {"छ", "chh"}, {"ज", "j"}, {"झ", "jh"}, {"ञ", "ny"},
         {"ट", "t"}, {"ठ", "th"}, {"ड", "d"}, {"ढ", "dh"}, {"ण", "n"},
         {"त", "t"}, {"थ", "th"}, {"द", "d"}, {"ध", "dh"}, {"न", "n"},
         {"प", "p"}, {"फ", "ph"}, {"ब", "b"}, {"भ", "bh"}, {"म", "m"},
         {"य", "y"}, {"र", "r"}, {"ल", "l"}, {"व", "v"},
         {"श", "sh"}, {"ष", "sh"}, {"स", "s"}, {"ह", "h"},
         {"ळ", "l"}, {"क़", "q"}, {"ख़", "kh"}, {"ग़", "gh"}, {"ज़", "z"},
         {"ड़", "r"}, {"ढ़", "rh"}, {"फ़", "f"}, {"य़", "y"},
      };
      for (String[] pair : cons) {
         // Nukta rows are base+U+093C, i.e. TWO chars. Keying them by
         // charAt(0) stored them under the BASE consonant and silently
         // overwrote it - which is why every plain क came out as "q".
         String key = Normalizer.normalize(pair[0], Normalizer.Form.NFC);
         if (key.length() == 1) {
            DEVA_CONSONANT.put(key.charAt(0), pair[1]);
         } else {
            DEVA_NUKTA.put(pair[0], pair[1]);
         }
      }

      String[][] vowels = {
         {"अ", "a"}, {"आ", "aa"}, {"इ", "i"}, {"ई", "ee"}, {"उ", "u"},
         {"ऊ", "oo"}, {"ऋ", "ri"}, {"ए", "e"}, {"ऐ", "ai"}, {"ओ", "o"},
         {"औ", "au"}, {"ऑ", "o"}, {"ऍ", "e"},
      };
      for (String[] pair : vowels) {
         DEVA_VOWEL.put(pair[0].charAt(0), pair[1]);
      }

      String[][] matras = {
         {"ा", "aa"}, {"ि", "i"}, {"ी", "ee"}, {"ु", "u"}, {"ू", "oo"},
         {"ृ", "ri"}, {"े", "e"}, {"ै", "ai"}, {"ो", "o"}, {"ौ", "au"},
         {"ॉ", "o"}, {"ॅ", "e"},
      };
      for (String[] pair : matras) {
         DEVA_MATRA.put(pair[0].charAt(0), pair[1]);
      }
   }

   private static final char VIRAMA = '\u094D';      // halant: kills the vowel
   private static final char NUKTA = '\u093C';
   private static final char ANUSVARA = '\u0902';    // nasal
   private static final char CHANDRABINDU = '\u0901';
   private static final char VISARGA = '\u0903';
   private static final char AVAGRAHA = '\u093D';

   /**
    * Romanizes a Devanagari string.
    *
    * <p>The hard part is the inherent vowel: a bare consonant carries an 'a'
    * unless a matra replaces it or a virama deletes it. Walking the string and
    * looking ahead one character is what makes "मुझको" come out as "mujhko"
    * rather than "mujhako".</p>
    */
   public static String devanagari(String in) {
      StringBuilder out = new StringBuilder(in.length() * 2);
      int i = 0;
      int n = in.length();
      // Consonants emitted in the CURRENT word. Schwa deletion must not apply
      // to the first syllable or "bataae" collapses to the unreadable "btaae".
      int syllables = 0;

      while (i < n) {
         char c = in.charAt(i);
         if (!isDevanagari(c)) {
            syllables = 0;
         }

         // Nukta modifies the PREVIOUS consonant; handled by lookahead below.
         if (c == NUKTA) {
            i++;
            continue;
         }
         if (c == ANUSVARA || c == CHANDRABINDU) {
            out.append('n');
            i++;
            continue;
         }
         if (c == VISARGA) {
            out.append('h');
            i++;
            continue;
         }
         if (c == AVAGRAHA) {
            i++;
            continue;
         }

         String vowel = DEVA_VOWEL.get(c);
         if (vowel != null) {
            out.append(vowel);
            syllables++;
            i++;
            continue;
         }

         String cons = null;
         // A consonant followed by a nukta may have a distinct precomposed
         // form (क + nukta = क़ = "q"). Only consult it when a nukta is
         // actually present AND the precomposed character really differs -
         // otherwise a plain क would wrongly pick up the nukta reading.
         if (i + 1 < n && in.charAt(i + 1) == NUKTA) {
            cons = DEVA_NUKTA.get(in.substring(i, i + 2));
            if (cons == null) {
               String composed = Normalizer.normalize(in.substring(i, i + 2),
                  Normalizer.Form.NFC);
               if (composed.length() == 1 && composed.charAt(0) != c) {
                  cons = DEVA_CONSONANT.get(composed.charAt(0));
               }
            }
         }
         if (cons == null) {
            cons = DEVA_CONSONANT.get(c);
         }

         if (cons != null) {
            out.append(cons);
            i++;
            if (i < n && in.charAt(i) == NUKTA) {
               i++;
            }

            // What follows decides the vowel.
            if (i < n) {
               char next = in.charAt(i);
               String matra = DEVA_MATRA.get(next);
               if (matra != null) {
                  out.append(matra);
                  // A syllable is completed by its VOWEL, not by its
                  // consonant. Counting here is what lets मुझको delete the
                  // schwa on झ ("mujhko") while इतना keeps ता ("itnaa").
                  syllables++;
                  i++;
                  continue;
               }
               if (next == VIRAMA) {
                  // Explicitly no vowel - a conjunct.
                  i++;
                  continue;
               }
            }
            // The inherent vowel. Hindi deletes it far more often than a
            // naive transliterator expects - not just word-finally ("राम" is
            // "ram") but mid-word too ("मुझको" is "mujhko", not "mujhako").
            //
            // The rule used here: emit 'a' only when the syllable NEEDS it to
            // stay pronounceable, i.e. when the next consonant is followed by
            // its own vowel sign. That produces the informal spelling people
            // actually type, which is the goal - not scholarly IAST.
            boolean endOfWord = i >= n || !isDevanagari(in.charAt(i));
            if (!endOfWord && !schwaDeleted(in, i, syllables)) {
               out.append('a');
            }
            // An inherent-vowel syllable also counts once resolved.
            syllables++;
            continue;
         }

         out.append(c);
         i++;
      }
      return out.toString();
   }

   /**
    * Decides whether the inherent 'a' after the consonant ending at
    * {@code i} should be dropped.
    *
    * <p>{@code i} points at the character AFTER the consonant just emitted.
    * The schwa is deleted when that next consonant carries its own vowel,
    * because the syllable is then already pronounceable without it - which is
    * what turns "mujhako" into "mujhko".</p>
    */
   private static boolean schwaDeleted(String in, int i, int syllables) {
      if (i >= in.length()) {
         return true;
      }
      // Never delete from the opening syllable of a word: "bataae" must not
      // collapse to "btaae". From the second syllable on, deletion is what
      // produces the natural spelling ("mujhko", not "mujhako").
      //
      // The exception is a CVCV word whose first consonant already took a
      // matra - there the second schwa is genuinely pronounced ("banaane"),
      // so only delete when the syllable before us was a bare consonant.
      if (syllables < 1) {
         return false;
      }
      char next = in.charAt(i);
      if (!DEVA_CONSONANT.containsKey(next)) {
         return false;
      }
      // Look past the next consonant (and any nukta) at what follows it.
      int j = i + 1;
      if (j < in.length() && in.charAt(j) == NUKTA) {
         j++;
      }
      if (j >= in.length()) {
         // "...CC" at the end: keep the vowel so it stays sayable.
         return false;
      }
      char after = in.charAt(j);
      // Delete only when the NEXT consonant carries its own vowel: the
      // syllable is then pronounceable without ours. Combined with the
      // first-syllable guard this reproduces ordinary Hinglish spelling -
      // mujhko, tujhse, itnaa - while leaving bataae and banaane intact.
      return DEVA_MATRA.containsKey(after);
   }

   private static boolean isDevanagari(char c) {
      return c >= '\u0900' && c <= '\u097F';
   }

   /* ---- Cyrillic ------------------------------------------------------- */

   private static final Map<Character, String> CYRILLIC = new HashMap<>();

   static {
      String[][] pairs = {
         {"а", "a"}, {"б", "b"}, {"в", "v"}, {"г", "g"}, {"д", "d"},
         {"е", "e"}, {"ё", "yo"}, {"ж", "zh"}, {"з", "z"}, {"и", "i"},
         {"й", "y"}, {"к", "k"}, {"л", "l"}, {"м", "m"}, {"н", "n"},
         {"о", "o"}, {"п", "p"}, {"р", "r"}, {"с", "s"}, {"т", "t"},
         {"у", "u"}, {"ф", "f"}, {"х", "kh"}, {"ц", "ts"}, {"ч", "ch"},
         {"ш", "sh"}, {"щ", "shch"}, {"ъ", ""}, {"ы", "y"}, {"ь", ""},
         {"э", "e"}, {"ю", "yu"}, {"я", "ya"},
      };
      for (String[] pair : pairs) {
         char lower = pair[0].charAt(0);
         CYRILLIC.put(lower, pair[1]);
         CYRILLIC.put(Character.toUpperCase(lower), capitalize(pair[1]));
      }
   }

   private static String capitalize(String s) {
      return s.isEmpty() ? s
         : Character.toUpperCase(s.charAt(0)) + s.substring(1);
   }

   public static String cyrillic(String in) {
      StringBuilder out = new StringBuilder(in.length() + 8);
      for (int i = 0; i < in.length(); i++) {
         String mapped = CYRILLIC.get(in.charAt(i));
         out.append(mapped == null ? String.valueOf(in.charAt(i)) : mapped);
      }
      return out.toString();
   }

   /* ---- Greek ---------------------------------------------------------- */

   private static final Map<Character, String> GREEK = new HashMap<>();

   static {
      String[][] pairs = {
         {"α", "a"}, {"β", "v"}, {"γ", "g"}, {"δ", "d"}, {"ε", "e"},
         {"ζ", "z"}, {"η", "i"}, {"θ", "th"}, {"ι", "i"}, {"κ", "k"},
         {"λ", "l"}, {"μ", "m"}, {"ν", "n"}, {"ξ", "x"}, {"ο", "o"},
         {"π", "p"}, {"ρ", "r"}, {"σ", "s"}, {"ς", "s"}, {"τ", "t"},
         {"υ", "y"}, {"φ", "f"}, {"χ", "ch"}, {"ψ", "ps"}, {"ω", "o"},
      };
      for (String[] pair : pairs) {
         char lower = pair[0].charAt(0);
         GREEK.put(lower, pair[1]);
         GREEK.put(Character.toUpperCase(lower), capitalize(pair[1]));
      }
   }

   public static String greek(String in) {
      StringBuilder out = new StringBuilder(in.length() + 4);
      for (int i = 0; i < in.length(); i++) {
         String mapped = GREEK.get(in.charAt(i));
         out.append(mapped == null ? String.valueOf(in.charAt(i)) : mapped);
      }
      return out.toString();
   }

   /* ---- entry point ---------------------------------------------------- */

   /**
    * Romanizes whatever script the text is in, if supported.
    *
    * <p>Unsupported scripts are returned <b>unchanged</b>. Mangling Japanese
    * into gibberish would be worse than leaving it alone - and the player can
    * always turn the setting off.</p>
    */
   public static String romanize(String text) {
      if (text == null || text.isEmpty()) {
         return text;
      }
      boolean deva = false;
      boolean cyr = false;
      boolean grk = false;
      for (int i = 0; i < text.length(); i++) {
         char c = text.charAt(i);
         if (c >= '\u0900' && c <= '\u097F') {
            deva = true;
         } else if (c >= '\u0400' && c <= '\u04FF') {
            cyr = true;
         } else if (c >= '\u0370' && c <= '\u03FF') {
            grk = true;
         }
      }
      String out = text;
      if (deva) {
         out = devanagari(out);
      }
      if (cyr) {
         out = cyrillic(out);
      }
      if (grk) {
         out = greek(out);
      }
      return out;
   }

   /** True when {@link #romanize} would change this text. */
   public static boolean canRomanize(String text) {
      if (text == null) {
         return false;
      }
      for (int i = 0; i < text.length(); i++) {
         char c = text.charAt(i);
         if ((c >= '\u0900' && c <= '\u097F')
            || (c >= '\u0400' && c <= '\u04FF')
            || (c >= '\u0370' && c <= '\u03FF')) {
            return true;
         }
      }
      return false;
   }
}
