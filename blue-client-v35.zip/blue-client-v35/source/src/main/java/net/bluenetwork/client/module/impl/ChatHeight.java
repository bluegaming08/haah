package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

public class ChatHeight extends Module {
   private static final double VANILLA_FOCUSED = 0.5;
   private static final double VANILLA_UNFOCUSED = 0.3;

   public ChatHeight() {
      super("Chat Height", "Show more chat history at once", Category.MISC);
   }

   @Override
   protected void onEnable() {
      this.apply(true);
   }

   @Override
   protected void onDisable() {
      this.apply(false);
   }

   private void apply(boolean tall) {
      try {
         GameOptions options = MinecraftClient.getInstance().options;
         SimpleOption<Double> focused = options.getChatHeightFocused();
         SimpleOption<Double> unfocused = options.getChatHeightUnfocused();
         focused.setValue(tall ? 1.0 : 0.5);
         unfocused.setValue(tall ? 0.5 : 0.3);
      } catch (Throwable var5) {
      }
   }
}
