package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;

/**
 * Nether Coords (bonus HUD) — always know where a portal will land: while in
 * the Overworld it shows the Nether equivalent (÷8), while in the Nether it
 * shows the Overworld equivalent (×8). Pure arithmetic on your position.
 */
public class NetherCoords extends HudModule {
   private final ColorSetting overworldColor = new ColorSetting("Overworld color", "Shown while in the Overworld", 0xFF7CFF9B);
   private final ColorSetting netherColor = new ColorSetting("Nether color", "Shown while in the Nether", 0xFFFF8A5C);

   public NetherCoords() {
      super("Nether Coords", "Nether <-> Overworld coordinate conversion", Category.HUD, 4, 4);
      this.addSettings(new net.bluenetwork.client.setting.Setting[]{this.overworldColor, this.netherColor});
      this.setAnchorAndOffsets(HudModule.Anchor.TOP_LEFT, 4, 48);
   }

   private String text() {
      MinecraftClient mc = MinecraftClient.getInstance();
      PlayerEntity p = mc.player;
      if (p == null || mc.world == null) {
         return "Nether --";
      }
      RegistryKey<World> dim = mc.world.getRegistryKey();
      int x = (int) Math.floor(p.getX());
      int y = (int) Math.floor(p.getY());
      int z = (int) Math.floor(p.getZ());
      if (dim == World.NETHER) {
         return "Overworld " + (x * 8) + " " + y + " " + (z * 8);
      }
      if (dim == World.OVERWORLD) {
         int nx = (int) Math.floor(x / 8.0);
         int nz = (int) Math.floor(z / 8.0);
         return "Nether " + nx + " " + y + " " + nz;
      }
      return "Nether --";
   }

   private int resolveColor() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null) {
         return 0xFFFFFFFF;
      }
      boolean nether = mc.world.getRegistryKey() == World.NETHER;
      return nether
         ? this.netherColor.currentRgb(System.currentTimeMillis())
         : this.overworldColor.currentRgb(System.currentTimeMillis());
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         return;
      }
      this.drawPanel(context);
      RenderUtil.drawText(context, this.text(), this.x + 6 + 2, this.y + 6, this.resolveColor());
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth(this.text()) + 12 + 2;
   }

   @Override
   public int getHeight() {
      return 21;
   }
}
