package net.bluenetwork.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

/**
 * Central knob for UI click sounds (v3 catalogue D3 "UI Sound Pack").
 * {@link net.bluenetwork.client.render.RenderUtil#clickSound()} and
 * {@link Sounds#click()} both route through here, so one setting changes every
 * click in the client. Defaults (pitch 1.0, unmuted) reproduce the legacy sound
 * exactly; the module merely flips these values.
 */
public final class UiSoundController {
   private static volatile float clickPitch = 1.0F;
   private static volatile boolean muted = false;

   private UiSoundController() {
   }

   public static void apply(String mode) {
      if (mode == null) {
         clickPitch = 1.0F;
         muted = false;
      } else {
         switch (mode) {
            case "Soft" -> {
               clickPitch = 0.72F;
               muted = false;
            }
            case "Off" -> {
               clickPitch = 1.0F;
               muted = true;
            }
            default -> {
               clickPitch = 1.0F;
               muted = false;
            }
         }
      }
   }

   public static boolean muted() {
      return muted;
   }

   public static float clickPitch() {
      return clickPitch;
   }

   /** The one play path every UI click uses. */
   public static void playClick() {
      if (muted) {
         return;
      }
      ui(SoundEvents.UI_BUTTON_CLICK.value(), clickPitch);
   }

   public static void ui(SoundEvent event, float pitch) {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.getSoundManager() != null) {
            mc.getSoundManager().play(PositionedSoundInstance.ui(event, pitch));
         }
      } catch (Throwable ignored) {
      }
   }
}
