package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.biome.Biome;

/**
 * Weather Changer — force clear / rain / thunder / snow, client-side.
 *
 * <h2>Owner spec</h2>
 * <pre>
 *   add a weather changer with presets (clear, rain, thunder, snow) and they
 *   must work even if i have a barrier above my head
 * </pre>
 *
 * <h2>Two halves</h2>
 * <ol>
 *   <li><b>Sky / lighting</b> — handled right here. {@code World} exposes
 *       {@code setRainGradient(float)} and {@code setThunderGradient(float)};
 *       every renderer (sky colour, fog, light level, sound) reads those. We
 *       write them each tick because the client interpolates them back toward
 *       the server's value otherwise.</li>
 *   <li><b>The falling particles</b> — handled by
 *       {@code WeatherRenderingMixin}, because vanilla decides where and
 *       whether to spawn a rain/snow column inside
 *       {@code WeatherRendering.buildPrecipitationPieces}, which we cannot
 *       reach from a module.</li>
 * </ol>
 *
 * <h2>Why a barrier above your head normally kills the rain</h2>
 * Vanilla places each precipitation column at
 * {@code World.getTopY(MOTION_BLOCKING, x, z)} — i.e. on top of the highest
 * solid block. Stand under a roof (or a barrier) and the rain is drawn on the
 * roof, above you, where you cannot see it. It also calls the private
 * {@code getPrecipitationAt}, which returns {@code NONE} in a dry biome and
 * skips the column entirely.
 *
 * <p>"Ignore roof" makes the mixin (a) force the precipitation type and (b)
 * clamp the column top to just above the camera, so the weather renders around
 * you regardless of what is overhead.</p>
 *
 * <h2>Anticheat</h2>
 * Nothing is sent to the server, and no movement, timing or interaction
 * behaviour changes — this is purely what your own client draws.
 */
public class WeatherChanger extends Module {

   private final ModeSetting mode = new ModeSetting("Weather", "Weather to force",
      List.of("CLEAR", "RAIN", "THUNDER", "SNOW"), "CLEAR");

   private final NumberSetting intensity = new NumberSetting("Intensity",
      "How heavy the weather looks, in percent", 100.0, 0.0, 100.0, 5.0);

   private final BooleanSetting ignoreRoof = new BooleanSetting("Ignore roof",
      "Draw the weather around you even with blocks (or a barrier) above your head", true);

   private final BooleanSetting weatherSound = new BooleanSetting("Weather sound",
      "Let the rain / thunder ambience play", true);

   public WeatherChanger() {
      super("Weather Changer", "Force clear, rain, thunder or snow on your client", Category.RENDER);
      this.intensity.visibleWhen(() -> !"CLEAR".equals(this.mode.get()));
      this.ignoreRoof.visibleWhen(() -> !"CLEAR".equals(this.mode.get()));
      this.weatherSound.visibleWhen(() -> !"CLEAR".equals(this.mode.get()));
      this.addSettings(new Setting[]{this.mode, this.intensity, this.ignoreRoof, this.weatherSound});
   }

   @Override
   protected void onDisable() {
      // Snap back to whatever the server last told us. The client re-syncs on
      // the next weather packet anyway; this just avoids a stuck sky until then.
      ClientWorld world = MinecraftClient.getInstance().world;
      if (world != null) {
         world.setRainGradient(world.isRaining() ? 1.0F : 0.0F);
         world.setThunderGradient(world.isThundering() ? 1.0F : 0.0F);
      }
   }

   @Override
   public void onTick() {
      ClientWorld world = MinecraftClient.getInstance().world;
      if (world == null) {
         return;
      }
      float strength = (float) (this.intensity.get() / 100.0);
      switch (this.mode.get()) {
         case "RAIN", "SNOW" -> {
            world.setRainGradient(strength);
            world.setThunderGradient(0.0F);
         }
         case "THUNDER" -> {
            world.setRainGradient(strength);
            world.setThunderGradient(strength);
         }
         default -> {
            world.setRainGradient(0.0F);
            world.setThunderGradient(0.0F);
         }
      }
   }

   /* ===================================================================== */
   /* Static bridge for WeatherRenderingMixin                               */
   /* ===================================================================== */
   /*
    * The mixin runs on the render thread every frame and must not allocate or
    * walk the module list. These little statics are the whole contract; they
    * resolve the module once and cache it.
    */

   private static WeatherChanger cached;

   private static WeatherChanger active() {
      if (cached == null) {
         Module module = BlueClient.getInstance().moduleManager().byName("Weather Changer");
         if (module instanceof WeatherChanger wc) {
            cached = wc;
         }
      }
      return cached != null && cached.isEnabled() ? cached : null;
   }

   /**
    * The precipitation type the mixin should force, or {@code null} to leave
    * vanilla's per-biome answer alone.
    */
   public static Biome.Precipitation forcedPrecipitation() {
      WeatherChanger wc = active();
      if (wc == null) {
         return null;
      }
      return switch (wc.mode.get()) {
         case "SNOW" -> Biome.Precipitation.SNOW;
         case "RAIN", "THUNDER" -> Biome.Precipitation.RAIN;
         default -> Biome.Precipitation.NONE;
      };
   }

   /** True when precipitation columns should start just above the camera. */
   public static boolean ignoreRoofActive() {
      WeatherChanger wc = active();
      return wc != null && wc.ignoreRoof.get() && !"CLEAR".equals(wc.mode.get());
   }

   /** True while weather ambience should be suppressed. */
   public static boolean muteWeatherSound() {
      WeatherChanger wc = active();
      return wc != null && !wc.weatherSound.get();
   }
}
