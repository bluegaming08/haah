package net.bluenetwork.client.render;

import net.bluenetwork.client.module.impl.Hitboxes;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShapes;

/**
 * Draws the {@link Hitboxes} module's entity outlines.
 *
 * <p>Called from {@code WorldRendererMixin} at the tail of
 * {@code renderTargetBlockOutline}, which is the one spot in world rendering
 * that already provides a camera-relative {@link MatrixStack}, an
 * {@code Immediate} vertex provider and the camera position.</p>
 *
 * <h2>Coordinate space</h2>
 * The matrix stack there is relative to the camera, so every box must be
 * translated by {@code entityPos - cameraPos}. {@code Box} coordinates are
 * absolute world space, so we subtract the camera position when passing the
 * origin to {@link VertexRendering#drawOutline}.
 *
 * <h2>Why interpolate the position</h2>
 * {@code entity.getBoundingBox()} is the box at the last <i>tick</i>. Drawing
 * that directly makes hitboxes visibly stutter behind fast-moving players at
 * high frame rates, so the box is shifted by the entity's interpolated
 * (tick-delta) position — the same thing the entity renderer does for the
 * model itself, which keeps box and player locked together.
 *
 * <h2>Performance</h2>
 * Two deliberate choices, because this runs every frame on an Intel HD 615:
 * <ul>
 *   <li>Settings are read <b>once</b> into a {@link Hitboxes.Snapshot} rather
 *       than looked up per entity.</li>
 *   <li>Entities come from a <b>bounded box query</b>
 *       ({@code getOtherEntities}), so the cost scales with the configured
 *       range instead of with the number of entities in the whole world. The
 *       old version walked {@code world.getEntities()} and then threw most of
 *       them away.</li>
 * </ul>
 */
public final class HitboxRenderer {

   private HitboxRenderer() {
   }

   /** Draws a box for every entity the module accepts. Never throws. */
   public static void render(VertexConsumerProvider.Immediate immediate,
                             MatrixStack matrices,
                             WorldRenderState state) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.world == null || mc.player == null || state == null) {
         return;
      }
      if (state.cameraRenderState == null) {
         return;
      }
      // One lookup per frame instead of one per entity; null means "off".
      Hitboxes.Snapshot cfg = Hitboxes.snapshot();
      if (cfg == null) {
         return;
      }
      double range = Hitboxes.range();
      if (range <= 0.0) {
         return;
      }

      var cameraPos = state.cameraRenderState.pos;
      float tickDelta = mc.getRenderTickCounter().getTickProgress(false);

      // linesTranslucent() ignores depth ordering against itself, which is what
      // "see through walls" wants; lines() respects the depth buffer.
      RenderLayer layer = cfg.seeThrough()
         ? RenderLayers.linesTranslucent()
         : RenderLayers.lines();
      var buffer = immediate.getBuffer(layer);

      // Broad phase: only entities inside the configured radius are considered.
      Box searchBox = mc.player.getBoundingBox().expand(range);
      var candidates = mc.world.getOtherEntities(
         cfg.showSelf() ? null : mc.player,
         searchBox,
         entity -> cfg.shouldDraw(entity, mc.player));

      boolean drewAny = false;
      for (Entity entity : candidates) {
         try {
            Box box = entity.getBoundingBox();

            // Shift the tick-aligned box onto the interpolated render position
            // so it does not lag behind a sprinting player.
            double ix = lerp(tickDelta, entity.lastX, entity.getX()) - entity.getX();
            double iy = lerp(tickDelta, entity.lastY, entity.getY()) - entity.getY();
            double iz = lerp(tickDelta, entity.lastZ, entity.getZ()) - entity.getZ();

            VertexRendering.drawOutline(
               matrices,
               buffer,
               VoxelShapes.cuboid(box.offset(-box.minX, -box.minY, -box.minZ)),
               box.minX + ix - cameraPos.x,
               box.minY + iy - cameraPos.y,
               box.minZ + iz - cameraPos.z,
               cfg.colorFor(entity),
               cfg.lineWidth());
            drewAny = true;
         } catch (Throwable ignored) {
            // One bad entity must not stop the rest from drawing.
         }
      }

      // Only flush if something was actually queued - draining an empty layer
      // every frame is pure overhead when the module is on but nobody is near.
      if (drewAny) {
         immediate.draw(layer);
      }
   }

   private static double lerp(float delta, double from, double to) {
      return from + (to - from) * delta;
   }
}
