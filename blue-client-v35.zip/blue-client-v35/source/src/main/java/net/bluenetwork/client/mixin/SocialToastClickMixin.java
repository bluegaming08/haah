package net.bluenetwork.client.mixin;

import net.bluenetwork.client.notification.SocialToasts;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.ParentElement;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Lets the clickable social toasts consume a click before the screen sees it.
 *
 * <h2>Why {@code ParentElement} and not {@code Screen}</h2>
 * {@code Screen} does <b>not</b> declare {@code mouseClicked} - it inherits
 * the default method from {@code ParentElement}. v11 learned this the hard
 * way: it injected into {@code Screen.mouseClicked}, the hook silently never
 * bound, and the pause-menu buttons "didn't work" for an entire release.
 * Verified with javap against 1.21.11 before writing this: the method is
 * declared on {@code ParentElement} with a real body, so it is a valid target.
 *
 * <h2>Why HEAD and cancellable</h2>
 * A toast floats above everything. If the player clicks one, that click must
 * NOT also fall through to whatever sits underneath. Running at HEAD and
 * cancelling when a toast was hit gives the toast first refusal without
 * disturbing any other click.
 *
 * <p>The guard is deliberately narrow: {@code isOver} is false unless a toast
 * is literally under the cursor, so in the overwhelmingly common case this
 * mixin costs one bounding-box test and gets out of the way.</p>
 */
@Mixin(ParentElement.class)
public interface SocialToastClickMixin {

   @Inject(
      method = "mouseClicked(Lnet/minecraft/client/gui/Click;Z)Z",
      at = @At("HEAD"),
      cancellable = true
   )
   private void blueclient$socialToastClick(Click click, boolean doubled,
                                            CallbackInfoReturnable<Boolean> cir) {
      // Only screens draw the toasts; widgets are parents too and must be
      // left alone, or a click inside a list would be stolen.
      if (!((Object) this instanceof Screen)) {
         return;
      }
      if (!SocialToasts.isOver(click.x(), click.y())) {
         return;
      }
      if (SocialToasts.click(click.x(), click.y())) {
         cir.setReturnValue(true);
      }
   }
}
