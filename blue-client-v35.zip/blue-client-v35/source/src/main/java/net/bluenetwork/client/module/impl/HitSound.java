package net.bluenetwork.client.module.impl;

import java.util.List;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HitReactor;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvents;

/**
 * Hit Sound - short local click on every successful attack so hits are
 * audible as well as visible. Played only for you, never sent to the server.
 */
public class HitSound extends Module implements HitReactor {
   private final ModeSetting sound = new ModeSetting("Sound", "Marker sound character",
      List.of("CLICK", "TICK", "POP"), "CLICK");
   private final NumberSetting volume = new NumberSetting("Volume", "Hit sound volume %", 60.0, 0.0, 100.0, 5.0);

   public HitSound() {
      super("Hit Sound", "Plays a short click when your attack lands", Category.COMBAT);
   }

   @Override
   public void onHit(PlayerEntity attacker, Entity target) {
      float pitch;
      net.minecraft.sound.SoundEvent sound;
      switch (this.sound.get()) {
         case "TICK" -> {
            sound = SoundEvents.ENTITY_ARROW_HIT_PLAYER;
            pitch = 1.2F;
         }
         case "POP" -> {
            sound = SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP;
            pitch = 0.9F;
         }
         default -> {
            sound = SoundEvents.ENTITY_ARROW_HIT_PLAYER;
            pitch = 1.8F;
         }
      }
      attacker.playSound(sound, this.volume.get().floatValue() / 100.0F, pitch);
   }
}
