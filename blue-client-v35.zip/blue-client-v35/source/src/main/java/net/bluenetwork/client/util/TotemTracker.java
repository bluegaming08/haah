package net.bluenetwork.client.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Tracks totem-of-undying pops, for you and for whoever you are fighting.
 *
 * <h2>How a pop is detected</h2>
 * When a totem saves an entity the server broadcasts an
 * {@code EntityStatusS2CPacket} with status <b>35</b> — the same signal that
 * plays the totem animation and particles. {@code EntityStatusMixin} forwards
 * that here. This is a read of a packet the client already receives and acts
 * on; nothing extra is sent, so it is not anticheat-flaggable.
 *
 * <h2>How the opponent is chosen</h2>
 * "Who you are fighting" is whoever you most recently hit or who most recently
 * hit you, within {@link #COMBAT_TIMEOUT_MS}. If there has been no such
 * exchange, it falls back to the player under your crosshair, so the panel
 * still shows something useful when you are lining someone up. Combat events
 * are reported by {@code TotemCombatMixin}.
 *
 * <p>Everything is per-session and cleared on disconnect.</p>
 */
public final class TotemTracker {

   /** How long after a hit a player still counts as "who you are fighting". */
   private static final long COMBAT_TIMEOUT_MS = 15_000L;

   private static final Map<UUID, Integer> pops = new ConcurrentHashMap<>();

   private static volatile UUID opponent = null;
   private static volatile long lastCombatMs = 0L;

   private TotemTracker() {
   }

   /** Called by the mixin when entity status 35 (totem used) arrives. */
   public static void onTotemPop(Entity entity) {
      if (entity == null) {
         return;
      }
      pops.merge(entity.getUuid(), 1, Integer::sum);
   }

   /**
    * Called by the mixin whenever you attack someone or take damage from a
    * player, to keep track of who the current fight is against.
    */
   public static void onCombatWith(Entity other) {
      if (other instanceof PlayerEntity player) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null && player.getUuid().equals(mc.player.getUuid())) {
            return;                       // ignore self-damage
         }
         opponent = player.getUuid();
         lastCombatMs = System.currentTimeMillis();
      }
   }

   /** @return how many totems this entity has popped this session. */
   public static int popsOf(UUID id) {
      return id == null ? 0 : pops.getOrDefault(id, 0);
   }

   /** @return your own pop count. */
   public static int ownPops() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc == null || mc.player == null ? 0 : popsOf(mc.player.getUuid());
   }

   /**
    * The player currently considered your opponent, or {@code null}.
    *
    * <p>Recent combat wins; otherwise whoever is under the crosshair.</p>
    */
   public static PlayerEntity opponent() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.world == null || mc.player == null) {
         return null;
      }
      UUID id = opponent;
      if (id != null && System.currentTimeMillis() - lastCombatMs <= COMBAT_TIMEOUT_MS) {
         for (PlayerEntity player : mc.world.getPlayers()) {
            if (player.getUuid().equals(id) && player != mc.player && player.isAlive()) {
               return player;
            }
         }
      }
      // Fallback: whoever you are looking at.
      if (mc.targetedEntity instanceof PlayerEntity looked && looked != mc.player) {
         return looked;
      }
      if (mc.crosshairTarget instanceof EntityHitResult hit
            && hit.getEntity() instanceof PlayerEntity looked2 && looked2 != mc.player) {
         return looked2;
      }
      return null;
   }

   /**
    * Totems visibly held by another player.
    *
    * <p><b>Only their hands are counted, and that is a hard limit, not an
    * oversight:</b> the client is never told what is in another player's
    * inventory. Anything claiming a full count would have to be guessing. Main
    * hand and offhand are genuinely synced to all clients, so that is what is
    * shown.</p>
    */
   public static int visibleTotems(PlayerEntity player) {
      if (player == null) {
         return 0;
      }
      int total = 0;
      ItemStack main = player.getMainHandStack();
      if (!main.isEmpty() && main.isOf(Items.TOTEM_OF_UNDYING)) {
         total += main.getCount();
      }
      ItemStack off = player.getOffHandStack();
      if (!off.isEmpty() && off.isOf(Items.TOTEM_OF_UNDYING)) {
         total += off.getCount();
      }
      return total;
   }

   /** @return true if this entity is holding a totem in either hand. */
   public static boolean isHoldingTotem(LivingEntity entity) {
      return entity != null
         && (entity.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)
            || entity.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING));
   }

   /** Clears all state. Called on world change / disconnect. */
   public static void reset() {
      pops.clear();
      opponent = null;
      lastCombatMs = 0L;
   }
}
