package net.bluenetwork.client.mixin;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.module.ScreenOverlay;
import net.bluenetwork.client.module.impl.CustomCrosshair;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public abstract class InGameHudMixin {
   @Inject(
      method = {"renderCrosshair"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void blueclient$customCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      CustomCrosshair crosshair = find();
      if (crosshair == null || !crosshair.isEnabled()) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || !mc.options.getPerspective().isFirstPerson()) {
         return;
      }
      ci.cancel();
      try {
         // Drawing lives in CrosshairRenderer so the settings-screen preview
         // and the real crosshair are guaranteed to be identical.
         int cx = mc.getWindow().getScaledWidth() / 2;
         int cy = mc.getWindow().getScaledHeight() / 2;
         crosshair.draw(context, cx, cy, true);
      } catch (Throwable ignored) {
         // A crosshair bug must never take the whole HUD down.
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("TAIL")},
      require = 0
   )
   private void blueclient$screenOverlays(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         if (module instanceof ScreenOverlay overlay && module.isEnabled()) {
            try {
               overlay.renderOverlay(context);
            } catch (Throwable ignored) {
            }
         }
      }
   }

   private static CustomCrosshair find() {
      for (Module module : BlueClient.getInstance().moduleManager().getModules()) {
         if (module instanceof CustomCrosshair crosshair) {
            return crosshair;
         }
      }

      return null;
   }
}
