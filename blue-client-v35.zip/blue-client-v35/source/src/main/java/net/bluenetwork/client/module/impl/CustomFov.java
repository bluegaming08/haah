package net.bluenetwork.client.module.impl;

import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.util.OptionGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Items;

/**
 * FOV Changer — a static FOV pin plus smooth dynamic FOV.
 *
 * <p>This was "Custom FOV" (a fixed value and nothing else) until v0.24.9, when
 * the owner asked for dynamic FOV "like when aiming with a bow, sprinting,
 * flying". Rather than ship a second module fighting over the same option, the
 * existing one was upgraded — two modules both writing FOV would clobber each
 * other.</p>
 *
 * <h2>How the two halves work, and why they are different</h2>
 * <ol>
 *   <li><b>Base FOV</b> is applied through {@link OptionGuard} to the vanilla
 *       FOV option, so it survives alongside Zoom and is restored on disable.
 *       The option is an <b>int</b>, which is fine for a value you set once.</li>
 *   <li><b>Dynamic FOV</b> can <b>not</b> use that option: stepping an integer
 *       every frame looks visibly steppy. Instead
 *       {@code GameRendererFovMixin} multiplies the renderer's own float FOV by
 *       {@link #dynamicMultiplier()}, giving smooth sub-degree motion.</li>
 * </ol>
 *
 * <p>Vanilla already nudges FOV when you sprint or pull a bow (the "FOV
 * Effects" slider). This module drives that effect itself so each trigger can
 * be tuned separately, and so it keeps working for players who turned the
 * vanilla slider off.</p>
 */
public class CustomFov extends Module
      implements net.bluenetwork.client.module.AdjustableModule {

   /* ---------------- base ---------------- */

   private final BooleanSetting pinBase = new BooleanSetting("Pin base FOV",
      "Force your FOV to the value below while this module is on", true);
   /* Adjustment hotkeys - see AdjustableModule. 0 = unbound. */
   private final NumberSetting keyUp = new NumberSetting("Key: FOV +",
      "GLFW key code to raise FOV. 0 = unbound.", 0.0, 0.0, 400.0, 1.0);
   private final NumberSetting keyDown = new NumberSetting("Key: FOV -",
      "GLFW key code to lower FOV. 0 = unbound.", 0.0, 0.0, 400.0, 1.0);

   private final NumberSetting fov = new NumberSetting("Base FOV",
      "Field of view in degrees", 90.0, 30.0, 120.0, 1.0);

   /* ---------------- dynamic ---------------- */

   private final BooleanSetting dynamic = new BooleanSetting("Dynamic FOV",
      "Smoothly change FOV when sprinting, aiming or flying", true);
   private final NumberSetting sprintBoost = new NumberSetting("Sprint boost",
      "Extra FOV multiplier while sprinting (%)", 10.0, 0.0, 40.0, 1.0);
   private final NumberSetting bowZoom = new NumberSetting("Bow zoom",
      "How far FOV pulls in while drawing a bow or crossbow (%)", 20.0, 0.0, 60.0, 1.0);
   private final NumberSetting flyBoost = new NumberSetting("Fly boost",
      "Extra FOV multiplier while elytra flying or creative flying (%)", 15.0, 0.0, 50.0, 1.0);
   private final NumberSetting speed = new NumberSetting("Transition speed",
      "How quickly the FOV eases to its target (higher = snappier)", 12.0, 1.0, 40.0, 1.0);

   private double lastApplied = -1.0;

   /**
    * The eased multiplier, updated every frame by the render hook.
    *
    * <p>{@code volatile} because it is written on the render thread and read
    * from the mixin on the same thread but via a static accessor — keeping it
    * volatile costs nothing and avoids surprises.</p>
    */
   private volatile float currentMultiplier = 1.0F;

   public CustomFov() {
      super("FOV Changer", "Pin your FOV and add smooth dynamic FOV while sprinting, aiming or flying",
         Category.MISC);
      this.addSettings(new Setting[]{
         this.pinBase, this.fov, this.dynamic,
         this.sprintBoost, this.bowZoom, this.flyBoost, this.speed, this.keyUp, this.keyDown});
      this.fov.visibleWhen(this.pinBase::get);
      this.sprintBoost.visibleWhen(this.dynamic::get);
      this.bowZoom.visibleWhen(this.dynamic::get);
      this.flyBoost.visibleWhen(this.dynamic::get);
      this.speed.visibleWhen(this.dynamic::get);
   }

   @Override
   protected void onEnable() {
      this.lastApplied = -1.0;
      this.currentMultiplier = 1.0F;
   }

   @Override
   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         OptionGuard.release(mc.options.getFov(), this);
      }
      this.currentMultiplier = 1.0F;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null || !OptionGuard.areOptionsReady()) {
         return;
      }
      if (!this.pinBase.get()) {
         if (OptionGuard.isHeldBy(mc.options.getFov(), this)) {
            OptionGuard.release(mc.options.getFov(), this);
            this.lastApplied = -1.0;
         }
         return;
      }
      int target = (int) Math.round(this.fov.get());
      if (target != (int) Math.round(this.lastApplied)) {
         this.lastApplied = target;
         OptionGuard.hold(mc.options.getFov(), target, this);
      }
   }

   private static CustomFov active() {
      Module m = BlueClient.getInstance().moduleManager().byName("FOV Changer");
      return m instanceof CustomFov f && f.isEnabled() ? f : null;
   }

   /**
    * Multiplier the render hook applies to the vanilla FOV.
    *
    * <p>Eased towards the target every call so transitions are smooth rather
    * than snapping the instant you start sprinting. Returns exactly
    * {@code 1.0} when the module or dynamic FOV is off, which the mixin treats
    * as "do nothing".</p>
    *
    * @param frameDelta seconds since the previous frame, used so the easing
    *                   runs at the same speed regardless of frame rate.
    */
   public static float dynamicMultiplier(float frameDelta) {
      CustomFov f = active();
      if (f == null || !f.dynamic.get()) {
         return 1.0F;
      }
      float target = f.targetMultiplier();
      float rate = Math.min(1.0F, f.speed.getFloat() * Math.max(0.0F, frameDelta));
      f.currentMultiplier += (target - f.currentMultiplier) * rate;
      if (Math.abs(target - f.currentMultiplier) < 0.0005F) {
         f.currentMultiplier = target;
      }
      return f.currentMultiplier;
   }

   /** The multiplier the current player state should ease towards. */
   private float targetMultiplier() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity player = mc == null ? null : mc.player;
      if (player == null) {
         return 1.0F;
      }
      float multiplier = 1.0F;

      // Drawing a bow / crossbow pulls the view IN (a zoom), so this divides.
      if (player.isUsingItem()) {
         var using = player.getActiveItem();
         boolean aiming = using.getItem() instanceof BowItem
            || using.getItem() instanceof CrossbowItem
            || using.isOf(Items.SPYGLASS);
         if (aiming) {
            multiplier *= 1.0F - (this.bowZoom.getFloat() / 100.0F);
            // While aiming, the sprint/fly widening would fight the zoom.
            return Math.max(0.1F, multiplier);
         }
      }
      if (player.isSprinting()) {
         multiplier *= 1.0F + (this.sprintBoost.getFloat() / 100.0F);
      }
      boolean flying = player.isGliding()
         || (player.getAbilities() != null && player.getAbilities().flying);
      if (flying) {
         multiplier *= 1.0F + (this.flyBoost.getFloat() / 100.0F);
      }
      return Math.max(0.1F, multiplier);
   }

   @Override
   public int increaseKey() {
      return this.keyUp.getInt();
   }

   @Override
   public int decreaseKey() {
      return this.keyDown.getInt();
   }

   @Override
   public String adjust(int direction) {
      if (!this.isEnabled()) {
         this.setEnabled(true);
      }
      this.fov.set(this.fov.get() + direction * 5.0);
      return "FOV " + this.fov.getInt();
   }
}
