package net.bluenetwork.client.ui.theme;

import net.bluenetwork.client.config.ThemeManager;

/**
 * Semantic colour tokens — the vocabulary the UI code speaks.
 *
 * <h2>v0.24.0: a live read-through to {@link ThemePalette}</h2>
 * These used to return the mutable {@code BlueColors} statics. They now read
 * the active palette, so every screen already written against DesignTokens
 * became BLACK/GLASS/WHITE aware with no changes, and there is exactly one
 * place to change a colour: {@link ThemePalette}.
 *
 * <h2>Which token should I use?</h2>
 * <pre>
 *   a panel background .................. panelBg()
 *   a panel under the cursor ............ panelBgHover()
 *   a 1px outline ....................... panelBorder()
 *   normal text ......................... textHi()
 *   secondary / hint text ............... textMid()
 *   the brand blue ...................... accent()
 *   a dim layer behind a modal .......... scrim()
 *   a BUTTON ............................ don't — use PremiumButton
 * </pre>
 * Buttons deliberately have no tokens here: they must all go through
 * {@link net.bluenetwork.client.ui.widget.PremiumButton} so the owner's preset
 * cannot drift between screens.
 */
public final class DesignTokens {

   private DesignTokens() {
   }

   private static ThemePalette p() {
      return ThemeManager.palette();
   }

   /* --- brand / interactive --- */

   /** Primary interactive, active and focus colour. */
   public static int accent() {
      return p().accent();
   }

   /** Accent at ~40 % alpha, for soft fills and pressed states. */
   public static int accentSoft() {
      return p().accentSoft();
   }

   /* --- text --- */

   /** Primary text. Near-white on dark themes, near-black on WHITE. */
   public static int textHi() {
      return p().textHi();
   }

   /** Muted secondary text. */
   public static int textMid() {
      return p().textMid();
   }

   /** Text drawn on top of an accent-filled surface. */
   public static int textOnAccent() {
      return p().textOnAccent();
   }

   /* --- surfaces --- */

   /** Main panel fill. Opaque on BLACK/WHITE, translucent on GLASS. */
   public static int panelBg() {
      return p().panelBg();
   }

   /** Panel fill under the cursor. */
   public static int panelBgHover() {
      return p().panelBgHover();
   }

   /** 1 px structural border. Fully transparent on the opaque themes. */
   public static int panelBorder() {
      return p().panelBorder();
   }

   /** Accent-tinted translucent wash used by the glass material. */
   public static int glassTint() {
      return ThemePalette.fade(p().accent(), 0.10F);
   }

   /** Drop-shadow colour under floating surfaces. */
   public static int shadow() {
      return p().shadow();
   }

   /**
    * The dim layer behind a modal / full-screen menu.
    *
    * <p>Theme-dependent on purpose: a dark scrim under the WHITE theme looks
    * like a bug, so WHITE gets a light scrim instead.</p>
    */
   public static int scrim() {
      return switch (ThemeManager.style()) {
         // v0.24.1: FULLY opaque for the solid themes. The owner asked for
         // "nothing behind visible" - 0xE6 (90 %) still let the world ghost
         // through behind the menu, which is what made BLACK look translucent.
         case BLACK -> 0xFF070910;   // 100 % opaque black
         case GLASS -> 0x99000000;   // translucent dim: glass is MEANT to show through
         case WHITE -> 0xFFF2F4F8;   // 100 % opaque light
      };
   }

   /* --- controls --- */

   /** Toggle track when off (red = tap to turn on). */
   public static int toggleOff() {
      return p().toggleOff();
   }

   /** Toggle track when on (green = tap to turn off). */
   public static int toggleOn() {
      return p().toggleOn();
   }

   /* --- introspection --- */

   /** The active theme's id, e.g. {@code "BLACK"}. */
   public static String themeName() {
      return ThemeManager.currentTheme();
   }

   /** The active theme. */
   public static ThemeStyle theme() {
      return ThemeManager.style();
   }
}
