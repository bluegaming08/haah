package net.bluenetwork.client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.config.ThemeManager;
import net.bluenetwork.client.render.PremiumRender;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.settings.ClientSettings;
import net.bluenetwork.client.ui.material.GlassSurface;
import net.bluenetwork.client.ui.screen.HudEditScreen;
import net.bluenetwork.client.ui.screen.ModuleMenuScreen;
import net.bluenetwork.client.ui.text.TextEffect;
import net.bluenetwork.client.ui.text.TextPainter;
import net.bluenetwork.client.ui.theme.DesignTokens;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * Client Settings v2 - premium settings console (feedback 2026-09-11,
 * reference shot 1): top bar with logo + tabs + close, left sidebar, group
 * chips, small-caps section headers, ON/OFF chip toggles with the label to
 * their right, value + blue-knob sliders, cycle boxes and a search field.
 *
 * <p>Rendered in the same fit-scaled virtual space as the modules menu, so
 * the panel can never be cut off by the window.</p>
 */
public class ClientSettingsScreen extends Screen {
   private static final int DESIGN_W = 700;
   private static final int DESIGN_H = 430;
   private static final int TOP_BAR_H = 34;
   private static final int SIDEBAR_W = 128;
   private static final int TOOLBAR_H = 30;
   private static final int PAD = 12;
   private static final int SEARCH_W = 150;

   private static final int GREEN = 0xFF3CB860;
   private static final int CRIMSON = 0xFFC9405E;

   private final Screen parent;
   private String group = "GENERAL";
   private String query = "";
   private boolean searchFocused = false;
   private float targetScroll;
   private float smoothScroll;
   private float drawScale = 1.0F;
   private boolean bindListening = false;
   private String editingString = null; // "top" or "bottom" gradient hex

   private final List<Hit> hits = new ArrayList<>();
   private Rect closeBtn;
   private Rect searchBox;
   private Rect hudBtn;
   private Rect saveBtn;
   private Rect bindBox;
   private float listTop;
   private float listBottom;
   private float dragX0;
   private float dragX1;
   private String draggingSlider = null;

   public ClientSettingsScreen(Screen parent) {
      super(Text.literal("Client Settings"));
      this.parent = parent;
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   /** Steps a cycle value by `step`, wrapping around at max back to min. */
   private static int nextStep(int current, int step, int min, int max) {
      int next = current + step;
      return next > max ? min : next;
   }

   private ClientSettings settings() {
      return BlueClient.getInstance().settings();
   }

   private boolean animated() {
      try {
         return this.settings().animations();
      } catch (Throwable t) {
         return true;
      }
   }

   /* ========================================================== RENDERING */

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      int w = context.getScaledWindowWidth();
      int h = context.getScaledWindowHeight();
      context.fill(0, 0, w, h, 0xB20B0E14);

      float base = 0.75F;
      float fit = Math.min(1.0F, Math.min(w / (base * DESIGN_W + 12.0F), h / (base * DESIGN_H + 12.0F)));
      float scale = base * Math.max(0.35F, fit);
      this.drawScale = scale;

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(scale, scale);
      int vw = (int) Math.floor(w / scale);
      int vh = (int) Math.floor(h / scale);
      int mx = (int) (mouseX / scale);
      int my = (int) (mouseY / scale);

      float panelW = Math.min(vw - 24, 980);
      float panelH = Math.min(vh - 24, 640);
      float panelX = (vw - panelW) / 2.0F;
      float panelY = (vh - panelH) / 2.0F;
      float radius = 12.0F;

      this.hits.clear();
      PremiumRender.drawShadow(context, (int) panelX - 2, (int) panelY - 2, (int) panelW + 4, (int) panelH + 4, 0x77000000, 14);
      SmoothRect.fill(context, panelX, panelY, panelW, panelH, radius,
         withAlpha(DesignTokens.panelBg() & 0x00FFFFFF, this.bodyAlpha()));

      this.drawTopBar(context, panelX, panelY, panelW, mx, my);
      this.drawSidebar(context, panelX, panelY, panelH, mx, my);

      float contentX = panelX + SIDEBAR_W;
      float contentW = panelW - SIDEBAR_W;
      this.drawToolbar(context, contentX, contentW, panelY + TOP_BAR_H, mx, my);

      float listX = contentX + PAD;
      float listW = contentW - PAD * 2 - 6;
      float top = panelY + TOP_BAR_H + TOOLBAR_H + 4;
      float bottom = panelY + panelH - PAD;
      this.drawSettings(context, listX, listW, top, bottom, scale, mx, my);

      int borderBase = DesignTokens.panelBorder();
      float borderAlpha = Math.max(0.55F, ((borderBase >>> 24) & 0xFF) / 255.0F);
      SmoothRect.outline(context, panelX, panelY, panelW, panelH, radius, 1.5F,
         withAlpha(borderBase & 0xFFFFFF, borderAlpha));
      context.getMatrices().popMatrix();

      if (this.animated()) {
         this.smoothScroll += (this.targetScroll - this.smoothScroll) * Math.min(1.0F, delta * 14.0F);
         if (Math.abs(this.targetScroll - this.smoothScroll) < 0.25F) {
            this.smoothScroll = this.targetScroll;
         }
      } else {
         this.smoothScroll = this.targetScroll;
      }
   }

   private void drawTopBar(DrawContext context, float px, float py, float pw, int mx, int my) {
      SmoothRect.fill(context, px + 1, py + 1, pw - 2, TOP_BAR_H - 1, 11.0F, this.cardFill(0x80141A26));
      SmoothRect.fill(context, px + 1, py + TOP_BAR_H - 1, pw - 2, 1, 0.5F, 0x22FFFFFF);
      RenderUtil.drawLogo(context, (int) (px + 10), (int) (py + 8), 18);
      TextPainter.drawPoppins(context, "BLUE CLIENT", px + 10 + RenderUtil.logoWidth(18) + 8, py + 11, DesignTokens.textHi(), 11.0F);

      String[] tabs = new String[]{"MODS", "SETTINGS", "HUD", "ACCOUNTS"};
      float tabW = 62;
      float total = tabs.length * tabW + (tabs.length - 1) * 6;
      float tx = px + pw / 2 - total / 2;
      for (int i = 0; i < tabs.length; i++) {
         float x = tx + i * (tabW + 6);
         boolean active = i == 1;
         boolean hovered = mx >= x && mx < x + tabW && my >= py + 7 && my < py + 27;
         SmoothRect.fill(context, x, py + 7, tabW, 20, 5.0F,
            active ? withAlpha(DesignTokens.accent(), 0.22F) : hovered ? 0x1FFFFFFF : 0x0DFFFFFF);
         if (active) {
            SmoothRect.outline(context, x, py + 7, tabW, 20, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.6F));
         }
         TextPainter.drawPoppins(context, tabs[i], x + tabW / 2 - TextPainter.poppinsWidth(tabs[i], 8.5F) / 2.0F,
            py + 12, active ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);
         if (!active) {
            this.hits.add(new Hit(new Rect(x, py + 7, tabW, 20), "tab:" + i));
         }
      }

      float cx = px + pw - 30;
      this.closeBtn = new Rect(cx, py + 7, 22, 20);
      boolean closeHover = this.closeBtn.contains(mx, my);
      SmoothRect.fill(context, cx, py + 7, 22, 20, 5.0F, closeHover ? 0x33FF5C5C : 0x14FFFFFF);
      RenderUtil.drawIcon(context, "x", (int) (cx + 6), (int) (py + 11), 10, closeHover ? 0xFFFF8A8A : DesignTokens.textMid());
   }

   private void drawSidebar(DrawContext context, float px, float py, float ph, int mx, int my) {
      float x = px + 1;
      float y = py + TOP_BAR_H;
      float w = SIDEBAR_W - 1;
      float h = ph - TOP_BAR_H - 1;
      SmoothRect.fill(context, x, y, w, h, 11.0F, this.cardFill(0x66141A26));
      SmoothRect.fill(context, x + w - 1, y + 6, 1, h - 12, 0.5F, 0x22FFFFFF);

      float ey = y + 10;
      TextPainter.drawPoppins(context, "SECTIONS", x + 10, ey, DesignTokens.textMid(), 7.5F);
      ey += 13;
      for (String g : new String[]{"GENERAL", "PERFORMANCE", "CONTROLS", "APPEARANCE"}) {
         boolean active = this.group.equals(g);
         boolean hovered = mx >= x + 6 && mx < x + w - 6 && my >= ey && my < ey + 22;
         if (active) {
            SmoothRect.fill(context, x + 6, ey, w - 12, 22, 5.0F, DesignTokens.accentSoft());
            SmoothRect.outline(context, x + 6, ey, w - 12, 22, 5.0F, 1.0F, withAlpha(DesignTokens.accent(), 0.55F));
         } else if (hovered) {
            SmoothRect.fill(context, x + 6, ey, w - 12, 22, 5.0F, 0x14FFFFFF);
         }
         String icon = switch (g) {
            case "PERFORMANCE" -> "gauge";
            case "CONTROLS" -> "keyboard";
            case "APPEARANCE" -> "sliders-horizontal";
            default -> "settings";
         };
         RenderUtil.drawIcon(context, icon, (int) (x + 12), (int) (ey + 5), 12, active ? DesignTokens.accent() : DesignTokens.textMid());
         TextPainter.drawPoppins(context, g.toLowerCase(Locale.ROOT), x + 30, ey + 7,
            active ? DesignTokens.textHi() : DesignTokens.textMid(), 9.0F);
         this.hits.add(new Hit(new Rect(x + 6, ey, w - 12, 22), "group:" + g));
         ey += 26;
      }

      float bottomY = py + ph - 78;
      this.hudBtn = new Rect(x + 8, bottomY, w - 16, 24);
      boolean hudHover = this.hudBtn.contains(mx, my);
      SmoothRect.fill(context, this.hudBtn.x, this.hudBtn.y, this.hudBtn.w, this.hudBtn.h, 5.0F,
         hudHover ? 0x22FFFFFF : 0x11FFFFFF);
      RenderUtil.drawIcon(context, "move", (int) (this.hudBtn.x + 8), (int) (this.hudBtn.y + 6), 12,
         hudHover ? DesignTokens.textHi() : DesignTokens.textMid());
      TextPainter.drawPoppins(context, "EDIT HUD", this.hudBtn.x + 26, this.hudBtn.y + 8,
         hudHover ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);

      this.saveBtn = new Rect(x + 8, bottomY + 28, w - 16, 24);
      boolean saveHover = this.saveBtn.contains(mx, my);
      SmoothRect.fill(context, this.saveBtn.x, this.saveBtn.y, this.saveBtn.w, this.saveBtn.h, 5.0F,
         saveHover ? 0x22FFFFFF : 0x11FFFFFF);
      RenderUtil.drawIcon(context, "download", (int) (this.saveBtn.x + 8), (int) (this.saveBtn.y + 6), 12,
         saveHover ? DesignTokens.textHi() : DesignTokens.textMid());
      TextPainter.drawPoppins(context, "SAVE", this.saveBtn.x + 26, this.saveBtn.y + 8,
         saveHover ? DesignTokens.textHi() : DesignTokens.textMid(), 8.5F);
   }

   private void drawToolbar(DrawContext context, float cx, float cw, float ty, int mx, int my) {
      float x = cx + PAD;
      float w = cw - PAD * 2;

      // group chips (synced with the sidebar)
      float chipX = x;
      for (String g : new String[]{"GENERAL", "PERFORMANCE", "CONTROLS", "APPEARANCE"}) {
         float chipW = TextPainter.poppinsWidth(g, 8.0F) + 16;
         boolean active = this.group.equals(g);
         boolean hovered = mx >= chipX && mx < chipX + chipW && my >= ty + 5 && my < ty + 23;
         SmoothRect.fill(context, chipX, ty + 5, chipW, 18, 4.0F,
            active ? withAlpha(DesignTokens.accent(), 0.85F) : hovered ? 0x26FFFFFF : 0x14FFFFFF);
         TextPainter.drawPoppins(context, g, chipX + 8, ty + 10,
            active ? 0xFFFFFFFF : DesignTokens.textMid(), 8.0F);
         this.hits.add(new Hit(new Rect(chipX, ty + 5, chipW, 18), "group:" + g));
         chipX += chipW + 6;
      }

      float sx = x + w - SEARCH_W;
      this.searchBox = new Rect(sx, ty + 4, SEARCH_W, 20);
      boolean hovered = this.searchBox.contains(mx, my);
      SmoothRect.fill(context, sx, ty + 4, SEARCH_W, 20, 6.0F, 0x99101520);
      SmoothRect.outline(context, sx, ty + 4, SEARCH_W, 20, 6.0F, 1.0F,
         this.searchFocused ? withAlpha(DesignTokens.accent(), 0.9F) : hovered ? 0x3DFFFFFF : 0x22FFFFFF);
      RenderUtil.drawIcon(context, "search", (int) sx + 7, (int) (ty + 9), 10,
         this.searchFocused || !this.query.isEmpty() ? DesignTokens.accent() : DesignTokens.textMid());
      if (this.query.isEmpty()) {
         TextPainter.drawPoppins(context, "Search...", sx + 22, ty + 9.5F, DesignTokens.textMid(), 9.0F);
      } else {
         TextPainter.drawPoppins(context, this.query, sx + 22, ty + 9.5F, DesignTokens.textHi(), 9.0F);
      }
   }

   /* --------------------------------------------------------- settings */

   private record Row(String kind, String label, String id) {
   }

   private record Section(String title, List<Row> rows) {
   }

   private boolean matches(String label) {
      return this.query.isEmpty() || label.toLowerCase(Locale.ROOT).contains(this.query.toLowerCase(Locale.ROOT));
   }

   private List<Section> sections() {
      List<Section> out = new ArrayList<>();
      if (this.group.equals("GENERAL") || !this.query.isEmpty()) {
         List<Row> menu = new ArrayList<>();
         add(menu, "bool", "Custom Main Menu", "mainMenu");
         add(menu, "bool", "Custom Pause Menu", "pauseMenu");
         add(menu, "bool", "Card Style GUI", "guiCards");
         add(menu, "bool", "HUD Grid Snap", "gridSnap");
         // OFF = smooth free scrolling (default). ON = old row-by-row snapping.
         add(menu, "bool", "Snap Scrolling", "snapScroll");
         add(menu, "bool", "Sort Enabled First", "enabledFirst");
         List<Row> client = new ArrayList<>();
         add(client, "bool", "Animations", "animations");
         add(client, "bool", "Discord Presence", "presence");
         if (!menu.isEmpty()) {
            out.add(new Section("MENU OPTIONS", menu));
         }
         if (!client.isEmpty()) {
            out.add(new Section("CLIENT", client));
         }
      }
      if (this.group.equals("PERFORMANCE") || !this.query.isEmpty()) {
         List<Row> perf = new ArrayList<>();
         add(perf, "bool", "Performance Optimizer", "optimizer");
         add(perf, "bool", "Particle Optimization", "particles");
         add(perf, "bool", "Entity Culling", "culling");
         add(perf, "bool", "Adaptive Framerate", "adaptive");
         add(perf, "cycle", "Render Resolution", "renderScale");
         add(perf, "cycle", "Chunk Builder Threads", "chunkThreads");
         add(perf, "cycle", "Chunk Pre-Render", "chunkPreload");
         add(perf, "bool", "Menu Intro Animation", "menuAnim");
         if (!perf.isEmpty()) {
            out.add(new Section("PERFORMANCE", perf));
         }
      }
      if (this.group.equals("CONTROLS") || !this.query.isEmpty()) {
         List<Row> controls = new ArrayList<>();
         add(controls, "bind", "Modules Menu Keybind", "guiKeybind");
         if (!controls.isEmpty()) {
            out.add(new Section("CONTROLS", controls));
         }
      }
      if (this.group.equals("APPEARANCE") || !this.query.isEmpty()) {
         List<Row> theme = new ArrayList<>();
         add(theme, "cycle", "Theme", "theme");
         add(theme, "cycle", "Text Effect", "textEffect");
         add(theme, "cycle", "Glass Level", "glass");
         List<Row> bg = new ArrayList<>();
         add(bg, "cycle", "Menu Background", "menuBg");
         add(bg, "cycle", "Menu Button Opacity", "btnOpacity");
         add(bg, "string", "Gradient Top Hex", "gradTop");
         add(bg, "string", "Gradient Bottom Hex", "gradBottom");
         if (!theme.isEmpty()) {
            out.add(new Section("THEME", theme));
         }
         if (!bg.isEmpty()) {
            out.add(new Section("BACKGROUND", bg));
         }
      }
      return out;
   }

   private void add(List<Row> list, String kind, String label, String id) {
      if (this.matches(label)) {
         list.add(new Row(kind, label, id));
      }
   }

   private void drawSettings(DrawContext context, float x, float w, float top, float bottom, float sc, int mx, int my) {
      this.listTop = top;
      this.listBottom = bottom;
      List<Section> sections = this.sections();

      // measure
      List<float[]> layout = new ArrayList<>(); // y,w per section element
      float contentHeight = 0;
      for (Section section : sections) {
         contentHeight += 16;
         int col = 0;
         for (Row row : section.rows()) {
            boolean wide = !row.kind().equals("bool");
            int span = wide ? 2 : 1;
            if (col + span > 2) {
               col = 0;
               contentHeight += 4;
            }
            contentHeight += 24;
            col += span;
         }
         contentHeight += 10;
      }
      float viewH = bottom - top;
      float maxScroll = Math.max(0, contentHeight - viewH);
      this.targetScroll = Math.max(0, Math.min(this.targetScroll, maxScroll));

      // enableScissor applies the current matrix itself - pass virtual coords.
      context.enableScissor((int) Math.floor(x - 2), (int) Math.floor(top),
         (int) Math.ceil(x + w + 8), (int) Math.ceil(bottom + 2));

      float y = top - this.smoothScroll + 4;
      float colW = (w - 18) / 2.0F;
      for (Section section : sections) {
         if (y + 16 > top && y < bottom) {
            TextPainter.drawPoppins(context, section.title(), x + 2, y + 3, DesignTokens.textMid(), 7.5F);
         }
         y += 16;
         int col = 0;
         for (Row row : section.rows()) {
            boolean wide = !row.kind().equals("bool");
            int span = wide ? 2 : 1;
            if (col + span > 2) {
               col = 0;
               y += 4;
            }
            float rx = x + col * (colW + 18);
            float rw = span == 2 ? w : colW;
            if (y + 24 > top - 24 && y < bottom + 24) {
               this.drawRow(context, row, rx, y, rw, mx, my);
            }
            y += 24;
            col += span;
         }
         y += 10;
      }
      context.disableScissor();

      if (contentHeight > viewH) {
         float thumbH = Math.max(24, viewH * (viewH / contentHeight));
         float thumbY = top + (this.smoothScroll / maxScroll) * (viewH - thumbH);
         SmoothRect.fill(context, x + w + 3, top, 3, viewH, 1.5F, 0x14FFFFFF);
         SmoothRect.fill(context, x + w + 3, thumbY, 3, thumbH, 1.5F, withAlpha(DesignTokens.accent(), 0.75F));
      }
      layout.clear();
   }

   /** One settings row: chip toggle / slider / cycle / bind / string. */
   private void drawRow(DrawContext context, Row row, float x, float y, float w, int mx, int my) {
      ClientSettings s = this.settings();
      String id = row.id();
      switch (row.kind()) {
         case "bool" -> {
            boolean on = this.boolValue(id);
            boolean hovered = mx >= x && mx < x + w && my >= y && my < y + 20;
            if (hovered) {
               SmoothRect.fill(context, x - 4, y - 2, w + 8, 22, 5.0F, 0x0FFFFFFF);
            }
            this.drawChipToggle(context, x, y + 2, on);
            TextPainter.drawPoppins(context, row.label(), x + 42, y + 5,
               on ? DesignTokens.textHi() : DesignTokens.textMid(), 10.0F);
            this.hits.add(new Hit(new Rect(x - 4, y - 2, w + 8, 22), "bool:" + id));
         }
         case "cycle" -> {
            TextPainter.drawPoppins(context, row.label(), x, y + 5, DesignTokens.textHi(), 10.0F);
            String value = this.cycleValue(id);
            float bw = Math.max(96, TextPainter.poppinsWidth(value, 8.5F) + 26);
            float bx = x + w - bw;
            boolean hovered = mx >= bx && mx < bx + bw && my >= y && my < y + 19;
            SmoothRect.fill(context, bx, y + 1, bw, 18, 4.0F, hovered ? 0x26FFFFFF : 0x14FFFFFF);
            SmoothRect.outline(context, bx, y + 1, bw, 18, 4.0F, 1.0F, hovered ? withAlpha(DesignTokens.accent(), 0.7F) : 0x22FFFFFF);
            TextPainter.drawPoppins(context, value, bx + 8, y + 5.5F, DesignTokens.textHi(), 8.5F);
            RenderUtil.drawIcon(context, "chevron-down", (int) (bx + bw - 14), (int) (y + 6), 8, DesignTokens.textMid());
            this.hits.add(new Hit(new Rect(bx, y + 1, bw, 18), "cycle:" + id));
         }
         case "bind" -> {
            TextPainter.drawPoppins(context, row.label(), x, y + 5, DesignTokens.textHi(), 10.0F);
            String label = this.bindListening ? "PRESS A KEY" : keyName(s.guiKeybind());
            float bw = Math.max(90, TextPainter.poppinsWidth(label, 8.5F) + 20);
            float bx = x + w - bw;
            boolean hovered = mx >= bx && mx < bx + bw && my >= y && my < y + 19;
            SmoothRect.fill(context, bx, y + 1, bw, 18, 4.0F,
               this.bindListening ? withAlpha(DesignTokens.accent(), 0.3F) : hovered ? 0x26FFFFFF : 0x14FFFFFF);
            SmoothRect.outline(context, bx, y + 1, bw, 18, 4.0F, 1.0F,
               this.bindListening ? DesignTokens.accent() : 0x22FFFFFF);
            TextPainter.drawPoppins(context, label, bx + 10, y + 5.5F,
               this.bindListening ? 0xFFFFFFFF : DesignTokens.textHi(), 8.5F);
            this.bindBox = new Rect(bx, y + 1, bw, 18);
            this.hits.add(new Hit(new Rect(bx, y + 1, bw, 18), "bind"));
         }
         case "string" -> {
            TextPainter.drawPoppins(context, row.label(), x, y + 5, DesignTokens.textHi(), 10.0F);
            String value = "gradTop".equals(id) ? s.gradientTop() : s.gradientBottom();
            boolean editing = this.editingString == id;
            if (editing) {
               value = value + "_";
            }
            float bw = 110;
            float bx = x + w - bw;
            boolean hovered = mx >= bx && mx < bx + bw && my >= y && my < y + 19;
            SmoothRect.fill(context, bx, y + 1, bw, 18, 4.0F, editing || hovered ? 0x26FFFFFF : 0x14FFFFFF);
            SmoothRect.outline(context, bx, y + 1, bw, 18, 4.0F, 1.0F,
               editing ? withAlpha(DesignTokens.accent(), 0.9F) : 0x22FFFFFF);
            TextPainter.drawPoppins(context, value, bx + 8, y + 5.5F, DesignTokens.textHi(), 8.5F);
            this.hits.add(new Hit(new Rect(bx, y + 1, bw, 18), "string:" + id));
         }
         default -> {
         }
      }
   }

   /** ON/OFF chip: grey track with a green ON or crimson OFF block. */
   private void drawChipToggle(DrawContext context, float x, float y, boolean on) {
      float w = 34;
      float h = 14;
      SmoothRect.fill(context, x, y, w, h, 4.0F, 0x33FFFFFF);
      if (on) {
         SmoothRect.fill(context, x + w / 2.0F, y + 1, w / 2.0F - 1, h - 2, 3.0F, GREEN);
         TextPainter.drawPoppins(context, "ON", x + w * 0.75F - TextPainter.poppinsWidth("ON", 6.5F) / 2.0F, y + 3.5F, 0xFFFFFFFF, 6.5F);
      } else {
         SmoothRect.fill(context, x + 1, y + 1, w / 2.0F - 1, h - 2, 3.0F, CRIMSON);
         TextPainter.drawPoppins(context, "OFF", x + w * 0.25F - TextPainter.poppinsWidth("OFF", 6.5F) / 2.0F, y + 3.5F, 0xFFFFFFFF, 6.5F);
      }
   }

   /* ---------------------------------------------------------- values */

   private boolean boolValue(String id) {
      ClientSettings s = this.settings();
      return switch (id) {
         case "mainMenu" -> s.customMainMenu();
         case "pauseMenu" -> s.customPauseMenu();
         case "guiCards" -> s.guiCards();
         case "gridSnap" -> s.hudGridSnap();
         case "snapScroll" -> s.snapScrolling();
         case "enabledFirst" -> s.modulesEnabledFirst();
         case "animations" -> s.animations();
         case "presence" -> s.presence();
         case "optimizer" -> s.perfOptimizer();
         case "particles" -> s.perfParticles();
         case "culling" -> s.perfCulling();
         case "adaptive" -> s.perfAdaptive();
         case "menuAnim" -> s.menuIntroAnim();
         default -> false;
      };
   }

   private void setBool(String id, boolean v) {
      ClientSettings s = this.settings();
      switch (id) {
         case "mainMenu" -> s.customMainMenu(v);
         case "pauseMenu" -> s.customPauseMenu(v);
         case "guiCards" -> s.guiCards(v);
         case "gridSnap" -> s.hudGridSnap(v);
         case "snapScroll" -> s.setSnapScrolling(v);
         case "enabledFirst" -> s.modulesEnabledFirst(v);
         case "animations" -> s.animations(v);
         case "presence" -> s.presence(v);
         case "optimizer" -> s.perfOptimizer(v);
         case "particles" -> s.perfParticles(v);
         case "culling" -> s.perfCulling(v);
         case "adaptive" -> s.perfAdaptive(v);
         case "menuAnim" -> s.menuIntroAnim(v);
         default -> {
         }
      }
   }

   private String cycleValue(String id) {
      ClientSettings s = this.settings();
      return switch (id) {
         case "theme" -> s.themeName();
         case "textEffect" -> s.textEffect().name();
         case "glass" -> s.glassLevel().name();
         case "menuBg" -> backgroundName(s.menuBackground());
         case "renderScale" -> ClientSettings.RESOLUTION_NAMES[s.renderScale()];
         case "chunkThreads" -> ClientSettings.CHUNK_THREAD_NAMES[s.chunkThreads()];
         case "btnOpacity" -> s.menuButtonOpacity() + "%";
         case "chunkPreload" -> s.chunkPreload() + " blocks";
         default -> "";
      };
   }

   private void cycle(String id) {
      ClientSettings s = this.settings();
      switch (id) {
         case "theme" -> {
            String[] themes = ThemeManager.THEMES;
            String current = s.themeName();
            String next = themes[0];
            for (int i = 0; i < themes.length; i++) {
               if (themes[i].equals(current)) {
                  next = themes[(i + 1) % themes.length];
               }
            }
            s.theme(next);
         }
         case "textEffect" -> {
            TextEffect[] effects = TextEffect.values();
            TextEffect current = s.textEffect();
            s.textEffect(effects[(current.ordinal() + 1) % effects.length]);
         }
         case "glass" -> {
            GlassSurface[] levels = GlassSurface.values();
            GlassSurface current = s.glassLevel();
            s.glassLevel(levels[(current.ordinal() + 1) % levels.length]);
         }
         case "menuBg" -> s.menuBackground((s.menuBackground() + 1) % 6);
         case "btnOpacity" -> s.menuButtonOpacity(nextStep(s.menuButtonOpacity(), 5, 0, 100));
         case "chunkPreload" -> s.chunkPreload(nextStep(s.chunkPreload(), 100, 100, 5000));
         case "renderScale" -> {
            s.renderScale((s.renderScale() + 1) % ClientSettings.RESOLUTION_NAMES.length);
            net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
            if (mc != null && mc.getWindow() != null) {
               mc.onResolutionChanged();
            }
         }
         case "chunkThreads" -> s.chunkThreads((s.chunkThreads() + 1) % ClientSettings.CHUNK_THREAD_NAMES.length);
         default -> {
         }
      }
   }

   private static String backgroundName(int value) {
      return switch (value) {
         case 1 -> "GRADIENT";
         case 2 -> "BLUR";
         case 3 -> "DARK";
         case 4 -> "CUSTOM";      // config/blueclient/background.png
         case 5 -> "PARTICLES";   // the pre-0.24.2 animated default
         default -> "BLUE NETWORK";
      };
   }

   private static String keyName(int key) {
      if (key <= 0) {
         return "NONE";
      }
      return switch (key) {
         case 32 -> "SPACE";
         case 340 -> "LSHIFT";
         case 341 -> "RSHIFT";
         case 342 -> "ALT";
         default -> {
            String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(key, 0);
            yield name != null ? name.toUpperCase(Locale.ROOT) : ("KEY " + key);
         }
      };
   }


   /* ---- shared glass material (same recipe as the modules menu) ---- */

   private net.bluenetwork.client.module.impl.MenuCustomizer customizer() {
      for (net.bluenetwork.client.module.Module m : BlueClient.getInstance().moduleManager().getModules()) {
         if (m instanceof net.bluenetwork.client.module.impl.MenuCustomizer mc) {
            return mc;
         }
      }
      return null;
   }

   private net.bluenetwork.client.module.impl.MenuCustomizer activeCustomizer() {
      net.bluenetwork.client.module.impl.MenuCustomizer mc = this.customizer();
      return mc != null && mc.isEnabled() ? mc : null;
   }

   private float bodyAlpha() {
      net.bluenetwork.client.module.impl.MenuCustomizer mc = this.activeCustomizer();
      int o = mc != null ? Math.max(0, Math.min(100, mc.opacityPercent()))
         : net.bluenetwork.client.module.impl.MenuCustomizer.DEFAULT_OPACITY;
      return Math.min(1.0F, 0.35F + 0.65F * (o / 100.0F));
   }

   private int cardFill(int baseArgb) {
      net.bluenetwork.client.module.impl.MenuCustomizer mc = this.activeCustomizer();
      int o = mc != null ? Math.max(0, Math.min(100, mc.opacityPercent()))
         : net.bluenetwork.client.module.impl.MenuCustomizer.DEFAULT_OPACITY;
      float alpha = 0.15F + 0.85F * (o / 100.0F);
      return withAlpha(baseArgb & 0x00FFFFFF, alpha);
   }
   private static int withAlpha(int color, float alpha) {
      int a = (int) (alpha * 255.0F) & 0xFF;
      return (a << 24) | (color & 0x00FFFFFF);
   }

   /* ============================================================= INPUT */

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      float s = this.drawScale;
      int mx = (int) (click.x() / s);
      int my = (int) (click.y() / s);

      if (this.closeBtn != null && this.closeBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.close();
         return true;
      }
      if (this.hudBtn != null && this.hudBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         this.client.setScreen(new HudEditScreen(BlueClient.getInstance(), this));
         return true;
      }
      if (this.saveBtn != null && this.saveBtn.contains(mx, my)) {
         RenderUtil.clickSound();
         try {
            BlueClient.getInstance().configManager().save();
            this.settings().save();
            BlueClient.getInstance().notificationManager().add("Config saved", -13673473);
         } catch (Throwable t) {
            BlueClient.getInstance().notificationManager().add("Couldn't save config", 0xFFFF5C5C);
         }
         return true;
      }
      if (this.searchBox != null && this.searchBox.contains(mx, my)) {
         this.searchFocused = true;
         return true;
      }
      this.searchFocused = false;

      for (Hit hit : this.hits) {
         if (!hit.rect.contains(mx, my)) {
            continue;
         }
         String tag = hit.tag;
         if (tag.startsWith("tab:")) {
            RenderUtil.clickSound();
            switch (Integer.parseInt(tag.substring(4))) {
               case 0 -> this.client.setScreen(new ModuleMenuScreen(BlueClient.getInstance(), this));
               case 2 -> this.client.setScreen(new HudEditScreen(BlueClient.getInstance(), this));
               case 3 -> this.client.setScreen(new AccountsScreen(this));
               default -> {
               }
            }
            return true;
         }
         if (tag.startsWith("group:")) {
            this.group = tag.substring(6);
            this.targetScroll = 0;
            this.smoothScroll = 0;
            RenderUtil.clickSound();
            return true;
         }
         if (tag.startsWith("bool:")) {
            String id = tag.substring(5);
            this.setBool(id, !this.boolValue(id));
            RenderUtil.clickSound();
            return true;
         }
         if (tag.startsWith("cycle:")) {
            this.cycle(tag.substring(6));
            RenderUtil.clickSound();
            return true;
         }
         if (tag.equals("bind")) {
            this.bindListening = true;
            this.editingString = null;
            RenderUtil.clickSound();
            return true;
         }
         if (tag.startsWith("string:")) {
            String id = tag.substring(7);
            this.editingString = this.editingString == id ? null : id;
            RenderUtil.clickSound();
            return true;
         }
      }
      this.editingString = null;
      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
      float s = this.drawScale;
      if (my / s >= this.listTop && my / s <= this.listBottom) {
         this.targetScroll -= (float) vAmount * 34.0F;
         return true;
      }
      return super.mouseScrolled(mx, my, hAmount, vAmount);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int key = input.key();
      if (this.bindListening) {
         this.settings().guiKeybind(key == 256 ? 0 : key);
         this.bindListening = false;
         RenderUtil.clickSound();
         return true;
      }
      if (this.editingString != null) {
         if (key == 257 || key == 256) {
            this.editingString = null;
            return true;
         }
         if (key == 86 && (input.modifiers() & 2) != 0) {
            try {
               String clip = this.client.keyboard.getClipboard();
               if (clip != null && !clip.isEmpty()) {
                  this.typeString(clip.replaceAll("[\\r\\n\\t]", ""));
               }
            } catch (Throwable ignored) {
            }
            return true;
         }
         if (key == 259) {
            this.backspaceString();
            return true;
         }
         return true;
      }
      if (key == 256) {
         if (!this.query.isEmpty()) {
            this.query = "";
            return true;
         }
         this.close();
         return true;
      }
      if (key == 264 || key == 266) {
         this.targetScroll += 40;
         return true;
      }
      if (key == 265 || key == 267) {
         this.targetScroll -= 40;
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (this.editingString != null && input.isValidChar()) {
         this.typeString(input.asString());
         return true;
      }
      if (this.searchFocused && input.isValidChar()) {
         char ch = (char) input.codepoint();
         if (ch >= 32 && ch < 127) {
            this.query += ch;
            this.targetScroll = 0;
            return true;
         }
      }
      return super.charTyped(input);
   }

   private void typeString(String text) {
      ClientSettings s = this.settings();
      for (char ch : text.toCharArray()) {
         if (ch < 32 || ch > 126) {
            continue;
         }
         if ("gradTop".equals(this.editingString)) {
            s.gradientTop(limitHex(s.gradientTop() + ch));
         } else if ("gradBottom".equals(this.editingString)) {
            s.gradientBottom(limitHex(s.gradientBottom() + ch));
         }
      }
   }

   private void backspaceString() {
      ClientSettings s = this.settings();
      if ("gradTop".equals(this.editingString)) {
         String v = s.gradientTop();
         s.gradientTop(v.isEmpty() ? v : v.substring(0, v.length() - 1));
      } else if ("gradBottom".equals(this.editingString)) {
         String v = s.gradientBottom();
         s.gradientBottom(v.isEmpty() ? v : v.substring(0, v.length() - 1));
      }
   }

   private static String limitHex(String value) {
      return value.length() > 7 ? value.substring(value.length() - 7) : value;
   }

   @Override
   public void removed() {
      try {
         this.settings().save();
      } catch (Throwable ignored) {
      }
      super.removed();
   }

   @Override
   public void close() {
      if (this.parent != null) {
         this.client.setScreen(this.parent);
      } else {
         super.close();
      }
   }

   private record Hit(Rect rect, String tag) {
   }

   private static final class Rect {
      final float x, y, w, h;

      Rect(float x, float y, float w, float h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(int px, int py) {
         return px >= x && px < x + w && py >= y && py < y + h;
      }
   }
}
