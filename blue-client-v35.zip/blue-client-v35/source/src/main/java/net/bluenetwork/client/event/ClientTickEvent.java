package net.bluenetwork.client.event;

public record ClientTickEvent() {
}
