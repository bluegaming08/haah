package net.bluenetwork.client.module.impl;

import java.util.Locale;
import net.bluenetwork.client.BlueClient;
import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.Module;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.Setting;
import net.bluenetwork.client.setting.StringSetting;

/**
 * Chat Cleaner (v3 catalogue C1) — silently drops chat messages that contain
 * any blocked word. Words are a comma-separated persisted list. Matching is
 * case-insensitive by default. The chat mixin consults {@link #blocks(String)}.
 */
public class ChatCleaner extends Module {
   private final StringSetting words = new StringSetting("Blocked words", "Comma-separated words/phrases to hide", "");
   private final BooleanSetting caseSensitive = new BooleanSetting("Case sensitive", "Match exactly as typed", false);

   public ChatCleaner() {
      super("Chat Cleaner", "Hide chat messages containing blocked words", Category.MISC);
      this.addSettings(new Setting[]{this.words, this.caseSensitive});
   }

   /** Called from the chat mixin for every incoming message. */
   public static boolean blocks(String content) {
      try {
         if (content == null || content.isEmpty()) {
            return false;
         }
         Module module = BlueClient.getInstance().moduleManager().byName("Chat Cleaner");
         if (!(module instanceof ChatCleaner cleaner) || !cleaner.isEnabled()) {
            return false;
         }
         String raw = cleaner.words.get();
         if (raw == null || raw.isBlank()) {
            return false;
         }
         String text = cleaner.caseSensitive.get() ? content : content.toLowerCase(Locale.ROOT);
         String[] list = cleaner.caseSensitive.get() ? raw.split(",") : raw.toLowerCase(Locale.ROOT).split(",");
         for (String word : list) {
            String w = word.trim();
            if (!w.isEmpty() && text.contains(w)) {
               return true;
            }
         }
      } catch (Throwable ignored) {
      }
      return false;
   }
}
