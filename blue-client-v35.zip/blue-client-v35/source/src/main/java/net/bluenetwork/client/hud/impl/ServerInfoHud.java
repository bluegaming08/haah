package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class ServerInfoHud extends HudModule {
   public ServerInfoHud() {
      super("Server", "Shows the server you are playing on.", Category.HUD, 60, 4);
   }

   @Override
   public void render(DrawContext context) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         String text;
         if (mc.getCurrentServerEntry() != null) {
            text = "Server: " + mc.getCurrentServerEntry().address;
         } else {
            text = "Server: Singleplayer";
         }

         this.drawTextPanel(context, text);
      }
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Server: play.sennahosting.com") + 12 + 2;
   }
}
