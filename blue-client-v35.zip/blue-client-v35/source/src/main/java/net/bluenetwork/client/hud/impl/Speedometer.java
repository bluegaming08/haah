package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ModeSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Shows how fast the player is moving.
 *
 * <h2>The "why does it say 1.6 when I'm standing still" bug</h2>
 * The old version used {@code getVelocity().length()}, which is the magnitude
 * of the FULL 3D velocity vector - including Y.
 *
 * <p>Standing on the ground is not a zero-velocity state: gravity accelerates
 * you downward every tick and the collision resolves it, leaving a residual
 * Y component of about -0.0784 blocks/tick. Multiplied by 20 ticks/second
 * that is <b>1.57 b/s</b> - exactly the 1.6 that was showing.</p>
 *
 * <p>Speed now measures the HORIZONTAL component by default, which is what
 * "how fast am I going" means in practice and what every other client shows.
 * A mode is provided for the 3D figure for anyone who wants it (it is the
 * useful one while flying with an elytra).</p>
 *
 * <h2>Why position delta, not getVelocity()</h2>
 * {@code getVelocity()} is the field the entity uses for its own physics, and
 * for the client player it is not always the distance actually travelled -
 * notably while riding, being pushed, or on a moving vehicle. Measuring the
 * change in position between ticks reports what really happened.
 */
public class Speedometer extends HudModule {

   private final ModeSetting axis = new ModeSetting("Measure",
      "Horizontal ignores falling; 3D includes vertical movement",
      java.util.List.of("Horizontal", "3D"), "Horizontal");

   private final ModeSetting unit = new ModeSetting("Unit",
      "Blocks per second, or km/h for a real-world feel",
      java.util.List.of("b/s", "km/h"), "b/s");

   private final BooleanSetting showDecimal = new BooleanSetting("Decimal",
      "Show one decimal place", true);

   /** Previous tick position, for the delta measurement. */
   private double lastX;
   private double lastY;
   private double lastZ;
   private boolean seeded;

   /** Smoothed speed, so the number does not flicker every tick. */
   private double smoothed;

   public Speedometer() {
      super("Speedometer", "Shows your speed in blocks per second.",
         Category.HUD, 4, 262);
      this.addSettings(new Setting[]{this.axis, this.unit, this.showDecimal});
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         this.seeded = false;
         return;
      }
      double x = mc.player.getX();
      double y = mc.player.getY();
      double z = mc.player.getZ();

      if (!this.seeded) {
         this.lastX = x;
         this.lastY = y;
         this.lastZ = z;
         this.seeded = true;
         return;
      }

      double dx = x - this.lastX;
      double dy = y - this.lastY;
      double dz = z - this.lastZ;
      this.lastX = x;
      this.lastY = y;
      this.lastZ = z;

      double perTick = "3D".equals(this.axis.get())
         ? Math.sqrt(dx * dx + dy * dy + dz * dz)
         : Math.sqrt(dx * dx + dz * dz);

      // A teleport or dimension change produces an enormous delta; ignore it
      // rather than flashing a nonsense number.
      if (perTick > 10.0) {
         return;
      }

      double bps = perTick * 20.0;
      // Light smoothing: raw per-tick speed jitters visibly while walking.
      this.smoothed += (bps - this.smoothed) * 0.35;
      if (this.smoothed < 0.05) {
         this.smoothed = 0.0;               // genuinely still reads as 0
      }
   }

   @Override
   public void render(DrawContext context) {
      this.drawTextPanel(context, text());
   }

   private String text() {
      double value = this.smoothed;
      String suffix = " b/s";
      if ("km/h".equals(this.unit.get())) {
         // One block is one metre, so b/s -> km/h is x3.6.
         value *= 3.6;
         suffix = " km/h";
      }
      String number = this.showDecimal.get()
         ? String.format("%.1f", value)
         : String.valueOf(Math.round(value));
      return "Speed: " + number + suffix;
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("Speed: 99.9 km/h") + 12 + 2;
   }
}
