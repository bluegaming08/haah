package net.bluenetwork.client.mixin;

import net.bluenetwork.client.module.impl.MotionBlur;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.memory.ObjectPool;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Runs the Motion Blur post-effect over the finished frame.
 *
 * <h2>Where the hook goes, and why</h2>
 * {@code GameRenderer.renderWorld} ends with the world fully drawn into
 * {@code minecraft:main} but before the HUD and any screen are composited on
 * top. That is exactly the right seam: the world smears, your HUD, chat and
 * inventory stay razor sharp. Hooking {@code render} instead would blur the
 * whole UI, which looks broken.
 *
 * <p>We copy vanilla's own {@code renderBlur()} verbatim, only with our
 * pipeline id:</p>
 * <pre>
 *   PostEffectProcessor p = client.getShaderLoader()
 *       .loadPostEffect(id, DefaultFramebufferSet.MAIN_ONLY);
 *   if (p != null) p.render(client.getFramebuffer(), allocator);
 * </pre>
 * {@code loadPostEffect} caches by id, so this is a map lookup per frame, not
 * a shader compile.
 *
 * <p>The whole body is wrapped in a try/catch: a broken or missing shader must
 * degrade to "no motion blur", never to a crash on someone's machine with an
 * old driver. On the first failure we latch {@link #blueclient$failed} so we
 * stop retrying every single frame.</p>
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMotionBlurMixin {

   /**
    * Vanilla's own framebuffer recycling pool, the exact object
    * {@code renderBlur()} hands to {@code PostEffectProcessor.render}. Shadowing
    * it means our pass reuses the same GPU targets as every other post-effect
    * instead of allocating a fresh one each frame.
    */
   @Shadow @Final private ObjectPool pool;

   /** Latched after the first failure so a bad driver doesn't spam the log. */
   private static boolean blueclient$failed;

   @Inject(method = "renderWorld", at = @At("RETURN"), require = 0)
   private void blueclient$motionBlur(RenderTickCounter counter, CallbackInfo ci) {
      if (blueclient$failed) {
         return;
      }
      Identifier effect = MotionBlur.activeEffect();
      if (effect == null) {
         return;
      }
      try {
         MinecraftClient client = MinecraftClient.getInstance();
         PostEffectProcessor processor =
            client.getShaderLoader().loadPostEffect(effect, DefaultFramebufferSet.MAIN_ONLY);
         if (processor != null) {
            processor.render(client.getFramebuffer(), this.pool);
         }
      } catch (Throwable t) {
         blueclient$failed = true;
         net.bluenetwork.client.BlueClient.LOGGER.warn("Motion blur disabled: {}", t.toString());
      }
   }

}
