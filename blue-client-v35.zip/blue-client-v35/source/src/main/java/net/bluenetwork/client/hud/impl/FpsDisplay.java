package net.bluenetwork.client.hud.impl;

import net.bluenetwork.client.module.Category;
import net.bluenetwork.client.module.HudModule;
import net.bluenetwork.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FpsDisplay extends HudModule {
   public FpsDisplay() {
      super("FPS Display", "Shows your current frames per second.", Category.HUD, 4, 26);
   }

   @Override
   public void render(DrawContext context) {
      String text = "FPS: " + MinecraftClient.getInstance().getCurrentFps();
      this.drawTextPanel(context, text);
   }

   @Override
   public int getWidth() {
      return RenderUtil.textWidth("FPS: 999") + 12 + 2;
   }
}
