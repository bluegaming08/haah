package net.bluenetwork.client.module;

import net.bluenetwork.client.BlueColors;
import net.bluenetwork.client.render.RenderUtil;
import net.bluenetwork.client.render.SmoothRect;
import net.bluenetwork.client.setting.BooleanSetting;
import net.bluenetwork.client.setting.ColorSetting;
import net.bluenetwork.client.setting.NumberSetting;
import net.bluenetwork.client.setting.Setting;
import net.minecraft.client.gui.DrawContext;

public abstract class HudModule extends Module {
   public static final int PADDING = 6;

   /* ===================================================================== */
   /* v0.24.0 DEFAULT HUD APPEARANCE PRESET                                 */
   /* ===================================================================== */
   /*
    * Owner spec, verbatim:
    *    "Whenever u enable a new module that has a hud the default hud
    *     settings should be:
    *        border opacity 0
    *        background enabled
    *        background color: #0B0E14
    *        Background opacity 100
    *        corner radius: 2
    *        text color: #FFFFFF"
    *
    * These constants are the ONLY place those numbers live, and they
    * intentionally match the premium BUTTON preset in ThemePalette so HUD
    * panels and buttons read as one design system.
    */

   /** Default panel background, #0B0E14. */
   public static final int DEFAULT_BG_RGB = 0x0B0E14;

   /** Default background opacity: 100 % (fully solid). */
   public static final double DEFAULT_BG_OPACITY = 100.0;

   /** Default corner radius: 2 px. */
   public static final double DEFAULT_RADIUS = 2.0;

   /** Default border opacity: 0 (invisible). */
   public static final double DEFAULT_BORDER_OPACITY = 0.0;

   /** Default text colour, #FFFFFF. */
   public static final int DEFAULT_TEXT_RGB = 0xFFFFFF;

   /** Anchored corners: positions survive GUI scale / resolution changes. */
   public enum Anchor {
      TOP_LEFT,
      TOP_RIGHT,
      BOTTOM_LEFT,
      BOTTOM_RIGHT
   }

   /* ---- per-module appearance ("100% customizability") ---- */

   private BooleanSetting appearanceBg;
   private ColorSetting appearanceBgColor;
   private NumberSetting appearanceOpacity;
   private NumberSetting appearanceRadius;
   private BooleanSetting appearanceBorder;
   private ColorSetting appearanceBorderColor;
   private ColorSetting appearanceTextColor;
   private NumberSetting appearanceBorderOpacity;
   private boolean appearanceInitialized = false;

   /* ---- per-tick size cache (perf charter: never re-measure text per frame) ---- */

   private int cachedW = -1;
   private int cachedH = -1;

   protected int x;
   protected int y;
   private float scale = 1.0F;
   private final int defaultX;
   private final int defaultY;
   private Anchor anchor = Anchor.TOP_LEFT;
   private int offsetX;
   private int offsetY;
   private boolean pendingAbsolute = true;

   protected HudModule(String name, String description, Category category, int defaultX, int defaultY) {
      super(name, description, category);
      this.defaultX = defaultX;
      this.defaultY = defaultY;
      this.x = defaultX;
      this.y = defaultY;
      this.offsetX = defaultX;
      this.offsetY = defaultY;
   }

   public abstract void render(DrawContext var1);

   public abstract int getWidth();

   public int getHeight() {
      return 21;
   }

   /* ===================================================================== */
   /* Appearance                                                            */
   /* ===================================================================== */

   /**
    * Registers the shared appearance settings (background, colors, opacity,
    * corner radius, border, text color) unless the module already defines a
    * setting with that name. Called once by ModuleManager right after
    * construction — before config load, so persisted values apply.
    */
   public final void ensureAppearanceSettings() {
      if (this.appearanceInitialized) {
         return;
      }
      this.appearanceInitialized = true;
      this.appearanceBg = this.attach(new BooleanSetting("Background", "Draw the panel background", true));
      this.appearanceBgColor = this.attach(new ColorSetting("Background color", "Panel background color", DEFAULT_BG_RGB));
      this.appearanceOpacity = this.attach(new NumberSetting("Background opacity", "0 = fully transparent, 100 = solid", DEFAULT_BG_OPACITY, 0.0, 100.0, 5.0));
      this.appearanceRadius = this.attach(new NumberSetting("Corner radius", "Roundness of the panel corners", DEFAULT_RADIUS, 0.0, 16.0, 1.0));
      this.appearanceBorder = this.attach(new BooleanSetting("Show border", "1px outline around the panel", false));
      this.appearanceBorderColor = this.attach(new ColorSetting("Border color", "Panel outline color", 0xFFFFFF));
      this.appearanceTextColor = this.attach(new ColorSetting("Text color", "Color of this panel's text", DEFAULT_TEXT_RGB));
      this.appearanceBorderOpacity = this.attach(new NumberSetting("Border opacity", "0 = invisible border, 100 = solid", DEFAULT_BORDER_OPACITY, 0.0, 100.0, 5.0));
   }

   /** Adds the setting, or returns an existing one with the same name. */
   private <T extends Setting<?>> T attach(T setting) {
      for (Setting<?> existing : this.getSettings()) {
         if (existing.getName().equals(setting.getName())) {
            try {
               return (T) existing;
            } catch (ClassCastException e) {
               return setting;
            }
         }
      }
      this.addSettings(setting);
      return setting;
   }

   /** True while this HUD module should draw a panel background. */
   protected final boolean panelBackground() {
      return this.appearanceBg == null || this.appearanceBg.get();
   }

   /** Resolved background argb (appearance color x appearance opacity), animated for rainbow colors. */
   protected final int panelBodyArgb() {
      long now = System.currentTimeMillis();
      int rgb = this.appearanceBgColor != null
         ? this.appearanceBgColor.currentRgb(now) & 0xFFFFFF
         : BlueColors.PANEL_BG & 0xFFFFFF;
      double opacity = this.appearanceOpacity != null ? this.appearanceOpacity.get() : DEFAULT_BG_OPACITY;
      int alpha = (int) Math.round(255.0 * Math.max(0.0, Math.min(100.0, opacity)) / 100.0);
      return alpha << 24 | rgb;
   }

   /** Resolved corner radius from the appearance settings. */
   protected final float panelRadius() {
      double radius = this.appearanceRadius != null ? this.appearanceRadius.get() : DEFAULT_RADIUS;
      return (float) Math.max(0.0, Math.min(16.0, radius));
   }

   /** True while a border should be drawn. */
   protected final boolean panelBorderEnabled() {
      return this.appearanceBorder != null && this.appearanceBorder.get();
   }

   /** Resolved border color (appearance color x appearance border opacity). */
   protected final int panelBorderArgb() {
      long now = System.currentTimeMillis();
      int rgb = this.appearanceBorderColor != null
         ? this.appearanceBorderColor.currentRgb(now) & 0xFFFFFF
         : 0xFFFFFF;
      double opacity = this.appearanceBorderOpacity != null ? this.appearanceBorderOpacity.get() : DEFAULT_BORDER_OPACITY;
      int alpha = (int) Math.round(255.0 * Math.max(0.0, Math.min(100.0, opacity)) / 100.0);
      return alpha << 24 | rgb;
   }

   /** This panel's text color (module's own "Text color" wins if it defined one first). */
   protected final int textColor() {
      if (this.appearanceTextColor != null) {
         return this.appearanceTextColor.currentRgb(System.currentTimeMillis());
      }
      return BlueColors.TEXT_PRIMARY;
   }

   /* ---- public read-through for settings-screen live preview (ModuleSettingsScreen) ---- */

   /** Public mirror of {@link #panelBackground()} for the settings-screen preview panel. */
   public final boolean previewHasBackground() {
      return this.panelBackground();
   }

   /** Public mirror of {@link #panelBodyArgb()} for the settings-screen preview panel. */
   public final int previewBodyArgb() {
      return this.panelBodyArgb();
   }

   /** Public mirror of {@link #panelRadius()} for the settings-screen preview panel. */
   public final float previewRadius() {
      return this.panelRadius();
   }

   /** Public mirror of {@link #panelBorderEnabled()} for the settings-screen preview panel. */
   public final boolean previewHasBorder() {
      return this.panelBorderEnabled();
   }

   /** Public mirror of {@link #panelBorderArgb()} for the settings-screen preview panel. */
   public final int previewBorderArgb() {
      return this.panelBorderArgb();
   }

   /** Public mirror of {@link #textColor()} for the settings-screen preview panel. */
   public final int previewTextColor() {
      return this.textColor();
   }

   /**
    * Draws this module's panel using its appearance settings. Replaces the old
    * fixed RenderUtil.drawRoundedPanel call every HUD module used.
    */
   protected final void drawPanel(DrawContext context, int w, int h) {
      if (this.panelBackground()) {
         SmoothRect.fill(context, this.x, this.y, w, h, this.panelRadius(), this.panelBodyArgb());
      }
      if (this.panelBorderEnabled()) {
         SmoothRect.outline(context, this.x, this.y, w, h, this.panelRadius(), 1.0F, this.panelBorderArgb());
      }
   }

   /** Panel sized to the module's cached width — the common case. */
   protected final void drawPanel(DrawContext context) {
      this.drawPanel(context, this.getWidthCached(), this.getHeightCached());
   }

   protected void drawTextPanel(DrawContext context, String text) {
      int panelWidth = net.bluenetwork.client.optimization.RenderCache.textWidth(text) + 12 + 2;
      int panelHeight = this.getHeightCached();
      this.drawPanel(context, panelWidth, panelHeight);
      RenderUtil.drawText(context, text, this.x + 6 + 2, this.y + 6, this.textColor());
   }

   /* ===================================================================== */
   /* Size cache                                                            */
   /* ===================================================================== */

   /**
    * Re-measures the module once per tick. Called by HudManager.tick() AFTER
    * module ticks, so modules that cache their text in onTick() are measured
    * against fresh values — and the per-frame path never re-runs getWidth().
    */
   public final void refreshSizeCache() {
      try {
         this.cachedW = Math.max(1, this.getWidth());
         this.cachedH = Math.max(1, this.getHeight());
      } catch (Throwable t) {
         this.cachedW = 40;
         this.cachedH = 21;
      }
   }

   /** Width for layout/anchoring — cached per tick, falls back to a live measure. */
   public final int getWidthCached() {
      return this.cachedW > 0 ? this.cachedW : Math.max(1, this.getWidth());
   }

   /** Height for layout/anchoring — cached per tick, falls back to a live measure. */
   public final int getHeightCached() {
      return this.cachedH > 0 ? this.cachedH : Math.max(1, this.getHeight());
   }

   /* ===================================================================== */
   /* Positioning                                                           */
   /* ===================================================================== */

   /**
    * Renders this module into a live-preview panel (used by ModuleSettingsScreen):
    * the module draws with its own render path at the given position, then its
    * real HUD position is restored.
    */
   public final void renderPreview(DrawContext context, int previewX, int previewY) {
      int savedX = this.x;
      int savedY = this.y;
      this.x = previewX;
      this.y = previewY;
      try {
         this.render(context);
      } catch (Throwable t) {
         net.bluenetwork.client.BlueClient.LOGGER.debug("HUD preview render failed for {}", this.getName(), t);
      } finally {
         this.x = savedX;
         this.y = savedY;
      }
   }

   /**
    * Converts this.x/this.y (absolute GUI coords) into an anchor + offsets
    * relative to the current screen size. Called when a legacy config (or a
    * drag) sets absolute coords and the screen dimensions are now known.
    */
   private void convertAbsoluteToAnchor(int screenW, int screenH) {
      int width = this.getWidthCached();
      int height = this.getHeightCached();
      boolean right = this.x + width / 2 >= screenW / 2;
      boolean bottom = this.y + height / 2 >= screenH / 2;
      this.anchor = right ? (bottom ? Anchor.BOTTOM_RIGHT : Anchor.TOP_RIGHT) : (bottom ? Anchor.BOTTOM_LEFT : Anchor.TOP_LEFT);
      this.offsetX = right ? Math.max(0, screenW - this.x - width) : this.x;
      this.offsetY = bottom ? Math.max(0, screenH - this.y - height) : this.y;
      this.pendingAbsolute = false;
   }

   /**
    * Resolves the on-screen position from the anchor. Called once per frame
    * before rendering, so right/bottom-anchored elements stay pinned to their
    * edge even when the window size or content width changes.
    */
   public void resolvePosition(int screenW, int screenH) {
      if (this.pendingAbsolute) {
         this.convertAbsoluteToAnchor(screenW, screenH);
      }

      int width = this.getWidthCached();
      int height = this.getHeightCached();
      switch (this.anchor) {
         case TOP_LEFT -> {
            this.x = this.offsetX;
            this.y = this.offsetY;
         }
         case TOP_RIGHT -> {
            this.x = screenW - this.offsetX - width;
            this.y = this.offsetY;
         }
         case BOTTOM_LEFT -> {
            this.x = this.offsetX;
            this.y = screenH - this.offsetY - height;
         }
         case BOTTOM_RIGHT -> {
            this.x = screenW - this.offsetX - width;
            this.y = screenH - this.offsetY - height;
         }
      }

      this.x = Math.max(0, Math.min(this.x, Math.max(0, screenW - width)));
      this.y = Math.max(0, Math.min(this.y, Math.max(0, screenH - height)));
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   /** Called by the HUD editor drag: stores the new position as anchor + offsets. */
   public void setPosition(int newX, int newY, int screenW, int screenH) {
      this.x = Math.max(0, newX);
      this.y = Math.max(0, newY);
      this.convertAbsoluteToAnchor(screenW, screenH);
   }

   /** Absolute coords from config without known screen size - converted at the next resolve. */
   public void setRawPosition(int rawX, int rawY) {
      this.x = rawX;
      this.y = rawY;
      this.pendingAbsolute = true;
   }

   public void setAnchorAndOffsets(Anchor newAnchor, int newOffsetX, int newOffsetY) {
      this.anchor = newAnchor;
      this.offsetX = newOffsetX;
      this.offsetY = newOffsetY;
      this.pendingAbsolute = false;
   }

   public Anchor getAnchor() {
      return this.anchor;
   }

   public int getOffsetX() {
      return this.offsetX;
   }

   public int getOffsetY() {
      return this.offsetY;
   }

   public void resetPosition() {
      this.anchor = Anchor.TOP_LEFT;
      this.offsetX = this.defaultX;
      this.offsetY = this.defaultY;
      this.x = this.defaultX;
      this.y = this.defaultY;
      this.pendingAbsolute = false;
   }

   public float getScale() {
      return this.scale;
   }

   public void setScale(float scale) {
      this.scale = Math.max(0.5F, Math.min(3.0F, scale));
   }
}
