#version 330

/*
 * Blue Client - smooth motion blur (accumulation / previous-frame blend).
 *
 * This is the same technique the major clients and the "Motion Blur (Fabric)" mod
 * use: instead of computing a per-pixel velocity vector (expensive, and
 * impossible without a motion-vector G-buffer), we simply blend a little of
 * the PREVIOUS finished frame back over the current one. Anything that moved
 * leaves a short trail; anything static is untouched because both frames are
 * identical there.
 *
 *   In    = this frame (minecraft:main)
 *   Prev  = the accumulation buffer, i.e. last frame's blurred result
 *   Blend = how much of the old frame survives, 0.0 .. 0.95
 *
 * Cost is one full-screen mix - effectively free next to the world render.
 */

uniform sampler2D InSampler;
uniform sampler2D PrevSampler;

layout(std140) uniform MotionBlurConfig {
    float Blend;
};

in vec2 texCoord;

out vec4 fragColor;

void main() {
    vec4 current = texture(InSampler, texCoord);
    vec4 previous = texture(PrevSampler, texCoord);
    fragColor = vec4(mix(current.rgb, previous.rgb, Blend), current.a);
}
