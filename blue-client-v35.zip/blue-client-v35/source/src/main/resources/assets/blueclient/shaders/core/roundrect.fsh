#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    float d = abs(texCoord0.x);
    float aa = texCoord0.y;
    float alpha = 1.0 - smoothstep(1.0 - aa, 1.0 + aa, d);
    vec4 color = vec4(vertexColor.rgb, vertexColor.a * alpha);
    fragColor = color * ColorModulator;
}
