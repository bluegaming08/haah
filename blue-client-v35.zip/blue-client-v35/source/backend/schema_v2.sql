-- ===========================================================================
--  BLUE CLIENT - SCHEMA v2
--  Minecraft linking, badges, DMs, groups, statuses, buddies, followers,
--  server-join and the (unused for now) cosmetics tables.
--
--  Run this in the Supabase SQL Editor AFTER schema.sql. Safe to re-run.
--  See README-BACKEND.md, Steps 23-30.
-- ===========================================================================
--
--  SAME SECURITY MODEL AS v1 - re-read this before editing.
--  The publishable key is inside the jar; anyone can extract it and call this
--  database with their own script. RLS is the ONLY protection. Assume every
--  caller is hostile.
-- ===========================================================================


-- ===========================================================================
-- 15. MINECRAFT ACCOUNT LINKING
-- ---------------------------------------------------------------------------
-- The rule: "players cannot take the username of a premium account unless
-- they own it."
--
-- HOW THE TWO CASES DIFFER
--
--   CRACKED (offline) names - fully verified right here in SQL.
--     An offline uuid is a pure function of the name:
--         MD5("OfflinePlayer:" + name), with version/variant bits forced.
--     So the database recomputes it and checks the claim. A client cannot lie
--     about a cracked name, because the uuid it sends must match the name.
--     Additionally a cracked claim is refused if a PREMIUM account owns that
--     name (the client checks Mojang, and we record the outcome).
--
--   PREMIUM names - cannot be verified in SQL, because proving ownership
--     needs a live Mojang token check. That happens in the Edge Function
--     `verify-minecraft`, which is the ONLY thing allowed to set
--     verified = true / premium = true (it uses the service role).
--
-- This split is why the columns below are written by two different paths.
-- ===========================================================================

-- Recomputes Minecraft's offline (cracked) uuid for a name.
-- Verified to match Java's UUID.nameUUIDFromBytes("OfflinePlayer:"+name)
-- exactly, which is what the vanilla server uses.
create or replace function public.offline_uuid(name text)
returns uuid
language sql
immutable
as $$
   select (
      substr(h, 1, 8) || '-' || substr(h, 9, 4) || '-3' || substr(h, 14, 3) || '-'
      || to_hex((('x' || substr(h, 17, 2))::bit(8)::int & 63 | 128))
      || substr(h, 19, 2) || '-' || substr(h, 21, 12)
   )::uuid
   from (select md5('OfflinePlayer:' || name) as h) t;
$$;

alter table public.profiles
   add column if not exists mc_uuid      uuid,
   add column if not exists mc_name      text,
   add column if not exists mc_premium   boolean not null default false,
   add column if not exists mc_verified  boolean not null default false,
   add column if not exists about        text,
   add column if not exists status       text,
   add column if not exists equipped_badge text;

-- One Minecraft account cannot be linked to two Blue Client accounts.
create unique index if not exists profiles_mc_uuid_key
   on public.profiles (mc_uuid) where mc_uuid is not null;

-- Fast lookup by Minecraft name (used by the in-game badge/nametag code).
create unique index if not exists profiles_mc_name_low_key
   on public.profiles (lower(mc_name)) where mc_name is not null;

do $$ begin
   -- "About me" is capped at 50 characters, per the spec.
   if not exists (select 1 from pg_constraint where conname = 'profiles_about_len') then
      alter table public.profiles add constraint profiles_about_len
         check (about is null or char_length(about) <= 50);
   end if;
   if not exists (select 1 from pg_constraint where conname = 'profiles_status_len') then
      alter table public.profiles add constraint profiles_status_len
         check (status is null or char_length(status) <= 40);
   end if;
end $$;


-- ===========================================================================
-- 16. BADGES
-- ---------------------------------------------------------------------------
-- Badges are GRANTED BY STAFF, never self-assigned. There is deliberately no
-- insert policy for players on user_badges - if there were, anyone could give
-- themselves "Founder".
-- ===========================================================================
create table if not exists public.badges (
   id          text primary key,
   label       text not null,
   colour      integer not null,          -- packed ARGB, e.g. 0xFF2FA5FF
   priority    integer not null default 0, -- higher sorts first
   description text
);

insert into public.badges (id, label, colour, priority, description) values
   ('founder',    'Founder',     -16754689, 100, 'Created Blue Client'),
   ('helper',     'Helper',      -16725108,  80, 'Helps players in the community'),
   ('tester',     'Tester',      -1086464,   60, 'Tests new builds'),
   ('beta_tester','Beta Tester', -4342339,   50, 'Tested the earliest builds'),
   ('supporter',  'Supporter',   -22988,     40, 'Supports the project'),
   ('famous',     'Famous',      -2949376,   30, 'Well-known community member')
on conflict (id) do update
   set label = excluded.label,
       colour = excluded.colour,
       priority = excluded.priority,
       description = excluded.description;

create table if not exists public.user_badges (
   user_id    uuid not null references public.profiles(id) on delete cascade,
   badge_id   text not null references public.badges(id) on delete cascade,
   granted_at timestamptz not null default now(),
   primary key (user_id, badge_id)
);

create index if not exists user_badges_user_idx on public.user_badges (user_id);

-- Only a badge you actually own may be equipped. Enforced by a trigger,
-- because a check constraint cannot query another table.
create or replace function public.validate_equipped_badge()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
   if new.equipped_badge is not null then
      if not exists (
         select 1 from public.user_badges ub
         where ub.user_id = new.id and ub.badge_id = new.equipped_badge
      ) then
         raise exception 'you do not have that badge';
      end if;
   end if;
   return new;
end;
$$;

drop trigger if exists check_equipped_badge on public.profiles;
create trigger check_equipped_badge
   before update of equipped_badge on public.profiles
   for each row execute function public.validate_equipped_badge();


-- ===========================================================================
-- 17. DIRECT MESSAGES
-- ---------------------------------------------------------------------------
-- A DM belongs to a CONVERSATION. Conversations are either:
--   * a 1:1 DM between two friends, or
--   * a group with a name and many members.
-- Using one table for both keeps the message code simple.
-- ===========================================================================
create table if not exists public.conversations (
   id         uuid primary key default gen_random_uuid(),
   is_group   boolean not null default false,
   name       text,
   owner_id   uuid references public.profiles(id) on delete set null,
   created_at timestamptz not null default now(),

   -- A group must have a name; a 1:1 DM must not.
   constraint conversations_name_rule
      check ((is_group and name is not null and char_length(name) between 1 and 24)
             or (not is_group and name is null))
);

create table if not exists public.conversation_members (
   conversation_id uuid not null references public.conversations(id) on delete cascade,
   user_id         uuid not null references public.profiles(id) on delete cascade,
   joined_at       timestamptz not null default now(),
   last_read_at    timestamptz not null default now(),
   primary key (conversation_id, user_id)
);

create index if not exists conv_members_user_idx
   on public.conversation_members (user_id);

create table if not exists public.messages (
   id              uuid primary key default gen_random_uuid(),
   conversation_id uuid not null references public.conversations(id) on delete cascade,
   sender_id       uuid not null references public.profiles(id) on delete cascade,
   body            text not null,
   created_at      timestamptz not null default now(),

   constraint messages_body_len check (char_length(body) between 1 and 256)
);

-- The index that makes "show me the latest 50 messages" fast.
create index if not exists messages_conv_time_idx
   on public.messages (conversation_id, created_at desc);

-- Am I a member of this conversation? Used by every DM policy.
create or replace function public.in_conversation(conv uuid, who uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
   select exists (
      select 1 from public.conversation_members m
      where m.conversation_id = conv and m.user_id = who
   );
$$;


-- ===========================================================================
-- 18. BUDDY SYSTEM
-- ---------------------------------------------------------------------------
-- You may set exactly ONE buddy. The 3x shard bonus requires the choice to be
-- MUTUAL, which the plugin checks via are_buddies().
--
-- Stored as a column on profiles rather than its own table, because "one
-- buddy" is enforced for free that way.
-- ===========================================================================
alter table public.profiles
   add column if not exists buddy_id uuid references public.profiles(id) on delete set null;

do $$ begin
   if not exists (select 1 from pg_constraint where conname = 'profiles_buddy_not_self') then
      alter table public.profiles add constraint profiles_buddy_not_self
         check (buddy_id is null or buddy_id <> id);
   end if;
end $$;

-- True only when BOTH players picked each other. This is what grants 3x.
create or replace function public.are_buddies(u1 uuid, u2 uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
   select exists (
      select 1 from public.profiles a
      join public.profiles b on b.id = u1
      where a.id = u2 and a.buddy_id = u1 and b.buddy_id = u2
   );
$$;

-- Server-facing helper: are these two MINECRAFT uuids mutual buddies?
-- The plugin knows Minecraft uuids, not Blue Client ids.
create or replace function public.are_buddies_mc(mc1 uuid, mc2 uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
   select exists (
      select 1
      from public.profiles a
      join public.profiles b on b.mc_uuid = mc2
      where a.mc_uuid = mc1
        and a.mc_verified and b.mc_verified
        and a.buddy_id = b.id
        and b.buddy_id = a.id
   );
$$;


-- ===========================================================================
-- 19. FOLLOWERS
-- ---------------------------------------------------------------------------
-- Deliberately one-directional and requires no approval - "people can just
-- follow them, easily". Unlike friendship, there is no request step.
-- ===========================================================================
create table if not exists public.follows (
   follower_id uuid not null references public.profiles(id) on delete cascade,
   followee_id uuid not null references public.profiles(id) on delete cascade,
   created_at  timestamptz not null default now(),

   primary key (follower_id, followee_id),
   constraint follows_not_self check (follower_id <> followee_id)
);

create index if not exists follows_followee_idx on public.follows (followee_id);


-- ===========================================================================
-- 20. COSMETICS (tables only - nothing uses these yet)
-- ---------------------------------------------------------------------------
-- Created now so cosmetics can be added later WITHOUT a migration that would
-- disturb live user data. Documented in README-NEXT-AGENT.md.
-- ===========================================================================
create table if not exists public.cosmetics (
   id        text primary key,
   kind      text not null,          -- 'cape' | 'wing' | 'hat' | 'trail' | ...
   name      text not null,
   rarity    text not null default 'common',
   texture   text,                   -- path or URL of the texture
   premium   boolean not null default false,

   constraint cosmetics_kind_valid
      check (kind in ('cape', 'wing', 'hat', 'trail', 'pet', 'effect')),
   constraint cosmetics_rarity_valid
      check (rarity in ('common', 'rare', 'epic', 'legendary'))
);

create table if not exists public.user_cosmetics (
   user_id     uuid not null references public.profiles(id) on delete cascade,
   cosmetic_id text not null references public.cosmetics(id) on delete cascade,
   granted_at  timestamptz not null default now(),
   equipped    boolean not null default false,
   primary key (user_id, cosmetic_id)
);

create index if not exists user_cosmetics_user_idx on public.user_cosmetics (user_id);


-- ===========================================================================
-- 21. RPCs
-- ===========================================================================

-- ---- Minecraft linking ----------------------------------------------------

-- Called ONLY by the verify-minecraft Edge Function (service role).
create or replace function public.apply_minecraft_link(
   p_user uuid, p_uuid uuid, p_name text, p_premium boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
   update public.profiles
      set mc_uuid = p_uuid,
          mc_name = p_name,
          mc_premium = p_premium,
          mc_verified = true
    where id = p_user;
end;
$$;

-- Links a CRACKED account. Fully verified in SQL: the uuid must be the exact
-- offline uuid of the claimed name, so the claim proves itself.
--
-- p_premium_taken is the client's report of Mojang's answer for this name.
-- A hostile client could lie and say "false"... but then it still only gets a
-- CRACKED link (mc_premium stays false), which grants nothing a premium owner
-- would care about, and the real owner can still link properly and take the
-- name via the unique index. Nothing of value is protected by that flag.
create or replace function public.link_cracked_minecraft(
   p_name text, p_premium_taken boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
   me uuid := auth.uid();
   claimed uuid;
begin
   if me is null then
      raise exception 'not authenticated';
   end if;
   if p_name is null or p_name !~ '^[A-Za-z0-9_]{3,16}$' then
      raise exception 'invalid Minecraft name';
   end if;
   if p_premium_taken then
      raise exception 'that name belongs to a premium account';
   end if;

   claimed := public.offline_uuid(p_name);

   -- Refuse if a VERIFIED premium player already holds this name.
   if exists (
      select 1 from public.profiles
      where lower(mc_name) = lower(p_name)
        and mc_premium and mc_verified and id <> me
   ) then
      raise exception 'that name belongs to a premium account';
   end if;

   update public.profiles
      set mc_uuid = claimed,
          mc_name = p_name,
          mc_premium = false,
          mc_verified = false
    where id = me;
end;
$$;

create or replace function public.unlink_minecraft()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   update public.profiles
      set mc_uuid = null, mc_name = null,
          mc_premium = false, mc_verified = false
    where id = me;
end;
$$;

-- ---- Badges ---------------------------------------------------------------

-- Bulk badge lookup for the nametag renderer: given the Minecraft names
-- currently visible, return each one's equipped badge.
--
-- Capped at 100 names so it cannot be used to dump the whole table, and it
-- returns ONLY the equipped badge - never the player's other badges.
create or replace function public.badges_for_players(names text[])
returns table (mc_name text, badge_id text, label text, colour integer)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
   if auth.uid() is null then
      raise exception 'not authenticated';
   end if;
   if names is null or array_length(names, 1) is null then
      return;
   end if;

   return query
      select p.mc_name, b.id, b.label, b.colour
      from public.profiles p
      join public.badges b on b.id = p.equipped_badge
      where p.mc_name is not null
        and lower(p.mc_name) = any (
           select lower(n) from unnest(names[1:100]) n
        )
        -- Respect the owner's choice to hide their badge.
        and coalesce((select s.show_badge from public.settings s where s.id = p.id), true);
end;
$$;

-- ---- Profile / status / about --------------------------------------------

create or replace function public.set_status(p_status text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   update public.profiles
      set status = nullif(left(trim(coalesce(p_status, '')), 40), '')
    where id = me;
end;
$$;

create or replace function public.set_about(p_about text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   update public.profiles
      set about = nullif(left(trim(coalesce(p_about, '')), 50), '')
    where id = me;
end;
$$;

-- The public profile card: identity, badge, counts, and the viewer's own
-- relationship to this person. One round trip for the whole GUI.
create or replace function public.get_profile(target uuid)
returns table (
   id uuid, username text, mc_name text, mc_uuid uuid, mc_premium boolean,
   about text, status text, badge_id text, badge_label text, badge_colour integer,
   follower_count bigint, following_count bigint,
   is_following boolean, is_friend boolean, is_buddy boolean,
   is_online boolean, server_name text
)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   if public.block_exists(me, target) then
      raise exception 'unavailable';
   end if;

   return query
   select p.id, p.username, p.mc_name, p.mc_uuid, p.mc_premium,
          p.about, p.status,
          b.id, b.label, b.colour,
          (select count(*) from public.follows f where f.followee_id = p.id),
          (select count(*) from public.follows f where f.follower_id = p.id),
          exists (select 1 from public.follows f
                  where f.follower_id = me and f.followee_id = p.id),
          public.are_friends(me, p.id),
          public.are_buddies(me, p.id),
          case when public.can_view(me, p.id, 'online') then p.is_online else false end,
          case when public.can_view(me, p.id, 'server') then p.server_name else null end
   from public.profiles p
   left join public.badges b on b.id = p.equipped_badge
   where p.id = target;
end;
$$;

-- My own badges, for the "equip a badge" list.
create or replace function public.my_badges()
returns table (badge_id text, label text, colour integer, priority integer)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   return query
      select b.id, b.label, b.colour, b.priority
      from public.user_badges ub
      join public.badges b on b.id = ub.badge_id
      where ub.user_id = me
      order by b.priority desc;
end;
$$;

-- ---- Buddy ----------------------------------------------------------------

create or replace function public.set_buddy(target uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   if target is not null then
      if target = me then
         raise exception 'cannot buddy yourself';
      end if;
      -- A buddy must be a friend; otherwise buddies could be used to bypass
      -- the friend system entirely.
      if not public.are_friends(me, target) then
         raise exception 'you can only buddy a friend';
      end if;
      if public.block_exists(me, target) then
         raise exception 'unavailable';
      end if;
   end if;
   update public.profiles set buddy_id = target where id = me;
end;
$$;

-- ---- Follows --------------------------------------------------------------

create or replace function public.follow_user(target uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   if me = target then raise exception 'cannot follow yourself'; end if;
   if public.block_exists(me, target) then raise exception 'unavailable'; end if;

   insert into public.follows (follower_id, followee_id)
   values (me, target) on conflict do nothing;
end;
$$;

create or replace function public.unfollow_user(target uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   delete from public.follows where follower_id = me and followee_id = target;
end;
$$;

-- ---- Messaging ------------------------------------------------------------

-- Opens (or finds) the 1:1 conversation with a friend.
-- Returns the conversation id either way, so the client can call it blindly.
create or replace function public.open_dm(target uuid)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
   me   uuid := auth.uid();
   conv uuid;
begin
   if me is null then raise exception 'not authenticated'; end if;
   if me = target then raise exception 'cannot DM yourself'; end if;
   if public.block_exists(me, target) then raise exception 'unavailable'; end if;
   -- DMs are friends-only. This is what stops strangers messaging you.
   if not public.are_friends(me, target) then
      raise exception 'you can only message friends';
   end if;

   -- Find an existing 1:1 conversation containing exactly these two.
   select c.id into conv
   from public.conversations c
   join public.conversation_members m1 on m1.conversation_id = c.id and m1.user_id = me
   join public.conversation_members m2 on m2.conversation_id = c.id and m2.user_id = target
   where not c.is_group
   limit 1;

   if conv is not null then
      return conv;
   end if;

   insert into public.conversations (is_group, owner_id)
   values (false, me) returning id into conv;

   insert into public.conversation_members (conversation_id, user_id)
   values (conv, me), (conv, target);

   return conv;
end;
$$;

create or replace function public.create_group(p_name text, members uuid[])
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
   me   uuid := auth.uid();
   conv uuid;
   m    uuid;
begin
   if me is null then raise exception 'not authenticated'; end if;
   if p_name is null or char_length(trim(p_name)) = 0 then
      raise exception 'group needs a name';
   end if;
   if array_length(members, 1) is null or array_length(members, 1) > 20 then
      raise exception 'groups take 1 to 20 members';
   end if;

   insert into public.conversations (is_group, name, owner_id)
   values (true, left(trim(p_name), 24), me) returning id into conv;

   insert into public.conversation_members (conversation_id, user_id)
   values (conv, me);

   foreach m in array members loop
      -- You may only add friends, and never someone who blocked you.
      if m <> me and public.are_friends(me, m) and not public.block_exists(me, m) then
         insert into public.conversation_members (conversation_id, user_id)
         values (conv, m) on conflict do nothing;
      end if;
   end loop;

   return conv;
end;
$$;

create or replace function public.leave_conversation(conv uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   delete from public.conversation_members
   where conversation_id = conv and user_id = me;

   -- Delete the conversation once the last member leaves, so empty threads
   -- do not accumulate forever.
   if not exists (select 1 from public.conversation_members
                  where conversation_id = conv) then
      delete from public.conversations where id = conv;
   end if;
end;
$$;

-- The conversation list, with the other person's name and an unread count.
create or replace function public.get_conversations()
returns table (
   id uuid, is_group boolean, name text,
   other_id uuid, other_name text,
   last_body text, last_at timestamptz, unread bigint
)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;

   return query
   select c.id, c.is_group, c.name,
          o.user_id, op.username,
          lm.body, lm.created_at,
          (select count(*) from public.messages x
            where x.conversation_id = c.id
              and x.created_at > mem.last_read_at
              and x.sender_id <> me)
   from public.conversations c
   join public.conversation_members mem
        on mem.conversation_id = c.id and mem.user_id = me
   -- the other member, for 1:1 conversations only
   left join lateral (
      select m2.user_id from public.conversation_members m2
      where m2.conversation_id = c.id and m2.user_id <> me
      limit 1
   ) o on not c.is_group
   left join public.profiles op on op.id = o.user_id
   left join lateral (
      select m3.body, m3.created_at from public.messages m3
      where m3.conversation_id = c.id
      order by m3.created_at desc limit 1
   ) lm on true
   order by coalesce(lm.created_at, '-infinity'::timestamptz) desc;
end;
$$;

create or replace function public.get_messages(conv uuid, limit_n integer default 50)
returns table (id uuid, sender_id uuid, sender_name text, body text, created_at timestamptz)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   if not public.in_conversation(conv, me) then
      raise exception 'not a member';
   end if;

   return query
      select m.id, m.sender_id, p.username, m.body, m.created_at
      from public.messages m
      join public.profiles p on p.id = m.sender_id
      where m.conversation_id = conv
      order by m.created_at desc
      limit least(greatest(coalesce(limit_n, 50), 1), 100);
end;
$$;

create or replace function public.mark_read(conv uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   update public.conversation_members
      set last_read_at = now()
    where conversation_id = conv and user_id = me;
end;
$$;

-- ---- Join a friend's server ----------------------------------------------

-- Returns the address to connect to, or null when not allowed.
-- Uses the SAME can_view() privacy check as the friend list, so hiding your
-- server also stops people joining you.
create or replace function public.get_join_address(target uuid)
returns text
language plpgsql
stable
security definer
set search_path = ''
as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   if not public.are_friends(me, target) then
      raise exception 'not your friend';
   end if;
   if not public.can_view(me, target, 'server') then
      raise exception 'they are not sharing their server';
   end if;

   return (select server_name from public.profiles
            where id = target and is_online);
end;
$$;


-- ===========================================================================
-- 22. SETTINGS additions (badge visibility)
-- ---------------------------------------------------------------------------
-- Per the spec these apply to the NAMETAG ONLY, not the tab list.
-- ===========================================================================
alter table public.settings
   add column if not exists show_badge        boolean not null default true,
   add column if not exists see_others_badges boolean not null default true;


-- ===========================================================================
-- 23. ROW LEVEL SECURITY for the new tables
-- ===========================================================================
alter table public.badges              enable row level security;
alter table public.user_badges         enable row level security;
alter table public.conversations       enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages            enable row level security;
alter table public.follows             enable row level security;
alter table public.cosmetics           enable row level security;
alter table public.user_cosmetics      enable row level security;

-- --- badges: a public catalogue, readable by all logged-in users ----------
drop policy if exists badges_select on public.badges;
create policy badges_select on public.badges
   for select to authenticated using (true);

-- --- user_badges: readable by anyone (badges are meant to be seen) --------
-- There is NO insert/update/delete policy: badges are granted by staff
-- through the dashboard or a service-role script. This is what stops a
-- modified client granting itself "Founder".
drop policy if exists user_badges_select on public.user_badges;
create policy user_badges_select on public.user_badges
   for select to authenticated using (true);

-- --- follows: public, so follower counts work -----------------------------
drop policy if exists follows_select on public.follows;
create policy follows_select on public.follows
   for select to authenticated using (true);

drop policy if exists follows_insert on public.follows;
create policy follows_insert on public.follows
   for insert to authenticated
   with check (auth.uid() = follower_id
               and follower_id <> followee_id
               and not public.block_exists(follower_id, followee_id));

drop policy if exists follows_delete on public.follows;
create policy follows_delete on public.follows
   for delete to authenticated using (auth.uid() = follower_id);

-- --- conversations: members only ------------------------------------------
drop policy if exists conversations_select on public.conversations;
create policy conversations_select on public.conversations
   for select to authenticated
   using (public.in_conversation(id, auth.uid()));

-- Creation goes through open_dm() / create_group() only.
drop policy if exists conversations_delete on public.conversations;
create policy conversations_delete on public.conversations
   for delete to authenticated using (auth.uid() = owner_id);

drop policy if exists conv_members_select on public.conversation_members;
create policy conv_members_select on public.conversation_members
   for select to authenticated
   using (public.in_conversation(conversation_id, auth.uid()));

drop policy if exists conv_members_delete on public.conversation_members;
create policy conv_members_delete on public.conversation_members
   for delete to authenticated using (auth.uid() = user_id);

-- --- messages: read if a member; send only as yourself, and only into a
--     conversation you belong to. -----------------------------------------
drop policy if exists messages_select on public.messages;
create policy messages_select on public.messages
   for select to authenticated
   using (public.in_conversation(conversation_id, auth.uid()));

drop policy if exists messages_insert on public.messages;
create policy messages_insert on public.messages
   for insert to authenticated
   with check (auth.uid() = sender_id
               and public.in_conversation(conversation_id, sender_id));

-- You may delete your own message.
drop policy if exists messages_delete on public.messages;
create policy messages_delete on public.messages
   for delete to authenticated using (auth.uid() = sender_id);

-- --- cosmetics: catalogue public, ownership readable ----------------------
drop policy if exists cosmetics_select on public.cosmetics;
create policy cosmetics_select on public.cosmetics
   for select to authenticated using (true);

drop policy if exists user_cosmetics_select on public.user_cosmetics;
create policy user_cosmetics_select on public.user_cosmetics
   for select to authenticated using (true);

-- Players may equip/unequip what they own, but NOT grant themselves items.
drop policy if exists user_cosmetics_update on public.user_cosmetics;
create policy user_cosmetics_update on public.user_cosmetics
   for update to authenticated
   using (auth.uid() = user_id) with check (auth.uid() = user_id);


-- ===========================================================================
-- 24. PERMISSIONS
-- ---------------------------------------------------------------------------
-- Remember: `revoke ... from anon` alone is NOT enough, because Postgres
-- grants EXECUTE to PUBLIC by default. Revoke from public too.
-- ===========================================================================
do $$
declare fn text;
begin
   foreach fn in array array[
      'public.link_cracked_minecraft(text, boolean)',
      'public.unlink_minecraft()',
      'public.badges_for_players(text[])',
      'public.set_status(text)',
      'public.set_about(text)',
      'public.get_profile(uuid)',
      'public.my_badges()',
      'public.set_buddy(uuid)',
      'public.are_buddies(uuid, uuid)',
      'public.follow_user(uuid)',
      'public.unfollow_user(uuid)',
      'public.open_dm(uuid)',
      'public.create_group(text, uuid[])',
      'public.leave_conversation(uuid)',
      'public.get_conversations()',
      'public.get_messages(uuid, integer)',
      'public.mark_read(uuid)',
      'public.get_join_address(uuid)',
      'public.in_conversation(uuid, uuid)',
      'public.offline_uuid(text)'
   ] loop
      execute format('revoke execute on function %s from public, anon', fn);
      execute format('grant execute on function %s to authenticated', fn);
   end loop;
end $$;

-- apply_minecraft_link is for the Edge Function (service role) ONLY.
-- If a player could call it, they could mark themselves as any premium user.
revoke execute on function public.apply_minecraft_link(uuid, uuid, text, boolean)
   from public, anon, authenticated;

-- are_buddies_mc is read by the SERVER PLUGIN using the service role.
revoke execute on function public.are_buddies_mc(uuid, uuid) from public, anon;


-- ===========================================================================
-- DONE. Verify with:
--    select count(*) from public.badges;      -- should be 6
--    select public.offline_uuid('Notch');     -- b50ad385-829d-3141-a216-7e7d7539ba7f
-- ===========================================================================
