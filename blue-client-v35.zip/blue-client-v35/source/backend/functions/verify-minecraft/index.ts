// ===========================================================================
//  BLUE CLIENT - Edge Function: verify-minecraft
// ---------------------------------------------------------------------------
//  Proves that the caller really owns the Minecraft account they claim, then
//  links it to their Blue Client profile.
//
//  WHY THIS EXISTS
//  ---------------
//  The rule is: "players can't take the username of a premium account unless
//  they have it in their account manager."
//
//  The client CANNOT be trusted to enforce that. Anyone can edit the mod and
//  tell the database "I am Notch". So the check has to happen somewhere the
//  player cannot modify - here, on Supabase's servers.
//
//  HOW THE PROOF WORKS
//  -------------------
//  We never see the player's password. Instead the client sends the Minecraft
//  ACCESS TOKEN that the Microsoft login already produced. We hand that token
//  to Mojang's own API:
//
//      GET https://api.minecraftservices.com/minecraft/profile
//      Authorization: Bearer <token>
//
//  Only the true owner can produce a token that Mojang accepts. Mojang replies
//  with the account's real uuid and name. A forged token gets a 401, and a
//  token for a DIFFERENT account returns that other account's name - which
//  will not match what the player claimed, so we reject it.
//
//  CRACKED ACCOUNTS
//  ----------------
//  Cracked (offline) accounts have no token and cannot be verified this way.
//  They are handled entirely in SQL instead: an offline uuid is just
//  MD5("OfflinePlayer:" + name), so the database recomputes it and checks the
//  claim itself. See link_cracked_minecraft() in schema_v2.sql.
//
//  A cracked player may only claim a name that NO premium account owns. We
//  check that here too, via Mojang's public username lookup.
//
//  DEPLOYING THIS
//  --------------
//  See README-BACKEND.md, Step 23. Short version:
//      supabase functions deploy verify-minecraft
//  It needs no secrets beyond the ones Supabase injects automatically.
// ===========================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const MOJANG_PROFILE = "https://api.minecraftservices.com/minecraft/profile";
const MOJANG_LOOKUP = "https://api.mojang.com/users/profiles/minecraft/";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

/** Adds the dashes Mojang strips from uuids. */
function dashed(id: string): string {
  const h = id.replace(/-/g, "").toLowerCase();
  if (h.length !== 32) return id;
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    // ---- 1. Identify the caller from their Blue Client session -----------
    // We deliberately read the user from the JWT rather than trusting any
    // user id in the request body.
    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader.startsWith("Bearer ")) {
      return json({ error: "Not logged in." }, 401);
    }

    const anonClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await anonClient.auth.getUser();
    if (userErr || !userData?.user) {
      return json({ error: "Not logged in." }, 401);
    }
    const callerId = userData.user.id;

    // ---- 2. Read the request --------------------------------------------
    const body = await req.json().catch(() => ({}));
    const mcToken: string | undefined = body.minecraft_token;

    if (!mcToken || typeof mcToken !== "string" || mcToken.length < 20) {
      return json({ error: "Missing Minecraft token." }, 400);
    }

    // ---- 3. Ask Mojang who this token belongs to -------------------------
    // This is the step that cannot be faked.
    const profileRes = await fetch(MOJANG_PROFILE, {
      headers: { Authorization: `Bearer ${mcToken}` },
    });

    if (profileRes.status === 401 || profileRes.status === 403) {
      return json({ error: "Minecraft login expired. Re-login in the account manager." }, 400);
    }
    if (!profileRes.ok) {
      return json({ error: "Could not reach Minecraft services. Try again." }, 502);
    }

    const profile = await profileRes.json();
    const realName: string = profile?.name;
    const realId: string = profile?.id;

    if (!realName || !realId) {
      return json({ error: "Minecraft did not return a profile." }, 502);
    }

    // ---- 4. Write the verified link using the service role ---------------
    // Only this function may set verified = true, which is why the table's
    // RLS policy forbids the client from writing these columns directly.
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { error: rpcErr } = await admin.rpc("apply_minecraft_link", {
      p_user: callerId,
      p_uuid: dashed(realId),
      p_name: realName,
      p_premium: true,
    });

    if (rpcErr) {
      // The most likely cause is that someone else already linked this
      // Minecraft account - a unique constraint in the database.
      const msg = String(rpcErr.message ?? "");
      if (msg.includes("duplicate") || msg.includes("unique")) {
        return json({ error: "That Minecraft account is already linked to another Blue Client account." }, 409);
      }
      return json({ error: "Could not save the link." }, 500);
    }

    return json({ ok: true, username: realName, uuid: dashed(realId), premium: true });
  } catch (e) {
    console.error(e);
    return json({ error: "Verification failed." }, 500);
  }
});
