// ===========================================================================
//  BLUE CLIENT - Edge Function: verify-join
// ---------------------------------------------------------------------------
//  Proves the caller really owns the Minecraft account they claim, WITHOUT
//  a Microsoft/Azure app registration and WITHOUT ever seeing their token.
//
//  WHY THIS REPLACES verify-minecraft
//  ----------------------------------
//  The old function needed the player's Minecraft ACCESS TOKEN, which meant:
//    1. the owner had to register an Azure application and get it approved
//       by Microsoft (blocked - approval never came), and
//    2. the token had to travel to this server, which is a real privacy cost.
//
//  This version uses the handshake every online-mode Minecraft server already
//  performs. Nothing to register, and the token never leaves the player's PC.
//
//  HOW THE PROOF WORKS  (the "joinServer / hasJoined" dance)
//  ---------------------------------------------------------
//    1. START: the client asks us to begin. We invent a random serverId
//       (a 32-char hex nonce) and remember it against their account.
//
//    2. The CLIENT calls Mojang itself:
//
//          sessionService.joinServer(uuid, accessToken, serverId)
//
//       This is the exact call vanilla makes when joining any online-mode
//       server. Mojang records "this account announced it is joining the
//       server identified by <serverId>". The access token is used locally
//       by the game's own session service and never sent to us.
//
//    3. FINISH: the client tells us it is done. We ask Mojang:
//
//          GET https://sessionserver.mojang.com/session/minecraft/hasJoined
//              ?username=<name>&serverId=<nonce>
//
//       Mojang answers with the verified uuid + name, or 204/empty if no
//       such join happened. Only somebody holding a genuine, currently-valid
//       Mojang session can make that call succeed.
//
//  WHY IT CANNOT BE FAKED
//  ----------------------
//  The serverId is random, single-use, short-lived, and tied to one account.
//  A player cannot make hasJoined return a profile for a name they do not
//  own, because joinServer requires a real token for that exact account.
//  Replaying an old nonce fails because we delete it on first use.
//
//  DEPLOYING
//  ---------
//      supabase functions deploy verify-join
//  Needs the SERVICE_ROLE_KEY secret (see README-BACKEND.md).
// ===========================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const HAS_JOINED = "https://sessionserver.mojang.com/session/minecraft/hasJoined";
const MOJANG_LOOKUP = "https://api.mojang.com/users/profiles/minecraft/";

/** A pending handshake is only valid this long. */
const NONCE_TTL_SECONDS = 120;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

/** Random 32-char hex string, used as the fake "server id". */
function makeNonce(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

/** Adds the dashes Postgres needs; Mojang returns undashed ids. */
function dashUuid(raw: string): string {
  if (raw.includes("-")) return raw;
  return [
    raw.slice(0, 8), raw.slice(8, 12), raw.slice(12, 16),
    raw.slice(16, 20), raw.slice(20),
  ].join("-");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: CORS });
  }

  // ---- who is calling? ----------------------------------------------------
  // The caller's JWT identifies their Blue Client account. We never trust a
  // user id sent in the body.
  const auth = req.headers.get("Authorization") ?? "";
  if (!auth.startsWith("Bearer ")) {
    return json({ ok: false, m: "Not logged in" }, 401);
  }

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SERVICE_ROLE_KEY")!,
    { auth: { persistSession: false } },
  );

  const { data: userData, error: userErr } = await admin.auth.getUser(
    auth.replace("Bearer ", ""),
  );
  if (userErr || !userData?.user) {
    return json({ ok: false, m: "Not logged in" }, 401);
  }
  const userId = userData.user.id;

  let body: { step?: string; username?: string };
  try {
    body = await req.json();
  } catch {
    return json({ ok: false, m: "Bad request" }, 400);
  }

  // =========================================================================
  //  STEP 1 - START: hand out a nonce
  // =========================================================================
  if (body.step === "start") {
    const username = (body.username ?? "").trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) {
      return json({ ok: false, m: "That is not a valid Minecraft name" });
    }

    // The name must actually be a premium account, otherwise hasJoined can
    // never succeed and we would just be wasting the player's time.
    const lookup = await fetch(MOJANG_LOOKUP + encodeURIComponent(username));
    if (lookup.status === 404) {
      return json({
        ok: false,
        m: "No premium account owns that name. Use 'Link cracked name' instead.",
      });
    }
    if (!lookup.ok) {
      return json({ ok: false, m: "Mojang is unreachable - try again shortly" });
    }

    const nonce = makeNonce();

    // Store the pending handshake. One row per user: starting again replaces
    // any previous attempt, so an abandoned nonce cannot pile up.
    const { error } = await admin.from("mc_link_pending").upsert({
      user_id: userId,
      nonce,
      username,
      created_at: new Date().toISOString(),
    }, { onConflict: "user_id" });

    if (error) {
      return json({ ok: false, m: "Could not start verification" }, 500);
    }

    // The client now calls joinServer(uuid, token, serverId) with this value.
    return json({ ok: true, serverId: nonce });
  }

  // =========================================================================
  //  STEP 2 - FINISH: ask Mojang whether the join really happened
  // =========================================================================
  if (body.step === "finish") {
    const { data: pending } = await admin
      .from("mc_link_pending")
      .select("nonce, username, created_at")
      .eq("user_id", userId)
      .maybeSingle();

    if (!pending) {
      return json({ ok: false, m: "Verification expired - start again" });
    }

    // Single use, always: delete before doing anything else so the same
    // nonce can never be replayed even if the rest of this fails.
    await admin.from("mc_link_pending").delete().eq("user_id", userId);

    const ageMs = Date.now() - new Date(pending.created_at).getTime();
    if (ageMs > NONCE_TTL_SECONDS * 1000) {
      return json({ ok: false, m: "Verification timed out - start again" });
    }

    const url = `${HAS_JOINED}?username=${encodeURIComponent(pending.username)}`
      + `&serverId=${encodeURIComponent(pending.nonce)}`;

    const res = await fetch(url);

    // 204 / empty body = Mojang has no record of that join.
    if (res.status !== 200) {
      return json({
        ok: false,
        m: "Mojang did not confirm the login. Are you signed in with that account?",
      });
    }

    let profile: { id?: string; name?: string };
    try {
      profile = await res.json();
    } catch {
      return json({ ok: false, m: "Mojang did not confirm the login." });
    }

    if (!profile?.id || !profile?.name) {
      return json({ ok: false, m: "Mojang did not confirm the login." });
    }

    // Paranoia: Mojang should echo the same name we asked about.
    if (profile.name.toLowerCase() !== pending.username.toLowerCase()) {
      return json({ ok: false, m: "That session belongs to a different account." });
    }

    // Write the link through the definer RPC, which enforces "one Minecraft
    // account per profile" and refuses names already verified by someone else.
    const { data: applied, error: applyErr } = await admin.rpc(
      "apply_minecraft_link",
      {
        target: userId,
        p_uuid: dashUuid(profile.id),
        p_name: profile.name,
        p_premium: true,
      },
    );

    if (applyErr) {
      return json({ ok: false, m: "That account is already linked to someone else." });
    }

    return json({ ok: true, name: profile.name, uuid: dashUuid(profile.id), applied });
  }

  return json({ ok: false, m: "Unknown step" }, 400);
});
