-- ===========================================================================
--  BLUE CLIENT - FRIENDS SYSTEM DATABASE SCHEMA
--  Run this ONCE in the Supabase SQL Editor (see README-BACKEND.md, Step 6).
--  Safe to re-run: every statement is written to be idempotent.
-- ===========================================================================
--
--  SECURITY MODEL - READ THIS BEFORE CHANGING ANYTHING
--  ---------------------------------------------------
--  The Minecraft client ships with the *publishable* key baked into the jar.
--  Anyone can extract it and call this database directly with their own
--  scripts. That is expected and supported by Supabase's design.
--
--  Therefore: the ONLY thing protecting user data is Row Level Security.
--  Every table below has RLS enabled and every policy assumes the caller is
--  hostile. Never add a policy like `using (true)` to a table with private
--  data, and never ship the service_role key inside the client.
--
--  The rules that MUST hold no matter what a malicious client sends:
--    1. You cannot read someone's email / private presence unless allowed.
--    2. You cannot create a friendship without the other side accepting.
--    3. A blocked user cannot message, request, or see private presence.
--    4. You cannot forge rows that claim to be from another user.
-- ===========================================================================


-- ---------------------------------------------------------------------------
-- 0. EXTENSIONS
-- ---------------------------------------------------------------------------
create extension if not exists "pgcrypto";   -- gen_random_uuid()


-- ===========================================================================
-- 1. PROFILES
-- ---------------------------------------------------------------------------
-- One row per Blue Client account, linked 1:1 to Supabase's auth.users.
--
--   id            same uuid as auth.users.id. Deleting the auth user deletes
--                 the profile (on delete cascade), which cascades onwards to
--                 friendships, requests and blocks.
--   username      the name other players type to find you. Case is PRESERVED
--                 for display ("BlueDev") ...
--   username_low  ...but uniqueness and search use this lowercased copy, so
--                 "BlueDev" and "bluedev" can never both exist.
--   last_seen     updated by a heartbeat while the game is open.
--   server_name   the server the player is currently on, or null in menus.
--                 Whether anyone may READ it is decided by settings + RLS.
-- ===========================================================================
create table if not exists public.profiles (
   id            uuid primary key references auth.users(id) on delete cascade,
   username      text not null,
   username_low  text not null,
   created_at    timestamptz not null default now(),
   last_seen     timestamptz not null default now(),
   is_online     boolean not null default false,
   server_name   text,

   -- A username must be 3-16 chars of letters/digits/underscore.
   -- Enforced in the DATABASE, not just the client, because the client lies.
   constraint profiles_username_format
      check (username ~ '^[A-Za-z0-9_]{3,16}$'),

   -- username_low must genuinely be the lowercase of username.
   constraint profiles_username_low_matches
      check (username_low = lower(username)),

   -- Server names are free text; cap the length so nobody stores a novel.
   constraint profiles_server_len
      check (server_name is null or char_length(server_name) <= 64)
);

-- THE uniqueness guarantee for usernames (case-insensitive).
create unique index if not exists profiles_username_low_key
   on public.profiles (username_low);

-- Makes "search users by prefix" fast: text_pattern_ops is what lets
-- Postgres use an index for `username_low like 'blue%'`.
create index if not exists profiles_username_low_prefix
   on public.profiles (username_low text_pattern_ops);


-- ===========================================================================
-- 2. SETTINGS  (privacy)
-- ---------------------------------------------------------------------------
-- One row per user. Created automatically with the profile (trigger below),
-- so the app can always assume it exists.
--
-- Every visibility column uses the same three-value vocabulary:
--     'everyone'  - any logged-in Blue Client user
--     'friends'   - only accepted friends
--     'nobody'    - nobody but yourself
--
-- These are enforced SERVER-SIDE by the RLS policies further down. Changing
-- them in the client does not change what the client is *allowed* to fetch.
-- ===========================================================================
create table if not exists public.settings (
   id                      uuid primary key references public.profiles(id) on delete cascade,
   allow_requests_from     text not null default 'everyone',
   show_online_status      text not null default 'friends',
   show_current_server     text not null default 'friends',
   show_last_seen          text not null default 'friends',
   presence_notifications  boolean not null default true,

   constraint settings_requests_valid
      check (allow_requests_from in ('everyone', 'friends_of_friends', 'nobody')),
   constraint settings_online_valid
      check (show_online_status  in ('everyone', 'friends', 'nobody')),
   constraint settings_server_valid
      check (show_current_server in ('everyone', 'friends', 'nobody')),
   constraint settings_seen_valid
      check (show_last_seen      in ('everyone', 'friends', 'nobody'))
);


-- ===========================================================================
-- 3. BLOCKS
-- ---------------------------------------------------------------------------
-- blocker_id blocked blocked_id. One-directional and PRIVATE: the blocked
-- user is never told, and cannot read this table.
-- ===========================================================================
create table if not exists public.blocks (
   blocker_id  uuid not null references public.profiles(id) on delete cascade,
   blocked_id  uuid not null references public.profiles(id) on delete cascade,
   created_at  timestamptz not null default now(),

   -- Composite PK: blocking the same person twice is impossible.
   primary key (blocker_id, blocked_id),

   -- You cannot block yourself.
   constraint blocks_not_self check (blocker_id <> blocked_id)
);

-- "who has blocked me?" needs its own index (the PK only helps the other way).
create index if not exists blocks_blocked_idx on public.blocks (blocked_id);


-- ===========================================================================
-- 4. FRIENDSHIPS
-- ---------------------------------------------------------------------------
-- An ACCEPTED, mutual friendship. Stored as ONE row, not two.
--
-- The classic bug here is ending up with both (A,B) and (B,A), which makes
-- "am I friends with X" return duplicates and "remove friend" leave a
-- half-friendship behind. We prevent it structurally: user_a is ALWAYS the
-- numerically smaller uuid. The check constraint makes the database reject
-- any row that ignores the rule, so the ordering cannot drift.
-- ===========================================================================
create table if not exists public.friendships (
   user_a      uuid not null references public.profiles(id) on delete cascade,
   user_b      uuid not null references public.profiles(id) on delete cascade,
   created_at  timestamptz not null default now(),

   primary key (user_a, user_b),

   -- Enforces the canonical ordering AND rules out self-friendship in one go.
   constraint friendships_ordered check (user_a < user_b)
);

create index if not exists friendships_user_b_idx on public.friendships (user_b);


-- ===========================================================================
-- 5. FRIEND REQUESTS
-- ---------------------------------------------------------------------------
-- A pending request from sender_id to receiver_id.
--
-- Rows are DELETED when accepted / declined / cancelled rather than kept with
-- a status column. That keeps the table tiny and makes "one pending request
-- per direction" a simple unique constraint instead of a partial index.
-- ===========================================================================
create table if not exists public.friend_requests (
   id           uuid primary key default gen_random_uuid(),
   sender_id    uuid not null references public.profiles(id) on delete cascade,
   receiver_id  uuid not null references public.profiles(id) on delete cascade,
   created_at   timestamptz not null default now(),

   -- No duplicate pending requests in the same direction.
   constraint friend_requests_unique_pair unique (sender_id, receiver_id),

   -- No sending a friend request to yourself.
   constraint friend_requests_not_self check (sender_id <> receiver_id)
);

create index if not exists friend_requests_receiver_idx
   on public.friend_requests (receiver_id);
create index if not exists friend_requests_sender_idx
   on public.friend_requests (sender_id);


-- ===========================================================================
-- 6. HELPER FUNCTIONS
-- ---------------------------------------------------------------------------
-- These are used inside RLS policies. They are all:
--
--   * security definer - they read tables the CALLER may not read directly.
--     Without this, "are we friends?" inside a policy would itself be
--     filtered by RLS and always return false.
--   * search_path pinned to an empty string - this is a REQUIRED hardening
--     step for security definer functions. Without it, a user could create
--     their own `public.friendships` table earlier in their search path and
--     trick the function into reading it.
-- ===========================================================================

-- Are these two users friends? Order of arguments does not matter.
create or replace function public.are_friends(u1 uuid, u2 uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
   -- Same anti-probing guard as block_exists() - see the note there.
   if auth.uid() is not null and auth.uid() <> u1 and auth.uid() <> u2 then
      return false;
   end if;

   return exists (
      select 1 from public.friendships f
      where f.user_a = least(u1, u2)
        and f.user_b = greatest(u1, u2)
   );
end;
$$;

-- Has EITHER user blocked the other? Blocking is one-directional to create,
-- but its EFFECT is mutual: once either side blocks, all interaction stops.
create or replace function public.block_exists(u1 uuid, u2 uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
   -- ANTI-PROBING GUARD (applies to all three relationship helpers).
   -- These functions must be callable by `authenticated`, because RLS policy
   -- expressions are evaluated as the calling user - revoking EXECUTE breaks
   -- every policy that uses them. But a function that answers "has X blocked
   -- Y?" for ARBITRARY X and Y would let a hostile client map the whole
   -- social graph. So: you may only ask about pairs that include yourself.
   -- auth.uid() is null for server-side/superuser calls, which we allow.
   if auth.uid() is not null and auth.uid() <> u1 and auth.uid() <> u2 then
      return false;
   end if;

   return exists (
      select 1 from public.blocks b
      where (b.blocker_id = u1 and b.blocked_id = u2)
         or (b.blocker_id = u2 and b.blocked_id = u1)
   );
end;
$$;

-- Do these two share at least one mutual friend? Used for the
-- 'friends_of_friends' request privacy level.
create or replace function public.shares_friend(u1 uuid, u2 uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
   -- Same anti-probing guard as block_exists() - see the note there.
   if auth.uid() is not null and auth.uid() <> u1 and auth.uid() <> u2 then
      return false;
   end if;

   return exists (
      with f1 as (
         select case when user_a = u1 then user_b else user_a end as other
         from public.friendships where user_a = u1 or user_b = u1
      ),
      f2 as (
         select case when user_a = u2 then user_b else user_a end as other
         from public.friendships where user_a = u2 or user_b = u2
      )
      select 1 from f1 join f2 on f1.other = f2.other
   );
end;
$$;

-- What is `owner`'s allow_requests_from setting?
--
-- WHY THIS FUNCTION EXISTS (subtle, and it bit us during testing):
-- The friend_requests INSERT policy needs to read the RECEIVER's settings
-- row. If the policy queried public.settings directly, that query would
-- itself be subject to the settings RLS policy - which only lets you read
-- YOUR OWN row. The subquery would return no rows, the WITH CHECK would
-- evaluate to NULL, and Postgres treats NULL as false, so EVERY friend
-- request would be rejected. Routing it through a security definer function
-- bypasses the inner RLS check safely, because the function returns nothing
-- except the one setting value the policy needs.
create or replace function public.request_policy_of(owner uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
   select coalesce(
      (select s.allow_requests_from from public.settings s where s.id = owner),
      'everyone'
   );
$$;

-- May `viewer` see the given privacy-controlled field of `owner`?
-- Central place for the everyone / friends / nobody vocabulary.
create or replace function public.can_view(viewer uuid, owner uuid, field text)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
   level text;
begin
   -- You can always see your own data.
   if viewer = owner then
      return true;
   end if;

   -- A block hides everything, in both directions, always.
   if public.block_exists(viewer, owner) then
      return false;
   end if;

   select case field
             when 'online' then s.show_online_status
             when 'server' then s.show_current_server
             when 'seen'   then s.show_last_seen
          end
     into level
     from public.settings s
    where s.id = owner;

   -- No settings row = fall back to the safest useful default.
   if level is null then
      level := 'friends';
   end if;

   return case level
             when 'everyone' then true
             when 'friends'  then public.are_friends(viewer, owner)
             else false
          end;
end;
$$;


-- ===========================================================================
-- 7. TRIGGER - give every new profile a settings row
-- ---------------------------------------------------------------------------
-- Guarantees `settings` always has a matching row, so the client never has to
-- handle "settings missing" and can_view() always finds a level.
-- ===========================================================================
create or replace function public.handle_new_profile()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
   insert into public.settings (id) values (new.id)
   on conflict (id) do nothing;
   return new;
end;
$$;

drop trigger if exists on_profile_created on public.profiles;
create trigger on_profile_created
   after insert on public.profiles
   for each row execute function public.handle_new_profile();


-- ===========================================================================
-- 8. RPC - accept_friend_request
-- ---------------------------------------------------------------------------
-- Accepting is TWO changes that must both happen or neither: delete the
-- request, and create the friendship. Doing that from the client in two
-- calls means a crash between them leaves the data broken.
--
-- So it is one function, which is one transaction. It also re-checks every
-- rule server-side, because the client calling it may be hostile.
-- ===========================================================================
create or replace function public.accept_friend_request(request_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
   req public.friend_requests%rowtype;
   me  uuid := auth.uid();
begin
   if me is null then
      raise exception 'not authenticated';
   end if;

   select * into req from public.friend_requests where id = request_id;

   if not found then
      raise exception 'request not found';
   end if;

   -- ONLY the receiver may accept. The sender cannot accept their own.
   if req.receiver_id <> me then
      raise exception 'not your request';
   end if;

   -- If a block appeared after the request was sent, refuse.
   if public.block_exists(req.sender_id, req.receiver_id) then
      delete from public.friend_requests where id = request_id;
      raise exception 'blocked';
   end if;

   insert into public.friendships (user_a, user_b)
   values (least(req.sender_id, req.receiver_id),
           greatest(req.sender_id, req.receiver_id))
   on conflict do nothing;

   -- Remove the request, and any mirrored request from the other direction
   -- (both people can send at once; accepting either resolves both).
   delete from public.friend_requests
   where (sender_id = req.sender_id   and receiver_id = req.receiver_id)
      or (sender_id = req.receiver_id and receiver_id = req.sender_id);
end;
$$;


-- ===========================================================================
-- 9. RPC - block_user
-- ---------------------------------------------------------------------------
-- Blocking must also DESTROY the existing relationship, otherwise a blocked
-- ex-friend keeps friend-level visibility. One transaction again.
-- ===========================================================================
create or replace function public.block_user(target uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
   me uuid := auth.uid();
begin
   if me is null then
      raise exception 'not authenticated';
   end if;
   if me = target then
      raise exception 'cannot block yourself';
   end if;
   if not exists (select 1 from public.profiles where id = target) then
      raise exception 'no such user';
   end if;

   insert into public.blocks (blocker_id, blocked_id)
   values (me, target)
   on conflict do nothing;

   -- End the friendship, in whichever order it is stored.
   delete from public.friendships
   where user_a = least(me, target) and user_b = greatest(me, target);

   -- Drop any pending requests in either direction.
   delete from public.friend_requests
   where (sender_id = me and receiver_id = target)
      or (sender_id = target and receiver_id = me);
end;
$$;


-- ===========================================================================
-- 10. RPC - search_users
-- ---------------------------------------------------------------------------
-- Why an RPC instead of letting the client SELECT from profiles?
--
-- Because search must NOT leak the private columns. This function returns
-- only id + username, hides anyone who blocked you (or whom you blocked),
-- hides yourself, and hard-caps the row count so nobody can dump the whole
-- user table with `limit=100000`.
-- ===========================================================================
create or replace function public.search_users(q text)
returns table (id uuid, username text)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
   me    uuid := auth.uid();
   clean text;
begin
   if me is null then
      raise exception 'not authenticated';
   end if;

   clean := lower(trim(coalesce(q, '')));

   -- Require 2 characters, so nobody enumerates everyone with "a".
   if char_length(clean) < 2 then
      return;
   end if;

   -- Escape LIKE wildcards so a search for "_" is literal.
   clean := replace(replace(clean, '\', '\\'), '%', '\%');
   clean := replace(clean, '_', '\_');

   return query
      select p.id, p.username
      from public.profiles p
      where p.username_low like clean || '%' escape '\'
        and p.id <> me
        and not public.block_exists(me, p.id)
      order by p.username_low
      limit 20;
end;
$$;


-- ===========================================================================
-- 11. RPC - heartbeat
-- ---------------------------------------------------------------------------
-- Updates presence in one round trip. Kept as an RPC so the client never
-- needs UPDATE rights on columns beyond these three.
-- ===========================================================================
create or replace function public.heartbeat(online boolean, server text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
   me uuid := auth.uid();
begin
   if me is null then
      raise exception 'not authenticated';
   end if;

   update public.profiles
      set is_online   = online,
          last_seen   = now(),
          server_name = case when online then left(server, 64) else null end
    where id = me;
end;
$$;


-- ===========================================================================
-- 12. RPC - get_friends
-- ---------------------------------------------------------------------------
-- Returns the friend list WITH privacy already applied per-friend, so the
-- client cannot see a field it is not allowed to see - the filtering happens
-- here, on the server, not in the UI.
-- ===========================================================================
create or replace function public.get_friends()
returns table (
   id          uuid,
   username    text,
   is_online   boolean,
   server_name text,
   last_seen   timestamptz
)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
   me uuid := auth.uid();
begin
   if me is null then
      raise exception 'not authenticated';
   end if;

   return query
      select p.id,
             p.username,
             case when public.can_view(me, p.id, 'online') then p.is_online   else false end,
             case when public.can_view(me, p.id, 'server') then p.server_name else null  end,
             case when public.can_view(me, p.id, 'seen')   then p.last_seen   else null  end
      from public.friendships f
      join public.profiles p
        on p.id = case when f.user_a = me then f.user_b else f.user_a end
      where f.user_a = me or f.user_b = me
      order by 3 desc, 2 asc;   -- online first, then alphabetical
end;
$$;


-- ===========================================================================
-- 13. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------------
-- Enable RLS on every table. With RLS on and no policy, access is DENIED by
-- default - which is the behaviour we want as a starting point.
-- ===========================================================================
alter table public.profiles        enable row level security;
alter table public.settings        enable row level security;
alter table public.blocks          enable row level security;
alter table public.friendships     enable row level security;
alter table public.friend_requests enable row level security;


-- --- PROFILES --------------------------------------------------------------

-- Read: any logged-in user may read profile ROWS (needed to show usernames on
-- friend lists and requests). The private columns are protected by the fact
-- that presence is only ever delivered through get_friends() / can_view().
--
-- NOTE: a determined user CAN read is_online straight off this table. That is
-- an accepted trade-off - "is this person online" is low-sensitivity, and the
-- alternative (a column-level security setup) is far more complex. Truly
-- private data (email) lives in auth.users, which is NOT readable here.
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles
   for select to authenticated
   using (not public.block_exists(auth.uid(), id));

-- Insert: you may only create YOUR OWN profile row.
drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles
   for insert to authenticated
   with check (auth.uid() = id);

-- Update: you may only update your own row.
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles
   for update to authenticated
   using (auth.uid() = id)
   with check (auth.uid() = id);


-- --- SETTINGS --------------------------------------------------------------
-- Strictly private: only the owner can ever see or change their settings.
drop policy if exists settings_select on public.settings;
create policy settings_select on public.settings
   for select to authenticated using (auth.uid() = id);

drop policy if exists settings_insert on public.settings;
create policy settings_insert on public.settings
   for insert to authenticated with check (auth.uid() = id);

drop policy if exists settings_update on public.settings;
create policy settings_update on public.settings
   for update to authenticated
   using (auth.uid() = id) with check (auth.uid() = id);


-- --- BLOCKS ----------------------------------------------------------------
-- Only the blocker sees their own block list. The blocked user must never be
-- able to detect the block, so there is deliberately NO policy letting them
-- read rows where blocked_id = auth.uid().
drop policy if exists blocks_select on public.blocks;
create policy blocks_select on public.blocks
   for select to authenticated using (auth.uid() = blocker_id);

drop policy if exists blocks_insert on public.blocks;
create policy blocks_insert on public.blocks
   for insert to authenticated
   with check (auth.uid() = blocker_id and blocker_id <> blocked_id);

-- Unblocking = deleting your own row.
drop policy if exists blocks_delete on public.blocks;
create policy blocks_delete on public.blocks
   for delete to authenticated using (auth.uid() = blocker_id);


-- --- FRIENDSHIPS -----------------------------------------------------------
-- Read your own friendships only.
drop policy if exists friendships_select on public.friendships;
create policy friendships_select on public.friendships
   for select to authenticated
   using (auth.uid() = user_a or auth.uid() = user_b);

-- There is deliberately NO insert policy. Friendships are created ONLY by
-- accept_friend_request(), which verifies a real request existed. This is
-- what makes it impossible to add yourself to someone's friend list.

-- Either party may remove the friendship.
drop policy if exists friendships_delete on public.friendships;
create policy friendships_delete on public.friendships
   for delete to authenticated
   using (auth.uid() = user_a or auth.uid() = user_b);


-- --- FRIEND REQUESTS -------------------------------------------------------
-- You can see requests you sent or received.
drop policy if exists friend_requests_select on public.friend_requests;
create policy friend_requests_select on public.friend_requests
   for select to authenticated
   using (auth.uid() = sender_id or auth.uid() = receiver_id);

-- Sending a request. This single policy enforces, server-side:
--   * you can only send AS yourself
--   * not to yourself (also a table constraint)
--   * not if either side has blocked the other
--   * not if you are already friends
--   * and it must satisfy the receiver's allow_requests_from setting
drop policy if exists friend_requests_insert on public.friend_requests;
create policy friend_requests_insert on public.friend_requests
   for insert to authenticated
   with check (
      auth.uid() = sender_id
      and sender_id <> receiver_id
      and not public.block_exists(sender_id, receiver_id)
      and not public.are_friends(sender_id, receiver_id)
      and case public.request_policy_of(receiver_id)
             when 'everyone'           then true
             when 'friends_of_friends' then public.shares_friend(sender_id, receiver_id)
             else false
          end
   );

-- Delete covers three user actions at once:
--   sender deleting   = cancelling their request
--   receiver deleting = declining it
--   (accepting goes through accept_friend_request instead)
drop policy if exists friend_requests_delete on public.friend_requests;
create policy friend_requests_delete on public.friend_requests
   for delete to authenticated
   using (auth.uid() = sender_id or auth.uid() = receiver_id);


-- ===========================================================================
-- 14. PERMISSIONS
-- ---------------------------------------------------------------------------
-- Let logged-in users call the RPCs. RLS still applies inside them for the
-- tables they touch, except where the function is security definer (which is
-- exactly why each one re-checks auth.uid() itself).
-- ===========================================================================
grant execute on function public.accept_friend_request(uuid) to authenticated;
grant execute on function public.block_user(uuid)            to authenticated;
grant execute on function public.search_users(text)          to authenticated;
grant execute on function public.heartbeat(boolean, text)    to authenticated;
grant execute on function public.get_friends()               to authenticated;
grant execute on function public.request_policy_of(uuid)     to authenticated;

-- Revoke from anon AND from public: every Friends feature requires login.
--
-- IMPORTANT: Postgres grants EXECUTE on new functions to the special role
-- PUBLIC automatically. Revoking only from `anon` therefore does NOTHING -
-- anon still inherits the right through PUBLIC. Both revokes are required.
revoke execute on function public.accept_friend_request(uuid) from public, anon;
revoke execute on function public.block_user(uuid)            from public, anon;
revoke execute on function public.search_users(text)          from public, anon;
revoke execute on function public.heartbeat(boolean, text)    from public, anon;
revoke execute on function public.get_friends()               from public, anon;
revoke execute on function public.request_policy_of(uuid)     from public, anon;

-- The policy helpers are revoked from anon, but MUST stay executable by
-- `authenticated`: an RLS policy expression runs as the calling user, so
-- revoking EXECUTE from authenticated would make every policy that calls
-- them fail with "permission denied for function". They are safe to expose
-- because each one carries the anti-probing guard (see block_exists).
revoke execute on function public.are_friends(uuid, uuid)     from public, anon;
revoke execute on function public.block_exists(uuid, uuid)    from public, anon;
revoke execute on function public.shares_friend(uuid, uuid)   from public, anon;
revoke execute on function public.can_view(uuid, uuid, text)  from public, anon;
revoke execute on function public.request_policy_of(uuid)     from public, anon;

grant execute on function public.are_friends(uuid, uuid)      to authenticated;
grant execute on function public.block_exists(uuid, uuid)     to authenticated;
grant execute on function public.shares_friend(uuid, uuid)    to authenticated;
grant execute on function public.can_view(uuid, uuid, text)   to authenticated;
grant execute on function public.request_policy_of(uuid)      to authenticated;

-- Re-grant to authenticated last, so the revokes above cannot clobber them.
grant execute on function public.accept_friend_request(uuid) to authenticated;
grant execute on function public.block_user(uuid)            to authenticated;
grant execute on function public.search_users(text)          to authenticated;
grant execute on function public.heartbeat(boolean, text)    to authenticated;
grant execute on function public.get_friends()               to authenticated;


-- ===========================================================================
-- DONE.
-- Verify with:  select count(*) from public.profiles;
-- It should return 0 and NOT an error.
-- ===========================================================================
