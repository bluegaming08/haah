-- ===========================================================================
--  BLUE CLIENT - SCHEMA v3  (release v21)
-- ---------------------------------------------------------------------------
--  Run AFTER schema.sql and schema_v2.sql. Safe to run twice.
--
--  Adds: Blue+ tier, redeem codes, posts, tiered limits, coloured nameplates,
--  presence modes, server invites, followers leaderboard, 3-accounts-per-IP,
--  auto-follow Blue and Cyan, and ONE batched sync() RPC.
--
--  EGRESS IS THE SCARCE RESOURCE (5 GB/month, org-wide). Every function here
--  returns SHORT KEYS ('u' not 'username'), strips nulls, and sync() returns
--  only rows changed since the caller's cursor.
-- ===========================================================================

create schema if not exists private;

-- ===========================================================================
-- 1. TIER + PROFILE COLUMNS
-- ===========================================================================

alter table public.profiles
   add column if not exists plus_since      timestamptz,
   add column if not exists plus_until      timestamptz,
   add column if not exists plus_permanent  boolean not null default false,
   add column if not exists name_color      text,
   add column if not exists presence        text not null default 'online',
   add column if not exists verified        boolean not null default false,
   add column if not exists verified_forced boolean not null default false,
   add column if not exists follower_count  integer not null default 0,
   add column if not exists following_count integer not null default 0,
   add column if not exists friend_count    integer not null default 0,
   add column if not exists skin_name       text;

-- presence: 'online' = visible + notifications
--           'dnd'    = visible, red dot, NO notifications
--           'offline'= appears offline, never shows what you are playing
alter table public.profiles drop constraint if exists profiles_presence_valid;
alter table public.profiles add constraint profiles_presence_valid
   check (presence in ('online', 'dnd', 'offline'));

-- Social avatar skin source: any Minecraft username. Cosmetic only, never
-- implies ownership - the verified tick still comes from mc_verified.
alter table public.profiles drop constraint if exists profiles_skin_name_valid;
alter table public.profiles add constraint profiles_skin_name_valid
   check (skin_name is null or skin_name ~ '^[A-Za-z0-9_]{3,16}$');

create index if not exists profiles_follower_count_idx
   on public.profiles (follower_count desc) where follower_count > 0;


-- is_plus(): single source of truth for "does this user have Blue+".
create or replace function public.is_plus(target uuid)
returns boolean language sql stable security definer set search_path = '' as $$
   select coalesce(
      (select p.plus_permanent or (p.plus_until is not null and p.plus_until > now())
       from public.profiles p where p.id = target), false);
$$;

grant execute on function public.is_plus(uuid) to authenticated;


-- Tier limits live HERE, not in Java: changing a number changes it for every
-- client instantly, old jars included.
create or replace function public.limit_of(target uuid, key text)
returns integer language sql stable security definer set search_path = '' as $$
   select case when public.is_plus(target) then
            case key
               when 'about' then 100 when 'status' then 40 when 'post' then 100
               when 'friends' then 40 when 'following' then 50
               when 'posts_hour' then 4 else 0 end
          else
            case key
               when 'about' then 50 when 'status' then 25 when 'post' then 25
               when 'friends' then 15 when 'following' then 15
               when 'posts_hour' then 2 else 0 end
          end;
$$;

grant execute on function public.limit_of(uuid, text) to authenticated;


-- ===========================================================================
-- 2. REDEEM CODES  (one-time use)
-- ---------------------------------------------------------------------------
-- Make one from the SQL Editor:
--    insert into public.redeem_codes (code, kind, plus_days, note)
--    values ('SUMMER2026', 'plus', 30, 'june promo');
--    insert into public.redeem_codes (code, kind, value)
--    values ('HELPER01', 'badge', 'helper');
-- ===========================================================================

create table if not exists public.redeem_codes (
   code        text primary key,
   kind        text not null,        -- 'plus' | 'badge' | 'cosmetic'
   value       text,                 -- badge code / cosmetic id; null for plus
   plus_days   integer,              -- null or 0 => permanent
   note        text,                 -- for you; never shown to players
   created_at  timestamptz not null default now(),
   expires_at  timestamptz,          -- optional: the code itself stops working
   redeemed_by uuid references public.profiles(id) on delete set null,
   redeemed_at timestamptz,

   constraint redeem_kind_valid check (kind in ('plus', 'badge', 'cosmetic')),
   constraint redeem_code_shape check (code ~ '^[A-Z0-9_-]{4,32}$')
);

create index if not exists redeem_codes_unused_idx
   on public.redeem_codes (code) where redeemed_by is null;

insert into public.redeem_codes (code, kind, plus_days, note)
values ('CYANBLUEPLUS', 'plus', 0, 'launch code - permanent'),
       ('BLUEPLUS',     'plus', 0, 'launch code - permanent')
on conflict (code) do nothing;


-- redeem() - atomic and one-time.
--
-- The race that matters: two people submit the same code at the same instant.
-- "select then update" lets both through. We UPDATE with the unused-check in
-- the WHERE clause, so Postgres serialises it and exactly one row is claimed.
create or replace function public.redeem(p_code text)
returns json language plpgsql security definer set search_path = '' as $$
declare
   me      uuid := auth.uid();
   claimed public.redeem_codes%rowtype;
   b_id    text;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;

   p_code := upper(trim(p_code));

   update public.redeem_codes
      set redeemed_by = me, redeemed_at = now()
    where code = p_code
      and redeemed_by is null
      and (expires_at is null or expires_at > now())
   returning * into claimed;

   if claimed.code is null then
      -- "already used" and "never existed" deliberately give the same answer,
      -- so nobody can probe for which codes are real.
      return json_build_object('ok', false, 'm', 'Invalid or already used code');
   end if;

   if claimed.kind = 'plus' then
      update public.profiles
         set plus_since = coalesce(plus_since, now()),
             plus_permanent = plus_permanent
                              or claimed.plus_days is null or claimed.plus_days = 0,
             plus_until = case
                when claimed.plus_days is null or claimed.plus_days = 0 then plus_until
                -- stack onto whatever is left, never truncate it
                else greatest(coalesce(plus_until, now()), now())
                     + (claimed.plus_days || ' days')::interval
             end
       where id = me;
      return json_build_object('ok', true, 'm', 'Blue+ activated', 'k', 'plus');

   elsif claimed.kind = 'badge' then
      select id into b_id from public.badges where id = claimed.value;
      if b_id is null then
         return json_build_object('ok', false, 'm', 'Code is broken - tell an admin');
      end if;
      insert into public.user_badges (user_id, badge_id) values (me, b_id)
      on conflict do nothing;
      return json_build_object('ok', true, 'm', 'Badge unlocked', 'k', 'badge');

   elsif claimed.kind = 'cosmetic' then
      insert into public.user_cosmetics (user_id, cosmetic_id) values (me, claimed.value)
      on conflict do nothing;
      return json_build_object('ok', true, 'm', 'Cosmetic unlocked', 'k', 'cosmetic');
   end if;

   return json_build_object('ok', false, 'm', 'Unknown code type');
end;
$$;

revoke all on function public.redeem(text) from public, anon;
grant execute on function public.redeem(text) to authenticated;


-- THE RLS TRAP, HIT FOR THE SECOND TIME (see README-NEXT-AGENT):
-- a subquery inside a policy is ITSELF filtered by the subquery table's own
-- RLS. `blocks_select` only lets you see rows where YOU are the blocker, so
-- "did they block me?" always came back empty and the policy passed everyone.
-- Route it through a security-definer helper that can see the whole table.
create or replace function public.blocked_me(other uuid)
returns boolean language sql stable security definer set search_path = '' as $$
   select exists (select 1 from public.blocks
                   where blocker_id = other and blocked_id = auth.uid());
$$;

grant execute on function public.blocked_me(uuid) to authenticated;

-- ===========================================================================
-- 3. POSTS  (public timeline, like X)
-- ===========================================================================

create table if not exists public.posts (
   id         uuid primary key default gen_random_uuid(),
   author_id  uuid not null references public.profiles(id) on delete cascade,
   body       text not null,
   created_at timestamptz not null default now(),
   constraint post_body_len check (char_length(body) between 1 and 100)
);

create index if not exists posts_author_idx on public.posts (author_id, created_at desc);
create index if not exists posts_recent_idx on public.posts (created_at desc);


-- Enforces BOTH the length limit and the per-hour rate limit for the
-- caller's tier. Free: 25 chars, 2/hour. Plus: 100 chars, 4/hour.
create or replace function public.create_post(p_body text)
returns json language plpgsql security definer set search_path = '' as $$
declare
   me uuid := auth.uid();
   max_len integer; per_hour integer; used integer; oldest timestamptz;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;

   p_body := trim(p_body);
   if p_body = '' then
      return json_build_object('ok', false, 'm', 'Post is empty');
   end if;

   max_len  := public.limit_of(me, 'post');
   per_hour := public.limit_of(me, 'posts_hour');

   -- Truncate rather than reject: the client already counts characters, so a
   -- rejection here would only ever mean a desync or a tampered client.
   p_body := left(p_body, max_len);

   select count(*), min(created_at) into used, oldest
     from public.posts
    where author_id = me and created_at > now() - interval '1 hour';

   if used >= per_hour then
      return json_build_object('ok', false,
         'm', 'Post limit reached (' || per_hour || '/hour).',
         'retry', greatest(0, extract(epoch from (oldest + interval '1 hour' - now()))::int));
   end if;

   insert into public.posts (author_id, body) values (me, p_body);
   return json_build_object('ok', true, 'left', per_hour - used - 1);
end;
$$;

revoke all on function public.create_post(text) from public, anon;
grant execute on function public.create_post(text) to authenticated;


create or replace function public.delete_post(p_id uuid)
returns boolean language sql security definer set search_path = '' as $$
   delete from public.posts where id = p_id and author_id = auth.uid() returning true;
$$;

revoke all on function public.delete_post(uuid) from public, anon;
grant execute on function public.delete_post(uuid) to authenticated;


-- Feed: people you follow, plus yourself. Short keys, capped at 50.
create or replace function public.get_feed(before timestamptz default null,
                                           limit_n integer default 30)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(feed)), '[]'::json)
   from (
      select p.id as i, pr.username as u, p.body as b,
             extract(epoch from p.created_at)::bigint as t,
             pr.equipped_badge as bd, pr.name_color as c,
             public.is_plus(pr.id) as pl, pr.verified as v
        from public.posts p
        join public.profiles pr on pr.id = p.author_id
       where (before is null or p.created_at < before)
         and (p.author_id = auth.uid()
              or p.author_id in (select followee_id from public.follows
                                  where follower_id = auth.uid()))
         and not public.blocked_me(p.author_id)
       order by p.created_at desc
       limit least(coalesce(limit_n, 30), 50)
   ) feed;
$$;

grant execute on function public.get_feed(timestamptz, integer) to authenticated;


-- ===========================================================================
-- 4. CAPS AND COUNTERS  (triggers, not client-side checks)
-- ===========================================================================

-- Denormalised counters. Counting rows on every profile view would be the
-- most expensive query in the app; these keep it to a single column read.
create or replace function public.sync_follow_counts()
returns trigger language plpgsql security definer set search_path = '' as $$
declare target uuid; n integer;
begin
   if tg_op = 'INSERT' then
      update public.profiles set following_count = following_count + 1
       where id = new.follower_id;
      update public.profiles set follower_count = follower_count + 1
       where id = new.followee_id returning follower_count into n;
      target := new.followee_id;
   else
      update public.profiles set following_count = greatest(0, following_count - 1)
       where id = old.follower_id;
      update public.profiles set follower_count = greatest(0, follower_count - 1)
       where id = old.followee_id returning follower_count into n;
      target := old.followee_id;
   end if;

   -- Verified at 100 followers, LOST if they drop below - unless granted
   -- manually (verified_forced), which Blue and Cyan have.
   update public.profiles set verified = (verified_forced or coalesce(n, 0) >= 100)
    where id = target;
   return null;
end;
$$;

drop trigger if exists follows_counts on public.follows;
create trigger follows_counts after insert or delete on public.follows
   for each row execute function public.sync_follow_counts();


create or replace function public.sync_friend_counts()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if tg_op = 'INSERT' then
      update public.profiles set friend_count = friend_count + 1
       where id in (new.user_a, new.user_b);
   else
      update public.profiles set friend_count = greatest(0, friend_count - 1)
       where id in (old.user_a, old.user_b);
   end if;
   return null;
end;
$$;

drop trigger if exists friendships_counts on public.friendships;
create trigger friendships_counts after insert or delete on public.friendships
   for each row execute function public.sync_friend_counts();


-- Follow cap. Blue and Cyan are free follows and never count toward it,
-- otherwise the two auto-follows would eat 2 of everyone's 15 slots.
create or replace function public.enforce_follow_cap()
returns trigger language plpgsql security definer set search_path = '' as $$
declare cap integer; have integer;
begin
   if exists (select 1 from public.profiles
               where id = new.followee_id and username_low in ('blue', 'cyan')) then
      return new;
   end if;

   cap := public.limit_of(new.follower_id, 'following');
   select count(*) into have
     from public.follows f
     join public.profiles p on p.id = f.followee_id
    where f.follower_id = new.follower_id
      and p.username_low not in ('blue', 'cyan');

   if have >= cap then
      raise exception 'Following limit reached (%). Blue+ raises it to 50.', cap
         using errcode = 'check_violation';
   end if;
   return new;
end;
$$;

drop trigger if exists follows_cap on public.follows;
create trigger follows_cap before insert on public.follows
   for each row execute function public.enforce_follow_cap();


-- Friend cap is checked when the friendship ROW is created (i.e. on accept),
-- because that is the moment the friendship actually exists. Both sides
-- must have room.
create or replace function public.enforce_friend_cap()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
   cap_a integer := public.limit_of(new.user_a, 'friends');
   cap_b integer := public.limit_of(new.user_b, 'friends');
   n_a integer; n_b integer;
begin
   select friend_count into n_a from public.profiles where id = new.user_a;
   select friend_count into n_b from public.profiles where id = new.user_b;
   if coalesce(n_a, 0) >= cap_a then
      raise exception 'Friend limit reached (%).', cap_a using errcode = 'check_violation';
   end if;
   if coalesce(n_b, 0) >= cap_b then
      raise exception 'That player''s friend list is full.' using errcode = 'check_violation';
   end if;
   return new;
end;
$$;

drop trigger if exists friendships_cap on public.friendships;
create trigger friendships_cap before insert on public.friendships
   for each row execute function public.enforce_friend_cap();


-- Backfill the counters for anyone who existed before this schema ran.
update public.profiles p set
   follower_count  = (select count(*) from public.follows where followee_id = p.id),
   following_count = (select count(*) from public.follows where follower_id  = p.id),
   friend_count    = (select count(*) from public.friendships
                       where user_a = p.id or user_b = p.id);

update public.profiles set verified = true where verified_forced or follower_count >= 100;


-- ===========================================================================
-- 5. COLOURED NAMEPLATES  (Blue+ only)
-- ---------------------------------------------------------------------------
-- Compact JSON, validated here so a tampered client cannot reach the renderer
-- with anything unexpected:
--    {"a":"#2FA5FF","b":"#FFD600","g":1,"bo":1,"it":0}
--    a=colour/gradient start, b=gradient end, g=gradient, bo=bold, it=italic
-- ===========================================================================

create or replace function public.set_name_color(p_json text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); j json;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   if not public.is_plus(me) then
      return json_build_object('ok', false, 'm', 'Coloured names are a Blue+ perk');
   end if;

   if p_json is null or trim(p_json) = '' then
      update public.profiles set name_color = null where id = me;
      return json_build_object('ok', true);
   end if;

   if char_length(p_json) > 120 then
      return json_build_object('ok', false, 'm', 'Colour data too long');
   end if;

   begin
      j := p_json::json;
   exception when others then
      return json_build_object('ok', false, 'm', 'Colour data is not valid');
   end;

   -- Hex only. This is what stops a crafted value reaching the renderer.
   if (j->>'a') is null or (j->>'a') !~ '^#[0-9A-Fa-f]{6}$' then
      return json_build_object('ok', false, 'm', 'Bad primary colour');
   end if;
   if (j->>'b') is not null and (j->>'b') !~ '^#[0-9A-Fa-f]{6}$' then
      return json_build_object('ok', false, 'm', 'Bad gradient colour');
   end if;

   update public.profiles set name_color = p_json where id = me;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.set_name_color(text) from public, anon;
grant execute on function public.set_name_color(text) to authenticated;


-- Losing Blue+ must also lose the colour, or the perk outlives the expiry.
create or replace function public.clear_expired_plus()
returns void language sql security definer set search_path = '' as $$
   update public.profiles set name_color = null
    where name_color is not null and not plus_permanent
      and (plus_until is null or plus_until <= now());
$$;

grant execute on function public.clear_expired_plus() to authenticated;


-- Social skin: any Minecraft username, purely cosmetic.
create or replace function public.set_skin_name(p_name text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   if p_name is null or trim(p_name) = '' then
      update public.profiles set skin_name = null where id = me;
      return json_build_object('ok', true);
   end if;
   p_name := trim(p_name);
   if p_name !~ '^[A-Za-z0-9_]{3,16}$' then
      return json_build_object('ok', false, 'm', 'Not a valid Minecraft name');
   end if;
   update public.profiles set skin_name = p_name where id = me;
   return json_build_object('ok', true, 'n', p_name);
end;
$$;

revoke all on function public.set_skin_name(text) from public, anon;
grant execute on function public.set_skin_name(text) to authenticated;


-- ===========================================================================
-- 5b. TIER-AWARE about/status  (replaces the v2 fixed-length versions)
-- ---------------------------------------------------------------------------
-- schema_v2 hardcoded CHECK (about <= 50) and (status <= 40) on the table,
-- which would stop a Blue+ user ever reaching 100 characters. Widen the
-- constraints to the Blue+ maximum and enforce the real per-tier limit in
-- the setters, where it can actually see who is calling.
-- ===========================================================================

alter table public.profiles drop constraint if exists profiles_about_len;
alter table public.profiles add constraint profiles_about_len
   check (about is null or char_length(about) <= 100);

alter table public.profiles drop constraint if exists profiles_status_len;
alter table public.profiles add constraint profiles_status_len
   check (status is null or char_length(status) <= 40);


drop function if exists public.set_about(text);
create or replace function public.set_about(p_about text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); cap integer;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   cap := public.limit_of(me, 'about');
   -- Truncate, never reject: the client counts characters too, so a rejection
   -- would only ever be a desync or a tampered client.
   update public.profiles set about = nullif(left(trim(coalesce(p_about,'')), cap), '')
    where id = me;
   return json_build_object('ok', true, 'cap', cap);
end;
$$;

revoke all on function public.set_about(text) from public, anon;
grant execute on function public.set_about(text) to authenticated;


drop function if exists public.set_status(text);
create or replace function public.set_status(p_status text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); cap integer;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   cap := public.limit_of(me, 'status');
   update public.profiles set status = nullif(left(trim(coalesce(p_status,'')), cap), '')
    where id = me;
   return json_build_object('ok', true, 'cap', cap);
end;
$$;

revoke all on function public.set_status(text) from public, anon;
grant execute on function public.set_status(text) to authenticated;


-- ===========================================================================
-- 6. PRESENCE + SERVER INVITES
-- ===========================================================================

create or replace function public.set_presence(p_mode text)
returns boolean language sql security definer set search_path = '' as $$
   update public.profiles set presence = p_mode
    where id = auth.uid() and p_mode in ('online', 'dnd', 'offline')
   returning true;
$$;

revoke all on function public.set_presence(text) from public, anon;
grant execute on function public.set_presence(text) to authenticated;


create table if not exists public.invites (
   id         uuid primary key default gen_random_uuid(),
   from_id    uuid not null references public.profiles(id) on delete cascade,
   to_id      uuid not null references public.profiles(id) on delete cascade,
   address    text not null,
   label      text,
   created_at timestamptz not null default now(),
   expires_at timestamptz not null default now() + interval '10 minutes',
   accepted   boolean not null default false,

   constraint invite_addr_len  check (char_length(address) between 3 and 120),
   constraint invite_label_len check (label is null or char_length(label) <= 40)
);

create index if not exists invites_to_idx
   on public.invites (to_id, created_at desc) where accepted = false;

-- Append-only send log, used ONLY for rate limiting. Kept separate from
-- `invites` because invites get deleted/replaced, which would erase the
-- very history the limiter needs.
create table if not exists public.invite_log (
   id      bigserial primary key,
   from_id uuid not null references public.profiles(id) on delete cascade,
   sent_at timestamptz not null default now()
);

create index if not exists invite_log_from_idx on public.invite_log (from_id, sent_at desc);

alter table public.invite_log enable row level security;
-- No policy: nobody reads it directly. send_invite() is security definer.
revoke all on table public.invite_log from public, anon, authenticated;


-- Friends only, respects DND/offline, rate limited so invites cannot be
-- turned into a spam channel.
create or replace function public.send_invite(target uuid, p_addr text, p_label text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); a uuid; b uuid; recent integer; mode text;
begin
   if me is null or target is null or me = target then
      return json_build_object('ok', false, 'm', 'Bad request');
   end if;

   a := least(me, target); b := greatest(me, target);
   if not exists (select 1 from public.friendships where user_a = a and user_b = b) then
      return json_build_object('ok', false, 'm', 'You can only invite friends');
   end if;

   select presence into mode from public.profiles where id = target;
   if mode = 'dnd' then
      return json_build_object('ok', false, 'm', 'That player has Do Not Disturb on');
   end if;
   if mode = 'offline' then
      return json_build_object('ok', false, 'm', 'That player is offline');
   end if;

   -- Rate limit from the LOG, not from `invites`.
   -- The bug this fixes: "one live invite per pair" deletes the previous
   -- invite, which also deleted the evidence the rate limiter counted - so
   -- the limit could never trigger. The log is append-only.
   select count(*) into recent from public.invite_log
    where from_id = me and sent_at > now() - interval '5 minutes';
   if recent >= 5 then
      return json_build_object('ok', false, 'm', 'Too many invites - slow down');
   end if;

   insert into public.invite_log (from_id) values (me);

   -- One live invite per pair: re-inviting replaces the old one.
   delete from public.invites where from_id = me and to_id = target and accepted = false;

   insert into public.invites (from_id, to_id, address, label)
   values (me, target, p_addr, nullif(left(coalesce(p_label, ''), 40), ''));

   return json_build_object('ok', true);
end;
$$;

revoke all on function public.send_invite(uuid, text, text) from public, anon;
grant execute on function public.send_invite(uuid, text, text) to authenticated;


create or replace function public.accept_invite(p_id uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare addr text;
begin
   update public.invites set accepted = true
    where id = p_id and to_id = auth.uid() and expires_at > now()
   returning address into addr;

   if addr is null then
      return json_build_object('ok', false, 'm', 'Invite expired');
   end if;
   return json_build_object('ok', true, 'a', addr);
end;
$$;

revoke all on function public.accept_invite(uuid) from public, anon;
grant execute on function public.accept_invite(uuid) to authenticated;


-- ===========================================================================
-- 7. LEADERBOARD  (top 5 most followed)
-- ---------------------------------------------------------------------------
-- Reads the denormalised counter via its index: 5 rows, not a count over
-- every follow in the database.
-- ===========================================================================

create or replace function public.leaderboard(limit_n integer default 5)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(lb)), '[]'::json)
   from (
      select p.username as u, p.follower_count as f, p.equipped_badge as bd,
             p.verified as v, p.name_color as c, public.is_plus(p.id) as pl
        from public.profiles p
       where p.follower_count > 0
       order by p.follower_count desc, p.username asc
       limit least(coalesce(limit_n, 5), 25)
   ) lb;
$$;

grant execute on function public.leaderboard(integer) to authenticated;


-- ===========================================================================
-- 8. 3 ACCOUNTS PER IP  +  AUTO-FOLLOW BLUE AND CYAN
-- ---------------------------------------------------------------------------
-- The IP is NEVER stored. We keep a salted SHA-256 hash: enough to count
-- accounts from one address, impossible to turn back into an address.
-- ===========================================================================

create table if not exists private.app_secrets (
   key text primary key, value text not null
);

-- CHANGE THIS ONCE before launch, then never again (changing it later
-- resets everyone's count):
--    update private.app_secrets set value = 'your-own-long-random-string'
--    where key = 'ip_salt';
insert into private.app_secrets (key, value)
values ('ip_salt', 'blue-client-' || gen_random_uuid()::text)
on conflict (key) do nothing;

create table if not exists private.ip_accounts (
   ip_hash    text not null,
   user_id    uuid not null references public.profiles(id) on delete cascade,
   created_at timestamptz not null default now(),
   primary key (ip_hash, user_id)
);

create index if not exists ip_accounts_hash_idx on private.ip_accounts (ip_hash);

-- Whitelist a household/school that legitimately needs more than 3:
--    insert into private.ip_whitelist (ip_hash, note)
--    select ip_hash, 'the smiths' from private.ip_accounts
--    where user_id = (select id from public.profiles where username_low = 'someone');
create table if not exists private.ip_whitelist (
   ip_hash  text primary key,
   note     text,
   added_at timestamptz not null default now()
);


create or replace function private.client_ip_hash()
returns text language plpgsql stable security definer set search_path = '' as $$
declare raw text; salt text;
begin
   -- Supabase puts the real client address first in x-forwarded-for.
   raw := trim(split_part(
      coalesce(current_setting('request.headers', true)::json->>'x-forwarded-for', ''),
      ',', 1));
   if raw = '' then
      return null;   -- no header (direct SQL, tests) => cannot tell, no limit
   end if;
   select value into salt from private.app_secrets where key = 'ip_salt';
   -- sha256() is built into Postgres 11+, so this needs no extension at all
   -- and behaves identically on Supabase and on a local test database.
   return encode(sha256((salt || raw)::bytea), 'hex');
end;
$$;


-- Called by the client right after signup.
create or replace function public.register_ip()
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); h text; used integer;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;

   h := private.client_ip_hash();
   if h is null then
      return json_build_object('ok', true);
   end if;

   if exists (select 1 from private.ip_whitelist where ip_hash = h) then
      insert into private.ip_accounts (ip_hash, user_id) values (h, me)
      on conflict do nothing;
      return json_build_object('ok', true);
   end if;

   select count(distinct user_id) into used
     from private.ip_accounts where ip_hash = h;

   if used >= 3 and not exists (select 1 from private.ip_accounts
                                 where ip_hash = h and user_id = me) then
      return json_build_object('ok', false,
         'm', 'This connection already has 3 Blue Client accounts.');
   end if;

   insert into private.ip_accounts (ip_hash, user_id) values (h, me)
   on conflict do nothing;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.register_ip() from public, anon;
grant execute on function public.register_ip() to authenticated;


-- ---------------------------------------------------------------------------
-- Auto-follow Blue and Cyan on signup.
--
-- Matched by USERNAME whenever they exist, so this works whether those
-- accounts registered before or after this schema ran (Cyan exists, Blue
-- does not yet - when Blue registers, the trigger below sets them up and
-- everyone who signs up afterwards follows them automatically).
--
-- Deliberately does not call follow_user(): the cap must not apply to the
-- freebies, and a brand-new account has nobody blocked.
-- ---------------------------------------------------------------------------
create or replace function public.auto_follow_staff()
returns trigger language plpgsql security definer set search_path = '' as $$
declare staff uuid;
begin
   for staff in select id from public.profiles
                 where username_low in ('blue', 'cyan') and id <> new.id
   loop
      insert into public.follows (follower_id, followee_id) values (new.id, staff)
      on conflict do nothing;
   end loop;
   return new;
end;
$$;

drop trigger if exists profiles_auto_follow on public.profiles;
create trigger profiles_auto_follow after insert on public.profiles
   for each row execute function public.auto_follow_staff();


-- New badges. Co-Founder is Cyan's; Verified is automatic at 100 followers;
-- Blue+ comes with the subscription.
-- colour is a signed ARGB int, matching the six seeded in schema_v2.
insert into public.badges (id, label, colour, priority, description) values
   ('co_founder', 'Co-Founder', -16711681, 95, 'Co-created Blue Client'),
   ('verified',   'Verified',   -13653761, 90, '100+ followers'),
   ('plus',       'Blue+',        -10752,  85, 'Blue+ supporter')
on conflict (id) do nothing;


-- Staff setup: every badge, verified forever, permanent Blue+.
-- Idempotent and safe to run before those accounts exist.
create or replace function public.setup_staff()
returns json language plpgsql security definer set search_path = '' as $$
declare found integer := 0; sid uuid; nm text;
begin
   for sid, nm in select id, username_low from public.profiles
                   where username_low in ('blue', 'cyan')
   loop
      found := found + 1;

      insert into public.user_badges (user_id, badge_id)
      select sid, b.id from public.badges b
      on conflict do nothing;

      update public.profiles
         set verified = true, verified_forced = true,
             plus_permanent = true, plus_since = coalesce(plus_since, now()),
             equipped_badge = coalesce(equipped_badge,
                                 case when nm = 'blue' then 'founder'
                                      else 'co_founder' end)
       where id = sid;

      -- Everyone who already registered should follow them too.
      insert into public.follows (follower_id, followee_id)
      select p.id, sid from public.profiles p
       where p.id <> sid and p.username_low not in ('blue', 'cyan')
      on conflict do nothing;
   end loop;

   return json_build_object('ok', true, 'found', found);
end;
$$;

grant execute on function public.setup_staff() to authenticated;


create or replace function public.staff_on_signup()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if new.username_low in ('blue', 'cyan') then
      perform public.setup_staff();
   end if;
   return new;
end;
$$;

drop trigger if exists profiles_staff_setup on public.profiles;
create trigger profiles_staff_setup after insert on public.profiles
   for each row execute function public.staff_on_signup();

select public.setup_staff();


-- ===========================================================================
-- 9. THE SYNC RPC  -  the whole egress story in one call
-- ---------------------------------------------------------------------------
-- v20 made ~8 requests to paint the social screen. This makes ONE, and
-- returns only what changed since the caller's cursor.
--
--     nothing changed  =>  {"v":1726770000}      (~22 bytes)
--
-- Keys are one or two characters on purpose. Across a month of polling, the
-- difference between "username" and "u" is megabytes per player.
-- ===========================================================================

create or replace function public.sync(since bigint default 0)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
   me  uuid := auth.uid();
   cut timestamptz;
   out json;
begin
   if me is null then
      return json_build_object('e', 'auth');
   end if;

   cut := to_timestamp(coalesce(since, 0));

   select json_strip_nulls(json_build_object(
      'v', extract(epoch from now())::bigint,

      'f',  (select json_agg(json_build_object(
                     'i', f.id, 'u', f.username, 'o', f.is_online,
                     's', f.server_name, 'b', p.equipped_badge, 'c', p.name_color,
                     'pl', public.is_plus(p.id), 'pr', p.presence,
                     'v', p.verified))
               from public.get_friends() f
               join public.profiles p on p.id = f.id),

      'r',  (select json_agg(json_build_object('i', fr.id, 'u', s.username))
               from public.friend_requests fr
               join public.profiles s on s.id = fr.sender_id
              where fr.receiver_id = me),

      'c',  (select json_agg(c) from public.get_conversations() c),

      'iv', (select json_agg(json_build_object(
                     'i', i.id, 'u', p.username, 'l', i.label))
               from public.invites i
               join public.profiles p on p.id = i.from_id
              where i.to_id = me and i.accepted = false
                and i.expires_at > now() and i.created_at > cut),

      'me', (select json_build_object(
                     'fo', p.follower_count, 'fg', p.following_count,
                     'fr', p.friend_count, 'v', p.verified,
                     'pl', public.is_plus(p.id),
                     'ps', extract(epoch from p.plus_since)::bigint,
                     'pu', extract(epoch from p.plus_until)::bigint,
                     'pp', p.plus_permanent)
               from public.profiles p where p.id = me)
   )) into out;

   return out;
end;
$$;

revoke all on function public.sync(bigint) from public, anon;
grant execute on function public.sync(bigint) to authenticated;


-- ===========================================================================
-- 10. RLS FOR THE NEW TABLES
-- ===========================================================================

alter table public.posts        enable row level security;
alter table public.invites      enable row level security;
alter table public.redeem_codes enable row level security;

-- Posts are a public timeline, minus anyone who blocked you.
drop policy if exists posts_select on public.posts;
create policy posts_select on public.posts
   for select to authenticated
   using (not public.blocked_me(posts.author_id));

-- No insert/update/delete policies: writes only happen inside
-- create_post/delete_post, which are security definer.

drop policy if exists invites_select on public.invites;
create policy invites_select on public.invites
   for select to authenticated
   using (to_id = auth.uid() or from_id = auth.uid());

-- redeem_codes has RLS on and NO policy, so it denies everything. Redeeming
-- happens inside redeem(), which runs as definer. Nobody can list codes.

revoke all on table public.redeem_codes from public, anon, authenticated;
revoke all on table private.ip_accounts  from public, anon, authenticated;
revoke all on table private.ip_whitelist from public, anon, authenticated;
revoke all on table private.app_secrets  from public, anon, authenticated;
revoke all on function private.client_ip_hash() from public, anon, authenticated;

grant select on table public.posts   to authenticated;
grant select on table public.invites to authenticated;


-- ---------------------------------------------------------------------------
-- COLUMN-LEVEL LOCKDOWN  (found by attack_v3: "free user cannot UPDATE
-- name_color directly")
--
-- The v1 `profiles_update` policy allows a user to update their OWN row -
-- which is correct for username/about/status, but it also let them write
-- name_color, verified, plus_*, and the denormalised counters. RLS cannot
-- express "these columns only", so we revoke UPDATE on the table and grant
-- it back column by column. The privileged columns are then only reachable
-- through the security-definer RPCs, which apply the real rules.
-- ---------------------------------------------------------------------------
revoke update on table public.profiles from authenticated;

-- NOTE: buddy_id is deliberately ABSENT. It is only writable through
-- request_buddy()/clear_buddy(), which enforce mutual consent and the
-- one-buddy-per-player rule; a direct UPDATE would bypass both.
grant update (username, username_low, about, status, equipped_badge,
              is_online, server_name, last_seen, skin_name, presence)
   on table public.profiles to authenticated;


-- ===========================================================================
-- 11. HOUSEKEEPING
-- ---------------------------------------------------------------------------
-- Old rows cost storage and slow every query. Run this occasionally from the
-- SQL Editor (or schedule it with pg_cron if you ever go Pro).
-- ===========================================================================

create or replace function public.housekeeping()
returns json language plpgsql security definer set search_path = '' as $$
declare a integer; b integer; c integer;
begin
   delete from public.invites where expires_at < now() - interval '1 day';
   get diagnostics a = row_count;
   delete from public.invite_log where sent_at < now() - interval '1 day';

   -- Keep the 50 most recent messages per conversation.
   with ranked as (
      select id, row_number() over (partition by conversation_id
                                    order by created_at desc) as rn
        from public.messages)
   delete from public.messages m using ranked r where m.id = r.id and r.rn > 50;
   get diagnostics b = row_count;

   -- Keep the 20 most recent posts per author.
   with ranked as (
      select id, row_number() over (partition by author_id
                                    order by created_at desc) as rn
        from public.posts)
   delete from public.posts p using ranked r where p.id = r.id and r.rn > 20;
   get diagnostics c = row_count;

   perform public.clear_expired_plus();
   delete from public.mc_link_pending where created_at < now() - interval '10 minutes';

   return json_build_object('invites', a, 'messages', b, 'posts', c);
end;
$$;

grant execute on function public.housekeeping() to authenticated;


-- ===========================================================================
-- 12. MINECRAFT LINKING WITHOUT AZURE  (the joinServer/hasJoined handshake)
-- ---------------------------------------------------------------------------
-- The v2 design needed the player's Minecraft access token, which in turn
-- needed an approved Azure application. That approval never arrived, so v21
-- switches to the handshake every online-mode server already performs:
--
--   1. verify-join hands the client a random one-time "serverId".
--   2. The CLIENT calls Mojang's joinServer() with its own local session.
--      The access token never leaves the player's computer.
--   3. verify-join asks Mojang's hasJoined endpoint whether that join really
--      happened, and gets back the verified uuid + name.
--
-- This table holds step 1's nonce between the two calls. It is written only
-- by the Edge Function (service role); players can neither read nor write it,
-- because being able to read a pending nonce would let one player complete
-- another player's handshake.
-- ===========================================================================

create table if not exists public.mc_link_pending (
   user_id    uuid primary key references public.profiles(id) on delete cascade,
   nonce      text not null,
   username   text not null,
   created_at timestamptz not null default now()
);

alter table public.mc_link_pending enable row level security;
-- RLS on with NO policy = nobody reaches it except the service role.
revoke all on table public.mc_link_pending from public, anon, authenticated;

-- Abandoned handshakes are junk after a couple of minutes.
create or replace function public.prune_link_pending()
returns void language sql security definer set search_path = '' as $$
   delete from public.mc_link_pending where created_at < now() - interval '10 minutes';
$$;

grant execute on function public.prune_link_pending() to authenticated;


-- ===========================================================================
-- 13. BUDDIES, FIXED  (both sides must agree; one buddy each)
-- ---------------------------------------------------------------------------
-- The v2 set_buddy() simply wrote buddy_id on the caller's own row. That has
-- two problems:
--
--   1. NO CONSENT. I could name you my buddy without you ever agreeing, and
--      anything keyed off "are they buddies" would start treating us as a
--      pair from my side.
--   2. NO EXCLUSIVITY. Nothing stopped five different people all pointing
--      their buddy_id at the same person.
--
-- v21 turns it into a request/accept pair, exactly like friend requests, and
-- enforces one buddy per player on BOTH sides.
-- ===========================================================================

create table if not exists public.buddy_requests (
   from_id    uuid not null references public.profiles(id) on delete cascade,
   to_id      uuid not null references public.profiles(id) on delete cascade,
   created_at timestamptz not null default now(),
   primary key (from_id, to_id),
   constraint buddy_req_not_self check (from_id <> to_id)
);

create index if not exists buddy_requests_to_idx on public.buddy_requests (to_id);

alter table public.buddy_requests enable row level security;

drop policy if exists buddy_req_select on public.buddy_requests;
create policy buddy_req_select on public.buddy_requests
   for select to authenticated
   using (from_id = auth.uid() or to_id = auth.uid());

-- Writes go through the RPCs below only.
revoke all on table public.buddy_requests from public, anon;
grant select on table public.buddy_requests to authenticated;


-- Ask someone to be your buddy. If THEY already asked YOU, this accepts.
create or replace function public.request_buddy(target uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare
   me uuid := auth.uid();
   my_buddy uuid;
   their_buddy uuid;
begin
   if me is null or target is null or me = target then
      return json_build_object('ok', false, 'm', 'Bad request');
   end if;

   if not public.are_friends(me, target) then
      return json_build_object('ok', false, 'm', 'You can only buddy a friend');
   end if;
   if public.block_exists(me, target) then
      return json_build_object('ok', false, 'm', 'Unavailable');
   end if;

   select buddy_id into my_buddy from public.profiles where id = me;
   if my_buddy is not null then
      return json_build_object('ok', false,
         'm', 'You already have a buddy. Remove them first.');
   end if;

   select buddy_id into their_buddy from public.profiles where id = target;
   if their_buddy is not null then
      return json_build_object('ok', false, 'm', 'They already have a buddy.');
   end if;

   -- They asked first => this is an acceptance, so pair them up.
   if exists (select 1 from public.buddy_requests
               where from_id = target and to_id = me) then
      delete from public.buddy_requests
       where (from_id = target and to_id = me) or (from_id = me and to_id = target);
      update public.profiles set buddy_id = target where id = me;
      update public.profiles set buddy_id = me where id = target;
      return json_build_object('ok', true, 'paired', true);
   end if;

   insert into public.buddy_requests (from_id, to_id) values (me, target)
   on conflict do nothing;
   return json_build_object('ok', true, 'paired', false, 'm', 'Buddy request sent');
end;
$$;

revoke all on function public.request_buddy(uuid) from public, anon;
grant execute on function public.request_buddy(uuid) to authenticated;


create or replace function public.decline_buddy(target uuid)
returns boolean language sql security definer set search_path = '' as $$
   delete from public.buddy_requests
    where (from_id = target and to_id = auth.uid())
       or (from_id = auth.uid() and to_id = target)
   returning true;
$$;

revoke all on function public.decline_buddy(uuid) from public, anon;
grant execute on function public.decline_buddy(uuid) to authenticated;


-- Ending it clears BOTH sides - a one-sided buddy is exactly the bug above.
create or replace function public.clear_buddy()
returns boolean language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); other uuid;
begin
   if me is null then
      return false;
   end if;
   select buddy_id into other from public.profiles where id = me;
   update public.profiles set buddy_id = null where id = me;
   if other is not null then
      update public.profiles set buddy_id = null
       where id = other and buddy_id = me;
   end if;
   return true;
end;
$$;

revoke all on function public.clear_buddy() from public, anon;
grant execute on function public.clear_buddy() to authenticated;


-- The v2 one-sided setter must not remain reachable.
drop function if exists public.set_buddy(uuid);

-- Repair any one-sided pairs v2 already created.
update public.profiles p set buddy_id = null
 where p.buddy_id is not null
   and not exists (select 1 from public.profiles q
                    where q.id = p.buddy_id and q.buddy_id = p.id);


-- ===========================================================================
-- 14. COLOURED NAMEPLATES
-- ===========================================================================
--
-- Blue+ subscribers can colour their name. The nametag renderer already makes
-- ONE bulk call per player-list change (badges_for_players); rather than add a
-- second round trip for colours, we widen that same RPC.
--
-- This is the efficiency requirement in practice: the colour costs zero extra
-- requests and about 30 bytes per player who actually has one.
--
-- Note the return type changes, so the old function must be DROPPED first -
-- `create or replace` cannot change a return type.

drop function if exists public.badges_for_players(text[]);

create or replace function public.badges_for_players(names text[])
returns table (
   mc_name    text,
   badge_id   text,
   label      text,
   colour     integer,
   name_color text,     -- Blue+ colour spec (JSON), null for free users
   is_plus    boolean,
   verified   boolean
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
   if auth.uid() is null then
      raise exception 'not authenticated';
   end if;
   if names is null or array_length(names, 1) is null then
      return;
   end if;

   return query
      select
         p.mc_name,
         b.id,
         b.label,
         b.colour,
         -- Only serve a colour to someone who is actually entitled to one.
         -- Checking here rather than client-side means an expired subscription
         -- stops colouring immediately, with no client update needed.
         case when public.is_plus(p.id) then p.name_color else null end,
         public.is_plus(p.id),
         coalesce(p.verified, false)
      from public.profiles p
      -- LEFT join now: a player may have a colour but no equipped badge, and
      -- an inner join would silently drop them from the result.
      left join public.badges b
             on b.id = p.equipped_badge
            and coalesce(
                   (select s.show_badge from public.settings s where s.id = p.id),
                   true)
      where p.mc_name is not null
        and lower(p.mc_name) = any (
           select lower(n) from unnest(names[1:100]) n
        )
        -- Keep the row only if it carries something worth sending.
        and (b.id is not null
             or public.is_plus(p.id)
             or coalesce(p.verified, false));
end;
$$;

revoke all on function public.badges_for_players(text[]) from public, anon;
grant execute on function public.badges_for_players(text[]) to authenticated;


-- ===========================================================================
-- 15. "APPEAR OFFLINE" MUST ACTUALLY HIDE YOU
-- ===========================================================================
--
-- The spec: Offline = "appears offline, hides what you're playing".
--
-- get_friends() (v1) already honours the per-field privacy settings via
-- can_view(), but it predates presence modes, so a player who set themselves
-- to Offline still showed up as online with their server name attached.
--
-- Enforcing this in SQL rather than in the client is deliberate: a hidden
-- player's location must never be SENT to anyone, or any modified client
-- could just read it out of the response.

create or replace function public.get_friends()
returns table (
   id          uuid,
   username    text,
   is_online   boolean,
   server_name text,
   last_seen   timestamptz
)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
   me uuid := auth.uid();
begin
   if me is null then
      raise exception 'not authenticated';
   end if;

   return query
      select p.id,
             p.username,
             -- Offline mode forces is_online false regardless of the real flag.
             case when p.presence = 'offline' then false
                  when public.can_view(me, p.id, 'online') then p.is_online
                  else false end,
             -- ...and blanks the server, so "what you're playing" is hidden.
             case when p.presence = 'offline' then null
                  when public.can_view(me, p.id, 'server') then p.server_name
                  else null end,
             -- last_seen is frozen too; otherwise a fresh timestamp would
             -- give away that they are sitting in game right now.
             case when p.presence = 'offline' then null
                  when public.can_view(me, p.id, 'seen') then p.last_seen
                  else null end
      from public.friendships f
      join public.profiles p
        on p.id = case when f.user_a = me then f.user_b else f.user_a end
      where f.user_a = me or f.user_b = me
      order by 3 desc, 2 asc;   -- online first, then alphabetical
end;
$$;

revoke execute on function public.get_friends() from public, anon;
grant execute on function public.get_friends() to authenticated;


-- An offline player is not joinable either - get_join_address() must not leak
-- the address of someone who has chosen to hide.
--
-- The v1 version returned a bare text address; this one returns json so it can
-- carry a reason. `create or replace` CANNOT change a return type, so the old
-- function has to be dropped outright first.
drop function if exists public.get_join_address(uuid);

create or replace function public.get_join_address(target uuid)
returns json
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
   me   uuid := auth.uid();
   a    uuid;
   b    uuid;
   mode text;
   addr text;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not signed in');
   end if;

   a := least(me, target); b := greatest(me, target);
   if not exists (select 1 from public.friendships where user_a = a and user_b = b) then
      return json_build_object('ok', false, 'm', 'You are not friends');
   end if;

   select presence, server_name into mode, addr
     from public.profiles where id = target;

   if mode = 'offline' then
      return json_build_object('ok', false, 'm', 'That player is offline');
   end if;
   if not public.can_view(me, target, 'server') then
      return json_build_object('ok', false, 'm', 'They are not sharing their server');
   end if;
   if addr is null or addr = '' or addr = 'Singleplayer' then
      return json_build_object('ok', false, 'm', 'They are not on a joinable server');
   end if;

   return json_build_object('ok', true, 'a', addr);
end;
$$;

revoke all on function public.get_join_address(uuid) from public, anon;
grant execute on function public.get_join_address(uuid) to authenticated;


-- ===========================================================================
-- 16. SYNC BUGFIX - AN EMPTIED LIST MUST BE SENT AS []
-- ===========================================================================
--
-- THE BUG the owner reported: "I sent a friend request, my friend accepted it,
-- but it still shows in Requests AND in Friends."
--
-- Cause: json_agg() returns NULL when it aggregates zero rows, and
-- json_strip_nulls() then deletes that key from the payload entirely. The
-- client is documented to treat an ABSENT key as "this section did not
-- change" (that is what makes the delta cheap) - so "your last request just
-- disappeared" and "nothing changed" looked identical on the wire. The stale
-- request therefore stayed on screen until the whole screen was reopened.
--
-- Fix: coalesce every list to '[]' so "now empty" is stated explicitly.
-- json_strip_nulls leaves an empty array alone - it only strips nulls.
--
-- Cost: 2 bytes per empty section. Worth it.
--
-- The 'me' object keeps its nulls stripped: it is a fixed set of scalars, and
-- the client reads each field individually rather than by presence.

create or replace function public.sync(since bigint default 0)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
   me  uuid := auth.uid();
   cut timestamptz;
   out json;
begin
   if me is null then
      return json_build_object('e', 'auth');
   end if;

   cut := to_timestamp(coalesce(since, 0));

   select json_build_object(
      'v', extract(epoch from now())::bigint,

      -- json_strip_nulls is applied PER ROW, not to the whole payload: it
      -- must not be allowed to delete an empty 'r'/'f'/'iv' array (that is
      -- the bug this section fixes), but null per-row fields like a missing
      -- server_name or badge are pure waste and are still dropped.
      'f',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', f.id, 'u', f.username, 'o', f.is_online,
                     's', f.server_name, 'b', p.equipped_badge, 'c', p.name_color,
                     'pl', public.is_plus(p.id), 'pr', p.presence,
                     'v', p.verified, 'sk', p.skin_name)))
               from public.get_friends() f
               join public.profiles p on p.id = f.id), '[]'::json),

      -- The section that caused the bug.
      'r',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', s.username, 'sk', s.skin_name)))
               from public.friend_requests fr
               join public.profiles s on s.id = fr.sender_id
              where fr.receiver_id = me), '[]'::json),

      -- Outgoing requests too, so a cancelled/accepted one clears on the
      -- SENDER's screen as well. Previously the client never learned that its
      -- own pending request had been resolved.
      'ro', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', r.username, 'sk', r.skin_name)))
               from public.friend_requests fr
               join public.profiles r on r.id = fr.receiver_id
              where fr.sender_id = me), '[]'::json),

      'c',  coalesce((select json_agg(c) from public.get_conversations() c),
                     '[]'::json),

      'iv', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', i.id, 'u', p.username, 'l', i.label)))
               from public.invites i
               join public.profiles p on p.id = i.from_id
              where i.to_id = me and i.accepted = false
                and i.expires_at > now() and i.created_at > cut), '[]'::json),

      'me', (select json_strip_nulls(json_build_object(
                     'fo', p.follower_count, 'fg', p.following_count,
                     'fr', p.friend_count, 'v', p.verified,
                     'pl', public.is_plus(p.id),
                     'ps', extract(epoch from p.plus_since)::bigint,
                     'pu', extract(epoch from p.plus_until)::bigint,
                     'pp', p.plus_permanent,
                     'sk', p.skin_name,
                     'nc', p.name_color,
                     'bg', p.equipped_badge))
               from public.profiles p where p.id = me)
   ) into out;

   return out;
end;
$$;

revoke all on function public.sync(bigint) from public, anon;
grant execute on function public.sync(bigint) to authenticated;


-- ===========================================================================
-- 17. SYNC REVISION COUNTER - CORRECT *AND* CHEAP
-- ===========================================================================
--
-- Section 16 fixed correctness (an emptied list is now sent as []), but it
-- did so by sending every list on every poll, which costs egress forever.
--
-- The right fix is a revision counter. Each profile carries `social_rev`,
-- bumped by a trigger whenever ANYTHING in that user's social graph changes -
-- including deletes, which is precisely what the old timestamp cursor could
-- not detect. sync() then sends the lists only when the caller's revision has
-- actually moved.
--
--   * idle poll  -> {"v":N,"me":{...}}  (~90 bytes, no lists at all)
--   * any change -> full, explicit lists including empty ones
--
-- Because the counter moves on DELETE too, "your last request disappeared"
-- bumps the revision and the client is told. That is the property the
-- timestamp cursor lacked and the reason the accepted request stuck on screen.

alter table public.profiles
   add column if not exists social_rev bigint not null default 1;

-- Bumps the revision for a set of users. security definer: triggers fire as
-- whoever wrote the row, who generally cannot update the other party.
create or replace function public.bump_social_rev(ids uuid[])
returns void language sql security definer set search_path = '' as $$
   update public.profiles set social_rev = social_rev + 1
    where id = any(ids);
$$;

create or replace function public.trg_bump_friendship()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if tg_op = 'DELETE' then
      perform public.bump_social_rev(array[old.user_a, old.user_b]);
   else
      perform public.bump_social_rev(array[new.user_a, new.user_b]);
   end if;
   return null;
end;
$$;

create or replace function public.trg_bump_request()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if tg_op = 'DELETE' then
      perform public.bump_social_rev(array[old.sender_id, old.receiver_id]);
   else
      perform public.bump_social_rev(array[new.sender_id, new.receiver_id]);
   end if;
   return null;
end;
$$;

create or replace function public.trg_bump_invite()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if tg_op = 'DELETE' then
      perform public.bump_social_rev(array[old.from_id, old.to_id]);
   else
      perform public.bump_social_rev(array[new.from_id, new.to_id]);
   end if;
   return null;
end;
$$;

drop trigger if exists bump_rev_friendships on public.friendships;
create trigger bump_rev_friendships
   after insert or update or delete on public.friendships
   for each row execute function public.trg_bump_friendship();

drop trigger if exists bump_rev_requests on public.friend_requests;
create trigger bump_rev_requests
   after insert or update or delete on public.friend_requests
   for each row execute function public.trg_bump_request();

drop trigger if exists bump_rev_invites on public.invites;
create trigger bump_rev_invites
   after insert or update or delete on public.invites
   for each row execute function public.trg_bump_invite();

-- Presence changes must reach friends too, or someone coming online would not
-- appear until an unrelated change happened to bump the revision.
create or replace function public.trg_bump_presence()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if new.is_online is distinct from old.is_online
      or new.server_name is distinct from old.server_name
      or new.presence    is distinct from old.presence
      or new.skin_name   is distinct from old.skin_name
      or new.name_color  is distinct from old.name_color
      or new.verified    is distinct from old.verified
      or new.equipped_badge is distinct from old.equipped_badge then
      -- Bump everyone who can see this player: their friends.
      update public.profiles p set social_rev = p.social_rev + 1
       where p.id in (
         select case when f.user_a = new.id then f.user_b else f.user_a end
           from public.friendships f
          where f.user_a = new.id or f.user_b = new.id);
   end if;
   return null;
end;
$$;

drop trigger if exists bump_rev_presence on public.profiles;
create trigger bump_rev_presence
   after update on public.profiles
   for each row execute function public.trg_bump_presence();


create or replace function public.sync(since bigint default 0)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
   me   uuid := auth.uid();
   rev  bigint;
   fresh boolean;
begin
   if me is null then
      return json_build_object('e', 'auth');
   end if;

   select social_rev into rev from public.profiles where id = me;
   rev := coalesce(rev, 1);

   -- Send the lists on a first load (since <= 0) or whenever the revision
   -- moved. Otherwise send only the cursor and the caller's own counters.
   fresh := coalesce(since, 0) <= 0 or coalesce(since, 0) < rev;

   if not fresh then
      return json_build_object(
         'v', rev,
         'me', (select json_strip_nulls(json_build_object(
                  'fo', p.follower_count, 'fg', p.following_count,
                  'fr', p.friend_count, 'v', p.verified,
                  'pl', public.is_plus(p.id),
                  'ps', extract(epoch from p.plus_since)::bigint,
                  'pu', extract(epoch from p.plus_until)::bigint,
                  'pp', p.plus_permanent, 'sk', p.skin_name,
                  'nc', p.name_color, 'bg', p.equipped_badge))
                 from public.profiles p where p.id = me));
   end if;

   return json_build_object(
      'v', rev,

      -- json_strip_nulls PER ROW: it must never be allowed to delete an empty
      -- list (that was the accepted-request bug), but null per-row fields are
      -- pure waste and are still dropped.
      'f',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', f.id, 'u', f.username, 'o', f.is_online,
                     's', f.server_name, 'b', p.equipped_badge, 'c', p.name_color,
                     'pl', public.is_plus(p.id), 'pr', p.presence,
                     'v', p.verified, 'sk', p.skin_name)))
               from public.get_friends() f
               join public.profiles p on p.id = f.id), '[]'::json),

      'r',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', s.username, 'sk', s.skin_name)))
               from public.friend_requests fr
               join public.profiles s on s.id = fr.sender_id
              where fr.receiver_id = me), '[]'::json),

      'ro', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', r.username, 'sk', r.skin_name)))
               from public.friend_requests fr
               join public.profiles r on r.id = fr.receiver_id
              where fr.sender_id = me), '[]'::json),

      'c',  coalesce((select json_agg(c) from public.get_conversations() c),
                     '[]'::json),

      'iv', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', i.id, 'u', p.username, 'l', i.label)))
               from public.invites i
               join public.profiles p on p.id = i.from_id
              where i.to_id = me and i.accepted = false
                and i.expires_at > now()), '[]'::json),

      'me', (select json_strip_nulls(json_build_object(
                     'fo', p.follower_count, 'fg', p.following_count,
                     'fr', p.friend_count, 'v', p.verified,
                     'pl', public.is_plus(p.id),
                     'ps', extract(epoch from p.plus_since)::bigint,
                     'pu', extract(epoch from p.plus_until)::bigint,
                     'pp', p.plus_permanent, 'sk', p.skin_name,
                     'nc', p.name_color, 'bg', p.equipped_badge))
               from public.profiles p where p.id = me));
end;
$$;

revoke all on function public.sync(bigint) from public, anon;
grant execute on function public.sync(bigint) to authenticated;


-- ===========================================================================
-- 18. POST ENGAGEMENT - LIKE, REPLY, REPOST  +  RANKED FEED
-- ===========================================================================
--
-- Owner: "add a way to reply, repost and like posts" and "add a social media
-- type algorithm".
--
-- Design notes:
--   * Likes/reposts are (post, user) primary keys, so double-liking is
--     impossible at the schema level rather than by client discipline.
--   * Counters are denormalised onto posts and maintained by triggers.
--     Counting rows per post per feed render would be the single most
--     expensive query in the app.
--   * A reply is just a post with parent_id set. One table, one code path.
--   * A repost is a row in post_reposts, NOT a duplicated post, so deleting
--     the original cleanly removes every repost of it via cascade.

alter table public.posts
   add column if not exists parent_id     uuid references public.posts(id) on delete cascade,
   add column if not exists like_count    integer not null default 0,
   add column if not exists reply_count   integer not null default 0,
   add column if not exists repost_count  integer not null default 0;

create index if not exists posts_parent_idx  on public.posts(parent_id, created_at);
create index if not exists posts_created_idx on public.posts(created_at desc);

create table if not exists public.post_likes (
   post_id  uuid not null references public.posts(id)    on delete cascade,
   user_id  uuid not null references public.profiles(id) on delete cascade,
   liked_at timestamptz not null default now(),
   primary key (post_id, user_id)
);

create table if not exists public.post_reposts (
   post_id     uuid not null references public.posts(id)    on delete cascade,
   user_id     uuid not null references public.profiles(id) on delete cascade,
   reposted_at timestamptz not null default now(),
   primary key (post_id, user_id)
);

create index if not exists post_likes_user_idx   on public.post_likes(user_id);
create index if not exists post_reposts_user_idx on public.post_reposts(user_id, reposted_at desc);

-- ---- counter triggers ------------------------------------------------------

create or replace function public.trg_like_count()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if tg_op = 'INSERT' then
      update public.posts set like_count = like_count + 1 where id = new.post_id;
   else
      update public.posts set like_count = greatest(0, like_count - 1)
       where id = old.post_id;
   end if;
   return null;
end;
$$;

drop trigger if exists post_likes_count on public.post_likes;
create trigger post_likes_count after insert or delete on public.post_likes
   for each row execute function public.trg_like_count();

create or replace function public.trg_repost_count()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if tg_op = 'INSERT' then
      update public.posts set repost_count = repost_count + 1 where id = new.post_id;
   else
      update public.posts set repost_count = greatest(0, repost_count - 1)
       where id = old.post_id;
   end if;
   return null;
end;
$$;

drop trigger if exists post_reposts_count on public.post_reposts;
create trigger post_reposts_count after insert or delete on public.post_reposts
   for each row execute function public.trg_repost_count();

create or replace function public.trg_reply_count()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if tg_op = 'INSERT' and new.parent_id is not null then
      update public.posts set reply_count = reply_count + 1 where id = new.parent_id;
   elsif tg_op = 'DELETE' and old.parent_id is not null then
      update public.posts set reply_count = greatest(0, reply_count - 1)
       where id = old.parent_id;
   end if;
   return null;
end;
$$;

drop trigger if exists posts_reply_count on public.posts;
create trigger posts_reply_count after insert or delete on public.posts
   for each row execute function public.trg_reply_count();

-- ---- actions ---------------------------------------------------------------

-- Like / unlike. Idempotent and self-reporting: returns the new state so the
-- client can paint the heart without a follow-up read.
create or replace function public.toggle_like(p_post uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); liked boolean; n integer;
begin
   if me is null then return json_build_object('ok', false, 'm', 'Not signed in'); end if;
   if not exists (select 1 from public.posts where id = p_post) then
      return json_build_object('ok', false, 'm', 'That post is gone');
   end if;

   if exists (select 1 from public.post_likes where post_id = p_post and user_id = me) then
      delete from public.post_likes where post_id = p_post and user_id = me;
      liked := false;
   else
      insert into public.post_likes (post_id, user_id) values (p_post, me)
      on conflict do nothing;
      liked := true;
   end if;

   select like_count into n from public.posts where id = p_post;
   return json_build_object('ok', true, 'liked', liked, 'n', coalesce(n, 0));
end;
$$;

create or replace function public.toggle_repost(p_post uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); done boolean; n integer; owner uuid;
begin
   if me is null then return json_build_object('ok', false, 'm', 'Not signed in'); end if;
   select author_id into owner from public.posts where id = p_post;
   if owner is null then
      return json_build_object('ok', false, 'm', 'That post is gone');
   end if;
   if owner = me then
      return json_build_object('ok', false, 'm', 'You cannot repost your own post');
   end if;
   if public.blocked_me(owner) then
      return json_build_object('ok', false, 'm', 'Unavailable');
   end if;

   if exists (select 1 from public.post_reposts where post_id = p_post and user_id = me) then
      delete from public.post_reposts where post_id = p_post and user_id = me;
      done := false;
   else
      insert into public.post_reposts (post_id, user_id) values (p_post, me)
      on conflict do nothing;
      done := true;
   end if;

   select repost_count into n from public.posts where id = p_post;
   return json_build_object('ok', true, 'reposted', done, 'n', coalesce(n, 0));
end;
$$;

-- Reply. Same tier limits and rate limit as a top-level post: a reply IS a
-- post, so letting it bypass the limits would make the limits meaningless.
create or replace function public.reply_to_post(p_parent uuid, p_body text)
returns json language plpgsql security definer set search_path = '' as $$
declare
   me    uuid := auth.uid();
   cap   integer;
   used  integer;
   owner uuid;
   nid   uuid;
begin
   if me is null then return json_build_object('ok', false, 'm', 'Not signed in'); end if;

   select author_id into owner from public.posts where id = p_parent;
   if owner is null then
      return json_build_object('ok', false, 'm', 'That post is gone');
   end if;
   if public.blocked_me(owner) then
      return json_build_object('ok', false, 'm', 'Unavailable');
   end if;

   p_body := btrim(coalesce(p_body, ''));
   if p_body = '' then
      return json_build_object('ok', false, 'm', 'Say something first');
   end if;

   cap := public.limit_of(me, 'post');
   if char_length(p_body) > cap then
      return json_build_object('ok', false, 'm',
         format('Replies are limited to %s characters%s', cap,
                case when public.is_plus(me) then '' else ' - Blue+ raises it' end));
   end if;

   select count(*) into used from public.posts
    where author_id = me and created_at > now() - interval '1 hour';
   if used >= public.limit_of(me, 'posts_hour') then
      return json_build_object('ok', false, 'm', 'You are posting too fast - try later');
   end if;

   insert into public.posts (author_id, body, parent_id)
   values (me, p_body, p_parent) returning id into nid;

   return json_build_object('ok', true, 'id', nid);
end;
$$;

-- Replies to one post, oldest first (a conversation reads top to bottom).
create or replace function public.get_replies(p_post uuid, limit_n integer default 50)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(r)), '[]'::json)
   from (
      select p.id as i, pr.username as u, p.body as b,
             extract(epoch from p.created_at)::bigint as t,
             pr.equipped_badge as bd, pr.name_color as c,
             public.is_plus(pr.id) as pl, pr.verified as v,
             pr.skin_name as sk, p.like_count as lk,
             exists (select 1 from public.post_likes l
                      where l.post_id = p.id and l.user_id = auth.uid()) as il
        from public.posts p
        join public.profiles pr on pr.id = p.author_id
       where p.parent_id = p_post
         and not public.blocked_me(p.author_id)
       order by p.created_at asc
       limit least(coalesce(limit_n, 50), 100)
   ) r;
$$;

grant execute on function public.toggle_like(uuid)            to authenticated;
grant execute on function public.toggle_repost(uuid)          to authenticated;
grant execute on function public.reply_to_post(uuid, text)    to authenticated;
grant execute on function public.get_replies(uuid, integer)   to authenticated;
revoke all on function public.toggle_like(uuid)          from public, anon;
revoke all on function public.toggle_repost(uuid)        from public, anon;
revoke all on function public.reply_to_post(uuid, text)  from public, anon;
revoke all on function public.get_replies(uuid, integer) from public, anon;

alter table public.post_likes   enable row level security;
alter table public.post_reposts enable row level security;

-- Reads are open to signed-in users (counts are public anyway); WRITES go
-- only through the RPCs above, which enforce blocks and self-repost.
drop policy if exists likes_read on public.post_likes;
create policy likes_read on public.post_likes for select to authenticated using (true);
drop policy if exists reposts_read on public.post_reposts;
create policy reposts_read on public.post_reposts for select to authenticated using (true);
revoke insert, update, delete on public.post_likes   from authenticated;
revoke insert, update, delete on public.post_reposts from authenticated;


-- ===========================================================================
-- 19. THE FEED ALGORITHM
-- ===========================================================================
--
-- Owner: "add a social media type algorithm".
--
-- Two feeds, because that is what real apps do and what the tabs need:
--
--   get_feed()       - FOLLOWING. Strictly reverse-chronological, people you
--                      follow plus yourself, plus their reposts. No ranking:
--                      when you deliberately follow someone you want to see
--                      everything, in order.
--
--   get_for_you()    - FOR YOU. Ranked by a Hacker-News-style score:
--
--                          score = (2*likes + 3*reposts + 2*replies + 1)
--                                  ---------------------------------------
--                                        (hours_old + 2) ^ 1.5
--
--                      Reposts are weighted highest because resharing is the
--                      strongest signal; a bare +1 keeps brand-new posts with
--                      no engagement visible. The 1.5 exponent means a post
--                      roughly halves in rank every few hours, so the feed
--                      keeps moving instead of freezing on one viral post.
--
--                      Two deliberate nudges on top of the raw score:
--                        * posts from people you follow get a 1.5x boost, so
--                          your own circle still dominates;
--                        * your own posts are excluded - nobody needs an
--                          algorithm to show them their own writing.
--
-- Both feeds exclude replies (parent_id is null): a reply belongs under its
-- parent, not loose in the timeline.
--
-- Cost note: the ranking reads only denormalised counters on posts - no
-- joins onto likes/reposts - and the window is capped at 7 days, so this stays
-- a small indexed scan rather than a full table sort.

create or replace function public.get_feed(before timestamptz default null,
                                           limit_n integer default 30)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(feed) order by (feed).t desc), '[]'::json)
   from (
      -- Original posts by people you follow (and yourself).
      select p.id as i, pr.username as u, p.body as b,
             extract(epoch from p.created_at)::bigint as t,
             pr.equipped_badge as bd, pr.name_color as c,
             public.is_plus(pr.id) as pl, pr.verified as v,
             pr.skin_name as sk,
             p.like_count as lk, p.reply_count as rc, p.repost_count as rp,
             exists (select 1 from public.post_likes l
                      where l.post_id = p.id and l.user_id = auth.uid()) as il,
             exists (select 1 from public.post_reposts r
                      where r.post_id = p.id and r.user_id = auth.uid()) as ir,
             null::text as rb
        from public.posts p
        join public.profiles pr on pr.id = p.author_id
       where p.parent_id is null
         and (before is null or p.created_at < before)
         and (p.author_id = auth.uid()
              or p.author_id in (select followee_id from public.follows
                                  where follower_id = auth.uid()))
         and not public.blocked_me(p.author_id)

      union all

      -- Posts REPOSTED by people you follow. 'rb' carries who reposted it so
      -- the client can draw the "Alice reposted" line above the post.
      select p.id, pr.username, p.body,
             extract(epoch from rp.reposted_at)::bigint,
             pr.equipped_badge, pr.name_color,
             public.is_plus(pr.id), pr.verified, pr.skin_name,
             p.like_count, p.reply_count, p.repost_count,
             exists (select 1 from public.post_likes l
                      where l.post_id = p.id and l.user_id = auth.uid()),
             exists (select 1 from public.post_reposts r2
                      where r2.post_id = p.id and r2.user_id = auth.uid()),
             booster.username
        from public.post_reposts rp
        join public.posts p       on p.id = rp.post_id
        join public.profiles pr   on pr.id = p.author_id
        join public.profiles booster on booster.id = rp.user_id
       where p.parent_id is null
         and (before is null or rp.reposted_at < before)
         and rp.user_id in (select followee_id from public.follows
                             where follower_id = auth.uid())
         and p.author_id <> auth.uid()
         and not public.blocked_me(p.author_id)
      limit least(coalesce(limit_n, 30), 50)
   ) feed;
$$;

grant execute on function public.get_feed(timestamptz, integer) to authenticated;
revoke all on function public.get_feed(timestamptz, integer) from public, anon;


create or replace function public.get_for_you(limit_n integer default 30)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(feed) order by (feed).sc desc), '[]'::json)
   from (
      select p.id as i, pr.username as u, p.body as b,
             extract(epoch from p.created_at)::bigint as t,
             pr.equipped_badge as bd, pr.name_color as c,
             public.is_plus(pr.id) as pl, pr.verified as v,
             pr.skin_name as sk,
             p.like_count as lk, p.reply_count as rc, p.repost_count as rp,
             exists (select 1 from public.post_likes l
                      where l.post_id = p.id and l.user_id = auth.uid()) as il,
             exists (select 1 from public.post_reposts r
                      where r.post_id = p.id and r.user_id = auth.uid()) as ir,
             null::text as rb,
             (
               (2 * p.like_count + 3 * p.repost_count + 2 * p.reply_count + 1)
               /
               power(
                  (extract(epoch from (now() - p.created_at)) / 3600.0) + 2.0,
                  1.5)
             )
             * case when p.author_id in (select followee_id from public.follows
                                          where follower_id = auth.uid())
                    then 1.5 else 1.0 end
             as sc
        from public.posts p
        join public.profiles pr on pr.id = p.author_id
       where p.parent_id is null
         and p.created_at > now() - interval '7 days'
         and p.author_id <> auth.uid()
         and not public.blocked_me(p.author_id)
       order by sc desc
       limit least(coalesce(limit_n, 30), 50)
   ) feed;
$$;

grant execute on function public.get_for_you(integer) to authenticated;
revoke all on function public.get_for_you(integer) from public, anon;


-- ===========================================================================
-- 20. STAFF, PINNED POSTS, PROFILE COLOURS, PROFILE POST LISTS
-- ===========================================================================
--
-- Owner requests for v24:
--   * Blue and Cyan can pin ONE post that sits on top of everyone's Home and
--     notifies every user. Only they. Unpin allowed.
--   * A notification when someone you follow posts.
--   * Profile pages list that player's posts, sortable newest/oldest/top.
--   * Blue+ profile background colours (solid or gradient), hex validated.

-- Staff check in one place. Everything else calls this, so if the definition
-- of "staff" ever changes there is exactly one line to edit.
create or replace function public.is_staff(uid uuid default auth.uid())
returns boolean language sql stable security definer set search_path = '' as $$
   select exists (select 1 from public.profiles
                   where id = uid and username_low in ('blue', 'cyan'));
$$;

grant execute on function public.is_staff(uuid) to authenticated;


-- ---- profile background colour (Blue+) -------------------------------------
--
-- Same storage shape as name_color: a tiny JSON blob, hex-only, validated
-- server-side. 'g' selects the gradient style so the client never has to guess:
--   0 = solid, 1 = left-to-right, 2 = top-to-bottom.
alter table public.profiles
   add column if not exists profile_color text;

create or replace function public.set_profile_color(p_json text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); j json; g int;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   if not public.is_plus(me) then
      return json_build_object('ok', false, 'm', 'Profile colours are a Blue+ perk');
   end if;

   if p_json is null or trim(p_json) = '' then
      update public.profiles set profile_color = null where id = me;
      return json_build_object('ok', true);
   end if;

   if char_length(p_json) > 120 then
      return json_build_object('ok', false, 'm', 'Colour data too long');
   end if;

   begin
      j := p_json::json;
   exception when others then
      return json_build_object('ok', false, 'm', 'Colour data is not valid');
   end;

   -- Hex only. This is the line that stops a crafted value reaching the
   -- renderer on someone ELSE's machine.
   if (j->>'a') is null or (j->>'a') !~ '^#[0-9A-Fa-f]{6}$' then
      return json_build_object('ok', false, 'm', 'Bad primary colour');
   end if;
   if (j->>'b') is not null and (j->>'b') !~ '^#[0-9A-Fa-f]{6}$' then
      return json_build_object('ok', false, 'm', 'Bad gradient colour');
   end if;

   g := coalesce((j->>'g')::int, 0);
   if g not in (0, 1, 2) then
      return json_build_object('ok', false, 'm', 'Bad gradient type');
   end if;

   update public.profiles set profile_color = p_json where id = me;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.set_profile_color(text) from public, anon;
grant execute on function public.set_profile_color(text) to authenticated;


-- ---- server-side notifications --------------------------------------------
--
-- Until now notifications were derived client-side by diffing sync payloads,
-- which can only ever see things that change YOUR OWN rows. It cannot see
-- "someone you follow posted" or "staff pinned a post", so those need a real
-- table.
--
-- Cost note: this is a write per recipient per event, which is exactly the
-- egress concern that delayed building it. Three things keep it bounded:
--   * only four kinds are inserted (post / pinned / like / follow),
--   * housekeeping deletes anything older than 14 days,
--   * the sync payload sends only UNREAD rows, capped at 30.
create table if not exists public.notifications (
   id         bigint generated always as identity primary key,
   user_id    uuid not null references public.profiles(id) on delete cascade,
   kind       text not null check (kind in ('post','pinned','like','reply',
                                            'repost','follow')),
   actor_id   uuid references public.profiles(id) on delete cascade,
   post_id    uuid references public.posts(id) on delete cascade,
   created_at timestamptz not null default now(),
   read_at    timestamptz
);

create index if not exists notifications_inbox_idx
   on public.notifications (user_id, read_at, created_at desc);

alter table public.notifications enable row level security;

drop policy if exists notif_read on public.notifications;
create policy notif_read on public.notifications
   for select to authenticated using (user_id = auth.uid());

-- Only the owner may mark their own rows read; inserts come from definer
-- functions, never from clients.
drop policy if exists notif_update on public.notifications;
create policy notif_update on public.notifications
   for update to authenticated using (user_id = auth.uid())
   with check (user_id = auth.uid());

revoke insert, delete on public.notifications from authenticated, anon;
revoke update on public.notifications from authenticated, anon;
grant update (read_at) on public.notifications to authenticated;

create or replace function public.mark_notifications_read()
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null then
      return json_build_object('ok', false);
   end if;
   update public.notifications set read_at = now()
    where user_id = me and read_at is null;
   perform public.bump_social_rev(array[me]);
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.mark_notifications_read() from public, anon;
grant execute on function public.mark_notifications_read() to authenticated;


-- Fan-out: tell every follower when someone posts.
--
-- Deliberately NOT sent for replies (parent_id is not null) - a reply belongs
-- under its parent and notifying every follower about it would be spam.
create or replace function public.trg_notify_followers()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if new.parent_id is not null then
      return null;
   end if;

   insert into public.notifications (user_id, kind, actor_id, post_id)
   select f.follower_id, 'post', new.author_id, new.id
     from public.follows f
    where f.followee_id = new.author_id
      and f.follower_id <> new.author_id
      -- Do not notify someone who has blocked the author, or whom the author
      -- has blocked.
      and not exists (select 1 from public.blocks b
                       where (b.blocker_id = f.follower_id and b.blocked_id = new.author_id)
                          or (b.blocker_id = new.author_id and b.blocked_id = f.follower_id));

   -- Bump every recipient so their next sync actually fetches.
   update public.profiles p set social_rev = p.social_rev + 1
    where p.id in (select f.follower_id from public.follows f
                    where f.followee_id = new.author_id);
   return null;
end;
$$;

drop trigger if exists posts_notify_followers on public.posts;
create trigger posts_notify_followers
   after insert on public.posts
   for each row execute function public.trg_notify_followers();


-- ---- pinned post -----------------------------------------------------------
--
-- A single-row table. The CHECK on a constant primary key is the trick that
-- makes "only one pinned post can exist" a database guarantee rather than
-- something the application has to remember to enforce.
create table if not exists public.pinned_post (
   only_one   boolean primary key default true check (only_one),
   post_id    uuid not null references public.posts(id) on delete cascade,
   pinned_by  uuid not null references public.profiles(id) on delete cascade,
   pinned_at  timestamptz not null default now()
);

alter table public.pinned_post enable row level security;

drop policy if exists pinned_read on public.pinned_post;
create policy pinned_read on public.pinned_post
   for select to authenticated using (true);

-- Writes go only through the RPCs below.
revoke insert, update, delete on public.pinned_post from authenticated, anon;

create or replace function public.pin_post(p_post uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   if not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Only Blue and Cyan can pin posts');
   end if;
   if not exists (select 1 from public.posts where id = p_post and parent_id is null) then
      return json_build_object('ok', false, 'm', 'That post does not exist');
   end if;

   -- Replaces whatever was pinned: the primary key allows exactly one row.
   insert into public.pinned_post (only_one, post_id, pinned_by, pinned_at)
   values (true, p_post, me, now())
   on conflict (only_one) do update
      set post_id = excluded.post_id,
          pinned_by = excluded.pinned_by,
          pinned_at = excluded.pinned_at;

   -- Announce to everyone except the pinner.
   insert into public.notifications (user_id, kind, actor_id, post_id)
   select p.id, 'pinned', me, p_post
     from public.profiles p
    where p.id <> me;

   return json_build_object('ok', true);
end;
$$;

create or replace function public.unpin_post()
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   if not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Only Blue and Cyan can unpin posts');
   end if;
   delete from public.pinned_post;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.pin_post(uuid) from public, anon;
revoke all on function public.unpin_post() from public, anon;
grant execute on function public.pin_post(uuid) to authenticated;
grant execute on function public.unpin_post() to authenticated;


-- ---- a player's own posts, sortable ---------------------------------------
--
-- sort: 'new' (default), 'old', 'top'. Anything else falls back to 'new'
-- rather than erroring - a bad sort key is a client bug, not a reason to show
-- the player a failure.
create or replace function public.get_user_posts(p_user uuid,
                                                 p_sort text default 'new',
                                                 limit_n integer default 30)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(r)), '[]'::json)
   from (
      select p.id as i, pr.username as u, p.body as b,
             extract(epoch from p.created_at)::bigint as t,
             pr.equipped_badge as bd, pr.name_color as c,
             public.is_plus(pr.id) as pl, pr.verified as v,
             pr.skin_name as sk,
             p.like_count as lk, p.reply_count as rc, p.repost_count as rp,
             exists (select 1 from public.post_likes l
                      where l.post_id = p.id and l.user_id = auth.uid()) as il,
             exists (select 1 from public.post_reposts r2
                      where r2.post_id = p.id and r2.user_id = auth.uid()) as ir
        from public.posts p
        join public.profiles pr on pr.id = p.author_id
       where p.author_id = p_user
         and p.parent_id is null
         and not public.blocked_me(p.author_id)
       order by
         case when p_sort = 'old' then p.created_at end asc,
         case when p_sort = 'top' then p.like_count end desc,
         p.created_at desc
       limit least(coalesce(limit_n, 30), 50)
   ) r;
$$;

revoke all on function public.get_user_posts(uuid, text, integer) from public, anon;
grant execute on function public.get_user_posts(uuid, text, integer) to authenticated;


-- ===========================================================================
-- 21. SYNC v3 - notifications + pinned post on the wire
-- ===========================================================================
--
-- Adds two keys:
--   'nt' - unread notifications, newest first, capped at 30
--   'pn' - the currently pinned post (or [] when nothing is pinned)
--
-- Both obey the same contract as every other list: ALWAYS present when the
-- payload is fresh, '[]' when empty, absent only when nothing changed. That
-- distinction is what the json_strip_nulls bug broke in v21 and it must not
-- be reintroduced.
create or replace function public.sync(since bigint default 0)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
   me   uuid := auth.uid();
   rev  bigint;
   fresh boolean;
begin
   if me is null then
      return json_build_object('e', 'auth');
   end if;

   select social_rev into rev from public.profiles where id = me;
   rev := coalesce(rev, 1);
   fresh := coalesce(since, 0) <= 0 or coalesce(since, 0) < rev;

   if not fresh then
      return json_build_object(
         'v', rev,
         'me', (select json_strip_nulls(json_build_object(
                  'fo', p.follower_count, 'fg', p.following_count,
                  'fr', p.friend_count, 'v', p.verified,
                  'pl', public.is_plus(p.id),
                  'ps', extract(epoch from p.plus_since)::bigint,
                  'pu', extract(epoch from p.plus_until)::bigint,
                  'pp', p.plus_permanent, 'sk', p.skin_name,
                  'nc', p.name_color, 'bg', p.equipped_badge,
                  'pc', p.profile_color, 'st', public.is_staff(p.id)))
                 from public.profiles p where p.id = me));
   end if;

   return json_build_object(
      'v', rev,

      'f',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', f.id, 'u', f.username, 'o', f.is_online,
                     's', f.server_name, 'b', p.equipped_badge, 'c', p.name_color,
                     'pl', public.is_plus(p.id), 'pr', p.presence,
                     'v', p.verified, 'sk', p.skin_name)))
               from public.get_friends() f
               join public.profiles p on p.id = f.id), '[]'::json),

      'r',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', s.username, 'sk', s.skin_name)))
               from public.friend_requests fr
               join public.profiles s on s.id = fr.sender_id
              where fr.receiver_id = me), '[]'::json),

      'ro', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', r.username, 'sk', r.skin_name)))
               from public.friend_requests fr
               join public.profiles r on r.id = fr.receiver_id
              where fr.sender_id = me), '[]'::json),

      'c',  coalesce((select json_agg(c) from public.get_conversations() c),
                     '[]'::json),

      'iv', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', i.id, 'u', p.username, 'l', i.label)))
               from public.invites i
               join public.profiles p on p.id = i.from_id
              where i.to_id = me and i.accepted = false
                and i.expires_at > now()), '[]'::json),

      -- Unread notifications. 'pv' is a short preview of the post body so the
      -- toast can say what was posted without a second round trip.
      'nt', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', n.id, 'k', n.kind,
                     'u', a.username, 'sk', a.skin_name,
                     'p', n.post_id,
                     'pv', left(po.body, 40),
                     't', extract(epoch from n.created_at)::bigint))
                     order by n.created_at desc)
               from public.notifications n
               left join public.profiles a on a.id = n.actor_id
               left join public.posts po on po.id = n.post_id
              where n.user_id = me and n.read_at is null
              limit 30), '[]'::json),

      -- The pinned post, rendered exactly like a feed row so the client can
      -- reuse its post renderer unchanged.
      'pn', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', p.id, 'u', pr.username, 'b', p.body,
                     't', extract(epoch from p.created_at)::bigint,
                     'bd', pr.equipped_badge, 'c', pr.name_color,
                     'pl', public.is_plus(pr.id), 'v', pr.verified,
                     'sk', pr.skin_name, 'lk', p.like_count,
                     'rc', p.reply_count, 'rp', p.repost_count,
                     'il', exists (select 1 from public.post_likes l
                                    where l.post_id = p.id and l.user_id = me),
                     'ir', exists (select 1 from public.post_reposts r
                                    where r.post_id = p.id and r.user_id = me))))
               from public.pinned_post pp
               join public.posts p on p.id = pp.post_id
               join public.profiles pr on pr.id = p.author_id
              where not public.blocked_me(p.author_id)), '[]'::json),

      'me', (select json_strip_nulls(json_build_object(
                     'fo', p.follower_count, 'fg', p.following_count,
                     'fr', p.friend_count, 'v', p.verified,
                     'pl', public.is_plus(p.id),
                     'ps', extract(epoch from p.plus_since)::bigint,
                     'pu', extract(epoch from p.plus_until)::bigint,
                     'pp', p.plus_permanent, 'sk', p.skin_name,
                     'nc', p.name_color, 'bg', p.equipped_badge,
                     'pc', p.profile_color, 'st', public.is_staff(p.id)))
               from public.profiles p where p.id = me));
end;
$$;

revoke all on function public.sync(bigint) from public, anon;
grant execute on function public.sync(bigint) to authenticated;


-- Keep the notification table from growing without bound.
create or replace function public.housekeeping()
returns json language plpgsql security definer set search_path = '' as $$
declare n integer := 0;
begin
   delete from public.invites where expires_at < now() - interval '1 day';
   -- mc_link_pending has created_at, NOT expires_at. Referencing a
   -- column that does not exist made the whole function throw, which
   -- silently disabled invite cleanup and Blue+ expiry as well.
   delete from public.mc_link_pending
    where created_at < now() - interval '10 minutes';
   perform public.clear_expired_plus();

   -- Read notifications age out fast; unread ones get two weeks.
   delete from public.notifications
    where (read_at is not null and read_at < now() - interval '2 days')
       or created_at < now() - interval '14 days';
   get diagnostics n = row_count;

   return json_build_object('ok', true, 'notifications_pruned', n);
end;
$$;

revoke all on function public.housekeeping() from public, anon;


-- ===========================================================================
-- 22. get_profile v2  -  everything the new profile PAGE needs
-- ===========================================================================
--
-- The v2 version predates verified, Blue+, skins, name colours and profile
-- colours, so the profile page could not render any of them. Return type
-- changes need a DROP first - "create or replace" cannot widen a table
-- signature.
drop function if exists public.get_profile(uuid);

create or replace function public.get_profile(target uuid)
returns table (
   id uuid, username text, mc_name text, mc_uuid uuid, mc_premium boolean,
   about text, status text, badge_id text, badge_label text, badge_colour integer,
   follower_count bigint, following_count bigint,
   is_following boolean, is_friend boolean, is_buddy boolean,
   is_online boolean, server_name text,
   skin_name text, verified boolean, is_plus boolean,
   name_color text, profile_color text,
   plus_since_epoch bigint, joined_epoch bigint,
   post_count bigint, is_staff boolean
)
language plpgsql stable security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null then raise exception 'not authenticated'; end if;
   if public.block_exists(me, target) then
      raise exception 'unavailable';
   end if;

   return query
   select p.id, p.username, p.mc_name, p.mc_uuid, p.mc_premium,
          p.about, p.status,
          b.id, b.label, b.colour,
          (select count(*) from public.follows f where f.followee_id = p.id),
          (select count(*) from public.follows f where f.follower_id = p.id),
          exists (select 1 from public.follows f
                  where f.follower_id = me and f.followee_id = p.id),
          public.are_friends(me, p.id),
          public.are_buddies(me, p.id),
          case when public.can_view(me, p.id, 'online') then p.is_online else false end,
          case when public.can_view(me, p.id, 'server') then p.server_name else null end,
          p.skin_name,
          p.verified,
          public.is_plus(p.id),
          p.name_color,
          p.profile_color,
          extract(epoch from p.plus_since)::bigint,
          extract(epoch from p.created_at)::bigint,
          (select count(*) from public.posts po
            where po.author_id = p.id and po.parent_id is null),
          public.is_staff(p.id)
   from public.profiles p
   left join public.badges b on b.id = p.equipped_badge
   where p.id = target;
end;
$$;

revoke all on function public.get_profile(uuid) from public, anon;
grant execute on function public.get_profile(uuid) to authenticated;


-- Look a profile up by name, so a post author can be opened without already
-- knowing their uuid.
create or replace function public.profile_id_by_name(p_name text)
returns uuid language sql stable security definer set search_path = '' as $$
   select id from public.profiles
    where username_low = lower(trim(p_name)) limit 1;
$$;

revoke all on function public.profile_id_by_name(text) from public, anon;
grant execute on function public.profile_id_by_name(text) to authenticated;


-- ===========================================================================
-- 23. AVATAR SYNC, MODERATION, ADMIN, ACCOUNT DELETION
-- ===========================================================================

-- ---- 23a. Avatars were falling back to the username -----------------------
--
-- leaderboard() and search_users() never returned skin_name, so those screens
-- rendered an avatar for the ACCOUNT name instead of the Minecraft skin the
-- player picked. Same player, two different faces depending on the screen.

drop function if exists public.leaderboard(integer);

create or replace function public.leaderboard(limit_n integer default 5)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(lb)), '[]'::json)
   from (
      select p.username as u, p.follower_count as f, p.equipped_badge as bd,
             p.verified as v, p.name_color as c, public.is_plus(p.id) as pl,
             p.skin_name as sk, p.id as i
        from public.profiles p
       where p.follower_count > 0
         and not public.blocked_me(p.id)
       order by p.follower_count desc, p.username asc
       limit least(coalesce(limit_n, 5), 25)
   ) lb;
$$;

revoke all on function public.leaderboard(integer) from public, anon;
grant execute on function public.leaderboard(integer) to authenticated;

drop function if exists public.search_users(text);

create or replace function public.search_users(q text)
returns table (id uuid, username text, skin_name text, verified boolean,
               is_plus boolean, equipped_badge text, name_color text)
language plpgsql stable security definer set search_path = '' as $$
declare
   me    uuid := auth.uid();
   clean text;
begin
   if me is null then
      raise exception 'not authenticated';
   end if;

   clean := lower(trim(coalesce(q, '')));
   -- Require 2 characters, so nobody enumerates everyone with "a".
   if char_length(clean) < 2 then
      return;
   end if;
   -- Escape LIKE wildcards so a search for "_" is literal.
   clean := replace(replace(clean, '\', '\\'), '%', '\%');
   clean := replace(clean, '_', '\_');

   return query
   select p.id, p.username, p.skin_name, p.verified,
          public.is_plus(p.id), p.equipped_badge, p.name_color
     from public.profiles p
    where p.username_low like clean || '%'
      and p.id <> me
      and not public.block_exists(me, p.id)
    order by p.username_low
    limit 20;
end;
$$;

revoke all on function public.search_users(text) from public, anon;
grant execute on function public.search_users(text) to authenticated;


-- ---- 23b. Content moderation ----------------------------------------------
--
-- Owner: "add anti spam and anti swear and no political and such stuff".
--
-- Design notes, because naive filters cause more grief than they prevent:
--
--  * Matching is on WORD BOUNDARIES, never substrings. A substring filter is
--    the classic Scunthorpe problem - it blocks "class", "assassin",
--    "Cockburn" and real place names. Every pattern here is anchored.
--
--  * Leetspeak is normalised first (4->a, 3->e, 1/!->i, 0->o, $->s) so the
--    obvious evasions are caught, and repeated letters are collapsed so
--    "shiiiit" matches "shit".
--
--  * The list is a TABLE, not a hardcoded regex, so the owner can edit it
--    live without a client update.
--
--  * Political terms are handled as a SOFT category: Blue Client is a game
--    client, and arguments about politics belong elsewhere - but the penalty
--    is a rejected post, not a ban.

create table if not exists public.banned_words (
   word      text primary key,
   category  text not null default 'profanity'
             check (category in ('profanity', 'slur', 'political', 'spam')),
   -- 'block' refuses the post; 'flag' allows it but records it for review.
   action    text not null default 'block' check (action in ('block', 'flag')),
   added_at  timestamptz not null default now()
);

alter table public.banned_words enable row level security;
-- Nobody but staff reads the list: publishing it is publishing an evasion
-- guide. The check function is security definer and reads it regardless.
drop policy if exists banned_staff_read on public.banned_words;
create policy banned_staff_read on public.banned_words
   for select to authenticated using (public.is_staff());
revoke insert, update, delete on public.banned_words from authenticated, anon;

insert into public.banned_words (word, category, action) values
   -- Profanity. Deliberately a short list of unambiguous terms; the goal is
   -- to keep a public feed civil, not to police every word.
   ('fuck','profanity','block'), ('shit','profanity','block'),
   ('bitch','profanity','block'), ('cunt','slur','block'),
   ('asshole','profanity','block'), ('bastard','profanity','block'),
   ('dick','profanity','flag'), ('piss','profanity','flag'),
   ('whore','slur','block'), ('slut','slur','block'),
   ('retard','slur','block'), ('faggot','slur','block'),
   ('nigger','slur','block'), ('nigga','slur','block'),
   ('rape','slur','block'), ('kys','slur','block'),
   -- Political. Flagged as its own category so the message can explain WHY,
   -- rather than calling someone's opinion profanity.
   ('trump','political','block'), ('biden','political','block'),
   ('putin','political','block'), ('zionist','political','block'),
   ('hamas','political','block'), ('israel','political','block'),
   ('palestine','political','block'), ('hitler','political','block'),
   ('nazi','political','block'), ('communist','political','flag'),
   ('abortion','political','block'), ('election','political','flag')
on conflict (word) do nothing;


-- Normalises text for matching: lowercase, de-leet, collapse runs, strip
-- anything that is not a letter or a space.
--
-- Runs collapse to a SINGLE character, not two. Collapsing "shiiiit" to
-- "shiit" still does not match "shit", so that evasion sailed straight
-- through - which defeats the point of the rule. Collapsing fully gives
-- "shit" and it matches.
--
-- Trade-off, stated plainly: words with genuine double letters collapse too
-- ("pass" -> "pas"), so any banned word containing a double must be stored in
-- its collapsed form. None of the current entries have doubles.
create or replace function public.normalize_for_filter(p_text text)
returns text language sql immutable set search_path = '' as $$
   select regexp_replace(
            regexp_replace(
              regexp_replace(
                translate(lower(coalesce(p_text, '')),
                          '4310$@!|', 'aeiosai1'),
                '[^a-z ]', ' ', 'g'),
              '(.)\1+', '\1', 'g'),
            '\s+', ' ', 'g');
$$;


/**
 * Checks a message against the word list and the spam rules.
 *
 * Returns {ok:true} or {ok:false, m:<reason>, c:<category>}.
 */
create or replace function public.check_content(p_text text)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
   me    uuid := auth.uid();
   norm  text;
   hit   record;
   caps  numeric;
   letters int;
begin
   if p_text is null or btrim(p_text) = '' then
      return json_build_object('ok', false, 'm', 'Say something first');
   end if;

   norm := public.normalize_for_filter(p_text);

   -- Word-boundary match only. \m and \M are Postgres word boundaries, so
   -- "class" never trips the "ass" pattern.
   select w.word, w.category, w.action into hit
     from public.banned_words w
    where w.action = 'block'
      and norm ~ ('\m' || w.word || '\M')
    limit 1;

   if found then
      return json_build_object('ok', false, 'c', hit.category, 'm',
         case hit.category
            when 'political' then
               'Blue Client is not the place for politics - keep it about the game'
            when 'slur' then
               'That word is not allowed here'
            else
               'Please keep it clean'
         end);
   end if;

   -- SHOUTING: more than 70% capitals in a message of real length.
   letters := length(regexp_replace(p_text, '[^A-Za-z]', '', 'g'));
   if letters >= 12 then
      caps := length(regexp_replace(p_text, '[^A-Z]', '', 'g'))::numeric / letters;
      if caps > 0.7 then
         return json_build_object('ok', false, 'c', 'spam',
            'm', 'Please do not type in all caps');
      end if;
   end if;

   -- Character spam: a long run of ONE character that also dominates the
   -- message. Both halves matter - "nooooooooo" inside a real sentence is not
   -- spam, but a post that is 90% one repeated character is.
   --
   -- The earlier version tripped on any 8-character run, which rejected
   -- perfectly ordinary emphatic text (and every length-check fixture in the
   -- test suite).
   if p_text ~ '(.)\1{11,}'
      and length(regexp_replace(p_text, '(.)\1{3,}', '', 'g'))
          < length(p_text) / 2 then
      return json_build_object('ok', false, 'c', 'spam',
         'm', 'That looks like spam');
   end if;

   -- Link spam. One link is fine; three or more in a short post is not.
   if (length(p_text) - length(replace(lower(p_text), 'http', ''))) / 4 >= 3 then
      return json_build_object('ok', false, 'c', 'spam',
         'm', 'Too many links');
   end if;

   -- Duplicate posting: the same text twice within ten minutes.
   if me is not null and exists (
         select 1 from public.posts
          where author_id = me
            and created_at > now() - interval '10 minutes'
            and public.normalize_for_filter(body) = norm) then
      return json_build_object('ok', false, 'c', 'spam',
         'm', 'You already posted that');
   end if;

   return json_build_object('ok', true);
end;
$$;

grant execute on function public.check_content(text) to authenticated;
grant execute on function public.normalize_for_filter(text) to authenticated;


-- ---- 23c. Enforce the filter where content is created ---------------------
--
-- Enforcement lives in the DATABASE, not the client. A modified client can
-- skip any check it likes; it cannot skip this one.

create or replace function public.trg_filter_post()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v json;
begin
   v := public.check_content(new.body);
   if not (v->>'ok')::boolean then
      raise exception '%', coalesce(v->>'m', 'Rejected');
   end if;
   return new;
end;
$$;

drop trigger if exists posts_filter on public.posts;
create trigger posts_filter before insert on public.posts
   for each row execute function public.trg_filter_post();

create or replace function public.trg_filter_message()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v json;
begin
   v := public.check_content(new.body);
   if not (v->>'ok')::boolean then
      raise exception '%', coalesce(v->>'m', 'Rejected');
   end if;
   return new;
end;
$$;

drop trigger if exists messages_filter on public.messages;
create trigger messages_filter before insert on public.messages
   for each row execute function public.trg_filter_message();

-- About / status go through their own RPCs, so filter there too.
create or replace function public.set_about(p_about text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); cap int; v json;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   if p_about is not null and btrim(p_about) <> '' then
      v := public.check_content(p_about);
      if not (v->>'ok')::boolean then
         return json_build_object('ok', false, 'm', v->>'m');
      end if;
   end if;
   -- Truncate, do not reject: this matches create_post and reply_to_post.
   -- The client counts characters already, so over-long input here means a
   -- desync or a tampered client, and silently trimming is kinder than
   -- throwing away what the player wrote.
   cap := public.limit_of(me, 'about');
   update public.profiles set about = left(p_about, cap) where id = me;
   return json_build_object('ok', true);
end;
$$;

grant execute on function public.set_about(text) to authenticated;


-- ---- 23d. Admin: reports, and the moderation actions ----------------------

create table if not exists public.reports (
   id          bigint generated always as identity primary key,
   reporter_id uuid not null references public.profiles(id) on delete cascade,
   target_id   uuid references public.profiles(id) on delete cascade,
   post_id     uuid references public.posts(id) on delete cascade,
   reason      text not null,
   created_at  timestamptz not null default now(),
   resolved_at timestamptz,
   unique (reporter_id, post_id)
);

alter table public.reports enable row level security;
drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports
   for insert to authenticated with check (reporter_id = auth.uid());
drop policy if exists reports_read on public.reports;
create policy reports_read on public.reports
   for select to authenticated using (public.is_staff());
revoke update, delete on public.reports from authenticated, anon;

create or replace function public.report_post(p_post uuid, p_reason text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); owner uuid;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   select author_id into owner from public.posts where id = p_post;
   if owner is null then
      return json_build_object('ok', false, 'm', 'That post is gone');
   end if;
   insert into public.reports (reporter_id, target_id, post_id, reason)
   values (me, owner, p_post, left(coalesce(p_reason, 'Not specified'), 200))
   on conflict (reporter_id, post_id) do nothing;
   return json_build_object('ok', true);
end;
$$;

grant execute on function public.report_post(uuid, text) to authenticated;


/**
 * The admin panel's data, in one call. Staff only.
 *
 * Returns {ok:false} for everyone else - the client hides the button, but the
 * SERVER is what actually enforces it. Hiding a button is not security.
 */
create or replace function public.admin_overview()
returns json language plpgsql stable security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;

   return json_build_object(
      'ok', true,
      'stats', json_build_object(
         'users',  (select count(*) from public.profiles),
         'posts',  (select count(*) from public.posts where parent_id is null),
         'online', (select count(*) from public.profiles where is_online),
         'plus',   (select count(*) from public.profiles
                     where plus_permanent or plus_until > now()),
         'new24',  (select count(*) from public.profiles
                     where created_at > now() - interval '24 hours')),
      'reports', coalesce((
         select json_agg(json_strip_nulls(json_build_object(
                  'i', r.id, 'u', rep.username, 't', tgt.username,
                  'p', r.post_id, 'b', left(po.body, 60), 'r', r.reason,
                  'at', extract(epoch from r.created_at)::bigint))
                order by r.created_at desc)
           from public.reports r
           join public.profiles rep on rep.id = r.reporter_id
           left join public.profiles tgt on tgt.id = r.target_id
           left join public.posts po on po.id = r.post_id
          where r.resolved_at is null
          limit 25), '[]'::json),
      'recent', coalesce((
         select json_agg(json_strip_nulls(json_build_object(
                  'i', p.id, 'u', pr.username, 'b', left(p.body, 60),
                  't', extract(epoch from p.created_at)::bigint))
                order by p.created_at desc)
           from public.posts p
           join public.profiles pr on pr.id = p.author_id
          where p.parent_id is null
          limit 25), '[]'::json));
end;
$$;

revoke all on function public.admin_overview() from public, anon;
grant execute on function public.admin_overview() to authenticated;


/** Staff: delete any post. */
create or replace function public.admin_delete_post(p_post uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;
   delete from public.posts where id = p_post;
   update public.reports set resolved_at = now()
    where post_id = p_post and resolved_at is null;
   return json_build_object('ok', true);
end;
$$;

/** Staff: grant or revoke a badge. */
create or replace function public.admin_set_badge(p_user uuid, p_badge text,
                                                  p_grant boolean)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;
   if p_grant then
      insert into public.user_badges (user_id, badge_id) values (p_user, p_badge)
      on conflict do nothing;
   else
      delete from public.user_badges where user_id = p_user and badge_id = p_badge;
      update public.profiles set equipped_badge = null
       where id = p_user and equipped_badge = p_badge;
   end if;
   perform public.bump_social_rev(array[p_user]);
   return json_build_object('ok', true);
end;
$$;

/** Staff: grant Blue+ for a number of days, or permanently with 0. */
create or replace function public.admin_grant_plus(p_user uuid, p_days integer)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;
   if coalesce(p_days, 0) <= 0 then
      update public.profiles
         set plus_permanent = true, plus_since = coalesce(plus_since, now())
       where id = p_user;
   else
      update public.profiles
         set plus_until = greatest(coalesce(plus_until, now()), now())
                          + make_interval(days => p_days),
             plus_since = coalesce(plus_since, now())
       where id = p_user;
   end if;
   perform public.bump_social_rev(array[p_user]);
   return json_build_object('ok', true);
end;
$$;

/** Staff: resolve a report without deleting anything. */
create or replace function public.admin_dismiss_report(p_report bigint)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;
   update public.reports set resolved_at = now() where id = p_report;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.admin_delete_post(uuid) from public, anon;
revoke all on function public.admin_set_badge(uuid, text, boolean) from public, anon;
revoke all on function public.admin_grant_plus(uuid, integer) from public, anon;
revoke all on function public.admin_dismiss_report(bigint) from public, anon;
grant execute on function public.admin_delete_post(uuid) to authenticated;
grant execute on function public.admin_set_badge(uuid, text, boolean) to authenticated;
grant execute on function public.admin_grant_plus(uuid, integer) to authenticated;
grant execute on function public.admin_dismiss_report(bigint) to authenticated;


-- ---- 23e. Account deletion ------------------------------------------------
--
-- Deleting the profile row cascades to posts, friendships, follows, likes,
-- messages and badges, because every one of those tables declares
-- "on delete cascade" against profiles(id).
--
-- The auth.users row is NOT deleted here: that needs the service_role key,
-- which must never ship in the client. The profile is gone, the username is
-- freed, and the orphaned auth row can log in but owns nothing. The owner can
-- purge those from the dashboard.

create or replace function public.delete_my_account(p_confirm text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); uname text;
begin
   if me is null then
      return json_build_object('ok', false, 'm', 'Not logged in');
   end if;
   select username into uname from public.profiles where id = me;
   if uname is null then
      return json_build_object('ok', false, 'm', 'No profile to delete');
   end if;

   -- Typing the username is the confirmation. An accidental click must not be
   -- able to destroy an account.
   if lower(coalesce(p_confirm, '')) <> lower(uname) then
      return json_build_object('ok', false, 'm',
         'Type your username exactly to confirm');
   end if;

   -- Staff cannot delete themselves: setup_staff() would recreate half of it
   -- and the badges would be left dangling.
   if public.is_staff(me) then
      return json_build_object('ok', false, 'm',
         'Staff accounts cannot be deleted from the client');
   end if;

   delete from public.profiles where id = me;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.delete_my_account(text) from public, anon;
grant execute on function public.delete_my_account(text) to authenticated;


-- ===========================================================================
-- 24. OWNER TRANSFER  -  staff becomes DATA, not hardcoded strings
-- ===========================================================================
--
-- Owner: "change the owner account and remove every permission from Blue and
-- give it to bluewuztaken".
--
-- The old design hardcoded 'blue' and 'cyan' in EIGHT different places: the
-- follow cap, the auto-follow trigger, setup_staff, staff_on_signup, is_staff
-- and more. Changing the owner meant finding all eight and hoping none were
-- missed - and a missed one is a security hole, because it would still grant
-- powers to an account that is supposed to have none.
--
-- So staff is now a TABLE. One row per staff account, one place to edit, and
-- every check reads from it.

create table if not exists public.staff_accounts (
   username_low text primary key,
   role         text not null default 'admin'
                check (role in ('owner', 'admin')),
   added_at     timestamptz not null default now()
);

alter table public.staff_accounts enable row level security;

-- Readable by signed-in users: the client needs to know who is staff to draw
-- badges. It is not secret - who runs the service is public information.
drop policy if exists staff_read on public.staff_accounts;
create policy staff_read on public.staff_accounts
   for select to authenticated using (true);

-- Writable by NOBODY through the API. Changing who is staff is a deliberate
-- act performed in the SQL editor, never something a client can request.
revoke insert, update, delete on public.staff_accounts from authenticated, anon;

-- THE TRANSFER.
-- bluewuztaken becomes owner; cyan stays admin; blue is removed entirely.
delete from public.staff_accounts;
insert into public.staff_accounts (username_low, role) values
   ('bluewuztaken', 'owner'),
   ('cyan',         'admin')
on conflict (username_low) do update set role = excluded.role;


-- is_staff now reads the table. Every other check goes through this, so this
-- single function is the whole permission surface.
create or replace function public.is_staff(uid uuid default auth.uid())
returns boolean language sql stable security definer set search_path = '' as $$
   select exists (
      select 1 from public.profiles p
        join public.staff_accounts s on s.username_low = p.username_low
       where p.id = uid);
$$;

/** True only for the single owner account. */
create or replace function public.is_owner(uid uuid default auth.uid())
returns boolean language sql stable security definer set search_path = '' as $$
   select exists (
      select 1 from public.profiles p
        join public.staff_accounts s on s.username_low = p.username_low
       where p.id = uid and s.role = 'owner');
$$;

grant execute on function public.is_staff(uuid) to authenticated;
grant execute on function public.is_owner(uuid) to authenticated;


-- ---- rewire the seven other hardcoded checks ------------------------------

create or replace function public.enforce_follow_cap()
returns trigger language plpgsql security definer set search_path = '' as $$
declare cap integer; have integer;
begin
   -- Staff are free follows and never count toward the cap, or the
   -- auto-follows would eat slots from everyone's limit.
   if public.is_staff(new.followee_id) then
      return new;
   end if;

   cap := public.limit_of(new.follower_id, 'following');
   select count(*) into have
     from public.follows f
     join public.profiles p on p.id = f.followee_id
    where f.follower_id = new.follower_id
      and not public.is_staff(p.id);

   if have >= cap then
      raise exception 'You can follow at most % people', cap;
   end if;
   return new;
end;
$$;

create or replace function public.auto_follow_staff()
returns trigger language plpgsql security definer set search_path = '' as $$
declare sid uuid;
begin
   for sid in select p.id from public.profiles p
               join public.staff_accounts s on s.username_low = p.username_low
              where p.id <> new.id
   loop
      insert into public.follows (follower_id, followee_id) values (new.id, sid)
      on conflict do nothing;
   end loop;
   return new;
end;
$$;

-- Staff setup: every badge, verified forever, permanent Blue+.
-- Idempotent, and safe to run before those accounts exist.
create or replace function public.setup_staff()
returns json language plpgsql security definer set search_path = '' as $$
declare found integer := 0; sid uuid; nm text; srole text;
begin
   for sid, nm, srole in
      select p.id, p.username_low, s.role
        from public.profiles p
        join public.staff_accounts s on s.username_low = p.username_low
   loop
      found := found + 1;

      insert into public.user_badges (user_id, badge_id)
      select sid, b.id from public.badges b
      on conflict do nothing;

      update public.profiles
         set verified = true, verified_forced = true,
             plus_permanent = true, plus_since = coalesce(plus_since, now()),
             equipped_badge = coalesce(equipped_badge,
                                case when srole = 'owner' then 'founder'
                                     else 'co_founder' end)
       where id = sid;

      -- Everyone who already registered should follow them.
      insert into public.follows (follower_id, followee_id)
      select p.id, sid from public.profiles p
       where p.id <> sid
         and not exists (select 1 from public.staff_accounts s2
                          where s2.username_low = p.username_low)
      on conflict do nothing;
   end loop;

   return json_build_object('ok', true, 'staff_found', found);
end;
$$;

grant execute on function public.setup_staff() to authenticated;

create or replace function public.staff_on_signup()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
   if exists (select 1 from public.staff_accounts
               where username_low = new.username_low) then
      perform public.setup_staff();
   end if;
   return new;
end;
$$;


-- ---- STRIP THE OLD OWNER --------------------------------------------------
--
-- Removing 'blue' from staff_accounts stops future grants, but it does NOT
-- take back what setup_staff already gave that account. Every privilege has
-- to be revoked explicitly, or the old owner keeps all nine badges, forced
-- verification and permanent Blue+ forever.
do $$
declare bid uuid;
begin
   select id into bid from public.profiles where username_low = 'blue';
   if bid is null then
      return;                              -- account never existed; nothing to do
   end if;

   -- Every badge granted by setup_staff.
   delete from public.user_badges where user_id = bid;

   -- Forced verification, permanent Blue+, the equipped staff badge.
   -- verified drops to whatever the 100-follower rule says it should be.
   update public.profiles
      set verified_forced = false,
          verified = (follower_count >= 100),
          plus_permanent = false,
          plus_until = null,
          plus_since = null,
          equipped_badge = null,
          name_color = null,
          profile_color = null
    where id = bid;

   -- Any post it pinned stops being pinned.
   delete from public.pinned_post where pinned_by = bid;

   perform public.bump_social_rev(array[bid]);
end;
$$;


-- ===========================================================================
-- 25. ADMIN: REDEEM CODE CREATION
-- ===========================================================================
--
-- Owner: "in admin panel, I should also be able to create redeem codes and
-- specify what they give."
--
-- redeem_codes already supported plus / badge / cosmetic with a duration, but
-- codes could only be inserted by hand in the SQL editor. These RPCs put that
-- in the panel, staff-gated server-side like every other admin action.

/**
 * Creates a redeem code.
 *
 * @param p_code      the code itself; uppercased, must match ^[A-Z0-9_-]{4,32}$
 * @param p_kind      'plus' | 'badge' | 'cosmetic'
 * @param p_value     badge id or cosmetic id; ignored for 'plus'
 * @param p_days      for 'plus': days granted. 0 or null = PERMANENT.
 * @param p_expires   days until the code itself stops working; null = never
 * @param p_note      private note, never shown to players
 */
create or replace function public.admin_create_code(
   p_code text, p_kind text, p_value text default null,
   p_days integer default null, p_expires integer default null,
   p_note text default null)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); c text;
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;

   c := upper(btrim(coalesce(p_code, '')));
   if c !~ '^[A-Z0-9_-]{4,32}$' then
      return json_build_object('ok', false, 'm',
         'Codes are 4-32 characters: A-Z, 0-9, _ and - only');
   end if;
   if p_kind not in ('plus', 'badge', 'cosmetic') then
      return json_build_object('ok', false, 'm', 'Kind must be plus, badge or cosmetic');
   end if;
   if exists (select 1 from public.redeem_codes where code = c) then
      return json_build_object('ok', false, 'm', 'That code already exists');
   end if;

   -- A badge code that names a badge which does not exist would fail silently
   -- at redeem time, leaving the player with a "redeemed" code and nothing.
   if p_kind = 'badge' then
      if p_value is null or not exists (select 1 from public.badges where id = p_value) then
         return json_build_object('ok', false, 'm', 'No badge with that id');
      end if;
   end if;

   insert into public.redeem_codes
      (code, kind, value, plus_days, note, expires_at)
   values
      (c, p_kind,
       case when p_kind = 'plus' then null else p_value end,
       case when p_kind = 'plus' then coalesce(p_days, 0) else null end,
       left(coalesce(p_note, ''), 200),
       case when coalesce(p_expires, 0) > 0
            then now() + make_interval(days => p_expires) end);

   return json_build_object('ok', true, 'code', c);
end;
$$;

/** Lists recent codes and whether they have been used. Staff only. */
create or replace function public.admin_list_codes(limit_n integer default 30)
returns json language plpgsql stable security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;

   return json_build_object('ok', true, 'codes', coalesce((
      select json_agg(json_strip_nulls(json_build_object(
               'c', r.code, 'k', r.kind, 'v', r.value, 'd', r.plus_days,
               'n', r.note,
               'by', u.username,
               'at', extract(epoch from r.redeemed_at)::bigint,
               'ex', extract(epoch from r.expires_at)::bigint))
             order by r.created_at desc)
        from public.redeem_codes r
        left join public.profiles u on u.id = r.redeemed_by
       limit least(coalesce(limit_n, 30), 100)), '[]'::json));
end;
$$;

/** Deletes an unused code. Used codes are kept as a record. */
create or replace function public.admin_delete_code(p_code text)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;
   delete from public.redeem_codes
    where code = upper(btrim(p_code)) and redeemed_by is null;
   if not found then
      return json_build_object('ok', false, 'm',
         'No such unused code - used codes are kept as a record');
   end if;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.admin_create_code(text, text, text, integer, integer, text)
   from public, anon;
revoke all on function public.admin_list_codes(integer) from public, anon;
revoke all on function public.admin_delete_code(text) from public, anon;
grant execute on function public.admin_create_code(text, text, text, integer, integer, text)
   to authenticated;
grant execute on function public.admin_list_codes(integer) to authenticated;
grant execute on function public.admin_delete_code(text) to authenticated;


-- ===========================================================================
-- 26. SELF-CHECK  -  run this to confirm the schema actually applied
-- ===========================================================================
--
-- Several rounds of "feature X is broken" turned out to be "schema_v3 was
-- never applied". This makes that answerable in one query instead of by
-- guessing from symptoms.
--
--   select * from public.blue_selfcheck();
--
-- Every row should say OK. Anything that says MISSING explains exactly which
-- feature will appear broken in-game.

create or replace function public.blue_selfcheck()
returns table (item text, state text, affects text)
language plpgsql stable security definer set search_path = '' as $$
begin
   return query
   select 'staff_accounts table',
          case when to_regclass('public.staff_accounts') is not null
               then 'OK' else 'MISSING' end,
          'Admin panel button, staff badges'
   union all
   select 'profiles.profile_color',
          case when exists (select 1 from information_schema.columns
                             where table_schema = 'public' and table_name = 'profiles'
                               and column_name = 'profile_color')
               then 'OK' else 'MISSING' end,
          'Blue+ profile banner'
   union all
   select 'notifications table',
          case when to_regclass('public.notifications') is not null
               then 'OK' else 'MISSING' end,
          'Follow-post and pinned notifications'
   union all
   select 'pinned_post table',
          case when to_regclass('public.pinned_post') is not null
               then 'OK' else 'MISSING' end,
          'Pinned post on Home'
   union all
   select 'banned_words table',
          case when to_regclass('public.banned_words') is not null
               then 'OK' else 'MISSING' end,
          'Anti-swear / anti-spam filter'
   union all
   select 'get_profile returns skin',
          case when exists (select 1 from information_schema.routines r
                             join information_schema.parameters p
                               on p.specific_name = r.specific_name
                            where r.routine_schema = 'public'
                              and r.routine_name = 'get_profile'
                              and p.parameter_name = 'skin_name')
               then 'OK' else 'MISSING' end,
          'Profile page shows the wrong skin'
   union all
   select 'admin RPCs',
          case when to_regproc('public.admin_overview') is not null
               and to_regproc('public.admin_create_code') is not null
               then 'OK' else 'MISSING' end,
          'Admin panel and redeem-code creation'
   union all
   select 'account deletion',
          case when to_regproc('public.delete_my_account') is not null
               then 'OK' else 'MISSING' end,
          'Delete account button'
   union all
   select 'announcements table',
          case when to_regclass('public.announcements') is not null
               and to_regproc('public.admin_announce') is not null
               then 'OK' else 'MISSING' end,
          'Admin panel broadcast / announcement toast'
   union all
   select 'owner is bluewuztaken',
          case when exists (select 1 from public.staff_accounts
                             where username_low = 'bluewuztaken' and role = 'owner')
               then 'OK' else 'MISSING' end,
          'Owner permissions'
   union all
   select 'old owner stripped',
          case when not exists (select 1 from public.profiles
                                 where username_low = 'blue' and plus_permanent)
               then 'OK' else 'STILL HAS PLUS' end,
          'blue should have no staff perks';
end;
$$;

grant execute on function public.blue_selfcheck() to authenticated;


-- ===========================================================================
-- 27. PROFILE PAGE: THE FULL BADGE COLLECTION
-- ===========================================================================
--
-- get_profile returned only the EQUIPPED badge, so a profile could never show
-- the badge row the owner asked for - and the hover descriptions written in
-- BadgeArt had nowhere to appear. Discord shows every badge a user owns; this
-- returns the same, ordered by the badges table's own priority so Founder
-- always sorts ahead of Supporter.

create or replace function public.profile_badges(target uuid)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(json_build_object(
             'id', b.id, 'l', b.label, 'c', b.colour, 'd', b.description)
             order by b.priority desc), '[]'::json)
     from public.user_badges ub
     join public.badges b on b.id = ub.badge_id
    where ub.user_id = target;
$$;

revoke all on function public.profile_badges(uuid) from public, anon;
grant execute on function public.profile_badges(uuid) to authenticated;


-- ===========================================================================
-- 28. STAFF ANNOUNCEMENTS  -  a toast broadcast to every Blue Client user
-- ===========================================================================
--
-- Owner: "I can make a custom toast with text using the admin panel that is
-- broadcasted to all the Blue Client users, no matter what server they are in
-- and even the main menu and singleplayer."
--
-- Design notes:
--
--  * ONE table, not one row per recipient. A fan-out insert to every profile
--    would be thousands of rows per announcement and would dominate the
--    notifications table. Instead the client remembers the highest id it has
--    shown and asks "anything newer?" - which is a single indexed read.
--
--  * Delivered through sync(), so it reaches the player wherever they are:
--    any server, singleplayer, or sitting on the main menu. The client polls
--    sync() regardless of world state, so no server plugin is involved.
--
--  * expires_at stops an old announcement popping up for someone who has not
--    played in a month.

create table if not exists public.announcements (
   id         bigint generated always as identity primary key,
   body       text not null check (char_length(body) between 1 and 200),
   accent     text not null default 'blue'
              check (accent in ('blue', 'green', 'gold', 'red')),
   created_by uuid references public.profiles(id) on delete set null,
   created_at timestamptz not null default now(),
   expires_at timestamptz not null default now() + interval '2 days'
);

create index if not exists announcements_live_idx
   on public.announcements (id desc, expires_at);

alter table public.announcements enable row level security;

-- Everyone signed in may READ them; only staff RPCs may write.
drop policy if exists announce_read on public.announcements;
create policy announce_read on public.announcements
   for select to authenticated using (true);
revoke insert, update, delete on public.announcements from authenticated, anon;

/**
 * Broadcasts an announcement. Staff only.
 *
 * @param p_hours how long it stays live; clamped to 1..168 (a week)
 */
create or replace function public.admin_announce(p_body text,
                                                 p_accent text default 'blue',
                                                 p_hours integer default 48)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid(); v json; newid bigint;
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;

   p_body := btrim(coalesce(p_body, ''));
   if p_body = '' then
      return json_build_object('ok', false, 'm', 'Write something first');
   end if;
   if char_length(p_body) > 200 then
      return json_build_object('ok', false, 'm', 'Announcements are limited to 200 characters');
   end if;

   -- Staff are not exempt from the content filter. An announcement reaches
   -- every user at once, so it is the LAST place to allow a slur through.
   v := public.check_content(p_body);
   if not (v->>'ok')::boolean then
      return json_build_object('ok', false, 'm', v->>'m');
   end if;

   if coalesce(p_accent, 'blue') not in ('blue', 'green', 'gold', 'red') then
      p_accent := 'blue';
   end if;

   insert into public.announcements (body, accent, created_by, expires_at)
   values (p_body, p_accent, me,
           now() + make_interval(hours => least(greatest(coalesce(p_hours, 48), 1), 168)))
   returning id into newid;

   -- Bump EVERY profile so the next sync for each user is a fresh one and the
   -- announcement is actually delivered rather than waiting for some other
   -- change to move their revision.
   update public.profiles set social_rev = social_rev + 1;

   return json_build_object('ok', true, 'id', newid);
end;
$$;

/** Removes an announcement early. Staff only. */
create or replace function public.admin_unannounce(p_id bigint)
returns json language plpgsql security definer set search_path = '' as $$
declare me uuid := auth.uid();
begin
   if me is null or not public.is_staff(me) then
      return json_build_object('ok', false, 'm', 'Not authorised');
   end if;
   delete from public.announcements where id = p_id;
   return json_build_object('ok', true);
end;
$$;

revoke all on function public.admin_announce(text, text, integer) from public, anon;
revoke all on function public.admin_unannounce(bigint) from public, anon;
grant execute on function public.admin_announce(text, text, integer) to authenticated;
grant execute on function public.admin_unannounce(bigint) to authenticated;


-- Deliver live announcements through sync() under the key 'an'.
-- Rebuilt in full because a function body cannot be patched in place.
create or replace function public.sync(since bigint default 0)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
   me   uuid := auth.uid();
   rev  bigint;
   fresh boolean;
begin
   if me is null then
      return json_build_object('e', 'auth');
   end if;

   select social_rev into rev from public.profiles where id = me;
   rev := coalesce(rev, 1);
   fresh := coalesce(since, 0) <= 0 or coalesce(since, 0) < rev;

   if not fresh then
      return json_build_object(
         'v', rev,
         'me', (select json_strip_nulls(json_build_object(
                  'fo', p.follower_count, 'fg', p.following_count,
                  'fr', p.friend_count, 'v', p.verified,
                  'pl', public.is_plus(p.id),
                  'ps', extract(epoch from p.plus_since)::bigint,
                  'pu', extract(epoch from p.plus_until)::bigint,
                  'pp', p.plus_permanent, 'sk', p.skin_name,
                  'nc', p.name_color, 'bg', p.equipped_badge,
                  'pc', p.profile_color, 'st', public.is_staff(p.id)))
                 from public.profiles p where p.id = me));
   end if;

   return json_build_object(
      'v', rev,

      'f',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', f.id, 'u', f.username, 'o', f.is_online,
                     's', f.server_name, 'b', p.equipped_badge, 'c', p.name_color,
                     'pl', public.is_plus(p.id), 'pr', p.presence,
                     'v', p.verified, 'sk', p.skin_name)))
               from public.get_friends() f
               join public.profiles p on p.id = f.id), '[]'::json),

      'r',  coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', s.username, 'sk', s.skin_name)))
               from public.friend_requests fr
               join public.profiles s on s.id = fr.sender_id
              where fr.receiver_id = me), '[]'::json),

      'ro', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', fr.id, 'u', r.username, 'sk', r.skin_name)))
               from public.friend_requests fr
               join public.profiles r on r.id = fr.receiver_id
              where fr.sender_id = me), '[]'::json),

      'c',  coalesce((select json_agg(c) from public.get_conversations() c),
                     '[]'::json),

      'iv', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', i.id, 'u', p.username, 'l', i.label)))
               from public.invites i
               join public.profiles p on p.id = i.from_id
              where i.to_id = me and i.accepted = false
                and i.expires_at > now()), '[]'::json),

      'nt', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', n.id, 'k', n.kind,
                     'u', a.username, 'sk', a.skin_name,
                     'p', n.post_id,
                     'pv', left(po.body, 40),
                     't', extract(epoch from n.created_at)::bigint))
                     order by n.created_at desc)
               from public.notifications n
               left join public.profiles a on a.id = n.actor_id
               left join public.posts po on po.id = n.post_id
              where n.user_id = me and n.read_at is null
              limit 30), '[]'::json),

      -- Live staff announcements, newest first. The client tracks the highest
      -- id it has already shown, so re-sending them is harmless.
      'an', coalesce((select json_agg(json_build_object(
                     'i', a.id, 'b', a.body, 'c', a.accent,
                     't', extract(epoch from a.created_at)::bigint)
                     order by a.id desc)
               from public.announcements a
              where a.expires_at > now()
              limit 5), '[]'::json),

      'pn', coalesce((select json_agg(json_strip_nulls(json_build_object(
                     'i', p.id, 'u', pr.username, 'b', p.body,
                     't', extract(epoch from p.created_at)::bigint,
                     'bd', pr.equipped_badge, 'c', pr.name_color,
                     'pl', public.is_plus(pr.id), 'v', pr.verified,
                     'sk', pr.skin_name, 'lk', p.like_count,
                     'rc', p.reply_count, 'rp', p.repost_count,
                     'il', exists (select 1 from public.post_likes l
                                    where l.post_id = p.id and l.user_id = me),
                     'ir', exists (select 1 from public.post_reposts r
                                    where r.post_id = p.id and r.user_id = me))))
               from public.pinned_post pp
               join public.posts p on p.id = pp.post_id
               join public.profiles pr on pr.id = p.author_id
              where not public.blocked_me(p.author_id)), '[]'::json),

      'me', (select json_strip_nulls(json_build_object(
                     'fo', p.follower_count, 'fg', p.following_count,
                     'fr', p.friend_count, 'v', p.verified,
                     'pl', public.is_plus(p.id),
                     'ps', extract(epoch from p.plus_since)::bigint,
                     'pu', extract(epoch from p.plus_until)::bigint,
                     'pp', p.plus_permanent, 'sk', p.skin_name,
                     'nc', p.name_color, 'bg', p.equipped_badge,
                     'pc', p.profile_color, 'st', public.is_staff(p.id)))
               from public.profiles p where p.id = me));
end;
$$;

revoke all on function public.sync(bigint) from public, anon;
grant execute on function public.sync(bigint) to authenticated;


-- ===========================================================================
-- 29. FOR YOU  -  recency first, like X
-- ===========================================================================
--
-- Owner: "make the For You page better, just make it new posts first and stuff
-- like X.com".
--
-- The old curve was Hacker-News shaped: (hours + 2) ^ 1.5. That is tuned for a
-- link aggregator where a good story should stay near the top for most of a
-- day. On a social feed it meant a brand-new post with no engagement ranked
-- FOURTH behind six-hour-old ones - so the page felt stale.
--
-- Modelled before changing it:
--
--   post                        OLD rank   NEW rank
--   brand new, 0 engagement            4          1
--   1h old, 2 likes                    1          2
--   6h old, 10 likes                   2          3
--   2 days old, 50 likes               3          4
--   6 days old, 200 likes              5          5
--
-- Two changes produce that:
--   * exponent 1.5 -> 2.2, so age bites far harder;
--   * the +2 hour offset -> +0.5, so a post minutes old is not pre-aged.
--
-- Engagement still matters - it decides order between posts of similar age -
-- but it can no longer keep yesterday's post above this minute's.
--
-- The window also drops from 7 days to 48 hours: a "For You" page showing
-- six-day-old posts is just an archive.
create or replace function public.get_for_you(limit_n integer default 30)
returns json language sql stable security definer set search_path = '' as $$
   select coalesce(json_agg(row_to_json(feed) order by (feed).sc desc), '[]'::json)
   from (
      select p.id as i, pr.username as u, p.body as b,
             extract(epoch from p.created_at)::bigint as t,
             pr.equipped_badge as bd, pr.name_color as c,
             public.is_plus(pr.id) as pl, pr.verified as v,
             pr.skin_name as sk,
             p.like_count as lk, p.reply_count as rc, p.repost_count as rp,
             exists (select 1 from public.post_likes l
                      where l.post_id = p.id and l.user_id = auth.uid()) as il,
             exists (select 1 from public.post_reposts r
                      where r.post_id = p.id and r.user_id = auth.uid()) as ir,
             null::text as rb,
             (
               (2 * p.like_count + 3 * p.repost_count + 2 * p.reply_count + 1)
               /
               power(
                  (extract(epoch from (now() - p.created_at)) / 3600.0) + 0.5,
                  2.2)
             )
             * case when p.author_id in (select followee_id from public.follows
                                          where follower_id = auth.uid())
                    then 1.5 else 1.0 end
             as sc
        from public.posts p
        join public.profiles pr on pr.id = p.author_id
       where p.parent_id is null
         and p.created_at > now() - interval '48 hours'
         and p.author_id <> auth.uid()
         and not public.blocked_me(p.author_id)
       order by sc desc
       limit least(coalesce(limit_n, 30), 50)
   ) feed;
$$;

revoke all on function public.get_for_you(integer) from public, anon;
grant execute on function public.get_for_you(integer) to authenticated;
