-- Local-only shim that imitates the parts of Supabase our schema relies on.
-- This is NOT shipped. It exists so we can run the real schema.sql against a
-- real Postgres and actually attack the RLS policies.

create schema if not exists auth;

-- Supabase's user table (only the columns we reference).
create table if not exists auth.users (
   id    uuid primary key,
   email text unique
);

-- Supabase exposes the current user id as auth.uid(). In real Supabase this
-- reads a JWT claim; here we read a session variable we set from the tests.
create or replace function auth.uid()
returns uuid
language sql
stable
as $$
   select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;

-- Supabase's two client roles.
do $$
begin
   if not exists (select 1 from pg_roles where rolname = 'anon') then
      create role anon nologin;
   end if;
   if not exists (select 1 from pg_roles where rolname = 'authenticated') then
      create role authenticated nologin;
   end if;
end
$$;

grant usage on schema public to anon, authenticated;
grant usage on schema auth   to anon, authenticated;

-- PostgREST grants table DML to these roles; RLS then filters it.
alter default privileges in schema public
   grant select, insert, update, delete on tables to authenticated;
