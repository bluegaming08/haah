-- ===========================================================================
--  ADVERSARIAL TESTS for schema_v2 (badges, DMs, groups, buddies, follows,
--  Minecraft linking, statuses, join-server, cosmetics).
--
--  Run AFTER 00_supabase_shim.sql + schema.sql + schema_v2.sql.
--  Every test acts as a HOSTILE client holding the publishable key.
-- ===========================================================================
\set ON_ERROR_STOP off
\pset pager off
set client_min_messages = notice;

create or replace function t_ok(name text, cond boolean) returns void
language plpgsql as $$
begin
   raise notice '%  %', case when cond then 'PASS' else '!!!! FAIL' end, name;
end; $$;

create or replace function t_blocked(uid uuid, sql text) returns boolean
language plpgsql as $$
declare n int;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   begin
      execute sql;
      get diagnostics n = row_count;
      execute 'set local role postgres';
      return n = 0;
   exception when others then
      execute 'set local role postgres';
      return true;
   end;
end; $$;

-- Runs a json-returning function AS a user (added in v21 for request_buddy).
create or replace function t_json(uid uuid, sql text) returns json
language plpgsql as $$
declare j json;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   execute sql into j;
   execute 'set local role postgres';
   return j;
exception when others then
   execute 'set local role postgres';
   return json_build_object('ok', false, 'm', 'EXCEPTION: ' || sqlerrm);
end; $$;

create or replace function t_count(uid uuid, sql text) returns int
language plpgsql as $$
declare n int;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   execute sql into n;
   execute 'set local role postgres';
   return coalesce(n, 0);
exception when others then
   execute 'set local role postgres';
   return -1;
end; $$;

-- ---- fixtures: alice & bob are friends; mallory is hostile; dave is alone --
do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   d uuid := '55555555-5555-5555-5555-555555555555';
begin
   delete from auth.users;
   insert into auth.users (id, email) values
      (a,'alice@blueclient.app'), (b,'bob@blueclient.app'),
      (m,'mallory@blueclient.app'), (d,'dave@blueclient.app');
   insert into public.profiles (id, username, username_low) values
      (a,'Alice','alice'), (b,'Bob','bob'), (m,'Mallory','mallory'), (d,'Dave','dave');
   insert into public.friendships (user_a,user_b) values (least(a,b), greatest(a,b));
   -- grant Alice a badge (as staff would)
   insert into public.user_badges (user_id, badge_id) values (a, 'founder');
end $$;

\echo ''
\echo '=============== MINECRAFT LINKING ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   m uuid := '44444444-4444-4444-4444-444444444444';
begin
   -- 1. offline_uuid matches Java's UUID.nameUUIDFromBytes exactly.
   perform t_ok('offline_uuid(Notch) matches Java',
      public.offline_uuid('Notch') = 'b50ad385-829d-3141-a216-7e7d7539ba7f'::uuid);
   perform t_ok('offline_uuid(jeb_) matches Java',
      public.offline_uuid('jeb_') = 'a762f560-4fce-3236-812a-b80efff0b62b'::uuid);
   perform t_ok('offline_uuid(xX_Steve_Xx) matches Java',
      public.offline_uuid('xX_Steve_Xx') = 'd740d592-3026-3ffd-886a-000a47ed303c'::uuid);

   -- 2. A player CANNOT call apply_minecraft_link (the Edge-Function-only RPC).
   --    If they could, they could claim to be any premium player.
   perform t_ok('player cannot call apply_minecraft_link',
      t_blocked(m, format('select public.apply_minecraft_link(%L,%L,%L,true)',
                          m, 'b50ad385-829d-3141-a216-7e7d7539ba7f', 'Notch')));

   -- 3. Cracked link works for a free name.
   perform set_config('request.jwt.claim.sub', m::text, true);
   set local role authenticated;
   perform public.link_cracked_minecraft('CrackedGuy', false);
   set local role postgres;
   perform t_ok('cracked link stores the correct offline uuid',
      (select mc_uuid from public.profiles where id=m) = public.offline_uuid('CrackedGuy')
      and (select mc_premium from public.profiles where id=m) = false
      and (select mc_verified from public.profiles where id=m) = false);

   -- 4. Claiming a name Mojang says is premium is refused.
   perform t_ok('cracked link refuses a premium-owned name',
      t_blocked(m, 'select public.link_cracked_minecraft(''Notch'', true)'));

   -- 5. Cannot take a name a VERIFIED premium player already holds.
   update public.profiles
      set mc_name='Herobrine', mc_uuid=gen_random_uuid(), mc_premium=true, mc_verified=true
    where id=a;
   perform t_ok('cannot claim a verified premium player''s name',
      t_blocked(m, 'select public.link_cracked_minecraft(''Herobrine'', false)'));

   -- 6. Invalid Minecraft names rejected.
   perform t_ok('invalid mc name rejected',
      t_blocked(m, 'select public.link_cracked_minecraft(''bad name!'', false)'));

   -- 7. One Minecraft account cannot be linked twice (unique index).
   perform t_ok('mc_uuid is unique across accounts',
      t_blocked(m, format('update public.profiles set mc_uuid=%L where id=%L',
                          (select mc_uuid from public.profiles where id=a), m)));
end $$;

\echo ''
\echo '=============== BADGES ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   m uuid := '44444444-4444-4444-4444-444444444444';
begin
   -- 8. A player cannot grant themselves a badge (no insert policy).
   perform t_ok('cannot grant yourself a badge',
      t_blocked(m, format('insert into public.user_badges (user_id,badge_id) values (%L,''founder'')', m)));

   -- 9. Cannot grant a badge to someone else either.
   perform t_ok('cannot grant a badge to another user',
      t_blocked(m, format('insert into public.user_badges (user_id,badge_id) values (%L,''helper'')', a)));

   -- 10. Cannot equip a badge you do not own (trigger).
   perform t_ok('cannot equip an unowned badge',
      t_blocked(m, format('update public.profiles set equipped_badge=''founder'' where id=%L', m)));

   -- 11. CAN equip a badge you do own.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   update public.profiles set equipped_badge='founder' where id=a;
   set local role postgres;
   perform t_ok('can equip an owned badge',
      (select equipped_badge from public.profiles where id=a) = 'founder');

   -- 12. badges_for_players returns the equipped badge by Minecraft name.
   perform t_ok('badges_for_players resolves by mc_name',
      t_count(m, 'select count(*) from public.badges_for_players(array[''Herobrine''])') = 1);

   -- 13. Hiding your badge removes it from the lookup.
   update public.settings set show_badge=false where id=a;
   perform t_ok('show_badge=false hides the badge from others',
      t_count(m, 'select count(*) from public.badges_for_players(array[''Herobrine''])') = 0);
   update public.settings set show_badge=true where id=a;

   -- 14. The lookup is capped at 100 names (anti-dump).
   perform t_ok('badges_for_players caps the name list',
      t_count(m, 'select count(*) from public.badges_for_players(
         (select array_agg(''name''||g) from generate_series(1,500) g))') <= 100);
end $$;

\echo ''
\echo '=============== DIRECT MESSAGES ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   conv uuid;
   n int;
begin
   -- 15. You can DM a friend.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   conv := public.open_dm(b);
   set local role postgres;
   perform t_ok('can open a DM with a friend', conv is not null);

   -- 16. open_dm is idempotent (no duplicate threads).
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform t_ok('open_dm returns the same conversation twice',
      public.open_dm(b) = conv);
   set local role postgres;

   -- 17. You CANNOT DM a non-friend.
   perform t_ok('cannot DM a stranger',
      t_blocked(m, format('select public.open_dm(%L)', a)));

   -- 18. A non-member cannot read the conversation's messages.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   insert into public.messages (conversation_id, sender_id, body)
   values (conv, a, 'hello bob');
   set local role postgres;

   perform t_ok('non-member cannot read messages',
      t_count(m, format('select count(*) from public.messages where conversation_id=%L', conv)) = 0);

   -- 19. A non-member cannot call get_messages either.
   perform t_ok('non-member cannot call get_messages',
      t_blocked(m, format('select public.get_messages(%L)', conv)));

   -- 20. A member CAN read them.
   perform t_ok('member can read messages',
      t_count(b, format('select count(*) from public.messages where conversation_id=%L', conv)) = 1);

   -- 21. Cannot inject a message into a conversation you are not in.
   perform t_ok('cannot post into someone else''s conversation',
      t_blocked(m, format('insert into public.messages (conversation_id,sender_id,body) values (%L,%L,''spam'')',
                          conv, m)));

   -- 22. Cannot forge a message FROM another user.
   perform t_ok('cannot send a message as another user',
      t_blocked(b, format('insert into public.messages (conversation_id,sender_id,body) values (%L,%L,''forged'')',
                          conv, a)));

   -- 23. Over-long messages rejected.
   perform t_ok('over-long message rejected',
      t_blocked(a, format('insert into public.messages (conversation_id,sender_id,body) values (%L,%L,%L)',
                          conv, a, repeat('the quick brown fox jumps over the lazy dog while nine clever badgers watch from a quiet hill nearby and hum softly ', 4))));

   -- 24. Empty message rejected.
   perform t_ok('empty message rejected',
      t_blocked(a, format('insert into public.messages (conversation_id,sender_id,body) values (%L,%L,'''')',
                          conv, a)));

   -- 25. Blocking prevents opening a DM.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform public.block_user(b);
   set local role postgres;
   perform t_ok('blocked user cannot open a DM',
      t_blocked(b, format('select public.open_dm(%L)', a)));
   delete from public.blocks where blocker_id=a;
   insert into public.friendships (user_a,user_b)
   values (least(a,b), greatest(a,b)) on conflict do nothing;
end $$;

\echo ''
\echo '=============== GROUPS ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   g uuid;
begin
   -- 26. Create a group with a friend.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   g := public.create_group('Test Group', array[b]);
   set local role postgres;
   perform t_ok('group created with owner + friend',
      (select count(*) from public.conversation_members where conversation_id=g) = 2);

   -- 27. Non-friends are silently skipped, not added.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   g := public.create_group('Second', array[b, m]);
   set local role postgres;
   perform t_ok('non-friends are not added to a group',
      not exists (select 1 from public.conversation_members
                  where conversation_id=g and user_id=m));

   -- 28. An outsider cannot read the group's messages.
   perform t_ok('outsider cannot read group messages',
      t_count(m, format('select count(*) from public.messages where conversation_id=%L', g)) = 0);

   -- 29. An outsider cannot add themselves to the group.
   perform t_ok('cannot add yourself to a group',
      t_blocked(m, format('insert into public.conversation_members (conversation_id,user_id) values (%L,%L)', g, m)));

   -- 30. An over-long group name is TRUNCATED to 24, not rejected.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   g := public.create_group(repeat('L', 60), array[b]);
   set local role postgres;
   perform t_ok('over-long group name truncated to 24',
      (select char_length(name) from public.conversations where id = g) = 24);

   -- 31. Leaving removes you.
   perform set_config('request.jwt.claim.sub', b::text, true);
   set local role authenticated;
   perform public.leave_conversation(g);
   set local role postgres;
   perform t_ok('leaving a group removes membership',
      not exists (select 1 from public.conversation_members
                  where conversation_id=g and user_id=b));
end $$;

\echo ''
\echo '=============== BUDDY SYSTEM (v21: mutual consent) ==============='

-- schema_v3 replaced the one-sided set_buddy() with request_buddy() /
-- clear_buddy(), which require BOTH players to agree and allow one buddy
-- each. These tests were rewritten to match; the deeper adversarial cases
-- live in attack_v3.sql.
do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   r json;
begin
   update public.profiles set buddy_id = null where id in (a,b,m);
   delete from public.buddy_requests;

   -- 32. Cannot buddy yourself.
   r := t_json(a, format('select public.request_buddy(%L)', a));
   perform t_ok('cannot buddy yourself', not (r->>'ok')::boolean);

   -- 33. Cannot buddy a non-friend.
   r := t_json(m, format('select public.request_buddy(%L)', a));
   perform t_ok('cannot buddy a non-friend', not (r->>'ok')::boolean);

   -- 34. One-sided request does NOT make them buddies.
   perform t_json(a, format('select public.request_buddy(%L)', b));
   perform t_ok('one-sided buddy is not mutual', public.are_buddies(a,b) = false);

   -- 35. Once the other side agrees, it is mutual.
   perform t_json(b, format('select public.request_buddy(%L)', a));
   perform t_ok('mutual buddy recognised', public.are_buddies(a,b) = true);

   -- 36. One buddy each: a paired player cannot take another.
   insert into public.friendships (user_a,user_b)
   values (least(a,m), greatest(a,m)) on conflict do nothing;
   r := t_json(a, format('select public.request_buddy(%L)', m));
   perform t_ok('cannot take a second buddy while paired',
      not (r->>'ok')::boolean and public.are_buddies(a,b) = true);

   -- 37. A player cannot force someone ELSE to be their buddy.
   perform t_ok('cannot set another user''s buddy',
      t_blocked(m, format('update public.profiles set buddy_id=%L where id=%L', m, a)));
end $$;

\echo ''
\echo '=============== BUDDY (server plugin view) ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   ua uuid := gen_random_uuid();
   ub uuid := gen_random_uuid();
begin
   update public.profiles set mc_uuid=ua, mc_name='AlicePremium',
      mc_premium=true, mc_verified=true, buddy_id=b where id=a;
   update public.profiles set mc_uuid=ub, mc_name='BobPremium',
      mc_premium=true, mc_verified=true, buddy_id=a where id=b;

   -- 38. Mutual + both verified -> 3x qualifies.
   perform t_ok('are_buddies_mc true for mutual verified pair',
      public.are_buddies_mc(ua, ub));

   -- 39. Unverified accounts do NOT qualify (stops cracked impersonation
   --     of a premium player to farm shards).
   update public.profiles set mc_verified=false where id=b;
   perform t_ok('are_buddies_mc false when one side is unverified',
      public.are_buddies_mc(ua, ub) = false);
   update public.profiles set mc_verified=true where id=b;

   -- 40. One-sided does not qualify.
   update public.profiles set buddy_id=null where id=b;
   perform t_ok('are_buddies_mc false when one-sided',
      public.are_buddies_mc(ua, ub) = false);
end $$;

\echo ''
\echo '=============== FOLLOWERS ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   m uuid := '44444444-4444-4444-4444-444444444444';
begin
   -- 41. Following needs no approval.
   perform set_config('request.jwt.claim.sub', m::text, true);
   set local role authenticated;
   perform public.follow_user(a);
   set local role postgres;
   perform t_ok('can follow without approval',
      exists (select 1 from public.follows where follower_id=m and followee_id=a));

   -- 42. Cannot follow yourself.
   perform t_ok('cannot follow yourself',
      t_blocked(m, format('select public.follow_user(%L)', m)));

   -- 43. Cannot forge a follow from someone else.
   perform t_ok('cannot forge a follow as another user',
      t_blocked(m, format('insert into public.follows (follower_id,followee_id) values (%L,%L)', a, m)));

   -- 44. Cannot remove someone else's follow.
   perform t_ok('cannot delete another user''s follow',
      t_blocked(a, format('delete from public.follows where follower_id=%L', m)));

   -- 45. Duplicate follow is harmless (idempotent).
   perform set_config('request.jwt.claim.sub', m::text, true);
   set local role authenticated;
   perform public.follow_user(a);
   set local role postgres;
   perform t_ok('duplicate follow does not error or duplicate',
      (select count(*) from public.follows where follower_id=m and followee_id=a) = 1);

   -- 46. Blocked users cannot follow.
   insert into public.blocks (blocker_id, blocked_id) values (a, m);
   perform t_ok('blocked user cannot follow',
      t_blocked(m, format('select public.follow_user(%L)', a)));
   delete from public.blocks where blocker_id=a;
end $$;

\echo ''
\echo '=============== ABOUT / STATUS ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   m uuid := '44444444-4444-4444-4444-444444444444';
begin
   -- 47. About is capped at 50 characters, not rejected.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform public.set_about(repeat('the quick brown fox jumps over the lazy dog while nine clever badgers watch from a quiet hill nearby and hum softly ', 3));
   set local role postgres;
   perform t_ok('about is truncated to 50 chars',
      char_length((select about from public.profiles where id=a)) = 50);

   -- 48. A direct over-long write is rejected by the constraint.
   --     schema_v3 widened this to 100 (the Blue+ cap) and moved the per-tier
   --     limit into set_about(), so test beyond ANY tier's allowance.
   perform t_ok('over-long about rejected at the table',
      t_blocked(a, format('update public.profiles set about=%L where id=%L', repeat('the quick brown fox jumps over the lazy dog while nine clever badgers watch from a quiet hill nearby and hum softly ', 2), a)));

   -- 49. Cannot set someone else's about.
   perform t_ok('cannot set another user''s about',
      t_blocked(m, format('update public.profiles set about=''hacked'' where id=%L', a)));
end $$;

\echo ''
\echo '=============== JOIN A FRIEND''S SERVER ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   d uuid := '55555555-5555-5555-5555-555555555555';
   r json;
begin
   update public.profiles set is_online=true, server_name='play.bluenetwork.net' where id=a;
   update public.settings set show_current_server='friends' where id=a;
   insert into public.friendships (user_a,user_b)
   values (least(a,b), greatest(a,b)) on conflict do nothing;

   -- v21 NOTE: get_join_address() used to return a bare text address and to
   -- signal refusal by raising. It now returns json {ok, a|m} so the client
   -- can show WHY a join failed (offline, not sharing, not a server). These
   -- three tests were updated with it - a refusal is now ok=false, not a throw.

   -- 50. A friend can get the address.
   r := t_json(b, format('select public.get_join_address(%L)', a));
   perform t_ok('friend can fetch the join address',
      (r->>'ok')::boolean and r->>'a' = 'play.bluenetwork.net');

   -- 51. A stranger cannot. NOTE: use Dave - Mallory was made a friend of
   -- Alice in test 36, so she is not a stranger by this point.
   r := t_json(d, format('select public.get_join_address(%L)', a));
   perform t_ok('stranger cannot fetch the join address',
      not (r->>'ok')::boolean and r->>'a' is null);

   -- 52. Hiding your server also blocks joining.
   update public.settings set show_current_server='nobody' where id=a;
   r := t_json(b, format('select public.get_join_address(%L)', a));
   perform t_ok('hiding your server prevents joining',
      not (r->>'ok')::boolean and r->>'a' is null);
end $$;

\echo ''
\echo '=============== COSMETICS (future use) ==============='

do $$
declare m uuid := '44444444-4444-4444-4444-444444444444';
begin
   insert into public.cosmetics (id,kind,name) values ('cape_test','cape','Test Cape')
   on conflict do nothing;

   -- 53. Players cannot grant themselves cosmetics.
   perform t_ok('cannot grant yourself a cosmetic',
      t_blocked(m, format('insert into public.user_cosmetics (user_id,cosmetic_id) values (%L,''cape_test'')', m)));

   -- 54. Players cannot invent catalogue entries.
   perform t_ok('cannot insert into the cosmetics catalogue',
      t_blocked(m, 'insert into public.cosmetics (id,kind,name) values (''hax'',''cape'',''Hax'')'));

   -- 55. Invalid cosmetic kind rejected.
   perform t_ok('invalid cosmetic kind rejected',
      t_blocked('11111111-1111-1111-1111-111111111111',
                'insert into public.cosmetics (id,kind,name) values (''x'',''nonsense'',''X'')'));
end $$;

\echo ''
\echo '=============== ANONYMOUS ACCESS ==============='

do $$
begin
   -- 56. anon cannot call the new RPCs.
   set local role anon;
   begin
      perform public.get_conversations();
      set local role postgres;
      perform t_ok('anon cannot call get_conversations', false);
   exception when insufficient_privilege then
      set local role postgres;
      perform t_ok('anon cannot call get_conversations', true);
   end;

   set local role anon;
   begin
      perform public.badges_for_players(array['Notch']);
      set local role postgres;
      perform t_ok('anon cannot call badges_for_players', false);
   exception when insufficient_privilege then
      set local role postgres;
      perform t_ok('anon cannot call badges_for_players', true);
   end;
end $$;

\echo ''
