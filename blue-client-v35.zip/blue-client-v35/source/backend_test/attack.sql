-- ===========================================================================
--  ADVERSARIAL TEST SUITE for the Blue Client friends schema.
--  Every test acts as a HOSTILE client holding the publishable key, doing
--  exactly what the Minecraft client could be modified to do.
--
--  Each test prints PASS or FAIL. Any FAIL is a real security hole.
-- ===========================================================================
\set ON_ERROR_STOP off
\pset pager off
\set QUIET off
set client_min_messages = notice;

-- ---- test harness ---------------------------------------------------------
create or replace function t_ok(name text, cond boolean) returns void
language plpgsql as $$
begin
   raise notice '%  %', case when cond then 'PASS' else '!!!! FAIL' end, name;
end; $$;

-- Runs SQL as a given user; returns true if it was BLOCKED (error or 0 rows).
create or replace function t_blocked(uid uuid, sql text) returns boolean
language plpgsql as $$
declare n int;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   begin
      execute sql;
      get diagnostics n = row_count;
      execute 'set local role postgres';
      return n = 0;          -- silently filtered by RLS counts as blocked
   exception when others then
      execute 'set local role postgres';
      return true;           -- raised an error = blocked
   end;
end; $$;

-- Runs SQL as a user and returns the single integer it selects.
create or replace function t_count(uid uuid, sql text) returns int
language plpgsql as $$
declare n int;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   execute sql into n;
   execute 'set local role postgres';
   return coalesce(n, 0);
exception when others then
   execute 'set local role postgres';
   return -1;                -- -1 means "error"
end; $$;


-- ---- fixtures -------------------------------------------------------------
-- alice, bob, carol, mallory (the attacker), dave
do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   c uuid := '33333333-3333-3333-3333-333333333333';
   m uuid := '44444444-4444-4444-4444-444444444444';
   d uuid := '55555555-5555-5555-5555-555555555555';
begin
   delete from auth.users;
   insert into auth.users (id, email) values
      (a,'alice@blueclient.app'), (b,'bob@blueclient.app'),
      (c,'carol@blueclient.app'), (m,'mallory@blueclient.app'),
      (d,'dave@blueclient.app');
   insert into public.profiles (id, username, username_low) values
      (a,'Alice','alice'), (b,'Bob','bob'), (c,'Carol','carol'),
      (m,'Mallory','mallory'), (d,'Dave','dave');
end $$;

\echo ''
\echo '=============== CONSTRAINT TESTS (data integrity) ==============='

-- 1. Duplicate username differing only in case must be rejected.
do $$ begin
   begin
      insert into public.profiles (id, username, username_low)
      values (gen_random_uuid(), 'ALICE', 'alice');
      perform t_ok('case-insensitive duplicate username rejected', false);
   exception when unique_violation then
      perform t_ok('case-insensitive duplicate username rejected', true);
   end;
end $$;

-- 2. username_low must match lower(username).
do $$ begin
   begin
      insert into public.profiles (id, username, username_low)
      values (gen_random_uuid(), 'Eve', 'notEve');
      perform t_ok('mismatched username_low rejected', false);
   exception when check_violation then
      perform t_ok('mismatched username_low rejected', true);
   end;
end $$;

-- 3. Invalid username characters rejected.
do $$ begin
   begin
      insert into public.profiles (id, username, username_low)
      values (gen_random_uuid(), 'bad name!', 'bad name!');
      perform t_ok('invalid username characters rejected', false);
   exception when check_violation then
      perform t_ok('invalid username characters rejected', true);
   end;
end $$;

-- 4. Self-friendship impossible.
do $$
declare a uuid := '11111111-1111-1111-1111-111111111111';
begin
   begin
      insert into public.friendships (user_a, user_b) values (a, a);
      perform t_ok('self-friendship rejected', false);
   exception when check_violation then
      perform t_ok('self-friendship rejected', true);
   end;
end $$;

-- 5. Unordered friendship (B,A) rejected -> no duplicate-pair bug possible.
do $$
declare a uuid := '11111111-1111-1111-1111-111111111111';
        b uuid := '22222222-2222-2222-2222-222222222222';
begin
   begin
      insert into public.friendships (user_a, user_b) values (greatest(a,b), least(a,b));
      perform t_ok('reversed-order friendship rejected', false);
   exception when check_violation then
      perform t_ok('reversed-order friendship rejected', true);
   end;
end $$;

-- 6. Self friend-request rejected.
do $$
declare a uuid := '11111111-1111-1111-1111-111111111111';
begin
   begin
      insert into public.friend_requests (sender_id, receiver_id) values (a, a);
      perform t_ok('self friend-request rejected', false);
   exception when check_violation then
      perform t_ok('self friend-request rejected', true);
   end;
end $$;

-- 7. Foreign key: request to a nonexistent user rejected.
do $$
declare a uuid := '11111111-1111-1111-1111-111111111111';
begin
   begin
      insert into public.friend_requests (sender_id, receiver_id)
      values (a, '99999999-9999-9999-9999-999999999999');
      perform t_ok('request to nonexistent user rejected', false);
   exception when foreign_key_violation then
      perform t_ok('request to nonexistent user rejected', true);
   end;
end $$;

-- 8. Settings row auto-created by trigger.
do $$ begin
   perform t_ok('settings auto-created for every profile',
      (select count(*) from public.settings) = (select count(*) from public.profiles));
end $$;

-- 9. Self-block rejected.
do $$
declare a uuid := '11111111-1111-1111-1111-111111111111';
begin
   begin
      insert into public.blocks (blocker_id, blocked_id) values (a, a);
      perform t_ok('self-block rejected', false);
   exception when check_violation then
      perform t_ok('self-block rejected', true);
   end;
end $$;


\echo ''
\echo '=============== RLS TESTS (hostile client) ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   c uuid := '33333333-3333-3333-3333-333333333333';
   m uuid := '44444444-4444-4444-4444-444444444444';
   d uuid := '55555555-5555-5555-5555-555555555555';
   rid uuid;
begin
   -- 10. Mallory cannot forge a request that claims to be from Alice.
   perform t_ok('cannot forge a request from another user',
      t_blocked(m, format('insert into public.friend_requests (sender_id, receiver_id) values (%L,%L)', a, b)));

   -- 11. Mallory cannot insert a friendship directly (no insert policy).
   perform t_ok('cannot self-insert a friendship (no accept needed)',
      t_blocked(m, format('insert into public.friendships (user_a,user_b) values (%L,%L)',
                          least(m,a), greatest(m,a))));

   -- 12. Mallory cannot create a profile row owned by someone else.
   perform t_ok('cannot create a profile for another uuid',
      t_blocked(m, format('insert into public.profiles (id,username,username_low) values (%L,%L,%L)',
                          gen_random_uuid(), 'Fake', 'fake')));

   -- 13. Mallory cannot rename Alice.
   perform t_ok('cannot update another user''s profile',
      t_blocked(m, format('update public.profiles set username=%L, username_low=%L where id=%L',
                          'Owned','owned', a)));

   -- 14. Mallory cannot read Alice's privacy settings.
   perform t_ok('cannot read another user''s settings',
      t_count(m, format('select count(*) from public.settings where id=%L', a)) = 0);

   -- 15. Mallory cannot change Alice's privacy settings.
   perform t_ok('cannot update another user''s settings',
      t_blocked(m, format('update public.settings set allow_requests_from=%L where id=%L','everyone',a)));
end $$;


\echo ''
\echo '=============== FRIEND REQUEST FLOW ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   rid uuid;
begin
   -- 16. Alice -> Bob request succeeds (default: everyone).
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   insert into public.friend_requests (sender_id, receiver_id) values (a, b);
   set local role postgres;
   perform t_ok('normal friend request succeeds',
      (select count(*) from public.friend_requests where sender_id=a and receiver_id=b) = 1);

   -- 17. Duplicate pending request rejected.
   perform t_ok('duplicate pending request rejected',
      t_blocked(a, format('insert into public.friend_requests (sender_id,receiver_id) values (%L,%L)', a, b)));

   -- 18. The SENDER cannot accept their own request.
   select id into rid from public.friend_requests where sender_id=a and receiver_id=b;
   perform t_ok('sender cannot accept their own request',
      t_blocked(a, format('select public.accept_friend_request(%L)', rid)));

   -- 19. An unrelated user cannot accept it either.
   perform t_ok('third party cannot accept someone else''s request',
      t_blocked('44444444-4444-4444-4444-444444444444', format('select public.accept_friend_request(%L)', rid)));

   -- 20. Bob accepts -> friendship created, request gone.
   perform set_config('request.jwt.claim.sub', b::text, true);
   set local role authenticated;
   perform public.accept_friend_request(rid);
   set local role postgres;
   perform t_ok('receiver can accept; friendship created',
      public.are_friends(a,b) and
      (select count(*) from public.friend_requests where sender_id=a and receiver_id=b) = 0);

   -- 21. Exactly ONE friendship row (no duplicate mirror).
   perform t_ok('exactly one friendship row exists',
      (select count(*) from public.friendships
        where (user_a=a and user_b=b) or (user_a=b and user_b=a)) = 1);

   -- 22. Cannot request someone you are already friends with.
   perform t_ok('cannot request an existing friend',
      t_blocked(a, format('insert into public.friend_requests (sender_id,receiver_id) values (%L,%L)', a, b)));
end $$;


\echo ''
\echo '=============== BLOCKING ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
begin
   -- Alice blocks Mallory.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform public.block_user(m);
   set local role postgres;

   -- 23. Blocked user cannot send a request.
   perform t_ok('blocked user cannot send a friend request',
      t_blocked(m, format('insert into public.friend_requests (sender_id,receiver_id) values (%L,%L)', m, a)));

   -- 24. Blocking is mutual in effect: blocker cannot request the blocked either.
   perform t_ok('block also stops the blocker from requesting',
      t_blocked(a, format('insert into public.friend_requests (sender_id,receiver_id) values (%L,%L)', a, m)));

   -- 25. The blocked user cannot SEE that they were blocked.
   perform t_ok('blocked user cannot see the block row',
      t_count(m, format('select count(*) from public.blocks where blocked_id=%L', m)) = 0);

   -- 26. The blocked user cannot even see the blocker's profile.
   perform t_ok('blocked user cannot read blocker profile',
      t_count(m, format('select count(*) from public.profiles where id=%L', a)) = 0);

   -- 27. Blocking an existing friend DESTROYS the friendship.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform public.block_user(b);
   set local role postgres;
   perform t_ok('blocking an existing friend ends the friendship',
      not public.are_friends(a,b));

   -- 28. Mallory cannot forge a block row on Alice's behalf.
   perform t_ok('cannot create a block as another user',
      t_blocked(m, format('insert into public.blocks (blocker_id,blocked_id) values (%L,%L)', a, m)));

   -- 29. Mallory cannot delete Alice's block on her (unblock themselves).
   perform t_ok('blocked user cannot unblock themselves',
      t_blocked(m, format('delete from public.blocks where blocker_id=%L and blocked_id=%L', a, m)));

   -- cleanup for later tests
   delete from public.blocks where blocker_id = a;
end $$;


\echo ''
\echo '=============== PRIVACY: allow_requests_from ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   c uuid := '33333333-3333-3333-3333-333333333333';
   m uuid := '44444444-4444-4444-4444-444444444444';
   d uuid := '55555555-5555-5555-5555-555555555555';
   rid uuid;
begin
   -- Carol: nobody may send her requests.
   update public.settings set allow_requests_from='nobody' where id=c;
   -- 30
   perform t_ok('allow_requests_from=nobody blocks all requests',
      t_blocked(m, format('insert into public.friend_requests (sender_id,receiver_id) values (%L,%L)', m, c)));

   -- Carol: friends-of-friends only.
   update public.settings set allow_requests_from='friends_of_friends' where id=c;
   -- 31. Mallory shares no friend with Carol -> blocked.
   perform t_ok('friends_of_friends blocks a stranger',
      t_blocked(m, format('insert into public.friend_requests (sender_id,receiver_id) values (%L,%L)', m, c)));

   -- Make Dave a mutual friend of both Carol and Mallory.
   insert into public.friendships (user_a,user_b) values (least(c,d), greatest(c,d));
   insert into public.friendships (user_a,user_b) values (least(m,d), greatest(m,d));

   -- 32. Now Mallory shares Dave with Carol -> allowed.
   perform t_ok('friends_of_friends allows a mutual-friend request',
      not t_blocked(m, format('insert into public.friend_requests (sender_id,receiver_id) values (%L,%L)', m, c)));

   delete from public.friend_requests;
   update public.settings set allow_requests_from='everyone' where id=c;
end $$;


\echo ''
\echo '=============== PRIVACY: presence visibility ==============='

do $$
declare
   c uuid := '33333333-3333-3333-3333-333333333333';
   d uuid := '55555555-5555-5555-5555-555555555555';
   m uuid := '44444444-4444-4444-4444-444444444444';
   srv text;
   v2 boolean;
begin
   update public.profiles set is_online=true, server_name='donutsmp.net', last_seen=now() where id=c;

   -- Carol hides her server from everyone.
   update public.settings set show_current_server='nobody' where id=c;
   perform set_config('request.jwt.claim.sub', d::text, true);
   set local role authenticated;
   select server_name into srv from public.get_friends() where id=c;
   set local role postgres;
   -- 33
   perform t_ok('show_current_server=nobody hides server from a friend', srv is null);

   -- Carol shares her server with friends.
   update public.settings set show_current_server='friends' where id=c;
   perform set_config('request.jwt.claim.sub', d::text, true);
   set local role authenticated;
   select server_name into srv from public.get_friends() where id=c;
   set local role postgres;
   -- 34
   perform t_ok('show_current_server=friends reveals server to a friend', srv = 'donutsmp.net');

   -- 35. can_view respects a block even when the setting says everyone.
   -- NOTE: this must be evaluated AS MALLORY. The relationship helpers carry
   -- an anti-probing guard that makes them return false when the caller is
   -- neither party, so asking "can m see c?" while authenticated as someone
   -- else is meaningless by design.
   update public.settings set show_online_status='everyone' where id=c;
   insert into public.blocks (blocker_id, blocked_id) values (c, m);
   perform set_config('request.jwt.claim.sub', m::text, true);
   set local role authenticated;
   select public.can_view(m, c, 'online') into v2;
   set local role postgres;
   perform t_ok('a block overrides show_online_status=everyone', v2 = false);
   delete from public.blocks where blocker_id=c;
end $$;


\echo ''
\echo '=============== SEARCH ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   m uuid := '44444444-4444-4444-4444-444444444444';
   n int;
begin
   -- 36. Search is case-insensitive but returns the display case.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   select count(*) into n from public.search_users('ALI') where username='Alice';
   set local role postgres;
   perform t_ok('own name excluded from own search results', n = 0);

   perform set_config('request.jwt.claim.sub', m::text, true);
   set local role authenticated;
   select count(*) into n from public.search_users('ALI') where username='Alice';
   set local role postgres;
   -- 37
   perform t_ok('search finds "Alice" from query "ALI"', n = 1);

   -- 38. Search never returns yourself.
   perform t_ok('search excludes yourself',
      t_count(m, 'select count(*) from public.search_users(''mall'')') = 0);

   -- 39. One-character queries return nothing (anti-enumeration).
   perform t_ok('1-char query returns nothing',
      t_count(m, 'select count(*) from public.search_users(''a'')') = 0);

   -- 40. Wildcards are escaped - '%' must not match everyone.
   perform t_ok('LIKE wildcards are escaped',
      t_count(m, 'select count(*) from public.search_users(''%%'')') = 0);

   -- 41. Blocked users are hidden from search.
   insert into public.blocks (blocker_id, blocked_id) values (a, m);
   perform t_ok('search hides users who blocked you',
      t_count(m, 'select count(*) from public.search_users(''alic'')') = 0);
   delete from public.blocks where blocker_id=a;

   -- 42. Search cannot be used to dump the table.
   perform t_ok('search result count is capped at 20',
      t_count(m, 'select count(*) from public.search_users(''a'')') <= 20);
end $$;


\echo ''
\echo '=============== ANONYMOUS (logged-out) ACCESS ==============='

do $$
begin
   -- 43. Not logged in => cannot read profiles at all.
   perform set_config('request.jwt.claim.sub', '', true);
   set local role anon;
   begin
      perform count(*) from public.profiles;
      set local role postgres;
      perform t_ok('anonymous cannot read profiles',
         (select count(*) from public.profiles) >= 0 and false);
   exception when insufficient_privilege then
      set local role postgres;
      perform t_ok('anonymous cannot read profiles', true);
   end;
end $$;

do $$
declare n int;
begin
   -- 44. anon role cannot call the RPCs.
   set local role anon;
   begin
      perform public.search_users('ali');
      set local role postgres;
      perform t_ok('anonymous cannot call search_users', false);
   exception when insufficient_privilege then
      set local role postgres;
      perform t_ok('anonymous cannot call search_users', true);
   end;
end $$;


\echo ''
\echo '=============== HEARTBEAT ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   v boolean;
begin
   -- 45. heartbeat only ever touches your OWN row.
   update public.profiles set is_online=false where id=b;
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform public.heartbeat(true, 'hypixel.net');
   set local role postgres;
   select is_online into v from public.profiles where id=b;
   perform t_ok('heartbeat cannot affect another user', v = false);

   -- 46. going offline clears the server name
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform public.heartbeat(false, 'hypixel.net');
   set local role postgres;
   perform t_ok('going offline clears server_name',
      (select server_name from public.profiles where id=a) is null);

   -- 47. over-long server names are truncated, not rejected
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   perform public.heartbeat(true, repeat('x', 500));
   set local role postgres;
   perform t_ok('over-long server name truncated to 64',
      char_length((select server_name from public.profiles where id=a)) = 64);
end $$;


\echo ''
\echo '=============== CASCADES ==============='

do $$
declare
   d uuid := '55555555-5555-5555-5555-555555555555';
   before_n int; after_n int;
begin
   select count(*) into before_n from public.friendships where user_a=d or user_b=d;
   delete from auth.users where id=d;
   select count(*) into after_n from public.friendships where user_a=d or user_b=d;
   -- 48
   perform t_ok('deleting the auth user cascades away their friendships',
      before_n > 0 and after_n = 0);
   -- 49
   perform t_ok('deleting the auth user cascades away their profile',
      (select count(*) from public.profiles where id=d) = 0);
   -- 50
   perform t_ok('deleting the auth user cascades away their settings',
      (select count(*) from public.settings where id=d) = 0);
end $$;

\echo ''

\echo '=============== ANTI-PROBING GUARD ==============='
do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   v boolean;
begin
   -- Make a and b friends again for this check.
   insert into public.friendships (user_a,user_b)
   values (least(a,b), greatest(a,b)) on conflict do nothing;

   -- 51. Mallory must NOT be able to probe whether two OTHER users are friends.
   perform set_config('request.jwt.claim.sub', m::text, true);
   set local role authenticated;
   select public.are_friends(a, b) into v;
   set local role postgres;
   perform t_ok('cannot probe the friendship of two other users', v = false);

   -- 52. ...but a participant still gets the true answer.
   perform set_config('request.jwt.claim.sub', a::text, true);
   set local role authenticated;
   select public.are_friends(a, b) into v;
   set local role postgres;
   perform t_ok('a participant still sees their own friendship', v = true);

   -- 53. Mallory cannot probe who blocked whom.
   insert into public.blocks (blocker_id, blocked_id) values (a, b) on conflict do nothing;
   perform set_config('request.jwt.claim.sub', m::text, true);
   set local role authenticated;
   select public.block_exists(a, b) into v;
   set local role postgres;
   perform t_ok('cannot probe blocks between two other users', v = false);
   delete from public.blocks where blocker_id=a and blocked_id=b;
end $$;
\echo ''
