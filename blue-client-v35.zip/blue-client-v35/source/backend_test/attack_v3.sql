-- ===========================================================================
--  ADVERSARIAL TESTS for schema_v3 (Blue+, redeem codes, posts, tier limits,
--  coloured names, presence, invites, leaderboard, IP cap, auto-follow, sync).
--
--  Run AFTER 00_supabase_shim.sql + schema.sql + schema_v2.sql + schema_v3.sql.
--  Every test acts as a HOSTILE client holding only the publishable key.
-- ===========================================================================
\set ON_ERROR_STOP off
\pset pager off
set client_min_messages = notice;

create or replace function t_ok(name text, cond boolean) returns void
language plpgsql as $$
begin
   raise notice '%  %', case when cond then 'PASS' else '!!!! FAIL' end, name;
end; $$;

create or replace function t_blocked(uid uuid, sql text) returns boolean
language plpgsql as $$
declare n int;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   begin
      execute sql;
      get diagnostics n = row_count;
      execute 'set local role postgres';
      return n = 0;
   exception when others then
      execute 'set local role postgres';
      return true;
   end;
end; $$;

-- run a function AS a user and return its json result
create or replace function t_json(uid uuid, sql text) returns json
language plpgsql as $$
declare j json;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   execute sql into j;
   execute 'set local role postgres';
   return j;
exception when others then
   execute 'set local role postgres';
   return json_build_object('ok', false, 'm', 'EXCEPTION: ' || sqlerrm);
end; $$;

-- run a boolean-returning function AS a user
create or replace function t_bool(uid uuid, sql text) returns boolean
language plpgsql as $$
declare b boolean;
begin
   perform set_config('request.jwt.claim.sub', uid::text, true);
   execute 'set local role authenticated';
   execute sql into b;
   execute 'set local role postgres';
   return coalesce(b, false);
exception when others then
   execute 'set local role postgres';
   return false;
end; $$;

-- did an action raise? (used for cap triggers)
create or replace function t_raises(sql text) returns boolean
language plpgsql as $$
begin
   execute sql;
   return false;
exception when others then
   return true;
end; $$;


-- ---- fixtures ------------------------------------------------------------
--  blue + cyan  = staff
--  alice, bob   = friends
--  mallory      = hostile
--  plusguy      = will redeem Blue+
do $$
declare
   bl uuid := '0a000000-0000-0000-0000-0000000000b1';
   cy uuid := '0c000000-0000-0000-0000-0000000000c1';
   a  uuid := '11111111-1111-1111-1111-111111111111';
   b  uuid := '22222222-2222-2222-2222-222222222222';
   m  uuid := '44444444-4444-4444-4444-444444444444';
   pg uuid := '66666666-6666-6666-6666-666666666666';
begin
   delete from auth.users;
   insert into auth.users (id, email) values
      (bl,'blue@blueclient.app'), (cy,'cyan@blueclient.app'),
      (a,'alice@blueclient.app'), (b,'bob@blueclient.app'),
      (m,'mallory@blueclient.app'), (pg,'plusguy@blueclient.app');
   -- Cyan first, Blue later: mirrors reality (Cyan exists, Blue does not yet).
   insert into public.profiles (id, username, username_low) values (cy,'Cyan','cyan');
   insert into public.profiles (id, username, username_low) values
      (a,'Alice','alice'), (b,'Bob','bob'), (m,'Mallory','mallory'),
      (pg,'PlusGuy','plusguy');
   -- Blue registers late (tested below), so it is NOT inserted here.
   insert into public.friendships (user_a,user_b) values (least(a,b), greatest(a,b));
end $$;


\echo ''
\echo '=============== AUTO-FOLLOW BLUE AND CYAN ==============='

do $$
declare
   cy uuid := '0c000000-0000-0000-0000-0000000000c1';
   bl uuid := '0a000000-0000-0000-0000-0000000000b1';
   a  uuid := '11111111-1111-1111-1111-111111111111';
   nu uuid := '77777777-7777-7777-7777-777777777777';
begin
   -- 1. Signing up while only Cyan exists auto-follows Cyan.
   perform t_ok('new account auto-follows Cyan',
      exists (select 1 from public.follows where follower_id=a and followee_id=cy));

   -- 2. The OWNER registers LATER. Everyone existing should be backfilled.
   -- Ownership moved from 'blue' to 'bluewuztaken', so the fixture registers
   -- the account that staff_accounts actually names.
   insert into auth.users (id,email) values (bl,'bluewuztaken@blueclient.app')
   on conflict do nothing;
   insert into public.profiles (id,username,username_low)
   values (bl,'bluewuztaken','bluewuztaken')
   on conflict do nothing;

   perform t_ok('existing accounts backfilled to follow the owner on registration',
      exists (select 1 from public.follows where follower_id=a and followee_id=bl));

   -- 3. Someone who signs up after BOTH exist follows both.
   insert into auth.users (id,email) values (nu,'newbie@blueclient.app');
   insert into public.profiles (id,username,username_low) values (nu,'Newbie','newbie');
   perform t_ok('later signup auto-follows both owner and Cyan',
      (select count(*) from public.follows
        where follower_id=nu and followee_id in (bl,cy)) = 2);

   -- 4. Staff do not follow themselves.
   perform t_ok('staff do not follow themselves',
      not exists (select 1 from public.follows where follower_id=bl and followee_id=bl));
end $$;


\echo ''
\echo '=============== STAFF BADGES AND VERIFICATION ==============='

do $$
declare
   bl uuid := '0a000000-0000-0000-0000-0000000000b1';
   cy uuid := '0c000000-0000-0000-0000-0000000000c1';
   a  uuid := '11111111-1111-1111-1111-111111111111';
begin
   perform t_ok('owner has every badge',
      (select count(*) from public.user_badges where user_id=bl)
      = (select count(*) from public.badges));
   perform t_ok('Cyan has every badge',
      (select count(*) from public.user_badges where user_id=cy)
      = (select count(*) from public.badges));
   perform t_ok('owner equips Founder',
      (select equipped_badge from public.profiles where id=bl) = 'founder');
   perform t_ok('Cyan equips Co-Founder',
      (select equipped_badge from public.profiles where id=cy) = 'co_founder');
   perform t_ok('staff are verified without 100 followers',
      (select verified and verified_forced from public.profiles where id=bl));
   perform t_ok('staff have permanent Blue+',
      public.is_plus(bl) and public.is_plus(cy));
   perform t_ok('a normal account is NOT verified',
      not (select verified from public.profiles where id=a));
   perform t_ok('a normal account does NOT have Blue+', not public.is_plus(a));
end $$;


\echo ''
\echo '=============== REDEEM CODES ==============='

do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   m  uuid := '44444444-4444-4444-4444-444444444444';
   pg uuid := '66666666-6666-6666-6666-666666666666';
   r  json;
begin
   -- 1. Codes are completely unreadable, even though they are in `public`.
   perform t_ok('player cannot SELECT redeem codes',
      t_blocked(m, 'select * from public.redeem_codes'));

   -- 2. Player cannot insert their own code.
   perform t_ok('player cannot INSERT a redeem code',
      t_blocked(m, 'insert into public.redeem_codes (code,kind,plus_days)
                    values (''FREEPLUS'',''plus'',0)'));

   -- 3. Player cannot un-redeem a used code.
   perform t_ok('player cannot UPDATE redeem codes',
      t_blocked(m, 'update public.redeem_codes set redeemed_by=null'));

   -- 4. A real code works once.
   r := t_json(pg, 'select public.redeem(''BLUEPLUS'')');
   perform t_ok('BLUEPLUS grants Blue+', (r->>'ok')::boolean and public.is_plus(pg));

   -- 5. The SAME code cannot be used by anyone else. This is the core rule.
   r := t_json(a, 'select public.redeem(''BLUEPLUS'')');
   perform t_ok('a used code cannot be redeemed again',
      not (r->>'ok')::boolean and not public.is_plus(a));

   -- 6. Not even by the original redeemer.
   r := t_json(pg, 'select public.redeem(''BLUEPLUS'')');
   perform t_ok('original redeemer cannot reuse their own code',
      not (r->>'ok')::boolean);

   -- 7. Made-up codes are refused, with the SAME message as a used code, so
   --    nobody can probe for which codes exist.
   r := t_json(m, 'select public.redeem(''NOTAREALCODE'')');
   perform t_ok('invalid code refused',  not (r->>'ok')::boolean);
   perform t_ok('invalid and used codes are indistinguishable',
      (r->>'m') = 'Invalid or already used code');

   -- 8. Case does not matter (players type lowercase).
   --    Redeemed as a THROWAWAY account: giving Alice Blue+ here would
   --    silently break every later "free user" assertion.
   insert into auth.users (id,email) values
      ('dddd0000-0000-0000-0000-000000000001','lower@blueclient.app')
   on conflict do nothing;
   insert into public.profiles (id,username,username_low) values
      ('dddd0000-0000-0000-0000-000000000001','LowerTest','lowertest')
   on conflict do nothing;
   insert into public.redeem_codes (code,kind,plus_days) values ('LOWERTEST','plus',30);
   r := t_json('dddd0000-0000-0000-0000-000000000001',
               'select public.redeem(''lowertest'')');
   perform t_ok('lowercase entry still redeems', (r->>'ok')::boolean);

   -- 9. Expired codes do not work.
   insert into public.redeem_codes (code,kind,plus_days,expires_at)
   values ('EXPIRED1','plus',30, now() - interval '1 day');
   r := t_json(m, 'select public.redeem(''EXPIRED1'')');
   perform t_ok('expired code refused', not (r->>'ok')::boolean);

   -- 10. A badge code grants exactly that badge.
   insert into public.redeem_codes (code,kind,value) values ('HELPER01','badge','helper');
   r := t_json(m, 'select public.redeem(''HELPER01'')');
   perform t_ok('badge code grants the badge',
      (r->>'ok')::boolean
      and exists (select 1 from public.user_badges where user_id=m and badge_id='helper'));

   -- 11. A badge code pointing at a non-existent badge fails safely.
   insert into public.redeem_codes (code,kind,value) values ('BADBADGE','badge','nope');
   r := t_json(m, 'select public.redeem(''BADBADGE'')');
   perform t_ok('code for a missing badge fails cleanly', not (r->>'ok')::boolean);

   -- 12. Anonymous users cannot redeem.
   perform set_config('request.jwt.claim.sub', '', true);
   set local role anon;
   begin
      perform public.redeem('CYANBLUEPLUS');
      set local role postgres;
      perform t_ok('anon cannot redeem', false);
   exception when others then
      set local role postgres;
      perform t_ok('anon cannot redeem', true);
   end;

   -- 13. CYANBLUEPLUS is still unused after all that.
   perform t_ok('CYANBLUEPLUS still unused',
      (select redeemed_by is null from public.redeem_codes where code='CYANBLUEPLUS'));
end $$;


\echo ''
\echo '=============== BLUE+ DURATION AND STACKING ==============='

do $$
declare
   d1 uuid := '88888888-8888-8888-8888-888888888881';
   r  json;
   until1 timestamptz;
   until2 timestamptz;
begin
   insert into auth.users (id,email) values (d1,'d1@blueclient.app');
   insert into public.profiles (id,username,username_low) values (d1,'DayGuy','dayguy');

   insert into public.redeem_codes (code,kind,plus_days) values ('THIRTY01','plus',30);
   insert into public.redeem_codes (code,kind,plus_days) values ('THIRTY02','plus',30);

   perform t_json(d1, 'select public.redeem(''THIRTY01'')');
   select plus_until into until1 from public.profiles where id=d1;

   perform t_json(d1, 'select public.redeem(''THIRTY02'')');
   select plus_until into until2 from public.profiles where id=d1;

   perform t_ok('30-day code grants ~30 days',
      until1 between now() + interval '29 days' and now() + interval '31 days');
   perform t_ok('a second code STACKS instead of overwriting',
      until2 between now() + interval '59 days' and now() + interval '61 days');
   perform t_ok('timed Blue+ is not marked permanent',
      not (select plus_permanent from public.profiles where id=d1));

   -- Expiry actually ends the subscription.
   update public.profiles set plus_until = now() - interval '1 day' where id=d1;
   perform t_ok('expired Blue+ is no longer active', not public.is_plus(d1));

   -- Permanent Blue+ survives a null/past plus_until.
   perform t_ok('permanent Blue+ ignores plus_until',
      public.is_plus('0a000000-0000-0000-0000-0000000000b1'));
end $$;


\echo ''
\echo '=============== TIER LIMITS ==============='

do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   pg uuid := '66666666-6666-6666-6666-666666666666';
begin
   perform t_ok('free about limit is 50',      public.limit_of(a,'about') = 50);
   perform t_ok('plus about limit is 100',     public.limit_of(pg,'about') = 100);
   perform t_ok('free status limit is 25',     public.limit_of(a,'status') = 25);
   perform t_ok('plus status limit is 40',     public.limit_of(pg,'status') = 40);
   perform t_ok('free post limit is 25',       public.limit_of(a,'post') = 25);
   perform t_ok('plus post limit is 100',      public.limit_of(pg,'post') = 100);
   perform t_ok('free friend limit is 15',     public.limit_of(a,'friends') = 15);
   perform t_ok('plus friend limit is 40',     public.limit_of(pg,'friends') = 40);
   perform t_ok('free following limit is 15',  public.limit_of(a,'following') = 15);
   perform t_ok('plus following limit is 50',  public.limit_of(pg,'following') = 50);
   perform t_ok('free posts/hour is 2',        public.limit_of(a,'posts_hour') = 2);
   perform t_ok('plus posts/hour is 4',        public.limit_of(pg,'posts_hour') = 4);
end $$;


\echo ''
\echo '=============== POSTS ==============='

do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   pg uuid := '66666666-6666-6666-6666-666666666666';
   m  uuid := '44444444-4444-4444-4444-444444444444';
   r  json;
begin
   delete from public.posts;

   -- 1. Free user post is truncated to 25 characters, not rejected.
   r := t_json(a, format('select public.create_post(%L)', repeat('the quick brown fox jumps over the lazy dog while nine clever badgers watch from a quiet hill nearby and hum softly ', 3)));
   perform t_ok('free post truncated to 25 chars',
      (r->>'ok')::boolean
      and (select char_length(body) from public.posts where author_id=a) = 25);

   -- 2. Free user hits 2/hour.
   r := t_json(a, 'select public.create_post(''second'')');
   perform t_ok('free user may post twice', (r->>'ok')::boolean);
   r := t_json(a, 'select public.create_post(''third'')');
   perform t_ok('free user blocked at 3rd post in an hour', not (r->>'ok')::boolean);
   perform t_ok('rate limit tells you when to retry', (r->>'retry') is not null);

   -- 3. Plus user gets 100 chars and 4/hour.
   r := t_json(pg, format('select public.create_post(%L)', repeat('the quick brown fox jumps over the lazy dog while nine clever badgers watch from a quiet hill nearby and hum softly ', 3)));
   perform t_ok('plus post truncated to 100 chars',
      (select char_length(body) from public.posts where author_id=pg) = 100);
   perform t_json(pg, 'select public.create_post(''2'')');
   perform t_json(pg, 'select public.create_post(''3'')');
   r := t_json(pg, 'select public.create_post(''4'')');
   perform t_ok('plus user may post 4 times', (r->>'ok')::boolean);
   r := t_json(pg, 'select public.create_post(''5'')');
   perform t_ok('plus user blocked at 5th post', not (r->>'ok')::boolean);

   -- 4. Direct INSERT bypassing the rate limit must fail.
   perform t_ok('player cannot INSERT a post directly',
      t_blocked(m, 'insert into public.posts (author_id,body) values
                    (''44444444-4444-4444-4444-444444444444'',''bypass'')'));

   -- 5. Cannot post AS someone else.
   perform t_ok('player cannot forge a post from another user',
      t_blocked(m, 'insert into public.posts (author_id,body) values
                    (''11111111-1111-1111-1111-111111111111'',''fake'')'));

   -- 6. Cannot delete someone else's post.
   perform t_bool(m, format('select public.delete_post(%L)',
      (select id from public.posts where author_id=a limit 1)));
   perform t_ok('cannot delete another user''s post',
      (select count(*) from public.posts where author_id=a) = 2);

   -- 7. Can delete your own.
   perform t_bool(a, format('select public.delete_post(%L)',
      (select id from public.posts where author_id=a limit 1)));
   perform t_ok('can delete your own post',
      (select count(*) from public.posts where author_id=a) = 1);

   -- 8. Empty posts refused.
   r := t_json(a, 'select public.create_post(''   '')');
   perform t_ok('empty post refused', not (r->>'ok')::boolean);
end $$;


\echo ''
\echo '=============== FEED AND BLOCKING ==============='

do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   b  uuid := '22222222-2222-2222-2222-222222222222';
   m  uuid := '44444444-4444-4444-4444-444444444444';
   f  json;
begin
   delete from public.posts;
   delete from public.blocks;
   insert into public.posts (author_id, body) values (b,'bob post'), (m,'mallory post');

   -- You see posts from people you follow.
   insert into public.follows (follower_id,followee_id) values (a,b) on conflict do nothing;
   f := t_json(a, 'select public.get_feed()');
   perform t_ok('feed shows posts from people you follow',
      f::text like '%bob post%');

   -- You do not see posts from people you do not follow.
   perform t_ok('feed hides posts from strangers',
      f::text not like '%mallory post%');

   -- A blocker's posts disappear from your feed.
   insert into public.follows (follower_id,followee_id) values (a,m) on conflict do nothing;
   insert into public.blocks (blocker_id,blocked_id) values (m,a);
   f := t_json(a, 'select public.get_feed()');
   perform t_ok('feed hides posts from someone who blocked you',
      f::text not like '%mallory post%');

   -- And direct table reads are blocked too, not just the RPC.
   perform t_ok('blocked user cannot read the blocker''s posts directly',
      t_blocked(a, 'select * from public.posts where author_id=
                    ''44444444-4444-4444-4444-444444444444'''));
   delete from public.blocks;
end $$;


\echo ''
\echo '=============== COLOURED NAMES (Blue+ only) ==============='

do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   pg uuid := '66666666-6666-6666-6666-666666666666';
   r  json;
begin
   -- 1. Free users cannot set a colour.
   r := t_json(a, 'select public.set_name_color(''{"a":"#FF0000"}'')');
   perform t_ok('free user refused a coloured name',
      not (r->>'ok')::boolean
      and (select name_color is null from public.profiles where id=a));

   -- 2. Plus users can.
   r := t_json(pg, 'select public.set_name_color(''{"a":"#2FA5FF","b":"#FFD600","g":1}'')');
   perform t_ok('plus user sets a gradient name', (r->>'ok')::boolean);

   -- 3. Non-hex values are rejected - this is what protects the renderer.
   r := t_json(pg, 'select public.set_name_color(''{"a":"red"}'')');
   perform t_ok('non-hex colour rejected', not (r->>'ok')::boolean);
   r := t_json(pg, 'select public.set_name_color(''{"a":"#GGGGGG"}'')');
   perform t_ok('invalid hex digits rejected', not (r->>'ok')::boolean);
   r := t_json(pg, 'select public.set_name_color(''not json at all'')');
   perform t_ok('malformed json rejected', not (r->>'ok')::boolean);
   r := t_json(pg, format('select public.set_name_color(%L)',
      '{"a":"#FF0000","x":"' || repeat('z', 200) || '"}'));
   perform t_ok('oversized colour payload rejected', not (r->>'ok')::boolean);

   -- 4. Direct UPDATE bypassing the Blue+ check must fail.
   perform t_ok('free user cannot UPDATE name_color directly',
      t_blocked(a, 'update public.profiles set name_color=''{"a":"#FF0000"}''
                    where id=''11111111-1111-1111-1111-111111111111'''));

   -- 5. Losing Blue+ clears the colour.
   update public.profiles set plus_until = now() - interval '1 day',
                              plus_permanent = false where id=pg;
   perform public.clear_expired_plus();
   perform t_ok('expired Blue+ loses the coloured name',
      (select name_color is null from public.profiles where id=pg));
   -- restore for later tests
   update public.profiles set plus_permanent = true where id=pg;
end $$;


\echo ''
\echo '=============== PRESENCE ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   r boolean;
begin
   perform t_bool(a, 'select public.set_presence(''dnd'')');
   perform t_ok('can set DND',
      (select presence from public.profiles where id=a) = 'dnd');

   perform t_bool(a, 'select public.set_presence(''invisible'')');
   perform t_ok('invalid presence value ignored',
      (select presence from public.profiles where id=a) = 'dnd');

   perform t_ok('cannot set another user''s presence',
      t_blocked(a, 'update public.profiles set presence=''offline''
                    where id=''22222222-2222-2222-2222-222222222222'''));

   perform t_bool(a, 'select public.set_presence(''online'')');
   perform t_ok('can return to online',
      (select presence from public.profiles where id=a) = 'online');
end $$;


\echo ''
\echo '=============== SERVER INVITES ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   r json;
   iv uuid;
begin
   delete from public.invites;
   update public.profiles set presence='online' where id in (a,b);

   -- 1. Friends can invite.
   r := t_json(a, format('select public.send_invite(%L,%L,%L)', b, 'play.test.net','My world'));
   perform t_ok('friend can send an invite', (r->>'ok')::boolean);

   -- 2. Strangers cannot.
   r := t_json(m, format('select public.send_invite(%L,%L,%L)', b, 'evil.net','hi'));
   perform t_ok('non-friend cannot send an invite', not (r->>'ok')::boolean);

   -- 3. DND refuses invites.
   perform t_bool(b, 'select public.set_presence(''dnd'')');
   r := t_json(a, format('select public.send_invite(%L,%L,%L)', b, 'play.test.net','x'));
   perform t_ok('DND player receives no invites', not (r->>'ok')::boolean);
   perform t_bool(b, 'select public.set_presence(''online'')');

   -- 4. Only the recipient can see it.
   perform t_ok('a third party cannot read your invites',
      t_blocked(m, 'select * from public.invites'));

   -- 5. Only the recipient can accept.
   select id into iv from public.invites where to_id=b limit 1;
   r := t_json(m, format('select public.accept_invite(%L)', iv));
   perform t_ok('a third party cannot accept your invite', not (r->>'ok')::boolean);

   r := t_json(b, format('select public.accept_invite(%L)', iv));
   perform t_ok('recipient accepts and gets the address',
      (r->>'ok')::boolean and (r->>'a') = 'play.test.net');

   -- 6. Expired invites are refused.
   insert into public.invites (from_id,to_id,address,expires_at)
   values (a,b,'old.net', now() - interval '1 hour') returning id into iv;
   r := t_json(b, format('select public.accept_invite(%L)', iv));
   perform t_ok('expired invite refused', not (r->>'ok')::boolean);

   -- 7. Spam is rate limited.
   delete from public.invites;
   for i in 1..5 loop
      perform t_json(a, format('select public.send_invite(%L,%L,%L)', b, 's'||i||'.net','x'));
   end loop;
   r := t_json(a, format('select public.send_invite(%L,%L,%L)', b, 'spam.net','x'));
   perform t_ok('invite spam is rate limited', not (r->>'ok')::boolean);

   -- 8. Cannot forge an invite FROM someone else.
   perform t_ok('cannot forge an invite from another user',
      t_blocked(m, format('insert into public.invites (from_id,to_id,address)
                           values (%L,%L,''fake.net'')', a, b)));
end $$;


\echo ''
\echo '=============== FOLLOW AND FRIEND CAPS ==============='

do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   pg uuid := '66666666-6666-6666-6666-666666666666';
   u  uuid;
   n  int;
begin
   -- Build 60 spare accounts to follow.
   for i in 1..60 loop
      u := ('99999999-0000-0000-0000-' || lpad(i::text, 12, '0'))::uuid;
      insert into auth.users (id,email) values (u, 'spare'||i||'@blueclient.app')
      on conflict do nothing;
      insert into public.profiles (id,username,username_low)
      values (u, 'Spare'||i, 'spare'||i) on conflict do nothing;
   end loop;

   -- Free user: 15 following, and the 2 staff follows must NOT count.
   delete from public.follows where follower_id=a
      and followee_id not in (select id from public.profiles
                               where username_low in ('bluewuztaken','cyan'));
   for i in 1..15 loop
      u := ('99999999-0000-0000-0000-' || lpad(i::text, 12, '0'))::uuid;
      insert into public.follows (follower_id,followee_id) values (a,u);
   end loop;
   perform t_ok('free user reaches 15 follows (staff excluded from the cap)',
      (select count(*) from public.follows f
         join public.profiles p on p.id=f.followee_id
        where f.follower_id=a and p.username_low not in ('bluewuztaken','cyan')) = 15);

   u := '99999999-0000-0000-0000-000000000016'::uuid;
   perform t_ok('free user blocked at the 16th follow',
      t_raises(format('insert into public.follows (follower_id,followee_id)
                       values (%L,%L)', a, u)));

   -- Plus user: 50.
   for i in 1..50 loop
      u := ('99999999-0000-0000-0000-' || lpad(i::text, 12, '0'))::uuid;
      insert into public.follows (follower_id,followee_id) values (pg,u)
      on conflict do nothing;
   end loop;
   perform t_ok('plus user reaches 50 follows',
      (select count(*) from public.follows f
         join public.profiles p on p.id=f.followee_id
        where f.follower_id=pg and p.username_low not in ('bluewuztaken','cyan')) = 50);

   u := '99999999-0000-0000-0000-000000000051'::uuid;
   perform t_ok('plus user blocked at the 51st follow',
      t_raises(format('insert into public.follows (follower_id,followee_id)
                       values (%L,%L)', pg, u)));
end $$;


\echo ''
\echo '=============== FOLLOWER COUNTS AND AUTO-VERIFY ==============='

do $$
declare
   star uuid := '33333333-0000-0000-0000-000000000001';
   u    uuid;
begin
   insert into auth.users (id,email) values (star,'star@blueclient.app');
   insert into public.profiles (id,username,username_low) values (star,'Star','star');

   -- 99 followers: not verified yet.
   for i in 1..99 loop
      u := ('99999999-0000-0000-0000-' || lpad(i::text, 12, '0'))::uuid;
      insert into auth.users (id,email) values (u,'fan'||i||'@blueclient.app')
      on conflict do nothing;
      insert into public.profiles (id,username,username_low)
      values (u,'Fan'||i,'fan'||i) on conflict do nothing;
      insert into public.follows (follower_id,followee_id) values (u,star)
      on conflict do nothing;
   end loop;

   perform t_ok('follower_count is maintained by trigger',
      (select follower_count from public.profiles where id=star) = 99);
   perform t_ok('99 followers is NOT verified',
      not (select verified from public.profiles where id=star));

   -- The 100th follower flips it.
   u := '99999999-0000-0000-0000-000000000100'::uuid;
   insert into auth.users (id,email) values (u,'fan100@blueclient.app');
   insert into public.profiles (id,username,username_low) values (u,'Fan100','fan100');
   insert into public.follows (follower_id,followee_id) values (u,star);

   perform t_ok('100 followers grants Verified',
      (select verified from public.profiles where id=star));

   -- Dropping below 100 takes it away.
   delete from public.follows where follower_id=u and followee_id=star;
   perform t_ok('dropping below 100 LOSES Verified',
      not (select verified from public.profiles where id=star));
   perform t_ok('follower_count decrements correctly',
      (select follower_count from public.profiles where id=star) = 99);

   -- Staff keep it regardless.
   perform t_ok('staff keep Verified below 100 followers',
      (select verified from public.profiles
        where id='0a000000-0000-0000-0000-0000000000b1'));

   -- Players cannot simply set verified on themselves.
   perform t_ok('player cannot self-verify',
      t_blocked('11111111-1111-1111-1111-111111111111',
                'update public.profiles set verified=true
                 where id=''11111111-1111-1111-1111-111111111111'''));
end $$;


\echo ''
\echo '=============== LEADERBOARD ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   lb json;
begin
   lb := t_json(a, 'select public.leaderboard(5)');
   perform t_ok('leaderboard returns at most 5', json_array_length(lb) <= 5);
   -- Blue and Cyan are auto-followed by EVERY account, so they legitimately
   -- top the board. What matters is the ordering is by follower_count desc.
   perform t_ok('leaderboard is sorted by follower count descending',
      (lb->0->>'f')::int >= (lb->1->>'f')::int);
   lb := t_json(a, 'select public.leaderboard(25)');
   perform t_ok('leaderboard includes Star with the right count',
      lb::text like '%"u" : "Star"%' or lb::text like '%"u":"Star"%');

   -- limit is clamped so nobody can dump the whole table
   lb := t_json(a, 'select public.leaderboard(100000)');
   perform t_ok('leaderboard limit is clamped to 25', json_array_length(lb) <= 25);
end $$;


\echo ''
\echo '=============== IP ACCOUNT CAP ==============='

do $$
declare
   u  uuid;
   r  json;
   h  text;
begin
   -- Simulate four signups from one address.
   perform set_config('request.headers',
      '{"x-forwarded-for":"203.0.113.9, 10.0.0.1"}', true);

   for i in 1..3 loop
      u := ('aaaa0000-0000-0000-0000-' || lpad(i::text,12,'0'))::uuid;
      insert into auth.users (id,email) values (u,'ip'||i||'@blueclient.app');
      insert into public.profiles (id,username,username_low)
      values (u,'Ip'||i,'ip'||i);
      r := t_json(u, 'select public.register_ip()');
      if i = 3 then
         perform t_ok('3rd account from one IP is allowed', (r->>'ok')::boolean);
      end if;
   end loop;

   u := 'aaaa0000-0000-0000-0000-000000000004'::uuid;
   insert into auth.users (id,email) values (u,'ip4@blueclient.app');
   insert into public.profiles (id,username,username_low) values (u,'Ip4','ip4');
   r := t_json(u, 'select public.register_ip()');
   perform t_ok('4th account from one IP is refused', not (r->>'ok')::boolean);

   -- The raw address is NEVER stored.
   perform t_ok('raw IP is not stored anywhere',
      not exists (select 1 from private.ip_accounts where ip_hash like '%203.0.113%'));
   perform t_ok('IP is stored as a 64-char sha256 hash',
      (select length(ip_hash) from private.ip_accounts limit 1) = 64);

   -- Whitelisting lets a household through.
   select ip_hash into h from private.ip_accounts limit 1;
   insert into private.ip_whitelist (ip_hash, note) values (h,'test house');
   r := t_json(u, 'select public.register_ip()');
   perform t_ok('whitelisted IP bypasses the cap', (r->>'ok')::boolean);
   delete from private.ip_whitelist;

   -- Players cannot read or tamper with any of it.
   perform t_ok('player cannot read ip_accounts',
      t_blocked('11111111-1111-1111-1111-111111111111',
                'select * from private.ip_accounts'));
   perform t_ok('player cannot read the IP salt',
      t_blocked('11111111-1111-1111-1111-111111111111',
                'select * from private.app_secrets'));
   perform t_ok('player cannot whitelist themselves',
      t_blocked('11111111-1111-1111-1111-111111111111',
                'insert into private.ip_whitelist (ip_hash) values (''x'')'));

   -- A different address is unaffected.
   perform set_config('request.headers',
      '{"x-forwarded-for":"198.51.100.7"}', true);
   u := 'bbbb0000-0000-0000-0000-000000000001'::uuid;
   insert into auth.users (id,email) values (u,'other@blueclient.app');
   insert into public.profiles (id,username,username_low) values (u,'Other','other');
   r := t_json(u, 'select public.register_ip()');
   perform t_ok('a different IP is unaffected by the cap', (r->>'ok')::boolean);

   perform set_config('request.headers', '', true);
end $$;


\echo ''
\echo '=============== SYNC (the egress-critical RPC) ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   s json;
   sz int;
begin
   s := t_json(a, 'select public.sync(0)');
   perform t_ok('sync returns a version cursor', (s->>'v') is not null);
   perform t_ok('sync includes the caller''s own counters', (s->'me') is not null);

   -- The important one: an idle poll must be tiny.
   --
   -- v21.1: the cursor is now a REVISION COUNTER, not a timestamp. Passing a
   -- revision >= the caller's current one means "nothing changed", and sync
   -- replies with just the cursor and the caller's own counters - no lists.
   -- A timestamp far in the future is no longer the way to ask that; it would
   -- read as a huge revision, which is still "not stale", so it also works.
   s := t_json(a, 'select public.sync(999999999)');
   sz := length(s::text);
   perform t_ok('an idle sync is under 200 bytes (egress!)', sz < 200);
   perform t_ok('an idle sync omits the list sections',
      (s->'f') is null and (s->'r') is null and (s->'c') is null);
   perform t_ok('nulls are stripped from sync output',
      s::text not like '%null%');

   -- ...but a STALE cursor must get the full picture, lists included.
   s := t_json(a, 'select public.sync(0)');
   perform t_ok('a stale cursor gets the full lists',
      json_typeof(s->'f') = 'array' and json_typeof(s->'r') = 'array');

   -- Anonymous callers get nothing.
   perform set_config('request.jwt.claim.sub', '', true);
   set local role anon;
   begin
      perform public.sync(0);
      set local role postgres;
      perform t_ok('anon cannot call sync', false);
   exception when others then
      set local role postgres;
      perform t_ok('anon cannot call sync', true);
   end;
end $$;


\echo ''
\echo '=============== SKIN NAME ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   r json;
begin
   r := t_json(a, 'select public.set_skin_name(''Notch'')');
   perform t_ok('can set a social skin name', (r->>'ok')::boolean);
   r := t_json(a, 'select public.set_skin_name(''not a name!'')');
   perform t_ok('invalid skin name rejected', not (r->>'ok')::boolean);
   r := t_json(a, format('select public.set_skin_name(%L)', repeat('x',40)));
   perform t_ok('over-long skin name rejected', not (r->>'ok')::boolean);

   -- A cosmetic skin must NOT imply a verified Minecraft link.
   perform t_ok('setting a skin does not set mc_verified',
      not coalesce((select mc_verified from public.profiles where id=a), false));
end $$;


\echo ''
\echo '=============== HOUSEKEEPING ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   r json;
begin
   insert into public.invites (from_id,to_id,address,expires_at)
   values (a,'22222222-2222-2222-2222-222222222222','old.net',
           now() - interval '3 days');
   r := t_json(a, 'select public.housekeeping()');
   perform t_ok('housekeeping deletes stale invites',
      not exists (select 1 from public.invites where address='old.net'));
end $$;

\echo ''

\echo ''
\echo '=============== BUDDIES (mutual consent, one each) ==============='

do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   c uuid := 'eeee0000-0000-0000-0000-000000000001';
   r json;
begin
   -- a and b are already friends from the fixture. Add c as a friend of a.
   insert into auth.users (id,email) values (c,'carol@blueclient.app')
   on conflict do nothing;
   insert into public.profiles (id,username,username_low) values (c,'Carol','carol')
   on conflict do nothing;
   insert into public.friendships (user_a,user_b)
   values (least(a,c), greatest(a,c)) on conflict do nothing;

   update public.profiles set buddy_id = null where id in (a,b,m,c);
   delete from public.buddy_requests;

   -- 1. The v2 one-sided setter is gone.
   perform t_ok('one-sided set_buddy no longer exists',
      not exists (select 1 from pg_proc where proname = 'set_buddy'));

   -- 2. A request alone does NOT make them buddies.
   r := t_json(a, format('select public.request_buddy(%L)', b));
   perform t_ok('request alone does not pair', (r->>'ok')::boolean
      and (r->>'paired')::boolean is false
      and (select buddy_id from public.profiles where id=a) is null);

   -- 3. The other side accepting DOES pair, on both rows.
   r := t_json(b, format('select public.request_buddy(%L)', a));
   perform t_ok('mutual request pairs both sides',
      (r->>'paired')::boolean
      and (select buddy_id from public.profiles where id=a) = b
      and (select buddy_id from public.profiles where id=b) = a);

   -- 4. One buddy each: a third player cannot join in.
   r := t_json(c, format('select public.request_buddy(%L)', a));
   perform t_ok('cannot buddy someone who already has one',
      not (r->>'ok')::boolean);

   -- 5. Nor can a paired player take a second buddy.
   r := t_json(a, format('select public.request_buddy(%L)', c));
   perform t_ok('cannot take a second buddy', not (r->>'ok')::boolean);

   -- 6. Non-friends cannot buddy.
   r := t_json(m, format('select public.request_buddy(%L)', c));
   perform t_ok('cannot buddy a non-friend', not (r->>'ok')::boolean);

   -- 7. Clearing removes BOTH sides.
   perform t_bool(a, 'select public.clear_buddy()');
   perform t_ok('clearing a buddy clears both rows',
      (select buddy_id from public.profiles where id=a) is null
      and (select buddy_id from public.profiles where id=b) is null);

   -- 8. Nobody can write buddy_id directly.
   perform t_ok('cannot set buddy_id by direct update',
      t_blocked(m, format('update public.profiles set buddy_id=%L where id=%L', a, m)));

   -- 9. A third party cannot read other people's buddy requests.
   perform t_json(a, format('select public.request_buddy(%L)', b));
   perform t_ok('cannot read other players'' buddy requests',
      t_blocked(m, 'select * from public.buddy_requests'));

   -- 10. Declining removes the request.
   perform t_bool(b, format('select public.decline_buddy(%L)', a));
   perform t_ok('declining removes the request',
      not exists (select 1 from public.buddy_requests where from_id=a and to_id=b));
end $$;

\echo ''

\echo '--- 14. coloured nameplates (widened badges_for_players) ---'
do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   b  uuid := '22222222-2222-2222-2222-222222222222';
   pg uuid := '66666666-6666-6666-6666-666666666666';
   n  integer;
   r  json;
begin
   -- Give everyone a Minecraft name so the lookup has something to match.
   update public.profiles set mc_name = 'Alice_MC'   where id = a;
   update public.profiles set mc_name = 'Bob_MC'     where id = b;
   update public.profiles set mc_name = 'PlusGuy_MC' where id = pg;

   -- PlusGuy is a subscriber with a colour; Alice is free but verified;
   -- Bob is plain free with nothing to show.
   -- Clear plus_permanent explicitly: an EARLIER test in this file redeems a
   -- permanent code as PlusGuy, and a permanent subscription ignores
   -- plus_until entirely - which would make the expiry test below a no-op.
   update public.profiles
      set plus_permanent = false,
          plus_until = now() + interval '30 days',
          name_color = '{"a":"#2FA5FF","b":"#FFD600","g":1}'
    where id = pg;
   update public.profiles set verified = true  where id = a;
   update public.profiles set verified = false, name_color = '{"a":"#FF0000"}'
    where id = b;

   -- badges_for_players requires auth.uid(), so act as Alice for the reads.
   -- (Test 7 below deliberately drops this to check the refusal.)
   perform set_config('request.jwt.claim.sub', a::text, true);

   -- 1. A free user's colour is never served, even if a row exists for it.
   select count(*) into n from public.badges_for_players(array['Bob_MC'])
      where name_color is not null;
   perform t_ok('free user gets no name colour', n = 0);

   -- 2. Bob carries nothing at all, so he is omitted entirely - the payload
   --    stays small, which is the whole point of filtering server-side.
   select count(*) into n from public.badges_for_players(array['Bob_MC']);
   perform t_ok('player with nothing to show is omitted', n = 0);

   -- 3. A subscriber's colour IS served.
   select count(*) into n from public.badges_for_players(array['PlusGuy_MC'])
      where name_color is not null and is_plus;
   perform t_ok('Blue+ user gets their name colour', n = 1);

   -- 4. Verified is reported even with no badge and no Blue+ (LEFT join).
   select count(*) into n from public.badges_for_players(array['Alice_MC'])
      where verified and not is_plus;
   perform t_ok('verified free user is still returned', n = 1);

   -- 5. An expired subscription stops colouring immediately.
   update public.profiles
      set plus_permanent = false, plus_until = now() - interval '1 day'
    where id = pg;
   select count(*) into n from public.badges_for_players(array['PlusGuy_MC'])
      where name_color is not null;
   perform t_ok('expired Blue+ loses its colour at once', n = 0);
   update public.profiles set plus_until = now() + interval '30 days' where id = pg;

   -- 6. Still capped at 100 names.
   select count(*) into n from public.badges_for_players(
      (select array_agg('N' || g) from generate_series(1,250) g));
   perform t_ok('name list is capped', n <= 100);

   -- 7. Anonymous callers are refused. t_blocked clears the claim for us.
   perform t_ok('badges_for_players requires auth',
      t_blocked(null, 'select * from public.badges_for_players(array[''Alice_MC''])'));
   perform set_config('request.jwt.claim.sub', a::text, true);
end $$;

\echo ''

\echo '--- 15. appear-offline actually hides you ---'
do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   n integer;
   r json;
begin
   -- Bob is genuinely in game on a real server.
   update public.profiles
      set is_online = true, server_name = 'play.donutsmp.net',
          last_seen = now(), presence = 'online'
    where id = b;
   perform set_config('request.jwt.claim.sub', a::text, true);

   -- 1. Normally Alice can see where Bob is.
   select count(*) into n from public.get_friends()
      where id = b and is_online and server_name = 'play.donutsmp.net';
   perform t_ok('online friend shows their server', n = 1);

   -- 2. Bob appears offline.
   update public.profiles set presence = 'offline' where id = b;
   select count(*) into n from public.get_friends()
      where id = b and is_online;
   perform t_ok('appear-offline forces is_online false', n = 0);

   select count(*) into n from public.get_friends()
      where id = b and server_name is not null;
   perform t_ok('appear-offline hides the server name', n = 0);

   select count(*) into n from public.get_friends()
      where id = b and last_seen is not null;
   perform t_ok('appear-offline hides last seen', n = 0);

   -- 3. He is still listed as a friend - hidden, not deleted.
   select count(*) into n from public.get_friends() where id = b;
   perform t_ok('hidden friend is still in the list', n = 1);

   -- 4. And he cannot be joined.
   r := t_json(a, format('select public.get_join_address(%L)', b));
   perform t_ok('cannot join an appear-offline friend', not (r->>'ok')::boolean);

   -- 5. Back online, everything returns.
   update public.profiles set presence = 'online' where id = b;
   perform set_config('request.jwt.claim.sub', a::text, true);
   select count(*) into n from public.get_friends()
      where id = b and is_online and server_name is not null;
   perform t_ok('going back online restores visibility', n = 1);

   -- 6. DND is NOT invisibility - it only silences notifications.
   update public.profiles set presence = 'dnd' where id = b;
   perform set_config('request.jwt.claim.sub', a::text, true);
   select count(*) into n from public.get_friends() where id = b and is_online;
   perform t_ok('DND still shows as online', n = 1);
   update public.profiles set presence = 'online' where id = b;
end $$;

\echo ''

\echo '--- 16. sync() must report emptied lists as [] (owner-reported bug) ---'
do $$
declare
   a   uuid := '11111111-1111-1111-1111-111111111111';
   b   uuid := '22222222-2222-2222-2222-222222222222';
   m   uuid := '44444444-4444-4444-4444-444444444444';
   s   json;
   rid uuid;
begin
   -- Clean slate between these two.
   delete from public.friend_requests
    where sender_id in (a,b,m) or receiver_id in (a,b,m);
   delete from public.friendships
    where user_a in (a,b,m) or user_b in (a,b,m);

   -- Mallory sends Alice a request. There is no send RPC - the client
   -- INSERTs into friend_requests directly, guarded by RLS - so the test
   -- does it the same way the client does.
   insert into public.friend_requests (sender_id, receiver_id)
   values (m, a) returning id into rid;

   -- 1. Alice sees exactly one incoming request.
   s := t_json(a, 'select public.sync(0)');
   perform t_ok('sync reports the incoming request',
      json_array_length(s->'r') = 1);

   -- 2. THE BUG: after accepting, 'r' must be present AND empty. Before the
   --    fix json_agg returned null, json_strip_nulls deleted the key, and the
   --    client read "key absent" as "unchanged" - so the request stuck.
   perform t_bool(a, format('select true from public.accept_friend_request(%L)', rid));
   s := t_json(a, 'select public.sync(0)');
   perform t_ok('sync still SENDS the r key when it empties',
      (s->'r') is not null);
   perform t_ok('accepted request is gone from sync',
      json_array_length(s->'r') = 0);

   -- 3. And they are now friends in the same payload.
   perform t_ok('accepting produces a friendship',
      json_array_length(s->'f') = 1);

   -- 4. The SENDER also learns their outgoing request resolved.
   s := t_json(m, 'select public.sync(0)');
   perform t_ok('sender sees their outgoing request cleared',
      (s->'ro') is not null and json_array_length(s->'ro') = 0);

   -- 5. Every list section is an array, never absent, on a totally empty
   --    account - this is the general form of the same bug.
   delete from public.friendships where user_a in (a,m) or user_b in (a,m);
   s := t_json(a, 'select public.sync(0)');
   perform t_ok('f is always an array',  json_typeof(s->'f')  = 'array');
   perform t_ok('r is always an array',  json_typeof(s->'r')  = 'array');
   perform t_ok('ro is always an array', json_typeof(s->'ro') = 'array');
   perform t_ok('c is always an array',  json_typeof(s->'c')  = 'array');
   perform t_ok('iv is always an array', json_typeof(s->'iv') = 'array');
end $$;

\echo ''

\echo '--- 18. post engagement: like / reply / repost + feed algorithm ---'
do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   b  uuid := '22222222-2222-2222-2222-222222222222';
   m  uuid := '44444444-4444-4444-4444-444444444444';
   pid uuid; r json; n int; f json;
begin
   delete from public.posts;
   delete from public.blocks where blocker_id in (a,b,m) or blocked_id in (a,b,m);

   insert into public.posts (author_id, body) values (b, 'bob original')
      returning id into pid;

   -- 1. Like is idempotent and reports the new state.
   r := t_json(a, format('select public.toggle_like(%L)', pid));
   perform t_ok('liking a post works', (r->>'ok')::boolean and (r->>'liked')::boolean
      and (r->>'n')::int = 1);

   -- 2. Liking again UNlikes - you cannot stack likes.
   r := t_json(a, format('select public.toggle_like(%L)', pid));
   perform t_ok('liking twice unlikes', not (r->>'liked')::boolean
      and (r->>'n')::int = 0);

   -- 3. The primary key makes a double like impossible even by direct insert.
   perform t_json(a, format('select public.toggle_like(%L)', pid));
   perform t_ok('cannot insert a duplicate like directly',
      t_blocked(a, format('insert into public.post_likes (post_id,user_id) values (%L,%L)', pid, a)));

   -- 4. Clients cannot write the like table at all.
   perform t_ok('likes are RPC-only',
      t_blocked(m, format('delete from public.post_likes where post_id=%L', pid)));

   -- 5. Replying works and bumps the parent's reply counter.
   r := t_json(a, format('select public.reply_to_post(%L, %L)', pid, 'nice one'));
   perform t_ok('replying works', (r->>'ok')::boolean);
   select reply_count into n from public.posts where id = pid;
   perform t_ok('reply bumps the parent counter', n = 1);

   -- 6. A reply obeys the SAME character cap as a post.
   r := t_json(a, format('select public.reply_to_post(%L, %L)', pid, repeat('the quick brown fox jumps over the lazy dog while nine clever badgers watch from a quiet hill nearby and hum softly ', 4)));
   perform t_ok('replies obey the character cap', not (r->>'ok')::boolean);

   -- 7. Replies do NOT appear as top-level posts in the feed.
   f := t_json(a, 'select public.get_feed(null, 50)');
   perform t_ok('replies stay out of the timeline',
      f::text not like '%nice one%');

   -- 8. ...but they do appear under their parent.
   f := t_json(a, format('select public.get_replies(%L, 50)', pid));
   perform t_ok('replies show under their parent', f::text like '%nice one%');

   -- 9. Reposting works.
   r := t_json(a, format('select public.toggle_repost(%L)', pid));
   perform t_ok('reposting works', (r->>'ok')::boolean and (r->>'reposted')::boolean);
   select repost_count into n from public.posts where id = pid;
   perform t_ok('repost bumps the counter', n = 1);

   -- 10. You cannot repost yourself.
   r := t_json(b, format('select public.toggle_repost(%L)', pid));
   perform t_ok('cannot repost your own post', not (r->>'ok')::boolean);

   -- 11. Deleting the post cascades its likes, replies and reposts away.
   delete from public.posts where id = pid;
   select count(*) into n from public.post_likes where post_id = pid;
   perform t_ok('deleting a post clears its likes', n = 0);
   select count(*) into n from public.post_reposts where post_id = pid;
   perform t_ok('deleting a post clears its reposts', n = 0);
   select count(*) into n from public.posts where parent_id = pid;
   perform t_ok('deleting a post clears its replies', n = 0);
end $$;

\echo '--- 19. the For You ranking ---'
do $$
declare
   a uuid := '11111111-1111-1111-1111-111111111111';
   b uuid := '22222222-2222-2222-2222-222222222222';
   m uuid := '44444444-4444-4444-4444-444444444444';
   hot uuid; cold uuid; mine uuid; f json;
begin
   delete from public.posts;
   delete from public.follows where follower_id = a;

   -- A fresh post with heavy engagement...
   insert into public.posts (author_id, body, created_at, like_count, repost_count)
   values (b, 'HOTPOST', now() - interval '1 hour', 50, 10) returning id into hot;

   -- ...an older post with none. Inside the 48h window, but old enough that
   -- the recency curve should rank it below the fresh one.
   insert into public.posts (author_id, body, created_at)
   values (m, 'COLDPOST', now() - interval '30 hours') returning id into cold;

   -- ...and one of my own.
   insert into public.posts (author_id, body) values (a, 'MYPOST') returning id into mine;

   f := t_json(a, 'select public.get_for_you(30)');

   -- 1. Engagement + freshness wins.
   perform t_ok('For You ranks the hot post first',
      (f->0->>'b') = 'HOTPOST');

   -- 2. Your own posts are not fed back to you.
   perform t_ok('For You excludes your own posts', f::text not like '%MYPOST%');

   -- 3. Old, unengaged posts still appear, just lower.
   perform t_ok('For You still includes cold posts', f::text like '%COLDPOST%');

   -- 4. Posts past the 48-hour window drop out entirely. The window was cut
   -- from 7 days to 48 hours so "For You" shows current posts, not an archive.
   update public.posts set created_at = now() - interval '30 days' where id = cold;
   f := t_json(a, 'select public.get_for_you(30)');
   perform t_ok('For You drops posts past the window', f::text not like '%COLDPOST%');

   -- 5. A blocked author never reaches the ranking.
   insert into public.blocks (blocker_id, blocked_id) values (b, a)
      on conflict do nothing;
   f := t_json(a, 'select public.get_for_you(30)');
   perform t_ok('For You respects blocks', f::text not like '%HOTPOST%');
   delete from public.blocks where blocker_id = b and blocked_id = a;

   -- 6. The Following feed carries reposts, tagged with who boosted them.
   insert into public.follows (follower_id, followee_id) values (a, m)
      on conflict do nothing;
   perform t_json(m, format('select public.toggle_repost(%L)', hot));
   f := t_json(a, 'select public.get_feed(null, 50)');
   perform t_ok('following feed shows reposts from people you follow',
      f::text like '%HOTPOST%');
   perform t_ok('a repost says who boosted it', f::text like '%Mallory%');
end $$;

\echo ''

\echo '--- 20. content filter, admin, owner transfer (v28 regressions) ---'
do $$
declare
   a  uuid := '11111111-1111-1111-1111-111111111111';
   v  json;
   n  int;
begin
   -- 1. Every spam branch must RETURN json, not throw. All four originally
   -- built a 5-element json_build_object and raised
   -- "argument list must have even number of elements".
   v := public.check_content(repeat('x', 200));
   perform t_ok('char spam returns ok=false', (v->>'ok') = 'false');
   perform t_ok('char spam has a message', (v->>'m') is not null);

   v := public.check_content('WHY IS EVERYONE SHOUTING AT ME');
   perform t_ok('all-caps returns a message', (v->>'m') is not null);

   v := public.check_content('http://a http://b http://c http://d');
   perform t_ok('link spam returns a message', (v->>'m') is not null);

   -- 2. Word boundaries, not substrings: the Scunthorpe problem.
   perform t_ok('"class" is not profanity',
      (public.check_content('my class assignment')->>'ok') = 'true');
   perform t_ok('"assassin" is not profanity',
      (public.check_content('the assassin creed game')->>'ok') = 'true');
   perform t_ok('real profanity is caught',
      (public.check_content('what the fuck')->>'ok') = 'false');
   perform t_ok('politics has its own category',
      (public.check_content('trump won')->>'c') = 'political');

   -- 3. Emphatic repetition inside real text is NOT spam.
   perform t_ok('"nooooo" in a sentence is allowed',
      (public.check_content('noooooooooo that is wild')->>'ok') = 'true');

   -- 4. Leetspeak evasion is normalised. NOTE: '4' maps to 'a', so "f4ck"
   -- becomes "fack" and is correctly NOT a match - the substitutions have to
   -- spell the real word after translation.
   perform t_ok('$ evasion is caught',
      (public.check_content('what the $hit')->>'ok') = 'false');
   perform t_ok('0 evasion is caught',
      (public.check_content('you are a wh0re')->>'ok') = 'false');
   perform t_ok('repeated-letter evasion is caught',
      (public.check_content('what the shiiiit')->>'ok') = 'false');
   perform t_ok('a near-miss is NOT caught',
      (public.check_content('what the fack')->>'ok') = 'true');

   -- 5. housekeeping() referenced a column that does not exist
   -- (mc_link_pending.expires_at), so the whole function threw and invite
   -- cleanup silently never ran.
   delete from public.invites;
   insert into public.invites (from_id, to_id, address, expires_at)
   values (a, '22222222-2222-2222-2222-222222222222', 'old.net',
           now() - interval '3 days');
   perform set_config('request.jwt.claim.sub', a::text, true);
   v := public.housekeeping();
   perform t_ok('housekeeping succeeds', (v->>'ok') = 'true');
   select count(*) into n from public.invites;
   perform t_ok('housekeeping removed the stale invite', n = 0);

   -- 6. set_about TRUNCATES, matching create_post. A v25 edit changed it to
   -- reject, which silently threw away what the player had written.
   perform set_config('request.jwt.claim.sub', a::text, true);
   v := public.set_about(repeat('the quick brown fox jumps over the lazy dog ', 5));
   perform t_ok('over-long about is accepted', (v->>'ok') = 'true');
   select char_length(about) into n from public.profiles where id = a;
   perform t_ok('over-long about was truncated, not rejected',
      n = public.limit_of(a, 'about'));
end $$;

\echo '--- 21. owner transfer ---'
do $$
declare n int;
begin
   -- Staff is DATA now, not hardcoded strings in eight functions.
   perform t_ok('staff_accounts exists',
      to_regclass('public.staff_accounts') is not null);
   perform t_ok('bluewuztaken is the owner',
      exists (select 1 from public.staff_accounts
               where username_low = 'bluewuztaken' and role = 'owner'));
   perform t_ok('cyan is still an admin',
      exists (select 1 from public.staff_accounts
               where username_low = 'cyan' and role = 'admin'));
   perform t_ok('blue is NOT staff any more',
      not exists (select 1 from public.staff_accounts
                   where username_low = 'blue'));

   -- Stripping must be explicit: removing the row does not undo what
   -- setup_staff() already granted.
   select count(*) into n from public.profiles
    where username_low = 'blue' and (plus_permanent or verified_forced);
   perform t_ok('blue keeps no staff perks', n = 0);

   -- Non-staff cannot reach any admin RPC.
   perform set_config('request.jwt.claim.sub',
      '11111111-1111-1111-1111-111111111111', true);
   perform t_ok('non-staff cannot use admin_overview',
      (public.admin_overview()->>'ok') = 'false');
   perform t_ok('non-staff cannot create codes',
      (public.admin_create_code('HACKCODE','plus',null,30,null,null)->>'ok') = 'false');
   perform t_ok('non-staff cannot pin',
      (public.pin_post('00000000-0000-0000-0000-000000000000')->>'ok') = 'false');
end $$;

\echo ''
