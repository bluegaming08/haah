#!/usr/bin/env python3
"""
Static mixin verifier for Blue Client.

Why this exists
---------------
A mixin whose target class or method name is wrong compiles perfectly and then
crashes the game at launch with a wall of Mixin apply errors. We cannot launch
the real client in this environment (Mojang asset download is blocked), so this
script does the next best thing: for every @Mixin in the source tree it checks
that

  1. the target CLASS exists in the remapped Minecraft jar, and
  2. every method named in method = {...} exists on that class
     (unless the injector is marked require = 0, which means "optional").

It is not a substitute for launching the game, but it catches the overwhelmingly
common mistakes: a renamed vanilla method, a typo'd target, or a mixin left
pointing at a class that no longer exists in this Minecraft version.

Run:  python3 verify_mixins.py
"""
import glob
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(ROOT, "work")
JAVAP = os.path.join(ROOT, ".tools/jdk21/bin/javap")

MC_JARS = glob.glob(os.path.expanduser(
    "~/.gradle/caches/fabric-loom/minecraftMaven/net/minecraft/"
    "minecraft-merged/*/minecraft-merged-*-v2.jar"))

_method_cache = {}


def methods_of(cls):
    """Every method + field name declared on a class, via javap."""
    if cls in _method_cache:
        return _method_cache[cls]
    names = set()
    for jar in MC_JARS:
        try:
            out = subprocess.run(
                [JAVAP, "-p", "-cp", jar, cls],
                capture_output=True, text=True, timeout=60).stdout
        except Exception:
            continue
        if not out.strip():
            continue
        for line in out.splitlines():
            m = re.search(r'([A-Za-z_$][\w$]*)\s*\(', line)
            if m:
                names.add(m.group(1))
            m = re.search(r'([A-Za-z_$][\w$]*);\s*$', line)
            if m:
                names.add(m.group(1))
        break
    _method_cache[cls] = names
    return names


def class_exists(cls):
    return bool(methods_of(cls))


def main():
    if not MC_JARS:
        print("!! Minecraft jar not found - run a build first")
        return 1

    src = os.path.join(WORK, "src/main/java")
    cfg = json.load(open(os.path.join(
        WORK, "src/main/resources/blueclient.mixins.json")))
    pkg = cfg["package"]

    problems = []
    checked = 0

    for path in glob.glob(os.path.join(src, "**/*.java"), recursive=True):
        text = open(path).read()
        # Strip comments first: prose that mentions a method name (e.g. a
        # write-up explaining why an old injection was removed) must not be
        # mistaken for a real injection target.
        text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
        text = re.sub(r'//[^\n]*', '', text)
        target_match = re.search(r'@Mixin\(\{?\s*([\w.]+)\.class', text)
        if not target_match:
            continue
        simple = target_match.group(1)
        checked += 1

        # resolve the simple name through the file's imports
        imp = re.search(r'import\s+((?:net|com|org|java)[\w.]*\.' + re.escape(simple) + r');', text)
        if not imp and "." in simple:
            # Nested target such as `Outer.Inner.class`: the import names the
            # OUTER class, and the runtime/javap name is Outer$Inner.
            outer, _, inner = simple.rpartition(".")
            outer_imp = re.search(
                r'import\s+((?:net|com|org|java)[\w.]*\.' + re.escape(outer) + r');', text)
            if outer_imp:
                class _Imp:
                    def __init__(self, value):
                        self._v = value

                    def group(self, _n):
                        return self._v

                imp = _Imp(outer_imp.group(1) + "$" + inner)
        if not imp:
            problems.append((path, f"cannot resolve import for {simple}"))
            continue
        target = imp.group(1)

        if not class_exists(target):
            problems.append((path, f"target class not found: {target}"))
            continue

        available = methods_of(target)
        for inj in re.finditer(
                r'@(Inject|ModifyVariable|ModifyArg|ModifyExpressionValue|'
                r'ModifyReturnValue|WrapOperation|Redirect)\('
                r'(.*?)\)\s*(?:private|public|protected)', text, re.S):
            body = inj.group(2)
            if re.search(r'require\s*=\s*0', body):
                continue                     # explicitly optional
            # ONLY read the method = {...} field. Naively scanning every
            # string literal also picks up @At("HEAD") and friends.
            mf = re.search(r'method\s*=\s*(\{[^}]*\}|"[^"]*")', body, re.S)
            if not mf:
                continue
            names = [n.split('(')[0]
                     for n in re.findall(r'"([^"]+)"', mf.group(1))]
            for name in names:
                if name and name not in available:
                    problems.append(
                        (path, f"{target}.{name}(...) not found on target"))

    print(f"checked {checked} mixin classes")
    if problems:
        print(f"\n{len(problems)} PROBLEM(S):")
        for path, msg in problems:
            print(f"  {os.path.relpath(path, WORK)}: {msg}")
        return 1
    print("all mixin targets resolve")
    return 0


if __name__ == "__main__":
    sys.exit(main())
