#!/usr/bin/env python3
"""
Post-build sanity check for the Blue Client jar.

WHY THIS EXISTS
---------------
Blue Client 0.24.0 shipped a jar that compiled perfectly and crashed the game
on startup:

    NoClassDefFoundError: org/jcodec/common/io/SeekableByteChannel

The JCodec nested jar WAS inside META-INF/jars/ (build.gradle copied it), but it
was NOT listed in fabric.mod.json's "jars" array. Fabric only loads nested jars
that are declared, so at runtime the classes simply were not on the classpath.

Compilation cannot catch this: at compile time JCodec is on the Gradle
classpath. Only a launch, or this script, catches it.

WHAT IT CHECKS
--------------
 1. fabric.mod.json parses, and its entrypoint / mixin config files exist.
 2. Every jar physically in META-INF/jars/ is DECLARED in "jars"  (the 0.24.0 bug)
 3. Every jar DECLARED in "jars" is physically present            (the mirror bug)
 4. Each nested jar has its own fabric.mod.json (Fabric refuses it otherwise).
 5. Every class referenced by our own classes resolves to: the JDK, Minecraft,
    Fabric, or a bundled nested jar. Anything else is a missing dependency and
    a future NoClassDefFoundError.
 6. Mixin config targets listed in blueclient.mixins.json exist in the jar.
 7. Every post_effect JSON's fragment shader exists in the jar.

Usage:  python3 verify_jar.py [path/to/blue-client-x.y.z.jar]
Exit code 0 = OK, 1 = problems found.
"""

import json
import re
import subprocess
import sys, glob
import zipfile
from pathlib import Path

def _newest_jar():
    """Newest built jar, so the verifier follows version bumps automatically."""
    jars = [j for j in glob.glob("/home/user/work/build/libs/*.jar")
            if not j.endswith(("-sources.jar", "-dev.jar"))]
    if not jars:
        return "/home/user/work/build/libs/blue-client.jar"
    return max(jars, key=lambda j: __import__("os").path.getmtime(j))


JAR = Path(sys.argv[1] if len(sys.argv) > 1
           else _newest_jar())
JAVAP = "/home/user/.tools/jdk21/bin/javap"
MC_JAR = next(Path("/home/user/.gradle/caches/fabric-loom").rglob(
    "minecraft-merged-*-v2.jar"), None)

problems = []
notes = []


def fail(msg):
    problems.append(msg)


def main():
    if not JAR.exists():
        print(f"jar not found: {JAR}")
        return 1

    zf = zipfile.ZipFile(JAR)
    names = set(zf.namelist())

    # ---------------------------------------------------------------- 1. fmj
    try:
        fmj = json.loads(zf.read("fabric.mod.json"))
    except Exception as e:
        print(f"fabric.mod.json is unreadable: {e}")
        return 1

    for cfg in fmj.get("mixins", []):
        cfg = cfg if isinstance(cfg, str) else cfg.get("config")
        if cfg and cfg not in names:
            fail(f"mixin config '{cfg}' declared but missing from the jar")

    # ------------------------------------------------- 2/3/4. nested jars
    present = {n for n in names if n.startswith("META-INF/jars/") and n.endswith(".jar")}
    declared = {j["file"] for j in fmj.get("jars", [])}

    for p in sorted(present - declared):
        fail(f"NESTED JAR NOT DECLARED: '{p}' is in the jar but missing from "
             f"fabric.mod.json \"jars\" -> Fabric will NOT load it -> "
             f"NoClassDefFoundError at runtime. This is the 0.24.0 crash.")
    for d in sorted(declared - present):
        fail(f"NESTED JAR MISSING: fabric.mod.json declares '{d}' but it is not "
             f"in the jar -> Fabric refuses to load the mod.")

    bundled_classes = set()
    for p in sorted(present):
        data = zf.read(p)
        tmp = Path("/tmp/_nested.jar")
        tmp.write_bytes(data)
        nz = zipfile.ZipFile(tmp)
        if "fabric.mod.json" not in nz.namelist():
            fail(f"nested jar '{p}' has no fabric.mod.json - Fabric will reject it")
        for n in nz.namelist():
            if n.endswith(".class"):
                bundled_classes.add(n[:-6])
        notes.append(f"nested jar OK: {p} ({len(nz.namelist())} entries)")

    # --------------------------------------------- 5. unresolved references
    own = {n[:-6] for n in names if n.endswith(".class")}
    mc_classes = set()
    if MC_JAR:
        mz = zipfile.ZipFile(MC_JAR)
        mc_classes = {n[:-6] for n in mz.namelist() if n.endswith(".class")}
    else:
        notes.append("WARNING: Minecraft jar not found, skipping MC resolution")

    # Roots that are supplied by the runtime (JDK / loader / Fabric API / MC libs).
    RUNTIME_PREFIXES = (
        "java/", "javax/", "jdk/", "sun/", "com/sun/",
        "net/minecraft/", "com/mojang/", "net/fabricmc/",
        "org/spongepowered/", "com/llamalad7/",
        "org/slf4j/", "org/apache/logging/", "org/apache/commons/",
        "org/lwjgl/", "org/joml/", "it/unimi/dsi/", "com/google/",
        "io/netty/", "org/jetbrains/", "org/objectweb/",
    )

    missing = {}
    for cls in sorted(own):
        if not cls.startswith("net/bluenetwork/"):
            continue
        try:
            out = subprocess.run(
                [JAVAP, "-p", "-c", "-cp", str(JAR), cls.replace("/", ".")],
                capture_output=True, text=True, timeout=60).stdout
        except Exception:
            continue
        for ref in set(re.findall(r'// (?:Method|Field|class|InterfaceMethod) ([\w/$]+)', out)):
            ref = ref.split("$")[0]
            if (ref in own or ref in bundled_classes or ref in mc_classes
                    or ref.startswith(RUNTIME_PREFIXES) or "/" not in ref):
                continue
            missing.setdefault(ref, []).append(cls)

    for ref, users in sorted(missing.items()):
        fail(f"UNRESOLVED CLASS '{ref}' referenced by {users[0]}"
             + (f" (+{len(users) - 1} more)" if len(users) > 1 else "")
             + " -> will throw NoClassDefFoundError when that code runs")

    # ------------------------------------------------- 6. mixin class files
    for cfg in fmj.get("mixins", []):
        cfg = cfg if isinstance(cfg, str) else cfg.get("config")
        if not cfg or cfg not in names:
            continue
        mj = json.loads(zf.read(cfg))
        pkg = mj.get("package", "").replace(".", "/")
        for key in ("mixins", "client", "server"):
            for m in mj.get(key, []):
                path = f"{pkg}/{m.replace('.', '/')}"
                if path not in own:
                    fail(f"mixin '{m}' listed in {cfg} but {path}.class is not in the jar")

    # ------------------------------------------------ 7. post-effect shaders
    for n in sorted(names):
        if "/post_effect/" in n and n.endswith(".json"):
            pipeline = json.loads(zf.read(n))
            for p in pipeline.get("passes", []):
                for key in ("fragment_shader", "vertex_shader"):
                    sid = p.get(key, "")
                    if ":" not in sid:
                        continue
                    ns, path = sid.split(":", 1)
                    if ns == "minecraft":
                        continue  # vanilla ships it
                    ext = ".fsh" if key == "fragment_shader" else ".vsh"
                    want = f"assets/{ns}/shaders/{path}{ext}"
                    if want not in names:
                        fail(f"{n} references shader '{sid}' but {want} is missing")

    # ------------------------------------------------------------- report
    print(f"jar:      {JAR}  ({JAR.stat().st_size:,} bytes)")
    print(f"classes:  {len(own)}   nested jars: {len(present)}")
    for n in notes:
        print(f"  - {n}")
    if problems:
        print(f"\n{len(problems)} PROBLEM(S):\n")
        for p in problems:
            print(f"  [X] {p}\n")
        return 1
    print("\nall checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
