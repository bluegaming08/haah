#!/bin/bash
#
# Cut a named release: ./release.sh v14 0.24.7
#
# Produces, in /home/user:
#   blue-client-v14-0.24.7.jar     <- the mod, drop this in .minecraft/mods
#   blue-client-v14.zip            <- jar + full source + all READMEs
#
# Every release keeps its OWN filename, so old downloads are never overwritten
# and you can always tell two builds apart.
set -e

REL="$1"
VER="$2"

if [ -z "$REL" ] || [ -z "$VER" ]; then
  echo "usage: ./release.sh <release-name> <semver>"
  echo "   eg: ./release.sh v14 0.24.7"
  echo
  echo "current:"
  grep -E '^(release_name|mod_version)=' /home/user/work/gradle.properties | sed 's/^/  /'
  exit 1
fi

# Fabric parses mod_version strictly; a non-semver value fails to load.
if ! echo "$VER" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+$'; then
  echo "ERROR: '$VER' is not valid semver (need N.N.N). Fabric would reject it."
  exit 1
fi

JDK=$(ls -d /home/user/.tools/jdk21 2>/dev/null | head -1)
GRADLE=$(ls /home/user/.tools/gradle-*/bin/gradle 2>/dev/null | head -1)
if [ ! -x "$JDK/bin/javac" ] || [ ! -x "$GRADLE" ]; then
  echo "TOOLCHAIN MISSING - see README-NEXT-AGENT.md section 1."
  exit 127
fi

cd /home/user/work
sed -i "s/^release_name=.*/release_name=$REL/" gradle.properties
sed -i "s/^mod_version=.*/mod_version=$VER/"   gradle.properties
echo ">> building $REL ($VER)"

rm -f build/libs/*.jar
JAVA_HOME="$JDK" "$GRADLE" build -x test --no-daemon --console=plain > /home/user/build.log 2>&1 || {
  grep -E "error:" -A3 /home/user/build.log | head -40; exit 1; }

JAR="build/libs/blue-client-$REL-$VER.jar"
[ -f "$JAR" ] || { echo "ERROR: expected $JAR, got:"; ls build/libs/; exit 1; }

echo ">> verifying"
python3 /home/user/verify_mixins.py | tail -2
python3 /home/user/verify_jar.py    | tail -3

echo ">> packaging"
OUT=/tmp/rel-$REL
rm -rf "$OUT"; mkdir -p "$OUT/blue-client-$REL/source"
cp "$JAR" "$OUT/blue-client-$REL/"
cp README-*.md "$OUT/blue-client-$REL/"
tar -c --exclude=build --exclude=.gradle --exclude=.git --exclude='*.log' . \
  | tar -x -C "$OUT/blue-client-$REL/source"

cd "$OUT"
rm -f "/home/user/blue-client-$REL.zip"
zip -qr "/home/user/blue-client-$REL.zip" "blue-client-$REL"
cp "/home/user/work/$JAR" /home/user/

echo
echo "DONE"
ls -la "/home/user/blue-client-$REL-$VER.jar" "/home/user/blue-client-$REL.zip"
