# The tab / nametag badge — how it works and how to back it with real storage

The Blue Client logo that appears next to a player's name in the **tab list**
and on **in-world nametags**.

**Right now it works with no backend**: you always see the badge on your own
name. To show it on *other* Blue Client users you need a presence service, which
is what this document specifies.

---

## 1. What ships today

| Piece | File | What it does |
|-------|------|--------------|
| Badge glyph | `assets/blueclient/font/blueclient_logo.png` (170×256) | A private-use character `U+E001` injected into the **default** font via `assets/minecraft/font/default.json`. Because it lives in the default font, any `Text` can contain it — no per-component font styling, which is what used to make badges silently vanish. |
| Side + toggles | `module/impl/BlueLogo.java` | `Nametags`, `Tab list` and `Logo on left` (default **left**). |
| Tab injection | `mixin/PlayerListHudMixin.java` | `@Inject` at `RETURN` of `getPlayerName`, wrapping the name with `BlueBrand.withIconLeft/withIcon`. |
| Nametag injection | `mixin/PlayerEntityRendererMixin.java` | Same idea against `PlayerEntityRenderState.displayName`. |
| Who is a Blue user | `presence/PresenceManager.java` | `isBlueClientUser(UUID)`. |

### The no-backend rule

```java
// PresenceManager.isBlueClientUser
if (uuid.equals(mc.player.getUuid())) return true;   // always yourself
return this.blueUsers.contains(uuid);                // empty with no backend
```

So with no service reachable: **you see your own badge, nobody else's.** That is
the intended fallback, not a failure state. Nothing logs errors at the player.

### Resolution note (v0.24.2)

The glyph used to be an **8×8** PNG, which is why it looked like a blue smudge.
It is now **170×256**, matching the source logo's 532:800 aspect. Minecraft
scales a bitmap provider down to the `height` in the font JSON (9 px), so the
oversized source is what gives you clean edges at GUI scale 3 and on 4K.
**Do not "optimise" this back down to 8×8.**

---

## 2. What a backend has to do

Two endpoints. Heartbeat says "I am here, I run Blue Client"; query asks "who
else on this server does?"

### `POST /bluePresenceHeartbeat`

```jsonc
// request
{ "uuid": "069a79f4-44e9-4726-a5be-fca90e38aaf5",
  "username": "Notch",
  "server": "play.sennahosting.com",
  "version": "0.24.2" }     // optional, useful for adoption stats

// response
{ "ok": true }
```

Store with a **TTL of about 90 seconds**. The client heartbeats roughly every
30 s (`PresenceManager`), so three missed beats means they quit.

### `POST /bluePresenceQuery`

```jsonc
// request
{ "server": "play.sennahosting.com" }

// response
{ "users": [ { "uuid": "069a79f4-..." }, { "uuid": "61699b2e-..." } ] }
```

Return **only UUIDs of players currently online on that server**. The client
turns this into a `Set<UUID>` and checks membership per rendered name.

### Suggested storage

Redis is the natural fit — the TTL is the whole data model:

```
SETEX blue:presence:<server>:<uuid>  90  "<username>"
# query:
SCAN/KEYS blue:presence:<server>:*      -> extract the uuid part
```

Any KV store with expiry works. A SQL table needs a `last_seen` column plus
`WHERE last_seen > now() - interval '90 seconds'` and a cleanup job.

---

## 3. Wiring it up

`PresenceManager` currently hardcodes:

```java
"https://solene-2ebf28bd.base44.app/functions/bluePresenceHeartbeat"
"https://solene-2ebf28bd.base44.app/functions/bluePresenceQuery"
```

Move these to `ClientSettings` (e.g. `presenceBaseUrl`) so the endpoint can
change without a rebuild, then:

```java
String base = BlueClient.getInstance().settings().presenceBaseUrl();
if (base == null || base.isBlank()) return;   // no backend -> self-only
```

---

## 4. Rules the backend must respect

1. **Never block the render thread.** All presence I/O is already on a worker
   with a 4-second timeout. Keep it that way.
2. **Fail silently.** `post()` sets a `rejected` latch on 401/403 and stops
   retrying. A dead backend must never spam chat or the log.
3. **Do not trust the client.** A heartbeat only proves someone *sent* a
   heartbeat. If the badge ever grants rewards, verify server-side — see
   `README-PLUGIN.md`, where the Blue Network plugin does exactly that for 2×
   shards.
4. **Privacy.** You are storing "player X is on server Y right now". Keep the
   TTL short, do not log history, and do not expose the endpoint publicly
   without rate limiting.

---

## 5. Better: let the server confirm it

Polling an external API is the weak link — it needs a public endpoint and it
lags. The robust design is a **Fabric custom payload** (plugin channel):

```
blueclient:hello   C->S   client announces itself on join
blueclient:users   S->C   server broadcasts the set of Blue users
```

The server then *knows* who runs the client (the channel is only registered by
clients that have it), no external storage is needed, and the badge is instant
and authoritative. `README-PLUGIN.md` already specifies this channel for the
shard multiplier — reuse it and have the plugin push the user set down the same
connection. If you do this, `PresenceManager` becomes a thin cache of whatever
the server last sent.

---

## 6. For the next AI

- Don't add a second badge code path. Everything routes through
  `BlueBrand.withIcon` / `withIconLeft` and `BlueLogo.logoOnLeft()`.
- The side is owned by **`BlueLogo`**, not `Nametags`. `Nametags.logoOnLeft()`
  is a `@Deprecated` delegate kept so old call sites compile.
- If the badge disappears entirely, check `assets/minecraft/font/default.json`
  first — a resource pack that overrides the default font will drop the
  provider, and the glyph then renders as a missing-character box.
