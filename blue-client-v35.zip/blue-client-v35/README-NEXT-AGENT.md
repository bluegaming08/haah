# Blue Client — handover for the next AI (current release: **v13** / `0.24.6`)

Read this file **before touching anything**. It explains how to build, what the
owner's standing rules are, what v12 changed, and — most usefully — the traps
that cost the previous agent hours.

---

## 0. The owner's standing rules

These are not suggestions. They were stated explicitly and still apply.

| Rule | Detail |
|---|---|
| **Do not touch the music player** | The only permitted change was adding Loop, which is done. Do not refactor `music/MusicEngine.java`, the decoders, or `module/impl/MusicPlayer.java` beyond that. |
| **Research before you code** | "Search/read documentation and learn before implementing anything — do not vibe code." Every feature in v12 was preceded by reading the actual decompiled Minecraft class. Do the same. |
| **Write for humans and for the next AI** | Long explanatory comments are wanted, especially on *why*, not *what*. |
| **Nothing anticheat-flaggable** | `AutoRespawn` was deleted for this reason. Do not add reach extension, auto-clickers, kill aura, ESP, etc. |
| **Black is the default theme** | Not Glass, not White. |
| **Use real Minecraft APIs** | The pause-menu button must be a real `ButtonWidget`, "not something blah blah". |
| **The plugin links with DonutCore, never overrides it** | DonutCore owns shards. |

---

## 0b. Release naming — READ BEFORE SHIPPING

Every delivered build gets its **own release name** (`v12`, `v13`, `v14`, ...).
The owner asked for this explicitly: *"name every version like v12, v13 etc not
a single name for everything"*. Shipping two different builds as
`blue-client-v12.zip` makes them impossible to tell apart.

**There are two version numbers and they are NOT interchangeable:**

| Property | Example | Purpose |
|---|---|---|
| `release_name` | `v13` | Owner-facing. Drives the **jar and zip filenames**. |
| `mod_version` | `0.24.6` | **Must be strict semver** — Fabric parses it. |

Artifacts come out as `blue-client-v13-0.24.6.jar` / `blue-client-v13.zip`,
while `fabric.mod.json` still reports a clean `0.24.6`.

**Do not fold the release name into `project.version`.** It is expanded into
`fabric.mod.json`'s `"version"`, and `v13-0.24.6` is not valid semver — the mod
would fail to load. The release name is applied to `archivesName` (the
filename) only, and exposed separately as the `blueclient:release` custom
value, which `BlueClient.RELEASE_NAME` reads at runtime.

Use `BlueClient.displayVersion()` (→ `"v13 (0.24.6)"`) for anything shown to
the user; `MOD_VERSION` alone is the bare semver.

### Cutting a release

```bash
./release.sh v14 0.24.7
```

That bumps both properties, builds, runs `verify_mixins.py` + `verify_jar.py`,
and writes `blue-client-v14-0.24.7.jar` + `blue-client-v14.zip` to
`/home/user`. It refuses a non-semver version and reports a missing toolchain
instead of failing cryptically. **Bump the release name on every delivery** so
old downloads are never overwritten.

---

## 1. Build

```bash
cd /home/user/work
JAVA_HOME=$JDK $GRADLE build -x test --no-daemon --console=plain
# artifact: build/libs/blue-client-<mod_version>.jar
```

Or use the helper: `./cc.sh` (fast `compileJava`, ~12 s) / `./cc.sh jar` (full build).

### FIRST: check the toolchain still exists

**The JDK and Gradle live OUTSIDE the snapshot and are deleted between
sessions.** `/home/user/.tools/` vanished once already mid-project. Nothing
below works until you re-provision, so start every session with:

```bash
JDK=$(ls -d /home/user/.tools/jdk21 2>/dev/null)
GRADLE=$(ls /home/user/.tools/gradle-*/bin/gradle 2>/dev/null | head -1)
[ -x "$JDK/bin/javac" ] && [ -x "$GRADLE" ] && echo "toolchain OK" || echo "RE-PROVISION NEEDED"
```

If it reports `RE-PROVISION NEEDED`, reinstall a **JDK 21** and **Gradle 9.5.0**
before doing anything else.

> **Install them OUTSIDE `/home/user`, then symlink in.** This is what caused
> both wipes. The snapshot only excludes *specific directory names*
> (`.venv`, `node_modules`, `build`, `dist`, ...) — `.tools`, `~/.gradle` and
> `work/.gradle` are **not** on that list, so they counted toward the ~128 MB
> cap and silently truncated the snapshot. Current layout:
>
> ```bash
> sudo -n mkdir -p /opt/blue && sudo -n chown user:user /opt/blue
> # JDK + Gradle:        /opt/blue/tools        <- symlinked as ~/.tools
> # Gradle user home:    /opt/blue/gradle-home  <- symlinked as ~/.gradle
> # Loom project cache:  /opt/blue/loom-cache   <- symlinked as work/.gradle
> ```
>
> That took `/home/user` from **1.1 GB to 65 MB**. If you re-provision, keep
> this shape: install to `/opt/blue/...` and `ln -s` it into place. Verify with
> `du -sh /home/user` — **anything approaching 128 MB means the next snapshot
> will lose work.** The Gradle/Loom caches
(`work/.gradle`, `~/.gradle`) are also excluded from snapshots, so the first
build of a session re-downloads Minecraft and takes several minutes — that is
normal, and **you must not kill it** (see the remap warning below).

**What DOES survive:** `work/src`, the READMEs, `build.gradle`,
`gradle.properties`, `libs/`, and the delivered `blue-client-*.jar` /
`blue-client-v12.zip` in `/home/user`. The **git history does not** — `.git`
has been wiped before, so treat the working tree as the only source of truth
and re-init if you want commits.

### Hard environment facts — do not rediscover these

* **Loom 1.17.20 requires Gradle exactly 9.5.0.** Gradle 8.10.2 and 9.1.0
  *cannot resolve the plugin*. The download URL is
  `https://services.gradle.org/distributions/gradle-9.5.0-bin.zip`
  (`gradle-9.5-bin.zip` is a 404 — the version has three components).
* **The box has ~2 GB RAM. You need swap or the daemon is OOM-killed.**
  ```bash
  sudo -n /bin/mkdir -p /swap && sudo -n /bin/dd if=/dev/zero of=/swap/swapfile bs=1M count=6144 status=none
  sudo -n /bin/chmod 600 /swap/swapfile
  sudo -n /sbin/mkswap /swap/swapfile && sudo -n /sbin/swapon /swap/swapfile
  ```
  `mkswap`/`swapon` are **not on PATH** — call them via `/sbin/`. Lowering
  `-Xmx` does *not* fix the OOM; adding swap does.
* **PUT THE SWAPFILE OUTSIDE `/home/user` (use `/swap`).** This bit us badly:
  the swapfile was originally created at `/home/user/swapfile`, which made the
  workspace 6.1 GB. Turn-end snapshots are capped around 128 MB, so the
  snapshot silently truncated and **the entire `work/src` tree was wiped
  between turns**, taking a session's worth of edits with it. Keep
  `/home/user` small (it is ~32 MB now). Anything large — swap, caches,
  downloads — belongs outside it.
* **Never kill a build mid-remap.** It leaves
  `~/.gradle/caches/fabric-loom` locked with `ACQUIRED_PREVIOUS_OWNER_MISSING`
  and forces a full Minecraft re-download.
* Versions: MC `1.21.11`, yarn `1.21.11+build.6`, loader `0.19.3`,
  fabric-api `0.141.6+1.21.11`.

### Inspecting Minecraft internals

This is how every API question in v12 was answered. Do this instead of guessing:

```bash
# The merged jar moves between Loom versions - ALWAYS locate it, never hardcode.
# It has lived under BOTH ~/.gradle/caches/fabric-loom/... and work/.gradle/loom-cache/...
MCJ=$(find /home/user -name "minecraft-merged*-v2.jar" 2>/dev/null | head -1)
$JDK/bin/javap -p -cp "$MCJ" net.minecraft.client.util.Window        # signatures
$JDK/bin/javap -p -c -cp "$MCJ" net.minecraft.client.render.WorldRenderer  # bytecode
```

Reading the **bytecode** is what found the Block Overlay bug (see §4).

### Verify the BUILT JAR — run this before every delivery

```bash
python3 /home/user/verify_jar.py          # ~2 min, checks build/libs/*.jar
```

**This exists because 0.24.0 shipped a jar that compiled perfectly and crashed
the game on startup.** `NoClassDefFoundError: org/jcodec/common/io/SeekableByteChannel`
— the JCodec nested jar was copied into `META-INF/jars/` by `build.gradle`, but
it was never listed in `fabric.mod.json`'s `"jars"` array, and **Fabric only
loads nested jars that are declared there.** Compilation cannot catch it
(JCodec is on the Gradle classpath at compile time); only a launch or this
script can.

It checks: declared-vs-present nested jars (both directions), that each nested
jar has its own `fabric.mod.json`, that every class our bytecode references
resolves to the JDK / Minecraft / Fabric / a bundled jar, that every mixin
listed in the config exists, and that every post-effect JSON's shader file is
present.

> **If you add a bundled library, you must edit TWO places:** the `jar` task in
> `build.gradle` *and* the `"jars"` array in `fabric.mod.json`. Forgetting the
> second one is invisible until the game launches.

### Verify mixins without launching the game

`runClient` does not work here (Mojang asset download is blocked). Instead:

```bash
python3 /home/user/verify_mixins.py
```

It checks every `@Mixin` target class and every non-optional `method = {...}`
against the real Minecraft jar. **This is how the broken pause-menu button was
found** — `Screen.mouseClicked` does not exist on `Screen` (it is a default
method on the `Element` interface), so that injection had been silently failing
at launch. Run it after every mixin change.

---

## 1b. Crash-proofing rules (learned the hard way)

* **A throwing module constructor kills the whole game.** Registration runs
  inside the Fabric client entrypoint; anything escaping it produces
  "Could not execute entrypoint stage 'client'" and the user loses everything,
  not just the broken feature. `ModuleManager.register` now guards each module,
  and `ModuleManager.safely(name, Foo::new)` guards *construction* (needed
  because `register(new Foo())` evaluates the constructor before `register` is
  even entered).
* **Catch `Throwable`, not `Exception`.** `NoClassDefFoundError` is an `Error`.
  A `catch (Exception)` would not have saved the 0.24.0 launch.
* **Never touch an optional bundled library from a field initialiser.** The JVM
  verifier resolves it when the class links, which is long before any user
  enables the feature. `ScreenRecorder` now creates its encoder lazily on the
  first recording attempt.

## 2. Critical Mixin rules for this codebase

| Rule | Why |
|---|---|
| **Plain `@Redirect` is FORBIDDEN** | MixinExtras 0.5.4 throws a `ClassCastException`. Use `@ModifyExpressionValue` or `@Inject`. |
| **`@ModifyVariable`'s `at` must be a scalar** `@At(...)`, never `{@At(...)}` | The array form gives "annotation value not of an allowable type". `@Inject` accepts both. |
| **Every mixin member must be `private`** | Share state through a helper class instead — e.g. `module/impl/WeatherRenderHook`. |
| **Check the method actually exists on the target class** | Inherited/default interface methods are *not* valid targets. Run `verify_mixins.py`. |

---

## 3. Architecture quick reference

### Theme system (v12, new)
```
ui/theme/ThemeStyle.java    enum BLACK (default) / GLASS / WHITE, migrates old names
ui/theme/ThemePalette.java  immutable ARGB record; ALL colours live here
ui/theme/DesignTokens.java  semantic read-through (panelBg(), textHi(), scrim(), ...)
ui/theme/UiTheme.java       DEPRECATED legacy enum, kept only so old screens compile
config/ThemeManager.java    palette() / style() / apply() / cycle()
```
Call `ThemeManager.palette()` **per frame**, never cache it.

The owner's button preset is in `ThemePalette`:
`BUTTON_RADIUS=2`, `BUTTON_BASE=0xFF0B0E14`, `BUTTON_TEXT=0xFFFFFFFF`, border alpha 0.
Draw buttons only via `ui/widget/PremiumButton.java` so it cannot drift.

### Module pattern
```java
public class Thing extends Module {
   private final BooleanSetting foo = new BooleanSetting("Foo", "desc", true);
   public Thing() {
      super("Thing", "description", Category.RENDER);
      this.addSettings(new Setting[]{ this.foo });
   }
   @Override public void onTick() { }
}
```
* `Category` is only `HUD, COMBAT, MOVEMENT, RENDER, MISC` — **there is no `UTILITY`**.
* `NumberSetting extends Setting<Double>` ⇒ use `.getInt()` / `.getFloat()`, never cast `.get()`.
* `NotificationManager` has only `add(String title, int accent)` and
  `addModuleToggle(String, boolean)` — there is no 3-arg overload.
* Register in `module/ModuleManager.java`; look up with
  `BlueClient.getInstance().moduleManager().byName("Thing")`.

### Adding a module? Give it a unique icon.
`ui/screen/ModuleMenuScreen.MODULE_ICONS` maps **every** module name to a
distinct sprite (105 modules, 105 unique icons — the owner asked for no
repeats). Add a line there with an unused sprite. New sprites: add the Lucide
path to `/home/user/make_icons.py` and re-run it.

---

## 4. What v12 changed

### Bugs fixed (with root causes)

* **Pause-menu "Blue Client" button** — v11 painted two *fake* squares and
  hit-tested them in `@Inject(method="mouseClicked")` on `Screen`. `Screen`
  does not declare `mouseClicked`, so the injection never applied. Replaced
  with a real `ButtonWidget` added via `addDrawableChild` in
  `mixin/GameMenuScreenMixin.java`; Minecraft now owns hit-testing, hover,
  focus and narration. Opens `QuickMenuScreen` (the right-shift menu).
* **Block Overlay** — three bugs, found by reading vanilla's `drawBlockOutline`
  bytecode. (1) The last parameter of `VertexRendering.drawOutline` is **line
  width, not alpha**; v11 passed `argb & 0xFFFFFF` (alpha stripped to 0 =
  invisible) plus a fractional "alpha" as the width. (2) The third parameter of
  `renderTargetBlockOutline` is `isTranslucent` (a render-pass flag), not "has
  block" — v11 read it as the latter, so the overlay drew in the wrong pass.
  (3) It used the live `mc.crosshairTarget` instead of the frame's
  `outlineRenderState`, so it lagged a frame on fast turns.
* **Capes** — the correct 1.21.11 path is render-state based:
  `PlayerEntityRenderer.updateRenderState` TAIL → build a
  `SkinTextures.SkinOverride` from `AssetInfo.TextureAssetInfo(cape.textureId())`
  and set `state.capeVisible = true`. Setting `skinTextures` + `capeVisible` is
  sufficient; `CapeFeatureRenderer` bails on `invisible || !capeVisible` and
  then on a null cape.
* **The capes were not the owner's art** — the three supplied images were plain
  artwork (and one was a phone screenshot with UI bars baked in), not 64×32 cape
  atlases. `/home/user/make_capes.py` converts them properly. See §5.
* **HUD default appearance** — now the owner's preset (border opacity 0, bg
  `#0B0E14`, bg opacity 100, radius 2, text `#FFFFFF`), defined once as
  constants at the top of `module/HudModule.java`.

### Features added

| Feature | Where |
|---|---|
| 3 themes (Black default / Glass / White) | `ui/theme/*` |
| Revamped custom pause menu | `gui/PauseMenuScreen.java` |
| Time Changer, Weather Changer (work under a roof) | `module/impl/{TimeChanger,WeatherChanger}.java`, `mixin/WeatherRenderingMixin.java` |
| Screen Recorder (JCodec, keybind, HUD timer + size) | `module/impl/ScreenRecorder.java`, `recorder/{VideoRecorder,AudioRecorder}.java`, `mixin/RecorderHookMixin.java` |
| Motion blur (accumulation style) | `module/impl/MotionBlur.java`, `mixin/GameRendererMotionBlurMixin.java`, `assets/blueclient/{post_effect/motion_blur_*.json,shaders/post/motion_blur.fsh}` |
| Crisp GUI (fractional GUI scale) | `mixin/WindowScaleMixin.java` |
| Blue logo as the OS window icon | `mixin/WindowIconMixin.java` |
| Share codes (`BLUE1-...`) Save/Load | `config/ProfileCode.java` + buttons in `ModuleMenuScreen` |
| HUD editor: remove-HUD, name labels, scroll-to-scale | `ui/screen/HudEditScreen.java`, scaling applied in `hud/HudManager.java` |
| Pre-render chunks: module → **setting** | `optimization/ChunkPreloader.java` + `ClientSettings.chunkPreloadEnabled()` |
| Music Loop (the only music change) | `module/impl/MusicPlayer.java` |
| "Reach" renamed → **"Reach Display"** | `module/impl/ReachHud.java` |
| Cosmetics menu + 7 previously-dead v0230 modules registered | `ModuleManager.java` |

`AutoRespawn` was **deleted** (anticheat-flaggable, per the owner).

---

## 5. Capes

**Do not hand-edit the PNGs in `textures/capes/`.** Source art lives in
`/home/user/assets_in/capes/`; run `/home/user/make_capes.py` to regenerate.

The 64×32 atlas layout (× `S` for a hi-res sheet; Blue Client uses `S=10`):

```
(1,1)  10x16  cape FRONT   <- the visible side
(11,1) 10x16  cape BACK
(0,1)   1x16  left edge     (1,0)  10x1  top edge
(21,1)  1x16  right edge    (11,0) 10x1  bottom edge
(22,0) 42x32  elytra region
```

Two fit modes, and choosing wrong is visible immediately:
* `cover` — scale to fill, centre-crop. For **photos**.
* `contain` — fit the whole image, pad with the art's own border colour. For
  **designs/logos**; cover-cropping chopped the "B" and "BLUE" capes on the
  first attempt.

The letterbox stripper must stay **off** for the design capes — their artwork
has a near-black gradient top and bottom that the bar detector happily ate,
truncating "BLUE" to "B L".

Register a cape in `cosmetics/CapeRegistry.java` (one line).

---

## 6. Outstanding / not yet done

Be honest with the owner about these:

* **The sandbox cannot launch the game** (`runClient` fails — Mojang's asset
  server is unreachable), so verification is: compile + `verify_mixins.py` +
  `verify_jar.py`. The owner launches the real client.
  * **0.24.0 first launch crashed** on the undeclared JCodec nested jar. Fixed,
    and `verify_jar.py` now catches that entire class of bug.
  * Still unverified on real hardware: the motion-blur GPU path, the screen
    recorder end-to-end, the window icon, and Crisp GUI. The user's machine is
    an Intel HD 615 with Sodium + Iris installed — **motion blur is the most
    likely next problem**, since Iris takes over the post-processing pipeline.
    If it misbehaves, turn the module off; it fails soft (the mixin latches a
    flag on the first error and never retries).
* **Still to port from v0230** (present there, absent here):
  `mixin/{BuiltChunkTaskAccessor,ChunkRenderTaskSchedulerMixin}.java`,
  `module/impl/{CustomChat,DarkMode}.java`, `music/{Id3Tags,SongImporter}.java`,
  `BlueClientGameTest.java`, assets `thumbs/` and `gametest-tone.m4a`.
* **The two extra READMEs** the owner asked for are written:
  `README-LAUNCHER.md` (launcher integration + feature plan) and
  `README-PLUGIN.md` (Blue Network / DonutCore 2× shards plugin spec).
* ~~The `blueclient:hello` channel is specified but not implemented.~~
  **DONE in 0.24.3** — `net/BlueHelloPacket.java`, wired into
  `BlueClient.onInitializeClient()` (register) and the client tick (send
  delay). See §8 of `README-PLUGIN.md`. The **server plugin itself is still
  unwritten**; the client no-ops until it exists.
* **System-audio capture is not possible in pure Java.** `AudioRecorder`
  records the microphone, and system audio only if the OS exposes a loopback
  input device. The real fix is a launcher-supplied FFmpeg binary — see
  §2 tier 3 item 15 of `README-LAUNCHER.md`.
* **The workspace has been wiped twice.** Know the difference:
  1. **Sources wiped (once, early).** Cause: a 6 GB swapfile inside
     `/home/user` blew the ~128 MB snapshot cap. `work/src` was rebuilt from
     `src_v11/source`. Keep swap at `/swap`, never under `/home/user`.
  2. **Toolchain wiped (again, after 0.24.3 shipped).** `/home/user/.tools`
     (JDK + Gradle), `work/.git`, and all Gradle caches are **excluded from
     snapshots by design** and disappear between sessions. The *sources and
     the delivered jar/zip survived untouched.* Recovery is just
     re-provisioning — see "FIRST: check the toolchain still exists" in §1.
     Re-provisioning costs ~4 min: JDK 21 tarball, Gradle 9.5.0 zip, 6 GB
     swapfile at `/swap`, then the first build re-downloads Minecraft (~80 s).
  `./cc.sh` now detects a missing toolchain and says so instead of failing
  with a confusing "No such file or directory".

---

## 7. File map

```
work/src/main/java/net/bluenetwork/client/
├── BlueClient.java              entry point; managers + per-tick wiring
├── cosmetics/                   capes + Blue Stars (CapeRegistry, CosmeticsManager)
├── config/
│   ├── ProfileCode.java         BLUE1- share codes (save/load)
│   └── ThemeManager.java        live theme state
├── gui/                         PauseMenuScreen, QuickMenuScreen, settings screens
├── hud/HudManager.java          per-frame HUD render + scaling + recorder tap
├── mixin/                       33 client mixins (see blueclient.mixins.json)
├── module/
│   ├── HudModule.java           anchors, sizing, DEFAULT_* appearance preset
│   ├── ModuleManager.java       the registry — add new modules here
│   └── impl/                    ~100 modules
├── optimization/ChunkPreloader.java   pre-render chunks (setting, not module)
├── recorder/                    VideoRecorder (JCodec H.264), AudioRecorder (mic/loopback WAV)
├── render/                      RenderUtil, SmoothRect, MotionBlurEffect
└── ui/
    ├── screen/                  ModuleMenuScreen, HudEditScreen, CosmeticsScreen
    ├── theme/                   ThemeStyle, ThemePalette, DesignTokens
    └── widget/PremiumButton.java
```

Helper scripts at `/home/user/`: `cc.sh` (build), `verify_mixins.py`,
`make_icons.py`, `make_capes.py`.

## v0.24.1 — owner feedback round 2

Everything here came from a single list the owner sent after playing 0.24.0.

| # | Request | Where it landed |
|---|---------|-----------------|
| 1 | Lyrics player (find lyrics online) | `module/impl/MusicPlayer.java` — `LyricsProvider` (LRCLIB) existed but **`fetchLyrics()` was never called**. `playSongFile()` now calls `fetchLyricsForFile(name)`, which parses `Artist - Title.ext`. "Show Lyrics" now defaults ON. |
| 2 | Paste a Spotify/YouTube link, download the mp4 | `MusicPlayer.downloadFromLink(link, play)` (worker thread) + a link field with a **GET** button at the bottom of `ui/screen/MusicScreen.java`. ENTER or GET starts it; CTRL+V / right-click pastes. |
| 3 | Glass theme must darken, not whiten | `ThemePalette` GLASS `panelBg` `0x1AFFFFFF` → `0x1A0B0E14`. |
| 4 | Dark mode 100% opaque | `DesignTokens.scrim()` BLACK → `0xFF070910`; `ModuleMenuScreen.cardFill()` is theme-aware. |
| 5 | White mode 100% opaque | `scrim()` WHITE → `0xFFF2F4F8`. |
| 6 | Button on the vanilla pause menu to reach the custom one | `GameMenuScreenMixin` adds a square `❐` `ButtonWidget` next to the Blue Client button. |
| 7 | Module settings too small | `ModuleSettingsScreen`: canvas 640→560, `ROW_H` 24→34, new `NAME_SIZE`/`VALUE_SIZE`/`LABEL_SIZE`/`CTRL_H`/`CTRL_Y` constants drive the whole screen. More scrolling, as the owner accepted. |
| 8 | HUD corner handles only on hover, draggable to scale | `HudEditScreen`: `proximity()` fades brackets in within `NEAR` (48 px); `drawCornerHandles()` paints 4 grab squares; dragging one scales around the opposite corner via `anchorDistance()`. |
| 9 | Exactly two code buttons | `ModuleMenuScreen`: the old plain SAVE (which only wrote config.json, something the client already does automatically) is gone. **SAVE** copies a `BLUE1-` code to the clipboard; **LOAD** opens an inline paste box (pre-filled from the clipboard) with a GO button. |
| 10 | Fix broken modules | 8 modules were written but never registered: Nametags, PotionEffects, BossBar, Animations, Horses, CustomF3, Screenshots, DiscordPresence. All now in `registerDefaults()`. |
| 11 | Third-person nametag | New `mixin/OwnNametagMixin.java` — see the "own nametag" section. |
| 12 | Smooth scroll wheel + a setting for the old snapping | `ClientSettings.snapScrolling` (**default false = smooth**), exposed as *Settings → General → Snap Scrolling*. `ModuleMenuScreen` branches on it: smooth mode clips at the panel edge and allows partial rows; snap mode is the old row-grid behaviour. |
| 13 | Strip session/hud/cosmetics/waypoints/accounts from the custom pause menu | `gui/PauseMenuScreen.java` — those panels and their helper methods are deleted. |

### If you change scrolling again
Smooth scrolling relies on `smoothScroll` easing toward `targetScroll` in `render()`. Do **not** round `targetScroll` unless `settings().snapScrolling()` is true — that is exactly the behaviour the owner asked to make optional.

## v0.24.2 — owner feedback round 3

| Request | Where it landed |
|---------|-----------------|
| Lyrics: words-per-segment setting | `MusicPlayer.wordsPerSegment` (0–12, **0 = whole line**). Splits the LRCLIB line into N-word chunks and steps through them across the line's own time slice. The pop/fade animation restarts per *segment*, not per line. |
| Lyrics: show next lyric | `MusicPlayer.showNextLyric` (default on). With segmenting active "next" means the next **segment** until the line runs out, then the next line. |
| Lyrics: MiniMessage-style shadow | `MusicPlayer.lyricShadow` (default on) → `drawLyricText()`. MiniMessage/vanilla shadows are a solid black copy offset +1/+1 at ~25–45% alpha, **not a blur**; the shadow alpha tracks the text's own fade. |
| Blue logo in tab, left of the name | `PlayerListHudMixin` now honours `BlueLogo.logoOnLeft()`. |
| Logo side moved to the right module | The side lived on **Nametags**, so tab could not read it and disabling Nametags flipped it back to the right. It is now `BlueLogo.logoLeft` (default left); `Nametags.logoOnLeft()` is a `@Deprecated` delegate. |
| High-res logo | The badge glyph was **8×8** — that is why it looked like a smudge. Rebuilt at **170×256** from the supplied 532×800 source, plus `brand/logo.png` 512², `textures/logo.png` 532×800, `icon.png` 128². Font JSONs render it at `height: 9`. **Do not shrink the source back down.** |
| Badge for other users + backend | `README-BADGE-BACKEND.md` — heartbeat/query contract, Redis TTL model, and the recommended custom-payload alternative. Self-only with no backend, which already worked. |
| Nametag logo on left, toggleable | Same `BlueLogo.logoLeft` toggle; nametags and tab can no longer disagree. |
| Light mode text colour in modules menu | `menuTextColor()`/`menuIconColor()` fell back to `MenuCustomizer.DEFAULT_*_COLOR` = hardcoded **white**, so WHITE theme drew white-on-white. They now fall back to `DesignTokens.textHi()`, while an explicitly customised colour still wins (`MenuCustomizer.textColorCustomised()`). The OPTIONS bar's hardcoded dark fill is theme-aware too. |
| Microsoft login | See **`README-MICROSOFT-LOGIN.md`**. Not fixable in code alone: the bundled client id is a placeholder and Mojang gates `login_with_xbox` behind app approval. What *was* fixed: a rejected id used to NPE on the missing `user_code` and show a blank notice; every response is now validated and HTTP status is preserved, so a 403 reports "app is not approved" by name. |
| Main menu revamp | `MainMenuScreen.menuButton()` now renders through the shared `PremiumButton` — the title screen was the one place ignoring the owner's mandated button preset and the theme system. Adds an accent bar that grows from the left on hover, centred icon+label, and theme-correct text on WHITE. Dock icons match. |
| Default background | Owner's Blue Network render, bundled at `assets/blueclient/textures/gui/menu_background.png` (1920×1080) as background **mode 0 = BLUE NETWORK**. Cover-cropped so it never stretches. The old particle gradient moved to **mode 5 = PARTICLES**. |

### Gotcha: the background already has a wordmark
The supplied artwork contains a large "BLUE NETWORK" logo in its upper half.
**As of v0.24.3 the client logo is ALWAYS drawn, centred above the buttons** —
the owner asked for it explicitly. `backgroundHasWordmark()` now only suppresses
the smaller "BLUE CLIENT" **wordmark**, and on that background the logo is drawn
smaller (`s(52)` vs `s(74)`) and lower so it sits in the empty middle band.
Do not re-add a skip for the logo itself.

### verify_jar.py
Now auto-selects the newest jar in `build/libs`, so it keeps working across
version bumps. Still run it before every delivery (~2 min).


---

## v0.24.3 — owner feedback round 4

| Request | Where it landed |
|---------|-----------------|
| Lyrics: default 3 words, drop the "0" option | `MusicPlayer.wordsPerSegment` is now `NumberSetting(..., 3.0, 1.0, 12.0, 1.0)`. There is no 0 any more; "whole line" is expressed by raising the slider past the line's word count. The `perSegment > 0` branches are gone and segmenting is unconditional. |
| Lyrics: fix the sync | **Root cause found.** The fade was a fixed 400 ms in + 400 ms out, but a 3-word segment only lasts ~600–800 ms — so alpha never reached 1.0 and every segment looked dim and late. Now `fadeMs = min(160, segDur * 0.18)` for both the fade and the pop, and the pop scale was softened `1.35 → 1.18`. **Rule: the animation length must always be a fraction of `segDur`.** |
| Main menu: centred logo above the buttons | `MainMenuScreen.render()` — see the wordmark note above. |
| Revamp the news panel | `MainMenuScreen.drawNetworkPanel()`, rewritten. It used to be a bare cropped banner: `NEWS_TITLE` / `NEWS_DESCRIPTION` were defined but **never drawn**. Now: banner strip with a gradient scrim under the text, headline + one-line summary, a pulsing `N ONLINE` chip from `NetworkStats`, and a `JOIN NOW` pill that reveals the address on hover. |
| Custom Blue Network join/connecting screen | `gui/BlueConnectOverlay.java` + `mixin/ConnectScreenMixin.java`. Branded backdrop, floating logo, the **live vanilla status text**, an indeterminate sweep bar, player count, and rotating tips. Only replaces the vanilla screen when the address passes `BlueBrand.isBlueNetwork` — every other server is untouched. |
| Revamp the account manager + bust renders | `gui/AccountsScreen.java`, rewritten as a **card grid**; `account/PlayerHeads.java` is the new async loader for `https://mc-api.io/render/BUST/<username>/JAVA?size=256`. Also used by the title-screen player card. |
| Multiplayer: drag to reorder servers | `util/ServerDrag.java` + `mixin/ServerEntryDragMixin.java` + `mixin/MultiplayerScreenAccessor.java`. |
| Fix the doubled third-person nametag badge | `PlayerEntityRendererMixin` — see below. |
| Fix the missing tab logo | `PlayerListHudMixin` — see below. |

### The doubled nametag badge: bridge methods (READ THIS)
`PlayerEntityRenderer.updateRenderState` has **three overloads** (the real one
plus synthetic bridges). `method = "updateRenderState"` with no descriptor binds
to **all of them**, so the badge was appended twice.

Fix: pin the full descriptor, on **one line** —

```java
@Inject(method = {"updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V"}, at = @At("TAIL"))
```

Do **not** split that string across lines with `+`: Java concatenation defeats
both Mixin's annotation parser and `verify_mixins.py`.

There is also a belt-and-braces idempotence guard — the injector returns early
if `state.displayName.getString().contains(BlueBrand.ICON_GLYPH)`. Keep it.
`OwnNametagMixin` was checked and is **safe**: it targets `EntityRenderer`,
which has a single overload.

### The missing tab logo: the gate, not the injection point
Verified with `javap -c` that `PlayerListHud` draws `ScoreDisplayEntry.name`,
which derives from `getPlayerName` — the injection point was always correct.
The **gate** was wrong: it asked `PresenceManager.isBlueClientUser(profile.id())`,
which is empty in singleplayer/with no backend, and proxies rewrite profile ids
so it missed even online. `PlayerListHudMixin` now has a
`@Unique blueclient$isBlueUser(PlayerListEntry)` that matches self by **UUID *or*
case-insensitive name** before falling back to the presence backend, and skips
entries whose name already contains the glyph.

### Drag-to-reorder: why it is not a `mouseDragged` mixin
**You cannot mixin `mouseDragged` / `mouseReleased` here.** Neither
`MultiplayerScreen` nor `MultiplayerServerListWidget` declares them — they are
inherited as `default` methods on the `Element` / `ParentElement` interfaces,
and Mixin refuses to inject into a method a target only inherits as a default.

So the drag rides on two methods `ServerEntry` **does** declare:

* `mouseClicked` → starts a drag when the press lands in the 10 px grip strip
  just **outside** the row's left edge (so it can never eat a click meant for
  the row, double-click-to-join, or the vanilla ▲/▼ buttons);
* `render` → runs per row per frame, so it publishes each row's screen band via
  `ServerDrag.trackRow` and polls the physical mouse button through
  `GLFW.glfwGetMouseButton` to detect the drop.

Row bands are **reported by the rows themselves**, not computed from scroll
offsets, which keeps it correct while scrolling and with LAN entries present.
`ServerList` only exposes `swapEntries(a, b)`, so the commit walks one slot at a
time — that preserves every other entry's order, which a remove+insert would not
— then calls `saveFile()` and re-`init()`s the screen.

### PlayerHeads: the pattern for any remote image
`account/PlayerHeads.java` is the reference implementation. Reuse it, do not
reinvent it:

* **never block the render thread** — `bust(name)` returns `null` on a miss and
  the next frame picks the texture up;
* **latch `requested` *before* starting the thread**, or a 60 fps screen fires
  60 identical HTTP requests per second;
* **cache failures too** (`failed` set), otherwise a bad username retries forever;
* decode off-thread with `NativeImage.read`, but **register the texture via
  `mc.execute`** — upload touches GL;
* `Identifier` paths only accept `[a-z0-9_.-/]`, so **sanitize usernames**.

Call `PlayerHeads.forget(name)` when an account is added or removed.

### verify_mixins.py now understands nested targets
`@Mixin(Outer.Inner.class)` used to report "cannot resolve import" because the
import names only the outer class. The verifier now falls back to
`Outer$Inner`. All **36** mixin classes resolve.


---

## v0.24.5 — owner feedback round 5

| Request | Root cause & fix |
|---------|------------------|
| Music drifts out of sync by 3-5 s after ~90 s | **Real bug in the AAC decoder path.** `MusicEngine.playM4a` called `decoder.getAudioFormat()` and opened the audio line with it **before decoding a single frame**. For HE-AAC / AAC+ (what most YouTube downloads are) SBR doubles the output rate, so the line could open at 22050 Hz while the decoder actually emitted 44100 Hz. `getMicrosecondPosition()` converts frames→time using the **line's** nominal rate, so the reported position drifted further from reality the longer the track ran — a slowly growing desync, exactly as described. The format is now taken from the **decoded `SampleBuffer`** (`getSampleRate`/`getChannels`/`getBitsPerSample`/`isBigEndian`), and the line is reopened if a stream changes rate mid-track. |
| …plus a manual nudge | LRCLIB timings are crowd-sourced and sometimes made against a different master. New `MusicPlayer.lyricOffset` (−5000..+5000 ms, step 50). **Positive = lyrics appear earlier.** |
| Draggable servers not working | **The grip was unreachable.** It was drawn *outside* the row's left edge, but `EntryListWidget` dispatches clicks through `getEntryAtPosition` → `Entry.isMouseOver`, which tests the row's own rect — a click outside the row never reaches `ServerEntry.mouseClicked`, so the drag could never start. The grip is now **inside** the row's left edge (vanilla's join/▲/▼ buttons are all on the right half, so there is no conflict). Also fixed: row bands now come from the entry's own `getY()`/`getHeight()` instead of `widget.getRowTop(index)` — `getRowTop` indexes the widget's children, which include the LAN header and LAN entries, so it did **not** line up with the ServerList index once a LAN server appeared. |
| LOAD popup opens off-screen | It was an inline strip at a hardcoded `bottomY + 84`, below the window edge on short displays. Replaced with a **centred modal** (`drawLoadModal`): dimmed backdrop, centred panel, **X close button**, paste field, and a full-width LOAD button. Drawn last in `render()` so nothing covers it. |
| Main-menu logo 40% bigger | `s(52) → s(73)` and `s(74) → s(104)`. `logoY` was raised to match so the logo still *ends* just above the buttons. Verified no overlap from 400×280 up to 1920×1080. |
| Music keeps playing after disabling the module | `MusicPlayer` had **no `onDisable()`**. Since `onTick()` only runs while a module is enabled, nothing could stop the audio thread — the only escape was the music screen's stop button. Added `onDisable()` → `MusicEngine.INSTANCE.stop()`, and it clears `wasPlaying` so re-enabling does not see a false "playing → stopped" edge and instantly re-loop. |

### Trap: modal coordinates vs. the panel transform
`ModuleMenuScreen` draws its panel inside a scale matrix and divides mouse
coords by `drawScale`. The LOAD modal is drawn **outside** that transform, so
its hitboxes are tested against **raw** `click.x()/y()`. If you add more
popups, follow the same split or the hitboxes will silently land in the wrong
place.

### Trap: `getRowTop(index)` is not your list index
`EntryListWidget.getRowTop(i)` indexes the **widget's children**, which for the
multiplayer screen includes the LAN-scan header and LAN entries. It is not the
`ServerList` index. Ask the entry for its own `getY()`/`getHeight()`.

### Also in this round
* Ported `music/Id3Tags.java` from v0230 **and fixed a fatal bug in it**: the
  frame-id validator accepted only `A-Z`, but every tag we care about contains
  a digit (`TIT2`, `TPE1`), so it bailed on the first frame and returned empty
  tags for **every** file. Now accepts `[A-Z0-9]`. Verified against generated
  ID3v2.2 / v2.3 / v2.4(UTF-8) / v1 fixtures — all four parse correctly.
* Lyrics now resolve **local `.lrc` sidecar → ID3 tags → filename**, and a
  successful online lookup is cached to a `.lrc` sidecar so a song is never
  looked up twice. Sidecar timestamps use standard `[mm:ss.xx]`; the v0230
  formatter emitted `[0:000.00]`, which our own parser tolerated but other
  players reject. Round-trip verified.


---

## v13 (`0.24.6`) — release naming

Renamed the delivery scheme at the owner's request: every build now ships as
`blue-client-<release>-<semver>.jar` inside `blue-client-<release>.zip`, so
`v12`, `v13`, `v14`... never overwrite each other. See **§0b** for the rules and
the `./release.sh` helper. No functional changes to the client itself; v13 is
v0.24.5's code under the new naming, with the release name surfaced in the
module menu, pause menu, quick menu and `/blueclient`.

**Release history**

| Release | semver | Highlights |
|---|---|---|
| v12 | 0.24.0–0.24.5 | Initial v12 delivery and rounds 1–5 of owner feedback (all shipped under one filename — the problem this change fixes). |
| v13 | 0.24.6 | Per-release naming + `release.sh`. |
| v14 | 0.24.7 | Reverted multiplayer drag; lyrics sync fix + disk cache; Tier Tagger (later removed); centred OPTIONS label. |
| v15 | 0.24.8 | Removed Tier Tagger; full centered-text audit (ellipsis budget, integer division, repeated ellipsis). |
| v16 | 0.24.9 | New Hitboxes + Item Physics modules; Totem Counter gains pops/opponent; Custom FOV → FOV Changer with dynamic FOV. |
| v19 | 0.25.2 | Friends system: accounts, requests, presence, blocking, privacy (Supabase + RLS) |
| v18 | 0.25.1 | Verifier catches silent mixin mis-binds (found a shipped nametag bug); perf snapshots; icons for all 106 modules; **Item Hold Display** (new) and **Crosshair+** (upgraded). |
| v17 | 0.25.0 | Lyric Mode (Full Line default) fixes desync at the display layer; AAC position-reset fix; recorder F9 default; removed two rival-client brand names. |

---

## v14 (`0.24.7`) — owner feedback round 6

Four requests. All four are done.

### 1. Multiplayer drag-to-reorder: REVERTED

The owner said "no need of them". Deleted outright:

* `util/ServerDrag.java`
* `mixin/ServerEntryDragMixin.java`
* `mixin/MultiplayerScreenAccessor.java`
* the two matching entries in `blueclient.mixins.json` (client list 31 → 29)

**Do not rebuild this.** It never worked, and the reasons are structural, not
bugs you can out-clever — see "Errors & dead ends": `EntryListWidget.Entry` is
protected, `EntryListWidget` has no `mouseClicked`, `getRowTop(index)` does not
line up with our rows because the LAN header is counted, and Mixin cannot inject
into the interface-default `mouseDragged`/`mouseReleased`.

`MultiplayerScreenMixin` was **kept** — that is the Blue Network server pin,
which predates the drag work and is unrelated.

### 2. Lyrics: fixed sync + real caching

Two separate defects were found; both are fixed.

**(a) The duration was never known — this was the root cause of the drift.**
`MusicEngine.setDurationMs()` existed but *nothing ever called it*, so
`durationMs()` was permanently `0`. `LyricsProvider.fetch` matches LRCLIB
candidates by duration, so with `0` every candidate scored identically and it
simply took **the first synced result**. LRCLIB has 19 entries for "catch me"
including both a **177 s** and a **303 s** master — load the wrong one and the
lyrics slide further behind the longer the song plays. Exactly the report.

Fixes:
* `MusicEngine` now publishes the real length: MP3 from `Header.total_ms()` on
  the first decoded frame (using the file size in `pendingStreamBytes`), M4A/AAC
  straight from `Movie.getDuration()`. Reset to `0` on every new track.
* `MusicPlayer.playSongFile` now starts playback **before** the lyrics lookup —
  the old order asked for lyrics while duration was still `0`. The lookup thread
  waits up to 2 s for the decoder to publish the length.

**(b) The matcher itself was too weak.** Rewritten (`LyricsProvider.fetch`):
duration within 2 s counts as exact, **beyond 12 s the candidate is rejected
outright** instead of merely penalised, title/artist similarity is now scored at
all, and synced still gets a strong bonus but can no longer drag in a track of
obviously wrong length. Verified against the real 19-result LRCLIB payload: a
177 s file picks the 177 s entry, a 303 s file picks the 303 s entry.

**Caching — `music/LyricsCache.java` (new).** The old code wrote a `.lrc`
sidecar next to the audio. That was replaced because it had three problems:
it was **poisoned** (every pre-0.24.7 build saved lyrics chosen *without* a
working duration match, and those files would be trusted forever — the bug would
look "fixed for new songs only"), it was indistinguishable from the user's own
hand-made `.lrc` files, and it failed on read-only/network folders.

Now: entries live in `config/blueclient/lyrics/`, keyed by
**title + artist + duration** (so the 177 s and 303 s masters cache separately
and can never collide), stamped with `CACHE_VERSION`, and expired after 90 days.
**Bump `CACHE_VERSION` whenever a bug could have written wrong lyrics to disk** —
old entries are then ignored and re-fetched automatically.

Lookup order is now: **user's own `.lrc` sidecar → disk cache → LRCLIB**. A
user-supplied sidecar still wins over everything and is never overwritten.

### 3. Tier Tagger — BUILT, THEN REMOVED

A Blue Tiers tier tagger was implemented in v14 and then **deleted in v15 at the
owner's request** ("no need of tier tagger"). Removed: `tiers/TierProvider`,
`tiers/TierRank`, `tiers/TierScraper`, `module/impl/TierTagger`, the bundled
`assets/blueclient/tiers/snapshot.json`, the `PlayerListHudMixin` tab hook, the
`PlayerEntityRendererMixin` nametag hook, the `ModuleManager` registration and
the module-menu icon mapping.

**Do not rebuild it unless asked.** If it is ever asked for again, the research
is worth knowing: `bluetiers.gamer.gd` has **no API**, its rankings are
hard-coded into a content-hashed JS bundle (`/assets/index-<hash>.js`), and the
site sits behind an InfinityFree AES-128-CBC bot challenge. The working approach
was: solve the challenge for a `__test` cookie, regex the current bundle hash out
of the SPA shell, then regex the player records out of the minified source — and
ship a bundled snapshot as the real source of truth, because the hash changes on
every redeploy. It is in git history if needed.

### 4. Uncentered module text

The `OPTIONS` label on every module card was drawn with a hard-coded `- 5`
nudge, added to stop it colliding with the gear icon at the right end of the
bar. That is what made it look off-centre.

It is now centred inside the space it can **actually** use — between the left
edge of the bar and the left edge of the gear — so the gaps are equal at any
card width (verified at 96/110/128 px: 17/17, 24/24, 33/33). A repo-wide grep
for the same `width/2 ± constant` pattern found no other instance.

---

## v15 (`0.24.8`) — owner feedback round 7

Two requests: remove the Tier Tagger, and fix *every* uncentered text anywhere.

### 1. Tier Tagger removed

See the v14 section above — all files, both mixin hooks, the registration, the
icon mapping and the bundled snapshot are gone. `blueclient.mixins.json` is
unchanged (the tier hooks lived inside existing mixin classes).

### 2. Uncentered text — full audit, four distinct bugs

The owner said the module menu text is "sometimes" uncentered. **"Sometimes" was
the clue**: the misalignment is *content-dependent*, so it could not be a plain
bad constant. I wrote a script that pulls apart every `drawPoppins` /
`drawText` call in the codebase and checks each centering expression, rather
than fixing the one label that got reported. Four separate bug classes turned up.

**(a) The real "sometimes" bug — the ellipsis was never measured.**
Five text-fitting helpers trimmed a string until *the bare text* fit, then
appended `"..."`:

```java
while (poppinsWidth(t, size) > maxWidth && t.length() > 2) { t = t.substring(0, t.length()-1); }
return t.equals(text) ? t : t + "...";   // <-- now ~8px WIDER than maxWidth
```

Centred labels are drawn at `x + w/2 - width/2`, so a string wider than its box
spills past **both** edges and reads as off-centre — but only when the text is
long enough to be truncated at all. Short names were always fine. Exactly
"sometimes".

Fixed in all five (`ModuleMenuScreen.fitTextPoppins` / `.fitText`,
`ModuleSettingsScreen.fit` / `.fitPoppins`, `MusicPlayer.fit`): the ellipsis
width is now part of the budget, so the result always fits. Measured on the
simulator, the old code overflowed by ~2.3–2.6 px on long labels; the new code
overflows by 0.

Three other helpers (`MusicScreen`, `WaypointsScreen`, `PremiumButton`) already
measured `t + "..."` correctly and were left alone.

**(b) Integer division.** `RenderUtil.textWidth()` returns `int` and
`RenderUtil.drawText()` takes `int x`, so `x - textWidth(s)/2` truncates and
odd-width strings sit half a pixel left. Fixed with float division +
`Math.round` in `ModuleMenuScreen:978` and `QuickMenuScreen:86`. Same bug with an
`int` container width in `WaypointsScreen` ("DEL" button, `Rect.w` is `int`).

**(c) The hard-coded nudge** (already fixed in v14): the `OPTIONS` label had a
`- 5` fudge to dodge the gear icon. It now centres in the space between the bar's
left edge and the gear's left edge, so gaps are equal at any card width.

**(d) Repeated ellipsis.** `CosmeticsScreen` appended `"…"` *inside* its trim
loop, so a long cape name could become `"Somethi………"` and still overflow. It now
builds the truncation once.

### Edge cases worth keeping

`fit*` returns the first character (not `"..."`) when the box is too narrow for
even an ellipsis — otherwise the "truncation" is wider than the original and
tells the user nothing. Verified against a width simulator covering empty
strings, single characters and 4 px boxes.

### If a label ever looks off-centre again

Check, in this order: is the string measured with the **same font and size** it
is drawn with; is the fitting helper measuring the ellipsis; is any width an
`int` being halved; and is the centre the **box actually drawn behind the text**
(the OPTIONS bug was centring on the bar while the gear ate the right end).

---

## v16 (`0.24.9`) — owner feedback round 8: four new/upgraded modules

The owner asked for a hitbox module, a totem counter, a FOV changer and item
physics, all configurable. **Two of the four already partly existed**, so rather
than ship duplicates that fight each other, those were upgraded (confirmed with
the owner first).

| Request | What happened | Why |
|---|---|---|
| Hitboxes | **New** module `module/impl/Hitboxes.java` | Nothing like it existed |
| Totem counter | **Upgraded** `hud/impl/TotemCounter.java` | A basic one already existed |
| FOV changer | **Upgraded** `module/impl/CustomFov.java` → renamed "FOV Changer" | `Custom FOV` already owned the FOV option |
| Item physics | **New** module `module/impl/ItemPhysics.java` | Nothing like it existed |

### 1. Hitboxes (RENDER, 8 settings)

Entity hitbox outlines. Vanilla can only do this via F3+B, which
shows every entity plus the eye-line and cannot be recoloured.

* **Players only** — on by default, as requested.
* **Dynamic colour** — the entity under your crosshair uses the hover colour,
  everything else the normal colour. Target detection uses
  `mc.targetedEntity` (the same raycast that decides what your attack hits),
  falling back to `crosshairTarget`.
* Plus line width, range, own-hitbox and see-through-walls.

Rendering is `render/HitboxRenderer.java`, called from a new `@Inject` at the
**TAIL of `WorldRenderer.renderTargetBlockOutline`**. That looks like an odd
host, but it is the one place in world rendering that already provides a
camera-relative `MatrixStack`, an `Immediate` vertex provider *and* the camera
position — exactly what `VertexRendering.drawOutline` needs. Guarded to the
opaque pass so boxes are emitted once per frame, not twice.

Boxes are drawn at the **interpolated** position, not `getBoundingBox()` alone:
that box is the last *tick*, so at high frame rates it visibly trails a
sprinting player.

> **Not anticheat-flaggable.** Purely visual — it draws the hitbox the client
> already has. It does not alter the box used for attacks, does not change
> reach, and sends nothing. (The "hitbox" *cheat* of the same name expands the
> attack box; this does not.)

### 2. Totem Counter (HUD, 8 settings) — upgraded

Now shows your totems **and pops**, plus your opponent's.

New tracking lives in `util/TotemTracker.java`:
* **Pops** come from `EntityStatusS2CPacket` **status 35** ("totem used"), the
  same signal that triggers the vanilla animation — observed in
  `TotemTrackerMixin`, nothing is sent.
* **Opponent** = whoever you last hit or who last hit you within 15 s
  (`TotemCombatMixin` on `attackEntity`), falling back to whoever is under your
  crosshair so the panel is still useful while lining someone up.
* Reset on disconnect (wired into `BlueHelloPacket`'s DISCONNECT handler), so
  counts never carry between servers.

> **Known limitation, deliberately surfaced in the UI.** For the opponent only
> totems **in their hands** can be counted — the server never tells your client
> what is in another player's inventory, so any "total" would be invented. The
> label reads `held ×N` for that reason. Their **pop count is exact**, because
> pops are broadcast to everyone.

### 3. FOV Changer (MISC, 7 settings) — upgraded from "Custom FOV"

Static pin **plus** smooth dynamic FOV: sprint boost, bow/crossbow/spyglass
zoom, elytra & creative-fly boost, and a transition-speed control.

The two halves work differently **on purpose**:
* the **base** FOV goes through `OptionGuard` (so Zoom still stacks and the
  original is restored on disable);
* the **dynamic** part can *not* — the vanilla FOV option is an `int`, and
  stepping it every frame produces visible 1-degree jumps. `GameRendererFovMixin`
  instead scales `GameRenderer.getFov`'s float return value, giving smooth
  sub-degree motion. Easing is frame-rate independent and the delta is clamped
  to 0.25 s so an alt-tab cannot teleport the view.

Aiming deliberately **overrides** sprint/fly widening — otherwise the zoom and
the sprint boost cancel out and a bow pull does nothing.

**Config migration:** modules are saved by display name, so the rename would
have silently reset everyone's FOV settings. `ConfigManager.renamedModule()` maps
`"Custom FOV"` → `"FOV Changer"`. **Add an entry there whenever a module is
renamed.**

### 4. Item Physics (RENDER, 8 settings)

Dropped items tip over and lie flat instead of hovering upright. Settle speed,
spin-in-air, bobbing, random resting angle, scale, ground offset and stack
layers are all configurable.

Implementation reads vanilla's `ItemEntityRenderer.render` from `javap -c`:
`push()` → `translate(0, bob, 0)` → `multiply(POSITIVE_Y.rotation(spin))` →
draw → `pop()`. Rather than cancel and reimplement (which would break other item
mods and silently drop future vanilla changes), three surgical hooks:
zero the bob at the `MathHelper.sin` call, freeze the spin at
`ItemEntity.getRotation`, and add the tipping rotation right after `push()`.

Per-item state (on-ground, time since landing, a stable seed) is attached to the
render state by **duck typing** — `ItemEntityRenderStateMixin` makes the vanilla
state implement `render/ItemPhysicsState`, filled in by `ItemPhysicsUpdateMixin`.
The alternative, a map keyed by entity id, would need manual eviction and leak
memory. The one small map that *is* needed (landing timestamps) drops entries
when an item leaves the ground and hard-clears past 4096 entries.

> **Rendering only** — position, hitbox and pickup are untouched, so items are
> still picked up exactly where vanilla says they are.

### The MixinExtras trap that cost a debugging cycle — READ THIS

`@ModifyExpressionValue` handlers may take *"the expression's resultant value,
optionally followed by the enclosing method's parameters"*. That is **all of the
target's parameters or none — a prefix subset does not bind.** The first version
of `ItemPhysicsMixin` captured only `(float original, ItemEntityRenderState)`
out of a four-parameter target. It **compiled fine and `verify_mixins.py`
passed**, because both only check that the target method exists. Combined with
`require = 0` the failure would have been completely silent: the module would
simply have done nothing in game, with no log line to explain it.

**Whenever you add a MixinExtras handler that captures target args, capture the
full parameter list**, and remember that `require = 0` converts a binding
mistake into a silent no-op rather than a crash.

---

## v17 (`0.25.0`) — owner feedback round 9

### 1. Lyrics: "still not working, its unsynced" — the actual root cause

Previous rounds fixed real bugs (duration matching, AAC sample-rate drift) and
the owner *still* reported desync. That is because the biggest cause was never
the timing at all — **it was the display mode.**

**The finding.** LRCLIB provides **line-level timestamps only**. Verified
directly against the API: all 19 "catch me" entries, zero contain word-level
`<mm:ss.xx>` enhanced timing. So the old "3 words at a time" mode had to
*invent* word times by dividing each line evenly. Real singing is not evenly
spaced. On the line `"Last week, been a whole year, but it feel like last week"`
(12 words in 4.05 s) you were shown a 3-word window while the vocal had already
moved on — and **no lyric offset can fix that**, because the error changes
*within* every line. That is exactly why it kept "still" being unsynced.

**The fix — new `Lyric Mode` setting:**

| Mode | Behaviour | Structural lag |
|---|---|---|
| **Full Line** (new default) | The whole line appears on its own timestamp | **0 ms** |
| **Karaoke** | Whole line visible, sung words brightened | **0 ms** |
| Word Window | The old few-words-at-a-time mode, kept for anyone who liked it | inherent |

Full Line shows exactly what LRCLIB actually guarantees, so it cannot drift.
Karaoke still highlights progressively, but because every word stays on screen a
slightly-off highlight is harmless rather than "the lyrics are behind".

**Also fixed — a genuine position bug.** `MusicEngine.positionMs()` returned
`line.getMicrosecondPosition()`, which counts from when the **audio line** was
opened, not from the start of the song. The AAC path *reopens the line* when a
stream changes sample rate midway (HE-AAC/SBR does exactly this), so the clock
reset to zero mid-track and every lyric after that point was wrong by the whole
elapsed time. Elapsed time is now banked into `positionBaseMs` before any
reopen, keeping the reported position monotonic.

> **On switching lyrics provider:** the owner asked whether to use another
> service. Word-level providers do exist (Apple Music TTML, QQ Music QRC,
> KuGou KRC), but all of them need either a paid subscription token or
> scraping an undocumented endpoint — and `bluetiers` already showed how that
> ends. LRCLIB is free, keyless and its *line* timings are accurate. Fixing the
> display was the correct fix; a new provider would not have helped, because the
> old mode would have mis-timed accurate data just the same. If word-level sync
> is ever wanted, the format to target is Enhanced LRC (`<mm:ss.xx>` per word) —
> `LyricsProvider` would need a new parser, and `LyricsCache.CACHE_VERSION` a
> bump.

### 2. Screen Recorder had no recording key

The keybind machinery worked all along — toggling the module starts/stops a
recording — but **no default key was ever bound**, and only Zoom (`C`) and the
client GUI (right shift) shipped defaults, so there was no hint recording could
be bound at all.

Default is now **F9** (free in vanilla; `F3`/`F5`/`F11` are not). Rebindable in
the module's settings page as usual, and a saved config still overrides it.

### 3. Removed two rival-client brand names

All 33 occurrences of the two names across `.java`, `.json`, `.md` and the shader source are
gone — module descriptions, javadoc, comments and the three shipped READMEs.
Two needed care rather than blind replacement:

* **`ThemeStyle.fromId()`** matched both names as legacy theme values.
  Deleting the strings naively would have been fine *by luck* (`default -> BLACK`
  catches them), but the whole retired-name list is now removed and the
  fall-through documented — **migration behaviour is unchanged**, old configs and
  shared `BLUE1-` codes still resolve correctly.
* **`SunPosition`** used one of them as a Minecraft *time-of-day* label, nothing to
  do with the client. Renamed to **`"Sunrise"`** — same meaning, same time range.

A repo-wide grep now returns **zero** matches.

---

## v18 (`0.25.1`) — fixing items from the self-audit

The owner asked for a list of things worth fixing, then asked me to fix them.
This round covers the performance items, the tooling gap, and module icons.

### The headline: the new verifier found a bug that had already shipped

Hardening `verify_mixins.py` (item 18) immediately caught a **real,
already-released defect** in `OwnNametagMixin`:

```
@ModifyExpressionValue handler for updateRenderState captures 1 of 3
target parameters - MixinExtras requires ALL or NONE
```

`updateRenderState(Entity, EntityRenderState, float)` has three parameters; the
handler captured only `(boolean original, Entity)`. It compiled, the old
verifier passed it, and `require = 0` turned the bad binding into a **silent
no-op** — meaning **your own third-person nametag never worked**, with nothing
in the log to say why. This is the second time this exact trap has bitten
(ItemPhysicsMixin in v0.24.9), which is precisely why it is now automated.

### `verify_mixins.py` — three upgrades

1. **MixinExtras signature checking.** `@ModifyExpressionValue` /
   `@ModifyReturnValue` handlers that capture target parameters must capture
   *all* of them. Partial capture is now a hard error.
2. **`require = 0` targets are checked.** They used to be skipped as "optional".
   That was backwards — optional means failures are *silent*, so they are the
   ones most worth reporting. They now surface as **warnings** (non-fatal).
3. **Superclass walking.** Mixins legitimately target inherited methods
   (`ConnectScreen.removed()` is declared on `Screen`). Without this the new
   warning produced a false positive, which would have trained the reader to
   ignore the output.

Verified by deliberately re-breaking `OwnNametagMixin` and confirming the
script fails, then restoring it.

### Performance (items 6–9, 11)

These matter because the target machine is an Intel HD 615 with a 4 GB heap.

| Fix | Before | After |
|---|---|---|
| **Hitboxes** | `byName()` lookup (+ a `toLowerCase()` allocation) *per entity per frame* | One `Hitboxes.Snapshot` per frame |
| **Hitboxes** | Iterated `world.getEntities()` — every entity in the world — then range-filtered | Bounded `getOtherEntities()` box query; cost scales with the range setting |
| **Item Physics** | Up to **10** `byName()` lookups *per item per frame* | One cached `Snapshot`, invalidated via `Setting.onChange` |
| **Totem Counter** | Rebuilt its line list **3×/frame** (render + getWidth + getHeight), each walking the player list | Built once per tick in `onTick()` |
| **Totem Counter** | "Hide at zero" walked the inventory *and* player list every frame | Also resolved once per tick |
| **Music Player** | Two **non-daemon** worker threads could hold the JVM open on quit | `setDaemon(true)`, matching every other thread in the client |

The `Snapshot` records are immutable on purpose: the renderer must not observe a
setting change halfway through an entity loop.

**Also fixed while in there:** Hitboxes read its colours with `ColorSetting.get()`
instead of `currentRgb(now)`, so the **rainbow colour option silently did
nothing**. Both colours now animate.

### Module icons (item 12)

Every one of the **106 modules now has an icon entry — up from 74**. The 32
that previously fell back to a generic per-category icon were mapped to
semantically appropriate sprites already in the atlas (`horse` → Horses,
`search` → Module Search, `milestone` → Death Coords, and so on).

14 sprites are still shared by two closely-related modules each (e.g.
`Frame Times` / `Performance Monitor`). That is deliberate: the remaining
unused sprites (`check`, `x`, `play`, `pause`…) are UI glyphs that would be
*worse* matches than an honest near-duplicate. Adding genuinely distinct art
for those pairs needs new sprites, not remapping.

### Session note: the toolchain was gone again

`/opt/blue` and the 6 GB swap file had both vanished (only ~1 GB RAM on a fresh
box). Re-provisioned JDK 21 + Gradle 9.5.0 and re-created the symlinks and swap
per the bootstrap recipe. **All 278 source files, the READMEs and the shipped
v17 artifacts survived** — as documented, only the toolchain is ephemeral.
Note `cc.sh` / `release.sh` also lose their **execute bit**; `chmod +x` them.

---

## v18 (`0.25.1`) — self-audit fixes + Item Hold Display + Crosshair+

Two tranches: the performance/tooling items from the self-audit, then the first
two features of the three-feature spec. **The Friends system is NOT in this
release** — it is a backend project of its own and is being done next.

### Tranche 1 — self-audit fixes

**The verifier found a bug that had already shipped.** Hardening
`verify_mixins.py` immediately caught a real defect in `OwnNametagMixin`:

```
@ModifyExpressionValue handler for updateRenderState captures 1 of 3
target parameters - MixinExtras requires ALL or NONE
```

`updateRenderState(Entity, EntityRenderState, float)` takes three parameters;
the handler captured two. It compiled, the old verifier passed it, and
`require = 0` made the bad binding a **silent no-op** — so **your own
third-person nametag never worked**, with nothing in the log. Second time this
trap has bitten (ItemPhysicsMixin, v0.24.9), hence the automation.

`verify_mixins.py` now: (1) checks MixinExtras handler signatures, (2) reports
`require = 0` targets as warnings instead of skipping them — *optional* means
failures are silent, so those are the ones most worth printing — and (3) walks
superclasses, since mixins legitimately target inherited methods
(`ConnectScreen.removed()` lives on `Screen`). Proven by deliberately
re-breaking the mixin and confirming a failure.

**Performance** (target hardware is an Intel HD 615 with a 4 GB heap):

| Fix | Before | After |
|---|---|---|
| Hitboxes | `byName()` + `toLowerCase()` alloc *per entity per frame* | one `Snapshot` per frame |
| Hitboxes | walked `world.getEntities()` then range-filtered | bounded `getOtherEntities()` box query |
| Item Physics | up to **10** lookups *per item per frame* | one cached `Snapshot`, invalidated via `Setting.onChange` |
| Totem Counter | line list rebuilt **3×/frame** | built once per tick |
| Music Player | 2 **non-daemon** threads could hold the JVM open | `setDaemon(true)` |

Also: Hitboxes read colours with `get()` instead of `currentRgb(now)`, so the
**rainbow option silently did nothing**. Fixed.

**Icons:** all **106 modules now have an icon** (was 74). 14 sprites are still
shared between closely-related pairs — the leftover sprites are UI glyphs
(`check`, `x`, `play`) that would be *worse* fits than an honest near-duplicate.

### Tranche 2 — Item Hold Display (new)

`hud/ItemInfo.java` + `hud/impl/ItemHoldDisplay.java`.

A **`HudModule`**, so it reuses the existing HUD editor — drag, scale and
restyle it like any other HUD element. The `Position` dropdown (Center / Top
Center / Bottom Center / Custom) is a convenience that jumps it to a common
spot; `Custom` leaves your own placement alone. Building a second positioning
system would have been a second thing to learn for no benefit.

Extraction is split from rendering: `ItemInfo` decides *what the text says*
(enchantments, durability, potion effect + `m:ss` duration, stack count), the
module decides *when and where*. The text is resolved **once per switch** into
an immutable `Snapshot`, never per frame — enchantment names hit the
translation system and durations format strings, far too costly at 60 fps for a
panel whose content cannot change while visible. Hidden cost is one null check.

**Rapid switching** (Sword → Pearl → Rod) cannot stack panels: there is exactly
one panel, and switching re-points it and restarts its timer.

**Animation** (Fade / Slide / Scale / None) is clamped to at most a third of
the display duration. This is a direct lesson from the v0.24.3 lyrics bug,
where a fixed animation longer than the segment meant alpha *never* reached 1
and the text looked permanently dim. Verified: peak alpha is 1.0 even at
0.5 s duration with a 600 ms animation.

### Tranche 2 — Crosshair+ (upgraded, not duplicated)

A `Crosshair` module already existed (38 lines: Style/Color/Size/Outline). It
was **upgraded in place**, keeping its registered name so existing configs and
`BLUE1-` share codes keep working — the same call made for Custom FOV and Totem
Counter. Two crosshair modules would both cancel the vanilla crosshair and
fight each other.

Now covers: 7 types, size/thickness/gap/opacity, outline + thickness, centre dot
+ size, outer lines + length/thickness, overall scale, hit colour + duration,
dynamic movement/attack spread, and 7 presets.

**`render/CrosshairRenderer.java` is the only place a crosshair is drawn**, used
by both the HUD mixin and the settings preview — the only way a live preview can
be trusted not to drift from the real thing. `InGameHudMixin` no longer contains
inline drawing code.

**Hit colour reuses the existing `HitReactor` interface** (the hook Hit Marker /
Hit Sound / Hit Color already use) — no second event system. It is purely visual
feedback for an attack you already made; nothing automated, nothing sent.

**Live preview** is wired into `ModuleSettingsScreen`, which previously only
previewed HUD modules. Dynamic spread is excluded from the preview so it does
not twitch merely because you are walking.

Performance: integer rect fills only, a precomputed 32-step unit circle (no
per-frame trig), no allocations beyond one `Style` record per frame.

**Verified:** arms are pixel-symmetric about the centre column at all 4080
size/thickness/gap combinations; dynamic spread is clamped so sprint-jumping
cannot blow it up; all 7 presets fall inside their slider ranges.

---

# v19 (0.25.2) — Blue Client Friends System

The third feature of the three-feature spec. Features 1 and 2 (Item Hold
Display, Crosshair+) shipped in v18.

## What it is

Accounts, friend requests, friend list, online/offline presence, current
server, last seen, blocking and privacy — backed by a **real hosted Supabase
project**, not a local JSON file.

Accounts are **username + password** and are completely independent of
Minecraft: no Microsoft account, no Mojang account, works on cracked clients.

## Where the code lives

| File | Role |
|---|---|
| `backend/schema.sql` | the whole database: tables, RLS policies, functions |
| `social/BlueBackend.java` | URL + publishable key + the fake email domain |
| `social/SupabaseClient.java` | all HTTP; returns `CompletableFuture`s |
| `social/FriendsManager.java` | cached state, presence timers, notifications |
| `social/SocialValidation.java` | username rules (mirrored in SQL) |
| `ui/screen/FriendsScreen.java` | the UI (5 tabs) |
| `README-BACKEND.md` | 22-step beginner setup guide |

Entry points: **FRIENDS** in the main-menu dock and in the pause menu.
Wired in `BlueClient` as `friends()`, ticked from the existing client tick.

## THE THING TO UNDERSTAND BEFORE EDITING

**The publishable key is inside the jar and anyone can extract it.** That is
normal (it is what a website ships in its JS) — but it means **RLS is the only
thing protecting user data**. Treat every request as coming from a hostile,
modified client.

Consequences:

* Never add `using (true)` to a table holding private data.
* Never embed the DB password or the `service_role` key. The `service_role`
  key ignores RLS entirely.
* A friendship has **no INSERT policy at all**. It can only be created by
  `accept_friend_request()`, which verifies a real request existed and that
  the caller is the receiver. Do not "helpfully" add an insert policy.

## Two non-obvious traps that were hit and fixed

1. **A policy sub-query is itself filtered by RLS.** The original
   `friend_requests` insert policy read the receiver's `settings` row to check
   their privacy level. But `settings` only lets you read your *own* row, so
   the sub-query returned nothing, the `WITH CHECK` evaluated to NULL, and
   **every friend request was rejected**. Fixed with the `security definer`
   helper `request_policy_of()`. If you add a policy that reads another
   user's row, it must go through a `security definer` function.

2. **`revoke ... from anon` does nothing on its own.** Postgres grants EXECUTE
   on new functions to `PUBLIC`, and `anon` inherits it. You must
   `revoke ... from public, anon`. Conversely the policy helpers **must stay
   granted to `authenticated`**, because a policy expression runs as the
   calling user — revoking it makes every policy fail with "permission denied
   for function". They are safe to expose because each carries an
   anti-probing guard (you may only ask about a pair that includes yourself).

## Verification (none of this ran in a real game — as always)

* **`backend_test/attack.sql` — 53 adversarial tests, all passing.** Run
  against a real Postgres 17 with a shim that imitates `auth.uid()`:
  ```bash
  sudo apt-get install -y postgresql
  export PATH=/usr/lib/postgresql/17/bin:$PATH; export PGHOST=/tmp PGPORT=5433 PGUSER=postgres
  pg_ctl -D /pgdata -o "-p 5433 -k /tmp" start
  psql -d bluetest -f backend_test/00_supabase_shim.sql
  psql -d bluetest -f backend/schema.sql
  psql -d bluetest -f backend_test/attack.sql    # expect 53 PASS, 0 FAIL
  ```
  It covers forged requests, self-inserted friendships, reading others'
  settings, block bypasses, block invisibility, search enumeration, wildcard
  injection, anonymous access, heartbeat scoping and delete cascades.
  **Re-run it after ANY change to `schema.sql`.**
* **Live Auth API probed** against the real project: signup returns a session
  immediately (`email_confirmed_at` is set, so confirmation is off), the
  refresh-token grant works, duplicate signup gives `user_already_exists`, and
  the JWT `sub` is the uuid RLS uses.
* **Request budget simulated:** 1.2 requests/min with the screen closed, 6.6
  with it open, versus 180 for a naive 1-second poll. Search debounce collapses
  5 keystrokes into 1 request.
* **UUID ordering:** Java `String.compareTo` matches Postgres `uuid` ordering
  across 3000 random pairs, so the smallest-first friendship key computed in
  Java always matches the row the database stored.

## Still to do / known gaps

* **The schema is NOT deployed yet.** Creating tables needs the SQL Editor —
  the publishable key cannot run DDL, and the sandbox has no IPv6 route to
  the DB host. The owner must do step 6 of `README-BACKEND.md` once.
* `ACCOUNT_EMAIL_DOMAIN` is `blueclient.app`, which **the owner does not own**.
  It passes Supabase validation and sends no mail, which is fine for beta, but
  should become a domain they control before a public release.
* `is_online` is readable directly off `profiles` by a determined client
  (accepted trade-off, documented in the schema). Private fields (server, last
  seen) are only served through `get_friends()`, which applies `can_view()`.
* Free-tier projects pause after ~1 week idle; Friends degrades to the
  unavailable message, which is the designed behaviour.
* `module/impl/FriendPresence.java` is a **different, older** feature (watches
  server chat for join/leave lines). It is unrelated to this system; both can
  run at once. Its header comment now says so.

---

# v20 — messaging, profiles, badges, Minecraft linking

Release `v20`, version `0.25.3`. Built on v19's Friends system.

## What was added

| Feature | Where |
|---|---|
| Email-link feature **removed** | gone from `FriendsManager`, `FriendsScreen`, README-BACKEND |
| Minecraft account linking | `social/FriendsManager.linkMinecraft/unlinkMinecraft`, `social/MojangLookup.java`, `backend/functions/verify-minecraft/index.ts` |
| DMs and groups | `ui/screen/ChatScreen.java`, `ui/screen/NewGroupScreen.java` |
| Statuses, about-me (50 chars), followers | `ui/screen/ProfileScreen.java` |
| Join a friend's server | `social/ServerJoiner.java` |
| Buddy system (3× shards) | `profiles.buddy_id`, `are_buddies_mc()`, README-PLUGIN §9 |
| Badges in nametags | `social/BadgeCache.java`, `mixin/PlayerEntityRendererMixin.java` |
| "Blue Logo" renamed **"Player Tags"** | `module/impl/BlueLogo.java` |
| Cosmetics tables | `backend/schema_v2.sql` §20 — **see below** |

## The cosmetics tables — read this before building cosmetics

`schema_v2.sql` creates **two empty tables that nothing in v20 touches**:

```sql
public.cosmetics       -- id, kind, name, rarity, texture, premium
public.user_cosmetics  -- user_id, cosmetic_id, granted_at, equipped
```

They exist **on purpose, ahead of time**. Adding tables to a database that
already has live users is the riskiest kind of change, so they were created
during the v20 migration when the schema was being touched anyway. RLS is
already enabled on both: the catalogue is world-readable, ownership is
readable, and a player may only update the `equipped` flag on rows that are
their own.

`kind` is constrained to `'cape' | 'wing' | 'hat' | 'trail' | 'pet' | 'effect'`
and `rarity` to `'common' | 'rare' | 'epic' | 'legendary'`. Widen the CHECK
constraints rather than inventing a parallel table.

### If you are the agent implementing cosmetics

1. **Do not create new tables.** Use these. Seed the catalogue with plain
   `insert`s into `cosmetics`.
2. **Add a `cosmetics_for_players(names text[])` RPC** modelled exactly on
   `badges_for_players`: one batched call, capped at 100 names, honouring a
   visibility setting. Do **not** query per player per frame.
3. **Cache like `BadgeCache`** — map lookup on the render thread, background
   refresh on a 60 s timer, never a network call inside `render()`.
4. **`equipped` must be enforced as one-per-kind**, which the current schema
   does *not* do. Either add a partial unique index
   (`unique (user_id, kind) where equipped`, requires denormalising `kind` onto
   `user_cosmetics`) or do it in an RPC. Decide before shipping; changing it
   afterwards means fixing live data.
5. **The owner will supply cape PNGs.** Capes are the most-requested item and
   the renderer for them already partly exists — check `cosmetic/` and the cape
   rendering fixes from v12 before writing anything new.
6. **Re-run the attack tests** and add cosmetics cases to
   `backend_test/attack_v2.sql`. The pattern: can a player equip a cosmetic
   they do not own? Can they read someone else's inventory? Can `anon` do
   anything at all?

## Gotchas discovered during v20

* **`GameProfile` is a record in 1.21.11** — `name()`, not `getName()`.
* **`PlayerLikeEntity` has no profile accessor.** For a raw username in a
  renderer mixin use `Entity.getNameForScoreboard()`.
* **`MinecraftClient` has no no-arg `disconnect()`** — use `disconnect(Text)`.
* **Badges render in nametags only, never the tab list.** That is a hard
  product requirement. Do not add a `PlayerListHudMixin` badge.
* **Removing a feature leaves dangling call sites.** Deleting the email-link
  methods broke `FriendsScreen` in two places. Grep the whole tree for a symbol
  before deleting it.
* **Your own test harness can be wrong.** Two of the 59 new attack tests failed
  because the *test* was wrong (an RPC truncates where the test expected a
  rejection; a "stranger" had been befriended by an earlier test). Adversarial
  fixtures share mutable state — verify the test before "fixing" the code.
* **Postgres cannot make HTTP calls**, and this environment has neither `http`
  nor `pg_net`. Anything needing an external API must be an Edge Function.
* **RLS policy subqueries are themselves RLS-filtered** — a subquery on
  `settings` returned NULL and rejected everything. Route through a
  `security definer` helper (`request_policy_of()`).
* **`revoke ... from anon` is a no-op.** EXECUTE is granted to `PUBLIC`; you
  must `revoke ... from public, anon`.

## Test status

* **112/112** backend attack tests pass (53 `attack.sql` + 59 `attack_v2.sql`).
* Java compiles clean; `verify_mixins.py` and `verify_jar.py` pass.
* **Nothing in v16–v20 has ever run in a real game.** The owner's reports are
  the only runtime signal. Treat every new screen as untested at runtime.
