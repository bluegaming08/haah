# Blue Client v28 (0.26.1) — READ THIS FIRST

This is the current release. It supersedes the v21/v22/v23 READMEs for anything
they disagree on.

```
jar     blue-client-v28-0.26.1.jar
```
(hash and size are printed at the end of the release build)

---

## 1. Installing

1. Drop `blue-client-v28-0.26.1.jar` into `mods/`.
2. Drop Fabric API `0.141.6+1.21.11` into `mods/`.
3. **Delete any older `blue-client-*.jar`.** Two versions of the same mod in
   one folder will conflict.

| Component | Version |
|---|---|
| Minecraft | `1.21.11` |
| Fabric Loader | `0.19.3` |
| Fabric API | `0.141.6+1.21.11` |
| Java | **21** |

---

## 2. YOU MUST RUN THE SQL

**Most of Social does not exist in your database yet.** Run these in the
Supabase SQL editor, in order:

```
source/backend/schema_v2.sql
source/backend/schema_v3.sql
```

Then:

```sql
select public.setup_staff();
```

Both files are idempotent (`create or replace`, `add column if not exists`,
`drop trigger if exists`), so re-running them is safe.

### Why you cannot skip this

`schema_v3.sql` defines almost the whole social system: `sync`, `get_feed`,
`get_for_you`, `create_post`, `toggle_like`, `toggle_repost`, `reply_to_post`,
`set_name_color`, `set_profile_color`, `set_skin_name`, `redeem`,
`leaderboard`, `pin_post`, the admin RPCs, the content filter and account
deletion. Only `search_users` and `accept_friend_request` live in the original
`schema.sql`.

**The old failure mode was silent** — background calls were swallowed, so a
missing RPC looked exactly like a broken client. That is fixed in v25 (see
§3.1), but the features still will not work until the schema is applied.

---

## 2a. VERIFY THE SCHEMA APPLIED

After running the SQL, run this:

```sql
select * from public.blue_selfcheck();
```

Every row should say **OK**. Any row saying MISSING names the exact feature
that will look broken in-game.

**This exists because four separate "bugs" in a row turned out to be one
thing: `schema_v3.sql` had never been applied.** The admin panel, the owner's
badges, the profile-page skin and the Blue+ banner are all defined there. The
client was asking for data the database could not return, and failing
silently.

v27 also makes the client say so out loud: if an RPC comes back "function does
not exist", Social shows a gold banner reading *"Database is out of date"*
instead of quietly doing nothing.

---

## 2b. OWNER TRANSFER — read before running the SQL

**`bluewuztaken` is now the owner. `blue` has been stripped of everything.**

Staff used to be hardcoded as the strings `'blue'` and `'cyan'` in **eight
separate places** — the follow cap, the auto-follow trigger, `setup_staff`,
`staff_on_signup`, `is_staff` and more. Changing the owner meant finding all
eight, and a missed one is a security hole: it would keep granting powers to an
account that is supposed to have none.

Staff is now a **table**:

```sql
select * from public.staff_accounts;
--  bluewuztaken | owner
--  cyan         | admin
```

One row per staff account, one place to edit, and every check reads from it via
`is_staff()`. Nobody can write that table through the API — changing who is
staff is a deliberate act in the SQL editor.

**Stripping the old owner is explicit.** Removing `blue` from the table stops
*future* grants but does not take back what `setup_staff()` already gave it, so
section 24 also revokes, for `blue`: every badge, `verified_forced`,
`plus_permanent`, `plus_until`, the equipped badge, name colour, profile colour
and any pinned post. Its `verified` flag drops back to whatever the
100-follower rule says.

After applying the schema, run:

```sql
select public.setup_staff();
```

so `bluewuztaken` receives the badges, forced verification and permanent Blue+.
It is safe to run before that account exists, and safe to re-run.

---

## 3. What changed in v24 → v26

### 3.1 The crash when opening Social — fixed

`FriendsManager.username()` could return **null**. A resumed session reports
`loggedIn() == true` the instant the refresh token is accepted, but the profile
row — and therefore the username — only arrives a round trip later. The nav
rail called `username().toLowerCase()` on that first frame and threw an NPE
inside `render()`, which takes the whole game down.

Fixed three ways:

* `username()` now returns `""` instead of null, and `profileReady()` exists
  for callers that need to know the difference.
* **`render()` is wrapped.** A throw in the render loop is a crash; now it
  shows an in-screen error and logs the stack trace instead.
* **`act()` is wrapped** the same way, so a bad click cannot kill the client.

> For the next agent: never let anything throw out of `render()`. The cost of a
> try/catch there is nothing; the cost of not having one is a crash report.

### 3.2 Header showed two overlapping titles

The header drew the tab title *and* the sub-page title at nearly the same x, so
"Home" and "Post" intersected. Now one title and one back arrow are decided
once, and sub-pages (thread / profile / chat) own the header outright.

### 3.3 Bold and Italic did nothing

`TextPainter` had **no concept of either**. The Blue+ toggles saved their value
and nothing ever read it.

Poppins ships as a single weight, so there is no real bold or italic face to
switch to. Both are now synthesised in `TextPainter.drawStyled()`, which is
what a text engine does when a face is missing: bold overdraws with sub-pixel
offsets, italic draws per character with a lean.

### 3.4 Gradient broke your name

The inline per-character loop advanced the cursor by summing **individual glyph
widths**, which is not the same as the width each character occupies inside a
word. The error accumulated, so long gradient names visibly stretched apart.

New `ui/NamePainter.java` measures the advance against the **growing prefix**
instead, so every glyph lands exactly where the unstyled string would put it.
It is now the single shared path, so gradient + bold + italic compose correctly
and behave identically on every screen.

### 3.5 Avatars were not synced

`leaderboard()` and `search_users()` never returned `skin_name`, so those
screens drew an avatar for the **account name** while everywhere else drew the
Minecraft skin. Same player, two different faces.

Both RPCs now return the skin (plus verified / plus / badge / colour), and the
`LeaderRow` and `Blocked` records carry an `avatarName()` that prefers the skin.

### 3.6 Content filter — anti-swear, anti-political, anti-spam

New `banned_words` table and `check_content()`, enforced by **database
triggers** on `posts` and `messages`. A modified client cannot bypass it.

Design decisions worth knowing:

* **Word boundaries, never substrings.** A substring filter is the classic
  Scunthorpe problem — it blocks "class", "assassin" and real place names.
  Every pattern is anchored with `\m ... \M`.
* **Leetspeak is normalised** (`4→a`, `3→e`, `0→o`, `$→s`) and repeated letters
  collapsed, so "shiiiit" matches.
* **The list is a table, not a hardcoded regex** — edit it live, no client
  update.
* **Politics is its own category** with its own message, so a political post is
  not told it contained profanity.
* Spam rules: all-caps (>70% of a message of real length), 8+ repeated
  characters, 3+ links, and the same post twice within ten minutes.

`banned_words` is readable **only by staff** — publishing the list is
publishing an evasion guide.

### 3.7 Admin panel

Staff-only nav entry (Blue and Cyan). Live stats, an open-reports queue with
delete/dismiss, and recent posts with pin/delete. Every post now has a **report
button** for everyone else.

**On "make it encrypted so no one can access it":** I did not do that, on
purpose. Client-side encryption here would be security theatre — whatever key
the client holds to decrypt the panel, an attacker holds too, because it ships
in the jar.

The real boundary is the **server**. Every admin RPC begins with
`is_staff(auth.uid())` and returns `Not authorised` otherwise, enforced by
Postgres under row level security. A modified client that forces the panel open
sees an empty screen and every button fails. That is strictly stronger than
encryption, because it does not depend on the client keeping a secret.

### 3.8 Account deletion

`delete_my_account(p_confirm)` — two-step, and the confirmation string must
equal your username exactly (checked **server-side**, so a client bug cannot
destroy an account). Deleting the profile cascades to posts, friendships,
follows, likes, messages and badges.

**Caveat:** the `auth.users` row is *not* deleted, because that needs the
`service_role` key, which must never ship in a client. The profile is gone and
the username is freed; the orphaned auth row owns nothing. Purge those from the
dashboard when convenient.

Staff accounts cannot delete themselves — `setup_staff()` would recreate half
the row and leave badges dangling.

### 3.9 Admin: redeem-code creation

The admin panel can now create codes and say what they grant: **Blue+** for a
number of days (0 = permanent), a **badge**, or a **cosmetic**. It also lists
recent codes with who redeemed them, and deletes unused ones.

A badge code naming a badge that does not exist is rejected at creation,
because it would otherwise "redeem" successfully and give the player nothing.
Used codes cannot be deleted — they are kept as a record.

### 3.10 Edit Profile is its own page

"Edit profile" used to drop you into privacy settings, where the skin field was
buried and the badge picker lived on a different screen entirely. There is now
a dedicated page with a **live preview** at the top and everything in one
place: avatar skin, status, about, and a badge picker showing the real badge
art with hover descriptions.

Each field saves on its own button rather than on every keystroke — each save
is a network write, and a live-saving text field would fire one per character.

### 3.11 Profile links everywhere

Clicking a user in Top, Explore, the sidebar, posts or notifications opens
their profile. The leaderboard and search now return the profile **id**, so
those open directly instead of round-tripping through a name lookup.

### 3.12 Profile page — rebuilt (v28)

Modelled on the two references the owner sent:

* **Discord** — a coloured banner with the avatar straddling its lower edge, a
  presence dot on the avatar corner, and a badge row underneath.
* **X** — the identity block (name, handle, bio, join date) above
  Following / Followers / Posts counts and a list of that player's posts.

Details worth knowing:

* Non-Blue+ profiles get a subtle accent **gradient** banner rather than flat
  grey, so a free profile never looks unfinished.
* The badge row shows **every badge the player owns**, not just the equipped
  one. This is what finally makes the hover descriptions visible - they were
  written in `BadgeArt` two releases ago but had nowhere to appear, because
  `get_profile` only ever returned the equipped badge. New `profile_badges()`
  RPC returns the collection, ordered by the badges table's own priority.
* The equipped badge gets a ring, so "which one is showing" is obvious.
* Verified, Blue+ and the staff shield all have hover tooltips; the Blue+ one
  reads **"Since: 3 months"** as asked.

### 3.13 Verified badge position (v27)

Nudged down by 22% of its own size. The badge is a square drawn from its top
edge while text sits on a baseline with its mass lower down, so aligning the
two tops made the badge look like it was floating. Fixed inside
`VerifiedBadge` so all seven call sites correct at once, proportionally.

### 3.14 Music: lyrics ran early on fast songs (v27)

`getMicrosecondPosition()` counts frames **handed to the audio device**, not
frames actually heard. `LINE_BUFFER` was 131072 bytes — **743 ms** of audio at
44.1 kHz stereo — so the reported position ran ahead of the sound by however
much was still queued.

That is a roughly *constant* error, which is why it only showed on fast
songs: at five seconds between lyric lines it is 6% of a line and invisible;
at one second it is 27% and obviously early.

Two fixes: `positionMs()` now subtracts what is still queued
(`bufferSize - available()`, converted using the line's own format), and
`LINE_BUFFER` dropped to 32768 bytes (186 ms). The lyric offset step also went
from 50 ms to 10 ms so the remainder can actually be tuned.

### 3.15 Smaller items

* **Home on open.** The screen always lands on Home, instead of whatever tab
  you last used.
* **First-run tutorial**, shown only when the account genuinely looks new (no
  posts, no followers, no friends), so existing players never see it.
* **Clicking your own name** in the bottom-left opens your profile page.
  Settings has its own rail entry.
* **Pause menu says SOCIAL**, not FRIENDS.
* **Rules page** in the nav rail.
* **Picture-in-Picture was removed** at the owner's request — module, the
  `pip/` package, the ModuleManager registration, the KeybindManager hook and
  the icon mapping. Module count is back to 105.

---

## 4. Still outstanding

Be honest with yourself about these before claiming the round is done.

* **The profile page revamp is NOT finished.** It renders as a page with a
  banner, avatar, badges and a sortable post list, but it has not been rebuilt
  to the Discord/X reference the owner sent. **Badge descriptions exist in
  `BadgeArt.describe()` for all nine badges and show on hover — but the profile
  page is where the owner expects to see them, so they will look missing until
  that page is redone.**
* **Nothing in v16–v25 has run in a real game.** `runClient` is not possible in
  this environment, so owner reports are the only runtime signal.
* **The backend suite has not run since v23.** Postgres is unavailable in this
  environment; sections 20–23 of `schema_v3.sql` are **syntax-checked only**
  (balanced `$$` blocks, balanced parens, every function present). Last real
  run was **285/285** at v23.
* **Release manifest URL** for the launcher's update system — still owed.

### Re-running the backend tests

```bash
export PATH=/usr/lib/postgresql/17/bin:$PATH PGHOST=/tmp PGPORT=5433 PGUSER=postgres
pg_ctl -D /pgdata -l /tmp/pg.log -o "-p 5433 -k /tmp" start
psql -d postgres -c "drop database if exists bluetest;" -c "create database bluetest;"
psql -d bluetest -f backend_test/00_supabase_shim.sql
psql -d bluetest -f backend/schema.sql
psql -d bluetest -f backend/schema_v2.sql
psql -d bluetest -f backend/schema_v3.sql
for f in attack attack_v2 attack_v3; do psql -d bluetest -f backend_test/$f.sql; done
```

PASS lines are NOTICEs on **stderr** — `2>&1 | grep -c 'NOTICE:  PASS'`.
**Always rebuild the database**: the adversarial fixtures mutate shared state.
**Always compare per-suite counts** — a schema change can silently cost an
older suite several passes while the total still looks fine.

---

## 5. What is in this zip

```
blue-client-v25-0.25.8.jar     the mod
README-V25-CURRENT.md          this file
README-NEXT-AGENT.md           full history and conventions
README-BACKEND.md              Supabase setup from scratch
README-LAUNCHER.md             launcher integration contract
README-PLUGIN.md               DonutCore server plugin
README-MICROSOFT-LOGIN.md      why MS login needs your own Azure app
README-BADGE-BACKEND.md        badge storage
README-V21/V22/V23-*.md        older release notes
source/                        full Gradle project
source/backend/*.sql           the schema you must run
source/backend_test/*.sql      the 285-assertion adversarial suite
```

Build it yourself with `./gradlew build` (needs JDK 21 and Gradle 9.5.0 —
Loom 1.17.20 requires exactly that Gradle version).
